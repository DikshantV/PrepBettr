exports.id=852,exports.ids=[852],exports.modules={10796:(e,t,r)=>{"use strict";r.d(t,{TelemetryProvider:()=>p,J:()=>m});var n=r(60687),a=r(43210),o=r(16189),s=r(96197);class i{async initialize(){this.isInitialized||(console.log("\uD83D\uDCCA Telemetry stub initialized (no actual telemetry)"),this.isInitialized=!0)}async trackPageView(e){console.log(`📊 [STUB] Page view: ${e.name}`,e)}async trackEvent(e){console.log(`📊 [STUB] Event: ${e.name}`,e)}async trackUserAction(e){console.log(`📊 [STUB] User action: ${e.action} on ${e.feature}`,e)}async trackFeatureUsage(e,t,r){console.log(`📊 [STUB] Feature usage: ${e}`,{userId:t,properties:r})}async trackMetric(e){console.log(`📈 [STUB] Metric: ${e.name} = ${e.value}`,e)}async trackBusinessMetric(e,t,r,n){console.log(`💼 [STUB] Business metric: ${e} = ${t}`,{userId:r,properties:n})}async trackInterviewCompletion(e,t,r,n,a){console.log(`🎯 [STUB] Interview completed:`,{userId:e,interviewId:t,questionCount:r,duration:n,score:a})}async trackResumeUpload(e,t,r,n){console.log(`📄 [STUB] Resume uploaded:`,{userId:e,fileSize:t,mimeType:r,processingTime:n})}async trackFormSubmission(e,t,r,n){console.log(`📝 [STUB] Form submitted: ${e}`,{userId:t,success:r,properties:n})}async trackButtonClick(e,t,r,n){console.log(`🔘 [STUB] Button clicked: ${e} at ${t}`,{userId:r,properties:n})}async trackSubscription(e,t,r,n){console.log(`💳 [STUB] Subscription ${t}: ${r}`,{userId:e,revenue:n})}async trackError(e){console.log(`🚨 [STUB] Error tracked: ${e.error.message}`,e)}async setUser(e,t,r){console.log(`👤 [STUB] User context set: ${e}`,{email:t,properties:r})}async clearUser(){console.log("\uD83D\uDC64 [STUB] User context cleared")}async trackABTest(e,t,r){console.log(`🧪 [STUB] A/B test: ${e} = ${t}`,{userId:r})}async trackConversion(e,t,r,n){console.log(`🎯 [STUB] Conversion: ${e}`,{value:t,userId:r,properties:n})}async flush(){console.log("\uD83D\uDEBF [STUB] Telemetry flushed")}getReactPlugin(){return null}getAppInsights(){return null}constructor(){this.isInitialized=!1,this.isClient=!1}}let l=new i,c=(0,a.createContext)(null);function p({children:e}){let[t,r]=(0,a.useState)(!1);(0,o.useRouter)();let{user:i}=(0,s.A)();return(0,n.jsx)(c.Provider,{value:{trackPageView:async(e,t)=>{await l.trackPageView({name:e,uri:window.location.pathname+window.location.search,userId:i?.uid,isLoggedIn:!!i,properties:t})},trackEvent:async(e,t,r)=>{await l.trackEvent({name:e,properties:{userId:i?.uid||"anonymous",...t},measurements:r})},trackUserAction:async(e,t,r)=>{await l.trackUserAction({action:e,feature:t,userId:i?.uid,properties:r})},trackFeatureUsage:async(e,t)=>{await l.trackFeatureUsage(e,i?.uid,t)},trackButtonClick:async(e,t)=>{await l.trackButtonClick(e,window.location.pathname,i?.uid,t)},trackFormSubmission:async(e,t,r)=>{await l.trackFormSubmission(e,i?.uid,t,r)},trackInterviewCompletion:async(e,t,r,n)=>{i?.uid&&await l.trackInterviewCompletion(i.uid,e,t,r,n)},trackResumeUpload:async(e,t,r)=>{i?.uid&&await l.trackResumeUpload(i.uid,e,t,r)},trackError:async(e,t)=>{await l.trackError({error:e,userId:i?.uid,context:t})},isInitialized:t},children:e})}function m(){let e=(0,a.useContext)(c);if(!e)throw Error("useTelemetry must be used within a TelemetryProvider");return e}},11967:(e,t,r)=>{Promise.resolve().then(r.bind(r,94515)),Promise.resolve().then(r.bind(r,10796)),Promise.resolve().then(r.bind(r,19760)),Promise.resolve().then(r.bind(r,96197)),Promise.resolve().then(r.bind(r,43410)),Promise.resolve().then(r.bind(r,52581))},19760:(e,t,r)=>{"use strict";r.d(t,{RouterLoadingHandler:()=>o});var n=r(43210),a=r(43410);let o=()=>{let{showLoader:e,hideLoader:t}=(0,a.M)();return(0,n.useEffect)(()=>{let r=null,n=()=>{e("",500),r=setTimeout(()=>{t(!0)},3e3)},a=()=>{r&&clearTimeout(r),t()},o=()=>{r&&clearTimeout(r),t()};return window.addEventListener("popstate",n),window.addEventListener("load",a),window.addEventListener("DOMContentLoaded",o),()=>{r&&clearTimeout(r),window.removeEventListener("popstate",n),window.removeEventListener("load",a),window.removeEventListener("DOMContentLoaded",o)}},[e,t]),null}},24824:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,16444,23)),Promise.resolve().then(r.t.bind(r,16042,23)),Promise.resolve().then(r.t.bind(r,88170,23)),Promise.resolve().then(r.t.bind(r,49477,23)),Promise.resolve().then(r.t.bind(r,29345,23)),Promise.resolve().then(r.t.bind(r,12089,23)),Promise.resolve().then(r.t.bind(r,46577,23)),Promise.resolve().then(r.t.bind(r,31307,23))},29296:(e,t,r)=>{"use strict";r.d(t,{LoadingProvider:()=>a});var n=r(12907);let a=(0,n.registerClientReference)(function(){throw Error("Attempted to call LoadingProvider() from the server but LoadingProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/contexts/LoadingContext.tsx","LoadingProvider");(0,n.registerClientReference)(function(){throw Error("Attempted to call useLoading() from the server but useLoading is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/contexts/LoadingContext.tsx","useLoading")},30119:(e,t,r)=>{Promise.resolve().then(r.bind(r,78972)),Promise.resolve().then(r.bind(r,72076)),Promise.resolve().then(r.bind(r,54310)),Promise.resolve().then(r.bind(r,94442)),Promise.resolve().then(r.bind(r,29296)),Promise.resolve().then(r.bind(r,6931))},34552:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,86346,23)),Promise.resolve().then(r.t.bind(r,27924,23)),Promise.resolve().then(r.t.bind(r,35656,23)),Promise.resolve().then(r.t.bind(r,40099,23)),Promise.resolve().then(r.t.bind(r,38243,23)),Promise.resolve().then(r.t.bind(r,28827,23)),Promise.resolve().then(r.t.bind(r,62763,23)),Promise.resolve().then(r.t.bind(r,97173,23))},36371:(e,t,r)=>{"use strict";r.d(t,{A:()=>i});var n=r(60687);r(43210);var a=r(47237),o=r(57048);let s=a.Ay.div`
  .banter-loader {
    position: relative;
    width: 72px;
    height: 72px;
    margin: 0 auto;
  }

  .banter-loader__box {
    float: left;
    position: relative;
    width: 20px;
    height: 20px;
    margin-right: 6px;
  }

  .banter-loader__box:before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: #fff;
  }

  .banter-loader__box:nth-child(3n) {
    margin-right: 0;
    margin-bottom: 6px;
  }

  .banter-loader__box:nth-child(1):before, .banter-loader__box:nth-child(4):before {
    margin-left: 26px;
  }

  .banter-loader__box:nth-child(3):before {
    margin-top: 52px;
  }

  .banter-loader__box:last-child {
    margin-bottom: 0;
  }

  @keyframes moveBox-1 {
    9.0909090909% {
      transform: translate(-26px, 0);
    }

    18.1818181818% {
      transform: translate(0px, 0);
    }

    27.2727272727% {
      transform: translate(0px, 0);
    }

    36.3636363636% {
      transform: translate(26px, 0);
    }

    45.4545454545% {
      transform: translate(26px, 26px);
    }

    54.5454545455% {
      transform: translate(26px, 26px);
    }

    63.6363636364% {
      transform: translate(26px, 26px);
    }

    72.7272727273% {
      transform: translate(26px, 0px);
    }

    81.8181818182% {
      transform: translate(0px, 0px);
    }

    90.9090909091% {
      transform: translate(-26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(1) {
    animation: moveBox-1 4s infinite;
  }

  @keyframes moveBox-2 {
    9.0909090909% {
      transform: translate(0, 0);
    }

    18.1818181818% {
      transform: translate(26px, 0);
    }

    27.2727272727% {
      transform: translate(0px, 0);
    }

    36.3636363636% {
      transform: translate(26px, 0);
    }

    45.4545454545% {
      transform: translate(26px, 26px);
    }

    54.5454545455% {
      transform: translate(26px, 26px);
    }

    63.6363636364% {
      transform: translate(26px, 26px);
    }

    72.7272727273% {
      transform: translate(26px, 26px);
    }

    81.8181818182% {
      transform: translate(0px, 26px);
    }

    90.9090909091% {
      transform: translate(0px, 26px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(2) {
    animation: moveBox-2 4s infinite;
  }

  @keyframes moveBox-3 {
    9.0909090909% {
      transform: translate(-26px, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(0px, 0);
    }

    36.3636363636% {
      transform: translate(-26px, 0);
    }

    45.4545454545% {
      transform: translate(-26px, 0);
    }

    54.5454545455% {
      transform: translate(-26px, 0);
    }

    63.6363636364% {
      transform: translate(-26px, 0);
    }

    72.7272727273% {
      transform: translate(-26px, 0);
    }

    81.8181818182% {
      transform: translate(-26px, -26px);
    }

    90.9090909091% {
      transform: translate(0px, -26px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(3) {
    animation: moveBox-3 4s infinite;
  }

  @keyframes moveBox-4 {
    9.0909090909% {
      transform: translate(-26px, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(-26px, -26px);
    }

    36.3636363636% {
      transform: translate(0px, -26px);
    }

    45.4545454545% {
      transform: translate(0px, 0px);
    }

    54.5454545455% {
      transform: translate(0px, -26px);
    }

    63.6363636364% {
      transform: translate(0px, -26px);
    }

    72.7272727273% {
      transform: translate(0px, -26px);
    }

    81.8181818182% {
      transform: translate(-26px, -26px);
    }

    90.9090909091% {
      transform: translate(-26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(4) {
    animation: moveBox-4 4s infinite;
  }

  @keyframes moveBox-5 {
    9.0909090909% {
      transform: translate(0, 0);
    }

    18.1818181818% {
      transform: translate(0, 0);
    }

    27.2727272727% {
      transform: translate(0, 0);
    }

    36.3636363636% {
      transform: translate(26px, 0);
    }

    45.4545454545% {
      transform: translate(26px, 0);
    }

    54.5454545455% {
      transform: translate(26px, 0);
    }

    63.6363636364% {
      transform: translate(26px, 0);
    }

    72.7272727273% {
      transform: translate(26px, 0);
    }

    81.8181818182% {
      transform: translate(26px, -26px);
    }

    90.9090909091% {
      transform: translate(0px, -26px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(5) {
    animation: moveBox-5 4s infinite;
  }

  @keyframes moveBox-6 {
    9.0909090909% {
      transform: translate(0, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(-26px, 0);
    }

    36.3636363636% {
      transform: translate(0px, 0);
    }

    45.4545454545% {
      transform: translate(0px, 0);
    }

    54.5454545455% {
      transform: translate(0px, 0);
    }

    63.6363636364% {
      transform: translate(0px, 0);
    }

    72.7272727273% {
      transform: translate(0px, 26px);
    }

    81.8181818182% {
      transform: translate(-26px, 26px);
    }

    90.9090909091% {
      transform: translate(-26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(6) {
    animation: moveBox-6 4s infinite;
  }

  @keyframes moveBox-7 {
    9.0909090909% {
      transform: translate(26px, 0);
    }

    18.1818181818% {
      transform: translate(26px, 0);
    }

    27.2727272727% {
      transform: translate(26px, 0);
    }

    36.3636363636% {
      transform: translate(0px, 0);
    }

    45.4545454545% {
      transform: translate(0px, -26px);
    }

    54.5454545455% {
      transform: translate(26px, -26px);
    }

    63.6363636364% {
      transform: translate(0px, -26px);
    }

    72.7272727273% {
      transform: translate(0px, -26px);
    }

    81.8181818182% {
      transform: translate(0px, 0px);
    }

    90.9090909091% {
      transform: translate(26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(7) {
    animation: moveBox-7 4s infinite;
  }

  @keyframes moveBox-8 {
    9.0909090909% {
      transform: translate(0, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(-26px, -26px);
    }

    36.3636363636% {
      transform: translate(0px, -26px);
    }

    45.4545454545% {
      transform: translate(0px, -26px);
    }

    54.5454545455% {
      transform: translate(0px, -26px);
    }

    63.6363636364% {
      transform: translate(0px, -26px);
    }

    72.7272727273% {
      transform: translate(0px, -26px);
    }

    81.8181818182% {
      transform: translate(26px, -26px);
    }

    90.9090909091% {
      transform: translate(26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(8) {
    animation: moveBox-8 4s infinite;
  }

  @keyframes moveBox-9 {
    9.0909090909% {
      transform: translate(-26px, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(0px, 0);
    }

    36.3636363636% {
      transform: translate(-26px, 0);
    }

    45.4545454545% {
      transform: translate(0px, 0);
    }

    54.5454545455% {
      transform: translate(0px, 0);
    }

    63.6363636364% {
      transform: translate(-26px, 0);
    }

    72.7272727273% {
      transform: translate(-26px, 0);
    }

    81.8181818182% {
      transform: translate(-52px, 0);
    }

    90.9090909091% {
      transform: translate(-26px, 0);
    }

    100% {
      transform: translate(0px, 0);
    }
  }

  .banter-loader__box:nth-child(9) {
    animation: moveBox-9 4s infinite;
  }
`,i=({overlay:e=!1,text:t,backgroundOpacity:r=80,blur:a=!0,className:i,ariaLabel:l="Loading..."})=>{let c=(0,n.jsxs)(s,{className:i,children:[(0,n.jsxs)("div",{className:"banter-loader",children:[(0,n.jsx)("div",{className:"banter-loader__box"}),(0,n.jsx)("div",{className:"banter-loader__box"}),(0,n.jsx)("div",{className:"banter-loader__box"}),(0,n.jsx)("div",{className:"banter-loader__box"}),(0,n.jsx)("div",{className:"banter-loader__box"}),(0,n.jsx)("div",{className:"banter-loader__box"}),(0,n.jsx)("div",{className:"banter-loader__box"}),(0,n.jsx)("div",{className:"banter-loader__box"}),(0,n.jsx)("div",{className:"banter-loader__box"})]}),e&&t&&(0,n.jsx)("p",{className:"text-white text-center mt-4 font-medium","aria-live":"polite",children:t})]});return e?(0,n.jsx)("div",{className:(0,o.cn)("fixed inset-0 z-50 flex items-center justify-center flex-col",a&&"backdrop-blur-md","transition-all duration-300"),style:{backgroundColor:`rgba(0, 0, 0, ${r/100})`,backdropFilter:a?"blur(8px)":"none",WebkitBackdropFilter:a?"blur(8px)":"none"},role:"dialog","aria-modal":"true","aria-label":l,children:(0,n.jsx)("div",{className:"relative",children:c})}):(0,n.jsx)("div",{role:"status","aria-label":l,children:c})}},43410:(e,t,r)=>{"use strict";r.d(t,{LoadingProvider:()=>i,M:()=>l});var n=r(60687),a=r(43210),o=r(36371);let s=(0,a.createContext)(void 0),i=({children:e})=>{let[t,r]=(0,a.useState)(!1),[i,l]=(0,a.useState)("Loading..."),[c,p]=(0,a.useState)(500),m=(0,a.useRef)(null),d=(0,a.useRef)(null),u=(0,a.useRef)(null);return(0,n.jsxs)(s.Provider,{value:{isLoading:t,loadingText:i,showLoader:(e="Loading...",t)=>{m.current&&clearTimeout(m.current),u.current&&clearTimeout(u.current),l(e),r(!0),d.current=Date.now(),void 0!==t&&p(t),u.current=setTimeout(()=>{console.warn("Loading timeout reached, force hiding loader"),r(!1),d.current=null},5e3)},hideLoader:(e=!1)=>{if(u.current&&clearTimeout(u.current),e){m.current&&clearTimeout(m.current),r(!1),d.current=null;return}let t=Math.max(0,c-(d.current?Date.now()-d.current:0));t>0?m.current=setTimeout(()=>{r(!1),d.current=null},t):(r(!1),d.current=null)},setMinimumDuration:e=>p(e)},children:[e,t&&(0,n.jsx)(o.A,{overlay:!0,text:i})]})},l=()=>{let e=(0,a.useContext)(s);if(!e)throw Error("useLoading must be used within a LoadingProvider");return e}},46024:(e,t,r)=>{"use strict";r.d(t,{zc:()=>a});var n=r(32190);class a{static initialize(e){}static withErrorHandler(e){return async t=>{try{return await e(t)}catch(e){return this.handleError(e,t)}}}static handleError(e,t){let r=this.normalizeError(e),n=this.extractErrorDetails(r,t);return this.logError(r,n),this.createErrorResponse(r,n)}static normalizeError(e){return e.statusCode&&void 0!==e.isOperational?e:"ECONNRESET"===e.code||"ENOTFOUND"===e.code?{name:"NetworkError",message:"Network connection failed",statusCode:503,code:e.code,isOperational:!0,stack:e.stack}:"ValidationError"===e.name||"ZodError"===e.name?{name:"ValidationError",message:e.message||"Validation failed",statusCode:400,code:"VALIDATION_ERROR",isOperational:!0,stack:e.stack}:e.message?.includes("unauthorized")||e.message?.includes("token")?{name:"AuthenticationError",message:"Authentication failed",statusCode:401,code:"AUTH_ERROR",isOperational:!0,stack:e.stack}:e.message?.includes("rate limit")||e.message?.includes("throttled")?{name:"RateLimitError",message:"Rate limit exceeded",statusCode:429,code:"RATE_LIMIT_ERROR",isOperational:!0,stack:e.stack}:e.message?.includes("Azure OpenAI")||e.message?.includes("OpenAI")?{name:"ExternalServiceError",message:"External AI service error",statusCode:502,code:"AI_SERVICE_ERROR",isOperational:!0,stack:e.stack}:{name:e.name||"InternalError",message:e.message||"An internal server error occurred",statusCode:500,code:"INTERNAL_ERROR",isOperational:!1,stack:e.stack}}static extractErrorDetails(e,t){let r=t?.url?new URL(t.url):void 0,n=t?.headers;return{userId:this.extractUserId(t),jobId:this.extractJobId(t),action:r?.pathname||"unknown",requestId:n?.get("x-request-id")||void 0,userAgent:n?.get("user-agent")||void 0,path:r?.pathname||void 0,method:t?.method||void 0,statusCode:e.statusCode||500,stack:e.stack,timestamp:new Date().toISOString()}}static extractUserId(e){if(!e)return;if(e.cookies.get("session")?.value)try{return"user_from_session"}catch{}let t=e.headers.get("x-user-id");if(t)return t}static extractJobId(e){if(!e)return;let t=e.url?new URL(e.url):void 0,r=t?.pathname.match(/\/jobs\/([^\/]+)/);if(r)return r[1];let n=t?.searchParams.get("jobId");if(n)return n}static logError(e,t){let r={level:"error",message:`API Error: ${e.message}`,properties:{errorName:e.name,errorCode:e.code,statusCode:e.statusCode,isOperational:e.isOperational,userId:t.userId,jobId:t.jobId,action:t.action,requestId:t.requestId,userAgent:t.userAgent,path:t.path,method:t.method,timestamp:t.timestamp},exception:{message:e.message,stack:e.stack,name:e.name}};console.error("API_ERROR",JSON.stringify(r)),this.appInsights&&(this.appInsights.trackException({exception:e,properties:r.properties,severityLevel:e.isOperational?2:3}),this.appInsights.trackMetric({name:"ApiError",average:1,sampleCount:1,properties:{errorCode:e.code||"unknown",statusCode:e.statusCode?.toString()||"500",action:t.action||"unknown"}}))}static createErrorResponse(e,t){let r={error:{message:e.isOperational?e.message:"An internal server error occurred",code:e.code||"INTERNAL_ERROR",timestamp:t.timestamp,requestId:t.requestId}};return n.NextResponse.json(r,{status:e.statusCode||500,headers:{"Content-Type":"application/json","X-Request-ID":t.requestId||"unknown"}})}static createOperationalError(e,t=400,r){return{name:"OperationalError",message:e,statusCode:t,code:r||"OPERATIONAL_ERROR",isOperational:!0}}static createProgrammingError(e,t){return{name:"ProgrammingError",message:e,statusCode:500,code:"PROGRAMMING_ERROR",isOperational:!1,stack:t?.stack}}}a.createOperationalError,a.createProgrammingError},46502:(e,t,r)=>{"use strict";r.d(t,{j:()=>n});class n{static initialize(e){}static async execute(e,t={}){let r,{maxRetries:n=3,baseDelay:a=1e3,maxDelay:o=3e4,jitter:s=!0,retryCondition:i=this.defaultRetryCondition,onRetry:l,userId:c,action:p="unknown"}=t,m=Date.now();for(let t=0;t<=n;t++)try{let r=await e();return t>0&&this.logRetrySuccess({attempt:t+1,totalAttempts:t+1,delay:0,userId:c,action:p,startTime:m,endTime:Date.now()}),r}catch(u){if(r=u,t===n||!i(u))throw this.logRetryFailure({attempt:t+1,totalAttempts:n+1,delay:0,error:u,userId:c,action:p,startTime:m,endTime:Date.now()}),u;let e=Math.min(a*Math.pow(2,t),o),d=s?e+Math.random()*e*.1:e;this.logRetryAttempt({attempt:t+1,totalAttempts:n+1,delay:d,error:u,userId:c,action:p,startTime:m}),l&&l(u,t+1),await this.sleep(d)}throw r}static defaultRetryCondition(e){if("ECONNRESET"===e.code||"ENOTFOUND"===e.code||"ECONNREFUSED"===e.code)return!0;if(e.response?.status){let t=e.response.status;return 429===t||502===t||503===t||504===t}return!!(e.message?.includes("rate limit")||e.message?.includes("throttled")||e.message?.includes("quota exceeded"))}static sleep(e){return new Promise(t=>setTimeout(t,e))}static logRetryAttempt(e){let t={level:"warn",message:`Retry attempt ${e.attempt}/${e.totalAttempts} for ${e.action}`,properties:{userId:e.userId,action:e.action,attempt:e.attempt,totalAttempts:e.totalAttempts,delay:e.delay,error:{message:e.error?.message,code:e.error?.code,status:e.error?.response?.status,name:e.error?.name},timestamp:new Date().toISOString()}};console.warn("RETRY_ATTEMPT",JSON.stringify(t)),this.appInsights&&this.appInsights.trackTrace({message:t.message,severityLevel:2,properties:t.properties})}static logRetrySuccess(e){let t=(e.endTime||Date.now())-e.startTime,r={level:"info",message:`Retry succeeded for ${e.action} after ${e.attempt} attempts`,properties:{userId:e.userId,action:e.action,attempt:e.attempt,totalAttempts:e.totalAttempts,duration:t,timestamp:new Date().toISOString()}};console.log("RETRY_SUCCESS",JSON.stringify(r)),this.appInsights&&(this.appInsights.trackTrace({message:r.message,severityLevel:1,properties:r.properties}),this.appInsights.trackMetric({name:"RetrySuccess",average:e.attempt,sampleCount:1,properties:{action:e.action,userId:e.userId||"unknown"}}))}static logRetryFailure(e){let t=(e.endTime||Date.now())-e.startTime,r={level:"error",message:`Retry failed for ${e.action} after ${e.attempt} attempts`,properties:{userId:e.userId,action:e.action,attempt:e.attempt,totalAttempts:e.totalAttempts,duration:t,error:{message:e.error?.message,code:e.error?.code,status:e.error?.response?.status,name:e.error?.name,stack:e.error?.stack},timestamp:new Date().toISOString()}};console.error("RETRY_FAILURE",JSON.stringify(r)),this.appInsights&&(this.appInsights.trackException({exception:e.error,properties:r.properties,severityLevel:3}),this.appInsights.trackMetric({name:"RetryFailure",average:e.attempt,sampleCount:1,properties:{action:e.action,userId:e.userId||"unknown"}}))}}},54310:(e,t,r)=>{"use strict";r.d(t,{RouterLoadingHandler:()=>n});let n=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call RouterLoadingHandler() from the server but RouterLoadingHandler is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/components/RouterLoadingHandler.tsx","RouterLoadingHandler")},57048:(e,t,r)=>{"use strict";r.d(t,{cn:()=>i,L8:()=>c,o8:()=>p,iE:()=>l});var n=r(9275);n.z.object({totalScore:n.z.number(),categoryScores:n.z.tuple([n.z.object({name:n.z.literal("Communication Skills"),score:n.z.number(),comment:n.z.string()}),n.z.object({name:n.z.literal("Technical Knowledge"),score:n.z.number(),comment:n.z.string()}),n.z.object({name:n.z.literal("Problem Solving"),score:n.z.number(),comment:n.z.string()}),n.z.object({name:n.z.literal("Cultural Fit"),score:n.z.number(),comment:n.z.string()}),n.z.object({name:n.z.literal("Confidence and Clarity"),score:n.z.number(),comment:n.z.string()})]),strengths:n.z.array(n.z.string()),areasForImprovement:n.z.array(n.z.string()),finalAssessment:n.z.string()});let a=[{name:"Apple",logo:"/apple.svg"},{name:"Microsoft",logo:"/microsoft.svg"},{name:"Google",logo:"/google.svg"},{name:"OpenAI",logo:"/openai.svg"},{name:"Instagram",logo:"/instagram.svg"},{name:"IBM",logo:"/ibm.svg"},{name:"LinkedIn",logo:"/linkedin.png"},{name:"Tesla",logo:"/tesla.png"},{name:"Netflix",logo:"/netflix.svg"},{name:"Amazon",logo:"/amazon.png"},{name:"Meta",logo:"/meta.png"},{name:"Adobe",logo:"/adobe.png"},{name:"Spotify",logo:"/spotify.png"},{name:"Airbnb",logo:"/airbnb.svg"},{name:"Uber",logo:"/uber.svg"},{name:"Reddit",logo:"/reddit.png"},{name:"Pinterest",logo:"/pinterest.png"},{name:"Quora",logo:"/quora.png"},{name:"Skype",logo:"/skype.png"},{name:"TikTok",logo:"/tiktok.png"},{name:"Yahoo",logo:"/yahoo.png"},{name:"Telegram",logo:"/telegram.png"},{name:"Facebook",logo:"/facebook.png"},{name:"Hostinger",logo:"/hostinger.png"}];a.map(e=>e.logo);var o=r(49384),s=r(82348);function i(...e){return(0,s.QP)((0,o.$)(e))}function l(e){return e?"string"==typeof e?e.split(",").map(e=>e.trim()).filter(Boolean):Array.isArray(e)?e.filter(e=>"string"==typeof e&&e.trim()):[]:[]}let c=e=>{if(e){let t=e.split("").reduce((e,t)=>e+t.charCodeAt(0),0)%a.length,r=a[t],n=`/covers${r.logo}`;return console.log("Generated company logo:",n,"Company:",r.name,"for ID:",e),{logo:n,company:r.name}}let t=a[0],r=`/covers${t.logo}`;return console.log("Fallback company logo:",r,"Company:",t.name),{logo:r,company:t.name}},p=e=>c(e).logo},58014:(e,t,r)=>{"use strict";r.a(e,async(e,n)=>{try{r.r(t),r.d(t,{default:()=>f,metadata:()=>E});var a=r(37413),o=r(6931),s=r(87664),i=r.n(s),l=r(94442),c=r(29296),p=r(54310),m=r(72076),d=r(78972),u=r(79881),h=r(46502),g=r(46024);r(82704);var v=e([u]);u=(v.then?(await v)():v)[0],(0,u.c)();let x="9ae93338-ec14-4020-9a1c-79098b102a7d";x&&(h.j.initialize(x),g.zc.initialize(x));let E={title:"PrepBettr",description:"An AI-powered platform for preparing for mock interviews",icons:{icon:[{url:"/icon",sizes:"512x512",type:"image/png"}],apple:[{url:"/apple-icon",sizes:"1024x1024",type:"image/png"}],other:[{rel:"icon",url:"/favicon.ico",sizes:"256x256"}]}};function f({children:e}){return(0,a.jsx)("html",{lang:"en",className:"dark",children:(0,a.jsxs)("body",{className:`${i().className} antialiased`,style:{backgroundColor:"#0a0a0a",backgroundImage:"url('/pattern.png')",backgroundSize:"cover",backgroundPosition:"center",backgroundRepeat:"no-repeat",backgroundAttachment:"fixed","--color-background":"transparent","--background":"transparent"},suppressHydrationWarning:!0,children:[(0,a.jsx)(d.default,{children:(0,a.jsxs)(c.LoadingProvider,{children:[(0,a.jsx)(p.RouterLoadingHandler,{}),(0,a.jsx)(l.AuthProvider,{children:(0,a.jsx)(m.TelemetryProvider,{children:e})})]})}),(0,a.jsx)(o.Toaster,{})]})})}n()}catch(e){n(e)}})},72076:(e,t,r)=>{"use strict";r.d(t,{TelemetryProvider:()=>a});var n=r(12907);let a=(0,n.registerClientReference)(function(){throw Error("Attempted to call TelemetryProvider() from the server but TelemetryProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/components/providers/TelemetryProvider.tsx","TelemetryProvider");(0,n.registerClientReference)(function(){throw Error("Attempted to call useTelemetry() from the server but useTelemetry is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/components/providers/TelemetryProvider.tsx","useTelemetry"),(0,n.registerClientReference)(function(){throw Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/components/providers/TelemetryProvider.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/components/providers/TelemetryProvider.tsx","default")},78972:(e,t,r)=>{"use strict";r.d(t,{default:()=>n});let n=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/app/providers.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/app/providers.tsx","default")},79881:(e,t,r)=>{"use strict";r.a(e,async(e,n)=>{try{r.d(t,{c:()=>s});var a=r(85500),o=e([a]);async function s(){try{console.log("\uD83D\uDE80 Initializing Azure services..."),await (0,a.hT)();let e=(0,a.iq)();console.log("\uD83D\uDD0D Azure configuration status:",{keyVaultUri:e.keyVaultUri,hasSecretsCache:e.hasSecretsCache,environmentVariables:{speechKey:e.environment.speechKey?"SET":"MISSING",speechEndpoint:e.environment.speechEndpoint?"SET":"MISSING",azureOpenAIKey:e.environment.azureOpenAIKey?"SET":"MISSING",azureOpenAIEndpoint:e.environment.azureOpenAIEndpoint?"SET":"MISSING",azureOpenAIDeployment:e.environment.azureOpenAIDeployment?"SET":"MISSING"}}),console.log("✅ Azure services initialized successfully")}catch(e){console.error("❌ Failed to initialize Azure services:",e)}}a=(o.then?(await o)():o)[0],n()}catch(e){n(e)}})},82704:()=>{},82897:(e,t,r)=>{"use strict";r.d(t,{db:()=>l,j2:()=>i});var n=r(75535),a=r(67989),o=r(4656);let s=(0,a.Dk)().length?(0,a.Sx)():(0,a.Wp)({apiKey:"AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8",authDomain:"prepbettr.firebaseapp.com",projectId:"prepbettr",storageBucket:"prepbettr.firebasestorage.app",messagingSenderId:"660242808945",appId:"1:660242808945:web:4edbaac82ed140f4d05bd0",measurementId:"G-LF6KN9F2HY"}),i=(0,o.xI)(s),l=(0,n.aU)(s);new o.HF},85500:(e,t,r)=>{"use strict";r.a(e,async(e,n)=>{try{r.d(t,{hT:()=>l,iq:()=>c});var a=r(10756),o=r(36695),s=e([a,o]);[a,o]=s.then?(await s)():s;let p=process.env.AZURE_KEY_VAULT_URI||"https://prepbettr-keyvault-083.vault.azure.net/",m=null;async function i(e=!1){if(e&&(console.log("\uD83D\uDD04 Clearing Azure secrets cache..."),m=null),m)return m;try{console.log("\uD83D\uDD11 Fetching secrets from Azure Key Vault...");let e=function(){if(!p)throw Error("AZURE_KEY_VAULT_URI environment variable is required");let e=new a.DefaultAzureCredential;return new o.SecretClient(p,e)}(),t=t=>e.getSecret(t).catch(e=>(404!==e.statusCode&&console.warn(`⚠️ Unexpected error fetching optional secret '${t}':`,e.message),null)),[r,n,s,i,l,c,d,u,h,g,v,f]=await Promise.all([e.getSecret("speech-key"),e.getSecret("speech-endpoint"),e.getSecret("azure-openai-key"),e.getSecret("azure-openai-endpoint"),e.getSecret("azure-openai-deployment"),t("firebase-project-id"),t("firebase-client-email"),t("firebase-private-key"),t("azure-form-recognizer-key"),t("azure-form-recognizer-endpoint"),t("azure-storage-account-name"),t("azure-storage-account-key")]),x={speechKey:r?.value,speechEndpoint:n?.value,azureOpenAIKey:s?.value,azureOpenAIEndpoint:i?.value,azureOpenAIDeployment:l?.value},E=Object.entries(x).filter(([e,t])=>!t).map(([e,t])=>e);if(E.length>0)throw Error(`Required Azure secrets missing from Key Vault: ${E.join(", ")}`);return m={speechKey:r.value,speechEndpoint:n.value,azureOpenAIKey:s.value,azureOpenAIEndpoint:i.value,azureOpenAIDeployment:l.value,firebaseProjectId:c?.value||process.env.FIREBASE_PROJECT_ID||"",firebaseClientEmail:d?.value||process.env.FIREBASE_CLIENT_EMAIL||"",firebasePrivateKey:u?.value||process.env.FIREBASE_PRIVATE_KEY||"",azureFormRecognizerKey:h?.value,azureFormRecognizerEndpoint:g?.value,azureStorageAccountName:v?.value,azureStorageAccountKey:f?.value},console.log("✅ Azure secrets loaded successfully"),m}catch(n){console.error("❌ Failed to fetch Azure secrets:",n),console.log("\uD83D\uDD04 Falling back to environment variables...");let e={speechKey:process.env.AZURE_SPEECH_KEY||process.env.SPEECH_KEY||"",speechEndpoint:process.env.SPEECH_ENDPOINT||"https://eastus2.api.cognitive.microsoft.com/",azureOpenAIKey:process.env.AZURE_OPENAI_API_KEY||process.env.AZURE_OPENAI_KEY||"",azureOpenAIEndpoint:process.env.AZURE_OPENAI_ENDPOINT||"",azureOpenAIDeployment:process.env.AZURE_OPENAI_DEPLOYMENT||"",firebaseProjectId:process.env.FIREBASE_PROJECT_ID||"",firebaseClientEmail:process.env.FIREBASE_CLIENT_EMAIL||"",firebasePrivateKey:process.env.FIREBASE_PRIVATE_KEY||"",azureFormRecognizerKey:process.env.AZURE_FORM_RECOGNIZER_KEY,azureFormRecognizerEndpoint:process.env.AZURE_FORM_RECOGNIZER_ENDPOINT,azureStorageAccountName:process.env.AZURE_STORAGE_ACCOUNT_NAME,azureStorageAccountKey:process.env.AZURE_STORAGE_ACCOUNT_KEY},t=[];e.speechKey||t.push("SPEECH_KEY"),e.azureOpenAIKey||t.push("AZURE_OPENAI_KEY");let r=[];return e.firebaseProjectId||process.env.FIREBASE_PROJECT_ID||r.push("FIREBASE_PROJECT_ID"),t.length>0&&console.error(`❌ Critical secrets missing: ${t.join(", ")}`),r.length>0&&console.warn(`⚠️ Optional secrets missing: ${r.join(", ")}`),m=e}}async function l(){try{let e=await i();process.env.NEXT_PUBLIC_SPEECH_KEY=e.speechKey,process.env.NEXT_PUBLIC_SPEECH_ENDPOINT=e.speechEndpoint,process.env.SPEECH_KEY=e.speechKey,process.env.SPEECH_ENDPOINT=e.speechEndpoint,process.env.AZURE_OPENAI_KEY=e.azureOpenAIKey,process.env.AZURE_OPENAI_ENDPOINT=e.azureOpenAIEndpoint,process.env.AZURE_OPENAI_DEPLOYMENT=e.azureOpenAIDeployment,process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY=e.azureOpenAIKey,process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT=e.azureOpenAIEndpoint,process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT=e.azureOpenAIDeployment,process.env.FIREBASE_PROJECT_ID=e.firebaseProjectId,process.env.FIREBASE_CLIENT_EMAIL=e.firebaseClientEmail,process.env.FIREBASE_PRIVATE_KEY=e.firebasePrivateKey,process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID=e.firebaseProjectId,e.azureFormRecognizerKey&&(process.env.AZURE_FORM_RECOGNIZER_KEY=e.azureFormRecognizerKey),e.azureFormRecognizerEndpoint&&(process.env.AZURE_FORM_RECOGNIZER_ENDPOINT=e.azureFormRecognizerEndpoint),e.azureStorageAccountName&&(process.env.AZURE_STORAGE_ACCOUNT_NAME=e.azureStorageAccountName),e.azureStorageAccountKey&&(process.env.AZURE_STORAGE_ACCOUNT_KEY=e.azureStorageAccountKey),console.log("\uD83C\uDF1F Azure environment initialized successfully")}catch(e){throw console.error("❌ Failed to initialize Azure environment:",e),e}}function c(){return{keyVaultUri:p,hasSecretsCache:!!m,environment:{speechKey:!!process.env.NEXT_PUBLIC_SPEECH_KEY,speechEndpoint:!!process.env.NEXT_PUBLIC_SPEECH_ENDPOINT,azureOpenAIKey:!!process.env.AZURE_OPENAI_KEY,azureOpenAIEndpoint:!!process.env.AZURE_OPENAI_ENDPOINT,azureOpenAIDeployment:!!process.env.AZURE_OPENAI_DEPLOYMENT}}}n()}catch(e){n(e)}})},94442:(e,t,r)=>{"use strict";r.d(t,{AuthProvider:()=>a});var n=r(12907);let a=(0,n.registerClientReference)(function(){throw Error("Attempted to call AuthProvider() from the server but AuthProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/contexts/AuthContext.tsx","AuthProvider");(0,n.registerClientReference)(function(){throw Error("Attempted to call useAuth() from the server but useAuth is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/contexts/AuthContext.tsx","useAuth"),(0,n.registerClientReference)(function(){throw Error("Attempted to call AuthContext() from the server but AuthContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/dikshantvashistha/PrepBettr/contexts/AuthContext.tsx","AuthContext")},94515:(e,t,r)=>{"use strict";r.d(t,{default:()=>c});var n=r(60687),a=r(60458),o=r(25995),s=r(52581);let i={dedupingInterval:3e5,focusThrottleInterval:3e4,revalidateOnReconnect:!0,revalidateOnFocus:!1,errorRetryCount:3,errorRetryInterval:1e3,loadingTimeout:3e3,onError:(e,t)=>{console.error("SWR Error:",{error:e,key:t}),!(e?.code==="permission-denied"||e?.message?.includes("auth"))&&e?.message&&s.o.error("Something went wrong",{description:"Please try again in a moment."})},onSuccess:(e,t)=>{},fallback:{},revalidateIfStale:!0,keepPreviousData:!0,suspense:!1};function l({children:e}){return(0,n.jsx)(o.BE,{value:i,children:e})}function c({children:e}){return(0,n.jsx)(l,{children:(0,n.jsx)(a.y,{theme:{fontFamily:"inherit",primaryColor:"blue"},children:e})})}},96197:(e,t,r)=>{"use strict";r.d(t,{AuthProvider:()=>s,A:()=>i});var n=r(60687),a=r(43210);r(4656),r(82897);let o=(0,a.createContext)({user:null,loading:!0,isAuthenticated:!1});function s({children:e,initialUser:t}){let[r,s]=(0,a.useState)(t||null),[i,l]=(0,a.useState)(!t);return(0,n.jsx)(o.Provider,{value:{user:r,loading:i,isAuthenticated:!!r},children:e})}function i(){let e=(0,a.useContext)(o);if(void 0===e)throw Error("useAuth must be used within an AuthProvider");return e}}};