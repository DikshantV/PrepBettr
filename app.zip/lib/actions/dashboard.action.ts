// Static export stubs
export async function createInterview() {
  return { error: 'Static mode' };
}

export async function getUserInterviews() {
  return [];
}

export async function getPublicInterviews() {
  return [];
}
