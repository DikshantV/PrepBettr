"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[5142],{

/***/ 23274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ useAuth),
/* harmony export */   AuthProvider: () => (/* binding */ AuthProvider)
/* harmony export */ });
/* unused harmony export AuthContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* __next_internal_client_entry_do_not_use__ AuthProvider,useAuth,AuthContext auto */ 

/**
 * Refresh the current Firebase auth token
 */ async function refreshAuthToken() {
    try {
        // Import Firebase auth dynamically to avoid SSR issues
        const { getCurrentUserIdToken } = await Promise.all(/* import() */[__webpack_require__.e(2992), __webpack_require__.e(7811), __webpack_require__.e(1840), __webpack_require__.e(3549), __webpack_require__.e(2144)]).then(__webpack_require__.bind(__webpack_require__, 12144));
        console.log('🔄 Attempting to refresh Firebase ID token...');
        // Force refresh the Firebase ID token
        const freshToken = await getCurrentUserIdToken(true);
        if (freshToken) {
            // Update localStorage with the new token
            localStorage.setItem('auth_token', freshToken);
            console.log('✅ Firebase ID token refreshed successfully');
            return freshToken;
        } else {
            console.warn('⚠️ No fresh token returned from Firebase');
            return null;
        }
    } catch (error) {
        console.error('❌ Token refresh failed:', error);
        // If Firebase auth is not available or user is not signed in,
        // clear the auth state completely
        if (error instanceof Error && error.message.includes('No Firebase user signed in')) {
            localStorage.removeItem('auth_token');
            // Clear all caches
            Object.keys(localStorage).forEach((key)=>{
                if (key.startsWith('auth_verification_')) {
                    localStorage.removeItem(key);
                }
            });
        }
        return null;
    }
}
// Create the context with default values
const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    user: null,
    loading: true,
    isAuthenticated: false,
    signOut: async ()=>{}
});
// AuthProvider component that manages unified auth state
function AuthProvider(param) {
    let { children, initialUser } = param;
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialUser || null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!initialUser);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Only check auth state once on mount
        let mounted = true;
        const checkAuthState = async ()=>{
            // Skip auth checks on authentication pages to prevent API loops
            const isAuthPage =  true && [
                '/sign-in',
                '/sign-up'
            ].includes(window.location.pathname);
            if (isAuthPage) {
                console.log('🚫 Auth check skipped: on authentication page');
                if (mounted) {
                    setUser(null);
                    setLoading(false);
                }
                return;
            }
            try {
                // First check for session cookie to avoid unnecessary API call
                const cookies = document.cookie.split(';').reduce((acc, cookie)=>{
                    const [name, value] = cookie.trim().split('=');
                    acc[name] = value;
                    return acc;
                }, {});
                const sessionCookie = cookies.session;
                const token = localStorage.getItem('auth_token');
                // If no session cookie and no token, user is not authenticated
                if (!sessionCookie && !token) {
                    if (mounted) {
                        setUser(null);
                        setLoading(false);
                    }
                    return;
                }
                // Only verify token if we have one
                if (token) {
                    // Check for cached verification result (15 min cache)
                    const cacheKey = "auth_verification_".concat(token.substring(0, 10));
                    const cachedVerification = localStorage.getItem(cacheKey);
                    if (cachedVerification) {
                        try {
                            const cached = JSON.parse(cachedVerification);
                            const cacheAge = Date.now() - cached.timestamp;
                            // Use cached result if less than 15 minutes old
                            if (cacheAge < 15 * 60 * 1000) {
                                console.log('🚀 Using cached auth verification');
                                if (mounted && cached.verified && cached.user) {
                                    setUser(cached.user);
                                }
                                if (mounted) {
                                    setLoading(false);
                                }
                                return;
                            } else {
                                // Remove expired cache
                                localStorage.removeItem(cacheKey);
                            }
                        } catch (error) {
                            // Invalid cache, remove it
                            localStorage.removeItem(cacheKey);
                        }
                    }
                    console.log('🔍 Verifying auth token via API');
                    const response = await fetch('/api/auth/verify', {
                        headers: {
                            'Authorization': "Bearer ".concat(token)
                        }
                    });
                    if (response.ok) {
                        const userData = await response.json();
                        // Cache successful verification
                        const cacheData = {
                            verified: true,
                            user: userData.user,
                            timestamp: Date.now()
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        if (mounted) {
                            setUser(userData.user);
                        }
                    } else if (response.status === 401) {
                        // Token is invalid/expired, check if server suggests refresh
                        const errorData = await response.json().catch(()=>({}));
                        const shouldRefresh = errorData.shouldRefresh !== false; // Default to true
                        console.log('🔄 Token expired/invalid:', errorData.error || 'Unknown error');
                        if (shouldRefresh) {
                            console.log('🔄 Attempting token refresh...');
                            try {
                                const refreshed = await refreshAuthToken();
                                if (refreshed && mounted) {
                                    // Retry verification with new token
                                    const retryResponse = await fetch('/api/auth/verify', {
                                        headers: {
                                            'Authorization': "Bearer ".concat(refreshed)
                                        }
                                    });
                                    if (retryResponse.ok) {
                                        const userData = await retryResponse.json();
                                        // Cache successful verification with new token
                                        const newCacheKey = "auth_verification_".concat(refreshed.substring(0, 10));
                                        const cacheData = {
                                            verified: true,
                                            user: userData.user,
                                            timestamp: Date.now()
                                        };
                                        localStorage.setItem(newCacheKey, JSON.stringify(cacheData));
                                        if (mounted) {
                                            setUser(userData.user);
                                        }
                                        return;
                                    }
                                }
                            } catch (refreshError) {
                                console.error('🔄 Token refresh failed:', refreshError);
                            }
                        }
                        // If refresh failed or not recommended, clear auth state
                        localStorage.removeItem('auth_token');
                        // Clear all verification caches
                        Object.keys(localStorage).forEach((key)=>{
                            if (key.startsWith('auth_verification_')) {
                                localStorage.removeItem(key);
                            }
                        });
                        if (mounted) {
                            setUser(null);
                        }
                    } else {
                        // Other error, cache failed verification temporarily (1 min)
                        const cacheData = {
                            verified: false,
                            user: null,
                            timestamp: Date.now() - 14 * 60 * 1000 // Expire quickly for failed attempts
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        localStorage.removeItem('auth_token');
                        if (mounted) {
                            setUser(null);
                        }
                    }
                } else if (sessionCookie) {
                    // If we have session cookie but no token, consider user logged in
                    // but with minimal user data
                    if (mounted) {
                        setUser({
                            uid: 'session-user',
                            email: 'unknown@session.com',
                            email_verified: false
                        });
                    }
                }
            } catch (error) {
                console.error('Auth state check failed:', error);
                if (mounted) {
                    setUser(null);
                }
            } finally{
                if (mounted) {
                    setLoading(false);
                }
            }
        };
        if (!initialUser) {
            checkAuthState();
        } else {
            setLoading(false);
        }
        return ()=>{
            mounted = false;
        };
    }, [
        initialUser
    ]);
    const signOut = async ()=>{
        try {
            await fetch('/api/auth/signout', {
                method: 'POST'
            });
            localStorage.removeItem('auth_token');
            setUser(null);
        } catch (error) {
            console.error('Sign out error:', error);
        }
    };
    const contextValue = {
        user,
        loading,
        isAuthenticated: !!user,
        signOut
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(AuthContext.Provider, {
        value: contextValue,
        children: children
    });
}
// Custom hook to use the auth context
function useAuth() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthContext);
    if (context === undefined) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
}
// Export the context for advanced use cases



/***/ }),

/***/ 85142:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  TelemetryProvider: () => (/* binding */ TelemetryProvider),
  J: () => (/* binding */ useTelemetry)
});

// UNUSED EXPORTS: default

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(35695);
// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(23274);
;// ./lib/utils/telemetry-stub.ts
// lib/utils/telemetry-stub.ts
// Temporary telemetry stub to allow testing without server-only dependencies
class TelemetryStubService {
    async initialize() {
        if (this.isInitialized) return;
        console.log('📊 Telemetry stub initialized (no actual telemetry)');
        this.isInitialized = true;
    }
    async trackPageView(pageView) {
        console.log("\uD83D\uDCCA [STUB] Page view: ".concat(pageView.name), pageView);
    }
    async trackEvent(event) {
        console.log("\uD83D\uDCCA [STUB] Event: ".concat(event.name), event);
    }
    async trackUserAction(action) {
        console.log("\uD83D\uDCCA [STUB] User action: ".concat(action.action, " on ").concat(action.feature), action);
    }
    async trackFeatureUsage(featureName, userId, properties) {
        console.log("\uD83D\uDCCA [STUB] Feature usage: ".concat(featureName), {
            userId,
            properties
        });
    }
    async trackMetric(metric) {
        console.log("\uD83D\uDCC8 [STUB] Metric: ".concat(metric.name, " = ").concat(metric.value), metric);
    }
    async trackBusinessMetric(metricName, value, userId, properties) {
        console.log("\uD83D\uDCBC [STUB] Business metric: ".concat(metricName, " = ").concat(value), {
            userId,
            properties
        });
    }
    async trackInterviewCompletion(userId, interviewId, questionCount, duration, score) {
        console.log("\uD83C\uDFAF [STUB] Interview completed:", {
            userId,
            interviewId,
            questionCount,
            duration,
            score
        });
    }
    async trackResumeUpload(userId, fileSize, mimeType, processingTime) {
        console.log("\uD83D\uDCC4 [STUB] Resume uploaded:", {
            userId,
            fileSize,
            mimeType,
            processingTime
        });
    }
    async trackFormSubmission(formName, userId, success, properties) {
        console.log("\uD83D\uDCDD [STUB] Form submitted: ".concat(formName), {
            userId,
            success,
            properties
        });
    }
    async trackButtonClick(buttonName, location, userId, properties) {
        console.log("\uD83D\uDD18 [STUB] Button clicked: ".concat(buttonName, " at ").concat(location), {
            userId,
            properties
        });
    }
    async trackSubscription(userId, action, plan, revenue) {
        console.log("\uD83D\uDCB3 [STUB] Subscription ".concat(action, ": ").concat(plan), {
            userId,
            revenue
        });
    }
    async trackError(errorInfo) {
        console.log("\uD83D\uDEA8 [STUB] Error tracked: ".concat(errorInfo.error.message), errorInfo);
    }
    async setUser(userId, email, properties) {
        console.log("\uD83D\uDC64 [STUB] User context set: ".concat(userId), {
            email,
            properties
        });
    }
    async clearUser() {
        console.log('👤 [STUB] User context cleared');
    }
    async trackABTest(testName, variant, userId) {
        console.log("\uD83E\uDDEA [STUB] A/B test: ".concat(testName, " = ").concat(variant), {
            userId
        });
    }
    async trackConversion(conversionType, value, userId, properties) {
        console.log("\uD83C\uDFAF [STUB] Conversion: ".concat(conversionType), {
            value,
            userId,
            properties
        });
    }
    async flush() {
        console.log('🚿 [STUB] Telemetry flushed');
    }
    getReactPlugin() {
        return null;
    }
    getAppInsights() {
        return null;
    }
    constructor(){
        this.isInitialized = false;
        this.isClient = "object" !== 'undefined';
    }
}
// Export singleton instance
const telemetry = new TelemetryStubService();
/* harmony default export */ const telemetry_stub = ((/* unused pure expression or super */ null && (telemetry)));

;// ./components/providers/TelemetryProvider.tsx
/* __next_internal_client_entry_do_not_use__ TelemetryProvider,useTelemetry,default auto */ 




const TelemetryContext = /*#__PURE__*/ (0,react.createContext)(null);
function TelemetryProvider(param) {
    let { children } = param;
    const [isInitialized, setIsInitialized] = (0,react.useState)(false);
    const router = (0,navigation.useRouter)();
    const { user } = (0,AuthContext/* useAuth */.A)();
    (0,react.useEffect)(()=>{
        const initTelemetry = async ()=>{
            try {
                await telemetry.initialize();
                setIsInitialized(true);
                // Track initial page view
                await telemetry.trackPageView({
                    name: document.title,
                    uri: window.location.pathname + window.location.search,
                    userId: user === null || user === void 0 ? void 0 : user.uid,
                    isLoggedIn: !!user
                });
            } catch (error) {
                console.error('Failed to initialize telemetry:', error);
            }
        };
        initTelemetry();
    }, [
        user
    ]);
    // Set user context when user changes
    (0,react.useEffect)(()=>{
        const updateUserContext = async ()=>{
            if (!isInitialized) return;
            if (user) {
                var _user_email_verified;
                await telemetry.setUser(user.uid, user.email || undefined, {
                    isEmailVerified: ((_user_email_verified = user.email_verified) === null || _user_email_verified === void 0 ? void 0 : _user_email_verified.toString()) || 'false',
                    creationTime: 'unknown' // metadata not available in AuthenticatedUser type
                });
            } else {
                await telemetry.clearUser();
            }
        };
        updateUserContext();
    }, [
        user,
        isInitialized
    ]);
    // Track route changes
    (0,react.useEffect)(()=>{
        if (!isInitialized) return;
        const handleRouteChange = async (url)=>{
            await telemetry.trackPageView({
                name: document.title,
                uri: url,
                userId: user === null || user === void 0 ? void 0 : user.uid,
                isLoggedIn: !!user
            });
        };
        // For Next.js app router, we need to listen for navigation events differently
        // This is a simplified version - you might need to adjust based on your routing setup
        const originalPushState = window.history.pushState;
        const originalReplaceState = window.history.replaceState;
        window.history.pushState = function() {
            for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                args[_key] = arguments[_key];
            }
            originalPushState.apply(this, args);
            handleRouteChange(window.location.pathname + window.location.search);
        };
        window.history.replaceState = function() {
            for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                args[_key] = arguments[_key];
            }
            originalReplaceState.apply(this, args);
            handleRouteChange(window.location.pathname + window.location.search);
        };
        window.addEventListener('popstate', ()=>{
            handleRouteChange(window.location.pathname + window.location.search);
        });
        return ()=>{
            window.history.pushState = originalPushState;
            window.history.replaceState = originalReplaceState;
            window.removeEventListener('popstate', ()=>{});
        };
    }, [
        isInitialized,
        user
    ]);
    const contextValue = {
        trackPageView: async (name, properties)=>{
            await telemetry.trackPageView({
                name,
                uri: window.location.pathname + window.location.search,
                userId: user === null || user === void 0 ? void 0 : user.uid,
                isLoggedIn: !!user,
                properties
            });
        },
        trackEvent: async (name, properties, measurements)=>{
            await telemetry.trackEvent({
                name,
                properties: {
                    userId: (user === null || user === void 0 ? void 0 : user.uid) || 'anonymous',
                    ...properties
                },
                measurements
            });
        },
        trackUserAction: async (action, feature, properties)=>{
            await telemetry.trackUserAction({
                action,
                feature,
                userId: user === null || user === void 0 ? void 0 : user.uid,
                properties
            });
        },
        trackFeatureUsage: async (featureName, properties)=>{
            await telemetry.trackFeatureUsage(featureName, user === null || user === void 0 ? void 0 : user.uid, properties);
        },
        trackButtonClick: async (buttonName, properties)=>{
            await telemetry.trackButtonClick(buttonName, window.location.pathname, user === null || user === void 0 ? void 0 : user.uid, properties);
        },
        trackFormSubmission: async (formName, success, properties)=>{
            await telemetry.trackFormSubmission(formName, user === null || user === void 0 ? void 0 : user.uid, success, properties);
        },
        trackInterviewCompletion: async (interviewId, questionCount, duration, score)=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return;
            await telemetry.trackInterviewCompletion(user.uid, interviewId, questionCount, duration, score);
        },
        trackResumeUpload: async (fileSize, mimeType, processingTime)=>{
            if (!(user === null || user === void 0 ? void 0 : user.uid)) return;
            await telemetry.trackResumeUpload(user.uid, fileSize, mimeType, processingTime);
        },
        trackError: async (error, context)=>{
            await telemetry.trackError({
                error,
                userId: user === null || user === void 0 ? void 0 : user.uid,
                context
            });
        },
        isInitialized
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(TelemetryContext.Provider, {
        value: contextValue,
        children: children
    });
}
function useTelemetry() {
    const context = (0,react.useContext)(TelemetryContext);
    if (!context) {
        throw new Error('useTelemetry must be used within a TelemetryProvider');
    }
    return context;
}
/* harmony default export */ const providers_TelemetryProvider = ((/* unused pure expression or super */ null && (TelemetryProvider)));


/***/ })

}]);