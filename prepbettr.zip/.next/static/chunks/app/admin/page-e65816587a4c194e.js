(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[3698],{

/***/ 16225:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94724));


/***/ }),

/***/ 17580:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Users)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19946);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
            key: "1yyitq"
        }
    ],
    [
        "path",
        {
            d: "M16 3.128a4 4 0 0 1 0 7.744",
            key: "16gr8j"
        }
    ],
    [
        "path",
        {
            d: "M22 21v-2a4 4 0 0 0-3-3.87",
            key: "kshegd"
        }
    ],
    [
        "circle",
        {
            cx: "9",
            cy: "7",
            r: "4",
            key: "nufk8"
        }
    ]
];
const Users = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("users", __iconNode);
 //# sourceMappingURL=users.js.map


/***/ }),

/***/ 27737:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ Skeleton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36680);


function Skeleton(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        "data-slot": "skeleton",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_1__.cn)("bg-accent animate-pulse rounded-md", className),
        ...props
    });
}



/***/ }),

/***/ 34964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Xi: () => (/* binding */ TabsTrigger),
/* harmony export */   av: () => (/* binding */ TabsContent),
/* harmony export */   j7: () => (/* binding */ TabsList),
/* harmony export */   tU: () => (/* binding */ Tabs)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60704);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);




const Tabs = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .bL;
const TabsList = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .List */ .B8, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    });
});
TabsList.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .List */ .B8.displayName;
const TabsTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    });
});
TabsTrigger.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9.displayName;
const TabsContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    });
});
TabsContent.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC.displayName;



/***/ }),

/***/ 49026:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fc: () => (/* binding */ Alert),
/* harmony export */   TN: () => (/* binding */ AlertDescription)
/* harmony export */ });
/* unused harmony export AlertTitle */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74466);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);




const alertVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("relative w-full rounded-lg border p-4 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7", {
    variants: {
        variant: {
            default: "bg-background text-foreground",
            destructive: "border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
const Alert = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, variant, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        role: "alert",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(alertVariants({
            variant
        }), className),
        ...props
    });
});
Alert.displayName = "Alert";
const AlertTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h5", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("mb-1 font-medium leading-none tracking-tight", className),
        ...props
    });
});
AlertTitle.displayName = "AlertTitle";
const AlertDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-sm [&_p]:leading-relaxed", className),
        ...props
    });
});
AlertDescription.displayName = "AlertDescription";



/***/ }),

/***/ 55868:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ DollarSign)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19946);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "line",
        {
            x1: "12",
            x2: "12",
            y1: "2",
            y2: "22",
            key: "7eqyqh"
        }
    ],
    [
        "path",
        {
            d: "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
            key: "1b0p4s"
        }
    ]
];
const DollarSign = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("dollar-sign", __iconNode);
 //# sourceMappingURL=dollar-sign.js.map


/***/ }),

/***/ 82714:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ Label)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(40968);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);
/* __next_internal_client_entry_do_not_use__ Label auto */ 



function Label(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .b, {
        "data-slot": "label",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className),
        ...props
    });
}



/***/ }),

/***/ 88145:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ Badge)
/* harmony export */ });
/* unused harmony export badgeVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74466);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);




const badgeVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
            secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
            destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
            outline: "text-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge(param) {
    let { className, variant, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(badgeVariants({
            variant
        }), className),
        ...props
    });
}



/***/ }),

/***/ 88482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BT: () => (/* binding */ CardDescription),
/* harmony export */   Wu: () => (/* binding */ CardContent),
/* harmony export */   ZB: () => (/* binding */ CardTitle),
/* harmony export */   Zp: () => (/* binding */ Card),
/* harmony export */   aR: () => (/* binding */ CardHeader)
/* harmony export */ });
/* unused harmony export CardFooter */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);



const Card = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    });
});
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    });
});
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    });
});
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-sm text-muted-foreground", className),
        ...props
    });
});
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("p-6 pt-0", className),
        ...props
    });
});
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center p-6 pt-0", className),
        ...props
    });
});
CardFooter.displayName = "CardFooter";



/***/ }),

/***/ 89852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);



function Input(param) {
    let { className, type, ...props } = param;
    const isDisabled = props.disabled;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
        type: type,
        "data-slot": "input",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(// Base styles for dark theme
        "bg-gray-800 text-white placeholder-gray-400 border-gray-600", "flex h-9 w-full min-w-0 rounded-md border px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none", "md:text-sm", // File input specific styles
        "file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-white", // Selection styles
        "selection:bg-primary-200 selection:text-dark-100", // Focus states with brand color (primary-200 from globals.css)
        "focus-visible:border-primary-200 focus-visible:ring-primary-200/50 focus-visible:ring-[3px]", // Disabled states with proper contrast
        isDisabled && "disabled:bg-gray-800/50 disabled:text-gray-500 disabled:placeholder-gray-500 disabled:cursor-not-allowed disabled:opacity-75", // Validation error states
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className),
        ...props
    });
}



/***/ }),

/***/ 94724:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AdminDashboard)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./components/ui/card.tsx
var card = __webpack_require__(88482);
// EXTERNAL MODULE: ./components/ui/badge.tsx
var badge = __webpack_require__(88145);
// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(36680);
;// ./components/ui/progress.tsx
/* __next_internal_client_entry_do_not_use__ Progress auto */ 


const Progress = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, value, indicatorClassName, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        ref: ref,
        className: (0,utils.cn)("relative h-4 w-full overflow-hidden rounded-full bg-secondary", className),
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: (0,utils.cn)("h-full w-full flex-1 bg-primary transition-all", indicatorClassName),
            style: {
                transform: "translateX(-".concat(100 - (value || 0), "%)")
            }
        })
    });
});
Progress.displayName = "Progress";


// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/dollar-sign.js
var dollar_sign = __webpack_require__(55868);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/users.js
var users = __webpack_require__(17580);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/createLucideIcon.js + 3 modules
var createLucideIcon = __webpack_require__(19946);
;// ./node_modules/lucide-react/dist/esm/icons/trending-down.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "polyline",
        {
            points: "22 17 13.5 8.5 8.5 13.5 2 7",
            key: "1r2t7k"
        }
    ],
    [
        "polyline",
        {
            points: "16 17 22 17 22 11",
            key: "11uiuu"
        }
    ]
];
const TrendingDown = (0,createLucideIcon/* default */.A)("trending-down", __iconNode);
 //# sourceMappingURL=trending-down.js.map

;// ./node_modules/lucide-react/dist/esm/icons/activity.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const activity_iconNode = [
    [
        "path",
        {
            d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
            key: "169zse"
        }
    ]
];
const Activity = (0,createLucideIcon/* default */.A)("activity", activity_iconNode);
 //# sourceMappingURL=activity.js.map

;// ./components/admin/analytics-charts.tsx
/* __next_internal_client_entry_do_not_use__ AnalyticsCharts auto */ 




function AnalyticsCharts(param) {
    let { data } = param;
    const maxRevenue = Math.max(...data.revenue.byDay.map((d)=>d.amount), 1);
    const premiumPercentage = data.subscriptions.byPlan.premium / data.subscriptions.byPlan.total * 100;
    const freePercentage = data.subscriptions.byPlan.free / data.subscriptions.byPlan.total * 100;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "grid gap-6 md:grid-cols-2 lg:grid-cols-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        className: "flex flex-row items-center justify-between space-y-0 pb-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                className: "text-sm font-medium",
                                children: "Total Revenue"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(dollar_sign/* default */.A, {
                                className: "h-4 w-4 text-muted-foreground"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-2xl font-bold",
                                children: [
                                    "$",
                                    data.revenue.total.toFixed(2)
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                className: "text-xs text-muted-foreground",
                                children: [
                                    "Last ",
                                    data.period.days,
                                    " days"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        className: "flex flex-row items-center justify-between space-y-0 pb-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                className: "text-sm font-medium",
                                children: "Total Users"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(users/* default */.A, {
                                className: "h-4 w-4 text-muted-foreground"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "text-2xl font-bold",
                                children: data.subscriptions.byPlan.total
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                className: "text-xs text-muted-foreground",
                                children: [
                                    "+",
                                    data.userGrowth.total,
                                    " this period"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        className: "flex flex-row items-center justify-between space-y-0 pb-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                className: "text-sm font-medium",
                                children: "Churn Rate"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(TrendingDown, {
                                className: "h-4 w-4 text-muted-foreground"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-2xl font-bold",
                                children: [
                                    data.churn.rate.toFixed(1),
                                    "%"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                className: "text-xs text-muted-foreground",
                                children: [
                                    data.churn.count,
                                    " users churned"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        className: "flex flex-row items-center justify-between space-y-0 pb-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                className: "text-sm font-medium",
                                children: "MRR Estimate"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(Activity, {
                                className: "h-4 w-4 text-muted-foreground"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-2xl font-bold",
                                children: [
                                    "$",
                                    data.subscriptions.mrr.toFixed(2)
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                className: "text-xs text-muted-foreground",
                                children: "Monthly recurring"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                className: "md:col-span-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                children: "Daily Revenue"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardDescription */.BT, {
                                children: [
                                    "Revenue over the last ",
                                    data.period.days,
                                    " days"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardContent */.Wu, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "space-y-2",
                            children: data.revenue.byDay.slice(-7).map((day, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center space-x-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "text-sm w-20",
                                            children: new Date(day.date).toLocaleDateString()
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "flex-1",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Progress, {
                                                value: day.amount / maxRevenue * 100,
                                                className: "h-2"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "text-sm font-medium w-16",
                                            children: [
                                                "$",
                                                day.amount.toFixed(2)
                                            ]
                                        })
                                    ]
                                }, day.date))
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                className: "md:col-span-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                children: "Subscription Breakdown"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardDescription */.BT, {
                                children: "Distribution of users by plan"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardContent */.Wu, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "flex items-center space-x-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(badge/* Badge */.E, {
                                                            variant: "secondary",
                                                            children: "Free"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                            className: "text-sm",
                                                            children: [
                                                                data.subscriptions.byPlan.free,
                                                                " users"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                    className: "text-sm font-medium",
                                                    children: [
                                                        freePercentage.toFixed(1),
                                                        "%"
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(Progress, {
                                            value: freePercentage,
                                            className: "h-2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "flex items-center space-x-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(badge/* Badge */.E, {
                                                            variant: "default",
                                                            children: "Premium"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                            className: "text-sm",
                                                            children: [
                                                                data.subscriptions.byPlan.premium,
                                                                " users"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                    className: "text-sm font-medium",
                                                    children: [
                                                        premiumPercentage.toFixed(1),
                                                        "%"
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(Progress, {
                                            value: premiumPercentage,
                                            className: "h-2"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                className: "md:col-span-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                children: "Recent Subscription Events"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardDescription */.BT, {
                                children: "Latest subscription activity"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardContent */.Wu, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "space-y-2",
                            children: data.recentEvents.slice(0, 10).map((event, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center justify-between p-2 border rounded",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "flex items-center space-x-3",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(badge/* Badge */.E, {
                                                    variant: "outline",
                                                    className: "text-xs",
                                                    children: event.eventType
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                    className: "text-sm",
                                                    children: event.userId
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                            className: "text-xs text-muted-foreground",
                                            children: new Date(event.timestamp).toLocaleString()
                                        })
                                    ]
                                }, event.id))
                        })
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./components/ui/skeleton.tsx
var skeleton = __webpack_require__(27737);
// EXTERNAL MODULE: ./components/ui/alert.tsx
var ui_alert = __webpack_require__(49026);
// EXTERNAL MODULE: ./components/ui/select.tsx
var ui_select = __webpack_require__(95784);
;// ./app/admin/analytics-client.tsx
/* __next_internal_client_entry_do_not_use__ AdminAnalyticsClient auto */ 





const fetchAnalytics = async function() {
    let period = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : '30';
    const response = await fetch("/api/admin/analytics?period=".concat(period));
    if (!response.ok) throw new Error('Failed to load analytics');
    return response.json();
};
function AdminAnalyticsClient() {
    const [data, setData] = (0,react.useState)(null);
    const [loading, setLoading] = (0,react.useState)(true);
    const [error, setError] = (0,react.useState)(null);
    const [period, setPeriod] = (0,react.useState)('30');
    const loadData = async ()=>{
        setLoading(true);
        setError(null);
        try {
            const analyticsData = await fetchAnalytics(period);
            setData(analyticsData);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An error occurred');
        } finally{
            setLoading(false);
        }
    };
    (0,react.useEffect)(()=>{
        loadData();
    }, [
        period
    ]);
    if (loading) {
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "space-y-6",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "flex justify-end",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                        className: "h-10 w-32"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grid gap-6 md:grid-cols-2 lg:grid-cols-4",
                    children: Array.from({
                        length: 4
                    }).map((_, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                            className: "h-32"
                        }, i))
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "grid gap-6 md:grid-cols-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                            className: "h-96"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                            className: "h-96"
                        })
                    ]
                })
            ]
        });
    }
    if (error) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_alert/* Alert */.Fc, {
            variant: "destructive",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_alert/* AlertDescription */.TN, {
                children: [
                    "Error loading analytics: ",
                    error
                ]
            })
        });
    }
    if (!data) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            children: "No data available"
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_select/* Select */.l6, {
                    value: period,
                    onValueChange: setPeriod,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_select/* SelectTrigger */.bq, {
                            className: "w-32",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_select/* SelectValue */.yv, {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_select/* SelectContent */.gC, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                    value: "7",
                                    children: "7 days"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                    value: "30",
                                    children: "30 days"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                    value: "90",
                                    children: "90 days"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(AnalyticsCharts, {
                data: data
            })
        ]
    });
}

// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(97168);
// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(89852);
// EXTERNAL MODULE: ./components/ui/label.tsx
var label = __webpack_require__(82714);
// EXTERNAL MODULE: ./components/ui/tabs.tsx
var tabs = __webpack_require__(34964);
;// ./node_modules/lucide-react/dist/esm/icons/circle-x.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const circle_x_iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "path",
        {
            d: "m15 9-6 6",
            key: "1uzhvr"
        }
    ],
    [
        "path",
        {
            d: "m9 9 6 6",
            key: "z0biqf"
        }
    ]
];
const CircleX = (0,createLucideIcon/* default */.A)("circle-x", circle_x_iconNode);
 //# sourceMappingURL=circle-x.js.map

;// ./node_modules/lucide-react/dist/esm/icons/triangle-alert.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const triangle_alert_iconNode = [
    [
        "path",
        {
            d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
            key: "wmoenq"
        }
    ],
    [
        "path",
        {
            d: "M12 9v4",
            key: "juzpu7"
        }
    ],
    [
        "path",
        {
            d: "M12 17h.01",
            key: "p32p05"
        }
    ]
];
const TriangleAlert = (0,createLucideIcon/* default */.A)("triangle-alert", triangle_alert_iconNode);
 //# sourceMappingURL=triangle-alert.js.map

;// ./node_modules/lucide-react/dist/esm/icons/circle-check-big.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const circle_check_big_iconNode = [
    [
        "path",
        {
            d: "M21.801 10A10 10 0 1 1 17 3.335",
            key: "yps3ct"
        }
    ],
    [
        "path",
        {
            d: "m9 11 3 3L22 4",
            key: "1pflzl"
        }
    ]
];
const CircleCheckBig = (0,createLucideIcon/* default */.A)("circle-check-big", circle_check_big_iconNode);
 //# sourceMappingURL=circle-check-big.js.map

;// ./node_modules/lucide-react/dist/esm/icons/refresh-cw.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const refresh_cw_iconNode = [
    [
        "path",
        {
            d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
            key: "v9h5vc"
        }
    ],
    [
        "path",
        {
            d: "M21 3v5h-5",
            key: "1q7to0"
        }
    ],
    [
        "path",
        {
            d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
            key: "3uifl3"
        }
    ],
    [
        "path",
        {
            d: "M8 16H3v5",
            key: "1cv678"
        }
    ]
];
const RefreshCw = (0,createLucideIcon/* default */.A)("refresh-cw", refresh_cw_iconNode);
 //# sourceMappingURL=refresh-cw.js.map

;// ./node_modules/lucide-react/dist/esm/icons/trending-up.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const trending_up_iconNode = [
    [
        "polyline",
        {
            points: "22 7 13.5 15.5 8.5 10.5 2 17",
            key: "126l90"
        }
    ],
    [
        "polyline",
        {
            points: "16 7 22 7 22 13",
            key: "kwv8wd"
        }
    ]
];
const TrendingUp = (0,createLucideIcon/* default */.A)("trending-up", trending_up_iconNode);
 //# sourceMappingURL=trending-up.js.map

;// ./components/admin/FeatureFlagManager.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










function FeatureFlagManager() {
    const [flags, setFlags] = (0,react.useState)(null);
    const [loading, setLoading] = (0,react.useState)(true);
    const [debugInfo, setDebugInfo] = (0,react.useState)(null);
    const [errorBudgets, setErrorBudgets] = (0,react.useState)({});
    const [rolloutPercentages, setRolloutPercentages] = (0,react.useState)({
        autoApplyAzure: 20,
        portalIntegration: 15
    });
    (0,react.useEffect)(()=>{
        loadData();
    }, []);
    const loadData = async ()=>{
        setLoading(true);
        try {
            // Use API calls instead of direct service imports
            const [flagsResponse, debugResponse] = await Promise.all([
                fetch('/api/feature-flags'),
                fetch('/api/admin/feature-flags/debug')
            ]);
            let flagsData = null;
            let debugData = null;
            if (flagsResponse.ok) {
                flagsData = await flagsResponse.json();
            }
            if (debugResponse.ok) {
                debugData = await debugResponse.json();
            }
            setFlags(flagsData);
            setDebugInfo(debugData);
            // Note: Error budgets functionality temporarily disabled - requires API endpoint
            setErrorBudgets({});
        } catch (error) {
            console.error('Error loading admin data:', error);
        } finally{
            setLoading(false);
        }
    };
    const updateRolloutPercentage = async (feature, percentage)=>{
        if (percentage < 0 || percentage > 100) return;
        try {
            // Update via API call
            const response = await fetch('/api/admin/rollout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    feature,
                    percentage
                })
            });
            if (response.ok) {
                setRolloutPercentages((prev)=>({
                        ...prev,
                        [feature]: percentage
                    }));
                loadData(); // Refresh data
            } else {
                console.error('Failed to update rollout percentage');
            }
        } catch (error) {
            console.error('Error updating rollout percentage:', error);
        }
    };
    const increaseRollout = function(feature) {
        let increment = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 5;
        const newPercentage = Math.min(100, rolloutPercentages[feature] + increment);
        updateRolloutPercentage(feature, newPercentage);
    };
    const decreaseRollout = function(feature) {
        let decrement = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 5;
        const newPercentage = Math.max(0, rolloutPercentages[feature] - decrement);
        updateRolloutPercentage(feature, newPercentage);
    };
    const getBudgetStatus = (budget)=>{
        if (budget.budgetExceeded) return 'error';
        if (budget.currentErrors > budget.errorThreshold * 0.8) return 'warning';
        return 'ok';
    };
    const getBudgetColor = (status)=>{
        switch(status){
            case 'error':
                return 'text-red-500';
            case 'warning':
                return 'text-yellow-500';
            default:
                return 'text-green-500';
        }
    };
    const getBudgetIcon = (status)=>{
        switch(status){
            case 'error':
                return CircleX;
            case 'warning':
                return TriangleAlert;
            default:
                return CircleCheckBig;
        }
    };
    if (loading) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "p-6 space-y-4",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "animate-pulse space-y-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "h-8 bg-gray-700 rounded w-1/3"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-48 bg-gray-800 rounded"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "h-48 bg-gray-800 rounded"
                            })
                        ]
                    })
                ]
            })
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "p-6 space-y-6",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                        className: "text-3xl font-bold text-white",
                        children: "Feature Flag Management"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                        onClick: loadData,
                        variant: "outline",
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(RefreshCw, {
                                className: "h-4 w-4"
                            }),
                            "Refresh"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(tabs/* Tabs */.tU, {
                defaultValue: "rollout",
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(tabs/* TabsList */.j7, {
                        className: "grid w-full grid-cols-3",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "rollout",
                                children: "Rollout Control"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "monitoring",
                                children: "Error Monitoring"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "debug",
                                children: "Debug Info"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "rollout",
                        className: "space-y-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                                    className: "bg-gray-900 border-gray-700",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardHeader */.aR, {
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardTitle */.ZB, {
                                                className: "text-white flex items-center justify-between",
                                                children: [
                                                    "Auto Apply Azure",
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(badge/* Badge */.E, {
                                                        variant: (flags === null || flags === void 0 ? void 0 : flags.autoApplyAzure) ? "default" : "secondary",
                                                        children: (flags === null || flags === void 0 ? void 0 : flags.autoApplyAzure) ? "Active" : "Inactive"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "flex items-center justify-between",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                                    className: "text-gray-300",
                                                                    children: "Rollout Percentage"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                                    className: "text-white font-bold",
                                                                    children: [
                                                                        rolloutPercentages.autoApplyAzure,
                                                                        "%"
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(Progress, {
                                                            value: rolloutPercentages.autoApplyAzure,
                                                            className: "h-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "flex gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                            size: "sm",
                                                            variant: "outline",
                                                            onClick: ()=>decreaseRollout('autoApplyAzure'),
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(TrendingDown, {
                                                                    className: "h-3 w-3"
                                                                }),
                                                                "-5%"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                            size: "sm",
                                                            variant: "outline",
                                                            onClick: ()=>increaseRollout('autoApplyAzure'),
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(TrendingUp, {
                                                                    className: "h-3 w-3"
                                                                }),
                                                                "+5%"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                            className: "text-gray-300",
                                                            children: "Custom Percentage"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "flex gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                                    type: "number",
                                                                    min: "0",
                                                                    max: "100",
                                                                    value: rolloutPercentages.autoApplyAzure,
                                                                    onChange: (e)=>setRolloutPercentages((prev)=>({
                                                                                ...prev,
                                                                                autoApplyAzure: parseInt(e.target.value) || 0
                                                                            })),
                                                                    className: "bg-gray-800 border-gray-600 text-white"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                                    size: "sm",
                                                                    onClick: ()=>updateRolloutPercentage('autoApplyAzure', rolloutPercentages.autoApplyAzure),
                                                                    children: "Apply"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                                    className: "bg-gray-900 border-gray-700",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardHeader */.aR, {
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardTitle */.ZB, {
                                                className: "text-white flex items-center justify-between",
                                                children: [
                                                    "Portal Integration",
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(badge/* Badge */.E, {
                                                        variant: (flags === null || flags === void 0 ? void 0 : flags.portalIntegration) ? "default" : "secondary",
                                                        children: (flags === null || flags === void 0 ? void 0 : flags.portalIntegration) ? "Active" : "Inactive"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "flex items-center justify-between",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                                    className: "text-gray-300",
                                                                    children: "Rollout Percentage"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                                    className: "text-white font-bold",
                                                                    children: [
                                                                        rolloutPercentages.portalIntegration,
                                                                        "%"
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(Progress, {
                                                            value: rolloutPercentages.portalIntegration,
                                                            className: "h-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "flex gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                            size: "sm",
                                                            variant: "outline",
                                                            onClick: ()=>decreaseRollout('portalIntegration'),
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(TrendingDown, {
                                                                    className: "h-3 w-3"
                                                                }),
                                                                "-5%"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                            size: "sm",
                                                            variant: "outline",
                                                            onClick: ()=>increaseRollout('portalIntegration'),
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(TrendingUp, {
                                                                    className: "h-3 w-3"
                                                                }),
                                                                "+5%"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(label/* Label */.J, {
                                                            className: "text-gray-300",
                                                            children: "Custom Percentage"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "flex gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
                                                                    type: "number",
                                                                    min: "0",
                                                                    max: "100",
                                                                    value: rolloutPercentages.portalIntegration,
                                                                    onChange: (e)=>setRolloutPercentages((prev)=>({
                                                                                ...prev,
                                                                                portalIntegration: parseInt(e.target.value) || 0
                                                                            })),
                                                                    className: "bg-gray-800 border-gray-600 text-white"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                                    size: "sm",
                                                                    onClick: ()=>updateRolloutPercentage('portalIntegration', rolloutPercentages.portalIntegration),
                                                                    children: "Apply"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "monitoring",
                        className: "space-y-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                            children: Object.entries(errorBudgets).map((param)=>{
                                let [featureName, budget] = param;
                                const status = getBudgetStatus(budget);
                                const StatusIcon = getBudgetIcon(status);
                                return /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                                    className: "bg-gray-900 border-gray-700",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardHeader */.aR, {
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardTitle */.ZB, {
                                                className: "text-white flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(StatusIcon, {
                                                        className: "h-5 w-5 ".concat(getBudgetColor(status))
                                                    }),
                                                    featureName
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                            className: "space-y-3",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "flex justify-between items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                            className: "text-gray-300",
                                                            children: "Error Count"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                            className: "font-bold ".concat(getBudgetColor(status)),
                                                            children: [
                                                                budget.currentErrors,
                                                                " / ",
                                                                budget.errorThreshold
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(Progress, {
                                                    value: budget.currentErrors / budget.errorThreshold * 100,
                                                    className: "h-2"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "text-xs text-gray-400",
                                                    children: [
                                                        "Time Window: ",
                                                        budget.timeWindow,
                                                        " minutes"
                                                    ]
                                                }),
                                                budget.budgetExceeded && /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_alert/* Alert */.Fc, {
                                                    className: "border-red-600 bg-red-900/20",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(TriangleAlert, {
                                                            className: "h-4 w-4 text-red-400"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_alert/* AlertDescription */.TN, {
                                                            className: "text-red-200",
                                                            children: "Error budget exceeded! Consider reducing rollout."
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }, featureName);
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "debug",
                        className: "space-y-4",
                        children: debugInfo && /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                            className: "bg-gray-900 border-gray-700",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardHeader */.aR, {
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                        className: "text-white",
                                        children: "Debug Information"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardContent */.Wu, {
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("pre", {
                                        className: "bg-gray-800 p-4 rounded text-sm text-gray-300 overflow-auto",
                                        children: JSON.stringify(debugInfo, null, 2)
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

;// ./app/admin/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function AdminDashboard() {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "container mx-auto py-6",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center justify-between mb-6",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                    className: "text-3xl font-bold text-white",
                    children: "Admin Dashboard"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(tabs/* Tabs */.tU, {
                defaultValue: "analytics",
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(tabs/* TabsList */.j7, {
                        className: "grid w-full grid-cols-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "analytics",
                                children: "Analytics"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "feature-flags",
                                children: "Feature Flags"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "analytics",
                        className: "space-y-6 mt-6",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(AdminAnalyticsClient, {})
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "feature-flags",
                        className: "mt-6",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(FeatureFlagManager, {})
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 95784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bq: () => (/* binding */ SelectTrigger),
/* harmony export */   eb: () => (/* binding */ SelectItem),
/* harmony export */   gC: () => (/* binding */ SelectContent),
/* harmony export */   l6: () => (/* binding */ Select),
/* harmony export */   yv: () => (/* binding */ SelectValue)
/* harmony export */ });
/* unused harmony exports SelectGroup, SelectLabel, SelectSeparator, SelectScrollUpButton, SelectScrollDownButton */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(14582);
/* harmony import */ var _barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(66474);
/* harmony import */ var _barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(47863);
/* harmony import */ var _barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5196);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);





const Select = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .bL;
const SelectGroup = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Group */ .YJ;
const SelectValue = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Value */ .WT;
const SelectTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Icon */ .In, {
                asChild: true,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A, {
                    className: "h-4 w-4 opacity-50"
                })
            })
        ]
    });
});
SelectTrigger.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9.displayName;
const SelectScrollUpButton = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollUpButton */ .PP, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A, {
            className: "h-4 w-4"
        })
    });
});
SelectScrollUpButton.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollUpButton */ .PP.displayName;
const SelectScrollDownButton = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollDownButton */ .wn, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A, {
            className: "h-4 w-4"
        })
    });
});
SelectScrollDownButton.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollDownButton */ .wn.displayName;
const SelectContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, children, position = "popper", ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Portal */ .ZL, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC, {
            ref: ref,
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
            position: position,
            ...props,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SelectScrollUpButton, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Viewport */ .LM, {
                    className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                    children: children
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SelectScrollDownButton, {})
            ]
        })
    });
});
SelectContent.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC.displayName;
const SelectLabel = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .JU, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("py-1.5 pl-8 pr-2 text-sm font-semibold", className),
        ...props
    });
});
SelectLabel.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .JU.displayName;
const SelectItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Item */ .q7, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ItemIndicator */ .VF, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, {
                        className: "h-4 w-4"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ItemText */ .p4, {
                children: children
            })
        ]
    });
});
SelectItem.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Item */ .q7.displayName;
const SelectSeparator = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Separator */ .wv, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("-mx-1 my-1 h-px bg-muted", className),
        ...props
    });
});
SelectSeparator.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Separator */ .wv.displayName;



/***/ }),

/***/ 97168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Button)
/* harmony export */ });
/* unused harmony export buttonVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99708);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74466);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);





const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none", {
    variants: {
        variant: {
            default: "bg-primary-200 text-dark-100 shadow-xs hover:bg-primary-200/90 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            destructive: "bg-destructive-100 text-white shadow-xs hover:bg-destructive-200 focus-visible:ring-destructive-100/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            outline: "border border-gray-600 bg-gray-800 text-white shadow-xs hover:bg-gray-700 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800/50 disabled:text-gray-500 disabled:border-gray-700",
            secondary: "bg-gray-700 text-white shadow-xs hover:bg-gray-600 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800 disabled:text-gray-500",
            ghost: "text-white hover:bg-gray-800 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500",
            link: "text-primary-200 underline-offset-4 hover:underline focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button(param) {
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__/* .Slot */ .DX : "button";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Comp, {
        "data-slot": "button",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    });
}



/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, [9798,9112,1641,214,6680,8441,1684,7358], () => (__webpack_exec__(16225)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);