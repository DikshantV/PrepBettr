(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[7177],{

/***/ 3304:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RouterLoadingHandler: () => (/* binding */ RouterLoadingHandler)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12115);
/* harmony import */ var _contexts_LoadingContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(99442);
/* __next_internal_client_entry_do_not_use__ RouterLoadingHandler auto */ 

const RouterLoadingHandler = ()=>{
    const { showLoader, hideLoader } = (0,_contexts_LoadingContext__WEBPACK_IMPORTED_MODULE_1__/* .useLoading */ .M)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        let navigationTimer = null;
        // Listen for browser navigation (back/forward buttons)
        const handlePopState = ()=>{
            showLoader('', 500);
            // Auto-hide after a maximum time to prevent infinite loading
            navigationTimer = setTimeout(()=>{
                hideLoader(true); // Force hide
            }, 3000); // 3 seconds max
        };
        // Listen for page load completion
        const handleLoad = ()=>{
            if (navigationTimer) {
                clearTimeout(navigationTimer);
            }
            hideLoader();
        };
        // Listen for DOM content loaded (faster than full load)
        const handleDOMContentLoaded = ()=>{
            if (navigationTimer) {
                clearTimeout(navigationTimer);
            }
            hideLoader();
        };
        // Only listen to popstate for browser navigation
        window.addEventListener('popstate', handlePopState);
        window.addEventListener('load', handleLoad);
        window.addEventListener('DOMContentLoaded', handleDOMContentLoaded);
        // Clean up on unmount
        return ()=>{
            if (navigationTimer) {
                clearTimeout(navigationTimer);
            }
            window.removeEventListener('popstate', handlePopState);
            window.removeEventListener('load', handleLoad);
            window.removeEventListener('DOMContentLoaded', handleDOMContentLoaded);
        };
    }, [
        showLoader,
        hideLoader
    ]);
    return null;
};


/***/ }),

/***/ 14538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ TestHelperInitializer)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12115);
/* provided dependency */ var process = __webpack_require__(87358);
/**
 * Test Helper Initializer for E2E Testing
 * 
 * This component exposes test helper functions to the browser window object
 * during E2E tests, allowing Playwright tests to simulate various scenarios
 * like voice transcripts, agent failures, network issues, and session state.
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 
function TestHelperInitializer() {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // Only initialize test helpers in test environment
        if ( true && !process.env.PLAYWRIGHT_TEST) {
            return;
        }
        // Store interview session state
        let currentSession = null;
        let currentResults = null;
        // Voice transcript simulation
        window.simulateVoiceTranscript = (transcript)=>{
            console.log('🎤 Test Helper: Simulating voice transcript:', transcript);
            // Trigger voice transcript event
            const event = new CustomEvent('voiceTranscript', {
                detail: {
                    transcript,
                    confidence: 0.95,
                    isFinal: true,
                    timestamp: Date.now()
                }
            });
            document.dispatchEvent(event);
            // Also dispatch to any voice components that might be listening
            const voiceEvents = [
                'speechResult',
                'transcriptionResult'
            ];
            voiceEvents.forEach((eventType)=>{
                const voiceEvent = new CustomEvent(eventType, {
                    detail: {
                        transcript,
                        confidence: 0.95,
                        isFinal: true
                    }
                });
                document.dispatchEvent(voiceEvent);
            });
        };
        // Agent failure simulation
        window.simulateAgentFailure = (agentType)=>{
            console.log('❌ Test Helper: Simulating agent failure for:', agentType);
            const event = new CustomEvent('agentFailure', {
                detail: {
                    agentType,
                    error: "Simulated ".concat(agentType, " agent failure"),
                    timestamp: Date.now(),
                    recoverable: true
                }
            });
            document.dispatchEvent(event);
        };
        // Network interruption simulation
        window.simulateNetworkInterruption = function() {
            let duration = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 5000;
            console.log('🌐 Test Helper: Simulating network interruption for', duration, 'ms');
            // Simulate connection lost
            const disconnectEvent = new CustomEvent('connectionLost', {
                detail: {
                    timestamp: Date.now(),
                    duration
                }
            });
            document.dispatchEvent(disconnectEvent);
            // Simulate connection restored after duration
            setTimeout(()=>{
                const reconnectEvent = new CustomEvent('connectionRestored', {
                    detail: {
                        timestamp: Date.now()
                    }
                });
                document.dispatchEvent(reconnectEvent);
                // Add visual indicator for tests
                const indicator = document.createElement('div');
                indicator.setAttribute('data-testid', 'connection-restored');
                indicator.style.display = 'none';
                document.body.appendChild(indicator);
            }, duration);
        };
        // Session timeout simulation
        window.simulateSessionTimeout = ()=>{
            console.log('⏰ Test Helper: Simulating session timeout');
            const event = new CustomEvent('sessionTimeout', {
                detail: {
                    timestamp: Date.now()
                }
            });
            document.dispatchEvent(event);
        };
        // Test helper utilities
        window.testHelpers = {
            setInterviewSession: (session)=>{
                var _session_config;
                console.log('📝 Test Helper: Setting interview session', session);
                currentSession = session;
                window.interviewSession = session;
                // Add session indicators for tests
                const sessionIndicator = document.createElement('div');
                sessionIndicator.setAttribute('data-testid', 'interview-session-active');
                sessionIndicator.style.display = 'none';
                document.body.appendChild(sessionIndicator);
                const sessionIdIndicator = document.createElement('div');
                sessionIdIndicator.setAttribute('data-testid', 'session-id');
                sessionIdIndicator.setAttribute('data-session-id', session.id || ((_session_config = session.config) === null || _session_config === void 0 ? void 0 : _session_config.sessionId) || 'test-session');
                sessionIdIndicator.style.display = 'none';
                document.body.appendChild(sessionIdIndicator);
            },
            setInterviewResults: (results)=>{
                console.log('📊 Test Helper: Setting interview results', results);
                currentResults = results;
                window.interviewResults = results;
                // Add results indicator for tests
                const resultsIndicator = document.createElement('div');
                resultsIndicator.setAttribute('data-testid', 'results-ready');
                resultsIndicator.style.display = 'none';
                document.body.appendChild(resultsIndicator);
            },
            triggerError: (errorType, details)=>{
                console.log('💥 Test Helper: Triggering error:', errorType, details);
                const event = new CustomEvent('testError', {
                    detail: {
                        errorType,
                        details,
                        timestamp: Date.now()
                    }
                });
                document.dispatchEvent(event);
            }
        };
        // Add global test indicators
        const addTestIndicator = function(testId) {
            let condition = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
            if (condition && !document.querySelector('[data-testid="'.concat(testId, '"]'))) {
                const indicator = document.createElement('div');
                indicator.setAttribute('data-testid', testId);
                indicator.style.display = 'none';
                document.body.appendChild(indicator);
            }
        };
        // Add common test indicators
        addTestIndicator('voice-ready-indicator');
        addTestIndicator('voice-active-indicator');
        addTestIndicator('agent-handoff-pending');
        addTestIndicator('agent-handoff-complete');
        addTestIndicator('backup-agent-active');
        addTestIndicator('system-recovered');
        addTestIndicator('interview-resumed');
        addTestIndicator('response-processed');
        // Mock current agent indicator
        const currentAgentIndicator = document.createElement('div');
        currentAgentIndicator.setAttribute('data-testid', 'current-agent');
        currentAgentIndicator.textContent = 'TechnicalInterviewer';
        currentAgentIndicator.style.display = 'none';
        document.body.appendChild(currentAgentIndicator);
        // Mock current phase indicator
        const currentPhaseIndicator = document.createElement('div');
        currentPhaseIndicator.setAttribute('data-testid', 'current-phase');
        currentPhaseIndicator.textContent = 'technical';
        currentPhaseIndicator.style.display = 'none';
        document.body.appendChild(currentPhaseIndicator);
        // Mock questions answered counter
        const questionsAnsweredIndicator = document.createElement('div');
        questionsAnsweredIndicator.setAttribute('data-testid', 'questions-answered-count');
        questionsAnsweredIndicator.textContent = '0';
        questionsAnsweredIndicator.style.display = 'none';
        document.body.appendChild(questionsAnsweredIndicator);
        console.log('✅ Test helpers initialized for E2E testing');
        // Cleanup function
        return ()=>{
            // Remove test helpers from window
            delete window.simulateVoiceTranscript;
            delete window.simulateAgentFailure;
            delete window.simulateNetworkInterruption;
            delete window.simulateSessionTimeout;
            delete window.testHelpers;
            delete window.interviewSession;
            delete window.interviewResults;
        };
    }, []);
    // This component renders nothing - it's just for side effects
    return null;
}


/***/ }),

/***/ 19324:
/***/ (() => {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 36635:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 19324, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85959));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 41131));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 88156));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85142));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3304));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 14538));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23274));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99442));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 85925, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 56671));


/***/ }),

/***/ 41131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FirebaseClientInit)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12115);
/* __next_internal_client_entry_do_not_use__ default auto */ 
/**
 * Firebase Client Initialization Component
 * 
 * This component ensures Firebase client environment variables are properly
 * set from Azure Key Vault before Firebase services are used
 */ function FirebaseClientInit() {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const initializeFirebaseConfig = async ()=>{
            try {
                // Check if Firebase config is already available
                const hasFirebaseConfig = !!("AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0 || 0);
                if (hasFirebaseConfig) {
                    console.log('🔥 Firebase client config already available');
                    return;
                }
                console.log('🔥 Firebase client config not found, checking Azure Key Vault...');
                // Try to fetch from server-side Azure configuration
                const response = await fetch('/api/config/firebase', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                if (response.ok) {
                    const config = await response.json();
                    // Set client-side environment variables
                    if (config.apiKey) {
                        window.__NEXT_FIREBASE_API_KEY__ = config.apiKey;
                    }
                    if (config.projectId) {
                        window.__NEXT_FIREBASE_PROJECT_ID__ = config.projectId;
                    }
                    if (config.authDomain) {
                        window.__NEXT_FIREBASE_AUTH_DOMAIN__ = config.authDomain;
                    }
                    console.log('🔥 Firebase client config loaded from server:', {
                        hasApiKey: !!config.apiKey,
                        projectId: config.projectId,
                        authDomain: config.authDomain
                    });
                } else {
                    console.warn('🔥 Failed to fetch Firebase config from server, using fallback');
                }
            } catch (error) {
                console.error('🔥 Error initializing Firebase client config:', error);
            }
        };
        // Initialize Firebase config on client side only
        if (true) {
            initializeFirebaseConfig();
        }
    }, []);
    // This component doesn't render anything
    return null;
}


/***/ }),

/***/ 65061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15933);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44987);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36680);

function _templateObject() {
    const data = (0,_swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__._)([
        '\n  .banter-loader {\n    position: relative;\n    width: 72px;\n    height: 72px;\n    margin: 0 auto;\n  }\n\n  .banter-loader__box {\n    float: left;\n    position: relative;\n    width: 20px;\n    height: 20px;\n    margin-right: 6px;\n  }\n\n  .banter-loader__box:before {\n    content: "";\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 100%;\n    height: 100%;\n    background: #fff;\n  }\n\n  .banter-loader__box:nth-child(3n) {\n    margin-right: 0;\n    margin-bottom: 6px;\n  }\n\n  .banter-loader__box:nth-child(1):before, .banter-loader__box:nth-child(4):before {\n    margin-left: 26px;\n  }\n\n  .banter-loader__box:nth-child(3):before {\n    margin-top: 52px;\n  }\n\n  .banter-loader__box:last-child {\n    margin-bottom: 0;\n  }\n\n  @keyframes moveBox-1 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(1) {\n    animation: moveBox-1 4s infinite;\n  }\n\n  @keyframes moveBox-2 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, 26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(2) {\n    animation: moveBox-2 4s infinite;\n  }\n\n  @keyframes moveBox-3 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(-26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(-26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(3) {\n    animation: moveBox-3 4s infinite;\n  }\n\n  @keyframes moveBox-4 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(4) {\n    animation: moveBox-4 4s infinite;\n  }\n\n  @keyframes moveBox-5 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(5) {\n    animation: moveBox-5 4s infinite;\n  }\n\n  @keyframes moveBox-6 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(6) {\n    animation: moveBox-6 4s infinite;\n  }\n\n  @keyframes moveBox-7 {\n    9.0909090909% {\n      transform: translate(26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(7) {\n    animation: moveBox-7 4s infinite;\n  }\n\n  @keyframes moveBox-8 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(8) {\n    animation: moveBox-8 4s infinite;\n  }\n\n  @keyframes moveBox-9 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-52px, 0);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0);\n    }\n\n    100% {\n      transform: translate(0px, 0);\n    }\n  }\n\n  .banter-loader__box:nth-child(9) {\n    animation: moveBox-9 4s infinite;\n  }\n'
    ]);
    _templateObject = function() {
        return data;
    };
    return data;
}




const Loader = (param)=>{
    let { overlay = false, text, backgroundOpacity = 80, blur = true, className, ariaLabel = 'Loading...' } = param;
    const loaderContent = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(StyledWrapper, {
        className: className,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
                className: "banter-loader",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    })
                ]
            }),
            overlay && text && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("p", {
                className: "text-white text-center mt-4 font-medium",
                "aria-live": "polite",
                children: text
            })
        ]
    });
    if (overlay) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("fixed inset-0 z-50 flex items-center justify-center flex-col", blur && "backdrop-blur-md", "transition-all duration-300"),
            style: {
                backgroundColor: "rgba(0, 0, 0, ".concat(backgroundOpacity / 100, ")"),
                backdropFilter: blur ? 'blur(8px)' : 'none',
                WebkitBackdropFilter: blur ? 'blur(8px)' : 'none'
            },
            role: "dialog",
            "aria-modal": "true",
            "aria-label": ariaLabel,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                className: "relative",
                children: loaderContent
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
        role: "status",
        "aria-label": ariaLabel,
        children: loaderContent
    });
};
const StyledWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Ay.div(_templateObject());
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ }),

/***/ 85959:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Providers)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/MantineProvider.mjs + 16 modules
var MantineProvider = __webpack_require__(39380);
// EXTERNAL MODULE: ./node_modules/swr/dist/index/index.mjs + 5 modules
var index = __webpack_require__(60838);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(56671);
;// ./contexts/SWRProvider.tsx
/* __next_internal_client_entry_do_not_use__ SWRProvider,createOptimisticUpdate,cacheKeys auto */ 


// Global SWR configuration
const swrConfig = {
    // Cache data for 5 minutes by default
    dedupingInterval: 5 * 60 * 1000,
    // Revalidate on focus after 30 seconds
    focusThrottleInterval: 30 * 1000,
    // Revalidate on reconnect
    revalidateOnReconnect: true,
    // Don't revalidate on focus for real-time data (we have listeners)
    revalidateOnFocus: false,
    // Retry failed requests up to 3 times
    errorRetryCount: 3,
    // Exponential backoff for retries
    errorRetryInterval: 1000,
    // Show loading states quickly
    loadingTimeout: 3000,
    // Global error handler
    onError: (error, key)=>{
        var _error_message;
        console.error('SWR Error:', {
            error,
            key
        });
        // Don't show toast errors for auth-related issues or expected errors
        if ((error === null || error === void 0 ? void 0 : error.code) === 'permission-denied' || (error === null || error === void 0 ? void 0 : (_error_message = error.message) === null || _error_message === void 0 ? void 0 : _error_message.includes('auth'))) {
            return;
        }
        // Show user-friendly error messages
        if (error === null || error === void 0 ? void 0 : error.message) {
            dist/* toast */.o.error('Something went wrong', {
                description: 'Please try again in a moment.'
            });
        }
    },
    // Global success handler for mutations
    onSuccess: (data, key)=>{
    // You can add global success handling here if needed
    // For now, we'll handle success per component
    },
    // Fallback data while loading
    fallback: {},
    // Keep data fresh in background
    revalidateIfStale: true,
    // Keep previous data while revalidating
    keepPreviousData: true,
    // Use suspense for better loading states
    suspense: false
};
function SWRProvider(param) {
    let { children } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(index/* SWRConfig */.BE, {
        value: swrConfig,
        children: children
    });
}
// Utility function to create optimistic updates
function createOptimisticUpdate(currentData, newItem, getId, action) {
    const id = getId(newItem);
    switch(action){
        case 'add':
            return [
                newItem,
                ...currentData
            ];
        case 'update':
            return currentData.map((item)=>getId(item) === id ? {
                    ...item,
                    ...newItem
                } : item);
        case 'delete':
            return currentData.filter((item)=>getId(item) !== id);
        default:
            return currentData;
    }
}
// Utility function for cache invalidation patterns
const cacheKeys = {
    userInterviews: (userId)=>"user-interviews/".concat(userId),
    publicInterviews: (userId)=>"public-interviews/".concat(userId),
    interview: (interviewId)=>"interviews/".concat(interviewId),
    feedback: (interviewId, userId)=>"feedback/".concat(interviewId, "/").concat(userId),
    userProfile: (userId)=>"users/".concat(userId),
    applicationStatus: (applicationId)=>"applicationStatuses/".concat(applicationId)
};

;// ./app/providers.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


function Providers(param) {
    let { children } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(SWRProvider, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(MantineProvider/* MantineProvider */.y, {
            theme: {
                fontFamily: 'inherit',
                primaryColor: 'blue'
            },
            children: children
        })
    });
}


/***/ }),

/***/ 88156:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ NetworkLoggerInit)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
;// ./lib/utils/network-logger.ts
/* __next_internal_client_entry_do_not_use__ initNetworkLogger,getNetworkCalls,getAuthCalls,getCallsToEndpoint,analyzeLoops,clearNetworkHistory,displayNetworkStats,getNetworkStats auto */ const networkCalls = (/* unused pure expression or super */ null && ([]));
const originalFetch =  true ? window.fetch : 0;
/**
 * Initialize network logging
 */ function initNetworkLogger() {
    if (true) {
        return;
    }
    console.log('🔍 Network logger initialized - tracing all fetch calls');
    // Monkey patch window.fetch
    window.fetch = function() {
        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
            args[_key] = arguments[_key];
        }
        var _stackLines_;
        const [input, init] = args;
        const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url;
        const method = (init === null || init === void 0 ? void 0 : init.method) || 'GET';
        // Create error to capture stack trace
        const error = new Error();
        const stack = error.stack || '';
        // Extract caller information from stack trace
        const stackLines = stack.split('\n');
        const caller = ((_stackLines_ = stackLines[2]) === null || _stackLines_ === void 0 ? void 0 : _stackLines_.trim()) || 'unknown';
        const networkCall = {
            url,
            method,
            timestamp: Date.now(),
            stack,
            caller
        };
        networkCalls.push(networkCall);
        // Log auth-related calls immediately
        if (url.includes('/api/auth/')) {
            console.group("\uD83D\uDD0D AUTH API CALL: ".concat(method, " ").concat(url));
            console.log('Timestamp:', new Date(networkCall.timestamp).toISOString());
            console.log('Caller:', caller);
            console.log('Full stack:', stack);
            console.groupEnd();
        }
        // Log dashboard-related calls immediately
        if (url.includes('/api/dashboard/') || url.includes('/dashboard')) {
            console.group("\uD83D\uDCCA DASHBOARD API CALL: ".concat(method, " ").concat(url));
            console.log('Timestamp:', new Date(networkCall.timestamp).toISOString());
            console.log('Caller:', caller);
            console.log('Full stack:', stack);
            console.groupEnd();
        }
        // Log sync-firebase calls (potential polling source)
        if (url.includes('/api/auth/sync-firebase')) {
            console.group("\uD83D\uDD04 SYNC-FIREBASE CALL: ".concat(method, " ").concat(url));
            console.log('Timestamp:', new Date(networkCall.timestamp).toISOString());
            console.log('Caller:', caller);
            console.warn('⚠️  This may be part of a polling loop!');
            console.log('Full stack:', stack);
            console.groupEnd();
        }
        // Call original fetch
        return originalFetch.apply(this, args);
    };
}
/**
 * Get all network calls
 */ function getNetworkCalls() {
    return [
        ...networkCalls
    ];
}
/**
 * Get auth-related network calls
 */ function getAuthCalls() {
    return networkCalls.filter((call)=>call.url.includes('/api/auth/'));
}
/**
 * Get calls to specific endpoint
 */ function getCallsToEndpoint(endpoint) {
    return networkCalls.filter((call)=>call.url.includes(endpoint));
}
/**
 * Analyze call frequency for potential loops
 */ function analyzeLoops() {
    let windowMs = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 5000;
    const now = Date.now();
    const recentCalls = networkCalls.filter((call)=>now - call.timestamp <= windowMs);
    const endpointCounts = recentCalls.reduce((acc, call)=>{
        acc[call.url] = (acc[call.url] || 0) + 1;
        return acc;
    }, {});
    return Object.entries(endpointCounts).map((param)=>{
        let [endpoint, count] = param;
        return {
            endpoint,
            count,
            frequency: count / (windowMs / 1000),
            isLoop: count > 3 // More than 3 calls in window indicates a potential loop
        };
    });
}
/**
 * Clear network call history
 */ function clearNetworkHistory() {
    networkCalls.length = 0;
    console.log('🗑️ Network call history cleared');
}
/**
 * Display current network statistics
 */ function displayNetworkStats() {
    if (true) return;
    const authCalls = getAuthCalls();
    const loops = analyzeLoops();
    console.group('📊 Network Statistics');
    console.log("Total calls: ".concat(networkCalls.length));
    console.log("Auth calls: ".concat(authCalls.length));
    if (loops.length > 0) {
        console.group('🔄 Potential loops detected:');
        loops.filter((l)=>l.isLoop).forEach((loop)=>{
            console.warn("".concat(loop.endpoint, ": ").concat(loop.count, " calls (").concat(loop.frequency.toFixed(1), "/s)"));
        });
        console.groupEnd();
    }
    if (authCalls.length > 0) {
        console.group('🔐 Recent auth calls:');
        authCalls.slice(-5).forEach((call)=>{
            console.log("".concat(call.method, " ").concat(call.url, " - ").concat(call.caller));
        });
        console.groupEnd();
    }
    console.groupEnd();
}
/**
 * Export network statistics for testing
 */ function getNetworkStats() {
    return {
        totalCalls: networkCalls.length,
        authCalls: getAuthCalls().length,
        loops: analyzeLoops(),
        recentAuthCalls: getAuthCalls().slice(-10)
    };
}
// Auto-display stats every 10 seconds in development (DISABLED to prevent polling)
// if (typeof window !== 'undefined' && process.env.NODE_ENV === 'development') {
//   setInterval(displayNetworkStats, 10000);
// }
// Instead, provide manual trigger for debugging:
if (false) {}

;// ./components/NetworkLoggerInit.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

function NetworkLoggerInit() {
    (0,react.useEffect)(()=>{
        // Only initialize network logger if explicitly enabled in development
        if (false) {}
    }, []);
    return null;
}


/***/ }),

/***/ 99442:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LoadingProvider: () => (/* binding */ LoadingProvider),
/* harmony export */   M: () => (/* binding */ useLoading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _components_ui_BanterLoader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65061);
/* __next_internal_client_entry_do_not_use__ LoadingProvider,useLoading auto */ 


const LoadingContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(undefined);
const LoadingProvider = (param)=>{
    let { children } = param;
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [loadingText, setLoadingText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('Loading...');
    const [minimumDuration, setMinimumDuration] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(500); // Minimum 500ms loading time
    const timeoutRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const startTimeRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const safetyTimeoutRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const showLoader = function() {
        let text = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Loading...', minDuration = arguments.length > 1 ? arguments[1] : void 0;
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
        if (safetyTimeoutRef.current) {
            clearTimeout(safetyTimeoutRef.current);
        }
        setLoadingText(text);
        setIsLoading(true);
        startTimeRef.current = Date.now();
        if (minDuration !== undefined) {
            setMinimumDuration(minDuration);
        }
        // Safety timeout: force hide after 5 seconds to prevent infinite loading
        safetyTimeoutRef.current = setTimeout(()=>{
            console.warn('Loading timeout reached, force hiding loader');
            setIsLoading(false);
            startTimeRef.current = null;
        }, 5000);
    };
    const hideLoader = function() {
        let force = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
        // Clear safety timeout
        if (safetyTimeoutRef.current) {
            clearTimeout(safetyTimeoutRef.current);
        }
        if (force) {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
            setIsLoading(false);
            startTimeRef.current = null;
            return;
        }
        const elapsedTime = startTimeRef.current ? Date.now() - startTimeRef.current : 0;
        const remainingTime = Math.max(0, minimumDuration - elapsedTime);
        if (remainingTime > 0) {
            timeoutRef.current = setTimeout(()=>{
                setIsLoading(false);
                startTimeRef.current = null;
            }, remainingTime);
        } else {
            setIsLoading(false);
            startTimeRef.current = null;
        }
    };
    const value = {
        isLoading,
        loadingText,
        showLoader,
        hideLoader,
        setMinimumDuration: (duration)=>setMinimumDuration(duration)
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(LoadingContext.Provider, {
        value: value,
        children: [
            children,
            isLoading && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_ui_BanterLoader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A, {
                overlay: true,
                text: loadingText
            })
        ]
    });
};
const useLoading = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(LoadingContext);
    if (!context) {
        throw new Error('useLoading must be used within a LoadingProvider');
    }
    return context;
};


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, [2533,7552,9798,9471,6671,3738,838,1800,6680,5142,8441,1684,7358], () => (__webpack_exec__(36635)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);