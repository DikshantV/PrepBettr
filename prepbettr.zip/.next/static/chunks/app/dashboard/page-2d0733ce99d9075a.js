(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[5105],{

/***/ 8773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ DashboardClientRealtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/client/app-dir/link.js
var app_dir_link = __webpack_require__(6874);
var link_default = /*#__PURE__*/__webpack_require__.n(app_dir_link);
// EXTERNAL MODULE: ./node_modules/next/dist/api/image.js
var api_image = __webpack_require__(66766);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(97168);
// EXTERNAL MODULE: ./node_modules/dayjs/dayjs.min.js
var dayjs_min = __webpack_require__(30832);
var dayjs_min_default = /*#__PURE__*/__webpack_require__.n(dayjs_min);
// EXTERNAL MODULE: ./components/DisplayTechIcons.tsx
var DisplayTechIcons = __webpack_require__(16159);
// EXTERNAL MODULE: ./components/tech-icons.ts
var tech_icons = __webpack_require__(87396);
;// ./lib/hooks/useRealtimeFirestore.ts
/**
 * Realtime Firestore Hooks Compatibility Layer
 * 
 * SWR-based implementations of realtime Firestore hooks for backward compatibility
 * Components using these should be migrated to Azure services with SignalR
 */ 
/**
 * Mock useRealtimeInterview hook
 * @param interviewId - Interview ID to watch
 * @returns Realtime interview data
 */ function useRealtimeInterview(interviewId) {
    const [interview, setInterview] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    useEffect(()=>{
        if (!interviewId) {
            setLoading(false);
            return;
        }
        // Mock realtime updates
        const timer = setTimeout(()=>{
            setInterview({
                id: interviewId,
                userId: 'mock-user',
                status: 'in-progress',
                questions: [
                    'What is your experience?',
                    'What are your goals?'
                ],
                answers: [
                    'I have 5 years experience',
                    'I want to grow'
                ],
                createdAt: new Date(),
                updatedAt: new Date()
            });
            setLoading(false);
        }, 1000);
        // Remove periodic updates to prevent polling loops
        // Real implementations should use SignalR or WebSocket connections
        // const updateTimer = setInterval(() => {
        //   setInterview(prev => prev ? {
        //     ...prev,
        //     updatedAt: new Date()
        //   } : null);
        // }, 10000);
        return ()=>{
            clearTimeout(timer);
        // clearInterval(updateTimer); // Commented out since updateTimer is no longer defined
        };
    }, [
        interviewId
    ]);
    return {
        interview,
        loading,
        error
    };
}
/**
 * Mock useRealtimeApplicationStatus hook
 * @param applicationId - Application ID to watch
 * @returns Realtime application status
 */ function useRealtimeApplicationStatus(applicationId) {
    const [status, setStatus] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    useEffect(()=>{
        if (!applicationId) {
            setLoading(false);
            return;
        }
        // Mock realtime status updates
        let progress = 0;
        const stages = [
            'Initializing application',
            'Processing documents',
            'Analyzing requirements',
            'Generating response',
            'Finalizing application'
        ];
        const updateStatus = ()=>{
            if (progress < 100) {
                progress += 20;
                const stageIndex = Math.floor(progress / 20) - 1;
                setStatus({
                    id: applicationId,
                    userId: 'mock-user',
                    status: progress < 100 ? 'processing' : 'completed',
                    progress,
                    details: {
                        stage: stages[stageIndex] || 'Completed',
                        message: "Processing... ".concat(progress, "% complete"),
                        warningMessages: progress > 60 ? [
                            'Quality check passed'
                        ] : undefined
                    },
                    updatedAt: new Date()
                });
                if (progress >= 100) {
                    setLoading(false);
                }
            }
        };
        const initialTimer = setTimeout(()=>{
            updateStatus();
            setLoading(false);
        }, 500);
        const progressTimer = setInterval(updateStatus, 2000);
        return ()=>{
            clearTimeout(initialTimer);
            clearInterval(progressTimer);
        };
    }, [
        applicationId
    ]);
    return {
        status,
        loading,
        error
    };
}
// Static mock data for dashboard - no API calls
function useRealtimeUserInterviews(userId) {
    // Return static mock data immediately, no API calls
    const interviews = userId ? [
        {
            id: 'mock-interview-user',
            userId,
            role: 'Software Engineer',
            type: 'technical',
            techstack: [
                'React',
                'TypeScript'
            ],
            status: 'completed',
            questions: [
                'Tell me about yourself'
            ],
            answers: [
                'I am a developer'
            ],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        }
    ] : [];
    return {
        data: interviews,
        isLoading: false,
        error: null
    };
}
function useRealtimePublicInterviews() {
    let limit = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 4;
    // Return static mock data immediately, no API calls
    const interviews = [
        {
            id: 'public-interview-1',
            userId: 'public-user-1',
            role: 'Frontend Developer',
            type: 'technical',
            techstack: [
                'React',
                'JavaScript'
            ],
            status: 'completed',
            questions: [
                'How do you handle state management?'
            ],
            answers: [
                'I use React hooks and context'
            ],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        },
        {
            id: 'public-interview-2',
            userId: 'public-user-2',
            role: 'Backend Developer',
            type: 'technical',
            techstack: [
                'Node.js',
                'Python'
            ],
            status: 'completed',
            questions: [
                'Explain REST API design'
            ],
            answers: [
                'REST follows HTTP principles with resources'
            ],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        },
        {
            id: 'public-interview-3',
            userId: 'public-user-3',
            role: 'Data Scientist',
            type: 'technical',
            techstack: [
                'Python',
                'Machine Learning'
            ],
            status: 'completed',
            questions: [
                'Explain supervised learning'
            ],
            answers: [
                'Uses labeled data to train models'
            ],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        }
    ].slice(0, limit);
    return {
        data: interviews,
        isLoading: false,
        error: null
    };
}
function useRealtimeFeedback(interviewId) {
    const [feedback, setFeedback] = (0,react.useState)(null);
    const [loading, setLoading] = (0,react.useState)(true);
    const [error, setError] = (0,react.useState)(null);
    (0,react.useEffect)(()=>{
        if (!interviewId) {
            setLoading(false);
            return;
        }
        // Mock feedback loading
        setTimeout(()=>{
            setFeedback({
                id: interviewId,
                score: 85,
                comments: 'Great performance!',
                areas: [
                    'Technical skills',
                    'Communication'
                ],
                createdAt: new Date()
            });
            setLoading(false);
        }, 1000);
    }, [
        interviewId
    ]);
    return {
        feedback,
        loading,
        error
    };
}

// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(23274);
// EXTERNAL MODULE: ./lib/utils/communityInterviewStorage.ts
var communityInterviewStorage = __webpack_require__(60853);
// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(36680);
;// ./components/InterviewCardClient.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










const InterviewCardClient = (param)=>{
    let { interviewId, role, type, techstack, createdAt, companyLogo, level, context = 'dashboard', isCommunityCard = false } = param;
    const { user } = (0,AuthContext/* useAuth */.A)();
    const userId = user === null || user === void 0 ? void 0 : user.uid;
    const { feedback, loading: feedbackLoading } = useRealtimeFeedback(userId && interviewId ? interviewId : '');
    const normalizedType = /mix/gi.test(type) ? "Mixed" : type;
    const badgeColor = {
        Behavioral: "bg-light-400",
        Mixed: "bg-light-600",
        Technical: "bg-light-800"
    }[normalizedType] || "bg-light-600";
    const formattedDate = dayjs_min_default()((feedback === null || feedback === void 0 ? void 0 : feedback.createdAt) || createdAt || new Date('2024-01-01')).format("MMM D, YYYY");
    // Determine link URLs based on context
    const getInterviewLink = ()=>{
        if (context === 'community-mock-interview') {
            // Store community interview data in localStorage for persistence
            (0,communityInterviewStorage/* setCommunityInterviewInStorage */.L7)({
                id: interviewId || '',
                role,
                type,
                techstack,
                level,
                createdAt,
                companyLogo
            });
            return "/community-mock-interview/interview?id=".concat(interviewId, "&role=").concat(encodeURIComponent(role), "&type=").concat(encodeURIComponent(type), "&level=").concat(encodeURIComponent(level || ''), "&techstack=").concat(encodeURIComponent(techstack.join(',')));
        }
        return "/dashboard/interview/".concat(interviewId);
    };
    const getFeedbackLink = ()=>{
        if (context === 'community-mock-interview') {
            // For community mock interviews, we might want different feedback behavior
            // For now, keep the dashboard feedback link but this can be customized later
            return "/dashboard/interview/".concat(interviewId, "/feedback");
        }
        return "/dashboard/interview/".concat(interviewId, "/feedback");
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "card-border w-[360px] max-sm:w-full h-96",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "card-interview",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: (0,utils.cn)("absolute top-0 right-0 w-fit px-4 py-2 rounded-bl-lg", badgeColor),
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                className: "badge-text ",
                                children: normalizedType
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "size-20 relative",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                                src: companyLogo || (0,utils/* getRandomInterviewCover */.o8)(interviewId),
                                alt: "".concat(role, " logo"),
                                fill: true,
                                className: "object-contain rounded-full ring-1 ring-white/10"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("h3", {
                            className: "mt-5 capitalize text-white",
                            children: [
                                role,
                                level ? " - ".concat(level) : '',
                                " Interview"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-row gap-5 mt-3",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex flex-row gap-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                                            src: "/calendar.svg",
                                            width: 22,
                                            height: 22,
                                            alt: "calendar"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                            children: formattedDate
                                        })
                                    ]
                                }),
                                !isCommunityCard && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex flex-row gap-2 items-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                                            src: "/star.svg",
                                            width: 22,
                                            height: 22,
                                            alt: "star"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                            children: [
                                                feedbackLoading ? "..." : (feedback === null || feedback === void 0 ? void 0 : feedback.totalScore) || "---",
                                                "/100"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        !isCommunityCard && /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                            className: "line-clamp-2 mt-5",
                            children: feedbackLoading ? "Loading feedback..." : (feedback === null || feedback === void 0 ? void 0 : feedback.finalAssessment) || "You haven't taken this interview yet. Take it now to improve your skills."
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex flex-row justify-between items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "flex flex-row gap-1",
                            children: techstack.slice(0, 4).map((tech, index)=>{
                                // Check if the tech string is a valid TechIconName
                                const isValidTechIcon = tech in tech_icons/* techIconMap */.qj;
                                return isValidTechIcon ? /*#__PURE__*/ (0,jsx_runtime.jsx)(DisplayTechIcons/* default */.A, {
                                    name: tech,
                                    size: 20
                                }, index) : null;
                            }).filter(Boolean)
                        }),
                        isCommunityCard ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                            className: "btn-primary",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)((link_default()), {
                                href: getInterviewLink(),
                                children: "Take Interview"
                            })
                        }) : /* For regular cards, show feedback or take interview based on feedback status */ feedback ? /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                            className: "btn-primary",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)((link_default()), {
                                href: getFeedbackLink(),
                                children: "Check Feedback"
                            })
                        }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                            className: "btn-primary",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)((link_default()), {
                                href: getInterviewLink(),
                                children: "Take Interview"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_InterviewCardClient = (InterviewCardClient);

// EXTERNAL MODULE: ./components/ui/skeleton.tsx
var skeleton = __webpack_require__(27737);
// EXTERNAL MODULE: ./components/ui/card.tsx
var card = __webpack_require__(88482);
// EXTERNAL MODULE: ./components/ui/BanterLoader.tsx
var BanterLoader = __webpack_require__(65061);
;// ./components/ui/LoadingStates.tsx
/* __next_internal_client_entry_do_not_use__ InterviewCardSkeleton,DashboardSkeleton,FeedbackSkeleton,InterviewDetailSkeleton,RealtimeStatusIndicator,DataSuspense,OptimisticUpdateIndicator auto */ 



// Interview card skeleton
function InterviewCardSkeleton() {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                className: "space-y-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex justify-between items-start",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-5 w-32"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-4 w-16"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                        className: "h-4 w-24"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                className: "space-y-3",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-wrap gap-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-6 w-16"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-6 w-20"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-6 w-18"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex justify-between items-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-4 w-28"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-8 w-24"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
// Dashboard loading skeleton
function DashboardSkeleton() {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "space-y-8",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                className: "card-cta",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-col gap-6 max-w-lg",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-12 w-96"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-6 w-80"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                                className: "h-10 w-40"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "max-sm:hidden",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                            className: "h-80 w-80 rounded-lg"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                className: "flex flex-col gap-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                        className: "h-8 w-48"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "interviews-section",
                        children: Array.from({
                            length: 4
                        }).map((_, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(InterviewCardSkeleton, {}, i))
                    })
                ]
            })
        ]
    });
}
// Feedback page skeleton
function FeedbackSkeleton() {
    return /*#__PURE__*/ _jsxs("div", {
        className: "max-w-4xl mx-auto space-y-8 p-6",
        children: [
            /*#__PURE__*/ _jsxs("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ _jsx(Skeleton, {
                        className: "h-8 w-64"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex gap-4",
                        children: [
                            /*#__PURE__*/ _jsx(Skeleton, {
                                className: "h-6 w-20"
                            }),
                            /*#__PURE__*/ _jsx(Skeleton, {
                                className: "h-6 w-24"
                            }),
                            /*#__PURE__*/ _jsx(Skeleton, {
                                className: "h-6 w-18"
                            })
                        ]
                    })
                ]
            }),
            Array.from({
                length: 3
            }).map((_, i)=>/*#__PURE__*/ _jsxs(Card, {
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ _jsx(CardHeader, {
                            children: /*#__PURE__*/ _jsx(Skeleton, {
                                className: "h-6 w-48"
                            })
                        }),
                        /*#__PURE__*/ _jsxs(CardContent, {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ _jsx(Skeleton, {
                                    className: "h-4 w-full"
                                }),
                                /*#__PURE__*/ _jsx(Skeleton, {
                                    className: "h-4 w-3/4"
                                }),
                                /*#__PURE__*/ _jsx(Skeleton, {
                                    className: "h-4 w-1/2"
                                })
                            ]
                        })
                    ]
                }, i))
        ]
    });
}
// Interview detail skeleton
function InterviewDetailSkeleton() {
    return /*#__PURE__*/ _jsxs("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ _jsxs("div", {
                className: "space-y-2",
                children: [
                    /*#__PURE__*/ _jsx(Skeleton, {
                        className: "h-8 w-64"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "flex gap-2",
                        children: [
                            /*#__PURE__*/ _jsx(Skeleton, {
                                className: "h-6 w-16"
                            }),
                            /*#__PURE__*/ _jsx(Skeleton, {
                                className: "h-6 w-20"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "space-y-4",
                children: Array.from({
                    length: 5
                }).map((_, i)=>/*#__PURE__*/ _jsx(Card, {
                        children: /*#__PURE__*/ _jsxs(CardContent, {
                            className: "p-4 space-y-2",
                            children: [
                                /*#__PURE__*/ _jsx(Skeleton, {
                                    className: "h-5 w-3/4"
                                }),
                                /*#__PURE__*/ _jsx(Skeleton, {
                                    className: "h-4 w-full"
                                }),
                                /*#__PURE__*/ _jsx(Skeleton, {
                                    className: "h-4 w-2/3"
                                })
                            ]
                        })
                    }, i))
            })
        ]
    });
}
// Real-time status indicator
function RealtimeStatusIndicator(param) {
    let { isConnected, lastUpdate } = param;
    return /*#__PURE__*/ _jsxs("div", {
        className: "flex items-center gap-2 text-xs text-muted-foreground",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "w-2 h-2 rounded-full ".concat(isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500')
            }),
            /*#__PURE__*/ _jsxs("span", {
                children: [
                    isConnected ? 'Live' : 'Disconnected',
                    lastUpdate && /*#__PURE__*/ _jsxs("span", {
                        className: "ml-1",
                        children: [
                            "• Updated ",
                            lastUpdate.toLocaleTimeString()
                        ]
                    })
                ]
            })
        ]
    });
}
function DataSuspense(param) {
    let { children, fallback, error, isLoading, isEmpty = false, emptyMessage = "No data available" } = param;
    // Show error state
    if (error) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* Card */.Zp, {
            className: "w-full p-6 text-center",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-destructive mb-2",
                        children: "⚠️ Error"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                        className: "text-muted-foreground",
                        children: error
                    })
                ]
            })
        });
    }
    // Show loading state
    if (isLoading) {
        return fallback || /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {
            text: "Loading..."
        });
    }
    // Show empty state
    if (isEmpty) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* Card */.Zp, {
            className: "w-full p-6 text-center",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-muted-foreground mb-2",
                        children: "\uD83D\uDCED"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                        className: "text-muted-foreground",
                        children: emptyMessage
                    })
                ]
            })
        });
    }
    // Show data
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: children
    });
}
// Optimistic update indicator
function OptimisticUpdateIndicator(param) {
    let { isPending, message = "Saving..." } = param;
    if (!isPending) return null;
    return /*#__PURE__*/ _jsxs("div", {
        className: "flex items-center gap-2 text-xs text-muted-foreground bg-muted px-2 py-1 rounded",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "w-3 h-3 border-2 border-primary border-t-transparent rounded-full animate-spin"
            }),
            /*#__PURE__*/ _jsx("span", {
                children: message
            })
        ]
    });
}

;// ./app/dashboard/DashboardClientRealtime.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









function DashboardClientRealtime() {
    const { user, loading: authLoading } = (0,AuthContext/* useAuth */.A)();
    const carouselRef = (0,react.useRef)(null);
    // Real-time hooks with SWR caching
    const { data: userInterviews = [], isLoading: userInterviewsLoading, error: userInterviewsError } = useRealtimeUserInterviews();
    const { data: publicInterviews = [], isLoading: publicInterviewsLoading, error: publicInterviewsError } = useRealtimePublicInterviews(8); // Load more for dashboard
    // Show loading state while auth is being determined
    if (authLoading) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(DashboardSkeleton, {});
    }
    // Show sign in message only if not loading and no user
    if (!user) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
            className: "card-cta",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex flex-col gap-6 max-w-lg",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                        className: "text-white dark:text-white",
                        children: "Get Interview-Ready with AI-Powered Practice & Feedback"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                        className: "text-lg",
                        children: "Please sign in to access your interviews"
                    })
                ]
            })
        });
    }
    const hasUserInterviews = userInterviews.length > 0;
    const hasPublicInterviews = publicInterviews.length > 0;
    const scrollCarousel = (direction)=>{
        if (carouselRef.current) {
            const scrollAmount = direction === 'left' ? -400 : 400;
            carouselRef.current.scrollBy({
                left: scrollAmount,
                behavior: 'smooth'
            });
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "space-y-8",
        "data-testid": "dashboard",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                className: "card-cta",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-col gap-6 max-w-lg",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                                className: "text-white dark:text-white",
                                children: "Get Interview-Ready with AI-Powered Practice & Feedback"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                className: "text-lg",
                                children: "Practice real interview questions & get instant feedback"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                asChild: true,
                                className: "btn-primary max-sm:w-full",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)((link_default()), {
                                    href: "/dashboard/interview",
                                    children: "Start an Interview"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                        src: "/robot.png",
                        alt: "robo-dude",
                        width: 400,
                        height: 400,
                        className: "max-sm:hidden"
                    })
                ]
            }),
            user && /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex items-center justify-between",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                            className: "text-white dark:text-white",
                            children: "Your Recent Interviews"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(DataSuspense, {
                        isLoading: userInterviewsLoading,
                        error: userInterviewsError,
                        isEmpty: !hasUserInterviews,
                        emptyMessage: "You haven't created any interviews yet. Start your first interview above!",
                        fallback: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "interviews-section",
                            children: Array.from({
                                length: 3
                            }).map((_, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(InterviewCardSkeleton, {}, i))
                        }),
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "interviews-section",
                                children: userInterviews.slice(0, 6).map((interview)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(components_InterviewCardClient, {
                                        interviewId: interview.id,
                                        role: interview.role,
                                        type: interview.type,
                                        techstack: (0,utils/* normalizeTechstack */.iE)(interview.techstack),
                                        createdAt: interview.createdAt
                                    }, interview.id))
                            }),
                            userInterviews.length > 6 && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "text-center",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                    variant: "outline",
                                    asChild: true,
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)((link_default()), {
                                        href: "/dashboard/interviews",
                                        children: "View All Your Interviews"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex items-center justify-between",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                            className: "text-white dark:text-white",
                            children: "Community Mock Interviews"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(DataSuspense, {
                        isLoading: publicInterviewsLoading,
                        error: publicInterviewsError,
                        isEmpty: !hasPublicInterviews,
                        emptyMessage: "No public interviews available at the moment.",
                        fallback: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "relative",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("ul", {
                                className: "no-list flex overflow-x-auto scroll-snap-x gap-4 no-scrollbar",
                                children: Array.from({
                                    length: 4
                                }).map((_, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                                        className: "flex-shrink-0 w-[360px] scroll-snap-start",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(InterviewCardSkeleton, {})
                                    }, i))
                            })
                        }),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "relative flex items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("ul", {
                                    ref: carouselRef,
                                    className: "no-list flex overflow-x-auto scroll-snap-x gap-4 no-scrollbar flex-1",
                                    children: publicInterviews.slice(0, 8).map((interview)=>{
                                        const isCommunityCard = true;
                                        return /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                                            className: "flex-shrink-0 w-[360px] scroll-snap-start",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(components_InterviewCardClient, {
                                                interviewId: interview.id,
                                                role: interview.role,
                                                type: interview.type,
                                                techstack: (0,utils/* normalizeTechstack */.iE)(interview.techstack),
                                                createdAt: interview.createdAt,
                                                context: "community-mock-interview",
                                                isCommunityCard: isCommunityCard
                                            })
                                        }, interview.id);
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex flex-col gap-2 ml-4 shrink-0",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                            variant: "default",
                                            size: "lg",
                                            className: "bg-red-500 hover:bg-red-600 text-white h-12 w-12 rounded-full shadow-2xl border-4 border-white",
                                            onClick: ()=>scrollCarousel('left'),
                                            "aria-label": "Previous interviews",
                                            children: "←"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                            variant: "default",
                                            size: "lg",
                                            className: "bg-blue-500 hover:bg-blue-600 text-white h-12 w-12 rounded-full shadow-2xl border-4 border-white",
                                            onClick: ()=>scrollCarousel('right'),
                                            "aria-label": "Next interviews",
                                            children: "→"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 9522:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8773));


/***/ }),

/***/ 23274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ useAuth),
/* harmony export */   AuthProvider: () => (/* binding */ AuthProvider)
/* harmony export */ });
/* unused harmony export AuthContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* __next_internal_client_entry_do_not_use__ AuthProvider,useAuth,AuthContext auto */ 

/**
 * Refresh the current Firebase auth token
 */ async function refreshAuthToken() {
    try {
        // Import Firebase auth dynamically to avoid SSR issues
        const { getCurrentUserIdToken } = await Promise.all(/* import() */[__webpack_require__.e(2992), __webpack_require__.e(7811), __webpack_require__.e(1840), __webpack_require__.e(3549), __webpack_require__.e(2144)]).then(__webpack_require__.bind(__webpack_require__, 12144));
        console.log('🔄 Attempting to refresh Firebase ID token...');
        // Force refresh the Firebase ID token
        const freshToken = await getCurrentUserIdToken(true);
        if (freshToken) {
            // Update localStorage with the new token
            localStorage.setItem('auth_token', freshToken);
            console.log('✅ Firebase ID token refreshed successfully');
            return freshToken;
        } else {
            console.warn('⚠️ No fresh token returned from Firebase');
            return null;
        }
    } catch (error) {
        console.error('❌ Token refresh failed:', error);
        // If Firebase auth is not available or user is not signed in,
        // clear the auth state completely
        if (error instanceof Error && error.message.includes('No Firebase user signed in')) {
            localStorage.removeItem('auth_token');
            // Clear all caches
            Object.keys(localStorage).forEach((key)=>{
                if (key.startsWith('auth_verification_')) {
                    localStorage.removeItem(key);
                }
            });
        }
        return null;
    }
}
// Create the context with default values
const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    user: null,
    loading: true,
    isAuthenticated: false,
    signOut: async ()=>{}
});
// AuthProvider component that manages unified auth state
function AuthProvider(param) {
    let { children, initialUser } = param;
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialUser || null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!initialUser);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Only check auth state once on mount
        let mounted = true;
        const checkAuthState = async ()=>{
            // Skip auth checks on authentication pages to prevent API loops
            const isAuthPage =  true && [
                '/sign-in',
                '/sign-up'
            ].includes(window.location.pathname);
            if (isAuthPage) {
                console.log('🚫 Auth check skipped: on authentication page');
                if (mounted) {
                    setUser(null);
                    setLoading(false);
                }
                return;
            }
            try {
                // First check for session cookie to avoid unnecessary API call
                const cookies = document.cookie.split(';').reduce((acc, cookie)=>{
                    const [name, value] = cookie.trim().split('=');
                    acc[name] = value;
                    return acc;
                }, {});
                const sessionCookie = cookies.session;
                const token = localStorage.getItem('auth_token');
                // If no session cookie and no token, user is not authenticated
                if (!sessionCookie && !token) {
                    if (mounted) {
                        setUser(null);
                        setLoading(false);
                    }
                    return;
                }
                // Only verify token if we have one
                if (token) {
                    // Check for cached verification result (15 min cache)
                    const cacheKey = "auth_verification_".concat(token.substring(0, 10));
                    const cachedVerification = localStorage.getItem(cacheKey);
                    if (cachedVerification) {
                        try {
                            const cached = JSON.parse(cachedVerification);
                            const cacheAge = Date.now() - cached.timestamp;
                            // Use cached result if less than 15 minutes old
                            if (cacheAge < 15 * 60 * 1000) {
                                console.log('🚀 Using cached auth verification');
                                if (mounted && cached.verified && cached.user) {
                                    setUser(cached.user);
                                }
                                if (mounted) {
                                    setLoading(false);
                                }
                                return;
                            } else {
                                // Remove expired cache
                                localStorage.removeItem(cacheKey);
                            }
                        } catch (error) {
                            // Invalid cache, remove it
                            localStorage.removeItem(cacheKey);
                        }
                    }
                    console.log('🔍 Verifying auth token via API');
                    const response = await fetch('/api/auth/verify', {
                        headers: {
                            'Authorization': "Bearer ".concat(token)
                        }
                    });
                    if (response.ok) {
                        const userData = await response.json();
                        // Cache successful verification
                        const cacheData = {
                            verified: true,
                            user: userData.user,
                            timestamp: Date.now()
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        if (mounted) {
                            setUser(userData.user);
                        }
                    } else if (response.status === 401) {
                        // Token is invalid/expired, check if server suggests refresh
                        const errorData = await response.json().catch(()=>({}));
                        const shouldRefresh = errorData.shouldRefresh !== false; // Default to true
                        console.log('🔄 Token expired/invalid:', errorData.error || 'Unknown error');
                        if (shouldRefresh) {
                            console.log('🔄 Attempting token refresh...');
                            try {
                                const refreshed = await refreshAuthToken();
                                if (refreshed && mounted) {
                                    // Retry verification with new token
                                    const retryResponse = await fetch('/api/auth/verify', {
                                        headers: {
                                            'Authorization': "Bearer ".concat(refreshed)
                                        }
                                    });
                                    if (retryResponse.ok) {
                                        const userData = await retryResponse.json();
                                        // Cache successful verification with new token
                                        const newCacheKey = "auth_verification_".concat(refreshed.substring(0, 10));
                                        const cacheData = {
                                            verified: true,
                                            user: userData.user,
                                            timestamp: Date.now()
                                        };
                                        localStorage.setItem(newCacheKey, JSON.stringify(cacheData));
                                        if (mounted) {
                                            setUser(userData.user);
                                        }
                                        return;
                                    }
                                }
                            } catch (refreshError) {
                                console.error('🔄 Token refresh failed:', refreshError);
                            }
                        }
                        // If refresh failed or not recommended, clear auth state
                        localStorage.removeItem('auth_token');
                        // Clear all verification caches
                        Object.keys(localStorage).forEach((key)=>{
                            if (key.startsWith('auth_verification_')) {
                                localStorage.removeItem(key);
                            }
                        });
                        if (mounted) {
                            setUser(null);
                        }
                    } else {
                        // Other error, cache failed verification temporarily (1 min)
                        const cacheData = {
                            verified: false,
                            user: null,
                            timestamp: Date.now() - 14 * 60 * 1000 // Expire quickly for failed attempts
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        localStorage.removeItem('auth_token');
                        if (mounted) {
                            setUser(null);
                        }
                    }
                } else if (sessionCookie) {
                    // If we have session cookie but no token, consider user logged in
                    // but with minimal user data
                    if (mounted) {
                        setUser({
                            uid: 'session-user',
                            email: 'unknown@session.com',
                            email_verified: false
                        });
                    }
                }
            } catch (error) {
                console.error('Auth state check failed:', error);
                if (mounted) {
                    setUser(null);
                }
            } finally{
                if (mounted) {
                    setLoading(false);
                }
            }
        };
        if (!initialUser) {
            checkAuthState();
        } else {
            setLoading(false);
        }
        return ()=>{
            mounted = false;
        };
    }, [
        initialUser
    ]);
    const signOut = async ()=>{
        try {
            await fetch('/api/auth/signout', {
                method: 'POST'
            });
            localStorage.removeItem('auth_token');
            setUser(null);
        } catch (error) {
            console.error('Sign out error:', error);
        }
    };
    const contextValue = {
        user,
        loading,
        isAuthenticated: !!user,
        signOut
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(AuthContext.Provider, {
        value: contextValue,
        children: children
    });
}
// Custom hook to use the auth context
function useAuth() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthContext);
    if (context === undefined) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
}
// Export the context for advanced use cases



/***/ }),

/***/ 27737:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ Skeleton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36680);


function Skeleton(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        "data-slot": "skeleton",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_1__.cn)("bg-accent animate-pulse rounded-md", className),
        ...props
    });
}



/***/ }),

/***/ 88482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BT: () => (/* binding */ CardDescription),
/* harmony export */   Wu: () => (/* binding */ CardContent),
/* harmony export */   ZB: () => (/* binding */ CardTitle),
/* harmony export */   Zp: () => (/* binding */ Card),
/* harmony export */   aR: () => (/* binding */ CardHeader)
/* harmony export */ });
/* unused harmony export CardFooter */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);



const Card = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    });
});
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    });
});
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    });
});
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-sm text-muted-foreground", className),
        ...props
    });
});
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("p-6 pt-0", className),
        ...props
    });
});
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center p-6 pt-0", className),
        ...props
    });
});
CardFooter.displayName = "CardFooter";



/***/ }),

/***/ 97168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Button)
/* harmony export */ });
/* unused harmony export buttonVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99708);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74466);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);





const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none", {
    variants: {
        variant: {
            default: "bg-primary-200 text-dark-100 shadow-xs hover:bg-primary-200/90 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            destructive: "bg-destructive-100 text-white shadow-xs hover:bg-destructive-200 focus-visible:ring-destructive-100/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            outline: "border border-gray-600 bg-gray-800 text-white shadow-xs hover:bg-gray-700 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800/50 disabled:text-gray-500 disabled:border-gray-700",
            secondary: "bg-gray-700 text-white shadow-xs hover:bg-gray-600 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800 disabled:text-gray-500",
            ghost: "text-white hover:bg-gray-800 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500",
            link: "text-primary-200 underline-offset-4 hover:underline focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button(param) {
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__/* .Slot */ .DX : "button";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Comp, {
        "data-slot": "button",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    });
}



/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, [2362,6711,9798,6874,6766,9471,1297,6680,6551,8441,1684,7358], () => (__webpack_exec__(9522)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);