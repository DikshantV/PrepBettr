(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[1954],{

/***/ 55778:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 37315));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 84874));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23274));


/***/ }),

/***/ 56171:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   db: () => (/* binding */ db),
/* harmony export */   hJ: () => (/* binding */ googleProvider),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23915);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16203);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(35317);
/* provided dependency */ var process = __webpack_require__(87358);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  true ? window.__NEXT_FIREBASE_API_KEY__ : 0;
    const windowProjectId =  true ? window.__NEXT_FIREBASE_PROJECT_ID__ : 0;
    const windowAuthDomain =  true ? window.__NEXT_FIREBASE_AUTH_DOMAIN__ : 0;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || "".concat(finalProjectId, ".firebaseapp.com");
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (false) {}
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__/* .getApps */ .Dk)();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__/* .initializeApp */ .Wp)(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .getAuth */ .xI)(app);
        db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__/* .getFirestore */ .aU)(app);
        // Initialize Google Auth Provider
        googleProvider = new firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .GoogleAuthProvider */ .HF();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (true) {
                    localStorage.removeItem('auth_token');
                    sessionStorage.removeItem('auth_token');
                    window.location.reload();
                }
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (true) {
    initializeFirebase();
}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});


/***/ }),

/***/ 84874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  AuthSync: () => (/* binding */ AuthSync)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/firebase/auth/dist/esm/index.esm.js + 1 modules
var index_esm = __webpack_require__(16203);
// EXTERNAL MODULE: ./firebase/client.ts
var client = __webpack_require__(56171);
// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(23274);
;// ./lib/utils/firebase-auth-debug.ts
/**
 * Firebase Auth Debug Utility (Stub)
 * 
 * Provides mock debugging functionality for Firebase authentication
 * This is a compatibility layer since Firebase is being phased out
 */ function debugFirebaseAuth(auth) {
    console.log('Firebase Auth Debug (stub) - Firebase services are deprecated');
    console.log('Auth object:', auth);
}
function logAuthState(user) {
    console.log('Auth State Debug (stub):', user);
}
function validateAuthToken(token) {
    console.warn('Firebase auth token validation is deprecated - use unified auth system');
    return !!token; // Basic validation
}
/* harmony default export */ const firebase_auth_debug = ({
    debugFirebaseAuth,
    logAuthState,
    validateAuthToken
});

;// ./components/AuthSync.tsx
/* __next_internal_client_entry_do_not_use__ AuthSync auto */ 




function AuthSync() {
    const { user } = (0,AuthContext/* useAuth */.A)();
    (0,react.useEffect)(()=>{
        async function syncAuth() {
            // Only run in development for debugging
            if (false) {}
            // If we have a user from server context but no Firebase user, 
            // there's an authentication mismatch
            if (user && client/* auth */.j2 && !client/* auth */.j2.currentUser) {
                console.warn('Authentication mismatch detected: Server has user but Firebase client does not');
                console.warn('This may cause Firestore permission errors');
                console.warn('User ID from server:', user.uid);
                // Try to get a fresh token from the server to sync Firebase auth
                try {
                    const response = await fetch('/api/auth/sync-firebase');
                    if (response.ok) {
                        const { customToken } = await response.json();
                        if (customToken) {
                            await (0,index_esm/* signInWithCustomToken */.p)(client/* auth */.j2, customToken);
                            console.log('Successfully synced Firebase authentication');
                        }
                    }
                } catch (error) {
                    console.error('Failed to sync Firebase authentication:', error);
                }
            }
        }
        // Run auth sync after a short delay to allow Firebase to initialize
        const timer = setTimeout(syncAuth, 1000);
        return ()=>clearTimeout(timer);
    }, [
        user
    ]);
    return null; // This component doesn't render anything
}


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, [2992,7811,9798,6874,6766,1840,6671,3549,9112,1641,5901,6680,7315,8441,1684,7358], () => (__webpack_exec__(55778)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);