(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[2219],{

/***/ 2539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ useInterview)
/* harmony export */ });
/* unused harmony export useInterviews */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12115);
/**
 * Firestore Hooks Compatibility Layer
 * 
 * Mock implementations of Firestore hooks for backward compatibility
 * Components using these should be migrated to Azure Cosmos DB
 */ 
/**
 * Mock useInterview hook
 * @param interviewId - Interview ID to fetch
 * @returns Mock interview data
 */ function useInterview(interviewId) {
    const [interview, setInterview] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // Mock loading behavior
        const timer = setTimeout(()=>{
            if (interviewId) {
                // Return mock data
                setInterview({
                    id: interviewId,
                    userId: 'mock-user',
                    questions: [
                        'What is your experience?',
                        'What are your goals?'
                    ],
                    answers: [
                        'I have 5 years experience',
                        'I want to grow'
                    ],
                    createdAt: new Date(),
                    updatedAt: new Date()
                });
            }
            setLoading(false);
        }, 500);
        return ()=>clearTimeout(timer);
    }, [
        interviewId
    ]);
    return {
        interview,
        loading,
        error,
        updateInterview: async (updates)=>{
            // Mock update
            if (interview) {
                setInterview({
                    ...interview,
                    ...updates,
                    updatedAt: new Date()
                });
            }
        }
    };
}
/**
 * Mock useInterviews hook
 * @param userId - User ID to fetch interviews for
 * @returns Mock interviews list
 */ function useInterviews(userId) {
    const [interviews, setInterviews] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    useEffect(()=>{
        // Mock loading behavior
        const timer = setTimeout(()=>{
            if (userId) {
                // Return mock data
                setInterviews([
                    {
                        id: 'interview-1',
                        userId,
                        questions: [
                            'Tell me about yourself'
                        ],
                        answers: [
                            'I am a software engineer'
                        ],
                        createdAt: new Date(),
                        updatedAt: new Date()
                    }
                ]);
            }
            setLoading(false);
        }, 500);
        return ()=>clearTimeout(timer);
    }, [
        userId
    ]);
    return {
        interviews,
        loading,
        error
    };
}


/***/ }),

/***/ 8714:
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ 41102:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   clearAzureSecretsCache: () => (/* binding */ clearAzureSecretsCache),
/* harmony export */   fetchAzureSecrets: () => (/* binding */ fetchAzureSecrets),
/* harmony export */   getAzureConfig: () => (/* binding */ getAzureConfig),
/* harmony export */   getConfiguration: () => (/* binding */ getConfiguration),
/* harmony export */   initializeAzureEnvironment: () => (/* binding */ initializeAzureEnvironment)
/* harmony export */ });
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87497);
/* harmony import */ var _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83091);
/* provided dependency */ var process = __webpack_require__(87358);


// Client-side safety check - provide empty implementations when running on client
const isClient = "object" !== 'undefined';
if (isClient) {
    console.warn('[Azure Config] Running on client side - using fallback implementations');
}
// Azure Key Vault configuration
const AZURE_KEY_VAULT_URI = process.env.AZURE_KEY_VAULT_URI || 'https://prepbettr-keyvault-083.vault.azure.net/';
let cachedSecrets = null;
/**
 * Initialize Azure Key Vault client
 */ function createKeyVaultClient() {
    if (!AZURE_KEY_VAULT_URI) {
        throw new Error('AZURE_KEY_VAULT_URI environment variable is required');
    }
    const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_0__/* .DefaultAzureCredential */ .gv();
    return new _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__/* .SecretClient */ ._V(AZURE_KEY_VAULT_URI, credential);
}
/**
 * Clear cached secrets (useful when Azure keys are renewed)
 */ function clearAzureSecretsCache() {
    if (isClient) return;
    console.log('🔄 Clearing Azure secrets cache...');
    cachedSecrets = null;
}
/**
 * Fetch secrets from Azure Key Vault
 */ async function fetchAzureSecrets() {
    let forceRefresh = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    if (isClient) {
        return {
            speechKey: '',
            speechEndpoint: '',
            azureOpenAIKey: '',
            azureOpenAIEndpoint: '',
            azureOpenAIDeployment: '',
            firebaseProjectId: '',
            firebaseClientEmail: '',
            firebasePrivateKey: ''
        };
    }
    // Clear cache if force refresh is requested
    if (forceRefresh) {
        clearAzureSecretsCache();
    }
    // Return cached secrets if available
    if (cachedSecrets) {
        return cachedSecrets;
    }
    try {
        console.log('🔑 Fetching secrets from Azure Key Vault...');
        const client = createKeyVaultClient();
        // Helper function to suppress expected 404 errors for optional secrets
        const getOptionalSecret = (name)=>client.getSecret(name).catch((err)=>{
                if (err.statusCode !== 404) {
                    console.warn("⚠️ Unexpected error fetching optional secret '".concat(name, "':"), err.message);
                }
                return null;
            });
        // Fetch all secrets (some are optional)
        const [speechKey, speechEndpoint, azureOpenAIKey, azureOpenAIEndpoint, azureOpenAIDeployment, firebaseProjectId, firebaseClientEmail, firebasePrivateKey, firebaseClientKey, azureFormRecognizerKey, azureFormRecognizerEndpoint, azureStorageAccount, azureStorageAccountKey, azureStorageConnectionString, azureStorageContainer, storageProvider] = await Promise.all([
            client.getSecret('speech-key'),
            client.getSecret('speech-endpoint'),
            client.getSecret('azure-openai-key'),
            client.getSecret('azure-openai-endpoint'),
            client.getSecret('azure-openai-deployment'),
            getOptionalSecret('firebase-project-id'),
            getOptionalSecret('firebase-client-email'),
            getOptionalSecret('firebase-private-key'),
            getOptionalSecret('NEXT-PUBLIC-FIREBASE-CLIENT-KEY'),
            getOptionalSecret('azure-form-recognizer-key'),
            getOptionalSecret('azure-form-recognizer-endpoint'),
            getOptionalSecret('azure-storage-account'),
            getOptionalSecret('azure-storage-account-key'),
            getOptionalSecret('azure-storage-connection-string'),
            getOptionalSecret('azure-storage-container'),
            getOptionalSecret('storage-provider')
        ]);
        // Validate only Azure-related secrets (Firebase can come from env vars)
        const requiredAzureSecrets = {
            speechKey: speechKey === null || speechKey === void 0 ? void 0 : speechKey.value,
            speechEndpoint: speechEndpoint === null || speechEndpoint === void 0 ? void 0 : speechEndpoint.value,
            azureOpenAIKey: azureOpenAIKey === null || azureOpenAIKey === void 0 ? void 0 : azureOpenAIKey.value,
            azureOpenAIEndpoint: azureOpenAIEndpoint === null || azureOpenAIEndpoint === void 0 ? void 0 : azureOpenAIEndpoint.value,
            azureOpenAIDeployment: azureOpenAIDeployment === null || azureOpenAIDeployment === void 0 ? void 0 : azureOpenAIDeployment.value
        };
        const missingAzureSecrets = Object.entries(requiredAzureSecrets).filter((param)=>{
            let [_, value] = param;
            return !value;
        }).map((param)=>{
            let [key, _] = param;
            return key;
        });
        if (missingAzureSecrets.length > 0) {
            throw new Error("Required Azure secrets missing from Key Vault: ".concat(missingAzureSecrets.join(', ')));
        }
        cachedSecrets = {
            speechKey: speechKey.value,
            speechEndpoint: speechEndpoint.value,
            azureOpenAIKey: azureOpenAIKey.value,
            azureOpenAIEndpoint: azureOpenAIEndpoint.value,
            azureOpenAIDeployment: azureOpenAIDeployment.value,
            firebaseProjectId: (firebaseProjectId === null || firebaseProjectId === void 0 ? void 0 : firebaseProjectId.value) || process.env.FIREBASE_PROJECT_ID || '',
            firebaseClientEmail: (firebaseClientEmail === null || firebaseClientEmail === void 0 ? void 0 : firebaseClientEmail.value) || process.env.FIREBASE_CLIENT_EMAIL || '',
            firebasePrivateKey: (firebasePrivateKey === null || firebasePrivateKey === void 0 ? void 0 : firebasePrivateKey.value) || process.env.FIREBASE_PRIVATE_KEY || '',
            firebaseClientKey: (firebaseClientKey === null || firebaseClientKey === void 0 ? void 0 : firebaseClientKey.value) || '',
            azureFormRecognizerKey: azureFormRecognizerKey === null || azureFormRecognizerKey === void 0 ? void 0 : azureFormRecognizerKey.value,
            azureFormRecognizerEndpoint: azureFormRecognizerEndpoint === null || azureFormRecognizerEndpoint === void 0 ? void 0 : azureFormRecognizerEndpoint.value,
            azureStorageAccount: azureStorageAccount === null || azureStorageAccount === void 0 ? void 0 : azureStorageAccount.value,
            azureStorageAccountKey: azureStorageAccountKey === null || azureStorageAccountKey === void 0 ? void 0 : azureStorageAccountKey.value,
            azureStorageConnectionString: azureStorageConnectionString === null || azureStorageConnectionString === void 0 ? void 0 : azureStorageConnectionString.value,
            azureStorageContainer: azureStorageContainer === null || azureStorageContainer === void 0 ? void 0 : azureStorageContainer.value,
            storageProvider: storageProvider === null || storageProvider === void 0 ? void 0 : storageProvider.value
        };
        console.log('✅ Azure secrets loaded successfully');
        return cachedSecrets;
    } catch (error) {
        console.error('❌ Failed to fetch Azure secrets:', error);
        // Fallback to environment variables if Key Vault fails
        console.log('🔄 Falling back to environment variables...');
        const fallbackSecrets = {
            speechKey: process.env.AZURE_SPEECH_KEY || process.env.SPEECH_KEY || '',
            speechEndpoint: process.env.SPEECH_ENDPOINT || 'https://eastus2.api.cognitive.microsoft.com/',
            azureOpenAIKey: process.env.AZURE_OPENAI_API_KEY || process.env.AZURE_OPENAI_KEY || '',
            azureOpenAIEndpoint: process.env.AZURE_OPENAI_ENDPOINT || '',
            azureOpenAIDeployment: process.env.AZURE_OPENAI_DEPLOYMENT || '',
            // Firebase fallbacks
            firebaseProjectId: process.env.FIREBASE_PROJECT_ID || '',
            firebaseClientEmail: process.env.FIREBASE_CLIENT_EMAIL || '',
            firebasePrivateKey: process.env.FIREBASE_PRIVATE_KEY || '',
            firebaseClientKey: '',
            // Optional fallbacks
            azureFormRecognizerKey: process.env.AZURE_FORM_RECOGNIZER_KEY,
            azureFormRecognizerEndpoint: process.env.AZURE_FORM_RECOGNIZER_ENDPOINT,
            azureStorageAccount: process.env.AZURE_STORAGE_ACCOUNT_NAME,
            azureStorageAccountKey: process.env.AZURE_STORAGE_ACCOUNT_KEY
        };
        // Only warn about critical missing secrets
        const missingCritical = [];
        if (!fallbackSecrets.speechKey) missingCritical.push('SPEECH_KEY');
        if (!fallbackSecrets.azureOpenAIKey) missingCritical.push('AZURE_OPENAI_KEY');
        // Only warn about missing optional secrets if not available from environment
        const missingOptional = [];
        if (!fallbackSecrets.firebaseProjectId && !process.env.FIREBASE_PROJECT_ID) missingOptional.push('FIREBASE_PROJECT_ID');
        if (missingCritical.length > 0) {
            console.error("❌ Critical secrets missing: ".concat(missingCritical.join(', ')));
        }
        if (missingOptional.length > 0) {
            console.warn("⚠️ Optional secrets missing: ".concat(missingOptional.join(', ')));
        }
        cachedSecrets = fallbackSecrets;
        return cachedSecrets;
    }
}
/**
 * Initialize environment variables from Azure Key Vault
 * This should be called at application startup
 */ async function initializeAzureEnvironment() {
    if (isClient) return;
    try {
        const secrets = await fetchAzureSecrets();
        // Set Azure service environment variables
        process.env.SPEECH_KEY = secrets.speechKey;
        process.env.SPEECH_ENDPOINT = secrets.speechEndpoint;
        // Set Azure OpenAI environment variables
        process.env.AZURE_OPENAI_KEY = secrets.azureOpenAIKey;
        process.env.AZURE_OPENAI_ENDPOINT = secrets.azureOpenAIEndpoint;
        process.env.AZURE_OPENAI_DEPLOYMENT = secrets.azureOpenAIDeployment;
        // Set Firebase environment variables
        process.env.FIREBASE_PROJECT_ID = secrets.firebaseProjectId;
        process.env.FIREBASE_CLIENT_EMAIL = secrets.firebaseClientEmail;
        process.env.FIREBASE_PRIVATE_KEY = secrets.firebasePrivateKey;
        // Set client-side environment variables using string concatenation to avoid Next.js inlining
        const nextPublicPrefix = 'NEXT_PUBLIC_';
        process.env[nextPublicPrefix + 'SPEECH_KEY'] = secrets.speechKey;
        process.env[nextPublicPrefix + 'SPEECH_ENDPOINT'] = secrets.speechEndpoint;
        process.env[nextPublicPrefix + 'AZURE_OPENAI_API_KEY'] = secrets.azureOpenAIKey;
        process.env[nextPublicPrefix + 'AZURE_OPENAI_ENDPOINT'] = secrets.azureOpenAIEndpoint;
        process.env[nextPublicPrefix + 'AZURE_OPENAI_DEPLOYMENT'] = secrets.azureOpenAIDeployment;
        process.env[nextPublicPrefix + 'FIREBASE_PROJECT_ID'] = secrets.firebaseProjectId;
        // Set the Firebase client key from secrets or environment
        if (secrets.firebaseClientKey) {
            process.env[nextPublicPrefix + 'FIREBASE_CLIENT_KEY'] = secrets.firebaseClientKey;
            console.log('🔑 Firebase client key set from Azure Key Vault');
        } else {
            console.warn('⚠️ Firebase client key not found in Azure Key Vault');
        }
        // Set optional Azure services if available
        if (secrets.azureFormRecognizerKey) {
            process.env.AZURE_FORM_RECOGNIZER_KEY = secrets.azureFormRecognizerKey;
        }
        if (secrets.azureFormRecognizerEndpoint) {
            process.env.AZURE_FORM_RECOGNIZER_ENDPOINT = secrets.azureFormRecognizerEndpoint;
        }
        // Set storage configuration
        if (secrets.azureStorageAccount) {
            process.env.AZURE_STORAGE_ACCOUNT = secrets.azureStorageAccount;
        }
        if (secrets.azureStorageAccountKey) {
            process.env.AZURE_STORAGE_ACCOUNT_KEY = secrets.azureStorageAccountKey;
        }
        if (secrets.azureStorageConnectionString) {
            process.env.AZURE_STORAGE_CONNECTION_STRING = secrets.azureStorageConnectionString;
        }
        if (secrets.azureStorageContainer) {
            process.env.AZURE_STORAGE_CONTAINER = secrets.azureStorageContainer;
        }
        if (secrets.storageProvider) {
            process.env.STORAGE_PROVIDER = secrets.storageProvider;
        }
        console.log('🌟 Azure environment initialized successfully');
    } catch (error) {
        console.error('❌ Failed to initialize Azure environment:', error);
        throw error;
    }
}
/**
 * Get generic configuration values (used by storage abstraction and other services)
 */ async function getConfiguration() {
    try {
        const secrets = await fetchAzureSecrets();
        return {
            // Azure Storage configuration
            'AZURE_STORAGE_ACCOUNT': secrets.azureStorageAccount || process.env.AZURE_STORAGE_ACCOUNT || 'prepbettrstorage684',
            'AZURE_STORAGE_ACCOUNT_KEY': secrets.azureStorageAccountKey || process.env.AZURE_STORAGE_ACCOUNT_KEY || '',
            'AZURE_STORAGE_CONNECTION_STRING': secrets.azureStorageConnectionString || process.env.AZURE_STORAGE_CONNECTION_STRING || '',
            'AZURE_STORAGE_CONTAINER': secrets.azureStorageContainer || process.env.AZURE_STORAGE_CONTAINER || 'resumes',
            'STORAGE_PROVIDER': secrets.storageProvider || process.env.STORAGE_PROVIDER || 'firebase',
            // Azure AI services
            'AZURE_OPENAI_KEY': secrets.azureOpenAIKey,
            'AZURE_OPENAI_ENDPOINT': secrets.azureOpenAIEndpoint,
            'AZURE_OPENAI_DEPLOYMENT': secrets.azureOpenAIDeployment,
            'AZURE_SPEECH_KEY': secrets.speechKey,
            'AZURE_SPEECH_ENDPOINT': secrets.speechEndpoint,
            'AZURE_FORM_RECOGNIZER_KEY': secrets.azureFormRecognizerKey || '',
            'AZURE_FORM_RECOGNIZER_ENDPOINT': secrets.azureFormRecognizerEndpoint || '',
            // Firebase configuration
            'FIREBASE_PROJECT_ID': secrets.firebaseProjectId,
            'FIREBASE_CLIENT_EMAIL': secrets.firebaseClientEmail,
            'FIREBASE_PRIVATE_KEY': secrets.firebasePrivateKey,
            'FIREBASE_CLIENT_KEY': secrets.firebaseClientKey || ''
        };
    } catch (error) {
        console.warn('Failed to get configuration from Azure, using environment variables:', error);
        // Fallback to environment variables only
        return {
            'AZURE_STORAGE_ACCOUNT': process.env.AZURE_STORAGE_ACCOUNT || 'prepbettrstorage684',
            'AZURE_STORAGE_ACCOUNT_KEY': process.env.AZURE_STORAGE_ACCOUNT_KEY || '',
            'AZURE_STORAGE_CONNECTION_STRING': process.env.AZURE_STORAGE_CONNECTION_STRING || '',
            'AZURE_STORAGE_CONTAINER': process.env.AZURE_STORAGE_CONTAINER || 'resumes',
            'STORAGE_PROVIDER': process.env.STORAGE_PROVIDER || 'firebase',
            'AZURE_OPENAI_KEY': process.env.AZURE_OPENAI_KEY || '',
            'AZURE_OPENAI_ENDPOINT': process.env.AZURE_OPENAI_ENDPOINT || '',
            'AZURE_OPENAI_DEPLOYMENT': process.env.AZURE_OPENAI_DEPLOYMENT || '',
            'AZURE_SPEECH_KEY': process.env.AZURE_SPEECH_KEY || process.env.SPEECH_KEY || '',
            'AZURE_SPEECH_ENDPOINT': process.env.SPEECH_ENDPOINT || '',
            'AZURE_FORM_RECOGNIZER_KEY': process.env.AZURE_FORM_RECOGNIZER_KEY || '',
            'AZURE_FORM_RECOGNIZER_ENDPOINT': process.env.AZURE_FORM_RECOGNIZER_ENDPOINT || '',
            'FIREBASE_PROJECT_ID': process.env.FIREBASE_PROJECT_ID || '',
            'FIREBASE_CLIENT_EMAIL': process.env.FIREBASE_CLIENT_EMAIL || '',
            'FIREBASE_PRIVATE_KEY': process.env.FIREBASE_PRIVATE_KEY || '',
            // Use string concatenation to avoid Next.js inlining
            'FIREBASE_CLIENT_KEY': process.env['NEXT_PUBLIC_' + 'FIREBASE_CLIENT_KEY'] || ''
        };
    }
}
/**
 * Get current Azure configuration (for debugging)
 */ function getAzureConfig() {
    const nextPublicPrefix = 'NEXT_PUBLIC_';
    return {
        keyVaultUri: AZURE_KEY_VAULT_URI,
        hasSecretsCache: !!cachedSecrets,
        environment: {
            speechKey: !!process.env[nextPublicPrefix + 'SPEECH_KEY'],
            speechEndpoint: !!process.env[nextPublicPrefix + 'SPEECH_ENDPOINT'],
            azureOpenAIKey: !!process.env.AZURE_OPENAI_KEY,
            azureOpenAIEndpoint: !!process.env.AZURE_OPENAI_ENDPOINT,
            azureOpenAIDeployment: !!process.env.AZURE_OPENAI_DEPLOYMENT
        }
    };
}


/***/ }),

/***/ 56171:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   db: () => (/* binding */ db),
/* harmony export */   hJ: () => (/* binding */ googleProvider),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23915);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16203);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(35317);
/* provided dependency */ var process = __webpack_require__(87358);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  true ? window.__NEXT_FIREBASE_API_KEY__ : 0;
    const windowProjectId =  true ? window.__NEXT_FIREBASE_PROJECT_ID__ : 0;
    const windowAuthDomain =  true ? window.__NEXT_FIREBASE_AUTH_DOMAIN__ : 0;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || "".concat(finalProjectId, ".firebaseapp.com");
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (false) {}
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__/* .getApps */ .Dk)();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__/* .initializeApp */ .Wp)(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .getAuth */ .xI)(app);
        db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__/* .getFirestore */ .aU)(app);
        // Initialize Google Auth Provider
        googleProvider = new firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .GoogleAuthProvider */ .HF();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (true) {
                    localStorage.removeItem('auth_token');
                    sessionStorage.removeItem('auth_token');
                    window.location.reload();
                }
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (true) {
    initializeFirebase();
}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});


/***/ }),

/***/ 60322:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 91866));


/***/ }),

/***/ 71205:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ InterviewHeader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(66766);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);
/* harmony import */ var _components_DisplayTechIcons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16159);
/* __next_internal_client_entry_do_not_use__ default auto */ 



function InterviewHeader(param) {
    let { role, techstack, type, interviewId, onToggleEditor } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "flex flex-col w-full mb-6",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center gap-4 p-4",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-4 flex-1",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            src: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__/* .getRandomInterviewCover */ .o8)(interviewId),
                            alt: "cover-image",
                            width: 48,
                            height: 48,
                            className: "rounded-full object-cover border-2 border-primary/20"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "border-l border-gray-600 h-10 mx-2"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                    className: "text-2xl font-bold capitalize text-white",
                                    children: [
                                        role,
                                        " Interview"
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center gap-2 mt-1",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "flex gap-1",
                                            children: techstack.map((tech)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_DisplayTechIcons__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A, {
                                                    name: tech,
                                                    size: 16
                                                }, tech))
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                            className: "text-sm text-gray-400",
                                            children: "•"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "text-sm text-gray-300",
                                            children: [
                                                type,
                                                " Interview"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                    onClick: onToggleEditor,
                    className: "p-2.5 text-gray-400 hover:text-white hover:bg-dark-300 rounded-lg transition-colors border border-dark-300 hover:border-gray-600",
                    "aria-label": "Toggle code editor",
                    title: "Toggle code editor",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", {
                        className: "w-6 h-6",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "24",
                        height: "24",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
                            stroke: "currentColor",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: "2",
                            d: "m8 8-4 4 4 4m8 0 4-4-4-4m-2-3-4 14"
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 89576:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ac: () => (/* binding */ getModelConfig),
/* harmony export */   I6: () => (/* binding */ validateFoundryConfig),
/* harmony export */   at: () => (/* binding */ getFoundryConfig),
/* harmony export */   fZ: () => (/* binding */ getDefaultModel)
/* harmony export */ });
/* unused harmony exports clearFoundryConfigCache, getEnvironmentDefaults, getDefaultModelConfigurations, getDefaultConnectionSettings, getFoundryConfigForEnvironment */
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87497);
/* harmony import */ var _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83091);
/* provided dependency */ var process = __webpack_require__(87358);
/**
 * Azure AI Foundry Configuration
 * 
 * This module handles configuration for Azure AI Foundry services,
 * including model configurations, retry policies, and connection settings.
 * Follows the existing pattern established in lib/azure-config.ts.
 */ 

// Client-side safety check
const isClient = "object" !== 'undefined';
if (isClient) {
    console.warn('[Azure AI Foundry Config] Running on client side - using fallback implementations');
}
// Azure Key Vault configuration (reuse existing vault)
const AZURE_KEY_VAULT_URI = process.env.AZURE_KEY_VAULT_URI || 'https://prepbettr-keyvault-083.vault.azure.net/';
let cachedFoundryConfig = null;
/**
 * Initialize Azure Key Vault client (reusing existing pattern)
 */ function createKeyVaultClient() {
    if (!AZURE_KEY_VAULT_URI) {
        throw new Error('AZURE_KEY_VAULT_URI environment variable is required');
    }
    const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_0__/* .DefaultAzureCredential */ .gv();
    return new _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__/* .SecretClient */ ._V(AZURE_KEY_VAULT_URI, credential);
}
/**
 * Clear cached foundry configuration
 */ function clearFoundryConfigCache() {
    if (isClient) return;
    console.log('🔄 Clearing Azure AI Foundry config cache...');
    cachedFoundryConfig = null;
}
/**
 * Fetch Azure AI Foundry configuration from Azure Key Vault with environment variable fallback
 * 
 * @param forceRefresh - Force refresh the cached configuration
 * @returns Promise<FoundryConfig> - The foundry configuration
 */ async function getFoundryConfig() {
    let forceRefresh = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    if (isClient) {
        // Client-side fallback - return empty config with all required fields
        return {
            endpoint: '',
            apiKey: '',
            projectId: '',
            resourceId: '',
            resourceGroup: '',
            region: '',
            models: {},
            connection: getDefaultConnectionSettings(),
            environment: 'development'
        };
    }
    // Clear cache if force refresh is requested
    if (forceRefresh) {
        clearFoundryConfigCache();
    }
    // Return cached configuration if available
    if (cachedFoundryConfig) {
        return cachedFoundryConfig;
    }
    try {
        console.log('🔑 Fetching Azure AI Foundry configuration from Key Vault...');
        const client = createKeyVaultClient();
        // Helper function to suppress expected 404 errors for optional secrets
        const getOptionalSecret = (name)=>client.getSecret(name).catch((err)=>{
                if (err.statusCode !== 404) {
                    console.warn("⚠️ Unexpected error fetching optional secret '".concat(name, "':"), err.message);
                }
                return null;
            });
        // Fetch foundry-specific secrets
        const [foundryEndpoint, foundryApiKey, foundryProjectId, foundryResourceGroup, foundryRegion, foundryDeploymentName, docIntEndpoint, docIntApiKey, docIntProjectId] = await Promise.all([
            getOptionalSecret('azure-foundry-endpoint'),
            getOptionalSecret('azure-foundry-api-key'),
            getOptionalSecret('azure-foundry-project-id'),
            getOptionalSecret('azure-foundry-resource-group'),
            getOptionalSecret('azure-foundry-region'),
            getOptionalSecret('azure-foundry-deployment-name'),
            getOptionalSecret('azure-foundry-docint-endpoint'),
            getOptionalSecret('azure-foundry-docint-api-key'),
            getOptionalSecret('azure-foundry-docint-project-id')
        ]);
        cachedFoundryConfig = {
            endpoint: (foundryEndpoint === null || foundryEndpoint === void 0 ? void 0 : foundryEndpoint.value) || process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: (foundryApiKey === null || foundryApiKey === void 0 ? void 0 : foundryApiKey.value) || process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: (foundryProjectId === null || foundryProjectId === void 0 ? void 0 : foundryProjectId.value) || process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: (foundryResourceGroup === null || foundryResourceGroup === void 0 ? void 0 : foundryResourceGroup.value) || process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            region: (foundryRegion === null || foundryRegion === void 0 ? void 0 : foundryRegion.value) || process.env.AZURE_FOUNDRY_REGION || 'eastus',
            environment: "production" || 0 || 0,
            models: getDefaultModelConfigurations(),
            connection: getDefaultConnectionSettings(),
            docIntelligence: (docIntEndpoint === null || docIntEndpoint === void 0 ? void 0 : docIntEndpoint.value) || (docIntApiKey === null || docIntApiKey === void 0 ? void 0 : docIntApiKey.value) || process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || process.env.AZURE_FOUNDRY_DOCINT_API_KEY ? {
                endpoint: (docIntEndpoint === null || docIntEndpoint === void 0 ? void 0 : docIntEndpoint.value) || process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || '',
                apiKey: (docIntApiKey === null || docIntApiKey === void 0 ? void 0 : docIntApiKey.value) || process.env.AZURE_FOUNDRY_DOCINT_API_KEY || '',
                projectId: (docIntProjectId === null || docIntProjectId === void 0 ? void 0 : docIntProjectId.value) || process.env.AZURE_FOUNDRY_DOCINT_PROJECT_ID,
                region: (foundryRegion === null || foundryRegion === void 0 ? void 0 : foundryRegion.value) || process.env.AZURE_FOUNDRY_REGION || 'eastus'
            } : undefined
        };
        // Validate required configuration
        const requiredFields = [
            'endpoint',
            'apiKey',
            'projectId',
            'resourceGroup'
        ];
        const missingFields = requiredFields.filter((field)=>!cachedFoundryConfig[field]);
        if (missingFields.length > 0) {
            console.warn("⚠️ Azure AI Foundry missing configuration: ".concat(missingFields.join(', ')));
            console.log('💡 Add these secrets to Azure Key Vault or set environment variables:');
            missingFields.forEach((field)=>{
                const envVar = "AZURE_FOUNDRY_".concat(field.toUpperCase());
                console.log("   - ".concat(envVar));
            });
        } else {
            console.log('✅ Azure AI Foundry configuration loaded successfully');
        }
        return cachedFoundryConfig;
    } catch (error) {
        console.error('❌ Failed to fetch Azure AI Foundry configuration:', error);
        // Fallback to environment variables
        console.log('🔄 Falling back to environment variables for Azure AI Foundry...');
        const fallbackConfig = {
            endpoint: process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            region: process.env.AZURE_FOUNDRY_REGION || 'eastus',
            environment: "production" || 0 || 0,
            models: getDefaultModelConfigurations(),
            connection: getDefaultConnectionSettings(),
            docIntelligence: process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || process.env.AZURE_FOUNDRY_DOCINT_API_KEY ? {
                endpoint: process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || '',
                apiKey: process.env.AZURE_FOUNDRY_DOCINT_API_KEY || '',
                projectId: process.env.AZURE_FOUNDRY_DOCINT_PROJECT_ID,
                region: process.env.AZURE_FOUNDRY_REGION || 'eastus'
            } : undefined
        };
        // Log missing critical configuration
        if (!fallbackConfig.endpoint || !fallbackConfig.apiKey) {
            console.error('❌ Critical Azure AI Foundry configuration missing from environment variables');
            console.log('💡 Set AZURE_FOUNDRY_ENDPOINT and AZURE_FOUNDRY_API_KEY environment variables');
        }
        cachedFoundryConfig = fallbackConfig;
        return cachedFoundryConfig;
    }
}
/**
 * Get environment-specific configuration defaults
 */ function getEnvironmentDefaults() {
    const environment = "production" || 0 || 0;
    const defaults = {
        development: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        },
        staging: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        },
        production: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        }
    };
    return defaults[environment] || defaults.development;
}
/**
 * Get default model configurations for Azure AI Foundry
 */ function getDefaultModelConfigurations() {
    return {
        'gpt-4o': {
            deploymentName: process.env.AZURE_FOUNDRY_GPT4O_DEPLOYMENT || 'gpt-4o',
            modelName: 'gpt-4o',
            version: '2024-05-13',
            maxTokens: 4096,
            temperature: 0.7,
            topP: 0.9,
            frequencyPenalty: 0,
            presencePenalty: 0,
            costPerToken: 0.005,
            capabilities: [
                'text-generation',
                'reasoning',
                'coding',
                'analysis'
            ],
            isDefault: true
        },
        'gpt-4-turbo': {
            deploymentName: process.env.AZURE_FOUNDRY_GPT4_TURBO_DEPLOYMENT || 'gpt-4-turbo',
            modelName: 'gpt-4-turbo',
            version: '2024-04-09',
            maxTokens: 4096,
            temperature: 0.7,
            topP: 0.9,
            frequencyPenalty: 0,
            presencePenalty: 0,
            costPerToken: 0.01,
            capabilities: [
                'text-generation',
                'reasoning',
                'coding',
                'analysis',
                'function-calling'
            ]
        },
        'phi-4': {
            deploymentName: process.env.AZURE_FOUNDRY_PHI4_DEPLOYMENT || 'phi-4',
            modelName: 'phi-4',
            version: '2024-12-12',
            maxTokens: 2048,
            temperature: 0.6,
            topP: 0.85,
            frequencyPenalty: 0.1,
            presencePenalty: 0.1,
            costPerToken: 0.001,
            capabilities: [
                'text-generation',
                'reasoning',
                'lightweight-tasks'
            ]
        }
    };
}
/**
 * Get default connection settings
 */ function getDefaultConnectionSettings() {
    const environment = "production" || 0 || 0;
    return {
        timeout: environment === 'production' ? 30000 : 60000,
        keepAlive: true,
        maxConnections: environment === 'production' ? 10 : 5,
        retryPolicy: {
            maxRetries: 3,
            baseDelay: 1000,
            maxDelay: 10000,
            exponentialBase: 2,
            jitter: true
        }
    };
}
/**
 * Get model configuration by name
 */ function getModelConfig(modelName) {
    const models = getDefaultModelConfigurations();
    return models[modelName] || null;
}
/**
 * Get default model configuration
 */ function getDefaultModel() {
    const models = getDefaultModelConfigurations();
    const defaultModel = Object.values(models).find((model)=>model.isDefault);
    return defaultModel || models['gpt-4o'];
}
/**
 * Validate foundry configuration
 */ function validateFoundryConfig(config) {
    const errors = [];
    if (!config.endpoint) {
        errors.push('Missing foundry endpoint');
    }
    if (!config.apiKey) {
        errors.push('Missing foundry API key');
    }
    if (!config.projectId) {
        errors.push('Missing foundry project ID');
    }
    if (!config.resourceGroup) {
        errors.push('Missing foundry resource group');
    }
    // Validate endpoint format
    if (config.endpoint && !config.endpoint.startsWith('https://')) {
        errors.push('Foundry endpoint must use HTTPS');
    }
    // Validate models configuration
    const models = Object.values(config.models);
    if (models.length === 0) {
        errors.push('No models configured');
    }
    const hasDefault = models.some((model)=>model.isDefault);
    if (!hasDefault) {
        errors.push('No default model configured');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * Get foundry configuration for specific environment
 */ async function getFoundryConfigForEnvironment(environment) {
    // Get config without modifying process.env to avoid webpack issues
    const config = await getFoundryConfig(true); // Force refresh
    // Override the environment in the returned config
    return {
        ...config,
        environment
    };
}


/***/ }),

/***/ 91866:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(35695);
// EXTERNAL MODULE: ./lib/hooks/useFirestore.ts
var useFirestore = __webpack_require__(2539);
// EXTERNAL MODULE: ./components/ui/BanterLoader.tsx
var BanterLoader = __webpack_require__(65061);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-down.js
var chevron_down = __webpack_require__(66474);
// EXTERNAL MODULE: ./components/Agent.tsx + 10 modules
var Agent = __webpack_require__(92310);
// EXTERNAL MODULE: ./components/CodeEditorWrapper.tsx
var CodeEditorWrapper = __webpack_require__(91944);
// EXTERNAL MODULE: ./app/dashboard/interview/[id]/InterviewHeader.tsx
var InterviewHeader = __webpack_require__(71205);
// EXTERNAL MODULE: ./node_modules/swr/dist/index/index.mjs + 5 modules
var index = __webpack_require__(60838);
// EXTERNAL MODULE: ./node_modules/firebase/firestore/dist/esm/index.esm.js
var index_esm = __webpack_require__(35317);
// EXTERNAL MODULE: ./firebase/client.ts
var client = __webpack_require__(56171);
;// ./lib/hooks/useCommunityInterview.ts
/* __next_internal_client_entry_do_not_use__ useCommunityInterview auto */ 


// Define the fetcher function for SWR
const fetcher = async (id)=>{
    if (!id) {
        throw new Error("Interview ID is required");
    }
    if (!client.db) {
        throw new Error("Firebase is not initialized");
    }
    // Reference to the document in the publicInterviews collection
    const interviewDocRef = (0,index_esm/* doc */.H9)(client.db, 'publicInterviews', id);
    // Fetch the document
    const interviewDoc = await (0,index_esm/* getDoc */.x7)(interviewDocRef);
    // Handle the case where the document does not exist
    if (!interviewDoc.exists()) {
        throw new Error("Interview not found");
    }
    // Return the document data
    return interviewDoc.data();
};
// Define the custom SWR hook
const useCommunityInterview = (id)=>{
    // Use SWR to fetch and cache the data
    const { data, error } = (0,index/* default */.Ay)(id ? id : null, fetcher, {
        revalidateOnFocus: false
    });
    return {
        interview: data,
        isLoading: !error && !data,
        isError: error
    };
};

// EXTERNAL MODULE: ./node_modules/node-fetch/browser.js
var browser = __webpack_require__(45901);
var browser_default = /*#__PURE__*/__webpack_require__.n(browser);
// EXTERNAL MODULE: ./node_modules/@azure/identity/dist/browser/index.js + 30 modules
var dist_browser = __webpack_require__(87497);
// EXTERNAL MODULE: ./node_modules/@azure/ai-projects/dist/browser/index.js + 207 modules
var ai_projects_dist_browser = __webpack_require__(9961);
// EXTERNAL MODULE: ./node_modules/@azure/ai-agents/dist/browser/index.js + 31 modules
var ai_agents_dist_browser = __webpack_require__(64348);
// EXTERNAL MODULE: ./lib/azure-ai-foundry/config/foundry-config.ts
var foundry_config = __webpack_require__(89576);
;// ./lib/azure-ai-foundry/clients/foundry-client.ts





// Client-side safety check
const isClient = "object" !== 'undefined';
if (isClient) {
    console.warn('[Azure AI Foundry Client] Running on client side - clients will not be initialized');
}
/**
 * Unified Azure AI Foundry Client
 * 
 * Combines HTTP request functionality with Azure SDK client factories.
 * Provides both low-level request() method and high-level SDK helpers.
 */ class FoundryClientBase {
    /**
   * Initialize configuration
   */ async init() {
        let forceRefresh = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
        this.config = await (0,foundry_config/* getFoundryConfig */.at)(forceRefresh);
        const { isValid, errors } = (0,foundry_config/* validateFoundryConfig */.I6)(this.config);
        if (!isValid) {
            throw new Error("Invalid Foundry configuration: ".concat(errors.join(', ')));
        }
    }
    /**
   * Build default headers with API key
   */ buildHeaders(extra) {
        return {
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': this.config.apiKey,
            'User-Agent': 'PrepBettr/FoundryClient',
            ...extra || {}
        };
    }
    /**
   * Core request helper with retry logic based on connection settings
   */ async request(path) {
        let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        const baseUrl = this.config.endpoint.replace(/\/$/, '');
        const url = "".concat(baseUrl).concat(path.startsWith('/') ? '' : '/').concat(path);
        const { connection } = this.config;
        const method = options.method || 'GET';
        const headers = this.buildHeaders(options.headers);
        const body = options.body ? JSON.stringify(options.body) : undefined;
        let attempt = 0;
        const max = connection.retryPolicy.maxRetries;
        const start = Date.now();
        while(true){
            try {
                const controller = new AbortController();
                const timeout = setTimeout(()=>controller.abort(), connection.timeout);
                const res = await browser_default()(url, {
                    method,
                    headers,
                    body,
                    // @ts-ignore node-fetch v2 compatibility
                    signal: controller.signal
                });
                clearTimeout(timeout);
                const raw = await res.text();
                let data = null;
                try {
                    data = raw ? JSON.parse(raw) : null;
                } catch (e) {
                // non-JSON response
                }
                if (!res.ok && this.shouldRetry(res.status) && attempt < max) {
                    attempt++;
                    await this.delay(this.backoff(attempt, connection));
                    continue;
                }
                return {
                    status: res.status,
                    data,
                    raw
                };
            } catch (err) {
                // AbortError / network errors
                if (attempt < max) {
                    attempt++;
                    await this.delay(this.backoff(attempt, connection));
                    continue;
                }
                throw new Error("Foundry request failed after ".concat(attempt, " retries: ").concat((err === null || err === void 0 ? void 0 : err.message) || err));
            } finally{
                // Optional: log slow requests
                const elapsed = Date.now() - start;
                if (elapsed > Math.max(2000, this.config.connection.timeout)) {
                    // eslint-disable-next-line no-console
                    console.warn("[FoundryClient] Slow request ".concat(method, " ").concat(url, " took ").concat(elapsed, "ms"));
                }
            }
        }
    }
    /**
   * Basic retry policy on transient status codes
   */ shouldRetry(status) {
        return [
            408,
            409,
            429,
            500,
            502,
            503,
            504
        ].includes(status);
    }
    /**
   * Exponential backoff with optional jitter
   */ backoff(attempt, conn) {
        const { baseDelay, maxDelay, exponentialBase, jitter } = conn.retryPolicy;
        const delay = Math.min(maxDelay, baseDelay * Math.pow(exponentialBase, attempt - 1));
        return jitter ? Math.floor(Math.random() * delay) : delay;
    }
    delay(ms) {
        return new Promise((resolve)=>setTimeout(resolve, ms));
    }
    /**
   * Validate connectivity to Foundry endpoint
   */ async validateConnection() {
        if (!this.config) await this.init();
        try {
            const res = await this.request('/', {
                method: 'GET'
            });
            // Root might be 404 but still proves connectivity
            const ok = res.status < 500;
            return {
                ok,
                status: res.status
            };
        } catch (err) {
            return {
                ok: false,
                error: (err === null || err === void 0 ? void 0 : err.message) || String(err)
            };
        }
    }
    /**
   * Placeholder for text completion call via model inference.
   * Implement with specific Foundry Inference API once finalized.
   */ // eslint-disable-next-line @typescript-eslint/no-unused-vars
    async completeText(_prompt) {
        let _modelKey = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'gpt-4o';
        throw new Error('completeText not implemented yet for Foundry Inference API');
    }
    /**
   * Azure SDK Client Methods
   */ /**
   * Create Azure AI Projects client with proper authentication
   */ createProjectsClient(config) {
        if (isClient) {
            throw new Error('Projects client cannot be initialized on client side');
        }
        try {
            const credential = new dist_browser/* DefaultAzureCredential */.gv();
            console.log("\uD83D\uDD27 Creating Azure AI Projects client for endpoint: ".concat(config.endpoint));
            const client = new ai_projects_dist_browser/* AIProjectClient */.b(config.endpoint, credential, {
                additionalPolicies: [
                    {
                        policy: {
                            name: 'PrepBettrUserAgent',
                            sendRequest: async (request, next)=>{
                                const existingUserAgent = request.headers.get('User-Agent') || '';
                                request.headers.set('User-Agent', "PrepBettr/1.0 ".concat(existingUserAgent));
                                return next(request);
                            }
                        },
                        position: 'perCall'
                    }
                ],
                retryOptions: {
                    maxRetries: 3,
                    retryDelayInMs: 1000
                }
            });
            console.log('✅ Azure AI Projects client created successfully');
            return client;
        } catch (error) {
            console.error('❌ Failed to create Azure AI Projects client:', error);
            throw error;
        }
    }
    /**
   * Create Azure AI Agents client with proper authentication
   */ createAgentsClient(config) {
        if (isClient) {
            throw new Error('Agents client cannot be initialized on client side');
        }
        try {
            const credential = new dist_browser/* DefaultAzureCredential */.gv();
            console.log("\uD83E\uDD16 Creating Azure AI Agents client for project: ".concat(config.projectId));
            const client = new ai_agents_dist_browser/* AgentsClient */.Iv(config.endpoint, credential, {
                additionalPolicies: [
                    {
                        policy: {
                            name: 'PrepBettrAgentUserAgent',
                            sendRequest: async (request, next)=>{
                                const existingUserAgent = request.headers.get('User-Agent') || '';
                                request.headers.set('User-Agent', "PrepBettr-Agent/1.0 ".concat(existingUserAgent));
                                if (config.projectId) {
                                    request.headers.set('X-Project-Id', config.projectId);
                                }
                                return next(request);
                            }
                        },
                        position: 'perCall'
                    }
                ],
                retryOptions: {
                    maxRetries: 3,
                    retryDelayInMs: 1000
                }
            });
            console.log('✅ Azure AI Agents client created successfully');
            return client;
        } catch (error) {
            console.error('❌ Failed to create Azure AI Agents client:', error);
            throw error;
        }
    }
    /**
   * Get or create Azure AI Projects client (singleton pattern)
   */ async getProjectsClient() {
        let forceRefresh = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
        if (isClient) {
            throw new Error('Projects client is not available on client side');
        }
        const config = await (0,foundry_config/* getFoundryConfig */.at)(forceRefresh);
        if (forceRefresh || !this.projectsClientInstance || !this.currentSdkConfig || this.currentSdkConfig.endpoint !== config.endpoint || this.currentSdkConfig.apiKey !== config.apiKey) {
            console.log('🔄 Creating new Azure AI Projects client instance...');
            this.projectsClientInstance = this.createProjectsClient(config);
            this.currentSdkConfig = {
                ...config
            };
        }
        return this.projectsClientInstance;
    }
    /**
   * Get or create Azure AI Agents client (singleton pattern)
   */ async getAgentsClient() {
        let forceRefresh = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
        if (isClient) {
            throw new Error('Agents client is not available on client side');
        }
        const config = await (0,foundry_config/* getFoundryConfig */.at)(forceRefresh);
        if (forceRefresh || !this.agentsClientInstance || !this.currentSdkConfig || this.currentSdkConfig.endpoint !== config.endpoint || this.currentSdkConfig.apiKey !== config.apiKey) {
            console.log('🔄 Creating new Azure AI Agents client instance...');
            this.agentsClientInstance = this.createAgentsClient(config);
            this.currentSdkConfig = {
                ...config
            };
        }
        return this.agentsClientInstance;
    }
    /**
   * Test connection to Azure AI Foundry services
   */ async testFoundryConnection() {
        if (isClient) {
            console.warn('⚠️ Cannot test foundry connection on client side');
            return false;
        }
        try {
            console.log('🔍 Testing Azure AI Foundry connection...');
            const client = await this.getProjectsClient();
            // TODO: Add actual connection test based on Azure AI Projects SDK
            console.log('✅ Azure AI Foundry connection test successful');
            return true;
        } catch (error) {
            console.error('❌ Azure AI Foundry connection test failed:', error);
            return false;
        }
    }
    /**
   * Clear SDK client instances (useful for testing or configuration updates)
   */ clearFoundryClients() {
        if (isClient) return;
        console.log('🔄 Clearing Azure AI Foundry client instances...');
        this.projectsClientInstance = null;
        this.agentsClientInstance = null;
        this.currentSdkConfig = null;
    }
    /**
   * Get current foundry configuration (for debugging)
   */ async getCurrentFoundryConfig() {
        if (isClient) {
            console.warn('⚠️ Cannot access foundry config on client side');
            return null;
        }
        try {
            return await (0,foundry_config/* getFoundryConfig */.at)();
        } catch (error) {
            console.error('❌ Failed to get current foundry configuration:', error);
            return null;
        }
    }
    constructor(){
        this.projectsClientInstance = null;
        this.agentsClientInstance = null;
        this.currentSdkConfig = null;
    }
}

;// ./lib/azure-ai-foundry/managers/model-manager.ts
/**
 * Azure AI Foundry Model Manager
 * 
 * Handles model configurations, deployments, cost tracking, and model selection logic.
 * Provides utilities for managing multiple models and their configurations.
 */ 

/**
 * FoundryModelManager class for managing model configurations and usage
 */ class FoundryModelManager extends FoundryClientBase {
    /**
   * Get all available model configurations
   */ getAvailableModels() {
        var _this_config;
        return ((_this_config = this.config) === null || _this_config === void 0 ? void 0 : _this_config.models) || {};
    }
    /**
   * Get model configuration by name with fallback
   */ getModel(modelName) {
        return (0,foundry_config/* getModelConfig */.Ac)(modelName);
    }
    /**
   * Get the default model configuration
   */ getDefaultModelConfig() {
        return (0,foundry_config/* getDefaultModel */.fZ)();
    }
    /**
   * Select best model based on criteria
   */ selectModel() {
        let criteria = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        const models = this.getAvailableModels();
        const modelList = Object.values(models);
        // Start with preferred model if specified
        if (criteria.preferredModel && models[criteria.preferredModel]) {
            const preferred = models[criteria.preferredModel];
            if (this.modelMeetsCriteria(preferred, criteria)) {
                return preferred;
            }
        }
        // Try fallback models
        if (criteria.fallbackModels) {
            for (const fallbackName of criteria.fallbackModels){
                const fallback = models[fallbackName];
                if (fallback && this.modelMeetsCriteria(fallback, criteria)) {
                    return fallback;
                }
            }
        }
        // Filter models by criteria
        let candidates = modelList.filter((model)=>this.modelMeetsCriteria(model, criteria));
        // Sort by cost (ascending) and capabilities (descending)
        candidates = candidates.sort((a, b)=>{
            // Primary sort: cost
            const costDiff = a.costPerToken - b.costPerToken;
            if (Math.abs(costDiff) > 0.001) return costDiff;
            // Secondary sort: capabilities (more is better)
            return b.capabilities.length - a.capabilities.length;
        });
        // Return best candidate or default model
        return candidates[0] || this.getDefaultModelConfig();
    }
    /**
   * Check if model meets selection criteria
   */ modelMeetsCriteria(model, criteria) {
        // Check cost constraint
        if (criteria.maxCost !== undefined && model.costPerToken > criteria.maxCost) {
            return false;
        }
        // Check capabilities
        if (criteria.requiredCapabilities) {
            const hasAllCapabilities = criteria.requiredCapabilities.every((capability)=>model.capabilities.includes(capability));
            if (!hasAllCapabilities) {
                return false;
            }
        }
        // Note: maxLatency check would require historical performance data
        // This could be implemented by tracking actual response times
        return true;
    }
    /**
   * Track usage for a model request
   */ trackUsage(param) {
        let { modelName, tokenUsage, latency, success, errorCode } = param;
        const model = this.getModel(modelName);
        if (!model) {
            console.warn("[ModelManager] Unknown model for usage tracking: ".concat(modelName));
            return;
        }
        const cost = tokenUsage.total_tokens / 1000 * model.costPerToken;
        const entry = {
            modelName,
            timestamp: new Date().toISOString(),
            promptTokens: tokenUsage.prompt_tokens,
            completionTokens: tokenUsage.completion_tokens,
            totalTokens: tokenUsage.total_tokens,
            cost,
            latency,
            success,
            errorCode
        };
        this.usageHistory.push(entry);
        // Keep only last 1000 entries to prevent memory bloat
        if (this.usageHistory.length > 1000) {
            this.usageHistory = this.usageHistory.slice(-1000);
        }
    }
    /**
   * Get performance metrics for a specific model
   */ getModelMetrics(modelName) {
        let timeRangeHours = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 24;
        const cutoff = Date.now() - timeRangeHours * 60 * 60 * 1000;
        const entries = this.usageHistory.filter((entry)=>entry.modelName === modelName && new Date(entry.timestamp).getTime() >= cutoff);
        if (entries.length === 0) {
            return {
                averageLatency: 0,
                successRate: 0,
                totalCost: 0,
                totalTokens: 0,
                requestCount: 0,
                costPerToken: 0,
                tokensPerSecond: 0
            };
        }
        const totalLatency = entries.reduce((sum, e)=>sum + e.latency, 0);
        const successCount = entries.filter((e)=>e.success).length;
        const totalCost = entries.reduce((sum, e)=>sum + e.cost, 0);
        const totalTokens = entries.reduce((sum, e)=>sum + e.totalTokens, 0);
        const totalTime = totalLatency / 1000; // convert to seconds
        return {
            averageLatency: totalLatency / entries.length,
            successRate: successCount / entries.length,
            totalCost,
            totalTokens,
            requestCount: entries.length,
            costPerToken: totalTokens > 0 ? totalCost / totalTokens * 1000 : 0,
            tokensPerSecond: totalTime > 0 ? totalTokens / totalTime : 0
        };
    }
    /**
   * Get usage statistics for all models
   */ getUsageStatistics() {
        let timeRangeHours = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 24;
        const cutoff = Date.now() - timeRangeHours * 60 * 60 * 1000;
        const entries = this.usageHistory.filter((entry)=>new Date(entry.timestamp).getTime() >= cutoff);
        const breakdown = {};
        const modelStats = new Map();
        entries.forEach((entry)=>{
            const stats = modelStats.get(entry.modelName) || {
                requests: 0,
                tokens: 0,
                errors: 0,
                latency: 0
            };
            stats.requests += 1;
            stats.tokens += entry.totalTokens;
            stats.errors += entry.success ? 0 : 1;
            stats.latency += entry.latency;
            modelStats.set(entry.modelName, stats);
        });
        modelStats.forEach((stats, modelName)=>{
            breakdown[modelName] = {
                requests: stats.requests,
                tokens: stats.tokens,
                errors: stats.errors
            };
        });
        const totalRequests = entries.length;
        const totalTokens = entries.reduce((sum, e)=>sum + e.totalTokens, 0);
        const totalErrors = entries.filter((e)=>!e.success).length;
        const totalLatency = entries.reduce((sum, e)=>sum + e.latency, 0);
        return {
            totalRequests,
            totalTokens,
            averageLatency: totalRequests > 0 ? totalLatency / totalRequests : 0,
            errorRate: totalRequests > 0 ? totalErrors / totalRequests : 0,
            timeRange: {
                start: new Date(cutoff).toISOString(),
                end: new Date().toISOString()
            },
            breakdown
        };
    }
    /**
   * Get cost estimate for a request
   */ estimateCost(modelName, estimatedTokens) {
        const model = this.getModel(modelName);
        if (!model) {
            console.warn("[ModelManager] Unknown model for cost estimation: ".concat(modelName));
            return 0;
        }
        return estimatedTokens / 1000 * model.costPerToken;
    }
    /**
   * List models sorted by cost efficiency
   */ getModelsByCostEfficiency() {
        const models = Object.values(this.getAvailableModels());
        return models.sort((a, b)=>a.costPerToken - b.costPerToken);
    }
    /**
   * Get models by capability
   */ getModelsByCapability(capability) {
        const models = Object.values(this.getAvailableModels());
        return models.filter((model)=>model.capabilities.includes(capability));
    }
    /**
   * Clear usage history (for testing or privacy)
   */ clearUsageHistory() {
        this.usageHistory = [];
        console.log('[ModelManager] Usage history cleared');
    }
    /**
   * Export usage history for external analysis
   */ exportUsageHistory() {
        return [
            ...this.usageHistory
        ]; // Return copy
    }
    /**
   * Get recommended model for specific use case
   */ getRecommendedModel(useCase) {
        const useCaseMap = {
            interview: {
                requiredCapabilities: [
                    'text-generation',
                    'reasoning'
                ],
                maxCost: 0.01,
                preferredModel: 'gpt-4o'
            },
            'code-generation': {
                requiredCapabilities: [
                    'code-generation',
                    'reasoning'
                ],
                preferredModel: 'gpt-4-turbo'
            },
            reasoning: {
                requiredCapabilities: [
                    'reasoning'
                ],
                preferredModel: 'gpt-4o'
            },
            lightweight: {
                maxCost: 0.002,
                preferredModel: 'phi-4',
                fallbackModels: [
                    'gpt-4o'
                ]
            }
        };
        const criteria = useCaseMap[useCase] || {};
        return this.selectModel(criteria);
    }
    /**
   * Health check for model availability
   */ async checkModelHealth(modelName) {
        const model = this.getModel(modelName);
        if (!model) {
            return {
                available: false,
                error: 'Model not found in configuration'
            };
        }
        try {
            const start = Date.now();
            // Simple health check with minimal prompt
            await this.request('/models/health-check', {
                method: 'POST',
                body: {
                    model: model.deploymentName,
                    prompt: 'test',
                    max_tokens: 1
                }
            });
            const latency = Date.now() - start;
            return {
                available: true,
                latency
            };
        } catch (error) {
            return {
                available: false,
                error: error.message || 'Health check failed'
            };
        }
    }
    constructor(){
        super(), this.usageHistory = [], this.deployments = new Map();
    }
}

;// ./lib/azure-ai-foundry/clients/migration-wrapper.ts
/**
 * Azure AI Foundry Migration Wrapper
 * 
 * Drop-in replacement for Azure OpenAI SDK that routes requests through
 * Azure AI Foundry while maintaining full API compatibility.
 * 
 * This allows for seamless migration from legacy OpenAI/Azure OpenAI clients
 * to the new Azure AI Foundry infrastructure without changing existing code.
 */ 

/**
 * Migration OpenAI Client
 * 
 * Provides full compatibility with OpenAI SDK while using Azure AI Foundry backend.
 * Includes cost tracking, usage monitoring, and intelligent model selection.
 */ class MigrationOpenAIClient extends FoundryClientBase {
    /**
   * Initialize the migration client
   */ async init() {
        if (this.isInitialized) return;
        await super.init(); // Call parent init
        await this.modelManager.init();
        this.isInitialized = true;
        console.log('✅ MigrationOpenAIClient initialized with Azure AI Foundry backend');
    }
    /**
   * Create chat completion (main method used by existing code)
   */ async createChatCompletion(params) {
        await this.ensureInitialized();
        const startTime = Date.now();
        const mappedModel = this.mapModel(params.model);
        const modelConfig = this.modelManager.getModel(mappedModel) || this.modelManager.getDefaultModelConfig();
        // Log cost estimation before the request
        const estimatedTokens = this.estimateTokens(params);
        const estimatedCost = estimatedTokens / 1000 * modelConfig.costPerToken;
        console.info("[Cost] Estimated cost for ".concat(mappedModel, ": $").concat(estimatedCost.toFixed(4), " (~").concat(estimatedTokens, " tokens)"));
        try {
            var _foundryResponse_data, _foundryResponse_data_choices, _foundryResponse_data1, _foundryResponse_data2, _foundryResponse_data3;
            var _params_temperature, _params_max_tokens, _params_top_p, _params_frequency_penalty, _params_presence_penalty, _params_n;
            // Convert OpenAI request to Foundry request format
            const foundryRequest = {
                messages: params.messages,
                model: mappedModel,
                temperature: (_params_temperature = params.temperature) !== null && _params_temperature !== void 0 ? _params_temperature : modelConfig.temperature,
                max_tokens: (_params_max_tokens = params.max_tokens) !== null && _params_max_tokens !== void 0 ? _params_max_tokens : modelConfig.maxTokens,
                top_p: (_params_top_p = params.top_p) !== null && _params_top_p !== void 0 ? _params_top_p : modelConfig.topP,
                frequency_penalty: (_params_frequency_penalty = params.frequency_penalty) !== null && _params_frequency_penalty !== void 0 ? _params_frequency_penalty : modelConfig.frequencyPenalty,
                presence_penalty: (_params_presence_penalty = params.presence_penalty) !== null && _params_presence_penalty !== void 0 ? _params_presence_penalty : modelConfig.presencePenalty,
                stream: false,
                stop: params.stop,
                n: (_params_n = params.n) !== null && _params_n !== void 0 ? _params_n : 1
            };
            // Make request through Foundry client (inherited method)
            const foundryResponse = await this.request("/chat/completions", {
                method: 'POST',
                body: foundryRequest
            });
            if (foundryResponse.status !== 200) {
                throw new Error("Foundry API returned status ".concat(foundryResponse.status, ": ").concat(foundryResponse.raw));
            }
            // Convert Foundry response to OpenAI format
            const openAIResponse = {
                id: ((_foundryResponse_data = foundryResponse.data) === null || _foundryResponse_data === void 0 ? void 0 : _foundryResponse_data.id) || "chatcmpl-".concat(Date.now()),
                object: 'chat.completion',
                created: Math.floor(Date.now() / 1000),
                model: mappedModel,
                choices: ((_foundryResponse_data1 = foundryResponse.data) === null || _foundryResponse_data1 === void 0 ? void 0 : (_foundryResponse_data_choices = _foundryResponse_data1.choices) === null || _foundryResponse_data_choices === void 0 ? void 0 : _foundryResponse_data_choices.map((choice, index)=>{
                    var _choice_message, _choice_message1, _choice_message2;
                    return {
                        index,
                        message: {
                            role: ((_choice_message = choice.message) === null || _choice_message === void 0 ? void 0 : _choice_message.role) || 'assistant',
                            content: ((_choice_message1 = choice.message) === null || _choice_message1 === void 0 ? void 0 : _choice_message1.content) || '',
                            function_call: (_choice_message2 = choice.message) === null || _choice_message2 === void 0 ? void 0 : _choice_message2.function_call
                        },
                        finish_reason: choice.finish_reason || 'stop'
                    };
                })) || [
                    {
                        index: 0,
                        message: {
                            role: 'assistant',
                            content: ((_foundryResponse_data2 = foundryResponse.data) === null || _foundryResponse_data2 === void 0 ? void 0 : _foundryResponse_data2.content) || foundryResponse.raw
                        },
                        finish_reason: 'stop'
                    }
                ],
                usage: ((_foundryResponse_data3 = foundryResponse.data) === null || _foundryResponse_data3 === void 0 ? void 0 : _foundryResponse_data3.usage) ? {
                    prompt_tokens: foundryResponse.data.usage.prompt_tokens || 0,
                    completion_tokens: foundryResponse.data.usage.completion_tokens || 0,
                    total_tokens: foundryResponse.data.usage.total_tokens || 0
                } : undefined
            };
            // Track usage metrics
            const latency = Date.now() - startTime;
            const actualUsage = openAIResponse.usage || {
                prompt_tokens: estimatedTokens * 0.7,
                completion_tokens: estimatedTokens * 0.3,
                total_tokens: estimatedTokens
            };
            this.modelManager.trackUsage({
                modelName: mappedModel,
                tokenUsage: actualUsage,
                latency,
                success: true
            });
            // Log actual cost
            const actualCost = actualUsage.total_tokens / 1000 * modelConfig.costPerToken;
            console.info("[Cost] Actual cost for ".concat(mappedModel, ": $").concat(actualCost.toFixed(4), " (").concat(actualUsage.total_tokens, " tokens, ").concat(latency, "ms)"));
            return openAIResponse;
        } catch (error) {
            var _error_status;
            // Track failed usage
            const latency = Date.now() - startTime;
            this.modelManager.trackUsage({
                modelName: mappedModel,
                tokenUsage: {
                    prompt_tokens: 0,
                    completion_tokens: 0,
                    total_tokens: 0
                },
                latency,
                success: false,
                errorCode: ((_error_status = error.status) === null || _error_status === void 0 ? void 0 : _error_status.toString()) || 'UNKNOWN_ERROR'
            });
            console.error("[Cost] Failed request for ".concat(mappedModel, " after ").concat(latency, "ms:"), error.message);
            throw error;
        }
    }
    /**
   * Create text completion (legacy method, less common but still used)
   */ async createCompletion(params) {
        await this.ensureInitialized();
        const startTime = Date.now();
        const mappedModel = this.mapModel(params.model);
        const modelConfig = this.modelManager.getModel(mappedModel) || this.modelManager.getDefaultModelConfig();
        // Estimate cost
        const estimatedTokens = params.prompt.length / 4; // Rough token estimation
        const estimatedCost = estimatedTokens / 1000 * modelConfig.costPerToken;
        console.info("[Cost] Estimated cost for ".concat(mappedModel, " completion: $").concat(estimatedCost.toFixed(4)));
        try {
            // Convert to chat completion format for Foundry
            const chatParams = {
                model: mappedModel,
                messages: [
                    {
                        role: 'user',
                        content: params.prompt
                    }
                ],
                temperature: params.temperature,
                max_tokens: params.max_tokens,
                top_p: params.top_p,
                frequency_penalty: params.frequency_penalty,
                presence_penalty: params.presence_penalty,
                stop: params.stop,
                n: params.n
            };
            const chatResponse = await this.createChatCompletion(chatParams);
            // Convert chat response to completion format
            const completionResponse = {
                id: chatResponse.id,
                object: 'text_completion',
                created: chatResponse.created,
                model: mappedModel,
                choices: chatResponse.choices.map((choice)=>({
                        text: choice.message.content,
                        index: choice.index,
                        finish_reason: choice.finish_reason
                    })),
                usage: chatResponse.usage
            };
            return completionResponse;
        } catch (error) {
            const latency = Date.now() - startTime;
            console.error("[Cost] Failed completion request for ".concat(mappedModel, " after ").concat(latency, "ms:"), error.message);
            throw error;
        }
    }
    /**
   * List available models
   */ async listModels() {
        await this.ensureInitialized();
        const availableModels = this.modelManager.getAvailableModels();
        const modelList = Object.entries(availableModels).map((param)=>{
            let [name, config] = param;
            return {
                id: name,
                object: 'model',
                created: Math.floor(Date.now() / 1000),
                owned_by: 'azure-ai-foundry'
            };
        });
        return {
            object: 'list',
            data: modelList
        };
    }
    /**
   * Map legacy model names to Azure AI Foundry model names
   * 
   * @param legacyModelName - Original model name from legacy code
   * @returns Mapped model name for Azure AI Foundry
   */ mapModel(legacyModelName) {
        // Define model mapping based on your specifications
        const modelMapping = {
            // GPT-4 variants → gpt-4.5 (though we'll use gpt-4o as it's available)
            'gpt-4': 'gpt-4o',
            'gpt-4-turbo': 'gpt-4-turbo',
            'gpt-4o': 'gpt-4o',
            // GPT-3.5 variants → gpt-4o (upgrade path)
            'gpt-3.5': 'gpt-4o',
            'gpt-3.5-turbo': 'gpt-4o',
            'gpt-35-turbo': 'gpt-4o',
            // Phi models (if they exist in your foundry config)
            'phi-4': 'phi-4',
            // Default fallback
            'default': 'gpt-4o'
        };
        const mapped = modelMapping[legacyModelName] || modelMapping['default'];
        if (legacyModelName !== mapped) {
            console.log("[ModelMapping] ".concat(legacyModelName, " → ").concat(mapped));
        }
        return mapped;
    }
    /**
   * Estimate token count for cost calculation
   */ estimateTokens(params) {
        const messageContent = params.messages.map((m)=>m.content).join(' ');
        // Rough estimation: 1 token ≈ 4 characters for English text
        const inputTokens = Math.ceil(messageContent.length / 4);
        const outputTokens = Math.min(params.max_tokens || 150, 500); // Conservative estimate
        return inputTokens + outputTokens;
    }
    /**
   * Ensure client is initialized before use
   */ async ensureInitialized() {
        if (!this.isInitialized) {
            await this.init();
        }
    }
    /**
   * Get usage statistics
   */ getUsageStats() {
        // Delegate to model manager for usage statistics
        return {
            availableModels: Object.keys(this.modelManager.getAvailableModels()),
            initialized: this.isInitialized
        };
    }
    /**
   * Clean up resources
   */ dispose() {
        this.isInitialized = false;
        console.log('🧹 MigrationOpenAIClient disposed');
    }
    constructor(){
        super(), this.isInitialized = false; // Call parent constructor
        this.modelManager = new FoundryModelManager();
        // Create nested API structure to match OpenAI SDK exactly
        this.chat = {
            completions: {
                create: this.createChatCompletion.bind(this)
            }
        };
        this.completions = {
            create: this.createCompletion.bind(this)
        };
    }
}
// Export singleton instance for drop-in replacement
const migrationOpenAIClient = new MigrationOpenAIClient();
// Export class for custom instantiation


// Default export for CommonJS compatibility
/* harmony default export */ const migration_wrapper = ((/* unused pure expression or super */ null && (MigrationOpenAIClient)));

;// ./lib/services/azure-openai-service.ts

// Client-side safety check
const azure_openai_service_isClient = "object" !== 'undefined';
// Only import server-side dependencies when running on server
let fetchAzureSecrets = null;
if (!azure_openai_service_isClient) {
    const azureConfig = __webpack_require__(41102);
    fetchAzureSecrets = azureConfig.fetchAzureSecrets;
}
class AzureOpenAIService {
    /**
   * Initialize the Azure OpenAI service
   */ async initialize() {
        if (azure_openai_service_isClient) {
            console.warn('[Azure OpenAI Service] Running on client side - service disabled');
            return false;
        }
        try {
            const secrets = await fetchAzureSecrets();
            if (!secrets.azureOpenAIKey || !secrets.azureOpenAIEndpoint) {
                console.warn('⚠️ Azure OpenAI credentials not available');
                return false;
            }
            this.deployment = secrets.azureOpenAIDeployment;
            this.client = new MigrationOpenAIClient();
            await this.client.init(); // Initialize the migration client
            // Test the connection with a simple request
            try {
                console.log("\uD83D\uDD04 Testing Azure OpenAI connection with deployment: ".concat(this.deployment));
                await this.client.chat.completions.create({
                    model: this.deployment,
                    messages: [
                        {
                            role: 'user',
                            content: 'Test'
                        }
                    ],
                    max_tokens: 5
                });
                this.isInitialized = true;
                console.log('✅ Azure OpenAI Service initialized and tested successfully');
                return true;
            } catch (testError) {
                console.error('❌ Azure OpenAI connection test failed:', testError.message);
                console.error('📋 Configuration details:', {
                    endpoint: secrets.azureOpenAIEndpoint,
                    deployment: this.deployment,
                    hasApiKey: !!secrets.azureOpenAIKey
                });
                if (testError.status === 401) {
                    console.error('🔐 Authentication Error (401):');
                    console.error('   • Your API key might be invalid or expired');
                    console.error('   • Check your Azure OpenAI resource for the correct key');
                } else if (testError.status === 404) {
                    console.error('📍 Resource Not Found (404):');
                    console.error('   • The deployment "' + this.deployment + '" does not exist');
                    console.error('   • Your endpoint URL might be incorrect');
                    console.error('   • No deployments might exist in your Azure OpenAI resource');
                    console.error('💡 To fix this:');
                    console.error('   1. Log into portal.azure.com');
                    console.error('   2. Navigate to your Azure OpenAI resource');
                    console.error('   3. Check the "Model deployments" or "Deployments" section');
                    console.error('   4. Create a deployment (e.g., gpt-35-turbo, gpt-4)');
                    console.error('   5. Update AZURE_OPENAI_DEPLOYMENT in your .env.local file');
                } else if (testError.status === 403) {
                    console.error('🚫 Access Forbidden (403):');
                    console.error('   • Your API key might not have the right permissions');
                    console.error('   • Your Azure OpenAI resource might not be properly configured');
                } else {
                    console.error("❓ Unexpected error (".concat(testError.status || 'Unknown', "):"));
                    console.error('   • Check your Azure OpenAI resource configuration');
                    console.error('   • Verify your subscription and resource status');
                }
                return false;
            }
        } catch (error) {
            console.error('❌ Failed to initialize Azure OpenAI Service:', error);
            return false;
        }
    }
    /**
   * Set interview context for conversation management
   */ setInterviewContext(context) {
        const previousState = {
            ...this.interviewContext
        };
        var _context_preliminaryCollected, _ref, _context_currentQuestionCount, _ref1, _context_maxQuestions, _ref2;
        // Merge context while preserving defaults
        this.interviewContext = {
            ...this.interviewContext,
            ...context,
            // Ensure defaults are set if not provided
            preliminaryCollected: (_ref = (_context_preliminaryCollected = context.preliminaryCollected) !== null && _context_preliminaryCollected !== void 0 ? _context_preliminaryCollected : this.interviewContext.preliminaryCollected) !== null && _ref !== void 0 ? _ref : false,
            currentQuestionCount: (_ref1 = (_context_currentQuestionCount = context.currentQuestionCount) !== null && _context_currentQuestionCount !== void 0 ? _context_currentQuestionCount : this.interviewContext.currentQuestionCount) !== null && _ref1 !== void 0 ? _ref1 : 0,
            maxQuestions: (_ref2 = (_context_maxQuestions = context.maxQuestions) !== null && _context_maxQuestions !== void 0 ? _context_maxQuestions : this.interviewContext.maxQuestions) !== null && _ref2 !== void 0 ? _ref2 : 10
        };
        // Log state transition
        console.log('📋 Interview context updated:', this.interviewContext);
        console.debug('🔄 [STATE_TRANSITION] Interview context changed', {
            from: previousState,
            to: this.interviewContext,
            changes: {
                preliminaryCollected: previousState.preliminaryCollected !== this.interviewContext.preliminaryCollected,
                currentQuestionCount: previousState.currentQuestionCount !== this.interviewContext.currentQuestionCount,
                maxQuestions: previousState.maxQuestions !== this.interviewContext.maxQuestions
            },
            timestamp: new Date().toISOString()
        });
    }
    /**
   * Get system prompt based on interview context
   */ getSystemPrompt() {
        const { type, position, company, difficulty } = this.interviewContext;
        let basePrompt = "You are an experienced AI interviewer conducting a ".concat(type, " interview. Your goal is to create an engaging, realistic interview experience that helps candidates prepare effectively.\n\nCore Interview Principles:\n1. Ask relevant, progressively challenging questions\n2. Provide thoughtful follow-ups based on candidate responses\n3. Maintain a professional yet conversational tone\n4. Show genuine interest in the candidate's experiences\n5. Adapt question difficulty based on their expertise level\n6. Give brief encouraging feedback when appropriate\n7. Keep responses concise (50-80 words) and ask one question at a time\n\n");
        if (position) {
            basePrompt += "Target Position: ".concat(position, "\n");
        }
        if (company) {
            basePrompt += "Company Context: ".concat(company, "\n");
        }
        if (difficulty) {
            basePrompt += "Difficulty Level: ".concat(difficulty, "\n");
        }
        switch(type){
            case 'technical':
                basePrompt += '\nTechnical Interview Focus:\n- Start with foundational concepts, then progress to complex scenarios\n- Ask about specific technologies, algorithms, and system design\n- Explore problem-solving approaches and trade-offs\n- Include practical coding scenarios and architecture discussions\n- Ask "How would you optimize this?" or "What challenges might arise?"\n- Focus on real-world application of technical knowledge';
                break;
            case 'behavioral':
                basePrompt += '\nBehavioral Interview Focus:\n- Use STAR method (Situation, Task, Action, Result) evaluation\n- Ask about leadership, teamwork, conflict resolution, and growth\n- Explore past experiences with specific examples\n- Ask follow-ups like "What would you do differently?" or "What did you learn?"\n- Focus on cultural fit, communication skills, and problem-solving approach\n- Include questions about handling failures and difficult situations';
                break;
            default:
                basePrompt += "\nGeneral Interview Focus:\n- Balance background, experience, motivation, and role fit\n- Ask about career goals, interests, and what excites them about the opportunity\n- Explore their understanding of the role and company\n- Include questions about learning style and professional development\n- Ask about their greatest achievements and challenges";
        }
        basePrompt += '\n\nInterview Style:\n- Be conversational and show active listening\n- Acknowledge good points: "That\'s a great approach" or "Interesting perspective"\n- Ask natural follow-ups that build on their responses\n- Create a comfortable environment that encourages detailed answers';
        return basePrompt;
    }
    /**
   * Start a new interview conversation
   */ async startInterviewConversation() {
        var _stack;
        console.log('🚀 [TRACE] startInterviewConversation called', {
            timestamp: new Date().toISOString(),
            interviewContext: this.interviewContext,
            isInitialized: this.isInitialized,
            callStack: (_stack = new Error().stack) === null || _stack === void 0 ? void 0 : _stack.split('\n').slice(0, 5).join('\n')
        });
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        // Reset conversation history
        this.conversationHistory = [
            {
                role: 'system',
                content: this.getSystemPrompt()
            }
        ];
        const openingMessage = this.getOpeningMessage();
        console.log('📢 [TRACE] Opening message generated', {
            message: openingMessage,
            interviewType: this.interviewContext.type,
            isPreliminaryQuestion: openingMessage.includes('tell me about your current role'),
            timestamp: new Date().toISOString()
        });
        this.conversationHistory.push({
            role: 'assistant',
            content: openingMessage
        });
        return {
            content: openingMessage,
            questionNumber: 1,
            isComplete: false
        };
    }
    /**
   * Get opening message based on interview type
   */ getOpeningMessage() {
        var _stack;
        const { type, position, preliminaryCollected } = this.interviewContext;
        console.log('🎯 [TRACE] getOpeningMessage called', {
            type,
            position,
            preliminaryCollected,
            timestamp: new Date().toISOString(),
            callStack: (_stack = new Error().stack) === null || _stack === void 0 ? void 0 : _stack.split('\n').slice(0, 5).join('\n')
        });
        // Always greet user
        let greeting = "Hello! I'm excited to interview you today. ";
        if (position) {
            greeting += "We'll be discussing the ".concat(position, " position. ");
        }
        // Build opening message dynamically based on preliminaryCollected flag
        if (!preliminaryCollected) {
            // Append the single preliminary request
            return greeting + "Before we dive into the main interview, I'd like to get to know you better. Could you please tell me about your current role, your years of experience, and the main technologies or skills you work with?";
        } else {
            // Immediately ask first domain-specific question
            return greeting + this.generateFirstInterviewQuestion();
        }
    }
    /**
   * Generate the first interview question based on interview type
   */ generateFirstInterviewQuestion() {
        const { type, position, company, difficulty } = this.interviewContext;
        switch(type){
            case 'technical':
                if (difficulty === 'easy') {
                    return "Let's start with some fundamentals. Can you explain the difference between an array and a linked list, and when you would choose one over the other?";
                } else if (difficulty === 'hard') {
                    return "Let's dive into system design. How would you design a distributed caching system that can handle millions of requests per second with sub-millisecond latency?";
                } else {
                    return "To get started, can you walk me through a recent technical challenge you faced and how you approached solving it?";
                }
            case 'behavioral':
                if (company) {
                    return "Tell me about a time when you had to work with a difficult team member. How did you handle the situation and what was the outcome?";
                } else {
                    return "Can you describe a situation where you had to lead a project or initiative? What was your approach and what did you learn from the experience?";
                }
            default:
                if (position) {
                    return "What specifically interests you about this ".concat(position, " role, and how does it align with your career goals?");
                } else {
                    return "What motivated you to pursue this opportunity, and what unique value do you think you can bring to our team?";
                }
        }
    }
    /**
   * Process user response and generate next question or comment
   */ async processUserResponse(userResponse) {
        var _stack;
        console.log('💬 [TRACE] processUserResponse called', {
            userResponse: userResponse.substring(0, 100) + '...',
            historyLength: this.conversationHistory.length,
            preliminaryCollected: this.interviewContext.preliminaryCollected,
            currentQuestionCount: this.interviewContext.currentQuestionCount,
            maxQuestions: this.interviewContext.maxQuestions,
            timestamp: new Date().toISOString(),
            callStack: (_stack = new Error().stack) === null || _stack === void 0 ? void 0 : _stack.split('\n').slice(0, 5).join('\n')
        });
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        // Check if we're still collecting preliminary information
        if (!this.interviewContext.preliminaryCollected) {
            console.debug('🎯 [PRELIMINARY] Processing preliminary response', {
                userResponseLength: userResponse.length,
                timestamp: new Date().toISOString()
            });
            // Process the preliminary response and set flag
            const previousPreliminaryState = this.interviewContext.preliminaryCollected;
            this.interviewContext.preliminaryCollected = true;
            console.debug('🔄 [STATE_TRANSITION] preliminaryCollected: false → true', {
                previousState: previousPreliminaryState,
                newState: true,
                timestamp: new Date().toISOString()
            });
            // Keep currentQuestionCount at 0 since we haven't asked real questions yet
            this.interviewContext.currentQuestionCount = 0;
            // Generate first real interview question
            const firstQuestion = this.generateFirstInterviewQuestion();
            this.conversationHistory.push({
                role: 'assistant',
                content: firstQuestion
            });
            // Increment to 1 for the first real question
            const previousQuestionCount = this.interviewContext.currentQuestionCount;
            this.interviewContext.currentQuestionCount = 1;
            console.debug('🔄 [STATE_TRANSITION] questionNumber: 0 → 1', {
                previousCount: previousQuestionCount,
                newCount: 1,
                isFirstRealQuestion: true,
                timestamp: new Date().toISOString()
            });
            return {
                content: "Thank you for that information! Now let's begin the interview.\n\n".concat(firstQuestion),
                questionNumber: 1,
                isComplete: false,
                followUpSuggestions: this.generateFollowUpSuggestions()
            };
        }
        // Normal interview flow - add user response to conversation history
        this.conversationHistory.push({
            role: 'user',
            content: userResponse
        });
        console.log('📝 [TRACE] User response added to history', {
            historyLength: this.conversationHistory.length,
            timestamp: new Date().toISOString()
        });
        try {
            var _completion_choices__message, _completion_choices_;
            const completion = await this.retryWithBackoff(async ()=>{
                return await this.client.chat.completions.create({
                    model: this.deployment,
                    messages: this.conversationHistory,
                    temperature: 0.7,
                    max_tokens: 200,
                    top_p: 0.9,
                    frequency_penalty: 0.1,
                    presence_penalty: 0.1
                });
            });
            const assistantResponse = ((_completion_choices_ = completion.choices[0]) === null || _completion_choices_ === void 0 ? void 0 : (_completion_choices__message = _completion_choices_.message) === null || _completion_choices__message === void 0 ? void 0 : _completion_choices__message.content) || 'I\'m sorry, I didn\'t catch that. Could you repeat your answer?';
            console.log('🤖 [TRACE] OpenAI response received', {
                response: assistantResponse.substring(0, 100) + '...',
                questionCount: this.interviewContext.currentQuestionCount,
                timestamp: new Date().toISOString()
            });
            // Add assistant response to conversation history
            this.conversationHistory.push({
                role: 'assistant',
                content: assistantResponse
            });
            const previousQuestionCount = this.interviewContext.currentQuestionCount || 0;
            const currentQuestionCount = previousQuestionCount + 1;
            const maxQuestions = this.interviewContext.maxQuestions || 10;
            console.log('📊 [TRACE] Question progression', {
                currentQuestionCount,
                maxQuestions,
                isComplete: currentQuestionCount >= maxQuestions,
                willContinue: currentQuestionCount < maxQuestions,
                timestamp: new Date().toISOString()
            });
            console.debug('🔄 [STATE_TRANSITION] questionNumber: %d → %d', previousQuestionCount, currentQuestionCount, {
                maxQuestions,
                progressPercentage: Math.round(currentQuestionCount / maxQuestions * 100),
                remainingQuestions: Math.max(0, maxQuestions - currentQuestionCount),
                timestamp: new Date().toISOString()
            });
            // Update question count
            this.interviewContext.currentQuestionCount = currentQuestionCount;
            return {
                content: assistantResponse,
                questionNumber: currentQuestionCount,
                isComplete: currentQuestionCount >= maxQuestions,
                followUpSuggestions: this.generateFollowUpSuggestions()
            };
        } catch (error) {
            console.error('❌ Error generating OpenAI response:', error);
            // Provide fallback response for common errors
            if (error.status === 429) {
                const fallbackResponse = this.getFallbackResponse(userResponse);
                this.conversationHistory.push({
                    role: 'assistant',
                    content: fallbackResponse
                });
                const currentQuestionCount = (this.interviewContext.currentQuestionCount || 0) + 1;
                this.interviewContext.currentQuestionCount = currentQuestionCount;
                return {
                    content: fallbackResponse,
                    questionNumber: currentQuestionCount,
                    isComplete: false,
                    followUpSuggestions: this.generateFollowUpSuggestions()
                };
            }
            throw new Error('Failed to generate response');
        }
    }
    /**
   * Retry mechanism with exponential backoff for rate limiting
   */ async retryWithBackoff(operation) {
        let maxRetries = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 3, baseDelay = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1000;
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                return await operation();
            } catch (error) {
                var _error_headers;
                lastError = error;
                // Don't retry on non-retryable errors
                if (error.status && ![
                    429,
                    500,
                    502,
                    503,
                    504
                ].includes(error.status)) {
                    throw error;
                }
                if (attempt === maxRetries) {
                    throw error;
                }
                // Calculate delay with exponential backoff
                const delay = error.status === 429 ? parseInt(((_error_headers = error.headers) === null || _error_headers === void 0 ? void 0 : _error_headers['retry-after']) || '10') * 1000 : baseDelay * Math.pow(2, attempt);
                console.log("⏳ Retrying in ".concat(delay, "ms (attempt ").concat(attempt + 1, "/").concat(maxRetries + 1, ")"));
                await new Promise((resolve)=>setTimeout(resolve, delay));
            }
        }
        throw lastError;
    }
    /**
   * Generate fallback response when AI service is unavailable
   */ getFallbackResponse(userResponse) {
        const { type } = this.interviewContext;
        const fallbackResponses = {
            technical: [
                "That's an interesting approach. Can you tell me more about the challenges you faced?",
                "I see. How would you optimize this solution for better performance?",
                "Good point. What alternative approaches did you consider?"
            ],
            behavioral: [
                "Thank you for sharing that experience. What was the outcome?",
                "That sounds challenging. What did you learn from that situation?",
                "Interesting. How would you handle a similar situation now?"
            ],
            general: [
                "That's great to hear. Can you elaborate on that?",
                "Interesting background. What motivates you in your work?",
                "I appreciate you sharing that. What are you most proud of?"
            ]
        };
        const responses = fallbackResponses[type] || fallbackResponses.general;
        return responses[Math.floor(Math.random() * responses.length)];
    }
    /**
   * Generate follow-up suggestions based on conversation
   */ generateFollowUpSuggestions() {
        const { type } = this.interviewContext;
        switch(type){
            case 'technical':
                return [
                    "Can you explain your thought process?",
                    "What would you do differently?",
                    "How would this scale?"
                ];
            case 'behavioral':
                return [
                    "What was the outcome?",
                    "What did you learn?",
                    "How would you handle it now?"
                ];
            default:
                return [
                    "Can you elaborate on that?",
                    "What was your biggest challenge?",
                    "What motivates you?"
                ];
        }
    }
    /**
   * Generate interview summary and feedback
   */ async generateInterviewSummary() {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        const summaryPrompt = {
            role: 'system',
            content: "Based on the interview conversation, provide a brief summary of the candidate's performance, highlighting:\n1. Key strengths demonstrated\n2. Areas for improvement\n3. Overall assessment\n4. Recommendation\n\nKeep it concise and constructive (under 200 words)."
        };
        try {
            var _completion_choices__message, _completion_choices_;
            const completion = await this.client.chat.completions.create({
                model: this.deployment,
                messages: [
                    ...this.conversationHistory,
                    summaryPrompt
                ],
                temperature: 0.3,
                max_tokens: 300
            });
            return ((_completion_choices_ = completion.choices[0]) === null || _completion_choices_ === void 0 ? void 0 : (_completion_choices__message = _completion_choices_.message) === null || _completion_choices__message === void 0 ? void 0 : _completion_choices__message.content) || 'Unable to generate summary.';
        } catch (error) {
            console.error('❌ Error generating interview summary:', error);
            throw new Error('Failed to generate summary');
        }
    }
    /**
   * Get conversation history
   */ getConversationHistory() {
        return this.conversationHistory.filter((msg)=>msg.role !== 'system');
    }
    /**
   * Clear conversation history
   */ clearConversation() {
        const previousState = {
            historyLength: this.conversationHistory.length,
            questionCount: this.interviewContext.currentQuestionCount,
            preliminaryCollected: this.interviewContext.preliminaryCollected
        };
        this.conversationHistory = [];
        this.interviewContext.currentQuestionCount = 0;
        this.interviewContext.preliminaryCollected = false;
        console.log('🧹 Conversation history cleared');
        console.debug('🔄 [STATE_RESET] Conversation state reset', {
            previousState,
            newState: {
                historyLength: 0,
                questionCount: 0,
                preliminaryCollected: false
            },
            timestamp: new Date().toISOString()
        });
    }
    /**
   * Generate questions based on resume information
   */ async generateQuestions(resumeInfo) {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        const prompt = "Given the following resume information, generate 5 relevant interview questions. Format each question on a new line. Only return the questions, no additional text.\n\nName: ".concat(resumeInfo.name, "\nExperience: ").concat(resumeInfo.experience, "\nEducation: ").concat(resumeInfo.education, "\nSkills: ").concat(resumeInfo.skills);
        try {
            var _completion_choices__message, _completion_choices_;
            const completion = await this.client.chat.completions.create({
                model: this.deployment,
                messages: [
                    {
                        role: 'system',
                        content: prompt
                    }
                ],
                temperature: 0.5,
                max_tokens: 150
            });
            const response = ((_completion_choices_ = completion.choices[0]) === null || _completion_choices_ === void 0 ? void 0 : (_completion_choices__message = _completion_choices_.message) === null || _completion_choices__message === void 0 ? void 0 : _completion_choices__message.content) || '';
            return response.split('\n').map((q)=>q.trim()).filter((q)=>q.length > 0).slice(0, 5);
        } catch (error) {
            console.error('❌ Error generating questions:', error);
            throw new Error('Failed to generate questions');
        }
    }
    /**
   * Tailor resume based on job description using Azure OpenAI
   */ async tailorResume(resumeText, jobDescription) {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        const prompt = "You are an expert resume writer and ATS optimization specialist. Please tailor this resume to better match the following job description for maximum ATS compatibility and relevance.\n\nJOB DESCRIPTION:\n".concat(jobDescription, "\n\nCURRENT RESUME:\n").concat(resumeText, "\n\nPlease provide a tailored version of the resume that:\n1. Uses keywords and phrases directly from the job description\n2. Highlights relevant skills and experiences that match the job requirements\n3. Maintains professional formatting and ATS-friendly structure\n4. Uses strong action verbs and quantifiable achievements\n5. Keeps the same overall length and format structure\n6. Optimizes for Applicant Tracking Systems (ATS)\n7. Ensures keyword density without keyword stuffing\n\nReturn ONLY the tailored resume content with no additional commentary or explanations.");
        try {
            var _completion_choices__message, _completion_choices_;
            const completion = await this.retryWithBackoff(async ()=>{
                return await this.client.chat.completions.create({
                    model: this.deployment,
                    messages: [
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    temperature: 0.3,
                    max_tokens: 2000,
                    top_p: 0.9,
                    frequency_penalty: 0.1,
                    presence_penalty: 0.1
                });
            });
            const tailoredResume = (_completion_choices_ = completion.choices[0]) === null || _completion_choices_ === void 0 ? void 0 : (_completion_choices__message = _completion_choices_.message) === null || _completion_choices__message === void 0 ? void 0 : _completion_choices__message.content;
            if (!tailoredResume) {
                throw new Error('No response generated');
            }
            return tailoredResume;
        } catch (error) {
            console.error('❌ Error tailoring resume:', error);
            throw error;
        }
    }
    /**
   * Check if service is ready
   */ isReady() {
        return this.isInitialized && this.client !== null;
    }
    /**
   * Generate a completion for a given prompt
   */ async generateCompletion(prompt) {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        try {
            var _completion_choices__message, _completion_choices_;
            const completion = await this.createCompletion([
                {
                    role: 'user',
                    content: prompt
                }
            ], {
                temperature: 0.7,
                maxTokens: 1000
            });
            return ((_completion_choices_ = completion.choices[0]) === null || _completion_choices_ === void 0 ? void 0 : (_completion_choices__message = _completion_choices_.message) === null || _completion_choices__message === void 0 ? void 0 : _completion_choices__message.content) || 'Unable to generate completion.';
        } catch (error) {
            console.error('❌ Error generating completion:', error);
            throw new Error('Failed to generate completion');
        }
    }
    /**
   * Create a chat completion with custom parameters
   * Public method for use by adapters
   */ async createCompletion(messages) {
        let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        const { temperature = 0.7, maxTokens = 1500, topP = 0.9, frequencyPenalty = 0.1, presencePenalty = 0.1 // Encourage diverse content
         } = options;
        return await this.retryWithBackoff(async ()=>{
            return await this.client.chat.completions.create({
                model: this.deployment,
                messages,
                temperature,
                max_tokens: maxTokens,
                top_p: topP,
                frequency_penalty: frequencyPenalty,
                presence_penalty: presencePenalty
            });
        });
    }
    /**
   * Dispose of resources
   */ dispose() {
        this.client = null;
        this.isInitialized = false;
        this.conversationHistory = [];
        console.log('🧹 Azure OpenAI Service disposed');
    }
    constructor(){
        this.client = null;
        this.isInitialized = false;
        this.deployment = '';
        this.conversationHistory = [];
        this.interviewContext = {
            type: 'general',
            preliminaryCollected: false,
            currentQuestionCount: 0,
            maxQuestions: 10
        };
    }
}
// Export singleton instance
const azureOpenAIService = new AzureOpenAIService();

;// ./lib/azure-config-browser.ts
/* provided dependency */ var process = __webpack_require__(87358);
// Browser-compatible Azure configuration
// This file only uses environment variables and doesn't import server-only Azure Identity libraries
let cachedSecrets = null;
/**
 * Fetch Azure secrets from environment variables (browser-safe version)
 * This function only uses NEXT_PUBLIC_ environment variables available in the browser
 */ async function azure_config_browser_fetchAzureSecrets() {
    // Return cached secrets if available
    if (cachedSecrets) {
        return cachedSecrets;
    }
    try {
        console.log('🔑 Loading Azure configuration from environment variables...');
        const secrets = {
            speechKey: process.env.NEXT_PUBLIC_SPEECH_KEY || '',
            speechEndpoint: process.env.NEXT_PUBLIC_SPEECH_ENDPOINT || '',
            azureOpenAIKey: process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY || '',
            azureOpenAIEndpoint: process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT || '',
            azureOpenAIDeployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT || 'gpt-4o',
            azureOpenAIGpt35Deployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            azureOpenAIGpt4oDeployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o',
            azureAppConfigConnectionString: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            azureAppConfigEndpoint: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        };
        // Validate that required secrets are available
        if (!secrets.speechKey || !secrets.speechEndpoint) {
            console.warn('⚠️ Azure Speech credentials not available in browser environment');
        }
        if (!secrets.azureOpenAIKey || !secrets.azureOpenAIEndpoint) {
            console.warn('⚠️ Azure OpenAI credentials not available in browser environment');
        }
        if (!secrets.azureAppConfigConnectionString && !secrets.azureAppConfigEndpoint) {
            console.warn('⚠️ Azure App Configuration credentials not available in browser environment');
        }
        cachedSecrets = secrets;
        console.log('✅ Azure configuration loaded from environment variables');
        return cachedSecrets;
    } catch (error) {
        console.error('❌ Failed to load Azure configuration:', error);
        // Return empty secrets as fallback
        const fallbackSecrets = {
            speechKey: '',
            speechEndpoint: '',
            azureOpenAIKey: '',
            azureOpenAIEndpoint: '',
            azureOpenAIDeployment: 'gpt-4o',
            azureOpenAIGpt35Deployment: 'gpt-4o',
            azureOpenAIGpt4oDeployment: 'gpt-4o',
            azureAppConfigConnectionString: undefined,
            azureAppConfigEndpoint: undefined
        };
        cachedSecrets = fallbackSecrets;
        return cachedSecrets;
    }
}
/**
 * Get current Azure configuration (for debugging)
 */ function getAzureConfig() {
    return {
        environment: 'browser',
        hasSecretsCache: !!cachedSecrets,
        configuration: {
            speechKey: !!process.env.NEXT_PUBLIC_SPEECH_KEY,
            speechEndpoint: !!process.env.NEXT_PUBLIC_SPEECH_ENDPOINT,
            azureOpenAIKey: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY,
            azureOpenAIEndpoint: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT,
            azureOpenAIDeployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT,
            azureOpenAIGpt35Deployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT,
            azureOpenAIGpt4oDeployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT,
            azureAppConfigConnectionString: !!process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            azureAppConfigEndpoint: !!process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        },
        deployments: {
            default: process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT,
            gpt35Turbo: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            gpt4o: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o'
        },
        appConfiguration: {
            connectionString: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            endpoint: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        }
    };
}
/**
 * Check if we're running in a browser environment
 */ function isBrowser() {
    return "object" !== 'undefined';
}
/**
 * Clear cached secrets (useful for testing or re-initialization)
 */ function clearCache() {
    cachedSecrets = null;
    console.log('🧹 Azure configuration cache cleared');
}

;// ./lib/services/azure-openai-enhanced.ts
/**
 * Enhanced Azure OpenAI Service with Multi-Deployment Support
 * 
 * This service provides intelligent model selection based on task type:
 * - gpt-35-turbo: Fast, cost-effective for simple tasks (relevancy scoring, basic Q&A)
 * - gpt-4o: Advanced reasoning for complex tasks (cover letters, resume tailoring)
 */ 

class EnhancedAzureOpenAIService {
    /**
   * Initialize the service with multiple deployment clients
   */ async initialize() {
        try {
            this.secrets = await azure_config_browser_fetchAzureSecrets();
            if (!this.secrets.azureOpenAIKey || !this.secrets.azureOpenAIEndpoint) {
                console.warn('⚠️ Azure OpenAI credentials not available');
                return false;
            }
            // Initialize clients for different deployments
            const deployments = [
                {
                    name: 'gpt-4o',
                    deployment: this.secrets.azureOpenAIGpt35Deployment || 'gpt-4o'
                },
                {
                    name: 'gpt-4o',
                    deployment: this.secrets.azureOpenAIGpt4oDeployment || 'gpt-4o'
                },
                {
                    name: 'default',
                    deployment: this.secrets.azureOpenAIDeployment
                }
            ];
            for (const { name, deployment } of deployments){
                if (deployment) {
                    const client = new MigrationOpenAIClient();
                    await client.init(); // Initialize the migration client
                    this.clients.set(name, client);
                    console.log("✅ Azure OpenAI client initialized for ".concat(name, " (").concat(deployment, ")"));
                }
            }
            this.isInitialized = this.clients.size > 0;
            if (this.isInitialized) {
                console.log("✅ Enhanced Azure OpenAI Service initialized with ".concat(this.clients.size, " clients"));
            }
            return this.isInitialized;
        } catch (error) {
            console.error('❌ Failed to initialize Enhanced Azure OpenAI Service:', error);
            return false;
        }
    }
    /**
   * Generate content using the optimal model for the task
   */ async generateContent(prompt, taskType, customOptions) {
        if (!this.isInitialized) {
            throw new Error('Enhanced Azure OpenAI Service not initialized');
        }
        const config = {
            ...this.taskConfigurations[taskType],
            ...customOptions
        };
        const client = this.clients.get(config.deployment) || this.clients.get('default');
        if (!client) {
            throw new Error("No client available for deployment: ".concat(config.deployment));
        }
        console.log("\uD83C\uDFAF Using ".concat(config.deployment, " for ").concat(taskType, " task"));
        const messages = [
            {
                role: 'user',
                content: prompt
            }
        ];
        try {
            var _completion_choices__message, _completion_choices_;
            const completion = await this.retryWithBackoff(async ()=>{
                return await client.chat.completions.create({
                    model: config.deployment,
                    messages,
                    temperature: config.temperature,
                    max_tokens: config.maxTokens,
                    top_p: config.topP || 0.9,
                    frequency_penalty: config.frequencyPenalty || 0.1,
                    presence_penalty: config.presencePenalty || 0.1
                });
            });
            const content = (_completion_choices_ = completion.choices[0]) === null || _completion_choices_ === void 0 ? void 0 : (_completion_choices__message = _completion_choices_.message) === null || _completion_choices__message === void 0 ? void 0 : _completion_choices__message.content;
            if (!content) {
                throw new Error("Empty response from Azure OpenAI (".concat(config.deployment, ")"));
            }
            return content;
        } catch (error) {
            console.error("❌ Error generating content with ".concat(config.deployment, ":"), error);
            throw error;
        }
    }
    /**
   * Generate cover letter using gpt-4o for high quality
   */ async generateCoverLetter(resumeText, jobDescription) {
        const prompt = "You are an expert career coach and professional writer. Please generate a compelling cover letter based on the provided resume and job description.\n\nJOB DESCRIPTION:\n".concat(jobDescription, "\n\nRESUME:\n").concat(resumeText, "\n\nPlease generate a cover letter that:\n1. Is tailored to the specific job description\n2. Highlights the most relevant skills and experiences from the resume\n3. Has a professional and engaging tone\n4. Is well-structured and easy to read\n5. Is approximately 3-4 paragraphs long\n\nReturn ONLY the cover letter content with no additional commentary or explanations.");
        return await this.generateContent(prompt, 'cover-letter');
    }
    /**
   * Calculate relevancy score using gpt-35-turbo for efficiency
   */ async calculateRelevancy(resumeText, jobDescription) {
        const prompt = "You are an expert ATS (Applicant Tracking System) analyzer. Please analyze the relevancy between this resume and job description.\n\nJOB DESCRIPTION:\n".concat(jobDescription, "\n\nRESUME:\n").concat(resumeText, "\n\nAnalyze the match between the resume and job description considering:\n1. Skills alignment (technical and soft skills)\n2. Experience relevance (years and type of experience)\n3. Education and certifications match\n4. Industry experience\n5. Role responsibilities alignment\n6. Keywords and terminology match\n\nReturn ONLY a single number between 0 and 100 representing the percentage match/relevancy score. No explanations or additional text.");
        const response = await this.generateContent(prompt, 'relevancy');
        // Extract number from response
        const scoreMatch = response.trim().match(/\d+/);
        if (!scoreMatch) {
            throw new Error('Could not extract relevancy score from response');
        }
        const score = parseInt(scoreMatch[0], 10);
        return Math.max(0, Math.min(100, score)); // Ensure score is between 0-100
    }
    /**
   * Tailor resume using gpt-4o for quality
   */ async tailorResume(resumeText, jobDescription) {
        const prompt = "You are an expert resume writer and ATS optimization specialist. Please tailor this resume to better match the following job description for maximum ATS compatibility and relevance.\n\nJOB DESCRIPTION:\n".concat(jobDescription, "\n\nCURRENT RESUME:\n").concat(resumeText, "\n\nPlease provide a tailored version of the resume that:\n1. Uses keywords and phrases directly from the job description\n2. Highlights relevant skills and experiences that match the job requirements\n3. Maintains professional formatting and ATS-friendly structure\n4. Uses strong action verbs and quantifiable achievements\n5. Keeps the same overall length and format structure\n6. Optimizes for Applicant Tracking Systems (ATS)\n7. Ensures keyword density without keyword stuffing\n\nReturn ONLY the tailored resume content with no additional commentary or explanations.");
        return await this.generateContent(prompt, 'resume-tailor');
    }
    /**
   * Generate interview questions using gpt-35-turbo for efficiency
   */ async generateQuestions(resumeInfo) {
        const prompt = "You are an experienced interviewer. Based on the following resume information, generate 5 relevant interview questions that would help assess this candidate's qualifications and fit for their field.\n\nRESUME INFORMATION:\nName: ".concat(resumeInfo.name, "\nExperience: ").concat(resumeInfo.experience, "\nEducation: ").concat(resumeInfo.education, "\nSkills: ").concat(resumeInfo.skills, "\n\nGenerate questions that:\n1. Are specific to their experience level and field\n2. Assess both technical and behavioral competencies\n3. Are professional and engaging\n4. Would help determine cultural fit\n5. Allow the candidate to showcase their strengths\n\nFormat: Return exactly 5 questions, each on a new line, numbered 1-5. No additional text or explanations.");
        const response = await this.generateContent(prompt, 'questions');
        // Parse questions from response
        const questions = response.split('\n').map((line)=>line.trim()).filter((line)=>line.length > 0).map((line)=>line.replace(/^\d+\.\s*/, '')) // Remove numbering
        .filter((line)=>line.length > 0).slice(0, 5); // Ensure max 5 questions
        if (questions.length === 0) {
            throw new Error('No questions could be parsed from response');
        }
        return questions;
    }
    /**
   * Retry mechanism with exponential backoff for rate limiting
   */ async retryWithBackoff(operation) {
        let maxRetries = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 3, baseDelay = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1000;
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                return await operation();
            } catch (error) {
                var _error_headers;
                lastError = error;
                // Don't retry on non-retryable errors
                if (error.status && ![
                    429,
                    500,
                    502,
                    503,
                    504
                ].includes(error.status)) {
                    throw error;
                }
                if (attempt === maxRetries) {
                    throw error;
                }
                // Calculate delay with exponential backoff
                const delay = error.status === 429 ? parseInt(((_error_headers = error.headers) === null || _error_headers === void 0 ? void 0 : _error_headers['retry-after']) || '10') * 1000 : baseDelay * Math.pow(2, attempt);
                console.log("⏳ Retrying in ".concat(delay, "ms (attempt ").concat(attempt + 1, "/").concat(maxRetries + 1, ")"));
                await new Promise((resolve)=>setTimeout(resolve, delay));
            }
        }
        throw lastError;
    }
    /**
   * Check if service is ready
   */ isReady() {
        return this.isInitialized && this.clients.size > 0;
    }
    /**
   * Get available deployments
   */ getAvailableDeployments() {
        return Array.from(this.clients.keys());
    }
    /**
   * Dispose of resources
   */ dispose() {
        this.clients.clear();
        this.isInitialized = false;
        console.log('🧹 Enhanced Azure OpenAI Service disposed');
    }
    constructor(){
        this.clients = new Map();
        this.isInitialized = false;
        this.secrets = null;
        // Task-specific configurations optimized for different models
        this.taskConfigurations = {
            // Fast tasks - use gpt-35-turbo for efficiency
            'relevancy': {
                deployment: 'gpt-4o',
                temperature: 0.1,
                maxTokens: 50,
                topP: 0.9,
                frequencyPenalty: 0.0,
                presencePenalty: 0.0
            },
            'questions': {
                deployment: 'gpt-4o',
                temperature: 0.5,
                maxTokens: 300,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            // Complex tasks - use gpt-4o for quality
            'cover-letter': {
                deployment: 'gpt-4o',
                temperature: 0.7,
                maxTokens: 1500,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            'resume-tailor': {
                deployment: 'gpt-4o',
                temperature: 0.3,
                maxTokens: 2000,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            // Interview tasks - use gpt-4o for nuanced conversation
            'interview': {
                deployment: 'gpt-4o',
                temperature: 0.7,
                maxTokens: 200,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            }
        };
    }
}
// Export singleton instance
const enhancedAzureOpenAIService = new EnhancedAzureOpenAIService();

// EXTERNAL MODULE: ./node_modules/@microsoft/applicationinsights-web/dist-es5/AISku.js + 101 modules
var AISku = __webpack_require__(58704);
;// ./lib/utils/retry-with-backoff.ts

class RetryWithBackoff {
    static initialize(instrumentationKey) {
        if (instrumentationKey && "object" !== 'undefined') {
            this.appInsights = new AISku/* AppInsightsSku */.M({
                config: {
                    instrumentationKey,
                    enableAutoRouteTracking: false
                }
            });
            this.appInsights.loadAppInsights();
        }
    }
    /**
   * Execute a function with exponential backoff retry logic
   */ static async execute(fn) {
        let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        const { maxRetries = 3, baseDelay = 1000, maxDelay = 30000, jitter = true, retryCondition = this.defaultRetryCondition, onRetry, userId, action = 'unknown' } = options;
        const startTime = Date.now();
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                const result = await fn();
                // Log success metrics
                if (attempt > 0) {
                    this.logRetrySuccess({
                        attempt: attempt + 1,
                        totalAttempts: attempt + 1,
                        delay: 0,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                }
                return result;
            } catch (error) {
                lastError = error;
                // Check if we should retry
                if (attempt === maxRetries || !retryCondition(error)) {
                    // Log final failure
                    this.logRetryFailure({
                        attempt: attempt + 1,
                        totalAttempts: maxRetries + 1,
                        delay: 0,
                        error,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                    throw error;
                }
                // Calculate delay for next attempt
                const exponentialDelay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
                const delay = jitter ? exponentialDelay + Math.random() * exponentialDelay * 0.1 // Add 10% jitter
                 : exponentialDelay;
                // Log retry attempt
                this.logRetryAttempt({
                    attempt: attempt + 1,
                    totalAttempts: maxRetries + 1,
                    delay,
                    error,
                    userId,
                    action,
                    startTime
                });
                // Execute retry callback if provided
                if (onRetry) {
                    onRetry(error, attempt + 1);
                }
                // Wait before next attempt
                await this.sleep(delay);
            }
        }
        throw lastError;
    }
    /**
   * Default retry condition - retry on network errors, rate limits, and server errors
   */ static defaultRetryCondition(error) {
        var _error_response, _error_message, _error_message1, _error_message2;
        // Network errors
        if (error.code === 'ECONNRESET' || error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
            return true;
        }
        // HTTP status codes that should be retried
        if ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.status) {
            const status = error.response.status;
            return status === 429 || // Rate limit
            status === 502 || // Bad Gateway
            status === 503 || // Service Unavailable
            status === 504; // Gateway Timeout
        }
        // Azure OpenAI specific errors
        if (((_error_message = error.message) === null || _error_message === void 0 ? void 0 : _error_message.includes('rate limit')) || ((_error_message1 = error.message) === null || _error_message1 === void 0 ? void 0 : _error_message1.includes('throttled')) || ((_error_message2 = error.message) === null || _error_message2 === void 0 ? void 0 : _error_message2.includes('quota exceeded'))) {
            return true;
        }
        return false;
    }
    /**
   * Sleep for specified milliseconds
   */ static sleep(ms) {
        return new Promise((resolve)=>setTimeout(resolve, ms));
    }
    /**
   * Log retry attempt
   */ static logRetryAttempt(metrics) {
        var _metrics_error, _metrics_error1, _metrics_error_response, _metrics_error2, _metrics_error3;
        const logData = {
            level: 'warn',
            message: "Retry attempt ".concat(metrics.attempt, "/").concat(metrics.totalAttempts, " for ").concat(metrics.action),
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                delay: metrics.delay,
                error: {
                    message: (_metrics_error = metrics.error) === null || _metrics_error === void 0 ? void 0 : _metrics_error.message,
                    code: (_metrics_error1 = metrics.error) === null || _metrics_error1 === void 0 ? void 0 : _metrics_error1.code,
                    status: (_metrics_error2 = metrics.error) === null || _metrics_error2 === void 0 ? void 0 : (_metrics_error_response = _metrics_error2.response) === null || _metrics_error_response === void 0 ? void 0 : _metrics_error_response.status,
                    name: (_metrics_error3 = metrics.error) === null || _metrics_error3 === void 0 ? void 0 : _metrics_error3.name
                },
                timestamp: new Date().toISOString()
            }
        };
        console.warn('RETRY_ATTEMPT', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 2,
                properties: logData.properties
            });
        }
    }
    /**
   * Log retry success
   */ static logRetrySuccess(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'info',
            message: "Retry succeeded for ".concat(metrics.action, " after ").concat(metrics.attempt, " attempts"),
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                timestamp: new Date().toISOString()
            }
        };
        console.log('RETRY_SUCCESS', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 1,
                properties: logData.properties
            });
            // Track custom metric for retry success
            this.appInsights.trackMetric({
                name: 'RetrySuccess',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
    /**
   * Log retry failure
   */ static logRetryFailure(metrics) {
        var _metrics_error, _metrics_error1, _metrics_error_response, _metrics_error2, _metrics_error3, _metrics_error4;
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'error',
            message: "Retry failed for ".concat(metrics.action, " after ").concat(metrics.attempt, " attempts"),
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                error: {
                    message: (_metrics_error = metrics.error) === null || _metrics_error === void 0 ? void 0 : _metrics_error.message,
                    code: (_metrics_error1 = metrics.error) === null || _metrics_error1 === void 0 ? void 0 : _metrics_error1.code,
                    status: (_metrics_error2 = metrics.error) === null || _metrics_error2 === void 0 ? void 0 : (_metrics_error_response = _metrics_error2.response) === null || _metrics_error_response === void 0 ? void 0 : _metrics_error_response.status,
                    name: (_metrics_error3 = metrics.error) === null || _metrics_error3 === void 0 ? void 0 : _metrics_error3.name,
                    stack: (_metrics_error4 = metrics.error) === null || _metrics_error4 === void 0 ? void 0 : _metrics_error4.stack
                },
                timestamp: new Date().toISOString()
            }
        };
        console.error('RETRY_FAILURE', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackException({
                exception: metrics.error,
                properties: logData.properties,
                severityLevel: 3 // Error
            });
            // Track custom metric for retry failure
            this.appInsights.trackMetric({
                name: 'RetryFailure',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
}
/**
 * Convenience function for common retry scenarios
 */ async function retryWithExponentialBackoff(fn, action, userId, options) {
    return RetryWithBackoff.execute(fn, {
        action,
        userId,
        ...options
    });
}

;// ./lib/ai/azureOpenAI.ts
/**
 * Azure OpenAI Provider Adapter
 * 
 * This adapter wraps Azure OpenAI API to provide a consistent interface
 * for the AI service layer. Reuses the existing AzureOpenAIService for
 * consistent configuration and error handling.
 */ 


class AzureOpenAIAdapter {
    /**
   * Initialize the Azure OpenAI service
   */ async initialize() {
        try {
            // Try enhanced service first, fallback to standard service
            if (this.useEnhancedService) {
                this.isInitialized = await enhancedAzureOpenAIService.initialize();
                if (this.isInitialized) {
                    console.log('✅ Azure OpenAI adapter initialized with enhanced service');
                    return true;
                }
                console.warn('⚠️ Enhanced service failed, falling back to standard service');
                this.useEnhancedService = false;
            }
            // Fallback to standard service
            this.isInitialized = await azureOpenAIService.initialize();
            if (this.isInitialized) {
                console.log('✅ Azure OpenAI adapter initialized with standard service');
            } else {
                console.warn('⚠️ Azure OpenAI adapter failed to initialize');
            }
            return this.isInitialized;
        } catch (error) {
            console.error('❌ Failed to initialize Azure OpenAI adapter:', error);
            return false;
        }
    }
    /**
   * Check if the adapter is ready
   */ isReady() {
        if (this.useEnhancedService) {
            return this.isInitialized && enhancedAzureOpenAIService.isReady();
        }
        return this.isInitialized && azureOpenAIService.isReady();
    }
    /**
   * Generate a cover letter using Azure OpenAI with retry logic
   */ async generateCoverLetter(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await retryWithExponentialBackoff(async ()=>{
            // Use enhanced service if available for optimal model selection
            if (this.useEnhancedService) {
                return await enhancedAzureOpenAIService.generateCoverLetter(resumeText, jobDescription);
            }
            // Fallback to custom implementation
            return await this.generateWithAzureOpenAI(this.getCoverLetterPrompt(resumeText, jobDescription));
        }, 'generate_cover_letter', userId, {
            maxRetries: 3,
            baseDelay: 2000,
            maxDelay: 60000 // 1 minute max delay
        });
    }
    /**
   * Calculate relevancy score between resume and job description with retry logic
   */ async calculateRelevancy(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await retryWithExponentialBackoff(async ()=>{
            // Use enhanced service for efficient gpt-35-turbo scoring
            if (this.useEnhancedService) {
                return await enhancedAzureOpenAIService.calculateRelevancy(resumeText, jobDescription);
            }
            // Fallback implementation
            const prompt = this.getRelevancyPrompt(resumeText, jobDescription);
            const response = await this.generateWithAzureOpenAI(prompt, this.RELEVANCY_TEMPERATURE, this.RELEVANCY_MAX_TOKENS);
            // Extract number from response
            const scoreMatch = response.trim().match(/\d+/);
            if (!scoreMatch) {
                throw new Error('Could not extract relevancy score from response');
            }
            const score = parseInt(scoreMatch[0], 10);
            return Math.max(0, Math.min(100, score)); // Ensure score is between 0-100
        }, 'calculate_relevancy', userId, {
            maxRetries: 2,
            baseDelay: 1000,
            maxDelay: 30000
        });
    }
    /**
   * Tailor resume to match job description with retry logic
   */ async tailorResume(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await retryWithExponentialBackoff(async ()=>{
            // Use enhanced service for optimal gpt-4o quality
            if (this.useEnhancedService) {
                return await enhancedAzureOpenAIService.tailorResume(resumeText, jobDescription);
            }
            // Fallback to standard service
            return await azureOpenAIService.tailorResume(resumeText, jobDescription);
        }, 'tailor_resume', userId, {
            maxRetries: 3,
            baseDelay: 3000,
            maxDelay: 90000 // 1.5 minutes max delay
        });
    }
    /**
   * Generate interview questions based on resume information with retry logic
   */ async generateQuestions(resumeInfo, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await retryWithExponentialBackoff(async ()=>{
            // Use enhanced service for efficient gpt-35-turbo question generation
            if (this.useEnhancedService) {
                return await enhancedAzureOpenAIService.generateQuestions(resumeInfo);
            }
            // Fallback to standard service
            return await azureOpenAIService.generateQuestions(resumeInfo);
        }, 'generate_questions', userId, {
            maxRetries: 2,
            baseDelay: 1500,
            maxDelay: 45000
        });
    }
    /**
   * Generate content using Azure OpenAI with retry logic
   * Uses optimized parameters for consistent high-quality responses
   */ async generateWithAzureOpenAI(prompt) {
        let temperature = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.DEFAULT_TEMPERATURE, maxTokens = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.DEFAULT_MAX_TOKENS;
        const messages = [
            {
                role: 'user',
                content: prompt
            }
        ];
        try {
            var _completion_choices__message, _completion_choices_;
            const completion = await azureOpenAIService.createCompletion(messages, {
                temperature,
                maxTokens,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1 // Encourage diverse content
            });
            const content = (_completion_choices_ = completion.choices[0]) === null || _completion_choices_ === void 0 ? void 0 : (_completion_choices__message = _completion_choices_.message) === null || _completion_choices__message === void 0 ? void 0 : _completion_choices__message.content;
            if (!content) {
                throw new Error('Empty response from Azure OpenAI');
            }
            return content;
        } catch (error) {
            console.error('❌ Error generating content with Azure OpenAI:', error);
            throw error;
        }
    }
    /**
   * Get cover letter generation prompt with optimized structure
   */ getCoverLetterPrompt(resumeText, jobDescription) {
        return "You are an expert career coach and professional writer. Please generate a compelling cover letter based on the provided resume and job description.\n\nJOB DESCRIPTION:\n".concat(jobDescription, "\n\nRESUME:\n").concat(resumeText, "\n\nPlease generate a cover letter that:\n1. Is tailored to the specific job description\n2. Highlights the most relevant skills and experiences from the resume\n3. Has a professional and engaging tone\n4. Is well-structured and easy to read\n5. Is approximately 3-4 paragraphs long\n\nReturn ONLY the cover letter content with no additional commentary or explanations.");
    }
    /**
   * Get relevancy analysis prompt with structured requirements
   */ getRelevancyPrompt(resumeText, jobDescription) {
        return "You are an expert ATS (Applicant Tracking System) analyzer. Please analyze the relevancy between this resume and job description.\n\nJOB DESCRIPTION:\n".concat(jobDescription, "\n\nRESUME:\n").concat(resumeText, "\n\nAnalyze the match between the resume and job description considering:\n1. Skills alignment (technical and soft skills)\n2. Experience relevance (years and type of experience)\n3. Education and certifications match\n4. Industry experience\n5. Role responsibilities alignment\n6. Keywords and terminology match\n\nReturn ONLY a single number between 0 and 100 representing the percentage match/relevancy score. No explanations or additional text.");
    }
    /**
   * Dispose of resources
   */ dispose() {
        // The underlying service manages its own resources
        this.isInitialized = false;
        this.useEnhancedService = true; // Reset for next initialization
        console.log('🧹 Azure OpenAI adapter disposed');
    }
    constructor(){
        this.name = 'Azure OpenAI (Enhanced)';
        this.isInitialized = false;
        this.useEnhancedService = true // Feature flag for enhanced multi-deployment service
        ;
        // Default parameters for optimal Azure OpenAI performance
        this.DEFAULT_TEMPERATURE = 0.7 // Balanced creativity
        ;
        this.DEFAULT_MAX_TOKENS = 1500 // Comprehensive responses
        ;
        this.RELEVANCY_TEMPERATURE = 0.1 // For precise scoring
        ;
        this.RELEVANCY_MAX_TOKENS = 50 // Short numeric response
        ;
    }
}

// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(36680);
;// ./lib/services/mock-interview.service.ts
/**
 * Mock Interview Generator Service
 * 
 * This service generates dynamic mock interviews using Azure OpenAI,
 * creating unique roles, companies, tech stacks, and questions while
 * avoiding duplicates and implementing memoization for efficiency.
 */ 

// Interview types with weighted distribution
const INTERVIEW_TYPES = [
    {
        type: 'Technical',
        weight: 0.33
    },
    {
        type: 'Behavioral',
        weight: 0.33
    },
    {
        type: 'Mixed',
        weight: 0.34
    }
];
// Cache configuration
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
class MockInterviewService {
    /**
   * Initialize the service
   */ async initialize() {
        try {
            this.isInitialized = await this.azureAdapter.initialize();
            if (this.isInitialized) {
                console.log('✅ Mock Interview Service initialized');
            }
            return this.isInitialized;
        } catch (error) {
            console.error('❌ Failed to initialize Mock Interview Service:', error);
            return false;
        }
    }
    /**
   * Generate a unique role and company with Azure OpenAI
   */ async generateUniqueRoleAndCompany(excludeRoles, excludeCompanies) {
        if (!this.isInitialized) {
            throw new Error('Mock Interview Service not initialized');
        }
        // Combine exclusion lists
        const allExcludedRoles = [
            ...this.usedRoles,
            ...excludeRoles || []
        ];
        const allExcludedCompanies = [
            ...this.usedCompanies,
            ...excludeCompanies || []
        ];
        const prompt = 'Generate a unique job interview scenario with the following requirements:\n\n1. Create a realistic job title (NOT generic like "Software Engineer")\n2. Assign an appropriate seniority level (Junior, Mid-level, Senior, Lead, or Principal)\n3. Create a fictitious but realistic company name (must be creative and unique)\n4. Specify the industry sector\n\nIMPORTANT: Avoid these previously used roles: '.concat(allExcludedRoles.join(', ') || 'none', "\nIMPORTANT: Avoid these previously used companies: ").concat(allExcludedCompanies.join(', ') || 'none', '\n\nReturn ONLY a valid JSON object in this exact format:\n{\n  "jobTitle": "Example: Cloud Architecture Specialist",\n  "seniority": "Senior",\n  "company": "Example: TechNova Solutions",\n  "industry": "Example: Financial Technology"\n}');
        try {
            // Generate using Azure OpenAI (via adapter's internal method)
            const response = await this.azureAdapter.generateWithAzureOpenAI(prompt, 0.8, 150 // Max tokens for JSON response
            );
            // Parse the JSON response
            const cleanedResponse = response.replace(/```json\n?|\n?```/g, '').trim();
            const generatedRole = JSON.parse(cleanedResponse);
            // Add to exclusion lists
            this.usedRoles.add(generatedRole.jobTitle);
            this.usedCompanies.add(generatedRole.company);
            // Cache the result
            const cacheKey = "".concat(generatedRole.jobTitle, "-").concat(generatedRole.company);
            this.roleCache.set(cacheKey, {
                data: generatedRole,
                timestamp: Date.now()
            });
            console.log('📋 Generated unique role:', generatedRole);
            return generatedRole;
        } catch (error) {
            console.error('❌ Error generating unique role and company:', error);
            // Fallback to predefined options
            return this.getFallbackRole();
        }
    }
    /**
   * Generate relevant tech stack for a given role
   */ async generateTechStack(role) {
        if (!this.isInitialized) {
            throw new Error('Mock Interview Service not initialized');
        }
        // Check cache first
        const cacheKey = "".concat(role.jobTitle, "-").concat(role.seniority);
        const cached = this.techStackCache.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
            console.log('📦 Using cached tech stack for:', cacheKey);
            return cached.data.technologies;
        }
        const prompt = "Based on this job role, generate a relevant technology stack:\n\nRole: ".concat(role.jobTitle, "\nSeniority: ").concat(role.seniority, "\nCompany: ").concat(role.company, "\nIndustry: ").concat(role.industry, '\n\nGenerate 4-6 specific technologies that would be relevant for this position.\nConsider the seniority level when selecting technologies (e.g., more advanced tools for senior roles).\n\nReturn ONLY a valid JSON object in this exact format:\n{\n  "technologies": ["Tech1", "Tech2", "Tech3", "Tech4"],\n  "primaryFocus": "Brief description of the tech focus area"\n}');
        try {
            const response = await this.azureAdapter.generateWithAzureOpenAI(prompt, 0.5, 150 // Max tokens for JSON response
            );
            // Parse the JSON response
            const cleanedResponse = response.replace(/```json\n?|\n?```/g, '').trim();
            const generatedTech = JSON.parse(cleanedResponse);
            // Cache the result
            this.techStackCache.set(cacheKey, {
                data: generatedTech,
                timestamp: Date.now()
            });
            console.log('🛠️ Generated tech stack:', generatedTech.technologies);
            return generatedTech.technologies;
        } catch (error) {
            console.error('❌ Error generating tech stack:', error);
            // Fallback to common tech stacks based on role
            return this.getFallbackTechStack(role);
        }
    }
    /**
   * Generate interview questions using the existing adapter method
   */ async generateQuestions(role, type, techStack) {
        if (!this.isInitialized) {
            throw new Error('Mock Interview Service not initialized');
        }
        // Create cache key
        const cacheKey = "".concat(role.jobTitle, "-").concat(type, "-").concat(techStack.join(','));
        const cached = this.questionsCache.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
            console.log('📦 Using cached questions for:', cacheKey);
            return cached.data;
        }
        // Create ResumeInfo object for the adapter's generateQuestions method
        const resumeInfo = {
            name: 'Mock Candidate',
            experience: "".concat(role.seniority, " ").concat(role.jobTitle, " with expertise in ").concat(techStack.slice(0, 3).join(', ')),
            education: this.getEducationForSeniority(role.seniority),
            skills: techStack.join(', ')
        };
        try {
            // Use the existing adapter method
            const questions = await this.azureAdapter.generateQuestions(resumeInfo);
            // Cache the result
            this.questionsCache.set(cacheKey, {
                data: questions,
                timestamp: Date.now()
            });
            console.log("❓ Generated ".concat(questions.length, " questions for ").concat(type, " interview"));
            return questions;
        } catch (error) {
            console.error('❌ Error generating questions:', error);
            // Fallback questions based on type
            return this.getFallbackQuestions(type, role);
        }
    }
    /**
   * Main method to create a complete mock interview
   */ async createMockInterview(userId) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        try {
            // Step 1: Generate unique role and company
            const role = await this.generateUniqueRoleAndCompany();
            // Step 2: Generate relevant tech stack
            const techStack = await this.generateTechStack(role);
            // Step 3: Select interview type (weighted random selection)
            const interviewType = this.selectInterviewType();
            // Step 4: Generate questions based on role, type, and tech stack
            const questions = await this.generateQuestions(role, interviewType, techStack);
            // Step 5: Generate unique interview ID
            const interviewId = this.generateInterviewId();
            // Step 6: Get company logo deterministically based on interview ID
            const { logo, company } = (0,utils/* getCompanyLogoForInterview */.L8)(interviewId);
            // Step 7: Create Interview object with company branding
            const interview = {
                id: interviewId,
                userId: userId || 'mock-user',
                jobTitle: role.jobTitle,
                company: company,
                questions: questions,
                finalized: true,
                createdAt: new Date().toISOString(),
                // Legacy properties for backward compatibility
                role: "".concat(role.jobTitle, " at ").concat(company),
                level: role.seniority,
                type: interviewType,
                techstack: techStack,
                companyLogo: logo,
                companyName: company
            };
            console.log('✨ Created mock interview:', {
                id: interview.id,
                role: interview.role,
                type: interview.type,
                questionCount: interview.questions.length
            });
            return interview;
        } catch (error) {
            console.error('❌ Error creating mock interview:', error);
            throw new Error('Failed to create mock interview');
        }
    }
    /**
   * Select interview type based on weighted distribution
   */ selectInterviewType() {
        const random = Math.random();
        let cumulativeWeight = 0;
        for (const { type, weight } of INTERVIEW_TYPES){
            cumulativeWeight += weight;
            if (random <= cumulativeWeight) {
                return type;
            }
        }
        return 'Mixed'; // Default fallback
    }
    /**
   * Generate unique interview ID
   */ generateInterviewId() {
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(2, 9);
        return "mock-".concat(timestamp, "-").concat(random);
    }
    /**
   * Get education level based on seniority
   */ getEducationForSeniority(seniority) {
        const educationMap = {
            'Junior': "Bachelor's degree in Computer Science or related field",
            'Mid-level': "Bachelor's degree with 3-5 years experience",
            'Senior': "Bachelor's/Master's degree with 5+ years experience",
            'Lead': "Advanced degree with 7+ years experience",
            'Principal': "Advanced degree with 10+ years experience"
        };
        return educationMap[seniority] || "Bachelor's degree in relevant field";
    }
    /**
   * Fallback role generation when API fails
   */ getFallbackRole() {
        const fallbackRoles = [
            {
                jobTitle: 'Full Stack Developer',
                seniority: 'Senior',
                company: 'InnovateTech Solutions',
                industry: 'Software Development'
            },
            {
                jobTitle: 'DevOps Engineer',
                seniority: 'Mid-level',
                company: 'CloudScale Systems',
                industry: 'Cloud Infrastructure'
            },
            {
                jobTitle: 'Data Engineer',
                seniority: 'Senior',
                company: 'DataFlow Analytics',
                industry: 'Data Analytics'
            },
            {
                jobTitle: 'Mobile App Developer',
                seniority: 'Mid-level',
                company: 'AppCraft Studios',
                industry: 'Mobile Development'
            },
            {
                jobTitle: 'Machine Learning Engineer',
                seniority: 'Senior',
                company: 'AI Innovations Lab',
                industry: 'Artificial Intelligence'
            }
        ];
        // Select a random fallback role that hasn't been used
        const availableRoles = fallbackRoles.filter((r)=>!this.usedRoles.has(r.jobTitle) && !this.usedCompanies.has(r.company));
        if (availableRoles.length === 0) {
            // If all fallbacks are used, return the first one with modified company
            const role = {
                ...fallbackRoles[0]
            };
            role.company = "".concat(role.company, " ").concat(Date.now() % 1000);
            return role;
        }
        const selected = availableRoles[Math.floor(Math.random() * availableRoles.length)];
        this.usedRoles.add(selected.jobTitle);
        this.usedCompanies.add(selected.company);
        return selected;
    }
    /**
   * Fallback tech stack generation based on role
   */ getFallbackTechStack(role) {
        const techByRole = {
            'Full Stack Developer': [
                'React',
                'Node.js',
                'MongoDB',
                'TypeScript',
                'Docker'
            ],
            'DevOps Engineer': [
                'Kubernetes',
                'Docker',
                'AWS',
                'Terraform',
                'Jenkins'
            ],
            'Data Engineer': [
                'Python',
                'Apache Spark',
                'SQL',
                'Kafka',
                'Airflow'
            ],
            'Mobile App Developer': [
                'React Native',
                'TypeScript',
                'Redux',
                'Firebase',
                'GraphQL'
            ],
            'Machine Learning Engineer': [
                'Python',
                'TensorFlow',
                'PyTorch',
                'Scikit-learn',
                'Docker'
            ],
            'Frontend Developer': [
                'React',
                'TypeScript',
                'Next.js',
                'Tailwind CSS',
                'Jest'
            ],
            'Backend Developer': [
                'Node.js',
                'Express',
                'PostgreSQL',
                'Redis',
                'Docker'
            ],
            'Cloud Architect': [
                'AWS',
                'Terraform',
                'Kubernetes',
                'Python',
                'Ansible'
            ]
        };
        // Find matching tech stack or return generic one
        for (const [roleKey, tech] of Object.entries(techByRole)){
            if (role.jobTitle.toLowerCase().includes(roleKey.toLowerCase())) {
                return tech.slice(0, 5); // Return 5 technologies
            }
        }
        // Generic fallback
        return [
            'JavaScript',
            'Python',
            'Docker',
            'Git',
            'SQL'
        ];
    }
    /**
   * Fallback questions generation
   */ getFallbackQuestions(type, role) {
        const questionsByType = {
            'Technical': [
                "Can you explain your experience with the technologies listed in the ".concat(role.jobTitle, " job description?"),
                'Describe a complex technical problem you solved recently. What was your approach?',
                'How do you ensure code quality and maintainability in your projects?',
                'What is your approach to system design and architecture decisions?',
                'Can you walk me through your debugging process when facing a difficult issue?'
            ],
            'Behavioral': [
                'Tell me about a time when you had to work with a difficult team member.',
                'Describe a situation where you had to meet a tight deadline. How did you manage it?',
                'Give an example of when you had to learn a new technology quickly.',
                'How do you handle constructive criticism and feedback?',
                'Tell me about a project you\'re particularly proud of. What was your role?'
            ],
            'Mixed': [
                "What interests you most about the ".concat(role.jobTitle, " position at ").concat(role.company, "?"),
                'How do you stay updated with the latest technology trends in your field?',
                'Describe your ideal work environment and team structure.',
                'What are your career goals for the next 3-5 years?',
                'How do you balance technical excellence with meeting business deadlines?'
            ]
        };
        return questionsByType[type] || questionsByType['Mixed'];
    }
    /**
   * Clear caches (useful for testing or memory management)
   */ clearCaches() {
        this.roleCache.clear();
        this.techStackCache.clear();
        this.questionsCache.clear();
        this.usedRoles.clear();
        this.usedCompanies.clear();
        console.log('🧹 Mock Interview Service caches cleared');
    }
    /**
   * Clean expired cache entries
   */ cleanExpiredCache() {
        const now = Date.now();
        // Clean role cache
        for (const [key, entry] of this.roleCache.entries()){
            if (now - entry.timestamp > CACHE_DURATION) {
                this.roleCache.delete(key);
            }
        }
        // Clean tech stack cache
        for (const [key, entry] of this.techStackCache.entries()){
            if (now - entry.timestamp > CACHE_DURATION) {
                this.techStackCache.delete(key);
            }
        }
        // Clean questions cache
        for (const [key, entry] of this.questionsCache.entries()){
            if (now - entry.timestamp > CACHE_DURATION) {
                this.questionsCache.delete(key);
            }
        }
        console.log('🧹 Expired cache entries cleaned');
    }
    /**
   * Get cache statistics (useful for monitoring)
   */ getCacheStats() {
        return {
            rolesCached: this.roleCache.size,
            techStacksCached: this.techStackCache.size,
            questionsCached: this.questionsCache.size,
            usedRolesCount: this.usedRoles.size,
            usedCompaniesCount: this.usedCompanies.size
        };
    }
    constructor(){
        this.isInitialized = false;
        // Memoization caches
        this.roleCache = new Map();
        this.techStackCache = new Map();
        this.questionsCache = new Map();
        // Exclusion lists to avoid duplicates
        this.usedRoles = new Set();
        this.usedCompanies = new Set();
        this.azureAdapter = new AzureOpenAIAdapter();
    }
}
// Export singleton instance
const mockInterviewService = new MockInterviewService();
// Export the main creation function for convenience
async function createMockInterview(userId) {
    return mockInterviewService.createMockInterview(userId);
}

;// ./components/CommunityInterviewPage.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





// Removed server-only auth import - using API calls instead




const SUPPORTED_LANGUAGES = [
    {
        value: 'javascript',
        label: 'JavaScript'
    },
    {
        value: 'typescript',
        label: 'TypeScript'
    },
    {
        value: 'python',
        label: 'Python'
    },
    {
        value: 'java',
        label: 'Java'
    },
    {
        value: 'csharp',
        label: 'C#'
    },
    {
        value: 'cpp',
        label: 'C++'
    },
    {
        value: 'go',
        label: 'Go'
    },
    {
        value: 'ruby',
        label: 'Ruby'
    }
];
const CommunityInterviewPage = function() {
    let { interviewId, role, type, techstack, level } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    var _SUPPORTED_LANGUAGES_find, _SUPPORTED_LANGUAGES_find1;
    const router = (0,navigation.useRouter)();
    const [isEditorExpanded, setIsEditorExpanded] = (0,react.useState)(false);
    const [selectedLanguage, setSelectedLanguage] = (0,react.useState)('javascript');
    const [isLanguageDropdownOpen, setIsLanguageDropdownOpen] = (0,react.useState)(false);
    const [user, setUser] = (0,react.useState)(null);
    const [isLoading, setIsLoading] = (0,react.useState)(true);
    const [questions, setQuestions] = (0,react.useState)([]);
    const [questionsLoading, setQuestionsLoading] = (0,react.useState)(false);
    const [questionsError, setQuestionsError] = (0,react.useState)(null);
    // Use SWR hook to fetch community interview data
    const { interview: communityInterview, isLoading: communityLoading, isError: communityError } = useCommunityInterview(interviewId || null);
    (0,react.useEffect)(()=>{
        // Use API call instead of direct service import
        const fetchUser = async ()=>{
            try {
                const response = await fetch('/api/auth/user');
                if (!response.ok) {
                    router.push('/sign-in');
                    return;
                }
                const userData = await response.json();
                if (!userData.user) {
                    router.push('/sign-in');
                    return;
                }
                setUser({
                    id: userData.user.uid || userData.user.id,
                    name: userData.user.name || userData.user.displayName || 'User',
                    email: userData.user.email || ''
                });
            } catch (error) {
                console.error('Error fetching user:', error);
                router.push('/sign-in');
            } finally{
                setIsLoading(false);
            }
        };
        fetchUser();
    }, [
        router
    ]);
    // Generate questions when community interview data is available
    (0,react.useEffect)(()=>{
        const generateQuestions = async ()=>{
            // Skip if we have questions already stored in the community interview
            if ((communityInterview === null || communityInterview === void 0 ? void 0 : communityInterview.questions) && Array.isArray(communityInterview.questions) && communityInterview.questions.length > 0) {
                setQuestions(communityInterview.questions);
                return;
            }
            // Skip if no community interview data or still loading
            if (!communityInterview || communityLoading) {
                return;
            }
            // Use provided props or fallback to community interview data
            const interviewType = type || communityInterview.type || 'Mixed';
            const interviewTechstack = techstack || communityInterview.techstack || [
                'JavaScript'
            ];
            const interviewRole = role || communityInterview.role || 'Software Developer';
            const interviewLevel = level || communityInterview.level || 'Mid-level';
            try {
                setQuestionsLoading(true);
                setQuestionsError(null);
                // Initialize the mock interview service if not already done
                await mockInterviewService.initialize();
                // Create a mock role object for the service
                const mockRole = {
                    jobTitle: interviewRole,
                    seniority: interviewLevel,
                    company: 'Community Interview',
                    industry: 'Technology'
                };
                // Generate questions using the same type and techstack
                const generatedQuestions = await mockInterviewService.generateQuestions(mockRole, interviewType, Array.isArray(interviewTechstack) ? interviewTechstack : [
                    interviewTechstack
                ]);
                setQuestions(generatedQuestions);
                console.log('📝 Generated questions for community interview:', generatedQuestions.length);
            } catch (error) {
                console.error('Error generating questions:', error);
                setQuestionsError('Failed to generate interview questions');
                // Set fallback questions
                setQuestions([
                    'Tell me about yourself and your experience.',
                    'What interests you about this role?',
                    'Describe a challenging project you worked on.',
                    'How do you stay updated with technology trends?',
                    'What are your career goals?'
                ]);
            } finally{
                setQuestionsLoading(false);
            }
        };
        generateQuestions();
    }, [
        communityInterview,
        communityLoading,
        type,
        techstack,
        role,
        level
    ]);
    if (isLoading || interviewId && communityLoading) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {
            overlay: true
        });
    }
    // Handle community interview error
    if (interviewId && communityError) {
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col items-center justify-center min-h-screen",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                    className: "text-xl font-semibold text-red-400 mb-4",
                    children: "Error Loading Community Interview"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                    className: "text-gray-300",
                    children: communityError.message || 'Failed to load interview data'
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                    className: "text-gray-500 mt-2",
                    children: "Please try again or contact support if the issue persists."
                })
            ]
        });
    }
    if (!user) {
        return null; // Redirecting to sign-in
    }
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex flex-col gap-8",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(InterviewHeader/* default */.A, {
                role: role || 'Community Mock',
                techstack: techstack && techstack.length > 0 ? techstack : [
                    'General'
                ],
                type: type || 'Community',
                interviewId: interviewId,
                onToggleEditor: ()=>setIsEditorExpanded(!isEditorExpanded)
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex justify-between items-center mb-6",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                            className: "text-xl font-semibold text-white",
                            children: "Interview Panel"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "space-y-4",
                        children: [
                            questionsLoading && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "flex items-center justify-center py-4",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "text-gray-400",
                                    children: "Generating interview questions..."
                                })
                            }),
                            questionsError && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "flex items-center justify-center py-4",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "text-red-400",
                                    children: [
                                        "Error: ",
                                        questionsError
                                    ]
                                })
                            }),
                            !questionsLoading && questions.length > 0 && /*#__PURE__*/ (0,jsx_runtime.jsx)(Agent/* default */.A, {
                                userName: user.name,
                                userId: user.id,
                                interviewId: interviewId,
                                type: "interview",
                                questions: questions
                            })
                        ]
                    })
                ]
            }),
            isEditorExpanded && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex justify-between items-center mb-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                className: "text-xl font-semibold text-white",
                                children: "Code Editor"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                                        type: "button",
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            setIsLanguageDropdownOpen(!isLanguageDropdownOpen);
                                        },
                                        className: "flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-gray-200 bg-gray-800 border border-gray-600 rounded-lg hover:bg-gray-700 transition-colors",
                                        children: [
                                            ((_SUPPORTED_LANGUAGES_find = SUPPORTED_LANGUAGES.find((lang)=>lang.value === selectedLanguage)) === null || _SUPPORTED_LANGUAGES_find === void 0 ? void 0 : _SUPPORTED_LANGUAGES_find.label) || 'Language',
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(chevron_down/* default */.A, {
                                                className: "w-4 h-4 ml-1"
                                            })
                                        ]
                                    }),
                                    isLanguageDropdownOpen && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "absolute right-0 z-10 mt-1 w-40 origin-top-right rounded-md bg-gray-800 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "py-1",
                                            children: SUPPORTED_LANGUAGES.map((language)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                                    onClick: (e)=>{
                                                        e.stopPropagation();
                                                        setSelectedLanguage(language.value);
                                                        setIsLanguageDropdownOpen(false);
                                                    },
                                                    className: "block w-full text-left px-4 py-2 text-sm ".concat(selectedLanguage === language.value ? 'bg-gray-700 text-white' : 'text-gray-200 hover:bg-gray-700'),
                                                    children: language.label
                                                }, language.value))
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(CodeEditorWrapper/* CodeEditorWrapper */.k, {
                        initialValue: "// Write your ".concat(((_SUPPORTED_LANGUAGES_find1 = SUPPORTED_LANGUAGES.find((lang)=>lang.value === selectedLanguage)) === null || _SUPPORTED_LANGUAGES_find1 === void 0 ? void 0 : _SUPPORTED_LANGUAGES_find1.label) || 'code', " here\n// The interviewer may ask you to solve coding problems\n// Use this editor to write and test your solutions"),
                        language: selectedLanguage,
                        className: "h-[500px] transition-all duration-300",
                        isExpanded: true,
                        onToggleExpand: ()=>setIsEditorExpanded(false)
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_CommunityInterviewPage = (CommunityInterviewPage);

// EXTERNAL MODULE: ./lib/utils/communityInterviewStorage.ts
var communityInterviewStorage = __webpack_require__(60853);
;// ./app/community-mock-interview/interview/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const InterviewPageContent = ()=>{
    const searchParams = (0,navigation.useSearchParams)();
    const [interviewData, setInterviewData] = (0,react.useState)(null);
    const [dataSource, setDataSource] = (0,react.useState)(null);
    // Extract all potential data sources
    const urlInterviewId = (searchParams === null || searchParams === void 0 ? void 0 : searchParams.get('id')) || null;
    const urlRole = (searchParams === null || searchParams === void 0 ? void 0 : searchParams.get('role')) || null;
    const urlType = (searchParams === null || searchParams === void 0 ? void 0 : searchParams.get('type')) || null;
    const urlLevel = (searchParams === null || searchParams === void 0 ? void 0 : searchParams.get('level')) || null;
    const urlTechstack = (0,communityInterviewStorage/* parseTechstack */.uS)((searchParams === null || searchParams === void 0 ? void 0 : searchParams.get('techstack')) || null);
    // Fetch interview data using Firestore lookup (only if we have an ID)
    const { interview, loading: firestoreLoading, error: firestoreError } = (0,useFirestore/* useInterview */.$)(urlInterviewId || '');
    // Data resolution effect
    (0,react.useEffect)(()=>{
        const resolveInterviewData = ()=>{
            // Priority 1: Check if URL has complete data (preferred for direct links)
            if (urlInterviewId && urlRole && urlType) {
                const urlData = {
                    id: urlInterviewId,
                    role: decodeURIComponent(urlRole),
                    type: decodeURIComponent(urlType),
                    techstack: urlTechstack.length > 0 ? urlTechstack : [
                        'General'
                    ],
                    level: urlLevel ? decodeURIComponent(urlLevel) : undefined,
                    timestamp: Date.now()
                };
                setInterviewData(urlData);
                setDataSource('url');
                console.log('✅ Using URL parameters for interview data');
                return;
            }
            // Priority 2: Check localStorage for recently stored data
            const storedData = (0,communityInterviewStorage/* getCommunityInterviewFromStorage */.Sy)();
            if (storedData && (!urlInterviewId || urlInterviewId === storedData.id)) {
                setInterviewData(storedData);
                setDataSource('localStorage');
                console.log('✅ Using localStorage for interview data');
                return;
            }
            // Priority 3: Use Firestore data if available
            if (interview && !firestoreLoading && !firestoreError) {
                const firestoreData = {
                    id: interview.id,
                    role: interview.role || interview.jobTitle || 'Unknown Role',
                    type: interview.type || 'technical',
                    techstack: Array.isArray(interview.techstack) ? interview.techstack : interview.techstack ? [
                        interview.techstack
                    ] : [
                        'General'
                    ],
                    level: interview.level,
                    createdAt: typeof interview.createdAt === 'string' ? interview.createdAt : interview.createdAt.toISOString(),
                    timestamp: Date.now()
                };
                setInterviewData(firestoreData);
                setDataSource('firestore');
                console.log('✅ Using Firestore for interview data');
                return;
            }
            // If we have an ID but no other data sources worked, wait for Firestore
            if (urlInterviewId && firestoreLoading) {
                return; // Still loading
            }
            // No valid data found
            setInterviewData(null);
            setDataSource(null);
        };
        resolveInterviewData();
    }, [
        urlInterviewId,
        urlRole,
        urlType,
        urlLevel,
        urlTechstack,
        interview,
        firestoreLoading,
        firestoreError
    ]);
    // Show loading state
    if (firestoreLoading && !interviewData) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {
            overlay: true
        });
    }
    // Show Firestore error state only if no other data sources are available
    if (firestoreError && !interviewData) {
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col items-center justify-center min-h-screen",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                    className: "text-xl font-semibold text-red-400 mb-4",
                    children: "Error Loading Interview"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                    className: "text-gray-300",
                    children: firestoreError
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                    className: "text-gray-500 mt-2",
                    children: "Please try again or contact support if the issue persists."
                })
            ]
        });
    }
    // Show no interview selected state
    if (!interviewData) {
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "flex flex-col items-center justify-center min-h-screen",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                    className: "text-xl font-semibold text-gray-400 mb-4",
                    children: "No Interview Selected"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                    className: "text-gray-300",
                    children: "Please select an interview from the dashboard to get started."
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                    className: "text-gray-500 mt-2",
                    children: "Make sure the interview link is complete and valid."
                })
            ]
        });
    }
    // Update localStorage with current data for future persistence (if not already from localStorage)
    (0,react.useEffect)(()=>{
        if (interviewData && dataSource !== 'localStorage') {
            (0,communityInterviewStorage/* setCommunityInterviewInStorage */.L7)(interviewData);
        }
    }, [
        interviewData,
        dataSource
    ]);
    // Add debug functions in development
    (0,react.useEffect)(()=>{
        (0,communityInterviewStorage/* addDebugFunctions */.kz)();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
             false && /*#__PURE__*/ 0,
            /*#__PURE__*/ (0,jsx_runtime.jsx)(components_CommunityInterviewPage, {
                interviewId: interviewData.id,
                role: interviewData.role,
                type: interviewData.type,
                techstack: interviewData.techstack,
                level: interviewData.level
            })
        ]
    });
};
const Page = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react.Suspense, {
        fallback: /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {
            overlay: true
        }),
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(InterviewPageContent, {})
    });
};
/* harmony default export */ const page = (Page);


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, [2992,7811,2362,6711,7370,9798,6766,9471,1840,3549,1975,6699,838,7744,6680,607,6551,8441,1684,7358], () => (__webpack_exec__(60322)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);