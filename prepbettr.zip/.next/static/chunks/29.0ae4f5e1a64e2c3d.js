"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[29],{

/***/ 10029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ PdfUploadButtonWrapper)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(56671);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/cloud-upload.js
var cloud_upload = __webpack_require__(42337);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/file-text.js
var file_text = __webpack_require__(57434);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/x.js
var x = __webpack_require__(54416);
// EXTERNAL MODULE: ./components/ui/BanterLoader.tsx
var BanterLoader = __webpack_require__(65061);
// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(36680);
;// ./components/ui/GlowingButton.tsx
/* __next_internal_client_entry_do_not_use__ GlowingButton auto */ 


const GlowingButton = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { children, className, glowClassName, innerClassName, disabled, size = 'md', ...props } = param;
    const sizeClasses = {
        sm: 'h-8 px-3 text-sm',
        md: 'h-12 px-4 text-base',
        lg: 'h-14 px-8 text-lg'
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
        ref: ref,
        className: (0,utils.cn)("relative inline-flex items-center justify-center overflow-hidden rounded-full p-[1px] focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 focus:ring-offset-slate-50 dark:focus:ring-offset-slate-900", disabled && "opacity-50 cursor-not-allowed", className),
        disabled: disabled,
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                className: (0,utils.cn)("absolute inset-[-1000%] animate-[spin_2s_linear_infinite] bg-[conic-gradient(from_90deg_at_50%_50%,#E2CBFF_0%,#393BB2_50%,#E2CBFF_100%)]", disabled && "animate-none opacity-50", glowClassName)
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                className: (0,utils.cn)("inline-flex h-full w-full cursor-pointer items-center justify-center rounded-full bg-slate-950 font-medium text-white backdrop-blur-3xl dark:bg-slate-900", sizeClasses[size], disabled && "cursor-not-allowed", innerClassName),
                children: children
            })
        ]
    });
});
GlowingButton.displayName = 'GlowingButton';


// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs + 3 modules
var AnimatePresence = __webpack_require__(60760);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs + 201 modules
var proxy = __webpack_require__(92236);
// EXTERNAL MODULE: ./node_modules/@rpldy/uploady/lib/esm/index.js + 2 modules
var esm = __webpack_require__(25840);
// EXTERNAL MODULE: ./node_modules/@rpldy/upload-button/lib/esm/index.js + 2 modules
var lib_esm = __webpack_require__(49436);
// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(23274);
// EXTERNAL MODULE: ./firebase/client.ts
var client = __webpack_require__(56171);
// EXTERNAL MODULE: ./components/providers/TelemetryProvider.tsx + 1 modules
var TelemetryProvider = __webpack_require__(85142);
;// ./components/PdfUploadButton.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 











const PdfUploadButton = (param)=>{
    let { onQuestionsGenerated, onUploadStart, onUploadEnd, onResumeReplaced } = param;
    const [file, setFile] = (0,react.useState)(null);
    const [isUploading, setIsUploading] = (0,react.useState)(false);
    const [uploadProgress, setUploadProgress] = (0,react.useState)(0);
    const uploaderRef = (0,react.useRef)(null);
    const { trackResumeUpload, trackUserAction, trackError } = (0,TelemetryProvider/* useTelemetry */.J)();
    // Handle upload start
    (0,esm/* useItemStartListener */.Jg)(async (item)=>{
        const uploadFile = item.file;
        // If there's an existing file, this means we're replacing it
        if (file) {
            console.log('🔄 Replacing existing resume file...');
            onResumeReplaced === null || onResumeReplaced === void 0 ? void 0 : onResumeReplaced();
            // Track resume replacement
            await trackUserAction('resume_upload_replacement', 'resume_processing', {
                oldFileName: file.name,
                newFileName: uploadFile.name,
                oldFileSize: file.size.toString(),
                newFileSize: uploadFile.size.toString()
            });
        }
        setFile(uploadFile);
        setIsUploading(true);
        onUploadStart === null || onUploadStart === void 0 ? void 0 : onUploadStart();
        // Track upload start
        await trackUserAction('resume_upload_start', 'resume_processing', {
            fileName: uploadFile.name,
            fileSize: uploadFile.size.toString(),
            fileType: uploadFile.type,
            isReplacement: (!!file).toString()
        });
    });
    // Handle upload progress
    (0,esm/* useItemProgressListener */.OE)((item)=>{
        setUploadProgress(item.completed);
    });
    // Handle upload errors
    (0,esm/* useItemErrorListener */.Xy)(async (item)=>{
        var _item_uploadResponse_data, _item_uploadResponse;
        setIsUploading(false);
        const error = ((_item_uploadResponse = item.uploadResponse) === null || _item_uploadResponse === void 0 ? void 0 : (_item_uploadResponse_data = _item_uploadResponse.data) === null || _item_uploadResponse_data === void 0 ? void 0 : _item_uploadResponse_data.error) || 'Failed to upload file';
        const errorMessage = typeof error === 'string' ? error : 'An unknown error occurred';
        dist/* toast */.o.error('Upload failed', {
            description: errorMessage
        });
        // Track upload error
        await trackError(new Error(errorMessage), {
            action: 'resume_upload_error',
            fileName: (file === null || file === void 0 ? void 0 : file.name) || 'unknown',
            fileSize: (file === null || file === void 0 ? void 0 : file.size.toString()) || '0',
            uploadProgress: uploadProgress.toString()
        });
        setFile(null);
        setUploadProgress(0);
        onUploadEnd === null || onUploadEnd === void 0 ? void 0 : onUploadEnd();
    });
    // Handle upload abort
    (0,esm/* useItemAbortListener */.NL)(()=>{
        setIsUploading(false);
        setFile(null);
        setUploadProgress(0);
        onUploadEnd === null || onUploadEnd === void 0 ? void 0 : onUploadEnd();
    });
    // Handle successful upload
    (0,esm/* useItemFinalizeListener */.zf)(async (item)=>{
        const endTime = Date.now();
        // Extract start time from item data or use end time as fallback
        const itemStartTime = item.startTime || endTime;
        const processingTime = endTime - itemStartTime;
        try {
            var _item_uploadResponse;
            const response = (_item_uploadResponse = item.uploadResponse) === null || _item_uploadResponse === void 0 ? void 0 : _item_uploadResponse.data;
            if (response === null || response === void 0 ? void 0 : response.success) {
                var _response_data, _response_data1, _response_data_fileInfo, _response_data2, _response_data3;
                const questions = ((_response_data = response.data) === null || _response_data === void 0 ? void 0 : _response_data.interviewQuestions) || [];
                const extractedData = (_response_data1 = response.data) === null || _response_data1 === void 0 ? void 0 : _response_data1.extractedData;
                const fileUrl = ((_response_data2 = response.data) === null || _response_data2 === void 0 ? void 0 : (_response_data_fileInfo = _response_data2.fileInfo) === null || _response_data_fileInfo === void 0 ? void 0 : _response_data_fileInfo.fileUrl) || '';
                const resumeId = ((_response_data3 = response.data) === null || _response_data3 === void 0 ? void 0 : _response_data3.resumeId) || '';
                if (questions.length > 0) {
                    dist/* toast */.o.success('Resume processed successfully!', {
                        description: "Generated ".concat(questions.length, " interview questions")
                    });
                    // Track successful resume upload and processing
                    if (file) {
                        await trackResumeUpload(file.size, file.type, processingTime);
                        await trackUserAction('resume_upload_success', 'resume_processing', {
                            fileName: file.name,
                            questionsGenerated: questions.length.toString(),
                            processingTimeMs: processingTime.toString(),
                            resumeId
                        });
                    }
                    onQuestionsGenerated === null || onQuestionsGenerated === void 0 ? void 0 : onQuestionsGenerated({
                        questions,
                        fileUrl,
                        resumeId,
                        extractedData
                    });
                } else {
                    dist/* toast */.o.warning('Resume uploaded but no questions generated', {
                        description: 'The resume was processed but might not contain enough relevant content for question generation.'
                    });
                    // Track upload with no questions generated
                    await trackUserAction('resume_upload_no_questions', 'resume_processing', {
                        fileName: (file === null || file === void 0 ? void 0 : file.name) || 'unknown',
                        processingTimeMs: processingTime.toString(),
                        resumeId
                    });
                    // Still call the callback with empty questions so UI knows upload succeeded
                    onQuestionsGenerated === null || onQuestionsGenerated === void 0 ? void 0 : onQuestionsGenerated({
                        questions: [],
                        fileUrl,
                        resumeId,
                        extractedData
                    });
                }
            } else {
                throw new Error((response === null || response === void 0 ? void 0 : response.error) || 'Failed to process resume');
            }
        } catch (error) {
            console.error('Error processing PDF:', error);
            const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
            dist/* toast */.o.error('Failed to process PDF', {
                description: errorMessage
            });
            // Track processing error
            await trackError(error instanceof Error ? error : new Error(errorMessage), {
                action: 'resume_processing_error',
                fileName: (file === null || file === void 0 ? void 0 : file.name) || 'unknown',
                processingTimeMs: processingTime.toString()
            });
        } finally{
            setIsUploading(false);
            onUploadEnd === null || onUploadEnd === void 0 ? void 0 : onUploadEnd();
        }
    });
    const removeFile = (0,react.useCallback)((e)=>{
        e.stopPropagation();
        setFile(null);
        setUploadProgress(0);
        setIsUploading(false);
        const uploader = window.RPyldyUploader;
        if (uploader) {
            uploader.abortAll();
        }
    }, []);
    // Custom button component for Uploady
    const CustomUploadButton = (0,lib_esm/* asUploadButton */.If)((param)=>{
        let { onClick, isUploading: isUploadingProp } = param;
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "relative",
            children: [
                isUploading && /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {
                    overlay: true,
                    text: "Uploading and Processing Resume..."
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(GlowingButton, {
                    onClick: onClick,
                    disabled: isUploading || isUploadingProp,
                    size: "sm",
                    className: "w-auto h-10",
                    innerClassName: "".concat(isUploading || isUploadingProp ? 'bg-indigo-600 dark:bg-indigo-700' : 'bg-slate-950 dark:bg-slate-900 hover:bg-slate-800 dark:hover:bg-slate-800'),
                    "aria-label": "Upload resume/CV",
                    title: "Upload resume/CV (PDF)",
                    ref: uploaderRef,
                    children: isUploading || isUploadingProp ? /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {}) : /*#__PURE__*/ (0,jsx_runtime.jsx)(cloud_upload/* default */.A, {
                        className: "w-6 h-6"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(AnimatePresence/* AnimatePresence */.N, {
                    children: file && /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.P.div, {
                        initial: {
                            opacity: 0,
                            scale: 0.95
                        },
                        animate: {
                            opacity: 1,
                            scale: 1
                        },
                        exit: {
                            opacity: 0,
                            scale: 0.95
                        },
                        className: "absolute right-0 z-10 mt-2 w-64 origin-top-right rounded-lg bg-white dark:bg-gray-800 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "p-3",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "flex items-center space-x-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(file_text/* default */.A, {
                                                    className: "w-4 h-4 text-indigo-600 dark:text-indigo-400 flex-shrink-0"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                    className: "text-xs font-medium text-gray-900 dark:text-gray-100 truncate",
                                                    children: file.name
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "flex items-center",
                                            children: isUploading ? /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {}) : /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                                type: "button",
                                                onClick: removeFile,
                                                className: "text-gray-400 hover:text-red-500 transition-colors p-1 -mr-1",
                                                "aria-label": "Remove file",
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(x/* default */.A, {
                                                    className: "w-3.5 h-3.5"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "mt-2 w-full bg-gray-200 rounded-full h-1.5 dark:bg-gray-700",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "h-1.5 rounded-full bg-indigo-500 transition-all duration-300",
                                        style: {
                                            width: "".concat(uploadProgress, "%")
                                        }
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        });
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(CustomUploadButton, {});
};
// Main component with Uploady provider
function PdfUploadButtonWrapper(props) {
    const { user } = (0,AuthContext/* useAuth */.A)();
    const [authHeaders, setAuthHeaders] = (0,react.useState)({
        'Accept': 'application/json',
        'Cache-Control': 'no-cache'
    });
    // Update headers with auth token when user changes
    react.useEffect(()=>{
        const updateAuthHeaders = async ()=>{
            try {
                if (user && client/* auth */.j2 && client/* auth */.j2.currentUser) {
                    const idToken = await client/* auth */.j2.currentUser.getIdToken();
                    setAuthHeaders((prev)=>({
                            ...prev,
                            'Authorization': "Bearer ".concat(idToken)
                        }));
                } else {
                    // Remove auth header if no user
                    setAuthHeaders((prev)=>{
                        const { Authorization, ...rest } = prev;
                        return rest;
                    });
                }
            } catch (error) {
                console.error('Error getting auth token:', error);
            // Continue without auth token - server will handle development mode
            }
        };
        updateAuthHeaders();
    }, [
        user
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(esm/* default */.Ay, {
        destination: {
            url: '/api/resume/upload',
            headers: authHeaders
        },
        accept: "application/pdf",
        multiple: false,
        autoUpload: true,
        inputFieldName: "file",
        fileFilter: (file)=>{
            // Additional client-side validation
            if (typeof file === 'string') {
                return false;
            }
            const isValid = file.type === 'application/pdf';
            if (!isValid) {
                dist/* toast */.o.error('Invalid file type', {
                    description: 'Please upload a PDF file'
                });
            }
            return isValid;
        },
        formatServerResponse: (_response)=>{
            try {
                const response = typeof _response === 'string' ? JSON.parse(_response) : _response;
                return {
                    success: response.success !== false,
                    data: response.data || response,
                    error: response.error
                };
            } catch (e) {
                console.error('Error parsing server response:', e);
                return {
                    success: false,
                    error: 'Invalid server response format',
                    data: {}
                };
            }
        },
        maxGroupSize: 1,
        clearPendingOnAdd: true,
        forceJsonResponse: true,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PdfUploadButton, {
            ...props
        })
    });
}


/***/ }),

/***/ 56171:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   db: () => (/* binding */ db),
/* harmony export */   hJ: () => (/* binding */ googleProvider),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23915);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16203);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(35317);
/* provided dependency */ var process = __webpack_require__(87358);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  true ? window.__NEXT_FIREBASE_API_KEY__ : 0;
    const windowProjectId =  true ? window.__NEXT_FIREBASE_PROJECT_ID__ : 0;
    const windowAuthDomain =  true ? window.__NEXT_FIREBASE_AUTH_DOMAIN__ : 0;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || "".concat(finalProjectId, ".firebaseapp.com");
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (false) {}
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__/* .getApps */ .Dk)();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__/* .initializeApp */ .Wp)(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .getAuth */ .xI)(app);
        db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__/* .getFirestore */ .aU)(app);
        // Initialize Google Auth Provider
        googleProvider = new firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .GoogleAuthProvider */ .HF();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (true) {
                    localStorage.removeItem('auth_token');
                    sessionStorage.removeItem('auth_token');
                    window.location.reload();
                }
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (true) {
    initializeFirebase();
}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});


/***/ }),

/***/ 65061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15933);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44987);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36680);

function _templateObject() {
    const data = (0,_swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__._)([
        '\n  .banter-loader {\n    position: relative;\n    width: 72px;\n    height: 72px;\n    margin: 0 auto;\n  }\n\n  .banter-loader__box {\n    float: left;\n    position: relative;\n    width: 20px;\n    height: 20px;\n    margin-right: 6px;\n  }\n\n  .banter-loader__box:before {\n    content: "";\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 100%;\n    height: 100%;\n    background: #fff;\n  }\n\n  .banter-loader__box:nth-child(3n) {\n    margin-right: 0;\n    margin-bottom: 6px;\n  }\n\n  .banter-loader__box:nth-child(1):before, .banter-loader__box:nth-child(4):before {\n    margin-left: 26px;\n  }\n\n  .banter-loader__box:nth-child(3):before {\n    margin-top: 52px;\n  }\n\n  .banter-loader__box:last-child {\n    margin-bottom: 0;\n  }\n\n  @keyframes moveBox-1 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(1) {\n    animation: moveBox-1 4s infinite;\n  }\n\n  @keyframes moveBox-2 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, 26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(2) {\n    animation: moveBox-2 4s infinite;\n  }\n\n  @keyframes moveBox-3 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(-26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(-26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(3) {\n    animation: moveBox-3 4s infinite;\n  }\n\n  @keyframes moveBox-4 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(4) {\n    animation: moveBox-4 4s infinite;\n  }\n\n  @keyframes moveBox-5 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(5) {\n    animation: moveBox-5 4s infinite;\n  }\n\n  @keyframes moveBox-6 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(6) {\n    animation: moveBox-6 4s infinite;\n  }\n\n  @keyframes moveBox-7 {\n    9.0909090909% {\n      transform: translate(26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(7) {\n    animation: moveBox-7 4s infinite;\n  }\n\n  @keyframes moveBox-8 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(8) {\n    animation: moveBox-8 4s infinite;\n  }\n\n  @keyframes moveBox-9 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-52px, 0);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0);\n    }\n\n    100% {\n      transform: translate(0px, 0);\n    }\n  }\n\n  .banter-loader__box:nth-child(9) {\n    animation: moveBox-9 4s infinite;\n  }\n'
    ]);
    _templateObject = function() {
        return data;
    };
    return data;
}




const Loader = (param)=>{
    let { overlay = false, text, backgroundOpacity = 80, blur = true, className, ariaLabel = 'Loading...' } = param;
    const loaderContent = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(StyledWrapper, {
        className: className,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
                className: "banter-loader",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    })
                ]
            }),
            overlay && text && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("p", {
                className: "text-white text-center mt-4 font-medium",
                "aria-live": "polite",
                children: text
            })
        ]
    });
    if (overlay) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("fixed inset-0 z-50 flex items-center justify-center flex-col", blur && "backdrop-blur-md", "transition-all duration-300"),
            style: {
                backgroundColor: "rgba(0, 0, 0, ".concat(backgroundOpacity / 100, ")"),
                backdropFilter: blur ? 'blur(8px)' : 'none',
                WebkitBackdropFilter: blur ? 'blur(8px)' : 'none'
            },
            role: "dialog",
            "aria-modal": "true",
            "aria-label": ariaLabel,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                className: "relative",
                children: loaderContent
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
        role: "status",
        "aria-label": ariaLabel,
        children: loaderContent
    });
};
const StyledWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Ay.div(_templateObject());
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ })

}]);