"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[4787],{

/***/ 65061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15933);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44987);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36680);

function _templateObject() {
    const data = (0,_swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__._)([
        '\n  .banter-loader {\n    position: relative;\n    width: 72px;\n    height: 72px;\n    margin: 0 auto;\n  }\n\n  .banter-loader__box {\n    float: left;\n    position: relative;\n    width: 20px;\n    height: 20px;\n    margin-right: 6px;\n  }\n\n  .banter-loader__box:before {\n    content: "";\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 100%;\n    height: 100%;\n    background: #fff;\n  }\n\n  .banter-loader__box:nth-child(3n) {\n    margin-right: 0;\n    margin-bottom: 6px;\n  }\n\n  .banter-loader__box:nth-child(1):before, .banter-loader__box:nth-child(4):before {\n    margin-left: 26px;\n  }\n\n  .banter-loader__box:nth-child(3):before {\n    margin-top: 52px;\n  }\n\n  .banter-loader__box:last-child {\n    margin-bottom: 0;\n  }\n\n  @keyframes moveBox-1 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(1) {\n    animation: moveBox-1 4s infinite;\n  }\n\n  @keyframes moveBox-2 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, 26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(2) {\n    animation: moveBox-2 4s infinite;\n  }\n\n  @keyframes moveBox-3 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(-26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(-26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(3) {\n    animation: moveBox-3 4s infinite;\n  }\n\n  @keyframes moveBox-4 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(4) {\n    animation: moveBox-4 4s infinite;\n  }\n\n  @keyframes moveBox-5 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(5) {\n    animation: moveBox-5 4s infinite;\n  }\n\n  @keyframes moveBox-6 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(6) {\n    animation: moveBox-6 4s infinite;\n  }\n\n  @keyframes moveBox-7 {\n    9.0909090909% {\n      transform: translate(26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(7) {\n    animation: moveBox-7 4s infinite;\n  }\n\n  @keyframes moveBox-8 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(8) {\n    animation: moveBox-8 4s infinite;\n  }\n\n  @keyframes moveBox-9 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-52px, 0);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0);\n    }\n\n    100% {\n      transform: translate(0px, 0);\n    }\n  }\n\n  .banter-loader__box:nth-child(9) {\n    animation: moveBox-9 4s infinite;\n  }\n'
    ]);
    _templateObject = function() {
        return data;
    };
    return data;
}




const Loader = (param)=>{
    let { overlay = false, text, backgroundOpacity = 80, blur = true, className, ariaLabel = 'Loading...' } = param;
    const loaderContent = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(StyledWrapper, {
        className: className,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
                className: "banter-loader",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    })
                ]
            }),
            overlay && text && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("p", {
                className: "text-white text-center mt-4 font-medium",
                "aria-live": "polite",
                children: text
            })
        ]
    });
    if (overlay) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("fixed inset-0 z-50 flex items-center justify-center flex-col", blur && "backdrop-blur-md", "transition-all duration-300"),
            style: {
                backgroundColor: "rgba(0, 0, 0, ".concat(backgroundOpacity / 100, ")"),
                backdropFilter: blur ? 'blur(8px)' : 'none',
                WebkitBackdropFilter: blur ? 'blur(8px)' : 'none'
            },
            role: "dialog",
            "aria-modal": "true",
            "aria-label": ariaLabel,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                className: "relative",
                children: loaderContent
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
        role: "status",
        "aria-label": ariaLabel,
        children: loaderContent
    });
};
const StyledWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Ay.div(_templateObject());
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ }),

/***/ 84787:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HomePage)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/client/app-dir/link.js
var app_dir_link = __webpack_require__(6874);
var link_default = /*#__PURE__*/__webpack_require__.n(app_dir_link);
// EXTERNAL MODULE: ./node_modules/next/dist/api/app-dynamic.js
var app_dynamic = __webpack_require__(55028);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(35695);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs + 201 modules
var proxy = __webpack_require__(92236);
;// ./components/ui/spotlight.tsx
/* __next_internal_client_entry_do_not_use__ Spotlight auto */ 


const Spotlight = function() {
    let { gradientFirst = "radial-gradient(68.54% 68.72% at 55.02% 31.46%, hsla(210, 100%, 85%, .08) 0, hsla(210, 100%, 55%, .02) 50%, hsla(210, 100%, 45%, 0) 80%)", gradientSecond = "radial-gradient(50% 50% at 50% 50%, hsla(210, 100%, 85%, .06) 0, hsla(210, 100%, 55%, .02) 80%, transparent 100%)", gradientThird = "radial-gradient(50% 50% at 50% 50%, hsla(210, 100%, 85%, .04) 0, hsla(210, 100%, 45%, .02) 80%, transparent 100%)", translateY = -350, width = 560, height = 1380, smallWidth = 240, duration = 7, xOffset = 100 } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(proxy/* motion */.P.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        transition: {
            duration: 1.5
        },
        className: "pointer-events-none absolute inset-0 h-full w-full",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(proxy/* motion */.P.div, {
                animate: {
                    x: [
                        0,
                        xOffset,
                        0
                    ]
                },
                transition: {
                    duration,
                    repeat: Infinity,
                    repeatType: "reverse",
                    ease: "easeInOut"
                },
                className: "absolute top-0 left-0 w-screen h-screen z-40 pointer-events-none",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        style: {
                            transform: "translateY(".concat(translateY, "px) rotate(-45deg)"),
                            background: gradientFirst,
                            width: "".concat(width, "px"),
                            height: "".concat(height, "px")
                        },
                        className: "absolute top-0 left-0"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        style: {
                            transform: "rotate(-45deg) translate(5%, -50%)",
                            background: gradientSecond,
                            width: "".concat(smallWidth, "px"),
                            height: "".concat(height, "px")
                        },
                        className: "absolute top-0 left-0 origin-top-left"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        style: {
                            transform: "rotate(-45deg) translate(-180%, -70%)",
                            background: gradientThird,
                            width: "".concat(smallWidth, "px"),
                            height: "".concat(height, "px")
                        },
                        className: "absolute top-0 left-0 origin-top-left"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(proxy/* motion */.P.div, {
                animate: {
                    x: [
                        0,
                        -xOffset,
                        0
                    ]
                },
                transition: {
                    duration,
                    repeat: Infinity,
                    repeatType: "reverse",
                    ease: "easeInOut"
                },
                className: "absolute top-0 right-0 w-screen h-screen z-40 pointer-events-none",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        style: {
                            transform: "translateY(".concat(translateY, "px) rotate(45deg)"),
                            background: gradientFirst,
                            width: "".concat(width, "px"),
                            height: "".concat(height, "px")
                        },
                        className: "absolute top-0 right-0"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        style: {
                            transform: "rotate(45deg) translate(-5%, -50%)",
                            background: gradientSecond,
                            width: "".concat(smallWidth, "px"),
                            height: "".concat(height, "px")
                        },
                        className: "absolute top-0 right-0 origin-top-right"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        style: {
                            transform: "rotate(45deg) translate(180%, -70%)",
                            background: gradientThird,
                            width: "".concat(smallWidth, "px"),
                            height: "".concat(height, "px")
                        },
                        className: "absolute top-0 right-0 origin-top-right"
                    })
                ]
            })
        ]
    });
};

// EXTERNAL MODULE: ./components/ui/BanterLoader.tsx
var BanterLoader = __webpack_require__(65061);
// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(36680);
;// ./components/ui/infinite-moving-cards.tsx
/* __next_internal_client_entry_do_not_use__ InfiniteMovingCards auto */ 


const InfiniteMovingCards = (param)=>{
    let { items, direction = "left", speed = "slow", pauseOnHover = true, className } = param;
    const containerRef = (0,react.useRef)(null);
    const scrollerRef = (0,react.useRef)(null);
    const [start, setStart] = (0,react.useState)(false);
    const getDirection = (0,react.useCallback)(()=>{
        if (containerRef.current) {
            if (direction === "left") {
                containerRef.current.style.setProperty("--animation-direction", "forwards");
            } else {
                containerRef.current.style.setProperty("--animation-direction", "reverse");
            }
        }
    }, [
        direction
    ]);
    const getSpeed = (0,react.useCallback)(()=>{
        if (containerRef.current) {
            if (speed === "fast") {
                containerRef.current.style.setProperty("--animation-duration", "20s");
            } else if (speed === "normal") {
                containerRef.current.style.setProperty("--animation-duration", "40s");
            } else {
                containerRef.current.style.setProperty("--animation-duration", "80s");
            }
        }
    }, [
        speed
    ]);
    const addAnimation = (0,react.useCallback)(()=>{
        if (containerRef.current && scrollerRef.current) {
            const scrollerContent = Array.from(scrollerRef.current.children);
            scrollerContent.forEach((item)=>{
                const duplicatedItem = item.cloneNode(true);
                if (scrollerRef.current) {
                    scrollerRef.current.appendChild(duplicatedItem);
                }
            });
            getDirection();
            getSpeed();
            setStart(true);
        }
    }, [
        containerRef,
        scrollerRef,
        getDirection,
        getSpeed
    ]);
    (0,react.useEffect)(()=>{
        addAnimation();
    }, [
        addAnimation
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        ref: containerRef,
        className: (0,utils.cn)("scroller relative z-20 w-full mx-auto overflow-hidden", className, start && "data-[animated=true]"),
        "data-direction": direction,
        "data-speed": speed,
        "data-animated": "true",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("ul", {
            ref: scrollerRef,
            className: (0,utils.cn)("scroller__inner flex min-w-full shrink-0 gap-4 py-4 w-max flex-nowrap", pauseOnHover && "hover:[animation-play-state:paused]"),
            children: items.map((item, idx)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                    className: "w-[350px] max-w-full relative rounded-2xl border border-neutral-200 dark:border-neutral-800 px-8 py-6 md:w-[450px] bg-white dark:bg-black list-none",
                    style: {
                        listStyle: 'none'
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "quote-container",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                "aria-hidden": "true",
                                className: "user-select-none -z-1 pointer-events-none absolute -left-0.5 -top-0.5 h-[calc(100%_+_4px)] w-[calc(100%_+_4px)]"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                className: "relative z-20 text-sm leading-[1.6] text-neutral-700 dark:text-neutral-300 font-normal",
                                children: item.quote
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "relative z-20 mt-6 flex flex-row items-center",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                    className: "flex flex-col gap-1",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                            className: "text-sm leading-[1.6] text-neutral-900 dark:text-white font-normal",
                                            children: item.name
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                            className: "text-sm leading-[1.6] text-neutral-500 dark:text-neutral-400 font-normal",
                                            children: item.title
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }, item.name + idx))
        })
    });
}; // Add the following CSS to your global CSS file or a CSS module
 // .scroller {
 //   --animation-duration: 40s;
 //   --animation-direction: forwards;
 // }
 // .scroller[data-animated="true"] {
 //   overflow: hidden;
 //   -webkit-mask: linear-gradient(
 //     90deg,
 //     transparent,
 //     white 20%,
 //     white 80%,
 //     transparent
 //   );
 //   mask: linear-gradient(90deg, transparent, white 20%, white 80%, transparent);
 // }
 // .scroller[data-animated="true"] .scroller__inner {
 //   width: max-content;
 //   flex-wrap: nowrap;
 //   animation: scroll var(--animation-duration, 40s) var(--animation-direction, forwards) linear infinite;
 // }
 // @keyframes scroll {
 //   to {
 //     transform: translate(calc(-50% - 0.5rem));
 //   }
 // }

;// ./components/ui/testimonials-section.tsx
/* __next_internal_client_entry_do_not_use__ TestimonialsSection auto */ 


function TestimonialsSection() {
    const [isMounted, setIsMounted] = (0,react.useState)(false);
    (0,react.useEffect)(()=>{
        setIsMounted(true);
    }, []);
    if (!isMounted) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
            id: "testimonials",
            className: "relative z-10 py-20 bg-white dark:bg-black",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "container mx-auto px-4",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "text-center py-12 px-4",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                            className: "text-4xl md:text-5xl font-medium text-gray-900 dark:text-white mb-4",
                            children: "Don't just take our word for it"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                            className: "text-xl text-gray-600 dark:text-gray-300",
                            children: "Join thousands of candidates who aced their interviews"
                        })
                    ]
                })
            })
        });
    }
    const testimonials = [
        {
            quote: "PrepBettr completely transformed my interview preparation. The AI feedback was spot on and helped me land my dream job at Google!",
            name: "Sarah Johnson",
            title: "Software Engineer at Google"
        },
        {
            quote: "I was struggling with technical interviews, but after using PrepBettr for just two weeks, I aced 5 out of 6 interviews. Highly recommended!",
            name: "Michael Chen",
            title: "Full Stack Developer"
        },
        {
            quote: "The behavioral interview practice was a game-changer for me. The AI picked up on things I didn't even realize I was doing.",
            name: "Emily Rodriguez",
            title: "Product Manager"
        },
        {
            quote: "As someone who gets nervous during interviews, the realistic practice sessions helped build my confidence tremendously.",
            name: "David Kim",
            title: "Data Scientist"
        },
        {
            quote: "Worth every penny! The system design practice alone was worth the subscription cost.",
            name: "Alex Thompson",
            title: "Senior Software Engineer at Amazon"
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
        id: "testimonials",
        className: "py-20 bg-white dark:bg-black",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "container mx-auto px-4 overflow-visible",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "text-center py-12 px-4",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                            className: "text-3xl lg:text-5xl lg:leading-tight max-w-5xl mx-auto text-center tracking-tight font-medium text-black dark:text-white mb-4",
                            children: "Dont just take our word for it"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                            className: "text-xl text-gray-600 dark:text-gray-300",
                            children: "Join thousands of candidates who aced their interviews"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "relative mt-8",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(InfiniteMovingCards, {
                        items: testimonials,
                        direction: "right",
                        speed: "normal",
                        pauseOnHover: true,
                        className: "py-8"
                    })
                })
            ]
        })
    });
}

;// ./components/ui/text-hover-effect.tsx
/* __next_internal_client_entry_do_not_use__ TextHoverEffect auto */ 


const TextHoverEffect = (param)=>{
    let { text, duration } = param;
    const svgRef = (0,react.useRef)(null);
    const [cursor, setCursor] = (0,react.useState)({
        x: 0,
        y: 0
    });
    const [hovered, setHovered] = (0,react.useState)(false);
    const [maskPosition, setMaskPosition] = (0,react.useState)({
        cx: "50%",
        cy: "50%"
    });
    (0,react.useEffect)(()=>{
        if (svgRef.current && cursor.x !== null && cursor.y !== null) {
            const svgRect = svgRef.current.getBoundingClientRect();
            const cxPercentage = (cursor.x - svgRect.left) / svgRect.width * 100;
            const cyPercentage = (cursor.y - svgRect.top) / svgRect.height * 100;
            setMaskPosition({
                cx: "".concat(cxPercentage, "%"),
                cy: "".concat(cyPercentage, "%")
            });
        }
    }, [
        cursor
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
        ref: svgRef,
        width: "100%",
        height: "100%",
        viewBox: "0 0 400 100",
        xmlns: "http://www.w3.org/2000/svg",
        onMouseEnter: ()=>setHovered(true),
        onMouseLeave: ()=>setHovered(false),
        onMouseMove: (e)=>setCursor({
                x: e.clientX,
                y: e.clientY
            }),
        className: "select-none",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("defs", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("linearGradient", {
                        id: "textGradient",
                        gradientUnits: "userSpaceOnUse",
                        cx: "50%",
                        cy: "50%",
                        r: "25%",
                        children: hovered && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("stop", {
                                    offset: "0%",
                                    stopColor: "#eab308"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("stop", {
                                    offset: "25%",
                                    stopColor: "#ef4444"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("stop", {
                                    offset: "50%",
                                    stopColor: "#3b82f6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("stop", {
                                    offset: "75%",
                                    stopColor: "#06b6d4"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("stop", {
                                    offset: "100%",
                                    stopColor: "#8b5cf6"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(proxy/* motion */.P.radialGradient, {
                        id: "revealMask",
                        gradientUnits: "userSpaceOnUse",
                        r: "20%",
                        initial: {
                            cx: "50%",
                            cy: "50%"
                        },
                        animate: maskPosition,
                        transition: {
                            duration: duration !== null && duration !== void 0 ? duration : 0,
                            ease: "easeOut"
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("stop", {
                                offset: "0%",
                                stopColor: "white"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("stop", {
                                offset: "100%",
                                stopColor: "black"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("mask", {
                        id: "textMask",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                            x: "0",
                            y: "0",
                            width: "100%",
                            height: "100%",
                            fill: "url(#revealMask)"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("text", {
                x: "50%",
                y: "50%",
                textAnchor: "middle",
                dominantBaseline: "middle",
                strokeWidth: "0.3",
                className: "fill-transparent stroke-neutral-200 font-[helvetica] text-7xl font-bold dark:stroke-neutral-800",
                style: {
                    opacity: hovered ? 0.7 : 0
                },
                children: text
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.P.text, {
                x: "50%",
                y: "50%",
                textAnchor: "middle",
                dominantBaseline: "middle",
                strokeWidth: "0.3",
                className: "fill-transparent stroke-neutral-200 font-[helvetica] text-7xl font-bold dark:stroke-neutral-800",
                initial: {
                    strokeDashoffset: 1000,
                    strokeDasharray: 1000
                },
                animate: {
                    strokeDashoffset: 0,
                    strokeDasharray: 1000
                },
                transition: {
                    duration: 4,
                    ease: "easeInOut"
                },
                children: text
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("text", {
                x: "50%",
                y: "50%",
                textAnchor: "middle",
                dominantBaseline: "middle",
                stroke: "url(#textGradient)",
                strokeWidth: "0.3",
                mask: "url(#textMask)",
                className: "fill-transparent font-[helvetica] text-7xl font-bold",
                children: text
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconTerminal2.mjs
var IconTerminal2 = __webpack_require__(76489);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconBrain.mjs
var IconBrain = __webpack_require__(20375);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconWorldSearch.mjs
var IconWorldSearch = __webpack_require__(78667);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconRouteAltLeft.mjs
var IconRouteAltLeft = __webpack_require__(26052);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconEaseInOut.mjs
var IconEaseInOut = __webpack_require__(12654);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconAdjustmentsBolt.mjs
var IconAdjustmentsBolt = __webpack_require__(52602);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconCurrencyDollar.mjs
var IconCurrencyDollar = __webpack_require__(87348);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconHeart.mjs
var IconHeart = __webpack_require__(98375);
;// ./components/ui/features-section.tsx
/* __next_internal_client_entry_do_not_use__ FeaturesSection auto */ 



function FeaturesSection() {
    const features = [
        {
            title: "AI-Powered Interviews",
            description: "Practice with our advanced AI that simulates real interview scenarios across various domains.",
            icon: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconTerminal2/* default */.A, {
                className: "w-6 h-6"
            })
        },
        {
            title: "Resume Optimizer",
            description: "AI tailors your resume to match job descriptions, boosting relevance and visibility.",
            icon: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconBrain/* default */.A, {
                className: "w-6 h-6"
            })
        },
        {
            title: "Smart Apply",
            description: "Automatically apply to relevant jobs using your tailored resume and preferences.",
            icon: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconWorldSearch/* default */.A, {
                className: "w-6 h-6"
            })
        },
        {
            title: "Multiple Domains",
            description: "Covering technical, behavioral, and system design interviews.",
            icon: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconRouteAltLeft/* default */.A, {
                className: "w-6 h-6"
            })
        },
        {
            title: "Instant Feedback",
            description: "Get detailed analysis of your answers, including suggestions for improvement.",
            icon: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconEaseInOut/* default */.A, {
                className: "w-6 h-6"
            })
        },
        {
            title: "Progress Tracking",
            description: "Monitor your improvement with detailed analytics and insights.",
            icon: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconAdjustmentsBolt/* default */.A, {
                className: "w-6 h-6"
            })
        },
        {
            title: "Affordable Pricing",
            description: "High-quality interview preparation at a fraction of the cost of human coaches.",
            icon: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconCurrencyDollar/* default */.A, {
                className: "w-6 h-6"
            })
        },
        {
            title: "And much more",
            description: "Join thousands of successful candidates who aced their interviews with us.",
            icon: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconHeart/* default */.A, {
                className: "w-6 h-6"
            })
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
        id: "features",
        className: "pt-6 pb-20 bg-white dark:bg-black",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            id: "features",
            className: "container mx-auto px-6",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "max-w-4xl mx-auto text-center mb-16 px-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("h2", {
                            className: "text-3xl lg:text-5xl lg:leading-tight max-w-5xl mx-auto text-center tracking-tight font-medium text-black dark:text-white mb-6 flex flex-wrap justify-center items-baseline gap-2",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    children: "Why Choose"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(TextHoverEffect, {
                                    text: "PrepBettr",
                                    className: "text-transparent bg-gradient-to-b from-neutral-900 to-neutral-600 dark:from-neutral-100 dark:to-neutral-300 text-sm md:text-base relative top-0.5 scale-50 origin-left px-1"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                            className: "text-lg text-neutral-600 dark:text-neutral-300",
                            children: "Everything you need to ace your next interview in one place"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 relative z-10",
                    children: features.map((feature, index)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(Feature, {
                            ...feature,
                            index: index
                        }, feature.title))
                })
            ]
        })
    });
}
const Feature = (param)=>{
    let { title, description, icon, index } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: (0,utils.cn)("flex flex-col lg:border-r py-10 relative group/feature dark:border-neutral-800", (index === 0 || index === 4) && "lg:border-l dark:border-neutral-800", index < 4 && "lg:border-b dark:border-neutral-800"),
        children: [
            index < 4 && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "opacity-0 group-hover/feature:opacity-100 transition duration-200 absolute inset-0 h-full w-full bg-gradient-to-t from-neutral-100 dark:from-neutral-800 to-transparent pointer-events-none"
            }),
            index >= 4 && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "opacity-0 group-hover/feature:opacity-100 transition duration-200 absolute inset-0 h-full w-full bg-gradient-to-b from-neutral-100 dark:from-neutral-800 to-transparent pointer-events-none"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "mb-4 relative z-10 px-10 text-neutral-600 dark:text-neutral-400",
                children: icon
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "text-lg font-bold mb-2 relative z-10 px-10",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "absolute left-0 inset-y-0 h-6 group-hover/feature:h-8 w-1 rounded-tr-full rounded-br-full bg-neutral-300 dark:bg-neutral-700 group-hover/feature:bg-blue-500 transition-all duration-200 origin-center"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                        className: "group-hover/feature:translate-x-2 transition duration-200 inline-block text-neutral-800 dark:text-neutral-100",
                        children: title
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                className: "text-sm text-neutral-600 dark:text-neutral-300 max-w-xs relative z-10 px-10",
                children: description
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/cobe/dist/index.esm.js + 1 modules
var index_esm = __webpack_require__(75214);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconBrandYoutubeFilled.mjs
var IconBrandYoutubeFilled = __webpack_require__(57981);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/components/Timeline/Timeline.mjs + 5 modules
var Timeline = __webpack_require__(10414);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/components/Text/Text.mjs + 2 modules
var Text = __webpack_require__(58328);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconUpload.mjs
var IconUpload = __webpack_require__(38280);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconQuestionMark.mjs
var IconQuestionMark = __webpack_require__(71604);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconBulb.mjs
var IconBulb = __webpack_require__(28614);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconMessageDots.mjs
var IconMessageDots = __webpack_require__(45066);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconAnalyze.mjs
var IconAnalyze = __webpack_require__(15711);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconTarget.mjs
var IconTarget = __webpack_require__(92224);
// EXTERNAL MODULE: ./node_modules/@tabler/icons-react/dist/esm/icons/IconTrophy.mjs
var IconTrophy = __webpack_require__(89685);
// EXTERNAL MODULE: ./node_modules/next-themes/dist/index.mjs
var dist = __webpack_require__(51362);
;// ./components/ui/TimelineCompact.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function TimelineCompact() {
    const { theme, resolvedTheme } = (0,dist/* useTheme */.D)();
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "w-full h-full flex items-center justify-center p-4",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(Timeline/* Timeline */.K, {
            active: 7,
            bulletSize: 32,
            lineWidth: 3,
            radius: "lg",
            color: "dark",
            classNames: {
                root: 'w-full max-w-md',
                item: 'mb-2 last:mb-0',
                itemTitle: 'text-sm md:text-base font-bold text-neutral-900 dark:text-white mb-1 tracking-tight',
                itemBullet: '!bg-black !border !border-white [&>*]:!bg-black',
                itemBody: 'text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed font-normal'
            },
            styles: {
                itemBullet: {
                    backgroundColor: '#000000 !important',
                    border: '1px solid white !important',
                    borderRadius: '50% !important'
                }
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(Timeline/* Timeline */.K.Item, {
                    title: "Upload Your Resume",
                    bullet: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconUpload/* default */.A, {
                        size: 16,
                        color: "white"
                    }),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Text/* Text */.E, {
                        className: "text-xs text-neutral-500 dark:text-neutral-400",
                        children: "Upload your resume and let our AI analyze your experience"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(Timeline/* Timeline */.K.Item, {
                    title: "AI Question Generation",
                    bullet: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconQuestionMark/* default */.A, {
                        size: 16,
                        color: "white"
                    }),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Text/* Text */.E, {
                        className: "text-xs text-neutral-500 dark:text-neutral-400",
                        children: "Get personalized questions based on your target role"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(Timeline/* Timeline */.K.Item, {
                    title: "Practice Interview",
                    bullet: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconBulb/* default */.A, {
                        size: 16,
                        color: "white"
                    }),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Text/* Text */.E, {
                        className: "text-xs text-neutral-500 dark:text-neutral-400",
                        children: "Practice with voice or text-based mock interviews"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(Timeline/* Timeline */.K.Item, {
                    title: "Real-time Feedback",
                    bullet: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconMessageDots/* default */.A, {
                        size: 16,
                        color: "white"
                    }),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Text/* Text */.E, {
                        className: "text-xs text-neutral-500 dark:text-neutral-400",
                        children: "Receive instant AI-powered feedback and suggestions"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(Timeline/* Timeline */.K.Item, {
                    title: "Performance Analytics",
                    bullet: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconAnalyze/* default */.A, {
                        size: 16,
                        color: "white"
                    }),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Text/* Text */.E, {
                        className: "text-xs text-neutral-500 dark:text-neutral-400",
                        children: "Track your progress with detailed analytics"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(Timeline/* Timeline */.K.Item, {
                    title: "Skill Improvement",
                    bullet: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconTarget/* default */.A, {
                        size: 16,
                        color: "white"
                    }),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Text/* Text */.E, {
                        className: "text-xs text-neutral-500 dark:text-neutral-400",
                        children: "Focus on weak areas with targeted practice"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(Timeline/* Timeline */.K.Item, {
                    title: "Land Your Dream Job",
                    bullet: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconTrophy/* default */.A, {
                        size: 16,
                        color: "white"
                    }),
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Text/* Text */.E, {
                        className: "text-xs text-neutral-500 dark:text-neutral-400",
                        children: "Apply with confidence and ace your interviews"
                    })
                })
            ]
        })
    });
}

;// ./components/ui/bento-grid-features.tsx
/* __next_internal_client_entry_do_not_use__ FeaturesSectionDemo,SkeletonOne,SkeletonThree,SkeletonTwo,SkeletonFour,Globe,BentoGridFeatures auto */ 






function FeaturesSectionDemo() {
    const features = [
        {
            title: "Hack job hunting",
            description: "Manage your entire application pipeline with a single click.",
            skeleton: /*#__PURE__*/ (0,jsx_runtime.jsx)(SkeletonOne, {}),
            className: "col-span-1 lg:col-span-4 border-b lg:border-r dark:border-neutral-800"
        },
        {
            title: "Mock interviews",
            description: "Practice with AI-generated questions tailored to your target role and get instant feedback.",
            skeleton: /*#__PURE__*/ (0,jsx_runtime.jsx)(SkeletonTwo, {}),
            className: "border-b col-span-1 lg:col-span-2 dark:border-neutral-800"
        },
        {
            title: "Watch our AI on YouTube",
            description: "Learn how to land your next role in just 30* days",
            skeleton: /*#__PURE__*/ (0,jsx_runtime.jsx)(SkeletonThree, {}),
            className: "col-span-1 lg:col-span-3 lg:border-r  dark:border-neutral-800"
        },
        {
            title: "Used by Learners Everywhere",
            description: "Join thousands of users who trust PrepBettr to advance their careers.",
            skeleton: /*#__PURE__*/ (0,jsx_runtime.jsx)(SkeletonFour, {}),
            className: "col-span-1 lg:col-span-3 border-b lg:border-none"
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "relative z-20 py-10 lg:py-40 max-w-7xl mx-auto bg-black",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "px-8",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h4", {
                        className: "text-3xl lg:text-5xl lg:leading-tight max-w-5xl mx-auto text-center tracking-tight font-medium text-black dark:text-white",
                        children: "Packed with everything you need"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                        className: "text-sm lg:text-base  max-w-2xl  my-4 mx-auto text-neutral-500 text-center font-normal dark:text-neutral-300",
                        children: "From ATS Resume Optimizer, Cover Letter Generator, Auto-Apply and Smart Tracker, Everything you need to master your job application process"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "relative ",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grid grid-cols-1 lg:grid-cols-6 mt-12 xl:border rounded-md dark:border-neutral-800",
                    children: features.map((feature)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)(FeatureCard, {
                            className: feature.className,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(FeatureTitle, {
                                    children: feature.title
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(FeatureDescription, {
                                    children: feature.description
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: " h-full w-full",
                                    children: feature.skeleton
                                })
                            ]
                        }, feature.title))
                })
            })
        ]
    });
}
const FeatureCard = (param)=>{
    let { children, className } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: (0,utils.cn)("p-4 sm:p-8 relative overflow-hidden", className),
        children: children
    });
};
const FeatureTitle = (param)=>{
    let { children } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
        className: " max-w-5xl mx-auto text-left tracking-tight text-black dark:text-white text-xl md:text-2xl md:leading-snug",
        children: children
    });
};
const FeatureDescription = (param)=>{
    let { children } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
        className: (0,utils.cn)("text-sm md:text-base  max-w-4xl text-left mx-auto", "text-neutral-500 text-center font-normal dark:text-neutral-300", "text-left max-w-sm mx-0 md:text-sm my-2"),
        children: children
    });
};
const SkeletonOne = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "relative flex py-8 px-2 gap-10 h-full",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-full  p-5  mx-auto bg-transparent shadow-2xl group h-full",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "flex flex-1 w-full h-full flex-col space-y-2  ",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        src: "/ProductMockup2.png",
                        alt: "header",
                        width: 800,
                        height: 800,
                        className: "h-full w-full aspect-square object-cover object-left-top rounded-sm"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "absolute bottom-0 z-40 inset-x-0 h-60 bg-gradient-to-t from-white dark:from-black via-white dark:via-black to-transparent w-full pointer-events-none"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "absolute top-0 z-40 inset-x-0 h-60 bg-gradient-to-b from-white dark:from-black via-transparent to-transparent w-full pointer-events-none"
            })
        ]
    });
};
const SkeletonThree = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
        href: "https://www.youtube.com/watch?v=RPa3_AD1_Vs",
        target: "__blank",
        className: "relative flex gap-10  h-full group/image",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "w-full  mx-auto bg-transparent dark:bg-transparent group h-full",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex flex-1 w-full h-full flex-col space-y-2  relative",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(IconBrandYoutubeFilled/* default */.A, {
                        className: "h-20 w-20 absolute z-10 inset-0 text-red-500 m-auto "
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        src: "/YTThumbnail.png",
                        alt: "YouTube video thumbnail",
                        width: 800,
                        height: 800,
                        className: "h-full w-full aspect-square object-cover object-center rounded-sm blur-none group-hover/image:blur-md transition-all duration-200"
                    })
                ]
            })
        })
    });
};
const SkeletonTwo = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "relative flex flex-col items-center justify-center h-full w-full",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TimelineCompact, {})
    });
};
const SkeletonFour = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "h-60 md:h-60  flex flex-col items-center justify-center relative bg-transparent dark:bg-transparent mt-10",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Globe, {
            className: "absolute left-1/2 transform -translate-x-1/2 translate-y-32"
        })
    });
};
const Globe = (param)=>{
    let { className } = param;
    const canvasRef = (0,react.useRef)(null);
    (0,react.useEffect)(()=>{
        let phi = 0;
        if (!canvasRef.current) return;
        const globe = (0,index_esm/* default */.A)(canvasRef.current, {
            devicePixelRatio: 2,
            width: 600 * 2,
            height: 600 * 2,
            phi: 0,
            theta: 0,
            dark: 1,
            diffuse: 1.2,
            mapSamples: 16000,
            mapBrightness: 6,
            baseColor: [
                0.3,
                0.3,
                0.3
            ],
            markerColor: [
                0.1,
                0.8,
                1
            ],
            glowColor: [
                1,
                1,
                1
            ],
            markers: [
                // longitude latitude
                {
                    location: [
                        37.7595,
                        -122.4367
                    ],
                    size: 0.03
                },
                {
                    location: [
                        40.7128,
                        -74.006
                    ],
                    size: 0.1
                },
                {
                    location: [
                        51.5074,
                        -0.1278
                    ],
                    size: 0.08
                },
                {
                    location: [
                        48.8566,
                        2.3522
                    ],
                    size: 0.06
                },
                {
                    location: [
                        35.6762,
                        139.6503
                    ],
                    size: 0.09
                },
                {
                    location: [
                        55.7558,
                        37.6176
                    ],
                    size: 0.05
                },
                {
                    location: [
                        -33.8688,
                        151.2093
                    ],
                    size: 0.07
                },
                {
                    location: [
                        19.4326,
                        -99.1332
                    ],
                    size: 0.04
                },
                {
                    location: [
                        -23.5505,
                        -46.6333
                    ],
                    size: 0.06
                },
                {
                    location: [
                        28.6139,
                        77.209
                    ],
                    size: 0.08
                },
                {
                    location: [
                        39.9042,
                        116.4074
                    ],
                    size: 0.07
                },
                {
                    location: [
                        1.3521,
                        103.8198
                    ],
                    size: 0.05
                },
                {
                    location: [
                        25.2048,
                        55.2708
                    ],
                    size: 0.04
                },
                {
                    location: [
                        -26.2041,
                        28.0473
                    ],
                    size: 0.06
                },
                {
                    location: [
                        52.3676,
                        4.9041
                    ],
                    size: 0.05
                },
                {
                    location: [
                        59.9311,
                        10.7583
                    ],
                    size: 0.04
                },
                {
                    location: [
                        41.9028,
                        12.4964
                    ],
                    size: 0.05
                },
                {
                    location: [
                        50.1109,
                        8.6821
                    ],
                    size: 0.04
                },
                {
                    location: [
                        43.6532,
                        -79.3832
                    ],
                    size: 0.06
                },
                {
                    location: [
                        49.2827,
                        -123.1207
                    ],
                    size: 0.05
                },
                {
                    location: [
                        -34.6037,
                        -58.3816
                    ],
                    size: 0.07
                },
                {
                    location: [
                        30.0444,
                        31.2357
                    ],
                    size: 0.05
                },
                {
                    location: [
                        13.7563,
                        100.5018
                    ],
                    size: 0.06
                },
                {
                    location: [
                        60.1699,
                        24.9384
                    ],
                    size: 0.04
                },
                {
                    location: [
                        -1.2921,
                        36.8219
                    ],
                    size: 0.05
                }
            ],
            onRender: (state)=>{
                // Called on every animation frame.
                // `state` will be an empty object, return updated params.
                state.phi = phi;
                phi += 0.01;
            }
        });
        return ()=>{
            globe.destroy();
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("canvas", {
        ref: canvasRef,
        style: {
            width: 600,
            height: 600,
            maxWidth: "100%",
            aspectRatio: 1
        },
        className: className
    });
};
// Export alias for backward compatibility
const BentoGridFeatures = FeaturesSectionDemo;

;// ./components/FAQsection.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

const FAQSection = ()=>{
    const [openIndex, setOpenIndex] = (0,react.useState)(null);
    const faqs = [
        {
            question: 'What is the purpose of this PrepBettr?',
            answer: 'PrepBettr helps you ace your interviews by providing AI-powered practice sessions, personalized feedback, and real-time analysis to improve your performance.'
        },
        {
            question: 'How does the AI evaluation work?',
            answer: 'Our AI analyzes your responses using natural language processing to evaluate your communication skills, technical knowledge, and overall interview performance.'
        },
        {
            question: 'Can I customize the interview questions?',
            answer: 'Yes, you can choose from various question categories and difficulty levels to tailor the interview to your specific needs and job role.'
        },
        {
            question: 'Is there a free trial available?',
            answer: 'Yes, we offer a free trial so you can experience our platform before committing to a subscription.'
        }
    ];
    const toggleAccordion = (index)=>{
        setOpenIndex(openIndex === index ? null : index);
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
        className: "py-20 bg-white dark:bg-black",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "container mx-auto px-4",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "text-center mb-16 max-w-3xl mx-auto",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                            className: "text-3xl lg:text-5xl lg:leading-tight max-w-5xl mx-auto text-center tracking-tight font-medium text-black dark:text-white mb-6 flex flex-wrap justify-center items-baseline gap-2",
                            children: "Frequently Asked Questions"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                            className: "text-gray-600 dark:text-gray-300",
                            children: "Find answers to common questions about PrepBettr and how it can help you land your dream job."
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex flex-col lg:flex-row gap-12",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "lg:w-1/3",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    className: "text-indigo-600 dark:text-indigo-400 text-sm font-medium",
                                    children: "Need Help?"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                                    className: "text-2xl font-bold my-4 text-black dark:text-white",
                                    children: "Still have questions?"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                    className: "text-gray-600 dark:text-gray-300 mb-6",
                                    children: "Can't find the answer you're looking for? Our support team is here to help you with any questions you might have."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                                    href: "mailto:contact@prepbettr.com",
                                    className: "inline-block bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-6 rounded-lg transition-colors",
                                    children: "Contact us"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "lg:w-2/3 space-y-4",
                            children: faqs.map((faq, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                                            className: "w-full px-6 py-4 text-left flex items-center justify-between ".concat(openIndex === index ? 'bg-gray-50 dark:bg-gray-800' : 'bg-white dark:bg-gray-900'),
                                            onClick: ()=>toggleAccordion(index),
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "flex items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                            className: "text-indigo-600 dark:text-indigo-400 mr-4",
                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "w-6 h-6",
                                                                fill: "currentColor",
                                                                viewBox: "0 0 16 16",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    d: "M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.496 6.033h.825c.138 0 .248-.113.266-.25.09-.656.54-1.134 1.342-1.134.686 0 1.314.343 1.314 1.168 0 .635-.374.927-.965 1.371-.673.489-1.206 1.06-1.168 1.987l.003.217a.25.25 0 0 0 .25.246h.811a.25.25 0 0 0 .25-.25v-.105c0-.718.273-.927 1.01-1.486.609-.463 1.244-.977 1.244-2.056 0-1.511-1.276-2.241-2.673-2.241-1.267 0-2.655.59-2.75 2.286a.237.237 0 0 0 .241.247zm2.325 6.443c.61 0 1.029-.394 1.029-.927 0-.552-.42-.94-1.029-.94-.584 0-1.009.388-1.009.94 0 .533.425.927 1.01.927z"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                            className: "font-medium text-gray-900 dark:text-white",
                                                            children: faq.question
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                    className: "w-5 h-5 text-gray-500 transition-transform duration-200 ".concat(openIndex === index ? 'transform rotate-180' : ''),
                                                    fill: "none",
                                                    viewBox: "0 0 24 24",
                                                    stroke: "currentColor",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        strokeWidth: 2,
                                                        d: "M19 9l-7 7-7-7"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "px-6 overflow-hidden transition-all duration-200 ".concat(openIndex === index ? 'max-h-96 py-4' : 'max-h-0 py-0'),
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                className: "pb-4 text-gray-600 dark:text-gray-300",
                                                children: faq.answer
                                            })
                                        })
                                    ]
                                }, index))
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const FAQsection = (FAQSection);

// EXTERNAL MODULE: ./node_modules/next/dist/api/image.js
var api_image = __webpack_require__(66766);
;// ./app/marketing/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









// Dynamic import for MacbookScroll component that requires DOM and scroll APIs
const MacbookScroll = (0,app_dynamic["default"])(()=>Promise.all(/* import() */[__webpack_require__.e(989), __webpack_require__.e(7516)]).then(__webpack_require__.bind(__webpack_require__, 27516)).then((mod)=>({
            default: mod.MacbookScroll
        })), {
    loadableGenerated: {
        webpack: ()=>[
                /*require.resolve*/(27516)
            ]
    },
    ssr: false,
    loading: ()=>/*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "relative w-full overflow-visible",
            style: {
                minHeight: '500px'
            },
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center justify-center h-80",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {})
            })
        })
});
// Dynamic import for BrandSlide component that requires framer-motion
const BrandSlide = (0,app_dynamic["default"])(()=>__webpack_require__.e(/* import() */ 809).then(__webpack_require__.bind(__webpack_require__, 20809)), {
    loadableGenerated: {
        webpack: ()=>[
                /*require.resolve*/(20809)
            ]
    },
    ssr: false,
    loading: ()=>/*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "py-12 bg-black",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {})
            })
        })
});


const SiteNavigation = (0,app_dynamic["default"])(()=>__webpack_require__.e(/* import() */ 2125).then(__webpack_require__.bind(__webpack_require__, 2125)).then((mod)=>mod.SiteNavigation), {
    loadableGenerated: {
        webpack: ()=>[
                /*require.resolve*/(2125)
            ]
    },
    ssr: false
});
function HomePage() {
    const [isDashboardLoading, setIsDashboardLoading] = (0,react.useState)(false);
    const [isSignUpLoading, setIsSignUpLoading] = (0,react.useState)(false);
    const router = (0,navigation.useRouter)();
    const handleDashboardClick = ()=>{
        setIsDashboardLoading(true);
        router.push('/dashboard');
    };
    const handleSignUpClick = ()=>{
        setIsSignUpLoading(true);
        router.push('/sign-up');
    };
    // Clean up loader state on component unmount
    (0,react.useEffect)(()=>{
        return ()=>{
            setIsDashboardLoading(false);
            setIsSignUpLoading(false);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("main", {
        className: "min-h-screen bg-white dark:bg-black font-mona-sans relative",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(Spotlight, {}),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(SiteNavigation, {
                onDashboardClick: handleDashboardClick
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative z-10",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        className: "relative overflow-hidden pt-32 pb-32 md:pt-48 md:pb-48",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "absolute inset-0 -z-10 h-full w-full bg-white dark:bg-black",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "absolute inset-0 bg-[radial-gradient(circle_600px_at_50%_300px,#C9EBFF,transparent_70%)] dark:bg-[radial-gradient(circle_600px_at_50%_300px,#1a1a2e,transparent_70%)]"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent dark:from-black"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "container mx-auto px-8",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "max-w-4xl mx-auto text-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                                            className: "text-3xl lg:text-5xl lg:leading-tight max-w-5xl mx-auto text-center tracking-tight font-bold text-black dark:text-white mb-12 pt-8",
                                            children: "Ace Your Next Interview with AI"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                            className: "text-xl md:text-2xl text-neutral-600 dark:text-neutral-300 mb-10 max-w-3xl mx-auto",
                                            children: "Practice with our AI-powered interview simulator and land your dream job."
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "flex flex-col sm:flex-row gap-4 justify-center",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                                                    onClick: handleSignUpClick,
                                                    className: "relative inline-flex h-12 items-center justify-center overflow-hidden rounded-full p-[1px] focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 focus:ring-offset-slate-50",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                            className: "absolute inset-[-1000%] animate-[spin_2s_linear_infinite] bg-[conic-gradient(from_90deg_at_50%_50%,#E2CBFF_0%,#393BB2_50%,#E2CBFF_100%)]"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                            className: "inline-flex h-full w-full cursor-pointer items-center justify-center rounded-full bg-slate-950 px-8 py-3 text-sm font-medium text-white backdrop-blur-3xl",
                                                            children: "Get Started for Free"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)((link_default()), {
                                                    href: "#features",
                                                    className: "inline-flex h-12 items-center justify-center rounded-full border-2 border-neutral-300 bg-transparent px-8 py-3 text-sm font-medium text-neutral-700 transition-colors hover:bg-neutral-100 focus:outline-none focus:ring-2 focus:ring-neutral-400 focus:ring-offset-2 dark:border-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-800",
                                                    children: "Learn More"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(FeaturesSection, {}),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
                        className: "w-full bg-black py-12",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "container mx-auto px-4 text-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                    className: "text-xl font-medium mb-8 whitespace-nowrap text-white",
                                    children: "300,000+ offers from the most exciting companies and organizations"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(BrandSlide, {})
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "relative z-0 py-12",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "container mx-auto px-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                                    className: "text-3xl lg:text-5xl lg:leading-tight max-w-5xl mx-auto text-center tracking-tight font-medium text-black dark:text-white mb-12",
                                    children: "Experience the Future of Interview Prep"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                    className: "text-xl text-center text-gray-600 dark:text-gray-300 mb-12 max-w-3xl mx-auto",
                                    children: "Our AI-powered platform provides real-time feedback and personalized coaching to help you ace your next interview."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "relative w-full overflow-visible",
                                    style: {
                                        minHeight: '500px'
                                    },
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(MacbookScroll, {
                                        src: "/ProductMockup1.png",
                                        showGradient: false
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(BentoGridFeatures, {}),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "relative z-10",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TestimonialsSection, {})
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "relative z-0 pt-4 pb-12 bg-white dark:bg-black",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(FAQsection, {})
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        id: "pricing",
                        className: "relative isolate bg-white px-6 py-18 sm:py-18 lg:px-8 dark:bg-black",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "absolute inset-x-0 -top-3 -z-10 transform-gpu overflow-hidden px-36 blur-3xl",
                                "aria-hidden": "true",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "mx-auto aspect-[1155/678] w-[72.1875rem] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-30",
                                    style: {
                                        clipPath: 'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)'
                                    }
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "mx-auto max-w-4xl text-center",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                    className: "mt-2 text-5xl font-semibold tracking-tight text-balance text-gray-900 dark:text-white sm:text-6xl",
                                    children: "Choose the right plan for you"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                className: "mx-auto mt-6 max-w-2xl text-center text-lg font-medium text-pretty text-gray-600 dark:text-gray-300 sm:text-xl/8",
                                children: "From casual prep to competitive interviews, we've got you covered. Choose the plan that fits your goals and start leveling up today."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "mx-auto mt-16 grid max-w-lg grid-cols-1 items-center gap-y-6 sm:mt-20 sm:gap-y-0 lg:max-w-4xl lg:grid-cols-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "rounded-3xl rounded-t-3xl bg-white/60 p-8 ring-1 ring-gray-900/10 dark:bg-gray-900/50 dark:ring-white/10 sm:mx-8 sm:rounded-b-none sm:p-10 lg:mx-0 lg:rounded-tr-none lg:rounded-bl-3xl",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                                id: "tier-hobby",
                                                className: "text-base/7 font-semibold text-indigo-600",
                                                children: "Individual"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                className: "mt-4 flex items-baseline gap-x-2",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                        className: "text-5xl font-semibold tracking-tight text-gray-900 dark:text-white",
                                                        children: "$49"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                        className: "text-base text-gray-500 dark:text-gray-400",
                                                        children: "/month"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                className: "mt-6 text-base/7 text-gray-600 dark:text-gray-300",
                                                children: "The perfect plan if you're getting started."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                role: "list",
                                                className: "mt-8 space-y-3 text-sm/6 text-gray-600 dark:text-gray-300 sm:mt-10",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-600 dark:text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "Unlimited voice interviews"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-600 dark:text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "Unlimited coding practice"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-600 dark:text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "Personalized interview paths"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-600 dark:text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "Analytics & weekly updates"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)((link_default()), {
                                                href: "/sign-up",
                                                className: "mt-8 block rounded-md px-3.5 py-2.5 text-center text-sm font-semibold text-indigo-600 ring-1 ring-indigo-200 ring-inset hover:ring-indigo-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 sm:mt-10 dark:text-indigo-400 dark:ring-indigo-700 dark:hover:ring-indigo-600",
                                                children: "Get started today"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "relative rounded-3xl bg-gray-900 p-8 shadow-2xl ring-1 ring-gray-900/10 dark:bg-gray-800 sm:p-10",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                                id: "tier-enterprise",
                                                className: "text-base/7 font-semibold text-indigo-400",
                                                children: "Enterprise"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                className: "mt-4 flex items-baseline gap-x-2",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                        className: "text-5xl font-semibold tracking-tight text-white",
                                                        children: "$199"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                        className: "text-base text-gray-400",
                                                        children: "/month"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                className: "mt-6 text-base/7 text-gray-300",
                                                children: "Dedicated support and infrastructure for your company."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                role: "list",
                                                className: "mt-8 space-y-3 text-sm/6 text-gray-300 sm:mt-10",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "Admin dashboard with cohort analytics"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "Curriculum & LMS integrations"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "Dedicated account manager"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "API access for internal platforms"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "Multi-language support (beta)"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        className: "flex gap-x-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                className: "h-6 w-5 flex-none text-indigo-400",
                                                                viewBox: "0 0 20 20",
                                                                fill: "currentColor",
                                                                "aria-hidden": "true",
                                                                "data-slot": "icon",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                    fillRule: "evenodd",
                                                                    d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
                                                                    clipRule: "evenodd"
                                                                })
                                                            }),
                                                            "Collaborative interview resources"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)((link_default()), {
                                                href: "/contact",
                                                "aria-describedby": "tier-enterprise",
                                                className: "mt-8 block rounded-md bg-indigo-500 px-3.5 py-2.5 text-center text-sm font-semibold text-white shadow-xs hover:bg-indigo-400 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500 sm:mt-10",
                                                children: "Contact Sales"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
                        className: "relative py-18",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "relative max-w-4xl mx-auto px-4 text-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "inline-flex items-center justify-center px-4 py-1.5 rounded-full text-sm font-medium bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 mb-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                            className: "relative flex h-2 w-2 mr-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                    className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                    className: "relative inline-flex rounded-full h-2 w-2 bg-blue-500"
                                                })
                                            ]
                                        }),
                                        "Join 1,000+ satisfied users"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                                    className: "text-3xl lg:text-5xl lg:leading-tight max-w-5xl mx-auto text-center tracking-tight font-medium text-black dark:text-white mb-6",
                                    children: "Ready to ace your next interview?"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                    className: "text-xl text-neutral-600 dark:text-neutral-300 mb-8 max-w-2xl mx-auto",
                                    children: "Join thousands of candidates who improved their interview skills with PrepBettr."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex flex-col sm:flex-row gap-4 justify-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                                            onClick: handleSignUpClick,
                                            className: "relative inline-flex h-14 items-center justify-center overflow-hidden rounded-full p-[1px] focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 focus:ring-offset-slate-50",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                    className: "absolute inset-[-1000%] animate-[spin_2s_linear_infinite] bg-[conic-gradient(from_90deg_at_50%_50%,#E2CBFF_0%,#393BB2_50%,#E2CBFF_100%)]"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                    className: "inline-flex h-full w-full cursor-pointer items-center justify-center rounded-full bg-slate-950 px-8 py-3 text-base font-medium text-white backdrop-blur-3xl",
                                                    children: "Start Practicing Now"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)((link_default()), {
                                            href: "#features",
                                            className: "inline-flex h-14 items-center justify-center rounded-full border-2 border-neutral-300 bg-transparent px-8 py-3 text-base font-medium text-neutral-700 transition-colors hover:bg-neutral-100 focus:outline-none focus:ring-2 focus:ring-neutral-400 focus:ring-offset-2 dark:border-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-800",
                                            children: "Learn more"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("footer", {
                        className: "relative overflow-hidden py-16 border-t border-neutral-200 dark:border-neutral-800",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "absolute inset-0 [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_70%,transparent_100%)]",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] dark:bg-[radial-gradient(#374151_1px,transparent_1px)] [background-size:16px_16px]"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "container mx-auto px-4 relative",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "grid grid-cols-1 md:grid-cols-4 gap-12",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "space-y-4",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "flex flex-col space-y-2 items-start",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                                                                src: "/logo.svg",
                                                                alt: "Logo",
                                                                width: 32,
                                                                height: 32,
                                                                className: "h-8 w-auto"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                className: "text-xl font-bold text-gray-900 dark:text-white",
                                                                children: "PrepBettr"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                        className: "text-sm text-neutral-600 dark:text-neutral-400 mb-4",
                                                        children: "The most advanced AI-powered interview preparation platform."
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                        className: "mb-6",
                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                                                            src: "/MFS Banner.png",
                                                            alt: "MFS Banner",
                                                            width: 1200,
                                                            height: 600,
                                                            className: "w-full max-w-sm mx-auto h-auto"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "flex space-x-4",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                href: "https://twitter.com/prepbettr",
                                                                target: "_blank",
                                                                rel: "noopener noreferrer",
                                                                className: "text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 transition-colors",
                                                                "aria-label": "Twitter",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                        className: "sr-only",
                                                                        children: "Twitter"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                        className: "h-7 w-7",
                                                                        fill: "currentColor",
                                                                        viewBox: "0 0 24 24",
                                                                        "aria-hidden": "true",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                            d: "M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84"
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                href: "https://github.com/prepbettr",
                                                                target: "_blank",
                                                                rel: "noopener noreferrer",
                                                                className: "text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 transition-colors",
                                                                "aria-label": "GitHub",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                        className: "sr-only",
                                                                        children: "GitHub"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                        className: "h-7 w-7",
                                                                        fill: "currentColor",
                                                                        viewBox: "0 0 24 24",
                                                                        "aria-hidden": "true",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                            fillRule: "evenodd",
                                                                            d: "M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.699 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z",
                                                                            clipRule: "evenodd"
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                                href: "https://linkedin.com/company/prepbettr",
                                                                target: "_blank",
                                                                rel: "noopener noreferrer",
                                                                className: "text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 transition-colors",
                                                                "aria-label": "LinkedIn",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                        className: "sr-only",
                                                                        children: "LinkedIn"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                                                                        className: "h-7 w-7",
                                                                        fill: "currentColor",
                                                                        viewBox: "0 0 24 24",
                                                                        "aria-hidden": "true",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                                                                            d: "M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            [
                                                {
                                                    title: 'Product',
                                                    links: [
                                                        {
                                                            name: 'Features',
                                                            href: '#features'
                                                        },
                                                        {
                                                            name: 'Pricing',
                                                            href: '#pricing'
                                                        },
                                                        {
                                                            name: 'Testimonials',
                                                            href: '#testimonials'
                                                        }
                                                    ]
                                                },
                                                {
                                                    title: 'Company',
                                                    links: [
                                                        {
                                                            name: 'About Us',
                                                            href: '/marketing/about'
                                                        },
                                                        {
                                                            name: 'Careers',
                                                            href: '/marketing/careers'
                                                        },
                                                        {
                                                            name: 'Contact',
                                                            href: 'mailto:contact@prepbettr.com'
                                                        }
                                                    ]
                                                },
                                                {
                                                    title: 'Legal',
                                                    links: [
                                                        {
                                                            name: 'Privacy Policy',
                                                            href: '/marketing/privacy'
                                                        },
                                                        {
                                                            name: 'Terms of Service',
                                                            href: '/marketing/terms'
                                                        },
                                                        {
                                                            name: 'Cookie Policy',
                                                            href: '/marketing/cookies'
                                                        }
                                                    ]
                                                }
                                            ].map((column, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                                            className: "text-sm font-semibold text-neutral-900 dark:text-white tracking-wider uppercase",
                                                            children: column.title
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("ul", {
                                                            className: "mt-4 space-y-3",
                                                            children: column.links.map((link, linkIndex)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                                                                        href: link.href,
                                                                        className: "text-base text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white transition-colors",
                                                                        children: link.name
                                                                    })
                                                                }, linkIndex))
                                                        })
                                                    ]
                                                }, index))
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "mt-12 pt-8 border-t border-neutral-200 dark:border-neutral-800",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                            className: "text-sm text-center text-neutral-600 dark:text-neutral-400",
                                            children: [
                                                "\xa9 ",
                                                new Date().getFullYear(),
                                                " PrepBettr. All rights reserved."
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            (isDashboardLoading || isSignUpLoading) && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-sm",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {})
            })
        ]
    });
}


/***/ })

}]);