(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[1800],{

/***/ 39380:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  y: () => (/* binding */ MantineProvider)
});

// UNUSED EXPORTS: HeadlessMantineProvider

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
;// ./node_modules/@mantine/core/esm/core/MantineProvider/color-scheme-managers/is-mantine-color-scheme.mjs
/* __next_internal_client_entry_do_not_use__ isMantineColorScheme auto */ function isMantineColorScheme(value) {
    return value === "auto" || value === "dark" || value === "light";
}
 //# sourceMappingURL=is-mantine-color-scheme.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/color-scheme-managers/local-storage-manager.mjs
/* __next_internal_client_entry_do_not_use__ localStorageColorSchemeManager auto */ 
function localStorageColorSchemeManager() {
    let { key = "mantine-color-scheme-value" } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    let handleStorageEvent;
    return {
        get: (defaultValue)=>{
            if (typeof window === "undefined") {
                return defaultValue;
            }
            try {
                const storedColorScheme = window.localStorage.getItem(key);
                return isMantineColorScheme(storedColorScheme) ? storedColorScheme : defaultValue;
            } catch (e) {
                return defaultValue;
            }
        },
        set: (value)=>{
            try {
                window.localStorage.setItem(key, value);
            } catch (error) {
                console.warn("[@mantine/core] Local storage color scheme manager was unable to save color scheme.", error);
            }
        },
        subscribe: (onUpdate)=>{
            handleStorageEvent = (event)=>{
                if (event.storageArea === window.localStorage && event.key === key) {
                    isMantineColorScheme(event.newValue) && onUpdate(event.newValue);
                }
            };
            window.addEventListener("storage", handleStorageEvent);
        },
        unsubscribe: ()=>{
            window.removeEventListener("storage", handleStorageEvent);
        },
        clear: ()=>{
            window.localStorage.removeItem(key);
        }
    };
}
 //# sourceMappingURL=local-storage-manager.mjs.map

// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/Mantine.context.mjs
var Mantine_context = __webpack_require__(13656);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/utils/keys/keys.mjs
var keys = __webpack_require__(19224);
;// ./node_modules/@mantine/core/esm/core/utils/units-converters/px.mjs
function getTransformedScaledValue(value) {
  if (typeof value !== "string" || !value.includes("var(--mantine-scale)")) {
    return value;
  }
  return value.match(/^calc\((.*?)\)$/)?.[1].split("*")[0].trim();
}
function px(value) {
  const transformedValue = getTransformedScaledValue(value);
  if (typeof transformedValue === "number") {
    return transformedValue;
  }
  if (typeof transformedValue === "string") {
    if (transformedValue.includes("calc") || transformedValue.includes("var")) {
      return transformedValue;
    }
    if (transformedValue.includes("px")) {
      return Number(transformedValue.replace("px", ""));
    }
    if (transformedValue.includes("rem")) {
      return Number(transformedValue.replace("rem", "")) * 16;
    }
    if (transformedValue.includes("em")) {
      return Number(transformedValue.replace("em", "")) * 16;
    }
    return Number(transformedValue);
  }
  return NaN;
}


//# sourceMappingURL=px.mjs.map

// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/utils/units-converters/rem.mjs
var rem = __webpack_require__(5903);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/MantineThemeProvider/MantineThemeProvider.mjs + 1 modules
var MantineThemeProvider = __webpack_require__(3131);
;// ./node_modules/@mantine/core/esm/core/MantineProvider/MantineClasses/MantineClasses.mjs
/* __next_internal_client_entry_do_not_use__ MantineClasses auto */ 







function MantineClasses() {
    const theme = (0,MantineThemeProvider/* useMantineTheme */.xd)();
    const nonce = (0,Mantine_context/* useMantineStyleNonce */.WV)();
    const classes = (0,keys/* keys */.H)(theme.breakpoints).reduce((acc, breakpoint)=>{
        const isPxBreakpoint = theme.breakpoints[breakpoint].includes("px");
        const pxValue = px(theme.breakpoints[breakpoint]);
        const maxWidthBreakpoint = isPxBreakpoint ? "".concat(pxValue - 0.1, "px") : (0,rem.em)(pxValue - 0.1);
        const minWidthBreakpoint = isPxBreakpoint ? "".concat(pxValue, "px") : (0,rem.em)(pxValue);
        return "".concat(acc, "@media (max-width: ").concat(maxWidthBreakpoint, ") {.mantine-visible-from-").concat(breakpoint, " {display: none !important;}}@media (min-width: ").concat(minWidthBreakpoint, ") {.mantine-hidden-from-").concat(breakpoint, " {display: none !important;}}");
    }, "");
    return /* @__PURE__ */ (0,jsx_runtime.jsx)("style", {
        "data-mantine-styles": "classes",
        nonce: nonce === null || nonce === void 0 ? void 0 : nonce(),
        dangerouslySetInnerHTML: {
            __html: classes
        }
    });
}
 //# sourceMappingURL=MantineClasses.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/convert-css-variables/css-variables-object-to-string.mjs
/* __next_internal_client_entry_do_not_use__ cssVariablesObjectToString auto */ function cssVariablesObjectToString(variables) {
    return Object.entries(variables).map((param)=>{
        let [name, value] = param;
        return "".concat(name, ": ").concat(value, ";");
    }).join("");
}
 //# sourceMappingURL=css-variables-object-to-string.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/convert-css-variables/wrap-with-selector.mjs
/* __next_internal_client_entry_do_not_use__ wrapWithSelector auto */ function wrapWithSelector(selectors, code) {
    const _selectors = Array.isArray(selectors) ? selectors : [
        selectors
    ];
    return _selectors.reduce((acc, selector)=>"".concat(selector, "{").concat(acc, "}"), code);
}
 //# sourceMappingURL=wrap-with-selector.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/convert-css-variables/convert-css-variables.mjs
/* __next_internal_client_entry_do_not_use__ convertCssVariables auto */ 

function convertCssVariables(input, selector) {
    const sharedVariables = cssVariablesObjectToString(input.variables);
    const shared = sharedVariables ? wrapWithSelector(selector, sharedVariables) : "";
    const dark = cssVariablesObjectToString(input.dark);
    const light = cssVariablesObjectToString(input.light);
    const darkForced = dark ? selector === ":host" ? wrapWithSelector("".concat(selector, '([data-mantine-color-scheme="dark"])'), dark) : wrapWithSelector("".concat(selector, '[data-mantine-color-scheme="dark"]'), dark) : "";
    const lightForced = light ? selector === ":host" ? wrapWithSelector("".concat(selector, '([data-mantine-color-scheme="light"])'), light) : wrapWithSelector("".concat(selector, '[data-mantine-color-scheme="light"]'), light) : "";
    return "".concat(shared, "\n\n").concat(darkForced, "\n\n").concat(lightForced);
}
 //# sourceMappingURL=convert-css-variables.mjs.map

// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/utils/deep-merge/deep-merge.mjs
var deep_merge = __webpack_require__(41750);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-primary-shade/get-primary-shade.mjs
var get_primary_shade = __webpack_require__(30128);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-contrast-color/get-contrast-color.mjs
var get_contrast_color = __webpack_require__(89200);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/rgba/rgba.mjs
var rgba = __webpack_require__(70714);
;// ./node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/get-css-color-variables.mjs
/* __next_internal_client_entry_do_not_use__ getCSSColorVariables auto */ 




function getCSSColorVariables(param) {
    let { theme, color, colorScheme, name = color, withColorValues = true } = param;
    if (!theme.colors[color]) {
        return {};
    }
    if (colorScheme === "light") {
        const primaryShade2 = (0,get_primary_shade/* getPrimaryShade */.g)(theme, "light");
        const dynamicVariables2 = {
            ["--mantine-color-".concat(name, "-text")]: "var(--mantine-color-".concat(name, "-filled)"),
            ["--mantine-color-".concat(name, "-filled")]: "var(--mantine-color-".concat(name, "-").concat(primaryShade2, ")"),
            ["--mantine-color-".concat(name, "-filled-hover")]: "var(--mantine-color-".concat(name, "-").concat(primaryShade2 === 9 ? 8 : primaryShade2 + 1, ")"),
            ["--mantine-color-".concat(name, "-light")]: (0,rgba/* alpha */.X)(theme.colors[color][primaryShade2], 0.1),
            ["--mantine-color-".concat(name, "-light-hover")]: (0,rgba/* alpha */.X)(theme.colors[color][primaryShade2], 0.12),
            ["--mantine-color-".concat(name, "-light-color")]: "var(--mantine-color-".concat(name, "-").concat(primaryShade2, ")"),
            ["--mantine-color-".concat(name, "-outline")]: "var(--mantine-color-".concat(name, "-").concat(primaryShade2, ")"),
            ["--mantine-color-".concat(name, "-outline-hover")]: (0,rgba/* alpha */.X)(theme.colors[color][primaryShade2], 0.05)
        };
        if (!withColorValues) {
            return dynamicVariables2;
        }
        return {
            ["--mantine-color-".concat(name, "-0")]: theme.colors[color][0],
            ["--mantine-color-".concat(name, "-1")]: theme.colors[color][1],
            ["--mantine-color-".concat(name, "-2")]: theme.colors[color][2],
            ["--mantine-color-".concat(name, "-3")]: theme.colors[color][3],
            ["--mantine-color-".concat(name, "-4")]: theme.colors[color][4],
            ["--mantine-color-".concat(name, "-5")]: theme.colors[color][5],
            ["--mantine-color-".concat(name, "-6")]: theme.colors[color][6],
            ["--mantine-color-".concat(name, "-7")]: theme.colors[color][7],
            ["--mantine-color-".concat(name, "-8")]: theme.colors[color][8],
            ["--mantine-color-".concat(name, "-9")]: theme.colors[color][9],
            ...dynamicVariables2
        };
    }
    const primaryShade = (0,get_primary_shade/* getPrimaryShade */.g)(theme, "dark");
    const dynamicVariables = {
        ["--mantine-color-".concat(name, "-text")]: "var(--mantine-color-".concat(name, "-4)"),
        ["--mantine-color-".concat(name, "-filled")]: "var(--mantine-color-".concat(name, "-").concat(primaryShade, ")"),
        ["--mantine-color-".concat(name, "-filled-hover")]: "var(--mantine-color-".concat(name, "-").concat(primaryShade === 9 ? 8 : primaryShade + 1, ")"),
        ["--mantine-color-".concat(name, "-light")]: (0,rgba/* alpha */.X)(theme.colors[color][Math.max(0, primaryShade - 2)], 0.15),
        ["--mantine-color-".concat(name, "-light-hover")]: (0,rgba/* alpha */.X)(theme.colors[color][Math.max(0, primaryShade - 2)], 0.2),
        ["--mantine-color-".concat(name, "-light-color")]: "var(--mantine-color-".concat(name, "-").concat(Math.max(primaryShade - 5, 0), ")"),
        ["--mantine-color-".concat(name, "-outline")]: "var(--mantine-color-".concat(name, "-").concat(Math.max(primaryShade - 4, 0), ")"),
        ["--mantine-color-".concat(name, "-outline-hover")]: (0,rgba/* alpha */.X)(theme.colors[color][Math.max(primaryShade - 4, 0)], 0.05)
    };
    if (!withColorValues) {
        return dynamicVariables;
    }
    return {
        ["--mantine-color-".concat(name, "-0")]: theme.colors[color][0],
        ["--mantine-color-".concat(name, "-1")]: theme.colors[color][1],
        ["--mantine-color-".concat(name, "-2")]: theme.colors[color][2],
        ["--mantine-color-".concat(name, "-3")]: theme.colors[color][3],
        ["--mantine-color-".concat(name, "-4")]: theme.colors[color][4],
        ["--mantine-color-".concat(name, "-5")]: theme.colors[color][5],
        ["--mantine-color-".concat(name, "-6")]: theme.colors[color][6],
        ["--mantine-color-".concat(name, "-7")]: theme.colors[color][7],
        ["--mantine-color-".concat(name, "-8")]: theme.colors[color][8],
        ["--mantine-color-".concat(name, "-9")]: theme.colors[color][9],
        ...dynamicVariables
    };
}
 //# sourceMappingURL=get-css-color-variables.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/virtual-color/virtual-color.mjs





function virtualColor(input) {
  const result = colorsTuple(
    Array.from({ length: 10 }).map((_, i) => `var(--mantine-color-${input.name}-${i})`)
  );
  Object.defineProperty(result, "mantine-virtual-color", {
    enumerable: false,
    writable: false,
    configurable: false,
    value: true
  });
  Object.defineProperty(result, "dark", {
    enumerable: false,
    writable: false,
    configurable: false,
    value: input.dark
  });
  Object.defineProperty(result, "light", {
    enumerable: false,
    writable: false,
    configurable: false,
    value: input.light
  });
  Object.defineProperty(result, "name", {
    enumerable: false,
    writable: false,
    configurable: false,
    value: input.name
  });
  return result;
}
function isVirtualColor(value) {
  return !!value && typeof value === "object" && "mantine-virtual-color" in value;
}


//# sourceMappingURL=virtual-color.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/default-css-variables-resolver.mjs
/* __next_internal_client_entry_do_not_use__ defaultCssVariablesResolver auto */ 








function assignSizeVariables(variables, sizes, name) {
    (0,keys/* keys */.H)(sizes).forEach((size)=>Object.assign(variables, {
            ["--mantine-".concat(name, "-").concat(size)]: sizes[size]
        }));
}
const defaultCssVariablesResolver = (theme)=>{
    const lightPrimaryShade = (0,get_primary_shade/* getPrimaryShade */.g)(theme, "light");
    const defaultRadius = theme.defaultRadius in theme.radius ? theme.radius[theme.defaultRadius] : (0,rem/* rem */.D)(theme.defaultRadius);
    const result = {
        variables: {
            "--mantine-z-index-app": "100",
            "--mantine-z-index-modal": "200",
            "--mantine-z-index-popover": "300",
            "--mantine-z-index-overlay": "400",
            "--mantine-z-index-max": "9999",
            "--mantine-scale": theme.scale.toString(),
            "--mantine-cursor-type": theme.cursorType,
            "--mantine-webkit-font-smoothing": theme.fontSmoothing ? "antialiased" : "unset",
            "--mantine-moz-font-smoothing": theme.fontSmoothing ? "grayscale" : "unset",
            "--mantine-color-white": theme.white,
            "--mantine-color-black": theme.black,
            "--mantine-line-height": theme.lineHeights.md,
            "--mantine-font-family": theme.fontFamily,
            "--mantine-font-family-monospace": theme.fontFamilyMonospace,
            "--mantine-font-family-headings": theme.headings.fontFamily,
            "--mantine-heading-font-weight": theme.headings.fontWeight,
            "--mantine-heading-text-wrap": theme.headings.textWrap,
            "--mantine-radius-default": defaultRadius,
            // Primary colors
            "--mantine-primary-color-filled": "var(--mantine-color-".concat(theme.primaryColor, "-filled)"),
            "--mantine-primary-color-filled-hover": "var(--mantine-color-".concat(theme.primaryColor, "-filled-hover)"),
            "--mantine-primary-color-light": "var(--mantine-color-".concat(theme.primaryColor, "-light)"),
            "--mantine-primary-color-light-hover": "var(--mantine-color-".concat(theme.primaryColor, "-light-hover)"),
            "--mantine-primary-color-light-color": "var(--mantine-color-".concat(theme.primaryColor, "-light-color)")
        },
        light: {
            "--mantine-color-scheme": "light",
            "--mantine-primary-color-contrast": (0,get_contrast_color/* getPrimaryContrastColor */.g)(theme, "light"),
            "--mantine-color-bright": "var(--mantine-color-black)",
            "--mantine-color-text": theme.black,
            "--mantine-color-body": theme.white,
            "--mantine-color-error": "var(--mantine-color-red-6)",
            "--mantine-color-placeholder": "var(--mantine-color-gray-5)",
            "--mantine-color-anchor": "var(--mantine-color-".concat(theme.primaryColor, "-").concat(lightPrimaryShade, ")"),
            "--mantine-color-default": "var(--mantine-color-white)",
            "--mantine-color-default-hover": "var(--mantine-color-gray-0)",
            "--mantine-color-default-color": "var(--mantine-color-black)",
            "--mantine-color-default-border": "var(--mantine-color-gray-4)",
            "--mantine-color-dimmed": "var(--mantine-color-gray-6)",
            "--mantine-color-disabled": "var(--mantine-color-gray-2)",
            "--mantine-color-disabled-color": "var(--mantine-color-gray-5)",
            "--mantine-color-disabled-border": "var(--mantine-color-gray-3)"
        },
        dark: {
            "--mantine-color-scheme": "dark",
            "--mantine-primary-color-contrast": (0,get_contrast_color/* getPrimaryContrastColor */.g)(theme, "dark"),
            "--mantine-color-bright": "var(--mantine-color-white)",
            "--mantine-color-text": "var(--mantine-color-dark-0)",
            "--mantine-color-body": "var(--mantine-color-dark-7)",
            "--mantine-color-error": "var(--mantine-color-red-8)",
            "--mantine-color-placeholder": "var(--mantine-color-dark-3)",
            "--mantine-color-anchor": "var(--mantine-color-".concat(theme.primaryColor, "-4)"),
            "--mantine-color-default": "var(--mantine-color-dark-6)",
            "--mantine-color-default-hover": "var(--mantine-color-dark-5)",
            "--mantine-color-default-color": "var(--mantine-color-white)",
            "--mantine-color-default-border": "var(--mantine-color-dark-4)",
            "--mantine-color-dimmed": "var(--mantine-color-dark-2)",
            "--mantine-color-disabled": "var(--mantine-color-dark-6)",
            "--mantine-color-disabled-color": "var(--mantine-color-dark-3)",
            "--mantine-color-disabled-border": "var(--mantine-color-dark-4)"
        }
    };
    assignSizeVariables(result.variables, theme.breakpoints, "breakpoint");
    assignSizeVariables(result.variables, theme.spacing, "spacing");
    assignSizeVariables(result.variables, theme.fontSizes, "font-size");
    assignSizeVariables(result.variables, theme.lineHeights, "line-height");
    assignSizeVariables(result.variables, theme.shadows, "shadow");
    assignSizeVariables(result.variables, theme.radius, "radius");
    theme.colors[theme.primaryColor].forEach((_, index)=>{
        result.variables["--mantine-primary-color-".concat(index)] = "var(--mantine-color-".concat(theme.primaryColor, "-").concat(index, ")");
    });
    (0,keys/* keys */.H)(theme.colors).forEach((color)=>{
        const value = theme.colors[color];
        if (isVirtualColor(value)) {
            Object.assign(result.light, getCSSColorVariables({
                theme,
                name: value.name,
                color: value.light,
                colorScheme: "light",
                withColorValues: true
            }));
            Object.assign(result.dark, getCSSColorVariables({
                theme,
                name: value.name,
                color: value.dark,
                colorScheme: "dark",
                withColorValues: true
            }));
            return;
        }
        value.forEach((shade, index)=>{
            result.variables["--mantine-color-".concat(color, "-").concat(index)] = shade;
        });
        Object.assign(result.light, getCSSColorVariables({
            theme,
            color,
            colorScheme: "light",
            withColorValues: false
        }));
        Object.assign(result.dark, getCSSColorVariables({
            theme,
            color,
            colorScheme: "dark",
            withColorValues: false
        }));
    });
    const headings = theme.headings.sizes;
    (0,keys/* keys */.H)(headings).forEach((heading)=>{
        result.variables["--mantine-".concat(heading, "-font-size")] = headings[heading].fontSize;
        result.variables["--mantine-".concat(heading, "-line-height")] = headings[heading].lineHeight;
        result.variables["--mantine-".concat(heading, "-font-weight")] = headings[heading].fontWeight || theme.headings.fontWeight;
    });
    return result;
};
 //# sourceMappingURL=default-css-variables-resolver.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/get-merged-variables.mjs
/* __next_internal_client_entry_do_not_use__ getMergedVariables auto */ 




function getMergedVariables(param) {
    let { theme, generator } = param;
    const defaultResolver = defaultCssVariablesResolver(theme);
    const providerGenerator = generator === null || generator === void 0 ? void 0 : generator(theme);
    return providerGenerator ? (0,deep_merge/* deepMerge */.$)(defaultResolver, providerGenerator) : defaultResolver;
}
 //# sourceMappingURL=get-merged-variables.mjs.map

// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/default-theme.mjs + 3 modules
var default_theme = __webpack_require__(64555);
;// ./node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/remove-default-variables.mjs
/* __next_internal_client_entry_do_not_use__ removeDefaultVariables auto */ 





const defaultCssVariables = defaultCssVariablesResolver(default_theme/* DEFAULT_THEME */.S);
function removeDefaultVariables(input) {
    const cleaned = {
        variables: {},
        light: {},
        dark: {}
    };
    (0,keys/* keys */.H)(input.variables).forEach((key)=>{
        if (defaultCssVariables.variables[key] !== input.variables[key]) {
            cleaned.variables[key] = input.variables[key];
        }
    });
    (0,keys/* keys */.H)(input.light).forEach((key)=>{
        if (defaultCssVariables.light[key] !== input.light[key]) {
            cleaned.light[key] = input.light[key];
        }
    });
    (0,keys/* keys */.H)(input.dark).forEach((key)=>{
        if (defaultCssVariables.dark[key] !== input.dark[key]) {
            cleaned.dark[key] = input.dark[key];
        }
    });
    return cleaned;
}
 //# sourceMappingURL=remove-default-variables.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/MantineCssVariables/MantineCssVariables.mjs
/* __next_internal_client_entry_do_not_use__ MantineCssVariables auto */ 





function getColorSchemeCssVariables(selector) {
    return "\n  ".concat(selector, '[data-mantine-color-scheme="dark"] { --mantine-color-scheme: dark; }\n  ').concat(selector, '[data-mantine-color-scheme="light"] { --mantine-color-scheme: light; }\n');
}
function MantineCssVariables(param) {
    let { cssVariablesSelector, deduplicateCssVariables } = param;
    const theme = (0,MantineThemeProvider/* useMantineTheme */.xd)();
    const nonce = (0,Mantine_context/* useMantineStyleNonce */.WV)();
    const generator = (0,Mantine_context/* useMantineCssVariablesResolver */.OY)();
    const mergedVariables = getMergedVariables({
        theme,
        generator
    });
    const shouldCleanVariables = cssVariablesSelector === ":root" && deduplicateCssVariables;
    const cleanedVariables = shouldCleanVariables ? removeDefaultVariables(mergedVariables) : mergedVariables;
    const css = convertCssVariables(cleanedVariables, cssVariablesSelector);
    if (css) {
        return /* @__PURE__ */ (0,jsx_runtime.jsx)("style", {
            "data-mantine-styles": true,
            nonce: nonce === null || nonce === void 0 ? void 0 : nonce(),
            dangerouslySetInnerHTML: {
                __html: "".concat(css).concat(shouldCleanVariables ? "" : getColorSchemeCssVariables(cssVariablesSelector))
            }
        });
    }
    return null;
}
MantineCssVariables.displayName = "@mantine/CssVariables";
 //# sourceMappingURL=MantineCssVariables.mjs.map

;// ./node_modules/@mantine/hooks/esm/use-isomorphic-effect/use-isomorphic-effect.mjs
/* __next_internal_client_entry_do_not_use__ useIsomorphicEffect auto */ 
const useIsomorphicEffect = typeof document !== "undefined" ? react.useLayoutEffect : react.useEffect;
 //# sourceMappingURL=use-isomorphic-effect.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/use-mantine-color-scheme/use-provider-color-scheme.mjs
/* __next_internal_client_entry_do_not_use__ useProviderColorScheme auto */ 

function setColorSchemeAttribute(colorScheme, getRootElement) {
    var _window_matchMedia, _getRootElement;
    const hasDarkColorScheme = typeof window !== "undefined" && "matchMedia" in window && ((_window_matchMedia = window.matchMedia("(prefers-color-scheme: dark)")) === null || _window_matchMedia === void 0 ? void 0 : _window_matchMedia.matches);
    const computedColorScheme = colorScheme !== "auto" ? colorScheme : hasDarkColorScheme ? "dark" : "light";
    (_getRootElement = getRootElement()) === null || _getRootElement === void 0 ? void 0 : _getRootElement.setAttribute("data-mantine-color-scheme", computedColorScheme);
}
function useProviderColorScheme(param) {
    let { manager, defaultColorScheme, getRootElement, forceColorScheme } = param;
    const media = (0,react.useRef)(null);
    const [value, setValue] = (0,react.useState)(()=>manager.get(defaultColorScheme));
    const colorSchemeValue = forceColorScheme || value;
    const setColorScheme = (0,react.useCallback)((colorScheme)=>{
        if (!forceColorScheme) {
            setColorSchemeAttribute(colorScheme, getRootElement);
            setValue(colorScheme);
            manager.set(colorScheme);
        }
    }, [
        manager.set,
        colorSchemeValue,
        forceColorScheme
    ]);
    const clearColorScheme = (0,react.useCallback)(()=>{
        setValue(defaultColorScheme);
        setColorSchemeAttribute(defaultColorScheme, getRootElement);
        manager.clear();
    }, [
        manager.clear,
        defaultColorScheme
    ]);
    (0,react.useEffect)(()=>{
        manager.subscribe(setColorScheme);
        return manager.unsubscribe;
    }, [
        manager.subscribe,
        manager.unsubscribe
    ]);
    useIsomorphicEffect(()=>{
        setColorSchemeAttribute(manager.get(defaultColorScheme), getRootElement);
    }, []);
    (0,react.useEffect)(()=>{
        var _media_current;
        if (forceColorScheme) {
            setColorSchemeAttribute(forceColorScheme, getRootElement);
            return ()=>{};
        }
        if (forceColorScheme === void 0) {
            setColorSchemeAttribute(value, getRootElement);
        }
        if (typeof window !== "undefined" && "matchMedia" in window) {
            media.current = window.matchMedia("(prefers-color-scheme: dark)");
        }
        const listener = (event)=>{
            if (value === "auto") {
                setColorSchemeAttribute(event.matches ? "dark" : "light", getRootElement);
            }
        };
        (_media_current = media.current) === null || _media_current === void 0 ? void 0 : _media_current.addEventListener("change", listener);
        return ()=>{
            var _media_current;
            return (_media_current = media.current) === null || _media_current === void 0 ? void 0 : _media_current.removeEventListener("change", listener);
        };
    }, [
        value,
        forceColorScheme
    ]);
    return {
        colorScheme: colorSchemeValue,
        setColorScheme,
        clearColorScheme
    };
}
 //# sourceMappingURL=use-provider-color-scheme.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/use-respect-reduce-motion/use-respect-reduce-motion.mjs
/* __next_internal_client_entry_do_not_use__ useRespectReduceMotion auto */ 
function useRespectReduceMotion(param) {
    let { respectReducedMotion, getRootElement } = param;
    useIsomorphicEffect(()=>{
        if (respectReducedMotion) {
            var _getRootElement;
            (_getRootElement = getRootElement()) === null || _getRootElement === void 0 ? void 0 : _getRootElement.setAttribute("data-respect-reduced-motion", "true");
        }
    }, [
        respectReducedMotion
    ]);
}
 //# sourceMappingURL=use-respect-reduce-motion.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/MantineProvider.mjs
/* __next_internal_client_entry_do_not_use__ HeadlessMantineProvider,MantineProvider auto */ 









function MantineProvider(param) {
    let { theme, children, getStyleNonce, withStaticClasses = true, withGlobalClasses = true, deduplicateCssVariables = true, withCssVariables = true, cssVariablesSelector = ":root", classNamesPrefix = "mantine", colorSchemeManager = localStorageColorSchemeManager(), defaultColorScheme = "light", getRootElement = ()=>document.documentElement, cssVariablesResolver, forceColorScheme, stylesTransform, env } = param;
    const { colorScheme, setColorScheme, clearColorScheme } = useProviderColorScheme({
        defaultColorScheme,
        forceColorScheme,
        manager: colorSchemeManager,
        getRootElement
    });
    useRespectReduceMotion({
        respectReducedMotion: (theme === null || theme === void 0 ? void 0 : theme.respectReducedMotion) || false,
        getRootElement
    });
    return /* @__PURE__ */ (0,jsx_runtime.jsx)(Mantine_context/* MantineContext */.A$.Provider, {
        value: {
            colorScheme,
            setColorScheme,
            clearColorScheme,
            getRootElement,
            classNamesPrefix,
            getStyleNonce,
            cssVariablesResolver,
            cssVariablesSelector,
            withStaticClasses,
            stylesTransform,
            env
        },
        children: /* @__PURE__ */ (0,jsx_runtime.jsxs)(MantineThemeProvider/* MantineThemeProvider */.nW, {
            theme,
            children: [
                withCssVariables && /* @__PURE__ */ (0,jsx_runtime.jsx)(MantineCssVariables, {
                    cssVariablesSelector,
                    deduplicateCssVariables
                }),
                withGlobalClasses && /* @__PURE__ */ (0,jsx_runtime.jsx)(MantineClasses, {}),
                children
            ]
        })
    });
}
MantineProvider.displayName = "@mantine/core/MantineProvider";
function HeadlessMantineProvider(param) {
    let { children, theme, env } = param;
    return /* @__PURE__ */ (0,jsx_runtime.jsx)(Mantine_context/* MantineContext */.A$.Provider, {
        value: {
            colorScheme: "auto",
            setColorScheme: ()=>{},
            clearColorScheme: ()=>{},
            getRootElement: ()=>document.documentElement,
            classNamesPrefix: "mantine",
            cssVariablesSelector: ":root",
            withStaticClasses: false,
            headless: true,
            env
        },
        children: /* @__PURE__ */ (0,jsx_runtime.jsx)(MantineThemeProvider/* MantineThemeProvider */.nW, {
            theme,
            children
        })
    });
}
HeadlessMantineProvider.displayName = "@mantine/core/HeadlessMantineProvider";
 //# sourceMappingURL=MantineProvider.mjs.map


/***/ }),

/***/ 85925:
/***/ ((module) => {

// extracted by mini-css-extract-plugin
module.exports = {"style":{"fontFamily":"'Mona Sans', 'Mona Sans Fallback'","fontStyle":"normal"},"className":"__className_852510","variable":"__variable_852510"};

/***/ })

}]);