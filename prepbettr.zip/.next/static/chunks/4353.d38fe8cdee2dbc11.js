"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[4353],{

/***/ 4353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(55028);
/* __next_internal_client_entry_do_not_use__ default auto */ 

// Dynamic import for PdfUploadButton component that requires DOM and framer-motion APIs
const PdfUploadButton = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_1__["default"])(()=>Promise.all(/* import() */[__webpack_require__.e(2992), __webpack_require__.e(7811), __webpack_require__.e(9471), __webpack_require__.e(1840), __webpack_require__.e(6671), __webpack_require__.e(3549), __webpack_require__.e(2236), __webpack_require__.e(3806), __webpack_require__.e(5142), __webpack_require__.e(29)]).then(__webpack_require__.bind(__webpack_require__, 10029)), {
    loadableGenerated: {
        webpack: ()=>[
                /*require.resolve*/(10029)
            ]
    },
    ssr: false,
    loading: ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "relative",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                type: "button",
                disabled: true,
                className: "p-2 text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white rounded-lg border border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-700 transition-colors shadow-sm animate-pulse",
                "aria-label": "Upload resume/CV",
                title: "Loading upload component...",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "w-6 h-6 bg-gray-400 dark:bg-gray-500 rounded animate-pulse"
                })
            })
        })
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PdfUploadButton);


/***/ })

}]);