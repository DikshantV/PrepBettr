(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[3806],{

/***/ 3404:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  O3: () => (/* reexport */ esm_NoDomUploady),
  QB: () => (/* reexport */ markAsUploadOptionsComponent),
  NL: () => (/* reexport */ useItemAbortListener),
  Xy: () => (/* reexport */ useItemErrorListener),
  zf: () => (/* reexport */ useItemFinalizeListener),
  OE: () => (/* reexport */ useItemProgressListener),
  Jg: () => (/* reexport */ useItemStartListener),
  bn: () => (/* reexport */ hooks_useUploadOptions),
  Bx: () => (/* reexport */ hooks_useUploadyContext)
});

// UNUSED EXPORTS: UploadyContext, assertContext, createContextApi, generateUploaderEventHook, generateUploaderEventHookWithState, getIsUploadOptionsComponent, getUploadyVersion, logWarning, useAbortAll, useAbortBatch, useAbortItem, useAllAbortListener, useBatchAbortListener, useBatchAddListener, useBatchCancelledListener, useBatchErrorListener, useBatchFinalizeListener, useBatchFinishListener, useBatchProgressListener, useBatchStartListener, useItemCancelListener, useItemFinishListener, useRequestPreSend, useUploady, withBatchStartUpdate, withRequestPreSendUpdate

// EXTERNAL MODULE: ./node_modules/@rpldy/uploader/lib/esm/index.js + 36 modules
var esm = __webpack_require__(46472);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/@rpldy/shared/lib/esm/index.js + 22 modules
var lib_esm = __webpack_require__(95785);
;// ./node_modules/@rpldy/shared-ui/lib/esm/uploadyVersion.js
/* provided dependency */ var process = __webpack_require__(87358);

const GLOBAL_VERSION_SYM = Symbol.for("_rpldy-version_");
const getVersion = () => "1.11.0" || 0;
const getGlobal = () => (0,lib_esm/* hasWindow */.Vd)() ? window : globalThis || process;
const getRegisteredVersion = () => {
  const global = getGlobal();
  return global[GLOBAL_VERSION_SYM];
};
const registerUploadyContextVersion = () => {
  const global = getGlobal();
  global[GLOBAL_VERSION_SYM] = getVersion();
};
const getIsVersionRegisteredAndDifferent = () => {
  const registeredVersion = getRegisteredVersion();
  return !!registeredVersion && registeredVersion !== getVersion();
};

;// ./node_modules/@rpldy/shared-ui/lib/esm/UploadyContext.js



const UploadyContext = /*#__PURE__*/react.createContext(null);
const NO_INPUT_ERROR_MSG = "Uploady - Context. File input isn't available";
const createContextApi = (uploader, internalInputRef) => {
  let fileInputRef, showFileUploadOptions;
  let isUsingExternalInput = false;
  if (internalInputRef) {
    fileInputRef = internalInputRef;
  } else {
    lib_esm/* logger.debugLog */.vF.debugLog("Uploady context - didn't receive input field ref - waiting for external ref");
  }
  const getInputField = () => fileInputRef?.current;
  const getInternalFileInput = () => {
    if (fileInputRef) {
      isUsingExternalInput = true;
    }
    return fileInputRef;
  };
  const getIsUsingExternalInput = () => isUsingExternalInput;
  const onFileInputChange = () => {
    const input = getInputField();
    (0,lib_esm/* invariant */.V1)(input, NO_INPUT_ERROR_MSG);
    input.removeEventListener("change", onFileInputChange);
    const addOptions = showFileUploadOptions;
    showFileUploadOptions = null;
    upload(input.files, addOptions);
  };
  const upload = (files, addOptions) => {
    uploader.add(files, addOptions);
  };
  registerUploadyContextVersion();
  return {
    hasUploader: () => !!uploader,
    getInternalFileInput,
    setExternalFileInput: extRef => {
      isUsingExternalInput = true;
      fileInputRef = extRef;
    },
    getIsUsingExternalInput,
    showFileUpload: addOptions => {
      const input = getInputField();
      (0,lib_esm/* invariant */.V1)(input, NO_INPUT_ERROR_MSG);
      showFileUploadOptions = addOptions;
      input.removeEventListener("change", onFileInputChange);
      input.addEventListener("change", onFileInputChange);
      input.value = "";
      input.click();
    },
    upload,
    processPending: uploadOptions => {
      uploader.upload(uploadOptions);
    },
    clearPending: () => {
      uploader.clearPending();
    },
    setOptions: options => {
      uploader.update(options);
    },
    getOptions: () => {
      return uploader.getOptions();
    },
    getExtension: name => {
      return uploader.getExtension(name);
    },
    abort: itemId => {
      uploader.abort(itemId);
    },
    abortBatch: batchId => {
      uploader.abortBatch(batchId);
    },
    on: (name, cb) => {
      return uploader.on(name, cb);
    },
    once: (name, cb) => {
      return uploader.once(name, cb);
    },
    off: (name, cb) => {
      return uploader.off(name, cb);
    }
  };
};
/* harmony default export */ const esm_UploadyContext = (UploadyContext);
;// ./node_modules/@rpldy/shared-ui/lib/esm/assertContext.js


const ERROR_MSG = "Uploady - Valid UploadyContext not found. Make sure you render inside <Uploady>";
const DIFFERENT_VERSION_ERROR_MSG = `Uploady - Valid UploadyContext not found.
You may be using packages of different Uploady versions. <Uploady> and all other packages using the context provider must be of the same version: %s`;
const assertContext = context => {
  (0,lib_esm/* invariant */.V1)(!getIsVersionRegisteredAndDifferent(), DIFFERENT_VERSION_ERROR_MSG, getRegisteredVersion());
  (0,lib_esm/* invariant */.V1)(context && context.hasUploader(), ERROR_MSG);
  return context;
};
/* harmony default export */ const esm_assertContext = (assertContext);
;// ./node_modules/@rpldy/shared-ui/lib/esm/hooks/useUploadyContext.js



const useUploadyContext_useUploadyContext = () => esm_assertContext((0,react.useContext)(esm_UploadyContext));
/* harmony default export */ const hooks_useUploadyContext = (useUploadyContext_useUploadyContext);
;// ./node_modules/@rpldy/shared-ui/lib/esm/hooks/hooksUtils.js



const useEventEffect = (event, fn) => {
  const context = hooks_useUploadyContext();
  const {
    on,
    off
  } = context;
  (0,react.useEffect)(() => {
    on(event, fn);
    return () => {
      off(event, fn);
    };
  }, [event, fn, on, off]);
};
const generateUploaderEventHookWithState = (event, stateCalculator) => (fn, id) => {
  const [eventState, setEventState] = (0,react.useState)(null);
  let cbFn = fn;
  let usedId = id;
  if (fn && !(0,lib_esm/* isFunction */.Tn)(fn)) {
    usedId = fn;
    cbFn = undefined;
  }
  const eventCallback = (0,react.useCallback)((eventObj, ...args) => {
    if (!usedId || eventObj.id === usedId) {
      setEventState(stateCalculator(eventObj, ...args));
      if ((0,lib_esm/* isFunction */.Tn)(cbFn)) {
        cbFn(eventObj, ...args);
      }
    }
  }, [cbFn, usedId]);
  useEventEffect(event, eventCallback);
  return eventState;
};
const generateUploaderEventHook = (event, canScope = true) => (fn, id) => {
  const eventCallback = (0,react.useCallback)((eventObj, ...args) => {
    return fn && (!canScope || !id || eventObj.id === id) ? fn(eventObj, ...args) : undefined;
  }, [fn, id]);
  useEventEffect(event, eventCallback);
};

;// ./node_modules/@rpldy/shared-ui/lib/esm/hooks/eventListenerHooks.js


const useBatchAddListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.BATCH_ADD, false);
const useBatchStartListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.BATCH_START);
const useBatchFinishListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.BATCH_FINISH);
const useBatchCancelledListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.BATCH_CANCEL);
const useBatchErrorListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.BATCH_ERROR);
const useBatchFinalizeListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.BATCH_FINALIZE);
const useBatchAbortListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.BATCH_ABORT);
const useBatchProgressListener = generateUploaderEventHookWithState(esm/* UPLOADER_EVENTS */.x0.BATCH_PROGRESS, batch => ({
  ...batch
}));
const useItemStartListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.ITEM_START);
const useItemFinishListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.ITEM_FINISH);
const useItemCancelListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.ITEM_CANCEL);
const useItemErrorListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.ITEM_ERROR);
const useItemAbortListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.ITEM_ABORT);
const useItemFinalizeListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.ITEM_FINALIZE);
const useItemProgressListener = generateUploaderEventHookWithState(esm/* UPLOADER_EVENTS */.x0.ITEM_PROGRESS, item => ({
  ...item
}));
const useRequestPreSend = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.REQUEST_PRE_SEND, false);
const useAllAbortListener = generateUploaderEventHook(esm/* UPLOADER_EVENTS */.x0.ALL_ABORT, false);

;// ./node_modules/@rpldy/shared-ui/lib/esm/consts.js
const consts_UPLOAD_OPTIONS_COMP = Symbol.for("rpldy_component");
;// ./node_modules/@rpldy/shared-ui/lib/esm/utils.js


const logWarning = (condition, msg) => {
  if (!isProduction() && !condition) {
    console.warn(msg);
  }
};
const markAsUploadOptionsComponent = Component => {
  Component[consts_UPLOAD_OPTIONS_COMP] = true;
};
const getIsUploadOptionsComponent = Component => Component[UPLOAD_OPTIONS_COMP] === true || Component.target?.[UPLOAD_OPTIONS_COMP] === true || Component.render?.[UPLOAD_OPTIONS_COMP] === true;

;// ./node_modules/@rpldy/shared-ui/lib/esm/hooks/useUploader.js



const useUploader = (options, listeners) => {
  const uploader = (0,react.useMemo)(() => {
    lib_esm/* logger.debugLog */.vF.debugLog("Uploady creating a new uploader instance", options);
    return (0,esm/* default */.Ay)(options);
  }, [options.enhancer]);
  uploader.update(options);
  (0,react.useEffect)(() => {
    if (listeners) {
      lib_esm/* logger.debugLog */.vF.debugLog("Uploady setting event listeners", listeners);
      Object.entries(listeners).forEach(([name, m]) => {
        uploader.on(name, m);
      });
    }
    return () => {
      if (listeners) {
        lib_esm/* logger.debugLog */.vF.debugLog("Uploady removing event listeners", listeners);
        Object.entries(listeners).forEach(([name, m]) => uploader.off(name, m));
      }
    };
  }, [listeners, uploader]);
  return uploader;
};
/* harmony default export */ const hooks_useUploader = (useUploader);
;// ./node_modules/@rpldy/shared-ui/lib/esm/NoDomUploady.js




const NoDomUploady = props => {
  const {
    listeners,
    debug,
    children,
    inputRef,
    ...uploadOptions
  } = props;
  lib_esm/* logger.setDebug */.vF.setDebug(!!debug);
  lib_esm/* logger.debugLog */.vF.debugLog("@@@@@@ Uploady Rendering @@@@@@", props);
  const uploader = hooks_useUploader(uploadOptions, listeners);
  const api = (0,react.useMemo)(() => createContextApi(uploader, inputRef), [uploader, inputRef]);
  return /*#__PURE__*/react.createElement(esm_UploadyContext.Provider, {
    value: api
  }, children);
};
/* harmony default export */ const esm_NoDomUploady = (NoDomUploady);
;// ./node_modules/@rpldy/shared-ui/lib/esm/hooks/useUploadOptions.js

const useUploadOptions = options => {
  const context = hooks_useUploadyContext();
  if (options) {
    context.setOptions(options);
  }
  return context.getOptions();
};
/* harmony default export */ const hooks_useUploadOptions = (useUploadOptions);
;// ./node_modules/@rpldy/shared-ui/lib/esm/hooks/useAbortItem.js


const useAbortItem = () => {
  const context = useUploadyContext();
  return useCallback(id => context.abort(id), [context]);
};
/* harmony default export */ const hooks_useAbortItem = ((/* unused pure expression or super */ null && (useAbortItem)));
;// ./node_modules/@rpldy/shared-ui/lib/esm/hooks/useAbortBatch.js


const useAbortBatch = () => {
  const context = useUploadyContext();
  return useCallback(id => context.abortBatch(id), [context]);
};
/* harmony default export */ const hooks_useAbortBatch = ((/* unused pure expression or super */ null && (useAbortBatch)));
;// ./node_modules/@rpldy/shared-ui/lib/esm/hooks/useAbortAll.js


const useAbortAll = () => {
  const context = useUploadyContext();
  return useCallback(() => context.abort(), [context]);
};
/* harmony default export */ const hooks_useAbortAll = ((/* unused pure expression or super */ null && (useAbortAll)));
;// ./node_modules/@rpldy/shared-ui/lib/esm/hocs/createRequestUpdateHoc.js
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }


const createRequestUpdateHoc = ({
  eventType,
  getIsValidEventData,
  getRequestData
}) => Component => props => {
  const context = hooks_useUploadyContext();
  const [updater, setUpdater] = (0,react.useState)({
    updateRequest: null,
    requestData: null
  });
  const {
    id
  } = props;
  (0,react.useLayoutEffect)(() => {
    const handleEvent = (...params) => getIsValidEventData(id, ...params) === true ? new Promise(resolve => {
      setUpdater({
        updateRequest: data => {
          context.off(eventType, handleEvent);
          resolve(data);
        },
        requestData: getRequestData(...params)
      });
    }) : undefined;
    if (id) {
      context.on(eventType, handleEvent);
    }
    return () => {
      if (id) {
        context.off(eventType, handleEvent);
      }
    };
  }, [context, id]);
  return /*#__PURE__*/react.createElement(Component, _extends({}, props, updater));
};

;// ./node_modules/@rpldy/shared-ui/lib/esm/hocs/withRequestPreSendUpdate.js


const withRequestPreSendUpdate = createRequestUpdateHoc({
  eventType: esm/* UPLOADER_EVENTS */.x0.REQUEST_PRE_SEND,
  getIsValidEventData: (id, {
    items
  }) => !!items.find(item => item.id === id),
  getRequestData: ({
    items,
    options
  }) => ({
    items,
    options
  })
});
/* harmony default export */ const hocs_withRequestPreSendUpdate = ((/* unused pure expression or super */ null && (withRequestPreSendUpdate)));
;// ./node_modules/@rpldy/shared-ui/lib/esm/hocs/withBatchStartUpdate.js


const withBatchStartUpdate = createRequestUpdateHoc({
  eventType: esm/* UPLOADER_EVENTS */.x0.BATCH_START,
  getIsValidEventData: (id, batch) => batch.id === id,
  getRequestData: (batch, batchOptions) => ({
    batch,
    items: batch.items,
    options: batchOptions
  })
});
/* harmony default export */ const hocs_withBatchStartUpdate = ((/* unused pure expression or super */ null && (withBatchStartUpdate)));
;// ./node_modules/@rpldy/shared-ui/lib/esm/index.js















/***/ }),

/***/ 23718:
/***/ ((module) => {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



/**
 * Use invariant() to assert state which your program assumes to be true.
 *
 * Provide sprintf-style format (only %s is supported) and arguments
 * to provide information about what broke and what you were
 * expecting.
 *
 * The invariant message will be stripped in production, but the invariant
 * will remain to ensure logic does not differ in production.
 */

var invariant = function(condition, format, a, b, c, d, e, f) {
  if (false) {}

  if (!condition) {
    var error;
    if (format === undefined) {
      error = new Error(
        'Minified exception occurred; use the non-minified dev environment ' +
        'for the full error message and additional helpful warnings.'
      );
    } else {
      var args = [a, b, c, d, e, f];
      var argIndex = 0;
      error = new Error(
        format.replace(/%s/g, function() { return args[argIndex++]; })
      );
      error.name = 'Invariant Violation';
    }

    error.framesToPop = 1; // we don't care about invariant's own frame
    throw error;
  }
};

module.exports = invariant;


/***/ }),

/***/ 25840:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Ay: () => (/* binding */ uploady_lib_esm),
  NL: () => (/* reexport */ lib_esm/* useItemAbortListener */.NL),
  Xy: () => (/* reexport */ lib_esm/* useItemErrorListener */.Xy),
  zf: () => (/* reexport */ lib_esm/* useItemFinalizeListener */.zf),
  OE: () => (/* reexport */ lib_esm/* useItemProgressListener */.OE),
  Jg: () => (/* reexport */ lib_esm/* useItemStartListener */.Jg)
});

// UNUSED EXPORTS: BATCH_STATES, DEFAULT_OPTIONS, FILE_STATES, MissingUrlError, NoDomUploady, UPLOADER_EVENTS, Uploady, UploadyContext, XHR_SENDER_TYPE, assertContext, composeEnhancers, createContextApi, createUploader, generateUploaderEventHook, generateUploaderEventHookWithState, getIsUploadOptionsComponent, getUploadyVersion, getXhrSend, logWarning, markAsUploadOptionsComponent, send, useAbortAll, useAbortBatch, useAbortItem, useAllAbortListener, useBatchAbortListener, useBatchAddListener, useBatchCancelledListener, useBatchErrorListener, useBatchFinalizeListener, useBatchFinishListener, useBatchProgressListener, useBatchStartListener, useFileInput, useItemCancelListener, useItemFinishListener, useRequestPreSend, useUploadOptions, useUploady, useUploadyContext, withBatchStartUpdate, withRequestPreSendUpdate

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-dom/index.js
var react_dom = __webpack_require__(47650);
// EXTERNAL MODULE: ./node_modules/@rpldy/shared/lib/esm/index.js + 22 modules
var esm = __webpack_require__(95785);
// EXTERNAL MODULE: ./node_modules/@rpldy/shared-ui/lib/esm/index.js + 17 modules
var lib_esm = __webpack_require__(3404);
;// ./node_modules/@rpldy/uploady/lib/esm/Uploady.js
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }




const NO_CONTAINER_ERROR_MSG = "Uploady - Container for file input must be a valid dom element";
const renderInput = (inputProps, instanceOptions, ref) => /*#__PURE__*/react.createElement("input", _extends({}, inputProps, {
  name: instanceOptions.inputFieldName,
  type: "file",
  ref: ref
}));
const renderInPortal = (container, isValidContainer, inputProps, instanceOptions, ref) => container && isValidContainer ? /*#__PURE__*/react_dom.createPortal(renderInput(inputProps, instanceOptions, ref), container) : null;
const FileInputField = /*#__PURE__*/(0,react.memo)(/*#__PURE__*/(0,react.forwardRef)(({
  container,
  noPortal,
  ...inputProps
}, ref) => {
  const instanceOptions = (0,lib_esm/* useUploadOptions */.bn)();
  const isValidContainer = container && container.nodeType === 1;
  (0,esm/* invariant */.V1)(isValidContainer || !(0,esm/* hasWindow */.Vd)(), NO_CONTAINER_ERROR_MSG);
  return noPortal ? renderInput(inputProps, instanceOptions, ref) : renderInPortal(container, isValidContainer, inputProps, instanceOptions, ref);
}));
const Uploady = props => {
  const {
    multiple = true,
    capture,
    accept,
    webkitdirectory,
    children,
    inputFieldContainer,
    customInput,
    fileInputId,
    noPortal = false,
    ...noDomProps
  } = props;
  const container = !customInput ? inputFieldContainer || ((0,esm/* hasWindow */.Vd)() ? document.body : null) : null;
  const internalInputFieldRef = (0,react.useRef)();
  return /*#__PURE__*/react.createElement(lib_esm/* NoDomUploady */.O3, _extends({}, noDomProps, {
    inputRef: internalInputFieldRef
  }), !customInput ? /*#__PURE__*/react.createElement(FileInputField, {
    container: container,
    multiple: multiple,
    capture: capture,
    accept: accept,
    webkitdirectory: webkitdirectory?.toString(),
    style: {
      display: "none"
    },
    ref: internalInputFieldRef,
    id: fileInputId,
    noPortal: noPortal
  }) : null, children);
};
/* harmony default export */ const esm_Uploady = (Uploady);
;// ./node_modules/@rpldy/uploady/lib/esm/useFileInput.js



const getUrl = form => {
  const loc = window.location;
  let url = form.getAttribute("action") || "";
  url = url.replace(/\s/g, "");
  let path;
  switch (true) {
    case url === "":
      url = loc.href;
      break;
    case url.startsWith("/"):
      url = `${loc.protocol}//${loc.host}${url}`;
      break;
    case !/:\/\//.test(url):
      path = loc.pathname.split("/").slice(0, -1).concat("").join("/");
      url = `${loc.protocol}//${loc.host}${path}${url}`;
      break;
  }
  return url;
};
const getNewDestination = (input, form) => {
  const method = form?.getAttribute("method"),
    url = form && getUrl(form);
  return {
    filesParamName: input.getAttribute("name"),
    method: method ? method.toUpperCase() : undefined,
    url: url
  };
};
const retrieveDestinationFromInput = (input, onUpdate) => {
  let destination, stopObserving;
  const form = input.closest("form");
  if (form) {
    destination = getNewDestination(input, form);
    logger.debugLog(`Uploady.useFileInput: using custom input's parent form url ${destination.url || ""} and method ${destination.method || ""}`);
    let observer = new MutationObserver(records => {
      if (records[0]?.attributeName === "action") {
        const newDestination = getNewDestination(input, form);
        if (newDestination.url) {
          logger.debugLog(`Uploady.useFileInput: form action attribute changed to ${newDestination.url}`);
          onUpdate(newDestination);
        }
      }
    });
    observer?.observe(form, {
      attributes: true,
      attributeFilter: ["action"]
    });
    stopObserving = () => {
      observer?.disconnect();
      observer = null;
    };
  }
  onUpdate(destination || getNewDestination(input));
  return {
    stopObserving
  };
};
const useFileInput = fileInputRef => {
  const context = useUploadyContext();
  if (fileInputRef) {
    context.setExternalFileInput(fileInputRef);
  }
  useEffect(() => {
    let stopObservingCallback;
    if (fileInputRef?.current && "closest" in fileInputRef.current) {
      const input = fileInputRef.current;
      const uploaderOptions = context.getOptions();
      if (!uploaderOptions.destination || !uploaderOptions.destination.url) {
        const {
          stopObserving
        } = retrieveDestinationFromInput(input, newDestination => {
          context.setOptions({
            destination: newDestination
          });
        });
        stopObservingCallback = stopObserving;
      }
    }
    return () => {
      stopObservingCallback?.();
    };
  }, [fileInputRef, context]);
  return !!fileInputRef ? fileInputRef : context.getInternalFileInput();
};
/* harmony default export */ const esm_useFileInput = ((/* unused pure expression or super */ null && (useFileInput)));
// EXTERNAL MODULE: ./node_modules/@rpldy/uploader/lib/esm/index.js + 36 modules
var uploader_lib_esm = __webpack_require__(46472);
;// ./node_modules/@rpldy/uploady/lib/esm/index.js

/* harmony default export */ const uploady_lib_esm = (esm_Uploady);





/***/ }),

/***/ 46472:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  x0: () => (/* reexport */ UPLOADER_EVENTS),
  Ay: () => (/* binding */ uploader_lib_esm)
});

// UNUSED EXPORTS: BATCH_STATES, DEFAULT_OPTIONS, FILE_STATES, MissingUrlError, XHR_SENDER_TYPE, composeEnhancers, createUploader, getXhrSend, send

// EXTERNAL MODULE: ./node_modules/@rpldy/shared/lib/esm/index.js + 22 modules
var esm = __webpack_require__(95785);
;// ./node_modules/@rpldy/life-events/lib/esm/defaults.js

const defaults = (0,esm/* devFreeze */.fO)({
  allowRegisterNonExistent: true,
  canAddEvents: true,
  canRemoveEvents: true,
  collectStats: false
});
/* harmony default export */ const esm_defaults = (defaults);
;// ./node_modules/@rpldy/life-events/lib/esm/utils.js

const validateFunction = (f, name) => {
  if (!(0,esm/* isFunction */.Tn)(f)) {
    throw new Error(`'${name}' is not a valid function`);
  }
};
const isUndefined = val => typeof val === "undefined";

;// ./node_modules/@rpldy/life-events/lib/esm/consts.js
const LESYM = Symbol.for("__le__");
const LE_PACK_SYM = Symbol.for("__le__pack__");
;// ./node_modules/@rpldy/life-events/lib/esm/lifeEvents.js




const getLE = obj => obj ? obj[LESYM] : null;
const getValidLE = obj => {
  const le = getLE(obj);
  if (!le) {
    throw new Error("Didnt find LE internal object. Something very bad happened!");
  }
  return le;
};
const isLE = obj => !!getLE(obj);
const addRegistration = (obj, name, cb, once = false) => {
  validateFunction(cb, "cb");
  const le = getValidLE(obj);
  if (!le.options.allowRegisterNonExistent && !~le.events.indexOf(name)) {
    throw new Error(`Cannot register for event ${name.toString()} that wasn't already defined (allowRegisterNonExistent = false)`);
  }
  const namedRegistry = le.registry[name] || [];
  if (!namedRegistry.find(r => r.cb === cb)) {
    namedRegistry.push({
      name,
      cb,
      once
    });
    le.registry[name] = namedRegistry;
  }
  return () => unregister.call(obj, name, cb);
};
const findRegistrations = (obj, name) => {
  const registry = getValidLE(obj).registry;
  return name ? registry[name] ? registry[name].slice() : [] : Object.values(registry).flat();
};
const publicMethods = {
  "on": register,
  "once": registerOnce,
  "off": unregister,
  "getEvents": getEvents
};
const getPublicMethods = () => Object.entries(publicMethods).reduce((res, [key, m]) => {
  res[key] = {
    value: m
  };
  return res;
}, {});
const apiMethods = {
  "trigger": trigger,
  "addEvent": addEvent,
  "removeEvent": removeEvent,
  "hasEvent": hasEvent,
  "hasEventRegistrations": hasEventRegistrations,
  "assign": lifeEvents_assign
};
const createApi = target => Object.entries(apiMethods).reduce((res, [name, fn]) => {
  res[name] = fn.bind(target);
  return res;
}, {
  ...apiMethods,
  target
});
const cleanRegistryForName = (obj, name, force = false) => {
  const registry = getValidLE(obj).registry;
  if (registry[name] && (force || !registry[name].length)) {
    delete registry[name];
  }
};
const removeRegItem = (obj, name, cb) => {
  const registry = getValidLE(obj).registry;
  if (registry[name]) {
    if (!cb) {
      cleanRegistryForName(obj, name, true);
    } else {
      registry[name] = registry[name].filter(reg => reg.cb !== cb);
      cleanRegistryForName(obj, name);
    }
  }
};
function register(name, cb) {
  return addRegistration(this, name, cb);
}
function registerOnce(name, cb) {
  return addRegistration(this, name, cb, true);
}
function unregister(name, cb) {
  removeRegItem(this, name, cb);
}
function getEvents() {
  return getValidLE(this).events.slice();
}
function trigger(name, ...args) {
  const regs = findRegistrations(this, name);
  let results;
  if (regs.length) {
    let packValue;
    if (args.length === 1 && args[0]?.[LE_PACK_SYM] === true) {
      packValue = args[0].resolve();
    }
    results = regs.map(r => {
      let result;
      if (r.once) {
        removeRegItem(this, name, r.cb);
      }
      if (packValue) {
        result = r.cb(...packValue);
      } else if (!args.length) {
        result = r.cb();
      } else if (args.length === 1) {
        result = r.cb(args[0]);
      } else if (args.length === 2) {
        result = r.cb(args[0], args[1]);
      } else if (args.length === 3) {
        result = r.cb(args[0], args[1], args[2]);
      } else {
        result = r.cb(...args);
      }
      return result;
    }).filter(result => !isUndefined(result)).map(result => (0,esm/* isPromise */.yL)(result) ? result : Promise.resolve(result));
  }
  return results && (results.length ? results : undefined);
}
function lifeEvents_assign(toObj) {
  const le = getValidLE(this);
  defineLifeData(toObj, le.options, le.events, le.registry, le.stats);
  return createApi(toObj);
}
function addEvent(name) {
  const le = getValidLE(this);
  if (le.options.canAddEvents) {
    const index = le.events.indexOf(name);
    if (!~index) {
      le.events.push(name);
    } else {
      throw new Error(`Event '${name}' already defined`);
    }
  } else {
    throw new Error("Cannot add new events (canAddEvents = false)");
  }
}
function removeEvent(name) {
  const le = getValidLE(this);
  if (le.options.canRemoveEvents) {
    const index = le.events.indexOf(name);
    le.events.splice(index, 1);
  } else {
    throw new Error("Cannot remove events (canRemoveEvents = false)");
  }
}
function hasEvent(name) {
  const le = getValidLE(this);
  return !!~le.events.indexOf(name);
}
function hasEventRegistrations(name) {
  return !!findRegistrations(this, name).length;
}
const defineLifeData = (target, options, events = [], registry = {}, stats = {}) => {
  Object.defineProperties(target, {
    [LESYM]: {
      value: Object.seal({
        registry,
        events,
        options,
        stats
      })
    },
    ...getPublicMethods()
  });
};
const addLife = (target, events = [], options) => {
  const useTarget = target || {};
  const usedOptions = {
    ...esm_defaults,
    ...options
  };
  if (!isLE(useTarget)) {
    defineLifeData(useTarget, usedOptions, events);
  }
  return createApi(useTarget);
};
/* harmony default export */ const lifeEvents = (addLife);

;// ./node_modules/@rpldy/life-events/lib/esm/lifePack.js

const createLifePack = creator => {
  const lp = {
    resolve: () => [].concat(creator())
  };
  Object.defineProperty(lp, LE_PACK_SYM, {
    value: true,
    configurable: false
  });
  return lp;
};
/* harmony default export */ const lifePack = (createLifePack);
;// ./node_modules/@rpldy/life-events/lib/esm/index.js


;// ./node_modules/@rpldy/abort/lib/esm/fastAbort.js
const fastAbortBatch = (batch, aborts) => {
  batch.items.forEach(({
    id
  }) => aborts[id]?.());
};
const fastAbortAll = aborts => {
  Object.values(aborts).forEach(fn => fn());
};

;// ./node_modules/@rpldy/abort/lib/esm/abort.js


const abortNonUploadingItem = (item, aborts, finalizeItem) => {
  esm/* logger.debugLog */.vF.debugLog(`abort: aborting ${item.state.valueOf()} item  - `, item);
  finalizeItem(item.id, {
    status: 0,
    state: esm/* FILE_STATES */.aN.ABORTED,
    response: "aborted"
  });
  return true;
};
const ITEM_STATE_ABORTS = {
  [esm/* FILE_STATES */.aN.UPLOADING]: (item, aborts) => {
    esm/* logger.debugLog */.vF.debugLog(`abort: aborting uploading item  - `, item);
    return aborts[item.id]();
  },
  [esm/* FILE_STATES */.aN.ADDED]: abortNonUploadingItem,
  [esm/* FILE_STATES */.aN.PENDING]: abortNonUploadingItem
};
const callAbortOnItem = (item, aborts, finalizeItem) => {
  const itemState = item?.state;
  const method = !!itemState && ITEM_STATE_ABORTS[itemState.valueOf()];
  return method ? method(item, aborts, finalizeItem) : false;
};
const abortItem = (id, items, aborts, finalizeItem) => callAbortOnItem(items[id], aborts, finalizeItem);
const getIsFastAbortNeeded = (count, threshold) => {
  let result = false;
  if (threshold !== 0 && threshold) {
    result = count >= threshold;
  }
  return result;
};
const abortAll = (items, aborts, queue, finalizeItem, options) => {
  const itemIds = Object.values(queue).flat();
  const isFastAbort = getIsFastAbortNeeded(itemIds.length, options.fastAbortThreshold);
  esm/* logger.debugLog */.vF.debugLog(`abort: doing abort-all (${isFastAbort ? "fast" : "normal"} abort)`);
  if (isFastAbort) {
    fastAbortAll(aborts);
  } else {
    itemIds.forEach(id => abortItem(id, items, aborts, finalizeItem));
  }
  return {
    isFast: isFastAbort
  };
};
const abortBatch = (batch, batchOptions, aborts, queue, finalizeItem, options) => {
  const threshold = batchOptions.fastAbortThreshold === 0 ? 0 : batchOptions.fastAbortThreshold || options.fastAbortThreshold;
  const isFastAbort = getIsFastAbortNeeded(queue[batch.id].length, threshold);
  esm/* logger.debugLog */.vF.debugLog(`abort: doing abort-batch on: ${batch.id} (${isFastAbort ? "fast" : "normal"} abort)`);
  if (isFastAbort) {
    fastAbortBatch(batch, aborts);
  } else {
    batch.items.forEach(bi => callAbortOnItem(bi, aborts, finalizeItem));
  }
  return {
    isFast: isFastAbort
  };
};

;// ./node_modules/@rpldy/abort/lib/esm/getAbortEnhancer.js

const getAbortEnhancer = () => {
  return uploader => {
    uploader.update({
      abortAll: abortAll,
      abortBatch: abortBatch,
      abortItem: abortItem
    });
    return uploader;
  };
};
/* harmony default export */ const esm_getAbortEnhancer = (getAbortEnhancer);
;// ./node_modules/@rpldy/abort/lib/esm/index.js

/* harmony default export */ const lib_esm = (esm_getAbortEnhancer);
;// ./node_modules/@rpldy/uploader/lib/esm/consts.js

const UPLOADER_EVENTS = (0,esm/* devFreeze */.fO)({
  BATCH_ADD: "BATCH-ADD",
  BATCH_START: "BATCH-START",
  BATCH_PROGRESS: "BATCH_PROGRESS",
  BATCH_FINISH: "BATCH-FINISH",
  BATCH_ABORT: "BATCH-ABORT",
  BATCH_CANCEL: "BATCH-CANCEL",
  BATCH_ERROR: "BATCH-ERROR",
  BATCH_FINALIZE: "BATCH-FINALIZE",
  ITEM_START: "FILE-START",
  ITEM_CANCEL: "FILE-CANCEL",
  ITEM_PROGRESS: "FILE-PROGRESS",
  ITEM_FINISH: "FILE-FINISH",
  ITEM_ABORT: "FILE-ABORT",
  ITEM_ERROR: "FILE-ERROR",
  ITEM_FINALIZE: "FILE-FINALIZE",
  REQUEST_PRE_SEND: "REQUEST_PRE_SEND",
  ALL_ABORT: "ALL_ABORT"
});
const PROGRESS_DELAY = 50;
const SENDER_EVENTS = (0,esm/* devFreeze */.fO)({
  ITEM_PROGRESS: "ITEM_PROGRESS",
  BATCH_PROGRESS: "BATCH_PROGRESS"
});
const ITEM_FINALIZE_STATES = [esm/* FILE_STATES */.aN.FINISHED, esm/* FILE_STATES */.aN.ERROR, esm/* FILE_STATES */.aN.CANCELLED, esm/* FILE_STATES */.aN.ABORTED];
;// ./node_modules/@rpldy/simple-state/lib/esm/consts.js
const PROXY_SYM = Symbol.for("__rpldy-sstt-proxy__");
const STATE_SYM = Symbol.for("__rpldy-sstt-state__");
;// ./node_modules/@rpldy/simple-state/lib/esm/utils.js


const isProxy = obj => !(0,esm/* isProduction */.KV)() && !!obj && !!~Object.getOwnPropertySymbols(obj).indexOf(PROXY_SYM);
const isNativeFile = obj => (0,esm/* hasWindow */.Vd)() && obj instanceof File || obj.name && obj.size && obj.uri;
const isProxiable = obj => Array.isArray(obj) || (0,esm/* isPlainObject */.Qd)(obj) && !isNativeFile(obj);

;// ./node_modules/@rpldy/simple-state/lib/esm/createState.js



const mergeWithSymbols = (0,esm/* getMerge */.fd)({
  withSymbols: true,
  predicate: key => key !== PROXY_SYM && key !== STATE_SYM
});
const getIsUpdateable = proxy => (0,esm/* isProduction */.KV)() ? true : proxy[STATE_SYM].isUpdateable;
const setIsUpdateable = (proxy, value) => {
  if (!(0,esm/* isProduction */.KV)()) {
    proxy[STATE_SYM].isUpdateable = value;
  }
};
const deepProxy = (obj, traps) => {
  let proxy;
  if (isProxiable(obj)) {
    if (!isProxy(obj)) {
      obj[PROXY_SYM] = true;
      proxy = new Proxy(obj, traps);
    }
    Object.keys(obj).forEach(key => {
      obj[key] = deepProxy(obj[key], traps);
    });
  }
  return proxy || obj;
};
const unwrapProxy = proxy => isProxy(proxy) ? (0,esm/* clone */.o8)(proxy, mergeWithSymbols) : proxy;
const createState = obj => {
  const traps = {
    set: (obj, key, value) => {
      if (getIsUpdateable(proxy)) {
        obj[key] = deepProxy(value, traps);
      }
      return true;
    },
    get: (obj, key) => {
      return key === PROXY_SYM ? unwrapProxy(obj) : obj[key];
    },
    defineProperty: () => {
      throw new Error("Simple State doesnt support defining property");
    },
    setPrototypeOf: () => {
      throw new Error("Simple State doesnt support setting prototype");
    },
    deleteProperty: (obj, key) => {
      if (getIsUpdateable(proxy)) {
        delete obj[key];
      }
      return true;
    }
  };
  if (!(0,esm/* isProduction */.KV)() && !isProxy(obj)) {
    Object.defineProperty(obj, STATE_SYM, {
      value: {
        isUpdateable: false
      },
      configurable: true
    });
  }
  const proxy = !(0,esm/* isProduction */.KV)() ? deepProxy(obj, traps) : obj;
  return {
    state: proxy,
    update: fn => {
      if (!(0,esm/* isProduction */.KV)() && getIsUpdateable(proxy)) {
        throw new Error("Can't call update on State already being updated!");
      }
      try {
        setIsUpdateable(proxy, true);
        fn(proxy);
      } finally {
        setIsUpdateable(proxy, false);
      }
      return proxy;
    },
    unwrap: entry => entry ? unwrapProxy(entry) : isProxy(proxy) ? unwrapProxy(proxy) : proxy
  };
};
/* harmony default export */ const esm_createState = (createState);

;// ./node_modules/@rpldy/simple-state/lib/esm/index.js


;// ./node_modules/@rpldy/uploader/lib/esm/queue/itemHelpers.js

const finalizeItem = (queue, id, delItem = false) => {
  queue.updateState(state => {
    const {
      batchId
    } = state.items[id] || {
      batchId: null
    };
    if (delItem) {
      delete state.items[id];
    }
    const index = batchId ? state.itemQueue[batchId].indexOf(id) : -1;
    if (~index && batchId) {
      state.itemQueue[batchId].splice(index, 1);
    }
    const activeIndex = state.activeIds.indexOf(id);
    if (~activeIndex) {
      state.activeIds.splice(activeIndex, 1);
    }
    if (batchId && state.batches[batchId].itemBatchOptions[id]) {
      delete state.batches[batchId].itemBatchOptions[id];
    }
  });
};
const getIsItemExists = (queue, itemId) => !!queue.getState().items[itemId];
const getIsItemFinalized = item => ITEM_FINALIZE_STATES.includes(item.state);

;// ./node_modules/@rpldy/uploader/lib/esm/queue/preSendPrepare.js


const mergeWithUndefined = (0,esm/* getMerge */.fd)({
  undefinedOverwrites: true
});
const processPrepareResponse = (eventType, items, options, updated) => {
  let usedOptions = options,
    usedItems = items;
  if (updated && typeof updated !== "boolean") {
    esm/* logger.debugLog */.vF.debugLog(`uploader.queue: REQUEST_PRE_SEND(${eventType}) event returned updated items/options`, updated);
    if (updated.items) {
      if (updated.items.length !== items.length || !(0,esm/* isSamePropInArrays */.hR)(updated.items, items, ["id", "batchId", "recycled"])) {
        throw new Error(`REQUEST_PRE_SEND(${eventType}) event handlers must return same items with same ids`);
      }
      usedItems = updated.items;
    }
    if (updated.options) {
      usedOptions = mergeWithUndefined({}, options, updated.options);
    }
  }
  return {
    items: usedItems,
    options: usedOptions,
    cancelled: updated === false
  };
};
const triggerItemsPrepareEvent = (queue, eventSubject, items, options, eventType, validateResponse) => (0,esm/* triggerUpdater */.w$)(queue.trigger, eventType, eventSubject, options).then(updated => {
  validateResponse?.(updated);
  return processPrepareResponse(eventType, items, options, updated);
});
const persistPrepareResponse = (queue, prepared) => {
  const batchId = prepared.items[0].batchId;
  if (prepared.items[0] && queue.getState().batches[batchId]) {
    queue.updateState(state => {
      prepared.items.forEach(i => {
        if (!getIsItemFinalized(state.items[i.id])) {
          state.items[i.id] = i;
        }
      });
      const batchData = state.batches[batchId];
      prepared.items.forEach(({
        id
      }) => {
        batchData.itemBatchOptions[id] = prepared.options;
      });
    });
    const updatedState = queue.getState();
    prepared.items = prepared.items.map(item => updatedState.items[item.id]);
    const batchData = updatedState.batches[batchId];
    prepared.options = batchData.itemBatchOptions[prepared.items[0].id] || batchData.batchOptions;
  }
};
const prepareItems = (queue, subject, retrieveItemsFromSubject, createEventSubject, validateResponse, eventType) => {
  const items = retrieveItemsFromSubject(subject);
  const batchOptions = queue.getState().batches[items[0].batchId].batchOptions;
  const eventSubject = createEventSubject?.(subject, batchOptions) || subject;
  return triggerItemsPrepareEvent(queue, eventSubject, items, batchOptions, eventType, validateResponse).then(prepared => {
    if (!prepared.cancelled) {
      persistPrepareResponse(queue, prepared);
    }
    return prepared;
  });
};
const getItemsPrepareUpdater = (eventType, retrieveItemsFromSubject, createEventSubject = null, validateResponse = null) => (queue, subject) => prepareItems(queue, subject, retrieveItemsFromSubject, createEventSubject, validateResponse, eventType);

;// ./node_modules/@rpldy/uploader/lib/esm/queue/batchHelpers.js





const prepareBatchStartItems = getItemsPrepareUpdater(UPLOADER_EVENTS.BATCH_START, batch => batch.items, null, ({
  batch
} = {
  batch: false
}) => {
  if (batch) {
    throw new Error(`BATCH_START event handlers cannot update batch data. Only items & options`);
  }
});
const BATCH_READY_STATES = [esm/* BATCH_STATES */.mX.ADDED, esm/* BATCH_STATES */.mX.PROCESSING, esm/* BATCH_STATES */.mX.UPLOADING];
const BATCH_FINISHED_STATES = [esm/* BATCH_STATES */.mX.ABORTED, esm/* BATCH_STATES */.mX.CANCELLED, esm/* BATCH_STATES */.mX.FINISHED, esm/* BATCH_STATES */.mX.ERROR];
const getBatchFromState = (state, id) => state.batches[id].batch;
const getBatch = (queue, id) => {
  return getBatchFromState(queue.getState(), id);
};
const getBatchDataFromItemId = (queue, itemId) => {
  const state = queue.getState();
  const item = state.items[itemId];
  return state.batches[item.batchId];
};
const getBatchFromItemId = (queue, itemId) => {
  return getBatchDataFromItemId(queue, itemId).batch;
};
const removeBatchItems = (queue, batchId) => {
  const batch = getBatch(queue, batchId);
  batch.items.forEach(({
    id
  }) => finalizeItem(queue, id, true));
};
const removeBatch = (queue, batchId) => {
  queue.updateState(state => {
    delete state.batches[batchId];
    delete state.itemQueue[batchId];
    const batchQueueIndex = state.batchQueue.indexOf(batchId);
    if (~batchQueueIndex) {
      state.batchQueue.splice(batchQueueIndex, 1);
    }
    const pendingFlagIndex = state.batchesStartPending.indexOf(batchId);
    if (~pendingFlagIndex) {
      state.batchesStartPending.splice(pendingFlagIndex, 1);
    }
  });
};
const finalizeBatch = (queue, batchId, eventType, finalState = esm/* BATCH_STATES */.mX.FINISHED, additionalInfo) => {
  queue.updateState(state => {
    const batch = getBatchFromState(state, batchId);
    batch.state = finalState;
    if (additionalInfo) {
      batch.additionalInfo = additionalInfo;
    }
  });
  triggerUploaderBatchEvent(queue, batchId, eventType);
  triggerUploaderBatchEvent(queue, batchId, UPLOADER_EVENTS.BATCH_FINALIZE);
};
const cancelBatchWithId = (queue, batchId) => {
  esm/* logger.debugLog */.vF.debugLog("uploady.uploader.batchHelpers: cancelling batch: ", batchId);
  finalizeBatch(queue, batchId, UPLOADER_EVENTS.BATCH_CANCEL, esm/* BATCH_STATES */.mX.CANCELLED);
  removeBatchItems(queue, batchId);
  removeBatch(queue, batchId);
};
const cancelBatchForItem = (queue, itemId) => {
  if (getIsItemExists(queue, itemId)) {
    const data = getBatchDataFromItemId(queue, itemId),
      batchId = data?.batch.id;
    if (batchId) {
      cancelBatchWithId(queue, batchId);
    } else {
      esm/* logger.debugLog */.vF.debugLog(`uploady.uploader.batchHelpers: cancel batch called for batch already removed (item id = ${itemId})`);
    }
  }
};
const failBatchForItem = (queue, itemId, err) => {
  const batch = getBatchFromItemId(queue, itemId),
    batchId = batch.id;
  esm/* logger.debugLog */.vF.debugLog("uploady.uploader.batchHelpers: failing batch: ", {
    batch
  });
  finalizeBatch(queue, batchId, UPLOADER_EVENTS.BATCH_ERROR, esm/* BATCH_STATES */.mX.ERROR, err.message);
  removeBatchItems(queue, batchId);
  removeBatch(queue, batchId);
};
const isItemBatchStartPending = (queue, itemId) => {
  const batch = getBatchFromItemId(queue, itemId);
  return queue.getState().batchesStartPending.includes(batch.id);
};
const isNewBatchStarting = (queue, itemId) => {
  const batch = getBatchFromItemId(queue, itemId);
  return queue.getState().currentBatch !== batch.id;
};
const loadNewBatchForItem = (queue, itemId) => {
  const batch = getBatchFromItemId(queue, itemId);
  queue.updateState(state => {
    state.batchesStartPending.push(batch.id);
  });
  return prepareBatchStartItems(queue, batch).then(({
    cancelled
  }) => {
    let alreadyFinished = false;
    queue.updateState(state => {
      const pendingFlagIndex = state.batchesStartPending.indexOf(batch.id);
      state.batchesStartPending.splice(pendingFlagIndex, 1);
    });
    if (!cancelled) {
      alreadyFinished = !getIsItemExists(queue, itemId);
      if (!alreadyFinished) {
        queue.updateState(state => {
          state.currentBatch = batch.id;
        });
      }
    }
    return !cancelled && !alreadyFinished;
  });
};
const cleanUpFinishedBatches = queue => {
  (0,esm/* scheduleIdleWork */.tD)(() => {
    const state = queue.getState();
    Object.keys(state.batches).forEach(batchId => {
      const {
        batch,
        finishedCounter
      } = state.batches[batchId];
      const {
        orgItemCount
      } = batch;
      const alreadyFinalized = getIsBatchFinalized(batch);
      if (orgItemCount === finishedCounter) {
        if (!alreadyFinalized && batch.completed !== 100) {
          queue.updateState(state => {
            const batch = getBatchFromState(state, batchId);
            batch.completed = 100;
            batch.loaded = batch.items.reduce((res, {
              loaded
            }) => res + loaded, 0);
          });
          triggerUploaderBatchEvent(queue, batchId, UPLOADER_EVENTS.BATCH_PROGRESS);
        }
        queue.updateState(state => {
          if (state.currentBatch === batchId) {
            state.currentBatch = null;
          }
        });
        esm/* logger.debugLog */.vF.debugLog(`uploady.uploader.batchHelpers: cleaning up batch: ${batch.id}`);
        if (!alreadyFinalized) {
          finalizeBatch(queue, batchId, UPLOADER_EVENTS.BATCH_FINISH);
        }
        removeBatchItems(queue, batchId);
        removeBatch(queue, batchId);
      }
    });
  });
};
const triggerUploaderBatchEvent = (queue, batchId, event) => {
  const state = queue.getState(),
    {
      batch,
      batchOptions
    } = state.batches[batchId],
    stateItems = state.items;
  const eventBatch = {
    ...unwrapProxy(batch),
    items: batch.items.map(({
      id
    }) => unwrapProxy(stateItems[id]))
  };
  queue.trigger(event, eventBatch, unwrapProxy(batchOptions));
};
const getIsBatchReady = (queue, batchId) => {
  const batch = getBatchFromState(queue.getState(), batchId);
  return BATCH_READY_STATES.includes(batch.state);
};
const detachRecycledFromPreviousBatch = (queue, item) => {
  const {
    previousBatch
  } = item;
  if (item.recycled && previousBatch && queue.getState().batches[previousBatch]) {
    const {
      id: batchId
    } = getBatchFromItemId(queue, item.id);
    if (batchId === previousBatch) {
      queue.updateState(state => {
        const batch = getBatchFromState(state, batchId);
        const index = batch.items.findIndex(({
          id
        }) => id === item.id);
        if (~index) {
          batch.items.splice(index, 1);
        }
        if (state.batches[batchId].itemBatchOptions[item.id]) {
          delete state.batches[batchId].itemBatchOptions[item.id];
        }
      });
    }
  }
};
const preparePendingForUpload = (queue, uploadOptions) => {
  queue.updateState(state => {
    Object.keys(state.batches).forEach(batchId => {
      const batchData = state.batches[batchId];
      const {
        batch,
        batchOptions
      } = batchData;
      if (batch.state === esm/* BATCH_STATES */.mX.PENDING) {
        batch.items.forEach(item => {
          item.state = esm/* FILE_STATES */.aN.ADDED;
        });
        batch.state = esm/* BATCH_STATES */.mX.ADDED;
        batchData.batchOptions = (0,esm/* merge */.h1)({}, batchOptions, uploadOptions);
      }
    });
  });
};
const removePendingBatches = queue => {
  const batches = queue.getState().batches;
  Object.keys(batches).filter(batchId => batches[batchId].batch.state === esm/* BATCH_STATES */.mX.PENDING).forEach(batchId => {
    removeBatchItems(queue, batchId);
    removeBatch(queue, batchId);
  });
};
const incrementBatchFinishedCounter = (queue, batchId) => {
  queue.updateState(state => {
    state.batches[batchId].finishedCounter += 1;
  });
};
const getIsBatchFinalized = batch => BATCH_FINISHED_STATES.includes(batch.state);
const clearBatchData = (queue, batchId) => {
  queue.updateState(state => {
    const {
      items
    } = getBatchFromState(state, batchId);
    delete state.batches[batchId];
    delete state.itemQueue[batchId];
    const indx = state.batchQueue.indexOf(batchId);
    if (~indx) {
      state.batchQueue.splice(indx, 1);
    }
    if (state.currentBatch === batchId) {
      state.currentBatch = null;
    }
    items.forEach(({
      id
    }) => {
      delete state.items[id];
      const activeIndex = state.activeIds.indexOf(id);
      if (~activeIndex) {
        state.activeIds.splice(activeIndex, 1);
      }
    });
  });
};

;// ./node_modules/@rpldy/uploader/lib/esm/queue/processFinishedRequest.js




const FILE_STATE_TO_EVENT_MAP = {
  [esm/* FILE_STATES */.aN.PENDING.valueOf()]: null,
  [esm/* FILE_STATES */.aN.ADDED.valueOf()]: UPLOADER_EVENTS.ITEM_START,
  [esm/* FILE_STATES */.aN.FINISHED.valueOf()]: UPLOADER_EVENTS.ITEM_FINISH,
  [esm/* FILE_STATES */.aN.ERROR.valueOf()]: UPLOADER_EVENTS.ITEM_ERROR,
  [esm/* FILE_STATES */.aN.CANCELLED.valueOf()]: UPLOADER_EVENTS.ITEM_CANCEL,
  [esm/* FILE_STATES */.aN.ABORTED.valueOf()]: UPLOADER_EVENTS.ITEM_ABORT,
  [esm/* FILE_STATES */.aN.UPLOADING.valueOf()]: UPLOADER_EVENTS.ITEM_PROGRESS
};
const getIsFinalized = item => !!~ITEM_FINALIZE_STATES.indexOf(item.state);
const processFinishedRequest = (queue, finishedData, next) => {
  finishedData.forEach(itemData => {
    const state = queue.getState();
    const {
      id,
      info
    } = itemData;
    esm/* logger.debugLog */.vF.debugLog("uploader.processor.queue: request finished for item - ", {
      id,
      info
    });
    if (state.items[id]) {
      queue.updateState(state => {
        const item = state.items[id];
        item.state = info.state;
        item.uploadResponse = info.response;
        item.uploadStatus = info.status;
        if (getIsFinalized(item)) {
          delete state.aborts[id];
        }
      });
      const item = queue.getState().items[id];
      if (info.state === esm/* FILE_STATES */.aN.FINISHED && item.completed < 100) {
        const size = item.file?.size || 0;
        queue.handleItemProgress(item, 100, size, size);
      }
      const {
        itemBatchOptions
      } = getBatchDataFromItemId(queue, id);
      const batchOptions = itemBatchOptions[id];
      const itemState = item.state.valueOf();
      if (FILE_STATE_TO_EVENT_MAP[itemState]) {
        queue.trigger(FILE_STATE_TO_EVENT_MAP[itemState], item, batchOptions);
      }
      if (getIsFinalized(item)) {
        incrementBatchFinishedCounter(queue, item.batchId);
        queue.trigger(UPLOADER_EVENTS.ITEM_FINALIZE, item, batchOptions);
      }
    }
    finalizeItem(queue, id);
  });
  cleanUpFinishedBatches(queue);
  next(queue);
};
/* harmony default export */ const queue_processFinishedRequest = (processFinishedRequest);
;// ./node_modules/@rpldy/uploader/lib/esm/queue/processBatchItems.js






const preparePreRequestItems = getItemsPrepareUpdater(UPLOADER_EVENTS.REQUEST_PRE_SEND, items => items, (items, options) => ({
  items,
  options
}));
const updateUploadingState = (queue, items, sendResult) => {
  queue.updateState(state => {
    items.forEach(bi => {
      const item = state.items[bi.id];
      item.state = esm/* FILE_STATES */.aN.UPLOADING;
      state.aborts[bi.id] = sendResult.abort;
    });
  });
};
const sendAllowedItems = (queue, itemsSendData, next) => {
  const {
    items,
    options
  } = itemsSendData;
  const batch = queue.getState().batches[items[0].batchId]?.batch;
  if (batch) {
    let sendResult;
    try {
      sendResult = queue.sender.send(items, batch, options);
    } catch (ex) {
      esm/* logger.debugLog */.vF.debugLog(`uploader.queue: sender failed with unexpected error`, ex);
      sendResult = {
        request: Promise.resolve({
          status: 0,
          state: esm/* FILE_STATES */.aN.ERROR,
          response: ex.message
        }),
        abort: () => false,
        senderType: "exception-handler"
      };
    }
    const {
      request
    } = sendResult;
    updateUploadingState(queue, items, sendResult);
    request.then(requestInfo => {
      const finishedData = items.map(item => ({
        id: item.id,
        info: requestInfo
      }));
      queue_processFinishedRequest(queue, finishedData, next);
    });
  }
};
const reportCancelledItems = (queue, items, cancelledResults, next) => {
  const cancelledItemsIds = cancelledResults.map((isCancelled, index) => isCancelled ? items[index].id : null).filter(Boolean);
  if (cancelledItemsIds.length) {
    const finishedData = cancelledItemsIds.map(id => ({
      id,
      info: {
        status: 0,
        state: esm/* FILE_STATES */.aN.CANCELLED,
        response: "cancel"
      }
    }));
    queue_processFinishedRequest(queue, finishedData, next);
  }
  return !!cancelledItemsIds.length;
};
const reportPreparedError = (error, queue, items, next) => {
  const finishedData = items.map(({
    id
  }) => ({
    id,
    info: {
      status: 0,
      state: esm/* FILE_STATES */.aN.ERROR,
      response: error
    }
  }));
  queue_processFinishedRequest(queue, finishedData, next);
};
const getAllowedItem = (id, queue) => {
  const item = queue.getState().items[id];
  return item && !getIsItemFinalized(item) ? item : undefined;
};
const processAllowedItems = ({
  allowedItems,
  cancelledResults,
  queue,
  items,
  ids,
  next
}) => {
  const afterPreparePromise = allowedItems.length ? preparePreRequestItems(queue, allowedItems) : Promise.resolve();
  let finalCancelledResults = cancelledResults;
  return afterPreparePromise.catch(err => {
    esm/* logger.debugLog */.vF.debugLog("uploader.queue: encountered error while preparing items for request", err);
    reportPreparedError(err, queue, items, next);
  }).then(itemsSendData => {
    let nextP;
    if (itemsSendData) {
      if (itemsSendData.cancelled) {
        finalCancelledResults = ids.map(() => true);
      } else {
        const hasAborted = itemsSendData.items.some(item => getIsItemFinalized(item));
        if (!hasAborted) {
          sendAllowedItems(queue, {
            items: itemsSendData.items,
            options: itemsSendData.options
          }, next);
        } else {
          esm/* logger.debugLog */.vF.debugLog("uploader.queue: send data contains aborted items - not sending");
        }
      }
    }
    if (!reportCancelledItems(queue, items, finalCancelledResults, next)) {
      nextP = next(queue);
    }
    return nextP;
  });
};
const processBatchItems = (queue, ids, next) => {
  const state = queue.getState();
  let items = Object.values(state.items);
  items = items.filter(item => ids.includes(item.id) && !getIsItemFinalized(item));
  return Promise.all(items.map(i => {
    const {
      batchOptions
    } = getBatchDataFromItemId(queue, i.id);
    return queue.runCancellable(UPLOADER_EVENTS.ITEM_START, i, batchOptions);
  })).then(cancelledResults => {
    let allowedItems = cancelledResults.map((isCancelled, index) => isCancelled ? null : getAllowedItem(items[index].id, queue)).filter(Boolean);
    return {
      allowedItems,
      cancelledResults,
      queue,
      items,
      ids,
      next
    };
  }).then(processAllowedItems);
};
/* harmony default export */ const queue_processBatchItems = (processBatchItems);
;// ./node_modules/@rpldy/uploader/lib/esm/queue/processQueueNext.js



const getIsItemInActiveRequest = (queue, itemId) => {
  return queue.getState().activeIds.flat().includes(itemId);
};
const getIsItemReady = item => item.state.valueOf() === esm/* FILE_STATES */.aN.ADDED.valueOf();
const findNextItemIndex = queue => {
  const state = queue.getState(),
    itemQueue = state.itemQueue,
    items = state.items;
  let nextItemId = null,
    batchIndex = 0,
    itemIndex = 0,
    batchId = state.batchQueue[batchIndex];
  while (batchId && !nextItemId) {
    if (getIsBatchReady(queue, batchId)) {
      nextItemId = itemQueue[batchId][itemIndex];
      while (nextItemId && (getIsItemInActiveRequest(queue, nextItemId) || !getIsItemReady(items[nextItemId]))) {
        itemIndex += 1;
        nextItemId = itemQueue[batchId][itemIndex];
      }
    }
    if (!nextItemId) {
      batchIndex += 1;
      batchId = state.batchQueue[batchIndex];
      itemIndex = 0;
    }
  }
  return nextItemId ? [batchId, itemIndex] : null;
};
const getNextIdGroup = queue => {
  const state = queue.getState(),
    itemQueue = state.itemQueue,
    [nextBatchId, nextItemIndex] = findNextItemIndex(queue) || [];
  let nextId = nextBatchId && ~nextItemIndex ? itemQueue[nextBatchId][nextItemIndex] : null,
    nextGroup;
  if (nextId) {
    const {
        batchOptions
      } = state.batches[nextBatchId],
      groupMax = batchOptions.maxGroupSize || 0;
    if (batchOptions.grouped && groupMax > 1) {
      const batchItems = state.itemQueue[nextBatchId];
      nextGroup = batchItems.slice(nextItemIndex, nextItemIndex + groupMax);
    } else {
      nextGroup = [nextId];
    }
  }
  return nextGroup;
};
const updateItemsAsActive = (queue, ids) => {
  queue.updateState(state => {
    state.activeIds = state.activeIds.concat(ids);
  });
};
const processNextWithBatch = (queue, ids) => {
  let newBatchP;
  if (!isItemBatchStartPending(queue, ids[0])) {
    updateItemsAsActive(queue, ids);
    if (isNewBatchStarting(queue, ids[0])) {
      newBatchP = loadNewBatchForItem(queue, ids[0]).then(allowBatch => {
        let cancelled = !allowBatch;
        if (cancelled) {
          cancelBatchForItem(queue, ids[0]);
          processNext(queue);
        }
        return cancelled;
      }).catch(err => {
        esm/* logger.debugLog */.vF.debugLog("uploader.processor: encountered error while preparing batch for request", err);
        failBatchForItem(queue, ids[0], err);
        processNext(queue);
        return true;
      });
    } else {
      newBatchP = Promise.resolve(false);
    }
  } else {
    newBatchP = Promise.resolve(true);
  }
  return newBatchP;
};
const processNext = queue => {
  let processPromise;
  const ids = getNextIdGroup(queue);
  if (ids) {
    const currentCount = queue.getCurrentActiveCount(),
      {
        concurrent = !!0,
        maxConcurrent = 0
      } = queue.getOptions();
    if (!currentCount || concurrent && currentCount < maxConcurrent) {
      esm/* logger.debugLog */.vF.debugLog("uploader.processor: Processing next upload - ", {
        ids,
        currentCount
      });
      processPromise = processNextWithBatch(queue, ids).then(failedOrCancelled => {
        if (!failedOrCancelled) {
          queue_processBatchItems(queue, ids, processNext);
          if (concurrent) {
            processNext(queue);
          }
        }
      });
    }
  }
  return processPromise;
};
/* harmony default export */ const processQueueNext = (processNext);
;// ./node_modules/@rpldy/uploader/lib/esm/queue/processAbort.js





const getFinalizeAbortedItem = queue => (id, data) => queue_processFinishedRequest(queue, [{
  id,
  info: data
}], processQueueNext);
const processAbortItem = (queue, id) => {
  const abortItemMethod = queue.getOptions().abortItem;
  (0,esm/* invariant */.V1)(!!abortItemMethod, "Abort Item method not provided yet abortItem was called");
  const state = queue.getState();
  return abortItemMethod(id, state.items, state.aborts, getFinalizeAbortedItem(queue));
};
const processAbortBatch = (queue, id) => {
  const abortBatchMethod = queue.getOptions().abortBatch;
  (0,esm/* invariant */.V1)(!!abortBatchMethod, "Abort Batch method not provided yet abortItem was called");
  const state = queue.getState(),
    batchData = state.batches[id],
    batch = batchData?.batch;
  if (batch && !getIsBatchFinalized(batch)) {
    finalizeBatch(queue, id, UPLOADER_EVENTS.BATCH_ABORT, esm/* BATCH_STATES */.mX.ABORTED);
    const {
      isFast
    } = abortBatchMethod(batch, batchData.batchOptions, state.aborts, state.itemQueue, getFinalizeAbortedItem(queue), queue.getOptions());
    if (isFast) {
      queue.clearBatchUploads(batch.id);
    }
  }
};
const processAbortAll = queue => {
  const abortAllMethod = queue.getOptions().abortAll;
  (0,esm/* invariant */.V1)(!!abortAllMethod, "Abort All method not provided yet abortAll was called");
  queue.trigger(UPLOADER_EVENTS.ALL_ABORT);
  const state = queue.getState();
  const {
    isFast
  } = abortAllMethod(state.items, state.aborts, state.itemQueue, getFinalizeAbortedItem(queue), queue.getOptions());
  if (isFast) {
    queue.clearAllUploads();
  }
};

;// ./node_modules/@rpldy/uploader/lib/esm/queue/uploaderQueue.js






const createUploaderQueue = (options, trigger, cancellable, sender, uploaderId) => {
  const {
    state,
    update
  } = esm_createState({
    itemQueue: {},
    batchQueue: [],
    currentBatch: null,
    batchesStartPending: [],
    batches: {},
    items: {},
    activeIds: [],
    aborts: {}
  });
  const getState = () => state;
  const updateState = updater => {
    update(updater);
  };
  const add = item => {
    if (state.items[item.id] && !item.recycled) {
      throw new Error(`Uploader queue conflict - item ${item.id} already exists`);
    }
    if (item.recycled) {
      detachRecycledFromPreviousBatch(queueState, item);
    }
    updateState(state => {
      state.items[item.id] = item;
    });
  };
  const handleItemProgress = (item, completed, loaded, total) => {
    if (state.items[item.id]) {
      updateState(state => {
        const stateItem = state.items[item.id];
        stateItem.loaded = loaded;
        stateItem.completed = completed;
        stateItem.total = total;
      });
      trigger(UPLOADER_EVENTS.ITEM_PROGRESS, getState().items[item.id]);
    }
  };
  sender.on(SENDER_EVENTS.ITEM_PROGRESS, handleItemProgress);
  sender.on(SENDER_EVENTS.BATCH_PROGRESS, batch => {
    const batchItems = state.batches[batch.id]?.batch.items;
    if (batchItems) {
      const [loaded, total] = batchItems.reduce((res, {
        id
      }) => {
        const {
          loaded,
          file
        } = state.items[id];
        const size = file?.size || loaded || 1;
        res[0] += loaded;
        res[1] += size;
        return res;
      }, [0, 0]);
      updateState(state => {
        const stateBatch = state.batches[batch.id].batch;
        stateBatch.total = total;
        stateBatch.loaded = loaded;
        stateBatch.completed = loaded / total;
      });
      triggerUploaderBatchEvent(queueState, batch.id, UPLOADER_EVENTS.BATCH_PROGRESS);
    }
  });
  const queueState = {
    uploaderId,
    getOptions: () => options,
    getCurrentActiveCount: () => state.activeIds.length,
    getState,
    updateState,
    trigger,
    runCancellable: (name, ...args) => {
      if (!(0,esm/* isFunction */.Tn)(cancellable)) {
        throw new Error("Uploader queue - cancellable is of wrong type");
      }
      return cancellable(name, ...args);
    },
    sender,
    handleItemProgress,
    clearAllUploads: () => {
      queueState.updateState(state => {
        state.itemQueue = {};
        state.batchQueue = [];
        state.currentBatch = null;
        state.batches = {};
        state.items = {};
        state.activeIds = [];
      });
    },
    clearBatchUploads: batchId => {
      (0,esm/* scheduleIdleWork */.tD)(() => {
        esm/* logger.debugLog */.vF.debugLog(`uploader.queue: started scheduled work to clear batch uploads (${batchId})`);
        if (getState().batches[batchId]) {
          clearBatchData(queueState, batchId);
        }
      });
    }
  };
  if ((0,esm/* hasWindow */.Vd)() && esm/* logger.isDebugOn */.vF.isDebugOn()) {
    window[`__rpldy_${uploaderId}_queue_state`] = queueState;
  }
  return {
    updateState,
    getState: queueState.getState,
    runCancellable: queueState.runCancellable,
    uploadBatch: (batch, batchOptions) => {
      if (batchOptions) {
        updateState(state => {
          state.batches[batch.id].batchOptions = batchOptions;
        });
      }
      processQueueNext(queueState);
    },
    addBatch: (batch, batchOptions) => {
      updateState(state => {
        state.batches[batch.id] = {
          batch,
          batchOptions,
          itemBatchOptions: {},
          finishedCounter: 0
        };
        state.batchQueue.push(batch.id);
        state.itemQueue[batch.id] = batch.items.map(({
          id
        }) => id);
      });
      batch.items.forEach(add);
      return getBatchFromState(state, batch.id);
    },
    abortItem: (...args) => processAbortItem(queueState, ...args),
    abortBatch: (...args) => processAbortBatch(queueState, ...args),
    abortAll: (...args) => processAbortAll(queueState, ...args),
    clearPendingBatches: () => {
      removePendingBatches(queueState);
    },
    uploadPendingBatches: uploadOptions => {
      preparePendingForUpload(queueState, uploadOptions);
      processQueueNext(queueState);
    },
    cancelBatch: batch => cancelBatchWithId(queueState, batch.id)
  };
};
/* harmony default export */ const uploaderQueue = (createUploaderQueue);
;// ./node_modules/@rpldy/uploader/lib/esm/queue/index.js

;// ./node_modules/@rpldy/sender/lib/esm/consts.js
const XHR_SENDER_TYPE = "rpldy-sender";
;// ./node_modules/@rpldy/sender/lib/esm/MissingUrlError.js
class MissingUrlError extends Error {
  constructor(senderType) {
    super(`${senderType} didn't receive upload URL`);
    this.name = "MissingUrlError";
  }
}
;// ./node_modules/@rpldy/sender/lib/esm/xhrSender/prepareFormData.js

const addToFormData = (fd, name, ...rest) => {
  if ("set" in fd) {
    fd.set(name, ...rest);
  } else {
    if ("delete" in fd) {
      fd.delete(name);
    }
    fd.append(name, ...rest);
  }
};
const getFormFileField = (fd, items, options) => {
  const single = items.length === 1;
  items.forEach((item, i) => {
    const name = single ? options.paramName : (0,esm/* isFunction */.Tn)(options.formatGroupParamName) ? options.formatGroupParamName(i, options.paramName) : `${options.paramName}[${i}]`;
    if (item.file) {
      addToFormData(fd, name, item.file, item.file.name);
    } else if (item.url) {
      addToFormData(fd, name, item.url);
    }
  });
};
const prepareFormData = (items, options) => {
  const fd = new FormData();
  if (options.params) {
    Object.entries(options.params).forEach(([key, val]) => {
      if (options.formDataAllowUndefined || val !== undefined) {
        addToFormData(fd, key, val);
      }
    });
  }
  getFormFileField(fd, items, options);
  return fd;
};
/* harmony default export */ const xhrSender_prepareFormData = (prepareFormData);
;// ./node_modules/@rpldy/sender/lib/esm/xhrSender/xhrSender.js




const SUCCESS_CODES = [200, 201, 202, 203, 204];
const getRequestData = (items, options) => {
  let data;
  if (options.sendWithFormData) {
    esm/* logger.debugLog */.vF.debugLog(`uploady.sender: sending ${items.length} item(s) as form data`);
    data = xhrSender_prepareFormData(items, options);
  } else {
    if (items.length > 1) {
      throw new Error(`XHR Sender - Request without form data can only contain 1 item. received ${items.length}`);
    }
    const item = items[0];
    esm/* logger.debugLog */.vF.debugLog(`uploady.sender: sending item ${item.id} as request body`);
    data = item.file || item.url;
  }
  return data;
};
const makeRequest = (items, url, options, onProgress, config) => {
  let xhr;
  const data = config?.getRequestData ? config.getRequestData(items, options) : getRequestData(items, options);
  const issueRequest = (requestUrl = url, requestData = data, requestOptions) => {
    const resolvedRequestOptions = (0,esm/* merge */.h1)({
      ...(0,esm/* pick */.Up)(options, ["method", "headers", "withCredentials"]),
      preSend: req => {
        req.upload.onprogress = e => {
          if (e.lengthComputable && onProgress) {
            onProgress(e, items.slice());
          }
        };
      }
    }, requestOptions);
    const realPXhr = (0,esm/* request */.Em)(requestUrl, requestData, resolvedRequestOptions);
    xhr = realPXhr.xhr;
    return realPXhr;
  };
  const pXhr = config?.preRequestHandler ? config.preRequestHandler(issueRequest, items, url, options, onProgress, config) : issueRequest();
  return {
    url,
    count: items.length,
    pXhr,
    getXhr: () => xhr,
    aborted: false
  };
};
const parseResponseJson = (response, headers, options) => {
  let parsed = response;
  const ct = headers?.["content-type"];
  if (options.forceJsonResponse || ct?.includes("json")) {
    try {
      parsed = JSON.parse(response);
    } catch {}
  }
  return parsed;
};
const checkIsResponseSuccessful = (xhr, options) => {
  const isSuccess = options.isSuccessfulCall ? options.isSuccessfulCall(xhr) : SUCCESS_CODES.includes(xhr.status);
  return (0,esm/* isPromise */.yL)(isSuccess) ? isSuccess : Promise.resolve(isSuccess);
};
const processResponse = (sendRequest, options) => sendRequest.pXhr.then(xhr => {
  esm/* logger.debugLog */.vF.debugLog("uploady.sender: received upload response ", xhr);
  return checkIsResponseSuccessful(xhr, options).then(isSuccess => {
    const state = isSuccess ? esm/* FILE_STATES */.aN.FINISHED : esm/* FILE_STATES */.aN.ERROR;
    const status = xhr.status;
    const resHeaders = (0,esm/* parseResponseHeaders */.tn)(xhr);
    const response = {
      data: options.formatServerResponse?.(xhr.response, status, resHeaders) ?? parseResponseJson(xhr.response, resHeaders, options),
      headers: resHeaders
    };
    return {
      status,
      state,
      response
    };
  });
}).catch(error => {
  let state, response;
  if (sendRequest.aborted) {
    state = esm/* FILE_STATES */.aN.ABORTED;
    response = "aborted";
  } else {
    esm/* logger.debugLog */.vF.debugLog("uploady.sender: upload failed: ", error);
    state = esm/* FILE_STATES */.aN.ERROR;
    response = error;
  }
  return {
    error: true,
    state,
    response,
    status: 0
  };
});
const abortRequest = sendRequest => {
  let abortCalled = false;
  const {
    aborted,
    getXhr
  } = sendRequest;
  const xhr = getXhr();
  if (!aborted && xhr && xhr.readyState && xhr.readyState !== 4) {
    esm/* logger.debugLog */.vF.debugLog(`uploady.sender: cancelling request with ${sendRequest.count} items to: ${sendRequest.url}`);
    xhr.abort();
    sendRequest.aborted = true;
    abortCalled = true;
  }
  return abortCalled;
};
const getXhrSend = config => (items, url, options, onProgress) => {
  if (!url) {
    throw new MissingUrlError(XHR_SENDER_TYPE);
  }
  esm/* logger.debugLog */.vF.debugLog("uploady.sender: sending file: ", {
    items,
    url,
    options
  });
  const sendRequest = makeRequest(items, url, options, onProgress, config);
  return {
    request: processResponse(sendRequest, options),
    abort: () => abortRequest(sendRequest),
    senderType: XHR_SENDER_TYPE
  };
};
/* harmony default export */ const xhrSender = (getXhrSend);
;// ./node_modules/@rpldy/sender/lib/esm/index.js


const send = xhrSender();
/* harmony default export */ const sender_lib_esm = (send);


;// ./node_modules/@rpldy/uploader/lib/esm/defaults.js

const DEFAULT_PARAM_NAME = "file";
const DEFAULT_FILTER = () => true;
const DEFAULT_OPTIONS = (0,esm/* devFreeze */.fO)({
  autoUpload: true,
  clearPendingOnAdd: false,
  inputFieldName: "file",
  concurrent: false,
  maxConcurrent: 2,
  grouped: false,
  maxGroupSize: 5,
  method: "POST",
  params: {},
  fileFilter: DEFAULT_FILTER,
  forceJsonResponse: false,
  withCredentials: false,
  destination: {},
  send: null,
  sendWithFormData: true,
  formDataAllowUndefined: false,
  fastAbortThreshold: 100
});
;// ./node_modules/@rpldy/uploader/lib/esm/batchItemsSender.js





const reportItemsProgress = (items, completed, loaded, total, trigger) => {
  items.forEach(item => {
    esm/* logger.debugLog */.vF.debugLog(`uploady.uploader.processor: file: ${item.id} progress event: loaded(${loaded}) - completed(${completed})`);
    trigger(SENDER_EVENTS.ITEM_PROGRESS, item, completed, loaded, total);
  });
};
const onItemUploadProgress = (items, batch, e, trigger) => {
  const completed = Math.min(e.loaded / e.total * 100, 100),
    completedPerItem = completed / items.length,
    loadedAverage = e.loaded / items.length;
  reportItemsProgress(items, completedPerItem, loadedAverage, e.total, trigger);
  trigger(SENDER_EVENTS.BATCH_PROGRESS, batch);
};
const createBatchItemsSender = () => {
  const {
    trigger,
    target: sender
  } = lifeEvents({
    send: (items, batch, batchOptions) => {
      const destination = batchOptions.destination,
        url = destination?.url;
      const throttledProgress = (0,esm/* throttle */.nF)(e => onItemUploadProgress(items, batch, e, trigger), PROGRESS_DELAY, true);
      const send = (0,esm/* isFunction */.Tn)(batchOptions.send) ? batchOptions.send : sender_lib_esm;
      return send(items, url, {
        method: destination?.method || batchOptions.method || DEFAULT_OPTIONS.method,
        paramName: destination?.filesParamName || batchOptions.inputFieldName || DEFAULT_PARAM_NAME,
        params: {
          ...batchOptions.params,
          ...destination?.params
        },
        forceJsonResponse: batchOptions.forceJsonResponse,
        withCredentials: batchOptions.withCredentials,
        formatGroupParamName: batchOptions.formatGroupParamName,
        headers: destination?.headers,
        sendWithFormData: batchOptions.sendWithFormData,
        formatServerResponse: batchOptions.formatServerResponse,
        formDataAllowUndefined: batchOptions.formDataAllowUndefined,
        isSuccessfulCall: batchOptions.isSuccessfulCall
      }, throttledProgress);
    }
  }, Object.values(SENDER_EVENTS));
  return sender;
};
/* harmony default export */ const batchItemsSender = (createBatchItemsSender);
;// ./node_modules/@rpldy/uploader/lib/esm/utils.js



const FILE_LIST_SUPPORT = (0,esm/* hasWindow */.Vd)() && "FileList" in window;
const getMandatoryDestination = dest => {
  return {
    params: {},
    ...dest
  };
};
const getMandatoryOptions = options => {
  return {
    ...DEFAULT_OPTIONS,
    ...options,
    destination: options && options.destination ? getMandatoryDestination(options.destination) : null
  };
};
const getIsFileList = files => FILE_LIST_SUPPORT && files instanceof FileList || files.toString() === "[object FileList]";
const deepProxyUnwrap = (obj, level = 0) => {
  let result = obj;
  if (!(0,esm/* isProduction */.KV)()) {
    if (level < 3 && isProxy(obj)) {
      result = unwrapProxy(obj);
    } else if (level < 3 && isProxiable(obj)) {
      result = Array.isArray(obj) ? obj.map(sub => deepProxyUnwrap(sub, level + 1)) : Object.keys(obj).reduce((res, key) => {
        res[key] = deepProxyUnwrap(obj[key], level + 1);
        return res;
      }, {});
    }
  }
  return result;
};

;// ./node_modules/@rpldy/uploader/lib/esm/batch.js



let bCounter = 0;
const processFiles = (batchId, files, isPending, fileFilter) => {
  const all = fileFilter ? Array.prototype.map.call(files, f => (0,esm/* getIsBatchItem */.Uk)(f) ? f.file || f.url : f) : [];
  return Promise.all(Array.prototype.map.call(files, (f, index) => {
    const filterResult = (fileFilter || DEFAULT_FILTER)(all[index], index, all);
    return (0,esm/* isPromise */.yL)(filterResult) ? filterResult.then(result => !!result && f) : !!filterResult && f;
  })).then(filtered => filtered.filter(Boolean).map(f => (0,esm/* createBatchItem */.UT)(f, batchId, isPending)));
};
const createBatch = (files, uploaderId, options) => {
  bCounter += 1;
  const id = `batch-${bCounter}`;
  const isFileList = getIsFileList(files);
  const usedFiles = Array.isArray(files) || isFileList ? files : [files];
  const isPending = !options.autoUpload;
  return processFiles(id, usedFiles, isPending, options.fileFilter).then(items => {
    return {
      id,
      uploaderId,
      items,
      state: isPending ? esm/* BATCH_STATES */.mX.PENDING : esm/* BATCH_STATES */.mX.ADDED,
      completed: 0,
      loaded: 0,
      orgItemCount: items.length,
      additionalInfo: null
    };
  });
};
/* harmony default export */ const batch = (createBatch);
;// ./node_modules/@rpldy/uploader/lib/esm/processor.js





const createProcessor = (trigger, cancellable, options, uploaderId) => {
  const sender = batchItemsSender(),
    queue = uploaderQueue(options, trigger, cancellable, sender, uploaderId);
  return {
    abortBatch: batchId => {
      queue.abortBatch(batchId);
    },
    abort: id => {
      if (id) {
        queue.abortItem(id);
      } else {
        queue.abortAll();
      }
    },
    addNewBatch: (files, processOptions) => batch(files, uploaderId, processOptions).then(batch => {
      let resultP;
      if (batch.items.length) {
        const addedBatch = queue.addBatch(batch, processOptions);
        resultP = queue.runCancellable(UPLOADER_EVENTS.BATCH_ADD, addedBatch, processOptions).then(isCancelled => {
          if (!isCancelled) {
            esm/* logger.debugLog */.vF.debugLog(`uploady.uploader [${uploaderId}]: new items added - auto upload =
                       ${String(processOptions.autoUpload)}`, addedBatch.items);
            if (processOptions.autoUpload) {
              queue.uploadBatch(addedBatch);
            }
          } else {
            queue.cancelBatch(addedBatch);
          }
          return addedBatch;
        });
      } else {
        esm/* logger.debugLog */.vF.debugLog(`uploady.uploader: no items to add. batch ${batch.id} is empty. check fileFilter if this isn't intended`);
      }
      return resultP || Promise.resolve(null);
    }),
    clearPendingBatches: () => {
      queue.clearPendingBatches();
    },
    processPendingBatches: uploadOptions => {
      queue.uploadPendingBatches(uploadOptions);
    }
  };
};
/* harmony default export */ const esm_processor = (createProcessor);
;// ./node_modules/@rpldy/uploader/lib/esm/composeEnhancers.js
const composeEnhancers = (...enhancers) => (uploader, ...args) => enhancers.reduce((enhanced, e) => e(enhanced, ...args) || enhanced, uploader);
/* harmony default export */ const esm_composeEnhancers = (composeEnhancers);
;// ./node_modules/@rpldy/uploader/lib/esm/uploader.js







const EVENT_NAMES = Object.values(UPLOADER_EVENTS);
const EXT_OUTSIDE_ENHANCER_TIME = "Uploady - uploader extensions can only be registered by enhancers",
  EXT_ALREADY_EXISTS = "Uploady - uploader extension by this name [%s] already exists";
let counter = 0;
const getComposedEnhancer = extEnhancer => esm_composeEnhancers(lib_esm(), extEnhancer);
const getEnhancedUploader = (uploader, options, triggerWithUnwrap, setEnhancerTime) => {
  const enhancer = options.enhancer ? getComposedEnhancer(options.enhancer) : lib_esm();
  setEnhancerTime(true);
  const enhanced = enhancer(uploader, triggerWithUnwrap);
  setEnhancerTime(false);
  return enhanced || uploader;
};
const createUploader = options => {
  counter += 1;
  const uploaderId = `uploader-${counter}`;
  let enhancerTime = false;
  const extensions = {};
  esm/* logger.debugLog */.vF.debugLog(`uploady.uploader: creating new instance (${uploaderId})`, {
    options,
    counter
  });
  let uploaderOptions = getMandatoryOptions(options);
  const clearPending = () => {
    processor.clearPendingBatches();
  };
  const getOptions = () => {
    return (0,esm/* clone */.o8)(uploaderOptions);
  };
  let {
    trigger,
    target: uploader
  } = lifeEvents({
    id: uploaderId,
    update: updateOptions => {
      uploaderOptions = (0,esm/* merge */.h1)({}, uploaderOptions, updateOptions);
      return uploader;
    },
    add: (files, addOptions) => {
      const processOptions = (0,esm/* merge */.h1)({}, uploaderOptions, addOptions);
      if (processOptions.clearPendingOnAdd) {
        clearPending();
      }
      return processor.addNewBatch(files, processOptions).then(() => {
        esm/* logger.debugLog */.vF.debugLog(`uploady.uploader: finished adding file data to be processed`);
      });
    },
    upload: uploadOptions => {
      processor.processPendingBatches(uploadOptions);
    },
    abort: id => {
      processor.abort(id);
    },
    abortBatch: id => {
      processor.abortBatch(id);
    },
    getOptions,
    clearPending,
    registerExtension: (name, methods) => {
      (0,esm/* invariant */.V1)(enhancerTime, EXT_OUTSIDE_ENHANCER_TIME);
      (0,esm/* invariant */.V1)(!extensions[name], EXT_ALREADY_EXISTS, name);
      esm/* logger.debugLog */.vF.debugLog(`uploady.uploader: registering extension: ${name.toString()}`, methods);
      extensions[name] = methods;
    },
    getExtension: name => {
      return extensions[name];
    }
  }, EVENT_NAMES, {
    canAddEvents: false,
    canRemoveEvents: false
  });
  const triggerWithUnwrap = (name, ...data) => {
    const lp = lifePack(() => data.map(deepProxyUnwrap));
    return trigger(name, lp);
  };
  const cancellable = (0,esm/* triggerCancellable */.x1)(triggerWithUnwrap);
  const enhancedUploader = getEnhancedUploader(uploader, uploaderOptions, triggerWithUnwrap, state => {
    enhancerTime = state;
  });
  const processor = esm_processor(triggerWithUnwrap, cancellable, uploaderOptions, enhancedUploader.id);
  return (0,esm/* devFreeze */.fO)(enhancedUploader);
};
/* harmony default export */ const uploader = (createUploader);
;// ./node_modules/@rpldy/uploader/lib/esm/index.js




/* harmony default export */ const uploader_lib_esm = (uploader);




/***/ }),

/***/ 49436:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  If: () => (/* reexport */ esm_asUploadButton)
});

// UNUSED EXPORTS: UploadButton, default

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/@rpldy/shared-ui/lib/esm/index.js + 17 modules
var esm = __webpack_require__(3404);
;// ./node_modules/@rpldy/upload-button/lib/esm/asUploadButton.js
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }


const asUploadButton = Component => {
  const AsUploadButton = (props, ref) => {
    const {
      showFileUpload
    } = (0,esm/* useUploadyContext */.Bx)();
    const {
      id,
      className,
      text,
      children,
      extraProps,
      onClick,
      ...uploadOptions
    } = props;
    const uploadOptionsRef = (0,react.useRef)();
    uploadOptionsRef.current = uploadOptions;
    const onButtonClick = (0,react.useCallback)(e => {
      showFileUpload(uploadOptionsRef.current);
      onClick?.(e);
    }, [showFileUpload, uploadOptionsRef, onClick]);
    return /*#__PURE__*/react.createElement(Component, _extends({
      ref: ref,
      onClick: onButtonClick,
      id: id,
      className: className
    }, extraProps), children || text || "Upload");
  };
  (0,esm/* markAsUploadOptionsComponent */.QB)(AsUploadButton);
  return /*#__PURE__*/(0,react.forwardRef)(AsUploadButton);
};
/* harmony default export */ const esm_asUploadButton = (asUploadButton);
;// ./node_modules/@rpldy/upload-button/lib/esm/UploadButton.js
function UploadButton_extends() { return UploadButton_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, UploadButton_extends.apply(null, arguments); }


const UploadButton_UploadButton = esm_asUploadButton(/*#__PURE__*/(0,react.forwardRef)((props, ref) => /*#__PURE__*/react.createElement("button", UploadButton_extends({
  ref: ref
}, props))));
/* harmony default export */ const esm_UploadButton = ((/* unused pure expression or super */ null && (UploadButton_UploadButton)));
;// ./node_modules/@rpldy/upload-button/lib/esm/index.js


/* harmony default export */ const lib_esm = ((/* unused pure expression or super */ null && (UploadButton)));


/***/ }),

/***/ 54416:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ X)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19946);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M18 6 6 18",
            key: "1bl5f8"
        }
    ],
    [
        "path",
        {
            d: "m6 6 12 12",
            key: "d8bk6v"
        }
    ]
];
const X = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("x", __iconNode);
 //# sourceMappingURL=x.js.map


/***/ }),

/***/ 57434:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ FileText)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19946);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
            key: "1rqfz7"
        }
    ],
    [
        "path",
        {
            d: "M14 2v4a2 2 0 0 0 2 2h4",
            key: "tnqrlb"
        }
    ],
    [
        "path",
        {
            d: "M10 9H8",
            key: "b1mrlr"
        }
    ],
    [
        "path",
        {
            d: "M16 13H8",
            key: "t4e002"
        }
    ],
    [
        "path",
        {
            d: "M16 17H8",
            key: "z1uh3a"
        }
    ]
];
const FileText = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("file-text", __iconNode);
 //# sourceMappingURL=file-text.js.map


/***/ }),

/***/ 60760:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  N: () => (/* binding */ AnimatePresence)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/context/LayoutGroupContext.mjs
var LayoutGroupContext = __webpack_require__(90869);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/utils/use-constant.mjs
var use_constant = __webpack_require__(82885);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/utils/use-isomorphic-effect.mjs
var use_isomorphic_effect = __webpack_require__(97494);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/context/PresenceContext.mjs
var PresenceContext = __webpack_require__(80845);
// EXTERNAL MODULE: ./node_modules/motion-dom/dist/es/utils/is-html-element.mjs
var is_html_element = __webpack_require__(27351);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/context/MotionConfigContext.mjs
var MotionConfigContext = __webpack_require__(51508);
;// ./node_modules/framer-motion/dist/es/components/AnimatePresence/PopChild.mjs
/* __next_internal_client_entry_do_not_use__ PopChild auto */ 




/**
 * Measurement functionality has to be within a separate component
 * to leverage snapshot lifecycle.
 */ class PopChildMeasure extends react.Component {
    getSnapshotBeforeUpdate(prevProps) {
        const element = this.props.childRef.current;
        if (element && prevProps.isPresent && !this.props.isPresent) {
            const parent = element.offsetParent;
            const parentWidth = (0,is_html_element/* isHTMLElement */.s)(parent) ? parent.offsetWidth || 0 : 0;
            const size = this.props.sizeRef.current;
            size.height = element.offsetHeight || 0;
            size.width = element.offsetWidth || 0;
            size.top = element.offsetTop;
            size.left = element.offsetLeft;
            size.right = parentWidth - size.width - size.left;
        }
        return null;
    }
    /**
     * Required with getSnapshotBeforeUpdate to stop React complaining.
     */ componentDidUpdate() {}
    render() {
        return this.props.children;
    }
}
function PopChild(param) {
    let { children, isPresent, anchorX, root } = param;
    const id = (0,react.useId)();
    const ref = (0,react.useRef)(null);
    const size = (0,react.useRef)({
        width: 0,
        height: 0,
        top: 0,
        left: 0,
        right: 0
    });
    const { nonce } = (0,react.useContext)(MotionConfigContext/* MotionConfigContext */.Q);
    /**
     * We create and inject a style block so we can apply this explicit
     * sizing in a non-destructive manner by just deleting the style block.
     *
     * We can't apply size via render as the measurement happens
     * in getSnapshotBeforeUpdate (post-render), likewise if we apply the
     * styles directly on the DOM node, we might be overwriting
     * styles set via the style prop.
     */ (0,react.useInsertionEffect)(()=>{
        const { width, height, top, left, right } = size.current;
        if (isPresent || !ref.current || !width || !height) return;
        const x = anchorX === "left" ? "left: ".concat(left) : "right: ".concat(right);
        ref.current.dataset.motionPopId = id;
        const style = document.createElement("style");
        if (nonce) style.nonce = nonce;
        const parent = root !== null && root !== void 0 ? root : document.head;
        parent.appendChild(style);
        if (style.sheet) {
            style.sheet.insertRule('\n          [data-motion-pop-id="'.concat(id, '"] {\n            position: absolute !important;\n            width: ').concat(width, "px !important;\n            height: ").concat(height, "px !important;\n            ").concat(x, "px !important;\n            top: ").concat(top, "px !important;\n          }\n        "));
        }
        return ()=>{
            if (parent.contains(style)) {
                parent.removeChild(style);
            }
        };
    }, [
        isPresent
    ]);
    return (0,jsx_runtime.jsx)(PopChildMeasure, {
        isPresent: isPresent,
        childRef: ref,
        sizeRef: size,
        children: /*#__PURE__*/ react.cloneElement(children, {
            ref
        })
    });
}


;// ./node_modules/framer-motion/dist/es/components/AnimatePresence/PresenceChild.mjs
/* __next_internal_client_entry_do_not_use__ PresenceChild auto */ 





const PresenceChild = (param)=>{
    let { children, initial, isPresent, onExitComplete, custom, presenceAffectsLayout, mode, anchorX, root } = param;
    const presenceChildren = (0,use_constant/* useConstant */.M)(newChildrenMap);
    const id = (0,react.useId)();
    let isReusedContext = true;
    let context = (0,react.useMemo)(()=>{
        isReusedContext = false;
        return {
            id,
            initial,
            isPresent,
            custom,
            onExitComplete: (childId)=>{
                presenceChildren.set(childId, true);
                for (const isComplete of presenceChildren.values()){
                    if (!isComplete) return; // can stop searching when any is incomplete
                }
                onExitComplete && onExitComplete();
            },
            register: (childId)=>{
                presenceChildren.set(childId, false);
                return ()=>presenceChildren.delete(childId);
            }
        };
    }, [
        isPresent,
        presenceChildren,
        onExitComplete
    ]);
    /**
     * If the presence of a child affects the layout of the components around it,
     * we want to make a new context value to ensure they get re-rendered
     * so they can detect that layout change.
     */ if (presenceAffectsLayout && isReusedContext) {
        context = {
            ...context
        };
    }
    (0,react.useMemo)(()=>{
        presenceChildren.forEach((_, key)=>presenceChildren.set(key, false));
    }, [
        isPresent
    ]);
    /**
     * If there's no `motion` components to fire exit animations, we want to remove this
     * component immediately.
     */ react.useEffect(()=>{
        !isPresent && !presenceChildren.size && onExitComplete && onExitComplete();
    }, [
        isPresent
    ]);
    if (mode === "popLayout") {
        children = (0,jsx_runtime.jsx)(PopChild, {
            isPresent: isPresent,
            anchorX: anchorX,
            root: root,
            children: children
        });
    }
    return (0,jsx_runtime.jsx)(PresenceContext/* PresenceContext */.t.Provider, {
        value: context,
        children: children
    });
};
function newChildrenMap() {
    return new Map();
}


// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/AnimatePresence/use-presence.mjs
var use_presence = __webpack_require__(32082);
;// ./node_modules/framer-motion/dist/es/components/AnimatePresence/utils.mjs


const getChildKey = (child) => child.key || "";
function onlyElements(children) {
    const filtered = [];
    // We use forEach here instead of map as map mutates the component key by preprending `.$`
    react.Children.forEach(children, (child) => {
        if ((0,react.isValidElement)(child))
            filtered.push(child);
    });
    return filtered;
}



;// ./node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs
/* __next_internal_client_entry_do_not_use__ AnimatePresence auto */ 







/**
 * `AnimatePresence` enables the animation of components that have been removed from the tree.
 *
 * When adding/removing more than a single child, every child **must** be given a unique `key` prop.
 *
 * Any `motion` components that have an `exit` property defined will animate out when removed from
 * the tree.
 *
 * ```jsx
 * import { motion, AnimatePresence } from 'framer-motion'
 *
 * export const Items = ({ items }) => (
 *   <AnimatePresence>
 *     {items.map(item => (
 *       <motion.div
 *         key={item.id}
 *         initial={{ opacity: 0 }}
 *         animate={{ opacity: 1 }}
 *         exit={{ opacity: 0 }}
 *       />
 *     ))}
 *   </AnimatePresence>
 * )
 * ```
 *
 * You can sequence exit animations throughout a tree using variants.
 *
 * If a child contains multiple `motion` components with `exit` props, it will only unmount the child
 * once all `motion` components have finished animating out. Likewise, any components using
 * `usePresence` all need to call `safeToRemove`.
 *
 * @public
 */ const AnimatePresence = (param)=>{
    let { children, custom, initial = true, onExitComplete, presenceAffectsLayout = true, mode = "sync", propagate = false, anchorX = "left", root } = param;
    const [isParentPresent, safeToRemove] = (0,use_presence/* usePresence */.xQ)(propagate);
    /**
     * Filter any children that aren't ReactElements. We can only track components
     * between renders with a props.key.
     */ const presentChildren = (0,react.useMemo)(()=>onlyElements(children), [
        children
    ]);
    /**
     * Track the keys of the currently rendered children. This is used to
     * determine which children are exiting.
     */ const presentKeys = propagate && !isParentPresent ? [] : presentChildren.map(getChildKey);
    /**
     * If `initial={false}` we only want to pass this to components in the first render.
     */ const isInitialRender = (0,react.useRef)(true);
    /**
     * A ref containing the currently present children. When all exit animations
     * are complete, we use this to re-render the component with the latest children
     * *committed* rather than the latest children *rendered*.
     */ const pendingPresentChildren = (0,react.useRef)(presentChildren);
    /**
     * Track which exiting children have finished animating out.
     */ const exitComplete = (0,use_constant/* useConstant */.M)(()=>new Map());
    /**
     * Save children to render as React state. To ensure this component is concurrent-safe,
     * we check for exiting children via an effect.
     */ const [diffedChildren, setDiffedChildren] = (0,react.useState)(presentChildren);
    const [renderedChildren, setRenderedChildren] = (0,react.useState)(presentChildren);
    (0,use_isomorphic_effect/* useIsomorphicLayoutEffect */.E)(()=>{
        isInitialRender.current = false;
        pendingPresentChildren.current = presentChildren;
        /**
         * Update complete status of exiting children.
         */ for(let i = 0; i < renderedChildren.length; i++){
            const key = getChildKey(renderedChildren[i]);
            if (!presentKeys.includes(key)) {
                if (exitComplete.get(key) !== true) {
                    exitComplete.set(key, false);
                }
            } else {
                exitComplete.delete(key);
            }
        }
    }, [
        renderedChildren,
        presentKeys.length,
        presentKeys.join("-")
    ]);
    const exitingChildren = [];
    if (presentChildren !== diffedChildren) {
        let nextChildren = [
            ...presentChildren
        ];
        /**
         * Loop through all the currently rendered components and decide which
         * are exiting.
         */ for(let i = 0; i < renderedChildren.length; i++){
            const child = renderedChildren[i];
            const key = getChildKey(child);
            if (!presentKeys.includes(key)) {
                nextChildren.splice(i, 0, child);
                exitingChildren.push(child);
            }
        }
        /**
         * If we're in "wait" mode, and we have exiting children, we want to
         * only render these until they've all exited.
         */ if (mode === "wait" && exitingChildren.length) {
            nextChildren = exitingChildren;
        }
        setRenderedChildren(onlyElements(nextChildren));
        setDiffedChildren(presentChildren);
        /**
         * Early return to ensure once we've set state with the latest diffed
         * children, we can immediately re-render.
         */ return null;
    }
    if (false) {}
    /**
     * If we've been provided a forceRender function by the LayoutGroupContext,
     * we can use it to force a re-render amongst all surrounding components once
     * all components have finished animating out.
     */ const { forceRender } = (0,react.useContext)(LayoutGroupContext/* LayoutGroupContext */.L);
    return (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: renderedChildren.map((child)=>{
            const key = getChildKey(child);
            const isPresent = propagate && !isParentPresent ? false : presentChildren === renderedChildren || presentKeys.includes(key);
            const onExit = ()=>{
                if (exitComplete.has(key)) {
                    exitComplete.set(key, true);
                } else {
                    return;
                }
                let isEveryExitComplete = true;
                exitComplete.forEach((isExitComplete)=>{
                    if (!isExitComplete) isEveryExitComplete = false;
                });
                if (isEveryExitComplete) {
                    forceRender === null || forceRender === void 0 ? void 0 : forceRender();
                    setRenderedChildren(pendingPresentChildren.current);
                    propagate && (safeToRemove === null || safeToRemove === void 0 ? void 0 : safeToRemove());
                    onExitComplete && onExitComplete();
                }
            };
            return (0,jsx_runtime.jsx)(PresenceChild, {
                isPresent: isPresent,
                initial: !isInitialRender.current || initial ? undefined : false,
                custom: custom,
                presenceAffectsLayout: presenceAffectsLayout,
                mode: mode,
                root: root,
                onExitComplete: isPresent ? undefined : onExit,
                anchorX: anchorX,
                children: child
            }, key);
        })
    });
};



/***/ }),

/***/ 69398:
/***/ ((module) => {

function isProduction() {
  return "production" === "production";
}
module.exports = isProduction;

/***/ }),

/***/ 74517:
/***/ ((module) => {

function isFunction(f) {
  return typeof f === "function";
}
module.exports = isFunction;

/***/ }),

/***/ 95785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  mX: () => (/* reexport */ BATCH_STATES),
  aN: () => (/* reexport */ FILE_STATES),
  o8: () => (/* reexport */ utils_clone),
  UT: () => (/* reexport */ batchItem),
  fO: () => (/* reexport */ utils_devFreeze),
  Uk: () => (/* reexport */ getIsBatchItem),
  fd: () => (/* reexport */ getMerge),
  Vd: () => (/* reexport */ utils_hasWindow),
  V1: () => (/* reexport */ (browser_default())),
  Tn: () => (/* reexport */ (isFunction_default())),
  Qd: () => (/* reexport */ utils_isPlainObject),
  KV: () => (/* reexport */ (isProduction_default())),
  yL: () => (/* reexport */ utils_isPromise),
  hR: () => (/* reexport */ utils_isSamePropInArrays),
  vF: () => (/* reexport */ logger_namespaceObject),
  h1: () => (/* reexport */ merge),
  tn: () => (/* reexport */ request_parseResponseHeaders),
  Up: () => (/* reexport */ utils_pick),
  Em: () => (/* reexport */ esm_request),
  tD: () => (/* reexport */ utils_scheduleIdleWork),
  nF: () => (/* reexport */ functionThrottle),
  x1: () => (/* reexport */ esm_triggerCancellable),
  w$: () => (/* reexport */ esm_triggerUpdater)
});

// UNUSED EXPORTS: XhrPromise, isEmpty

// NAMESPACE OBJECT: ./node_modules/@rpldy/shared/lib/esm/logger.js
var logger_namespaceObject = {};
__webpack_require__.r(logger_namespaceObject);
__webpack_require__.d(logger_namespaceObject, {
  debugLog: () => (debugLog),
  isDebugOn: () => (isDebugOn),
  setDebug: () => (setDebug)
});

// EXTERNAL MODULE: ./node_modules/invariant/browser.js
var browser = __webpack_require__(23718);
var browser_default = /*#__PURE__*/__webpack_require__.n(browser);
;// ./node_modules/just-throttle/index.mjs
var functionThrottle = throttle;

function throttle(fn, interval, options) {
  var timeoutId = null;
  var throttledFn = null;
  var leading = (options && options.leading);
  var trailing = (options && options.trailing);

  if (leading == null) {
    leading = true; // default
  }

  if (trailing == null) {
    trailing = !leading; //default
  }

  if (leading == true) {
    trailing = false; // forced because there should be invocation per call
  }

  var cancel = function() {
    if (timeoutId) {
      clearTimeout(timeoutId);
      timeoutId = null;
    }
  };

  var flush = function() {
    var call = throttledFn;
    cancel();

    if (call) {
      call();
    }
  };

  var throttleWrapper = function() {
    var callNow = leading && !timeoutId;
    var context = this;
    var args = arguments;

    throttledFn = function() {
      return fn.apply(context, args);
    };

    if (!timeoutId) {
      timeoutId = setTimeout(function() {
        timeoutId = null;

        if (trailing) {
          return throttledFn();
        }
      }, interval);
    }

    if (callNow) {
      callNow = false;
      return throttledFn();
    }
  };

  throttleWrapper.cancel = cancel;
  throttleWrapper.flush = flush;

  return throttleWrapper;
}



;// ./node_modules/@rpldy/shared/lib/esm/consts.js
const DEBUG_LOG_KEY = "__rpldy-logger-debug__";
;// ./node_modules/@rpldy/shared/lib/esm/utils/hasWindow.js
const hasWindow = () => {
  return typeof window === "object" && !!window.document;
};
/* harmony default export */ const utils_hasWindow = (hasWindow);
;// ./node_modules/@rpldy/shared/lib/esm/logger.js


let isDebug = null;
const isDebugOn = () => {
  if (typeof isDebug !== "boolean") {
    isDebug = utils_hasWindow() && ("location" in window && !!~window.location.search.indexOf("rpldy_debug=true") || window[DEBUG_LOG_KEY] === true);
  }
  return !!isDebug;
};
const setDebug = debugOn => {
  if (utils_hasWindow()) {
    window[DEBUG_LOG_KEY] = debugOn;
  }
  isDebug = debugOn ? true : null;
};
const debugLog = (...args) => {
  if (isDebugOn()) {
    console.log(...args);
  }
};

;// ./node_modules/@rpldy/shared/lib/esm/triggerCancellable.js
const triggerCancellable = (trigger, event, ...args) => {
  const doTrigger = (event, ...args) => new Promise((resolve, reject) => {
    const results = trigger(event, ...args);
    if (results && results.length) {
      Promise.all(results).catch(reject).then(resolvedResults => resolvedResults && resolve(!!~resolvedResults.findIndex(r => r === false)));
    } else {
      resolve(false);
    }
  });
  return event ? doTrigger(event, ...args) : doTrigger;
};
/* harmony default export */ const esm_triggerCancellable = (triggerCancellable);
// EXTERNAL MODULE: ./node_modules/@rpldy/shared/lib/esm/utils/isFunction.js
var isFunction = __webpack_require__(74517);
var isFunction_default = /*#__PURE__*/__webpack_require__.n(isFunction);
;// ./node_modules/@rpldy/shared/lib/esm/utils/isSamePropInArrays.js
const getPropsExtractor = prop => {
  const props = [].concat(prop);
  return arr => arr.map(i => props.map(p => i[p]).join());
};
const isSamePropInArrays = (arr1, arr2, prop) => {
  let diff = true;
  const propsExtractor = getPropsExtractor(prop);
  if (arr1 && arr2 && arr1.length === arr2.length) {
    const props1 = propsExtractor(arr1),
      props2 = propsExtractor(arr2);
    diff = !!props1.find((p, i) => p !== props2[i]);
  }
  return !diff;
};
/* harmony default export */ const utils_isSamePropInArrays = (isSamePropInArrays);
// EXTERNAL MODULE: ./node_modules/@rpldy/shared/lib/esm/utils/isProduction.js
var isProduction = __webpack_require__(69398);
var isProduction_default = /*#__PURE__*/__webpack_require__.n(isProduction);
;// ./node_modules/@rpldy/shared/lib/esm/utils/devFreeze.js

const devFreeze = obj => isProduction_default()() ? obj : Object.freeze(obj);
/* harmony default export */ const utils_devFreeze = (devFreeze);
;// ./node_modules/@rpldy/shared/lib/esm/utils/isPlainObject.js
const isPlainObject = obj => {
  const proto = Object.getPrototypeOf(Object(obj));
  return !!obj && typeof obj === "object" && (proto?.constructor.name === "Object" || proto === null) && !Object.prototype.hasOwnProperty.call(obj, "__proto__");
};
/* harmony default export */ const utils_isPlainObject = (isPlainObject);
;// ./node_modules/@rpldy/shared/lib/esm/utils/merge.js

const isMergeObj = obj => utils_isPlainObject(obj) || Array.isArray(obj);
const getKeys = (obj, options) => {
  const keys = Object.keys(obj).filter(k => obj.hasOwnProperty(k) && k !== "__proto__");
  return options.withSymbols ? keys.concat(Object.getOwnPropertySymbols(obj)) : keys;
};
const getMerge = (options = {}) => {
  const merge = (target, ...sources) => {
    if (target && sources.length) {
      sources.forEach(source => {
        if (source) {
          getKeys(source, options).forEach(key => {
            const prop = source[key];
            if (!options.predicate || options.predicate(key, prop)) {
              if (typeof prop !== "undefined" || options.undefinedOverwrites) {
                if (isMergeObj(prop)) {
                  if (typeof target[key] === "undefined" || !utils_isPlainObject(target[key])) {
                    target[key] = Array.isArray(prop) ? [] : {};
                  }
                  merge(target[key], prop);
                } else {
                  target[key] = prop;
                }
              }
            }
          });
        }
      });
    }
    return target;
  };
  return merge;
};
/* harmony default export */ const merge = (getMerge());

;// ./node_modules/@rpldy/shared/lib/esm/utils/clone.js

const clone = (obj, mergeFn = merge) => isMergeObj(obj) ? mergeFn(Array.isArray(obj) ? [] : {}, obj) : obj;
/* harmony default export */ const utils_clone = (clone);
;// ./node_modules/@rpldy/shared/lib/esm/utils/pick.js
const pick = (obj, props) => obj && Object.keys(obj).reduce((res, key) => {
  if (~props.indexOf(key)) {
    res[key] = obj[key];
  }
  return res;
}, {});
/* harmony default export */ const utils_pick = (pick);
;// ./node_modules/@rpldy/shared/lib/esm/utils/isPromise.js
function isPromise(obj) {
  return !!obj && typeof obj === "object" && typeof obj.then === "function";
}
/* harmony default export */ const utils_isPromise = (isPromise);
;// ./node_modules/@rpldy/shared/lib/esm/utils/scheduleIdleWork.js

const supportsIdle = utils_hasWindow() && window.requestIdleCallback;
const scheduler = supportsIdle ? window.requestIdleCallback : setTimeout;
const clear = supportsIdle ? window.cancelIdleCallback : clearTimeout;
const scheduleIdleWork = (fn, timeout = 0) => {
  const handler = scheduler(fn, supportsIdle ? {
    timeout
  } : timeout);
  return () => clear(handler);
};
/* harmony default export */ const utils_scheduleIdleWork = (scheduleIdleWork);
;// ./node_modules/@rpldy/shared/lib/esm/utils/isEmpty.js
function isEmpty(val) {
  return val === null || val === undefined;
}
/* harmony default export */ const utils_isEmpty = (isEmpty);
;// ./node_modules/@rpldy/shared/lib/esm/utils/index.js













;// ./node_modules/@rpldy/shared/lib/esm/triggerUpdater.js

const triggerUpdater = (trigger, event, ...args) => {
  const doTrigger = (event, ...args) => new Promise((resolve, reject) => {
    const results = trigger(event, ...args);
    if (results && results.length) {
      Promise.all(results).catch(reject).then(resolvedResults => {
        let result;
        if (resolvedResults) {
          while (utils_isEmpty(result) && resolvedResults.length) {
            result = resolvedResults.pop();
          }
        }
        resolve(utils_isEmpty(result) ? undefined : result);
      });
    } else {
      resolve();
    }
  });
  return event ? doTrigger(event, ...args) : doTrigger;
};
/* harmony default export */ const esm_triggerUpdater = (triggerUpdater);
;// ./node_modules/@rpldy/shared/lib/esm/enums.js
const BATCH_STATES = (enumObj => Object.freeze(enumObj))({
  PENDING: "pending",
  ADDED: "added",
  PROCESSING: "processing",
  UPLOADING: "uploading",
  CANCELLED: "cancelled",
  FINISHED: "finished",
  ABORTED: "aborted",
  ERROR: "error"
});
const FILE_STATES = (enumObj => Object.freeze(enumObj))({
  PENDING: "pending",
  ADDED: "added",
  UPLOADING: "uploading",
  CANCELLED: "cancelled",
  FINISHED: "finished",
  ERROR: "error",
  ABORTED: "aborted"
});

;// ./node_modules/@rpldy/shared/lib/esm/batchItem.js

const BISYM = Symbol.for("__rpldy-bi__");
let iCounter = 0;
const getBatchItemWithUrl = (batchItem, url) => {
  batchItem.url = url;
  return batchItem;
};
const getBatchItemWithFile = (batchItem, file) => {
  batchItem.file = file;
  return batchItem;
};
const isLikeFile = f => f && (f instanceof File || f instanceof Blob || !!(typeof f === "object" && f.name && f.type));
const getIsBatchItem = obj => {
  return !!(typeof obj === "object" && obj.id && obj.batchId && obj[BISYM] === true);
};
const createBatchItem = (f, batchId, isPending = false) => {
  const isAlreadyBatchItem = getIsBatchItem(f);
  iCounter += isAlreadyBatchItem ? 0 : 1;
  const id = isAlreadyBatchItem && f.id && typeof f.id === "string" ? f.id : `${batchId}.item-${iCounter}`,
    state = isPending ? FILE_STATES.PENDING : FILE_STATES.ADDED;
  let batchItem = {
    id,
    batchId,
    state,
    uploadStatus: 0,
    total: 0,
    completed: 0,
    loaded: 0,
    recycled: isAlreadyBatchItem,
    previousBatch: isAlreadyBatchItem ? f.batchId : null
  };
  Object.defineProperty(batchItem, BISYM, {
    value: true,
    writable: true
  });
  const fileData = isAlreadyBatchItem ? f.file || f.url : f;
  if (typeof fileData === "string") {
    batchItem = getBatchItemWithUrl(batchItem, fileData);
  } else if (isLikeFile(fileData)) {
    batchItem = getBatchItemWithFile(batchItem, fileData);
  } else {
    throw new Error(`Unknown type of file added: ${typeof fileData}`);
  }
  return batchItem;
};
/* harmony default export */ const batchItem = (createBatchItem);

;// ./node_modules/@rpldy/shared/lib/esm/request/XhrPromise.js
class XhrPromise extends Promise {
  constructor(fn, req) {
    super(fn);
    this.xhr = req;
  }
}
/* harmony default export */ const request_XhrPromise = (XhrPromise);
;// ./node_modules/@rpldy/shared/lib/esm/request/request.js

const setHeaders = (req, headers) => {
  if (headers) {
    Object.keys(headers).forEach(name => {
      if (headers[name] !== undefined) {
        req.setRequestHeader(name, headers[name]);
      }
    });
  }
};
const request = (url, data, options = {}) => {
  const req = new XMLHttpRequest();
  return new request_XhrPromise((resolve, reject) => {
    req.onerror = () => reject(req);
    req.ontimeout = () => reject(req);
    req.onabort = () => reject(req);
    req.onload = () => resolve(req);
    req.open(options?.method || "GET", url);
    setHeaders(req, options?.headers);
    req.withCredentials = !!options?.withCredentials;
    options?.preSend?.(req);
    req.send(data);
  }, req);
};
/* harmony default export */ const request_request = (request);
;// ./node_modules/@rpldy/shared/lib/esm/request/parseResponseHeaders.js

const parseResponseHeaders = xhr => {
  let resHeaders;
  try {
    resHeaders = xhr.getAllResponseHeaders().trim().split(/[\r\n]+/).reduce((res, line) => {
      const [key, val] = line.split(": ");
      res[key] = val;
      return res;
    }, {});
  } catch (ex) {
    debugLog("uploady.request: failed to read response headers", xhr);
  }
  return resHeaders;
};
/* harmony default export */ const request_parseResponseHeaders = (parseResponseHeaders);
;// ./node_modules/@rpldy/shared/lib/esm/request/index.js



/* harmony default export */ const esm_request = (request_request);
;// ./node_modules/@rpldy/shared/lib/esm/index.js











/***/ })

}]);