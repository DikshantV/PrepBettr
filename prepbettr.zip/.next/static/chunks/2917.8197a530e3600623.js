"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[2917],{

/***/ 23274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ useAuth),
/* harmony export */   AuthProvider: () => (/* binding */ AuthProvider)
/* harmony export */ });
/* unused harmony export AuthContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* __next_internal_client_entry_do_not_use__ AuthProvider,useAuth,AuthContext auto */ 

/**
 * Refresh the current Firebase auth token
 */ async function refreshAuthToken() {
    try {
        // Import Firebase auth dynamically to avoid SSR issues
        const { getCurrentUserIdToken } = await Promise.all(/* import() */[__webpack_require__.e(2992), __webpack_require__.e(7811), __webpack_require__.e(1840), __webpack_require__.e(3549), __webpack_require__.e(2144)]).then(__webpack_require__.bind(__webpack_require__, 12144));
        console.log('🔄 Attempting to refresh Firebase ID token...');
        // Force refresh the Firebase ID token
        const freshToken = await getCurrentUserIdToken(true);
        if (freshToken) {
            // Update localStorage with the new token
            localStorage.setItem('auth_token', freshToken);
            console.log('✅ Firebase ID token refreshed successfully');
            return freshToken;
        } else {
            console.warn('⚠️ No fresh token returned from Firebase');
            return null;
        }
    } catch (error) {
        console.error('❌ Token refresh failed:', error);
        // If Firebase auth is not available or user is not signed in,
        // clear the auth state completely
        if (error instanceof Error && error.message.includes('No Firebase user signed in')) {
            localStorage.removeItem('auth_token');
            // Clear all caches
            Object.keys(localStorage).forEach((key)=>{
                if (key.startsWith('auth_verification_')) {
                    localStorage.removeItem(key);
                }
            });
        }
        return null;
    }
}
// Create the context with default values
const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    user: null,
    loading: true,
    isAuthenticated: false,
    signOut: async ()=>{}
});
// AuthProvider component that manages unified auth state
function AuthProvider(param) {
    let { children, initialUser } = param;
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialUser || null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!initialUser);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Only check auth state once on mount
        let mounted = true;
        const checkAuthState = async ()=>{
            // Skip auth checks on authentication pages to prevent API loops
            const isAuthPage =  true && [
                '/sign-in',
                '/sign-up'
            ].includes(window.location.pathname);
            if (isAuthPage) {
                console.log('🚫 Auth check skipped: on authentication page');
                if (mounted) {
                    setUser(null);
                    setLoading(false);
                }
                return;
            }
            try {
                // First check for session cookie to avoid unnecessary API call
                const cookies = document.cookie.split(';').reduce((acc, cookie)=>{
                    const [name, value] = cookie.trim().split('=');
                    acc[name] = value;
                    return acc;
                }, {});
                const sessionCookie = cookies.session;
                const token = localStorage.getItem('auth_token');
                // If no session cookie and no token, user is not authenticated
                if (!sessionCookie && !token) {
                    if (mounted) {
                        setUser(null);
                        setLoading(false);
                    }
                    return;
                }
                // Only verify token if we have one
                if (token) {
                    // Check for cached verification result (15 min cache)
                    const cacheKey = "auth_verification_".concat(token.substring(0, 10));
                    const cachedVerification = localStorage.getItem(cacheKey);
                    if (cachedVerification) {
                        try {
                            const cached = JSON.parse(cachedVerification);
                            const cacheAge = Date.now() - cached.timestamp;
                            // Use cached result if less than 15 minutes old
                            if (cacheAge < 15 * 60 * 1000) {
                                console.log('🚀 Using cached auth verification');
                                if (mounted && cached.verified && cached.user) {
                                    setUser(cached.user);
                                }
                                if (mounted) {
                                    setLoading(false);
                                }
                                return;
                            } else {
                                // Remove expired cache
                                localStorage.removeItem(cacheKey);
                            }
                        } catch (error) {
                            // Invalid cache, remove it
                            localStorage.removeItem(cacheKey);
                        }
                    }
                    console.log('🔍 Verifying auth token via API');
                    const response = await fetch('/api/auth/verify', {
                        headers: {
                            'Authorization': "Bearer ".concat(token)
                        }
                    });
                    if (response.ok) {
                        const userData = await response.json();
                        // Cache successful verification
                        const cacheData = {
                            verified: true,
                            user: userData.user,
                            timestamp: Date.now()
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        if (mounted) {
                            setUser(userData.user);
                        }
                    } else if (response.status === 401) {
                        // Token is invalid/expired, check if server suggests refresh
                        const errorData = await response.json().catch(()=>({}));
                        const shouldRefresh = errorData.shouldRefresh !== false; // Default to true
                        console.log('🔄 Token expired/invalid:', errorData.error || 'Unknown error');
                        if (shouldRefresh) {
                            console.log('🔄 Attempting token refresh...');
                            try {
                                const refreshed = await refreshAuthToken();
                                if (refreshed && mounted) {
                                    // Retry verification with new token
                                    const retryResponse = await fetch('/api/auth/verify', {
                                        headers: {
                                            'Authorization': "Bearer ".concat(refreshed)
                                        }
                                    });
                                    if (retryResponse.ok) {
                                        const userData = await retryResponse.json();
                                        // Cache successful verification with new token
                                        const newCacheKey = "auth_verification_".concat(refreshed.substring(0, 10));
                                        const cacheData = {
                                            verified: true,
                                            user: userData.user,
                                            timestamp: Date.now()
                                        };
                                        localStorage.setItem(newCacheKey, JSON.stringify(cacheData));
                                        if (mounted) {
                                            setUser(userData.user);
                                        }
                                        return;
                                    }
                                }
                            } catch (refreshError) {
                                console.error('🔄 Token refresh failed:', refreshError);
                            }
                        }
                        // If refresh failed or not recommended, clear auth state
                        localStorage.removeItem('auth_token');
                        // Clear all verification caches
                        Object.keys(localStorage).forEach((key)=>{
                            if (key.startsWith('auth_verification_')) {
                                localStorage.removeItem(key);
                            }
                        });
                        if (mounted) {
                            setUser(null);
                        }
                    } else {
                        // Other error, cache failed verification temporarily (1 min)
                        const cacheData = {
                            verified: false,
                            user: null,
                            timestamp: Date.now() - 14 * 60 * 1000 // Expire quickly for failed attempts
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        localStorage.removeItem('auth_token');
                        if (mounted) {
                            setUser(null);
                        }
                    }
                } else if (sessionCookie) {
                    // If we have session cookie but no token, consider user logged in
                    // but with minimal user data
                    if (mounted) {
                        setUser({
                            uid: 'session-user',
                            email: 'unknown@session.com',
                            email_verified: false
                        });
                    }
                }
            } catch (error) {
                console.error('Auth state check failed:', error);
                if (mounted) {
                    setUser(null);
                }
            } finally{
                if (mounted) {
                    setLoading(false);
                }
            }
        };
        if (!initialUser) {
            checkAuthState();
        } else {
            setLoading(false);
        }
        return ()=>{
            mounted = false;
        };
    }, [
        initialUser
    ]);
    const signOut = async ()=>{
        try {
            await fetch('/api/auth/signout', {
                method: 'POST'
            });
            localStorage.removeItem('auth_token');
            setUser(null);
        } catch (error) {
            console.error('Sign out error:', error);
        }
    };
    const contextValue = {
        user,
        loading,
        isAuthenticated: !!user,
        signOut
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(AuthContext.Provider, {
        value: contextValue,
        children: children
    });
}
// Custom hook to use the auth context
function useAuth() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthContext);
    if (context === undefined) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
}
// Export the context for advanced use cases



/***/ }),

/***/ 25657:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Bot)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19946);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M12 8V4H8",
            key: "hb8ula"
        }
    ],
    [
        "rect",
        {
            width: "16",
            height: "12",
            x: "4",
            y: "8",
            rx: "2",
            key: "enze0r"
        }
    ],
    [
        "path",
        {
            d: "M2 14h2",
            key: "vft8re"
        }
    ],
    [
        "path",
        {
            d: "M20 14h2",
            key: "4cs60a"
        }
    ],
    [
        "path",
        {
            d: "M15 13v2",
            key: "1xurst"
        }
    ],
    [
        "path",
        {
            d: "M9 13v2",
            key: "rq6x2g"
        }
    ]
];
const Bot = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("bot", __iconNode);
 //# sourceMappingURL=bot.js.map


/***/ }),

/***/ 34964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Xi: () => (/* binding */ TabsTrigger),
/* harmony export */   av: () => (/* binding */ TabsContent),
/* harmony export */   j7: () => (/* binding */ TabsList),
/* harmony export */   tU: () => (/* binding */ Tabs)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60704);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);




const Tabs = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .bL;
const TabsList = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .List */ .B8, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    });
});
TabsList.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .List */ .B8.displayName;
const TabsTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    });
});
TabsTrigger.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9.displayName;
const TabsContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    });
});
TabsContent.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC.displayName;



/***/ }),

/***/ 47924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Search)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19946);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "m21 21-4.34-4.34",
            key: "14j7rj"
        }
    ],
    [
        "circle",
        {
            cx: "11",
            cy: "11",
            r: "8",
            key: "4ej97u"
        }
    ]
];
const Search = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("search", __iconNode);
 //# sourceMappingURL=search.js.map


/***/ }),

/***/ 60704:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   B8: () => (/* binding */ List),
/* harmony export */   UC: () => (/* binding */ Content),
/* harmony export */   bL: () => (/* binding */ Root2),
/* harmony export */   l9: () => (/* binding */ Trigger)
/* harmony export */ });
/* unused harmony exports Tabs, TabsContent, TabsList, TabsTrigger, createTabsScope */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_primitive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(85185);
/* harmony import */ var _radix_ui_react_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46081);
/* harmony import */ var _radix_ui_react_roving_focus__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(89196);
/* harmony import */ var _radix_ui_react_presence__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(28905);
/* harmony import */ var _radix_ui_react_primitive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(63655);
/* harmony import */ var _radix_ui_react_direction__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94315);
/* harmony import */ var _radix_ui_react_use_controllable_state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5845);
/* harmony import */ var _radix_ui_react_id__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(61285);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95155);
/* __next_internal_client_entry_do_not_use__ Content,List,Root,Tabs,TabsContent,TabsList,TabsTrigger,Trigger,createTabsScope auto */ // src/tabs.tsx











var TABS_NAME = "Tabs";
var [createTabsContext, createTabsScope] = (0,_radix_ui_react_context__WEBPACK_IMPORTED_MODULE_2__/* .createContextScope */ .A)(TABS_NAME, [
    _radix_ui_react_roving_focus__WEBPACK_IMPORTED_MODULE_3__/* .createRovingFocusGroupScope */ .RG
]);
var useRovingFocusGroupScope = (0,_radix_ui_react_roving_focus__WEBPACK_IMPORTED_MODULE_3__/* .createRovingFocusGroupScope */ .RG)();
var [TabsProvider, useTabsContext] = createTabsContext(TABS_NAME);
var Tabs = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.forwardRef((props, forwardedRef)=>{
    const { __scopeTabs, value: valueProp, onValueChange, defaultValue, orientation = "horizontal", dir, activationMode = "automatic", ...tabsProps } = props;
    const direction = (0,_radix_ui_react_direction__WEBPACK_IMPORTED_MODULE_4__/* .useDirection */ .jH)(dir);
    const [value, setValue] = (0,_radix_ui_react_use_controllable_state__WEBPACK_IMPORTED_MODULE_5__/* .useControllableState */ .i)({
        prop: valueProp,
        onChange: onValueChange,
        defaultProp: defaultValue !== null && defaultValue !== void 0 ? defaultValue : "",
        caller: TABS_NAME
    });
    return /* @__PURE__ */ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(TabsProvider, {
        scope: __scopeTabs,
        baseId: (0,_radix_ui_react_id__WEBPACK_IMPORTED_MODULE_6__/* .useId */ .B)(),
        value,
        onValueChange: setValue,
        orientation,
        dir: direction,
        activationMode,
        children: /* @__PURE__ */ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_radix_ui_react_primitive__WEBPACK_IMPORTED_MODULE_7__/* .Primitive */ .sG.div, {
            dir: direction,
            "data-orientation": orientation,
            ...tabsProps,
            ref: forwardedRef
        })
    });
});
Tabs.displayName = TABS_NAME;
var TAB_LIST_NAME = "TabsList";
var TabsList = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.forwardRef((props, forwardedRef)=>{
    const { __scopeTabs, loop = true, ...listProps } = props;
    const context = useTabsContext(TAB_LIST_NAME, __scopeTabs);
    const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeTabs);
    return /* @__PURE__ */ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_radix_ui_react_roving_focus__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .bL, {
        asChild: true,
        ...rovingFocusGroupScope,
        orientation: context.orientation,
        dir: context.dir,
        loop,
        children: /* @__PURE__ */ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_radix_ui_react_primitive__WEBPACK_IMPORTED_MODULE_7__/* .Primitive */ .sG.div, {
            role: "tablist",
            "aria-orientation": context.orientation,
            ...listProps,
            ref: forwardedRef
        })
    });
});
TabsList.displayName = TAB_LIST_NAME;
var TRIGGER_NAME = "TabsTrigger";
var TabsTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.forwardRef((props, forwardedRef)=>{
    const { __scopeTabs, value, disabled = false, ...triggerProps } = props;
    const context = useTabsContext(TRIGGER_NAME, __scopeTabs);
    const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeTabs);
    const triggerId = makeTriggerId(context.baseId, value);
    const contentId = makeContentId(context.baseId, value);
    const isSelected = value === context.value;
    return /* @__PURE__ */ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_radix_ui_react_roving_focus__WEBPACK_IMPORTED_MODULE_3__/* .Item */ .q7, {
        asChild: true,
        ...rovingFocusGroupScope,
        focusable: !disabled,
        active: isSelected,
        children: /* @__PURE__ */ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_radix_ui_react_primitive__WEBPACK_IMPORTED_MODULE_7__/* .Primitive */ .sG.button, {
            type: "button",
            role: "tab",
            "aria-selected": isSelected,
            "aria-controls": contentId,
            "data-state": isSelected ? "active" : "inactive",
            "data-disabled": disabled ? "" : void 0,
            disabled,
            id: triggerId,
            ...triggerProps,
            ref: forwardedRef,
            onMouseDown: (0,_radix_ui_primitive__WEBPACK_IMPORTED_MODULE_8__/* .composeEventHandlers */ .mK)(props.onMouseDown, (event)=>{
                if (!disabled && event.button === 0 && event.ctrlKey === false) {
                    context.onValueChange(value);
                } else {
                    event.preventDefault();
                }
            }),
            onKeyDown: (0,_radix_ui_primitive__WEBPACK_IMPORTED_MODULE_8__/* .composeEventHandlers */ .mK)(props.onKeyDown, (event)=>{
                if ([
                    " ",
                    "Enter"
                ].includes(event.key)) context.onValueChange(value);
            }),
            onFocus: (0,_radix_ui_primitive__WEBPACK_IMPORTED_MODULE_8__/* .composeEventHandlers */ .mK)(props.onFocus, ()=>{
                const isAutomaticActivation = context.activationMode !== "manual";
                if (!isSelected && !disabled && isAutomaticActivation) {
                    context.onValueChange(value);
                }
            })
        })
    });
});
TabsTrigger.displayName = TRIGGER_NAME;
var CONTENT_NAME = "TabsContent";
var TabsContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.forwardRef((props, forwardedRef)=>{
    const { __scopeTabs, value, forceMount, children, ...contentProps } = props;
    const context = useTabsContext(CONTENT_NAME, __scopeTabs);
    const triggerId = makeTriggerId(context.baseId, value);
    const contentId = makeContentId(context.baseId, value);
    const isSelected = value === context.value;
    const isMountAnimationPreventedRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef(isSelected);
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(()=>{
        const rAF = requestAnimationFrame(()=>isMountAnimationPreventedRef.current = false);
        return ()=>cancelAnimationFrame(rAF);
    }, []);
    return /* @__PURE__ */ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_radix_ui_react_presence__WEBPACK_IMPORTED_MODULE_9__/* .Presence */ .C, {
        present: forceMount || isSelected,
        children: (param)=>{
            let { present } = param;
            return /* @__PURE__ */ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_radix_ui_react_primitive__WEBPACK_IMPORTED_MODULE_7__/* .Primitive */ .sG.div, {
                "data-state": isSelected ? "active" : "inactive",
                "data-orientation": context.orientation,
                role: "tabpanel",
                "aria-labelledby": triggerId,
                hidden: !present,
                id: contentId,
                tabIndex: 0,
                ...contentProps,
                ref: forwardedRef,
                style: {
                    ...props.style,
                    animationDuration: isMountAnimationPreventedRef.current ? "0s" : void 0
                },
                children: present && children
            });
        }
    });
});
TabsContent.displayName = CONTENT_NAME;
function makeTriggerId(baseId, value) {
    return "".concat(baseId, "-trigger-").concat(value);
}
function makeContentId(baseId, value) {
    return "".concat(baseId, "-content-").concat(value);
}
var Root2 = Tabs;
var List = TabsList;
var Trigger = TabsTrigger;
var Content = TabsContent;
 //# sourceMappingURL=index.mjs.map


/***/ }),

/***/ 65061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15933);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44987);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36680);

function _templateObject() {
    const data = (0,_swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__._)([
        '\n  .banter-loader {\n    position: relative;\n    width: 72px;\n    height: 72px;\n    margin: 0 auto;\n  }\n\n  .banter-loader__box {\n    float: left;\n    position: relative;\n    width: 20px;\n    height: 20px;\n    margin-right: 6px;\n  }\n\n  .banter-loader__box:before {\n    content: "";\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 100%;\n    height: 100%;\n    background: #fff;\n  }\n\n  .banter-loader__box:nth-child(3n) {\n    margin-right: 0;\n    margin-bottom: 6px;\n  }\n\n  .banter-loader__box:nth-child(1):before, .banter-loader__box:nth-child(4):before {\n    margin-left: 26px;\n  }\n\n  .banter-loader__box:nth-child(3):before {\n    margin-top: 52px;\n  }\n\n  .banter-loader__box:last-child {\n    margin-bottom: 0;\n  }\n\n  @keyframes moveBox-1 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(1) {\n    animation: moveBox-1 4s infinite;\n  }\n\n  @keyframes moveBox-2 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, 26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(2) {\n    animation: moveBox-2 4s infinite;\n  }\n\n  @keyframes moveBox-3 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(-26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(-26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(3) {\n    animation: moveBox-3 4s infinite;\n  }\n\n  @keyframes moveBox-4 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(4) {\n    animation: moveBox-4 4s infinite;\n  }\n\n  @keyframes moveBox-5 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(5) {\n    animation: moveBox-5 4s infinite;\n  }\n\n  @keyframes moveBox-6 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(6) {\n    animation: moveBox-6 4s infinite;\n  }\n\n  @keyframes moveBox-7 {\n    9.0909090909% {\n      transform: translate(26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(7) {\n    animation: moveBox-7 4s infinite;\n  }\n\n  @keyframes moveBox-8 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(8) {\n    animation: moveBox-8 4s infinite;\n  }\n\n  @keyframes moveBox-9 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-52px, 0);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0);\n    }\n\n    100% {\n      transform: translate(0px, 0);\n    }\n  }\n\n  .banter-loader__box:nth-child(9) {\n    animation: moveBox-9 4s infinite;\n  }\n'
    ]);
    _templateObject = function() {
        return data;
    };
    return data;
}




const Loader = (param)=>{
    let { overlay = false, text, backgroundOpacity = 80, blur = true, className, ariaLabel = 'Loading...' } = param;
    const loaderContent = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(StyledWrapper, {
        className: className,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
                className: "banter-loader",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    })
                ]
            }),
            overlay && text && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("p", {
                className: "text-white text-center mt-4 font-medium",
                "aria-live": "polite",
                children: text
            })
        ]
    });
    if (overlay) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("fixed inset-0 z-50 flex items-center justify-center flex-col", blur && "backdrop-blur-md", "transition-all duration-300"),
            style: {
                backgroundColor: "rgba(0, 0, 0, ".concat(backgroundOpacity / 100, ")"),
                backdropFilter: blur ? 'blur(8px)' : 'none',
                WebkitBackdropFilter: blur ? 'blur(8px)' : 'none'
            },
            role: "dialog",
            "aria-modal": "true",
            "aria-label": ariaLabel,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                className: "relative",
                children: loaderContent
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
        role: "status",
        "aria-label": ariaLabel,
        children: loaderContent
    });
};
const StyledWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Ay.div(_templateObject());
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ }),

/***/ 71539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Zap)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19946);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
            key: "1xq2db"
        }
    ]
];
const Zap = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("zap", __iconNode);
 //# sourceMappingURL=zap.js.map


/***/ }),

/***/ 72917:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  AutoApplyDashboard: () => (/* binding */ AutoApplyDashboard)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
;// ./types/auto-apply.ts
// Auto-Apply Job Application Types and Interfaces
// Constants
const JOB_PORTALS = [
    {
        name: 'LinkedIn',
        logo: '/icons/linkedin.svg',
        website: 'https://linkedin.com',
        supportsAutoApply: true
    },
    {
        name: 'Indeed',
        logo: '/icons/indeed.svg',
        website: 'https://indeed.com',
        supportsAutoApply: true
    },
    {
        name: 'Glassdoor',
        logo: '/icons/glassdoor.svg',
        website: 'https://glassdoor.com',
        supportsAutoApply: false
    },
    {
        name: 'AngelList',
        logo: '/icons/angellist.svg',
        website: 'https://angel.co',
        supportsAutoApply: true
    },
    {
        name: 'RemoteOK',
        logo: '/icons/remoteok.svg',
        website: 'https://remoteok.io',
        supportsAutoApply: false
    }
];
const APPLICATION_STATUS_LABELS = {
    'discovered': 'Discovered',
    'analyzing': 'Analyzing',
    'ready_to_apply': 'Ready to Apply',
    'applying': 'Applying',
    'applied': 'Applied',
    'application_viewed': 'Application Viewed',
    'interview_request': 'Interview Request',
    'rejected': 'Rejected',
    'withdrawn': 'Withdrawn',
    'expired': 'Expired'
};
const APPLICATION_STATUS_COLORS = {
    'discovered': 'bg-blue-500',
    'analyzing': 'bg-yellow-500',
    'ready_to_apply': 'bg-green-500',
    'applying': 'bg-orange-500',
    'applied': 'bg-purple-500',
    'application_viewed': 'bg-indigo-500',
    'interview_request': 'bg-emerald-500',
    'rejected': 'bg-red-500',
    'withdrawn': 'bg-gray-500',
    'expired': 'bg-gray-400'
};

// EXTERNAL MODULE: ./components/ui/card.tsx
var card = __webpack_require__(88482);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(97168);
// EXTERNAL MODULE: ./components/ui/badge.tsx
var badge = __webpack_require__(88145);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/createLucideIcon.js + 3 modules
var createLucideIcon = __webpack_require__(19946);
;// ./node_modules/lucide-react/dist/esm/icons/chart-column.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M3 3v16a2 2 0 0 0 2 2h16",
            key: "c24i48"
        }
    ],
    [
        "path",
        {
            d: "M18 17V9",
            key: "2bz60n"
        }
    ],
    [
        "path",
        {
            d: "M13 17V5",
            key: "1frdt8"
        }
    ],
    [
        "path",
        {
            d: "M8 17v-3",
            key: "17ska0"
        }
    ]
];
const ChartColumn = (0,createLucideIcon/* default */.A)("chart-column", __iconNode);
 //# sourceMappingURL=chart-column.js.map

;// ./node_modules/lucide-react/dist/esm/icons/eye.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const eye_iconNode = [
    [
        "path",
        {
            d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
            key: "1nclc0"
        }
    ],
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "3",
            key: "1v7zrd"
        }
    ]
];
const Eye = (0,createLucideIcon/* default */.A)("eye", eye_iconNode);
 //# sourceMappingURL=eye.js.map

// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/zap.js
var zap = __webpack_require__(71539);
;// ./node_modules/lucide-react/dist/esm/icons/external-link.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const external_link_iconNode = [
    [
        "path",
        {
            d: "M15 3h6v6",
            key: "1q9fwt"
        }
    ],
    [
        "path",
        {
            d: "M10 14 21 3",
            key: "gplh6r"
        }
    ],
    [
        "path",
        {
            d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
            key: "a6xqqp"
        }
    ]
];
const ExternalLink = (0,createLucideIcon/* default */.A)("external-link", external_link_iconNode);
 //# sourceMappingURL=external-link.js.map

// EXTERNAL MODULE: ./components/ui/BanterLoader.tsx
var BanterLoader = __webpack_require__(65061);
;// ./components/JobListingTable.tsx








const JobListingTable = (param)=>{
    let { jobs, onApply, onAnalyze, onView, loading, pagination } = param;
    if (jobs.length === 0) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* Card */.Zp, {
            className: "bg-gray-900 border-gray-700",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                className: "flex flex-col items-center justify-center py-12",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "text-gray-400 mb-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ChartColumn, {
                            className: "h-12 w-12"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                        className: "text-lg font-semibold text-white mb-2",
                        children: "No jobs found"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                        className: "text-gray-300 text-center max-w-md",
                        children: "Try adjusting your search filters or keywords to find more relevant positions."
                    })
                ]
            })
        });
    }
    const formatSalary = (salary)=>{
        if (!salary) return 'Not specified';
        const formatNumber = (num)=>new Intl.NumberFormat('en-US').format(num);
        const min = salary.min ? formatNumber(salary.min) : '';
        const max = salary.max ? formatNumber(salary.max) : '';
        const range = min && max ? "".concat(min, " - ").concat(max) : min || max || 'Not specified';
        return "".concat(salary.currency, " ").concat(range, "/").concat(salary.period);
    };
    const formatDate = (dateString)=>{
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now.getTime() - date.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays === 1) return '1 day ago';
        if (diffDays < 7) return "".concat(diffDays, " days ago");
        if (diffDays < 30) return "".concat(Math.ceil(diffDays / 7), " weeks ago");
        // Use consistent date format to avoid hydration mismatch
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    };
    // Dark theme optimized status colors with high contrast
    const getStatusColor = (status)=>{
        const colors = {
            'discovered': 'bg-blue-600 text-white border border-blue-500',
            'analyzing': 'bg-yellow-600 text-white border border-yellow-500',
            'ready_to_apply': 'bg-green-600 text-white border border-green-500',
            'applying': 'bg-orange-600 text-white border border-orange-500',
            'applied': 'bg-purple-600 text-white border border-purple-500',
            'application_viewed': 'bg-indigo-600 text-white border border-indigo-500',
            'interview_request': 'bg-emerald-600 text-white border border-emerald-500',
            'rejected': 'bg-red-600 text-white border border-red-500',
            'withdrawn': 'bg-gray-600 text-white border border-gray-500',
            'expired': 'bg-gray-700 text-gray-300 border border-gray-600'
        };
        return colors[status] || 'bg-gray-600 text-white border border-gray-500';
    };
    // Dark theme optimized relevancy score colors with better contrast
    const getRelevancyColor = (score)=>{
        if (!score) return 'text-gray-400';
        if (score >= 85) return 'text-green-400 font-semibold';
        if (score >= 70) return 'text-blue-400 font-medium';
        if (score >= 50) return 'text-yellow-400';
        return 'text-red-400';
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
        className: "bg-gray-900 border-gray-700",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardHeader */.aR, {
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardTitle */.ZB, {
                    className: "flex items-center gap-2 text-white",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)(ChartColumn, {
                            className: "h-5 w-5 text-blue-400"
                        }),
                        "Job Opportunities (",
                        jobs.length,
                        ")"
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                className: "p-0",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "overflow-x-auto",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("table", {
                            className: "w-full",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("thead", {
                                    className: "border-b border-gray-700 bg-gray-800",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("tr", {
                                        className: "text-left",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("th", {
                                                className: "px-4 py-3 text-sm font-medium text-gray-200",
                                                children: "Job Details"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("th", {
                                                className: "px-4 py-3 text-sm font-medium text-gray-200",
                                                children: "Company"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("th", {
                                                className: "px-4 py-3 text-sm font-medium text-gray-200",
                                                children: "Portal"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("th", {
                                                className: "px-4 py-3 text-sm font-medium text-gray-200",
                                                children: "Match Score"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("th", {
                                                className: "px-4 py-3 text-sm font-medium text-gray-200",
                                                children: "Status"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("th", {
                                                className: "px-4 py-3 text-sm font-medium text-gray-200",
                                                children: "Actions"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("tbody", {
                                    className: "divide-y divide-gray-700",
                                    children: jobs.map((job)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("tr", {
                                            className: "hover:bg-gray-800 transition-colors",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("td", {
                                                    className: "px-4 py-4",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "space-y-1",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                                className: "font-medium text-white text-sm",
                                                                children: job.title
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                className: "text-xs text-gray-400",
                                                                children: [
                                                                    job.location,
                                                                    " • ",
                                                                    job.workArrangement
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                                className: "text-xs text-gray-400",
                                                                children: formatSalary(job.salary)
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                className: "text-xs text-gray-500",
                                                                children: [
                                                                    "Posted ",
                                                                    formatDate(job.postedDate)
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("td", {
                                                    className: "px-4 py-4",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                            className: "text-sm font-medium text-white",
                                                            children: job.company
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                            className: "text-xs text-gray-400 capitalize",
                                                            children: job.jobType
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("td", {
                                                    className: "px-4 py-4",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                                className: "text-sm font-medium text-white",
                                                                children: job.jobPortal.name
                                                            }),
                                                            job.jobPortal.supportsAutoApply && /*#__PURE__*/ (0,jsx_runtime.jsx)(badge/* Badge */.E, {
                                                                variant: "secondary",
                                                                className: "text-xs bg-gray-700 text-gray-200 border-gray-600",
                                                                children: "Auto-Apply"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("td", {
                                                    className: "px-4 py-4",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                            className: "text-sm font-semibold ".concat(getRelevancyColor(job.relevancyScore)),
                                                            children: job.relevancyScore ? "".concat(job.relevancyScore, "%") : 'N/A'
                                                        }),
                                                        job.matchedSkills && job.matchedSkills.length > 0 && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "text-xs text-gray-400 mt-1",
                                                            children: [
                                                                job.matchedSkills.slice(0, 2).join(', '),
                                                                job.matchedSkills.length > 2 && " +".concat(job.matchedSkills.length - 2)
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("td", {
                                                    className: "px-4 py-4",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(badge/* Badge */.E, {
                                                        className: "text-xs ".concat(getStatusColor(job.applicationStatus)),
                                                        children: [
                                                            job.applicationStatus === 'applying' && /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {
                                                                className: "mr-1"
                                                            }),
                                                            APPLICATION_STATUS_LABELS[job.applicationStatus] || job.applicationStatus
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)("td", {
                                                    className: "px-4 py-4",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "flex items-center gap-1",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                                variant: "ghost",
                                                                size: "sm",
                                                                onClick: ()=>onView(job.id),
                                                                className: "h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700",
                                                                title: "View job posting",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Eye, {
                                                                    className: "h-3 w-3"
                                                                })
                                                            }),
                                                            job.applicationStatus === 'discovered' && /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                                variant: "ghost",
                                                                size: "sm",
                                                                onClick: ()=>onAnalyze(job.id),
                                                                className: "h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-gray-700",
                                                                title: "Analyze job match",
                                                                disabled: loading,
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ChartColumn, {
                                                                    className: "h-3 w-3"
                                                                })
                                                            }),
                                                            (job.applicationStatus === 'ready_to_apply' || job.applicationStatus === 'analyzing' || job.applicationStatus === 'applying') && /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                                variant: "ghost",
                                                                size: "sm",
                                                                onClick: ()=>onApply(job.id),
                                                                className: "h-8 w-8 p-0 text-green-400 hover:text-green-300 hover:bg-gray-700",
                                                                title: "Apply to job",
                                                                disabled: loading || job.applicationStatus === 'applying',
                                                                children: job.applicationStatus === 'applying' ? /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {}) : /*#__PURE__*/ (0,jsx_runtime.jsx)(zap/* default */.A, {
                                                                    className: "h-3 w-3"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                                variant: "ghost",
                                                                size: "sm",
                                                                onClick: ()=>window.open(job.originalUrl, '_blank'),
                                                                className: "h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700",
                                                                title: "Open original job posting",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ExternalLink, {
                                                                    className: "h-3 w-3"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }, job.id))
                                })
                            ]
                        })
                    }),
                    pagination && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "border-t border-gray-700 px-4 py-4 flex items-center justify-between bg-gray-800",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-sm text-gray-300",
                                children: [
                                    "Showing ",
                                    Math.min(pagination.pageSize, jobs.length),
                                    " of ",
                                    pagination.total,
                                    " jobs"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                        variant: "outline",
                                        size: "sm",
                                        onClick: ()=>pagination.onChange(pagination.current - 1),
                                        disabled: pagination.current <= 1,
                                        className: "border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white",
                                        children: "Previous"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                        className: "text-sm text-gray-300",
                                        children: [
                                            "Page ",
                                            pagination.current,
                                            " of ",
                                            Math.ceil(pagination.total / pagination.pageSize)
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                        variant: "outline",
                                        size: "sm",
                                        onClick: ()=>pagination.onChange(pagination.current + 1),
                                        disabled: pagination.current >= Math.ceil(pagination.total / pagination.pageSize),
                                        className: "border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white",
                                        children: "Next"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};

;// ./components/JobFilters.tsx




const JobFilters = (param)=>{
    let { filters, onChange, onSearch, loading } = param;
    const handleKeywordChange = (e)=>{
        const keywords = e.target.value.split(',').map((keyword)=>keyword.trim()).filter(Boolean);
        onChange({
            ...filters,
            keywords
        });
    };
    const handleLocationChange = (e)=>{
        const locations = e.target.value.split(',').map((location)=>location.trim()).filter(Boolean);
        onChange({
            ...filters,
            locations
        });
    };
    const handleJobTypeChange = (jobType, checked)=>{
        const newJobTypes = checked ? [
            ...filters.jobTypes,
            jobType
        ] : filters.jobTypes.filter((type)=>type !== jobType);
        onChange({
            ...filters,
            jobTypes: newJobTypes
        });
    };
    const handleWorkArrangementChange = (arrangement, checked)=>{
        const newArrangements = checked ? [
            ...filters.workArrangements,
            arrangement
        ] : filters.workArrangements.filter((arr)=>arr !== arrangement);
        onChange({
            ...filters,
            workArrangements: newArrangements
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "bg-gray-900 border border-gray-700 p-6 rounded-lg shadow-md space-y-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                className: "text-lg font-semibold text-white",
                children: "Job Search Filters"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                                className: "block text-sm font-medium text-gray-200 mb-1",
                                children: "Keywords"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                type: "text",
                                placeholder: "React, JavaScript, Python...",
                                className: "w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500",
                                onChange: handleKeywordChange,
                                value: filters.keywords.join(', ')
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                                className: "block text-sm font-medium text-gray-200 mb-1",
                                children: "Locations"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                type: "text",
                                placeholder: "New York, Remote, San Francisco...",
                                className: "w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500",
                                onChange: handleLocationChange,
                                value: filters.locations.join(', ')
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                                className: "block text-sm font-medium text-gray-200 mb-1",
                                children: "Date Posted"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                                className: "w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500",
                                value: filters.datePosted,
                                onChange: (e)=>onChange({
                                        ...filters,
                                        datePosted: e.target.value
                                    }),
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: "any",
                                        children: "Any time"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: "past-24-hours",
                                        children: "Past 24 hours"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: "past-week",
                                        children: "Past week"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                        value: "past-month",
                                        children: "Past month"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                                className: "block text-sm font-medium text-gray-200 mb-2",
                                children: "Job Type"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "space-y-2",
                                children: [
                                    'full-time',
                                    'part-time',
                                    'contract',
                                    'internship'
                                ].map((type)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                                type: "checkbox",
                                                checked: filters.jobTypes.includes(type),
                                                onChange: (e)=>handleJobTypeChange(type, e.target.checked),
                                                className: "mr-2 text-blue-500 bg-gray-800 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                className: "capitalize text-gray-300",
                                                children: type.replace('-', ' ')
                                            })
                                        ]
                                    }, type))
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                                className: "block text-sm font-medium text-gray-200 mb-2",
                                children: "Work Arrangement"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "space-y-2",
                                children: [
                                    'remote',
                                    'hybrid',
                                    'onsite'
                                ].map((arrangement)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                                type: "checkbox",
                                                checked: filters.workArrangements.includes(arrangement),
                                                onChange: (e)=>handleWorkArrangementChange(arrangement, e.target.checked),
                                                className: "mr-2 text-blue-500 bg-gray-800 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                className: "capitalize text-gray-300",
                                                children: arrangement
                                            })
                                        ]
                                    }, arrangement))
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                onClick: onSearch,
                disabled: loading,
                className: "w-full bg-blue-600 hover:bg-blue-700 text-white border-blue-600",
                children: [
                    loading && /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {
                        className: "mr-2"
                    }),
                    loading ? 'Searching...' : 'Search Jobs'
                ]
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(56671);
// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(23274);
;// ./components/ResumeUpload.tsx






const ResumeUpload = (param)=>{
    let { onProfileExtracted, loading } = param;
    const { user } = (0,AuthContext/* useAuth */.A)();
    const [file, setFile] = (0,react.useState)(null);
    const [error, setError] = (0,react.useState)(null);
    const [isUploading, setIsUploading] = (0,react.useState)(false);
    const handleFileChange = (event)=>{
        const selectedFile = event.target.files ? event.target.files[0] : null;
        if (selectedFile) {
            if (selectedFile.size > 10 * 1024 * 1024) {
                setError('File size cannot exceed 10MB.');
                dist/* toast */.o.error('File size cannot exceed 10MB.');
                setFile(null);
            } else {
                setFile(selectedFile);
                setError(null);
            }
        }
    };
    const handleUpload = async ()=>{
        if (!file) {
            setError('Please select a file to upload.');
            dist/* toast */.o.warning('Please select a file to upload.');
            return;
        }
        if (!user) {
            setError('You must be logged in to upload a resume.');
            dist/* toast */.o.error('Authentication error. Please log in again.');
            return;
        }
        // Get auth token from localStorage
        const token = localStorage.getItem('auth_token');
        if (!token) {
            setError('Authentication token not found. Please log in again.');
            dist/* toast */.o.error('Authentication error. Please log in again.');
            return;
        }
        setIsUploading(true);
        setError(null);
        try {
            const formData = new FormData();
            formData.append('file', file);
            const response = await fetch('/api/upload-pdf', {
                method: 'POST',
                headers: {
                    Authorization: "Bearer ".concat(token)
                },
                body: formData
            });
            const result = await response.json();
            if (response.ok) {
                dist/* toast */.o.success('Resume uploaded and processed successfully!');
                onProfileExtracted(result.extractedData);
                console.log('File uploaded to:', result.fileUrl);
            } else {
                throw new Error(result.error || 'Upload failed');
            }
        } catch (err) {
            console.error(err);
            const errorMessage = err.message || 'Failed to upload the file. Please try again.';
            setError(errorMessage);
            dist/* toast */.o.error(errorMessage);
        } finally{
            setIsUploading(false);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "bg-gray-900 border border-gray-700 p-6 rounded-lg shadow-md space-y-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                className: "text-lg font-semibold text-white",
                children: "Upload Your Resume"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                        className: "block text-sm font-medium text-gray-200 mb-1",
                        children: "Select a PDF file"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                        type: "file",
                        accept: ".pdf",
                        onChange: handleFileChange,
                        className: "w-full text-gray-300 bg-gray-800 border border-gray-600 rounded-md p-2 file:mr-4 file:py-1 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-blue-600 file:text-white hover:file:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    }),
                    error && /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                        className: "text-red-400 text-sm mt-2",
                        children: error
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                onClick: handleUpload,
                disabled: loading || isUploading || !file,
                className: "w-full bg-blue-600 hover:bg-blue-700 text-white border-blue-600 disabled:bg-gray-700 disabled:text-gray-400",
                children: [
                    (loading || isUploading) && /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {
                        className: "mr-2"
                    }),
                    loading || isUploading ? 'Uploading...' : 'Upload and Extract'
                ]
            })
        ]
    });
};

;// ./components/SettingsForm.tsx




const SettingsForm = (param)=>{
    let { settings, onChange, onSave, loading } = param;
    const handleToggleChange = (field, value)=>{
        onChange({
            ...settings,
            [field]: value
        });
    };
    const handleInputChange = (field, value)=>{
        onChange({
            ...settings,
            [field]: value
        });
    };
    const handleNotificationChange = (field, value)=>{
        onChange({
            ...settings,
            notifications: {
                ...settings.notifications,
                [field]: value
            }
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "bg-gray-900 border border-gray-700 p-6 rounded-lg shadow-md space-y-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                className: "text-lg font-semibold text-white",
                children: "Auto-Apply Settings"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                            className: "flex items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                    type: "checkbox",
                                    checked: settings.isEnabled,
                                    onChange: (e)=>handleToggleChange('isEnabled', e.target.checked),
                                    className: "mr-2 text-blue-500 bg-gray-800 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    className: "text-gray-200",
                                    children: "Enable Auto-Apply"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                                className: "block text-sm font-medium text-gray-200 mb-1",
                                children: "Daily Application Limit"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                type: "number",
                                value: settings.dailyApplicationLimit,
                                onChange: (e)=>handleInputChange('dailyApplicationLimit', parseInt(e.target.value)),
                                min: "1",
                                max: "50",
                                className: "w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                                className: "block text-sm font-medium text-gray-200 mb-1",
                                children: "Auto-Apply Threshold (%)"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                type: "number",
                                value: settings.autoApplyThreshold,
                                onChange: (e)=>handleInputChange('autoApplyThreshold', parseInt(e.target.value)),
                                min: "0",
                                max: "100",
                                className: "w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                className: "text-xs text-gray-400 mt-1",
                                children: "Minimum relevancy score to automatically apply"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                            className: "flex items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                    type: "checkbox",
                                    checked: settings.useCustomCoverLetter,
                                    onChange: (e)=>handleToggleChange('useCustomCoverLetter', e.target.checked),
                                    className: "mr-2 text-blue-500 bg-gray-800 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    className: "text-gray-200",
                                    children: "Use Custom Cover Letter"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                        className: "block text-sm font-medium text-gray-200 mb-1",
                        children: "Blacklisted Companies"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                        type: "text",
                        placeholder: "Company 1, Company 2, ...",
                        value: settings.blacklistedCompanies.join(', '),
                        onChange: (e)=>{
                            const companies = e.target.value.split(',').map((c)=>c.trim()).filter(Boolean);
                            handleInputChange('blacklistedCompanies', companies);
                        },
                        className: "w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h4", {
                        className: "text-md font-medium text-white mb-2",
                        children: "Email Notifications"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                        type: "checkbox",
                                        checked: settings.notifications.newJobsFound,
                                        onChange: (e)=>handleNotificationChange('newJobsFound', e.target.checked),
                                        className: "mr-2 text-blue-500 bg-gray-800 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "text-gray-200",
                                        children: "New jobs found"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                        type: "checkbox",
                                        checked: settings.notifications.applicationsSubmitted,
                                        onChange: (e)=>handleNotificationChange('applicationsSubmitted', e.target.checked),
                                        className: "mr-2 text-blue-500 bg-gray-800 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "text-gray-200",
                                        children: "Applications submitted"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                        type: "checkbox",
                                        checked: settings.notifications.errorAlerts,
                                        onChange: (e)=>handleNotificationChange('errorAlerts', e.target.checked),
                                        className: "mr-2 text-blue-500 bg-gray-800 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "text-gray-200",
                                        children: "Error alerts"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                onClick: onSave,
                disabled: loading,
                className: "w-full bg-blue-600 hover:bg-blue-700 text-white border-blue-600",
                children: [
                    loading && /*#__PURE__*/ (0,jsx_runtime.jsx)(BanterLoader/* default */.A, {
                        className: "mr-2"
                    }),
                    loading ? 'Saving...' : 'Save Settings'
                ]
            })
        ]
    });
};

// EXTERNAL MODULE: ./components/ui/tabs.tsx
var tabs = __webpack_require__(34964);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/bot.js
var bot = __webpack_require__(25657);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/search.js
var search = __webpack_require__(47924);
;// ./node_modules/lucide-react/dist/esm/icons/pause.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const pause_iconNode = [
    [
        "rect",
        {
            x: "14",
            y: "4",
            width: "4",
            height: "16",
            rx: "1",
            key: "zuxfzm"
        }
    ],
    [
        "rect",
        {
            x: "6",
            y: "4",
            width: "4",
            height: "16",
            rx: "1",
            key: "1okwgv"
        }
    ]
];
const Pause = (0,createLucideIcon/* default */.A)("pause", pause_iconNode);
 //# sourceMappingURL=pause.js.map

;// ./node_modules/lucide-react/dist/esm/icons/play.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const play_iconNode = [
    [
        "polygon",
        {
            points: "6 3 20 12 6 21 6 3",
            key: "1oa8hb"
        }
    ]
];
const Play = (0,createLucideIcon/* default */.A)("play", play_iconNode);
 //# sourceMappingURL=play.js.map

// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/download.js
var download = __webpack_require__(91788);
;// ./components/AutoApplyDashboard.tsx
/* __next_internal_client_entry_do_not_use__ AutoApplyDashboard auto */ 










// Mock job data for demonstration
const mockJobs = [
    {
        id: '1',
        title: 'Senior Frontend Developer',
        company: 'Tech Innovations Inc.',
        location: 'San Francisco, CA',
        salary: {
            min: 120000,
            max: 160000,
            currency: 'USD',
            period: 'yearly'
        },
        jobType: 'full-time',
        workArrangement: 'hybrid',
        description: 'Join our team to build cutting-edge web applications using React and TypeScript.',
        requirements: [
            '5+ years React experience',
            'TypeScript proficiency',
            'Frontend architecture'
        ],
        responsibilities: [
            'Lead frontend development',
            'Mentor junior developers',
            'Code reviews'
        ],
        postedDate: '2024-01-15',
        jobPortal: JOB_PORTALS[0],
        originalUrl: 'https://linkedin.com/jobs/123',
        relevancyScore: 88,
        matchedSkills: [
            'React',
            'TypeScript',
            'JavaScript'
        ],
        missingSkills: [
            'Vue.js'
        ],
        applicationStatus: 'ready_to_apply',
        createdAt: '2024-01-15T08:00:00Z',
        updatedAt: '2024-01-15T08:00:00Z'
    },
    {
        id: '2',
        title: 'Full Stack Engineer',
        company: 'StartupXYZ',
        location: 'Remote',
        salary: {
            min: 100000,
            max: 140000,
            currency: 'USD',
            period: 'yearly'
        },
        jobType: 'full-time',
        workArrangement: 'remote',
        description: 'Build scalable web applications from frontend to backend.',
        requirements: [
            'Node.js',
            'React',
            'Database design'
        ],
        responsibilities: [
            'Full-stack development',
            'API design',
            'Database optimization'
        ],
        postedDate: '2024-01-14',
        jobPortal: JOB_PORTALS[1],
        originalUrl: 'https://indeed.com/jobs/456',
        relevancyScore: 92,
        matchedSkills: [
            'React',
            'Node.js',
            'JavaScript',
            'Python'
        ],
        missingSkills: [
            'MongoDB'
        ],
        applicationStatus: 'applied',
        createdAt: '2024-01-14T10:30:00Z',
        updatedAt: '2024-01-14T10:30:00Z'
    },
    {
        id: '3',
        title: 'Software Development Engineer',
        company: 'Big Tech Corp',
        location: 'Seattle, WA',
        salary: {
            min: 150000,
            max: 200000,
            currency: 'USD',
            period: 'yearly'
        },
        jobType: 'full-time',
        workArrangement: 'onsite',
        description: 'Work on large-scale distributed systems and cloud infrastructure.',
        requirements: [
            'AWS',
            'Microservices',
            'System design'
        ],
        responsibilities: [
            'System architecture',
            'Performance optimization',
            'Code quality'
        ],
        postedDate: '2024-01-13',
        jobPortal: JOB_PORTALS[0],
        originalUrl: 'https://linkedin.com/jobs/789',
        relevancyScore: 75,
        matchedSkills: [
            'JavaScript',
            'Python',
            'AWS'
        ],
        missingSkills: [
            'Kubernetes',
            'Docker'
        ],
        applicationStatus: 'analyzing',
        createdAt: '2024-01-13T14:15:00Z',
        updatedAt: '2024-01-13T14:15:00Z'
    }
];
const AutoApplyDashboard = (param)=>{
    let { userProfile, settings } = param;
    const [jobListings, setJobListings] = (0,react.useState)(mockJobs);
    const [loading, setLoading] = (0,react.useState)(false);
    const [searchLoading, setSearchLoading] = (0,react.useState)(false);
    const [currentSettings, setCurrentSettings] = (0,react.useState)(settings);
    const [activeTab, setActiveTab] = (0,react.useState)('search');
    const [stats, setStats] = (0,react.useState)({
        totalApplications: 127,
        pendingApplications: 23,
        interviewRequests: 8,
        averageRelevancyScore: 82
    });
    const handleSearch = async (filters)=>{
        setSearchLoading(true);
        try {
            // TODO: Implement actual job search API call
            console.log('Searching with filters:', filters);
            // For now, just filter mock jobs based on keywords
            const filteredJobs = mockJobs.filter((job)=>filters.keywords.some((keyword)=>job.title.toLowerCase().includes(keyword.toLowerCase()) || job.description.toLowerCase().includes(keyword.toLowerCase())));
            setJobListings(filteredJobs);
        } catch (error) {
            console.error('Search failed:', error);
        } finally{
            setSearchLoading(false);
        }
    };
    const handleApply = async (jobId)=>{
        setLoading(true);
        try {
            // TODO: Implement actual job application logic
            console.log("Applying for job with ID: ".concat(jobId));
            // Update job status to "applying" then "applied"
            setJobListings((prev)=>prev.map((job)=>job.id === jobId ? {
                        ...job,
                        applicationStatus: 'applying'
                    } : job));
            // For now, immediately mark as applied (remove simulation delay)
            setJobListings((prev)=>prev.map((job)=>job.id === jobId ? {
                        ...job,
                        applicationStatus: 'applied'
                    } : job));
            // Update stats
            setStats((prev)=>({
                    ...prev,
                    totalApplications: prev.totalApplications + 1
                }));
        } catch (error) {
            console.error('Application failed:', error);
        } finally{
            setLoading(false);
        }
    };
    const handleAnalyze = async (jobId)=>{
        setLoading(true);
        try {
            // TODO: Implement actual job analysis with Azure OpenAI
            console.log("Analyzing job with ID: ".concat(jobId));
            // Update job status to "analyzing"
            setJobListings((prev)=>prev.map((job)=>job.id === jobId ? {
                        ...job,
                        applicationStatus: 'analyzing'
                    } : job));
            // Generate random relevancy score for demo (remove delay)
            const relevancyScore = Math.floor(Math.random() * 40) + 60; // 60-100
            setJobListings((prev)=>prev.map((job)=>job.id === jobId ? {
                        ...job,
                        applicationStatus: 'ready_to_apply',
                        relevancyScore
                    } : job));
        } catch (error) {
            console.error('Analysis failed:', error);
        } finally{
            setLoading(false);
        }
    };
    const handleView = (jobId)=>{
        const job = jobListings.find((j)=>j.id === jobId);
        if (job) {
            window.open(job.originalUrl, '_blank');
        }
    };
    const handleProfileExtracted = (profile)=>{
        console.log('Extracted profile:', profile);
    // TODO: Update user profile with extracted data
    };
    const handleSettingsChange = (newSettings)=>{
        setCurrentSettings(newSettings);
    };
    const handleSettingsSave = async ()=>{
        setLoading(true);
        try {
            // TODO: Save settings to API
            console.log('Saving settings:', currentSettings);
        // Remove artificial delay - let the actual API call determine timing
        } catch (error) {
            console.error('Failed to save settings:', error);
        } finally{
            setLoading(false);
        }
    };
    const downloadSummaryReport = async ()=>{
        // TODO: Generate and download summary report
        console.log('Generating summary report...');
        const reportData = {
            userProfile,
            stats,
            jobListings,
            settings: currentSettings,
            generatedAt: new Date().toISOString()
        };
        const dataStr = JSON.stringify(reportData, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
        const exportFileDefaultName = "auto-apply-report-".concat(new Date().toISOString().split('T')[0], ".json");
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
    };
    const toggleAutoApply = ()=>{
        const newSettings = {
            ...currentSettings,
            isEnabled: !currentSettings.isEnabled
        };
        setCurrentSettings(newSettings);
        handleSettingsSave();
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                        className: "bg-gray-900 border-gray-700",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                                className: "flex flex-row items-center justify-between space-y-0 pb-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                        className: "text-sm font-medium text-white",
                                        children: "Total Applications"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ChartColumn, {
                                        className: "h-4 w-4 text-gray-400"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-2xl font-bold text-white",
                                        children: stats.totalApplications
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                        className: "text-xs text-gray-400",
                                        children: "+12 from last week"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                        className: "bg-gray-900 border-gray-700",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                                className: "flex flex-row items-center justify-between space-y-0 pb-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                        className: "text-sm font-medium text-white",
                                        children: "Pending"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(bot/* default */.A, {
                                        className: "h-4 w-4 text-gray-400"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-2xl font-bold text-white",
                                        children: stats.pendingApplications
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                        className: "text-xs text-gray-400",
                                        children: "Awaiting response"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                        className: "bg-gray-900 border-gray-700",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                                className: "flex flex-row items-center justify-between space-y-0 pb-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                        className: "text-sm font-medium text-white",
                                        children: "Interviews"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(search/* default */.A, {
                                        className: "h-4 w-4 text-gray-400"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-2xl font-bold text-white",
                                        children: stats.interviewRequests
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                        className: "text-xs text-gray-400",
                                        children: "6.3% response rate"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                        className: "bg-gray-900 border-gray-700",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                                className: "flex flex-row items-center justify-between space-y-0 pb-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                        className: "text-sm font-medium text-white",
                                        children: "Avg. Match Score"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(ChartColumn, {
                                        className: "h-4 w-4 text-gray-400"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "text-2xl font-bold text-white",
                                        children: [
                                            stats.averageRelevancyScore,
                                            "%"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                        className: "text-xs text-gray-400",
                                        children: "+2% improvement"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                className: "bg-gray-900 border-gray-700",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardHeader */.aR, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardTitle */.ZB, {
                                            className: "flex items-center gap-2 text-white mb-3",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(bot/* default */.A, {
                                                    className: "h-5 w-5 text-blue-400"
                                                }),
                                                "Auto-Apply Status"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardDescription */.BT, {
                                            className: "text-gray-300",
                                            children: "AI agent will automatically search and apply to relevant jobs"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(ui_button/* Button */.$, {
                                    onClick: toggleAutoApply,
                                    variant: currentSettings.isEnabled ? 'default' : 'outline',
                                    className: currentSettings.isEnabled ? 'bg-green-600 hover:bg-green-700 text-white border-green-600' : 'border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white',
                                    children: currentSettings.isEnabled ? /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(Pause, {
                                                className: "h-4 w-4 mr-2"
                                            }),
                                            " Active"
                                        ]
                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(Play, {
                                                className: "h-4 w-4 mr-2"
                                            }),
                                            " Start"
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    currentSettings.isEnabled && /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardContent */.Wu, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "text-sm text-gray-300",
                            children: [
                                "Next scheduled search: in 2 hours • Daily limit: ",
                                currentSettings.dailyApplicationLimit,
                                " applications"
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(tabs/* Tabs */.tU, {
                value: activeTab,
                onValueChange: setActiveTab,
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(tabs/* TabsList */.j7, {
                        className: "grid w-full grid-cols-4 bg-gray-800 border border-gray-600",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "search",
                                className: "text-gray-300 data-[state=active]:text-white data-[state=active]:bg-gray-700",
                                children: "Job Search"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "profile",
                                className: "text-gray-300 data-[state=active]:text-white data-[state=active]:bg-gray-700",
                                children: "Profile"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "settings",
                                className: "text-gray-300 data-[state=active]:text-white data-[state=active]:bg-gray-700",
                                children: "Settings"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "analytics",
                                className: "text-gray-300 data-[state=active]:text-white data-[state=active]:bg-gray-700",
                                children: "Analytics"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(tabs/* TabsContent */.av, {
                        value: "search",
                        className: "space-y-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(JobFilters, {
                                filters: currentSettings.filters,
                                onChange: (newFilters)=>{
                                    const newSettings = {
                                        ...currentSettings,
                                        filters: newFilters
                                    };
                                    setCurrentSettings(newSettings);
                                },
                                onSearch: ()=>handleSearch(currentSettings.filters),
                                loading: searchLoading
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(JobListingTable, {
                                jobs: jobListings,
                                onApply: handleApply,
                                onAnalyze: handleAnalyze,
                                onView: handleView,
                                loading: loading
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(tabs/* TabsContent */.av, {
                        value: "profile",
                        className: "space-y-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(ResumeUpload, {
                                onProfileExtracted: handleProfileExtracted,
                                loading: loading
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                                className: "bg-gray-900 border-gray-700",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                                className: "text-white",
                                                children: "Current Profile Summary"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardDescription */.BT, {
                                                className: "text-gray-300",
                                                children: "Your extracted profile information"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardContent */.Wu, {
                                        className: "space-y-4",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h4", {
                                                            className: "font-semibold mb-2 text-white",
                                                            children: "Contact Info"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                            className: "text-sm text-gray-300",
                                                            children: userProfile.name
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                            className: "text-sm text-gray-300",
                                                            children: userProfile.email
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                            className: "text-sm text-gray-300",
                                                            children: userProfile.location
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h4", {
                                                            className: "font-semibold mb-2 text-white",
                                                            children: "Skills"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                            className: "flex flex-wrap gap-1",
                                                            children: userProfile.skills.slice(0, 8).map((skill, index)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                    className: "px-2 py-1 bg-blue-600 text-white text-xs rounded border border-blue-500",
                                                                    children: skill
                                                                }, index))
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "settings",
                        className: "space-y-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SettingsForm, {
                            settings: currentSettings,
                            onChange: handleSettingsChange,
                            onSave: handleSettingsSave,
                            loading: loading
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "analytics",
                        className: "space-y-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* Card */.Zp, {
                            className: "bg-gray-900 border-gray-700",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                            className: "text-white",
                                            children: "Application Analytics"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardDescription */.BT, {
                                            className: "text-gray-300",
                                            children: "Track your job search performance"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(card/* CardContent */.Wu, {
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h4", {
                                                                className: "font-semibold mb-2 text-white",
                                                                children: "Applications by Status"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                                className: "space-y-2",
                                                                children: Object.entries({
                                                                    applied: 87,
                                                                    pending: 23,
                                                                    interview: 8,
                                                                    rejected: 9
                                                                }).map((param)=>{
                                                                    let [status, count] = param;
                                                                    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                        className: "flex justify-between items-center border-b border-gray-700 pb-1",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                                className: "text-sm capitalize text-gray-300",
                                                                                children: status
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                                className: "font-semibold text-white",
                                                                                children: count
                                                                            })
                                                                        ]
                                                                    }, status);
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h4", {
                                                                className: "font-semibold mb-2 text-white",
                                                                children: "Top Job Portals"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                                className: "space-y-2",
                                                                children: [
                                                                    {
                                                                        name: 'LinkedIn',
                                                                        count: 45
                                                                    },
                                                                    {
                                                                        name: 'Indeed',
                                                                        count: 32
                                                                    },
                                                                    {
                                                                        name: 'Glassdoor',
                                                                        count: 28
                                                                    }
                                                                ].map((portal)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                        className: "flex justify-between items-center border-b border-gray-700 pb-1",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                                className: "text-sm text-gray-300",
                                                                                children: portal.name
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                                className: "font-semibold text-white",
                                                                                children: portal.count
                                                                            })
                                                                        ]
                                                                    }, portal.name))
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                onClick: downloadSummaryReport,
                                                className: "w-full bg-blue-600 hover:bg-blue-700 text-white border-blue-600",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(download/* default */.A, {
                                                        className: "h-4 w-4 mr-2"
                                                    }),
                                                    "Download Detailed Report"
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 88145:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ Badge)
/* harmony export */ });
/* unused harmony export badgeVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74466);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);




const badgeVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
            secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
            destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
            outline: "text-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge(param) {
    let { className, variant, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(badgeVariants({
            variant
        }), className),
        ...props
    });
}



/***/ }),

/***/ 88482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BT: () => (/* binding */ CardDescription),
/* harmony export */   Wu: () => (/* binding */ CardContent),
/* harmony export */   ZB: () => (/* binding */ CardTitle),
/* harmony export */   Zp: () => (/* binding */ Card),
/* harmony export */   aR: () => (/* binding */ CardHeader)
/* harmony export */ });
/* unused harmony export CardFooter */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);



const Card = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    });
});
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    });
});
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    });
});
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-sm text-muted-foreground", className),
        ...props
    });
});
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("p-6 pt-0", className),
        ...props
    });
});
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center p-6 pt-0", className),
        ...props
    });
});
CardFooter.displayName = "CardFooter";



/***/ }),

/***/ 91788:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Download)
/* harmony export */ });
/* unused harmony export __iconNode */
/* harmony import */ var _createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19946);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
            key: "ih7n3h"
        }
    ],
    [
        "polyline",
        {
            points: "7 10 12 15 17 10",
            key: "2ggqvy"
        }
    ],
    [
        "line",
        {
            x1: "12",
            x2: "12",
            y1: "15",
            y2: "3",
            key: "1vk2je"
        }
    ]
];
const Download = (0,_createLucideIcon_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)("download", __iconNode);
 //# sourceMappingURL=download.js.map


/***/ }),

/***/ 97168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Button)
/* harmony export */ });
/* unused harmony export buttonVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99708);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74466);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);





const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none", {
    variants: {
        variant: {
            default: "bg-primary-200 text-dark-100 shadow-xs hover:bg-primary-200/90 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            destructive: "bg-destructive-100 text-white shadow-xs hover:bg-destructive-200 focus-visible:ring-destructive-100/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            outline: "border border-gray-600 bg-gray-800 text-white shadow-xs hover:bg-gray-700 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800/50 disabled:text-gray-500 disabled:border-gray-700",
            secondary: "bg-gray-700 text-white shadow-xs hover:bg-gray-600 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800 disabled:text-gray-500",
            ghost: "text-white hover:bg-gray-800 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500",
            link: "text-primary-200 underline-offset-4 hover:underline focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button(param) {
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__/* .Slot */ .DX : "button";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Comp, {
        "data-slot": "button",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    });
}



/***/ })

}]);