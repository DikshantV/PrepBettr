"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[6680],{

/***/ 36680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  cn: () => (/* binding */ cn),
  L8: () => (/* binding */ getCompanyLogoForInterview),
  o8: () => (/* binding */ getRandomInterviewCover),
  iE: () => (/* binding */ normalizeTechstack)
});

// UNUSED EXPORTS: getTechIcons

// EXTERNAL MODULE: ./node_modules/zod/lib/index.mjs
var lib = __webpack_require__(55594);
;// ./constants/index.ts

const mappings = {
    "react.js": "react",
    reactjs: "react",
    react: "react",
    "next.js": "nextjs",
    nextjs: "nextjs",
    next: "nextjs",
    "vue.js": "vuejs",
    vuejs: "vuejs",
    vue: "vuejs",
    "express.js": "express",
    expressjs: "express",
    express: "express",
    "node.js": "nodejs",
    nodejs: "nodejs",
    node: "nodejs",
    mongodb: "mongodb",
    mongo: "mongodb",
    mongoose: "mongoose",
    mysql: "mysql",
    postgresql: "postgresql",
    sqlite: "sqlite",
    firebase: "firebase",
    docker: "docker",
    kubernetes: "kubernetes",
    aws: "aws",
    azure: "azure",
    gcp: "gcp",
    digitalocean: "digitalocean",
    heroku: "heroku",
    photoshop: "photoshop",
    "adobe photoshop": "photoshop",
    html5: "html5",
    html: "html5",
    css3: "css3",
    css: "css3",
    sass: "sass",
    scss: "sass",
    less: "less",
    tailwindcss: "tailwindcss",
    tailwind: "tailwindcss",
    bootstrap: "bootstrap",
    jquery: "jquery",
    typescript: "typescript",
    ts: "typescript",
    javascript: "javascript",
    js: "javascript",
    "angular.js": "angular",
    angularjs: "angular",
    angular: "angular",
    "ember.js": "ember",
    emberjs: "ember",
    ember: "ember",
    "backbone.js": "backbone",
    backbonejs: "backbone",
    backbone: "backbone",
    nestjs: "nestjs",
    graphql: "graphql",
    "graph ql": "graphql",
    apollo: "apollo",
    webpack: "webpack",
    babel: "babel",
    "rollup.js": "rollup",
    rollupjs: "rollup",
    rollup: "rollup",
    "parcel.js": "parcel",
    parceljs: "parcel",
    npm: "npm",
    yarn: "yarn",
    git: "git",
    github: "github",
    gitlab: "gitlab",
    bitbucket: "bitbucket",
    figma: "figma",
    prisma: "prisma",
    redux: "redux",
    flux: "flux",
    redis: "redis",
    selenium: "selenium",
    cypress: "cypress",
    jest: "jest",
    mocha: "mocha",
    chai: "chai",
    karma: "karma",
    vuex: "vuex",
    "nuxt.js": "nuxt",
    nuxtjs: "nuxt",
    nuxt: "nuxt",
    strapi: "strapi",
    wordpress: "wordpress",
    contentful: "contentful",
    netlify: "netlify",
    "aws amplify": "amplify"
};
// Azure-based interviewer configuration
const azureInterviewer = {
    name: "PrepBettr AI Interviewer",
    first_message: "Hello {{candidateName}}! Thank you for taking the time to speak with me today. I'm excited to learn more about you and your experience.",
    system_prompt: "You are a professional job interviewer conducting a real-time voice interview with a candidate. Your goal is to assess their qualifications, motivation, and fit for the role.\n\nInterview Guidelines:\nFollow the structured question flow:\n{{questions}}\n\nEngage naturally & react appropriately:\nListen actively to responses and acknowledge them before moving forward.\nAsk brief follow-up questions if a response is vague or requires more detail.\nKeep the conversation flowing smoothly while maintaining control.\nBe professional, yet warm and welcoming:\n\nUse official yet friendly language.\nKeep responses concise and to the point (like in a real voice interview).\nAvoid robotic phrasing—sound natural and conversational.\nAnswer the candidate's questions professionally:\n\nIf asked about the role, company, or expectations, provide a clear and relevant answer.\nIf unsure, redirect the candidate to HR for more details.\n\nConclude the interview properly:\nThank the candidate for their time.\nInform them that the company will reach out soon with feedback.\nEnd the conversation on a polite and positive note.\n\n- Be sure to be professional and polite.\n- Keep all your responses short and simple. Use official language, but be kind and welcoming.\n- This is a voice conversation, so keep your responses short, like in a real conversation. Don't ramble for too long.",
    speech: {
        region: "eastus",
        voice_name: "en-US-JennyNeural",
        speaking_rate: 0.9,
        pitch: "+0Hz"
    },
    openai: {
        model: "gpt-4",
        temperature: 0.7,
        max_tokens: 200
    }
};
const feedbackSchema = lib.z.object({
    totalScore: lib.z.number(),
    categoryScores: lib.z.tuple([
        lib.z.object({
            name: lib.z.literal("Communication Skills"),
            score: lib.z.number(),
            comment: lib.z.string()
        }),
        lib.z.object({
            name: lib.z.literal("Technical Knowledge"),
            score: lib.z.number(),
            comment: lib.z.string()
        }),
        lib.z.object({
            name: lib.z.literal("Problem Solving"),
            score: lib.z.number(),
            comment: lib.z.string()
        }),
        lib.z.object({
            name: lib.z.literal("Cultural Fit"),
            score: lib.z.number(),
            comment: lib.z.string()
        }),
        lib.z.object({
            name: lib.z.literal("Confidence and Clarity"),
            score: lib.z.number(),
            comment: lib.z.string()
        })
    ]),
    strengths: lib.z.array(lib.z.string()),
    areasForImprovement: lib.z.array(lib.z.string()),
    finalAssessment: lib.z.string()
});
// Company logos for interviews
const companyLogos = [
    {
        name: "Apple",
        logo: "/apple.svg"
    },
    {
        name: "Microsoft",
        logo: "/microsoft.svg"
    },
    {
        name: "Google",
        logo: "/google.svg"
    },
    {
        name: "OpenAI",
        logo: "/openai.svg"
    },
    {
        name: "Instagram",
        logo: "/instagram.svg"
    },
    {
        name: "IBM",
        logo: "/ibm.svg"
    },
    {
        name: "LinkedIn",
        logo: "/linkedin.png"
    },
    {
        name: "Tesla",
        logo: "/tesla.png"
    },
    {
        name: "Netflix",
        logo: "/netflix.svg"
    },
    {
        name: "Amazon",
        logo: "/amazon.png"
    },
    {
        name: "Meta",
        logo: "/meta.png"
    },
    {
        name: "Adobe",
        logo: "/adobe.png"
    },
    {
        name: "Spotify",
        logo: "/spotify.png"
    },
    {
        name: "Airbnb",
        logo: "/airbnb.svg"
    },
    {
        name: "Uber",
        logo: "/uber.svg"
    },
    {
        name: "Reddit",
        logo: "/reddit.png"
    },
    {
        name: "Pinterest",
        logo: "/pinterest.png"
    },
    {
        name: "Quora",
        logo: "/quora.png"
    },
    {
        name: "Skype",
        logo: "/skype.png"
    },
    {
        name: "TikTok",
        logo: "/tiktok.png"
    },
    {
        name: "Yahoo",
        logo: "/yahoo.png"
    },
    {
        name: "Telegram",
        logo: "/telegram.png"
    },
    {
        name: "Facebook",
        logo: "/facebook.png"
    },
    {
        name: "Hostinger",
        logo: "/hostinger.png"
    }
];
// Legacy array for backward compatibility
const interviewCovers = companyLogos.map((c)=>c.logo);
const dummyInterviews = [
    {
        id: "1",
        userId: "user1",
        jobTitle: "Frontend Developer",
        company: "TechCorp",
        jobDescription: "Frontend developer position working with React and TypeScript",
        questions: [
            {
                question: "What is React?",
                category: "technical",
                difficulty: "medium"
            },
            {
                question: "Explain TypeScript benefits",
                category: "technical",
                difficulty: "medium"
            }
        ],
        finalized: false,
        feedbackGenerated: false,
        createdAt: "2024-03-15T10:00:00Z",
        updatedAt: "2024-03-15T10:00:00Z",
        // Legacy properties for backward compatibility
        role: "Frontend Developer",
        type: "Technical",
        techstack: [
            "React",
            "TypeScript",
            "Next.js",
            "Tailwind CSS"
        ],
        level: "Junior"
    },
    {
        id: "2",
        userId: "user1",
        jobTitle: "Full Stack Developer",
        company: "StartupXYZ",
        jobDescription: "Full stack developer position using Node.js and React",
        questions: [
            {
                question: "What is Node.js?",
                category: "technical",
                difficulty: "medium"
            },
            {
                question: "Explain RESTful APIs",
                category: "technical",
                difficulty: "medium"
            }
        ],
        finalized: false,
        feedbackGenerated: false,
        createdAt: "2024-03-14T15:30:00Z",
        updatedAt: "2024-03-14T15:30:00Z",
        // Legacy properties for backward compatibility
        role: "Full Stack Developer",
        type: "Mixed",
        techstack: [
            "Node.js",
            "Express",
            "MongoDB",
            "React"
        ],
        level: "Senior"
    }
];

// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(52596);
// EXTERNAL MODULE: ./node_modules/tailwind-merge/dist/bundle-mjs.mjs
var bundle_mjs = __webpack_require__(39688);
;// ./lib/utils.ts



function cn() {
    for(var _len = arguments.length, inputs = new Array(_len), _key = 0; _key < _len; _key++){
        inputs[_key] = arguments[_key];
    }
    return (0,bundle_mjs/* twMerge */.QP)((0,clsx/* clsx */.$)(inputs));
}
/**
 * Normalizes techstack data to always return a string array
 * Handles cases where techstack might be null, undefined, string, or already an array
 */ function normalizeTechstack(techstack) {
    if (!techstack) return [];
    if (typeof techstack === 'string') {
        return techstack.split(',').map((tech)=>tech.trim()).filter(Boolean);
    }
    if (Array.isArray(techstack)) {
        return techstack.filter((tech)=>typeof tech === 'string' && tech.trim());
    }
    return [];
}
// Tech icon configuration using React Icons (primary) and DevIcons (fallback)
const techIconsMap = {
    // Frontend
    'react': {
        type: 'react-icon',
        icon: 'FaReact'
    },
    'nextjs': {
        type: 'react-icon',
        icon: 'SiNextdotjs'
    },
    'next': {
        type: 'react-icon',
        icon: 'SiNextdotjs'
    },
    'next.js': {
        type: 'react-icon',
        icon: 'SiNextdotjs'
    },
    'vue': {
        type: 'react-icon',
        icon: 'FaVuejs'
    },
    'angular': {
        type: 'react-icon',
        icon: 'FaAngular'
    },
    'svelte': {
        type: 'react-icon',
        icon: 'SiSvelte'
    },
    'typescript': {
        type: 'react-icon',
        icon: 'SiTypescript'
    },
    'javascript': {
        type: 'react-icon',
        icon: 'SiJavascript'
    },
    'html': {
        type: 'react-icon',
        icon: 'FaHtml5'
    },
    'css': {
        type: 'react-icon',
        icon: 'FaCss3Alt'
    },
    'sass': {
        type: 'react-icon',
        icon: 'FaSass'
    },
    'tailwind': {
        type: 'react-icon',
        icon: 'SiTailwindcss'
    },
    'tailwindcss': {
        type: 'react-icon',
        icon: 'SiTailwindcss'
    },
    'bootstrap': {
        type: 'react-icon',
        icon: 'FaBootstrap'
    },
    'materialui': {
        type: 'react-icon',
        icon: 'SiMui'
    },
    'mui': {
        type: 'react-icon',
        icon: 'SiMui'
    },
    // Backend
    'nodejs': {
        type: 'react-icon',
        icon: 'FaNodeJs'
    },
    'node': {
        type: 'react-icon',
        icon: 'FaNodeJs'
    },
    'node.js': {
        type: 'react-icon',
        icon: 'FaNodeJs'
    },
    'express': {
        type: 'react-icon',
        icon: 'SiExpress'
    },
    'python': {
        type: 'react-icon',
        icon: 'FaPython'
    },
    'django': {
        type: 'react-icon',
        icon: 'SiDjango'
    },
    'flask': {
        type: 'react-icon',
        icon: 'SiFlask'
    },
    'java': {
        type: 'react-icon',
        icon: 'FaJava'
    },
    'spring': {
        type: 'react-icon',
        icon: 'SiSpring'
    },
    'php': {
        type: 'react-icon',
        icon: 'FaPhp'
    },
    'ruby': {
        type: 'react-icon',
        icon: 'SiRuby'
    },
    'rails': {
        type: 'react-icon',
        icon: 'SiRubyonrails'
    },
    'go': {
        type: 'react-icon',
        icon: 'SiGo'
    },
    'golang': {
        type: 'react-icon',
        icon: 'SiGo'
    },
    'rust': {
        type: 'react-icon',
        icon: 'SiRust'
    },
    'csharp': {
        type: 'devicon',
        icon: '',
        fallbackUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg'
    },
    'c#': {
        type: 'devicon',
        icon: '',
        fallbackUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg'
    },
    'dotnet': {
        type: 'react-icon',
        icon: 'SiDotnet'
    },
    '.net': {
        type: 'react-icon',
        icon: 'SiDotnet'
    },
    // Databases
    'mongodb': {
        type: 'react-icon',
        icon: 'SiMongodb'
    },
    'mysql': {
        type: 'react-icon',
        icon: 'SiMysql'
    },
    'postgresql': {
        type: 'react-icon',
        icon: 'SiPostgresql'
    },
    'postgres': {
        type: 'react-icon',
        icon: 'SiPostgresql'
    },
    'redis': {
        type: 'react-icon',
        icon: 'SiRedis'
    },
    'sqlite': {
        type: 'react-icon',
        icon: 'SiSqlite'
    },
    'oracle': {
        type: 'react-icon',
        icon: 'SiOracle'
    },
    'elasticsearch': {
        type: 'react-icon',
        icon: 'SiElasticsearch'
    },
    // Mobile
    'reactnative': {
        type: 'react-icon',
        icon: 'FaReact'
    },
    'flutter': {
        type: 'react-icon',
        icon: 'SiFlutter'
    },
    'swift': {
        type: 'react-icon',
        icon: 'SiSwift'
    },
    'kotlin': {
        type: 'react-icon',
        icon: 'SiKotlin'
    },
    'android': {
        type: 'react-icon',
        icon: 'FaAndroid'
    },
    'ios': {
        type: 'react-icon',
        icon: 'FaApple'
    },
    // Cloud & DevOps
    'docker': {
        type: 'react-icon',
        icon: 'FaDocker'
    },
    'kubernetes': {
        type: 'react-icon',
        icon: 'SiKubernetes'
    },
    'aws': {
        type: 'react-icon',
        icon: 'FaAws'
    },
    'azure': {
        type: 'devicon',
        icon: '',
        fallbackUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/azure/azure-original.svg'
    },
    'gcp': {
        type: 'react-icon',
        icon: 'SiGooglecloud'
    },
    'googlecloud': {
        type: 'react-icon',
        icon: 'SiGooglecloud'
    },
    'firebase': {
        type: 'react-icon',
        icon: 'SiFirebase'
    },
    'netlify': {
        type: 'react-icon',
        icon: 'SiNetlify'
    },
    // Version Control
    'git': {
        type: 'react-icon',
        icon: 'FaGitAlt'
    },
    'github': {
        type: 'react-icon',
        icon: 'FaGithub'
    },
    'gitlab': {
        type: 'react-icon',
        icon: 'FaGitlab'
    },
    'bitbucket': {
        type: 'react-icon',
        icon: 'FaBitbucket'
    },
    // Build Tools & Bundlers
    'webpack': {
        type: 'react-icon',
        icon: 'SiWebpack'
    },
    'vite': {
        type: 'react-icon',
        icon: 'SiVite'
    },
    'rollup': {
        type: 'react-icon',
        icon: 'SiRollupdotjs'
    },
    'babel': {
        type: 'react-icon',
        icon: 'SiBabel'
    },
    'eslint': {
        type: 'react-icon',
        icon: 'SiEslint'
    },
    'prettier': {
        type: 'react-icon',
        icon: 'SiPrettier'
    },
    // Testing
    'jest': {
        type: 'react-icon',
        icon: 'SiJest'
    },
    'cypress': {
        type: 'react-icon',
        icon: 'SiCypress'
    },
    'mocha': {
        type: 'devicon',
        icon: '',
        fallbackUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mocha/mocha-plain.svg'
    },
    // State Management
    'redux': {
        type: 'react-icon',
        icon: 'SiRedux'
    },
    'mobx': {
        type: 'react-icon',
        icon: 'SiMobx'
    },
    // API Technologies
    'graphql': {
        type: 'react-icon',
        icon: 'SiGraphql'
    },
    'apollo': {
        type: 'react-icon',
        icon: 'SiApollographql'
    },
    'restapi': {
        type: 'react-icon',
        icon: 'SiPostman'
    },
    'rest': {
        type: 'react-icon',
        icon: 'SiPostman'
    },
    // CI/CD
    'jenkins': {
        type: 'react-icon',
        icon: 'SiJenkins'
    },
    'githubactions': {
        type: 'react-icon',
        icon: 'SiGithubactions'
    },
    'circleci': {
        type: 'react-icon',
        icon: 'SiCircleci'
    },
    'travis': {
        type: 'react-icon',
        icon: 'SiTravisci'
    },
    // Additional Popular Technologies
    'laravel': {
        type: 'react-icon',
        icon: 'SiLaravel'
    },
    'symfony': {
        type: 'react-icon',
        icon: 'SiSymfony'
    },
    'codeigniter': {
        type: 'react-icon',
        icon: 'SiCodeigniter'
    },
    'wordpress': {
        type: 'react-icon',
        icon: 'FaWordpress'
    },
    'drupal': {
        type: 'react-icon',
        icon: 'FaDrupal'
    },
    'joomla': {
        type: 'react-icon',
        icon: 'FaJoomla'
    },
    'shopify': {
        type: 'react-icon',
        icon: 'SiShopify'
    },
    'strapi': {
        type: 'react-icon',
        icon: 'SiStrapi'
    },
    'contentful': {
        type: 'react-icon',
        icon: 'SiContentful'
    },
    'sanity': {
        type: 'react-icon',
        icon: 'SiSanity'
    },
    // Additional Frameworks & Libraries (20+ new entries)
    'nuxt': {
        type: 'react-icon',
        icon: 'SiNuxtdotjs'
    },
    'nuxtjs': {
        type: 'react-icon',
        icon: 'SiNuxtdotjs'
    },
    'gatsby': {
        type: 'react-icon',
        icon: 'SiGatsby'
    },
    'ember': {
        type: 'react-icon',
        icon: 'SiEmber'
    },
    'backbone': {
        type: 'react-icon',
        icon: 'SiBackbonedotjs'
    },
    'polymer': {
        type: 'react-icon',
        icon: 'SiPolymer'
    },
    'astro': {
        type: 'react-icon',
        icon: 'SiAstro'
    },
    // Backend Frameworks
    'fastapi': {
        type: 'react-icon',
        icon: 'SiFastapi'
    },
    'nestjs': {
        type: 'react-icon',
        icon: 'SiNestjs'
    },
    'koa': {
        type: 'react-icon',
        icon: 'SiKoa'
    },
    'hapi': {
        type: 'react-icon',
        icon: 'SiHapi'
    },
    'deno': {
        type: 'react-icon',
        icon: 'SiDeno'
    },
    // Cloud & Database
    'supabase': {
        type: 'react-icon',
        icon: 'SiSupabase'
    },
    'prisma': {
        type: 'react-icon',
        icon: 'SiPrisma'
    },
    'sequelize': {
        type: 'react-icon',
        icon: 'SiSequelize'
    },
    'mariadb': {
        type: 'react-icon',
        icon: 'SiMariadb'
    },
    'cassandra': {
        type: 'react-icon',
        icon: 'SiCassandra'
    },
    'couchdb': {
        type: 'react-icon',
        icon: 'SiCouchdb'
    },
    'neo4j': {
        type: 'react-icon',
        icon: 'SiNeo4j'
    },
    'influxdb': {
        type: 'react-icon',
        icon: 'SiInfluxdb'
    },
    // DevOps & Monitoring
    'grafana': {
        type: 'react-icon',
        icon: 'SiGrafana'
    },
    'prometheus': {
        type: 'react-icon',
        icon: 'SiPrometheus'
    },
    'terraform': {
        type: 'react-icon',
        icon: 'SiTerraform'
    },
    'ansible': {
        type: 'react-icon',
        icon: 'SiAnsible'
    },
    'puppet': {
        type: 'react-icon',
        icon: 'SiPuppet'
    },
    'helm': {
        type: 'react-icon',
        icon: 'SiHelm'
    },
    'argo': {
        type: 'react-icon',
        icon: 'SiArgo'
    },
    'rancher': {
        type: 'react-icon',
        icon: 'SiRancher'
    },
    'datadog': {
        type: 'react-icon',
        icon: 'SiDatadog'
    },
    'newrelic': {
        type: 'react-icon',
        icon: 'SiNewrelic'
    },
    'sentry': {
        type: 'react-icon',
        icon: 'SiSentry'
    },
    // Data Processing & Analytics
    'elastic': {
        type: 'react-icon',
        icon: 'SiElastic'
    },
    'logstash': {
        type: 'react-icon',
        icon: 'SiLogstash'
    },
    'kibana': {
        type: 'react-icon',
        icon: 'SiKibana'
    },
    'kafka': {
        type: 'react-icon',
        icon: 'SiApachekafka'
    },
    'rabbitmq': {
        type: 'react-icon',
        icon: 'SiRabbitmq'
    },
    'spark': {
        type: 'react-icon',
        icon: 'SiApachespark'
    },
    'hadoop': {
        type: 'react-icon',
        icon: 'SiHadoop'
    },
    'databricks': {
        type: 'react-icon',
        icon: 'SiDatabricks'
    },
    'snowflake': {
        type: 'react-icon',
        icon: 'SiSnowflake'
    },
    'tableau': {
        type: 'react-icon',
        icon: 'SiTableau'
    },
    'powerbi': {
        type: 'react-icon',
        icon: 'SiPowerbi'
    },
    'qlik': {
        type: 'react-icon',
        icon: 'SiQlik'
    },
    // Data Visualization
    'd3': {
        type: 'react-icon',
        icon: 'SiD3Dotjs'
    },
    'd3js': {
        type: 'react-icon',
        icon: 'SiD3Dotjs'
    },
    'chartjs': {
        type: 'react-icon',
        icon: 'SiChartdotjs'
    },
    'plotly': {
        type: 'react-icon',
        icon: 'SiPlotly'
    },
    'leaflet': {
        type: 'react-icon',
        icon: 'SiLeaflet'
    },
    'mapbox': {
        type: 'react-icon',
        icon: 'SiMapbox'
    },
    'threejs': {
        type: 'react-icon',
        icon: 'SiThreejs'
    },
    // Testing Frameworks
    'playwright': {
        type: 'react-icon',
        icon: 'SiPlaywright'
    },
    'selenium': {
        type: 'react-icon',
        icon: 'SiSelenium'
    },
    'testinglibrary': {
        type: 'react-icon',
        icon: 'SiTestinglibrary'
    },
    'vitest': {
        type: 'react-icon',
        icon: 'SiVitest'
    },
    'storybook': {
        type: 'react-icon',
        icon: 'SiStorybook'
    },
    'chromatic': {
        type: 'react-icon',
        icon: 'SiChromatic'
    },
    // Validation & Design
    'zod': {
        type: 'react-icon',
        icon: 'SiZod'
    },
    'yup': {
        type: 'react-icon',
        icon: 'SiYup'
    },
    'figma': {
        type: 'react-icon',
        icon: 'SiFigma'
    },
    'sketch': {
        type: 'react-icon',
        icon: 'SiSketch'
    },
    'adobexd': {
        type: 'react-icon',
        icon: 'SiAdobexd'
    },
    'framer': {
        type: 'react-icon',
        icon: 'SiFramer'
    },
    // Web3 & Blockchain
    'solidity': {
        type: 'react-icon',
        icon: 'SiSolidity'
    },
    'ethereum': {
        type: 'react-icon',
        icon: 'SiEthereum'
    },
    'web3': {
        type: 'react-icon',
        icon: 'SiWeb3Dotjs'
    },
    'web3js': {
        type: 'react-icon',
        icon: 'SiWeb3Dotjs'
    },
    'ipfs': {
        type: 'react-icon',
        icon: 'SiIpfs'
    },
    'chainlink': {
        type: 'react-icon',
        icon: 'SiChainlink'
    },
    'alchemy': {
        type: 'react-icon',
        icon: 'SiAlchemy'
    },
    // Payment Processing
    'stripe': {
        type: 'react-icon',
        icon: 'SiStripe'
    }
};
// DevIcon fallback URLs for technologies not available in React Icons
const devIconFallbacks = {
    'rails': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/rails/rails-original-wordmark.svg',
    'mocha': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mocha/mocha-plain.svg',
    'materialui': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/materialui/materialui-original.svg',
    'oracle': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/oracle/oracle-original.svg'
};
const normalizeTechName = (tech)=>{
    if (!tech) return '';
    // First normalize common tech names
    const normalized = tech.toLowerCase().replace(/\.js$/, '').replace(/\s+/g, '').replace(/[^a-z0-9]/g, '');
    // Special handling for common tech names
    if ([
        'node',
        'nodejs'
    ].includes(normalized)) return 'nodejs';
    if ([
        'next',
        'nextjs'
    ].includes(normalized)) return 'nextjs';
    return normalized;
};
/**
 * Get available tech icons configuration for a given array of technologies
 * Only returns technologies that have corresponding icons available
 * @param techArray - Array of technology names
 * @param maxIcons - Maximum number of icons to return (default: 6)
 * @returns Array of tech icon configurations
 */ const getTechIcons = function() {
    let techArray = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], maxIcons = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 6;
    if (!techArray || techArray.length === 0) return [];
    // Filter and map technologies to their icon configurations
    const availableIcons = techArray.map((tech)=>{
        const normalized = normalizeTechName(tech);
        const iconConfig = techIconsMap[normalized];
        // Only include technologies that have icon configurations
        if (iconConfig) {
            return {
                tech: tech.trim(),
                normalized,
                ...iconConfig
            };
        }
        return null;
    }).filter((icon)=>icon !== null) // Remove null values with proper typing
    .slice(0, maxIcons); // Limit number of icons
    return availableIcons;
};
/**
 * Get company logo deterministically based on interview ID
 * Returns both logo path and company name
 */ const getCompanyLogoForInterview = (id)=>{
    // Use deterministic selection based on ID to ensure consistency
    if (id) {
        const hash = id.split('').reduce((acc, char)=>acc + char.charCodeAt(0), 0);
        const index = hash % companyLogos.length;
        const company = companyLogos[index];
        const path = "/covers".concat(company.logo);
        console.log('Generated company logo:', path, 'Company:', company.name, 'for ID:', id);
        return {
            logo: path,
            company: company.name
        };
    }
    // Fallback to first company if no ID provided
    const fallback = companyLogos[0];
    const path = "/covers".concat(fallback.logo);
    console.log('Fallback company logo:', path, 'Company:', fallback.name);
    return {
        logo: path,
        company: fallback.name
    };
};
// Legacy function for backward compatibility
const getRandomInterviewCover = (id)=>{
    return getCompanyLogoForInterview(id).logo;
};


/***/ })

}]);