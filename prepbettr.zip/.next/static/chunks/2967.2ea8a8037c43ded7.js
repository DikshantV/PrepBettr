"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[2967],{

/***/ 42967:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(85339);
/* harmony import */ var _barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57434);
/* harmony import */ var _barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(29869);
/* harmony import */ var _barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71539);
/* harmony import */ var _barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5196);
/* harmony import */ var _barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(24357);
/* harmony import */ var _barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(91788);
/* harmony import */ var _components_ui_BanterLoader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65061);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(26597);
/* __next_internal_client_entry_do_not_use__ default auto */ 




// Function to parse PDF files on the client side
async function parsePdfFile(file) {
    try {
        const formData = new FormData();
        formData.append('file', file);
        const response = await fetch('/api/parse-pdf', {
            method: 'POST',
            body: formData
        });
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to parse PDF');
        }
        const data = await response.json();
        return data.text || '';
    } catch (error) {
        console.error('Error parsing PDF:', error);
        throw new Error('Failed to parse PDF file. Please try converting to text format.');
    }
}
// Function to generate cover letter using server-side API
async function generateCoverLetter(resumeText, jobDescription) {
    try {
        const response = await fetch('/api/cover-letter', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                resumeText,
                jobDescription
            })
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || 'Failed to generate cover letter');
        }
        return data.coverLetter;
    } catch (error) {
        console.error('Cover letter generation API Error:', error);
        if (error instanceof Error) {
            throw error;
        }
        throw new Error('Failed to generate cover letter. Please try again.');
    }
}
const CoverLetterGeneratorSection = ()=>{
    const [resumeText, setResumeText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [jobDescription, setJobDescription] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [generatedCoverLetter, setGeneratedCoverLetter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [isProcessing, setIsProcessing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [copied, setCopied] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleFileUpload = async (event, type)=>{
        const files = event.target.files;
        if (!files || files.length === 0) return;
        setError(null);
        setIsProcessing(true);
        try {
            const file = files[0];
            let text = '';
            if (file.size > 10 * 1024 * 1024) {
                throw new Error('File size exceeds 10MB limit. Please use a smaller file.');
            }
            if (file.type === 'text/plain') {
                text = await file.text();
            } else if (file.type === 'application/pdf') {
                text = await parsePdfFile(file);
            } else {
                throw new Error('Unsupported file type. Please use PDF or TXT files.');
            }
            if (type === 'resume') {
                setResumeText(text);
            } else {
                setJobDescription(text);
            }
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Failed to process the file.';
            setError(errorMessage);
            console.error('Error parsing file:', error);
        } finally{
            setIsProcessing(false);
        }
    };
    const handleGenerateCoverLetter = async ()=>{
        if (!resumeText.trim()) {
            setError('Please provide your resume content.');
            return;
        }
        if (!jobDescription.trim()) {
            setError('Please provide the job description.');
            return;
        }
        setError(null);
        setIsProcessing(true);
        setGeneratedCoverLetter('');
        try {
            const coverLetter = await generateCoverLetter(resumeText, jobDescription);
            setGeneratedCoverLetter(coverLetter);
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'An error occurred while generating the cover letter.';
            setError(errorMessage);
        } finally{
            setIsProcessing(false);
        }
    };
    const copyToClipboard = async ()=>{
        try {
            await navigator.clipboard.writeText(generatedCoverLetter);
            setCopied(true);
            setTimeout(()=>setCopied(false), 2000);
        } catch (err) {
            console.error('Failed to copy text:', err);
            setError('Failed to copy to clipboard.');
        }
    };
    const downloadAsPdf = ()=>{
        try {
            const doc = new jspdf__WEBPACK_IMPORTED_MODULE_3__/* .jsPDF */ .uE();
            const pageWidth = doc.internal.pageSize.getWidth();
            const pageHeight = doc.internal.pageSize.getHeight();
            const margin = 20;
            const maxLineWidth = pageWidth - 2 * margin;
            // Split text into lines that fit within the page width
            const lines = doc.splitTextToSize(generatedCoverLetter, maxLineWidth);
            let y = margin;
            const lineHeight = 7;
            for(let i = 0; i < lines.length; i++){
                if (y + lineHeight > pageHeight - margin) {
                    doc.addPage();
                    y = margin;
                }
                doc.text(lines[i], margin, y);
                y += lineHeight;
            }
            doc.save("cover-letter.pdf");
        } catch (err) {
            console.error('Failed to download PDF:', err);
            setError('Failed to download PDF.');
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-full p-6 mb-8",
        children: [
            isProcessing && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_ui_BanterLoader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A, {
                overlay: true,
                text: "Generating Cover Letter..."
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "mb-6",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                    className: "text-gray-300",
                    children: "Upload your resume and a job description to generate a compelling, AI-powered cover letter tailored to the role."
                })
            }),
            error && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-6 p-4 bg-red-900/30 border border-red-500/60 rounded-lg flex items-start",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A, {
                        className: "w-5 h-5 text-red-400 mr-2 mt-0.5 flex-shrink-0"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                        className: "text-red-300 text-sm",
                        children: error
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "grid grid-cols-1 lg:grid-cols-2 gap-6 h-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "space-y-6",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-gray-900 border border-gray-700 rounded-lg p-6 shadow-md",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center mb-4",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A, {
                                                className: "w-5 h-5 text-blue-400 mr-2"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
                                                className: "text-xl font-semibold text-white",
                                                children: "Your Resume"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "mb-4",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", {
                                                className: "block text-sm font-medium text-gray-200 mb-2",
                                                children: "Upload Resume File (PDF or TXT format)"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "flex items-center justify-center w-full",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                    className: "flex flex-col items-center justify-center w-full h-32 border-2 border-gray-600 border-dashed rounded-lg cursor-pointer bg-gray-800 hover:border-blue-500 hover:bg-gray-750 transition-colors",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex flex-col items-center justify-center pt-5 pb-6",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, {
                                                                    className: "w-8 h-8 mb-4 text-gray-400"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                    className: "mb-2 text-sm text-gray-300",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                                            className: "font-semibold",
                                                                            children: "Click to upload"
                                                                        }),
                                                                        " or drag and drop"
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                                                                    className: "text-xs text-gray-400",
                                                                    children: "PDF or TXT files"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                            type: "file",
                                                            className: "hidden",
                                                            accept: ".pdf,.txt",
                                                            onChange: (e)=>handleFileUpload(e, 'resume')
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-gray-900 border border-gray-700 rounded-lg p-6 shadow-md",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center mb-4",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A, {
                                                className: "w-5 h-5 text-green-400 mr-2"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
                                                className: "text-xl font-semibold text-white",
                                                children: "Job Description"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "mb-4",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", {
                                                htmlFor: "job-description",
                                                className: "block text-sm font-medium text-gray-200 mb-2",
                                                children: "Paste the job description here"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("textarea", {
                                                id: "job-description",
                                                rows: 8,
                                                className: "w-full px-3 py-2 bg-gray-800 border border-gray-600 text-white placeholder-gray-400 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500",
                                                placeholder: "Paste the job description here...",
                                                value: jobDescription,
                                                onChange: (e)=>{
                                                    setJobDescription(e.target.value);
                                                    setError(null);
                                                }
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                onClick: handleGenerateCoverLetter,
                                disabled: !resumeText || !jobDescription || isProcessing,
                                className: "w-full flex items-center justify-center px-6 py-3 text-base font-medium rounded-md transition-colors ".concat(!resumeText || !jobDescription || isProcessing ? 'bg-gray-700 text-gray-400 cursor-not-allowed border border-gray-600' : 'bg-blue-600 hover:bg-blue-700 text-white border border-blue-600', " focus:outline-none focus:ring-2 focus:ring-blue-500"),
                                children: isProcessing ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_ui_BanterLoader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A, {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                            className: "ml-3",
                                            children: "Generating Cover Letter..."
                                        })
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .A, {
                                            className: "w-5 h-5 mr-2"
                                        }),
                                        "Generate Cover Letter"
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-gray-900 border border-gray-700 rounded-lg p-6 shadow-md flex flex-col h-full",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between items-center mb-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h2", {
                                        className: "text-xl font-semibold text-white",
                                        children: "Generated Cover Letter"
                                    }),
                                    generatedCoverLetter && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex space-x-2",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                onClick: copyToClipboard,
                                                className: "inline-flex items-center px-3 py-1.5 border border-gray-600 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-300 bg-gray-800 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors",
                                                children: [
                                                    copied ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .A, {
                                                        className: "w-4 h-4 mr-1 text-green-400"
                                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .A, {
                                                        className: "w-4 h-4 mr-1"
                                                    }),
                                                    copied ? 'Copied!' : 'Copy'
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                onClick: downloadAsPdf,
                                                className: "inline-flex items-center px-3 py-1.5 border border-gray-600 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-300 bg-gray-800 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .A, {
                                                        className: "w-4 h-4 mr-1"
                                                    }),
                                                    "Download PDF"
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            isProcessing ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "border-2 border-dashed border-gray-600 rounded-lg p-8 text-center flex-1 flex items-center justify-center flex-col space-y-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_ui_BanterLoader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A, {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                                        className: "text-gray-300",
                                        children: "Generating your cover letter with AI..."
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                                        className: "text-sm text-gray-400",
                                        children: "This may take a few moments."
                                    })
                                ]
                            }) : generatedCoverLetter ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "border border-gray-600 rounded-md p-4 flex-1 overflow-y-auto bg-gray-800",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("pre", {
                                    className: "whitespace-pre-wrap font-sans text-white text-sm leading-relaxed",
                                    children: generatedCoverLetter
                                })
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "border-2 border-dashed border-gray-600 rounded-lg p-8 text-center flex-1 flex items-center justify-center",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_AlertCircle_Check_Copy_Download_FileText_Upload_Zap_lucide_react__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A, {
                                            className: "w-12 h-12 mx-auto text-gray-500 mb-4"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                                            className: "text-gray-400",
                                            children: "Your generated cover letter will appear here."
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CoverLetterGeneratorSection);


/***/ }),

/***/ 65061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15933);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12115);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44987);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36680);

function _templateObject() {
    const data = (0,_swc_helpers_tagged_template_literal__WEBPACK_IMPORTED_MODULE_0__._)([
        '\n  .banter-loader {\n    position: relative;\n    width: 72px;\n    height: 72px;\n    margin: 0 auto;\n  }\n\n  .banter-loader__box {\n    float: left;\n    position: relative;\n    width: 20px;\n    height: 20px;\n    margin-right: 6px;\n  }\n\n  .banter-loader__box:before {\n    content: "";\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 100%;\n    height: 100%;\n    background: #fff;\n  }\n\n  .banter-loader__box:nth-child(3n) {\n    margin-right: 0;\n    margin-bottom: 6px;\n  }\n\n  .banter-loader__box:nth-child(1):before, .banter-loader__box:nth-child(4):before {\n    margin-left: 26px;\n  }\n\n  .banter-loader__box:nth-child(3):before {\n    margin-top: 52px;\n  }\n\n  .banter-loader__box:last-child {\n    margin-bottom: 0;\n  }\n\n  @keyframes moveBox-1 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(1) {\n    animation: moveBox-1 4s infinite;\n  }\n\n  @keyframes moveBox-2 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 26px);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 26px);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, 26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(2) {\n    animation: moveBox-2 4s infinite;\n  }\n\n  @keyframes moveBox-3 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(-26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(-26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(3) {\n    animation: moveBox-3 4s infinite;\n  }\n\n  @keyframes moveBox-4 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(4) {\n    animation: moveBox-4 4s infinite;\n  }\n\n  @keyframes moveBox-5 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(0, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(26px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(0px, -26px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(5) {\n    animation: moveBox-5 4s infinite;\n  }\n\n  @keyframes moveBox-6 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, 26px);\n    }\n\n    81.8181818182% {\n      transform: translate(-26px, 26px);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(6) {\n    animation: moveBox-6 4s infinite;\n  }\n\n  @keyframes moveBox-7 {\n    9.0909090909% {\n      transform: translate(26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(26px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(26px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(0px, 0px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(7) {\n    animation: moveBox-7 4s infinite;\n  }\n\n  @keyframes moveBox-8 {\n    9.0909090909% {\n      transform: translate(0, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(-26px, -26px);\n    }\n\n    36.3636363636% {\n      transform: translate(0px, -26px);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, -26px);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, -26px);\n    }\n\n    63.6363636364% {\n      transform: translate(0px, -26px);\n    }\n\n    72.7272727273% {\n      transform: translate(0px, -26px);\n    }\n\n    81.8181818182% {\n      transform: translate(26px, -26px);\n    }\n\n    90.9090909091% {\n      transform: translate(26px, 0px);\n    }\n\n    100% {\n      transform: translate(0px, 0px);\n    }\n  }\n\n  .banter-loader__box:nth-child(8) {\n    animation: moveBox-8 4s infinite;\n  }\n\n  @keyframes moveBox-9 {\n    9.0909090909% {\n      transform: translate(-26px, 0);\n    }\n\n    18.1818181818% {\n      transform: translate(-26px, 0);\n    }\n\n    27.2727272727% {\n      transform: translate(0px, 0);\n    }\n\n    36.3636363636% {\n      transform: translate(-26px, 0);\n    }\n\n    45.4545454545% {\n      transform: translate(0px, 0);\n    }\n\n    54.5454545455% {\n      transform: translate(0px, 0);\n    }\n\n    63.6363636364% {\n      transform: translate(-26px, 0);\n    }\n\n    72.7272727273% {\n      transform: translate(-26px, 0);\n    }\n\n    81.8181818182% {\n      transform: translate(-52px, 0);\n    }\n\n    90.9090909091% {\n      transform: translate(-26px, 0);\n    }\n\n    100% {\n      transform: translate(0px, 0);\n    }\n  }\n\n  .banter-loader__box:nth-child(9) {\n    animation: moveBox-9 4s infinite;\n  }\n'
    ]);
    _templateObject = function() {
        return data;
    };
    return data;
}




const Loader = (param)=>{
    let { overlay = false, text, backgroundOpacity = 80, blur = true, className, ariaLabel = 'Loading...' } = param;
    const loaderContent = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(StyledWrapper, {
        className: className,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
                className: "banter-loader",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                        className: "banter-loader__box"
                    })
                ]
            }),
            overlay && text && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("p", {
                className: "text-white text-center mt-4 font-medium",
                "aria-live": "polite",
                children: text
            })
        ]
    });
    if (overlay) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("fixed inset-0 z-50 flex items-center justify-center flex-col", blur && "backdrop-blur-md", "transition-all duration-300"),
            style: {
                backgroundColor: "rgba(0, 0, 0, ".concat(backgroundOpacity / 100, ")"),
                backdropFilter: blur ? 'blur(8px)' : 'none',
                WebkitBackdropFilter: blur ? 'blur(8px)' : 'none'
            },
            role: "dialog",
            "aria-modal": "true",
            "aria-label": ariaLabel,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
                className: "relative",
                children: loaderContent
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
        role: "status",
        "aria-label": ariaLabel,
        children: loaderContent
    });
};
const StyledWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Ay.div(_templateObject());
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ })

}]);