"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[7315],{

/***/ 23274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ useAuth),
/* harmony export */   AuthProvider: () => (/* binding */ AuthProvider)
/* harmony export */ });
/* unused harmony export AuthContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* __next_internal_client_entry_do_not_use__ AuthProvider,useAuth,AuthContext auto */ 

/**
 * Refresh the current Firebase auth token
 */ async function refreshAuthToken() {
    try {
        // Import Firebase auth dynamically to avoid SSR issues
        const { getCurrentUserIdToken } = await Promise.all(/* import() */[__webpack_require__.e(2992), __webpack_require__.e(7811), __webpack_require__.e(1840), __webpack_require__.e(3549), __webpack_require__.e(2144)]).then(__webpack_require__.bind(__webpack_require__, 12144));
        console.log('🔄 Attempting to refresh Firebase ID token...');
        // Force refresh the Firebase ID token
        const freshToken = await getCurrentUserIdToken(true);
        if (freshToken) {
            // Update localStorage with the new token
            localStorage.setItem('auth_token', freshToken);
            console.log('✅ Firebase ID token refreshed successfully');
            return freshToken;
        } else {
            console.warn('⚠️ No fresh token returned from Firebase');
            return null;
        }
    } catch (error) {
        console.error('❌ Token refresh failed:', error);
        // If Firebase auth is not available or user is not signed in,
        // clear the auth state completely
        if (error instanceof Error && error.message.includes('No Firebase user signed in')) {
            localStorage.removeItem('auth_token');
            // Clear all caches
            Object.keys(localStorage).forEach((key)=>{
                if (key.startsWith('auth_verification_')) {
                    localStorage.removeItem(key);
                }
            });
        }
        return null;
    }
}
// Create the context with default values
const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    user: null,
    loading: true,
    isAuthenticated: false,
    signOut: async ()=>{}
});
// AuthProvider component that manages unified auth state
function AuthProvider(param) {
    let { children, initialUser } = param;
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialUser || null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!initialUser);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Only check auth state once on mount
        let mounted = true;
        const checkAuthState = async ()=>{
            // Skip auth checks on authentication pages to prevent API loops
            const isAuthPage =  true && [
                '/sign-in',
                '/sign-up'
            ].includes(window.location.pathname);
            if (isAuthPage) {
                console.log('🚫 Auth check skipped: on authentication page');
                if (mounted) {
                    setUser(null);
                    setLoading(false);
                }
                return;
            }
            try {
                // First check for session cookie to avoid unnecessary API call
                const cookies = document.cookie.split(';').reduce((acc, cookie)=>{
                    const [name, value] = cookie.trim().split('=');
                    acc[name] = value;
                    return acc;
                }, {});
                const sessionCookie = cookies.session;
                const token = localStorage.getItem('auth_token');
                // If no session cookie and no token, user is not authenticated
                if (!sessionCookie && !token) {
                    if (mounted) {
                        setUser(null);
                        setLoading(false);
                    }
                    return;
                }
                // Only verify token if we have one
                if (token) {
                    // Check for cached verification result (15 min cache)
                    const cacheKey = "auth_verification_".concat(token.substring(0, 10));
                    const cachedVerification = localStorage.getItem(cacheKey);
                    if (cachedVerification) {
                        try {
                            const cached = JSON.parse(cachedVerification);
                            const cacheAge = Date.now() - cached.timestamp;
                            // Use cached result if less than 15 minutes old
                            if (cacheAge < 15 * 60 * 1000) {
                                console.log('🚀 Using cached auth verification');
                                if (mounted && cached.verified && cached.user) {
                                    setUser(cached.user);
                                }
                                if (mounted) {
                                    setLoading(false);
                                }
                                return;
                            } else {
                                // Remove expired cache
                                localStorage.removeItem(cacheKey);
                            }
                        } catch (error) {
                            // Invalid cache, remove it
                            localStorage.removeItem(cacheKey);
                        }
                    }
                    console.log('🔍 Verifying auth token via API');
                    const response = await fetch('/api/auth/verify', {
                        headers: {
                            'Authorization': "Bearer ".concat(token)
                        }
                    });
                    if (response.ok) {
                        const userData = await response.json();
                        // Cache successful verification
                        const cacheData = {
                            verified: true,
                            user: userData.user,
                            timestamp: Date.now()
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        if (mounted) {
                            setUser(userData.user);
                        }
                    } else if (response.status === 401) {
                        // Token is invalid/expired, check if server suggests refresh
                        const errorData = await response.json().catch(()=>({}));
                        const shouldRefresh = errorData.shouldRefresh !== false; // Default to true
                        console.log('🔄 Token expired/invalid:', errorData.error || 'Unknown error');
                        if (shouldRefresh) {
                            console.log('🔄 Attempting token refresh...');
                            try {
                                const refreshed = await refreshAuthToken();
                                if (refreshed && mounted) {
                                    // Retry verification with new token
                                    const retryResponse = await fetch('/api/auth/verify', {
                                        headers: {
                                            'Authorization': "Bearer ".concat(refreshed)
                                        }
                                    });
                                    if (retryResponse.ok) {
                                        const userData = await retryResponse.json();
                                        // Cache successful verification with new token
                                        const newCacheKey = "auth_verification_".concat(refreshed.substring(0, 10));
                                        const cacheData = {
                                            verified: true,
                                            user: userData.user,
                                            timestamp: Date.now()
                                        };
                                        localStorage.setItem(newCacheKey, JSON.stringify(cacheData));
                                        if (mounted) {
                                            setUser(userData.user);
                                        }
                                        return;
                                    }
                                }
                            } catch (refreshError) {
                                console.error('🔄 Token refresh failed:', refreshError);
                            }
                        }
                        // If refresh failed or not recommended, clear auth state
                        localStorage.removeItem('auth_token');
                        // Clear all verification caches
                        Object.keys(localStorage).forEach((key)=>{
                            if (key.startsWith('auth_verification_')) {
                                localStorage.removeItem(key);
                            }
                        });
                        if (mounted) {
                            setUser(null);
                        }
                    } else {
                        // Other error, cache failed verification temporarily (1 min)
                        const cacheData = {
                            verified: false,
                            user: null,
                            timestamp: Date.now() - 14 * 60 * 1000 // Expire quickly for failed attempts
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        localStorage.removeItem('auth_token');
                        if (mounted) {
                            setUser(null);
                        }
                    }
                } else if (sessionCookie) {
                    // If we have session cookie but no token, consider user logged in
                    // but with minimal user data
                    if (mounted) {
                        setUser({
                            uid: 'session-user',
                            email: 'unknown@session.com',
                            email_verified: false
                        });
                    }
                }
            } catch (error) {
                console.error('Auth state check failed:', error);
                if (mounted) {
                    setUser(null);
                }
            } finally{
                if (mounted) {
                    setLoading(false);
                }
            }
        };
        if (!initialUser) {
            checkAuthState();
        } else {
            setLoading(false);
        }
        return ()=>{
            mounted = false;
        };
    }, [
        initialUser
    ]);
    const signOut = async ()=>{
        try {
            await fetch('/api/auth/signout', {
                method: 'POST'
            });
            localStorage.removeItem('auth_token');
            setUser(null);
        } catch (error) {
            console.error('Sign out error:', error);
        }
    };
    const contextValue = {
        user,
        loading,
        isAuthenticated: !!user,
        signOut
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(AuthContext.Provider, {
        value: contextValue,
        children: children
    });
}
// Custom hook to use the auth context
function useAuth() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthContext);
    if (context === undefined) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
}
// Export the context for advanced use cases



/***/ }),

/***/ 27737:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ Skeleton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36680);


function Skeleton(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        "data-slot": "skeleton",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_1__.cn)("bg-accent animate-pulse rounded-md", className),
        ...props
    });
}



/***/ }),

/***/ 37315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ authenticated_layout)
});

// UNUSED EXPORTS: AuthenticatedLayout

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next/dist/client/app-dir/link.js
var app_dir_link = __webpack_require__(6874);
var link_default = /*#__PURE__*/__webpack_require__.n(app_dir_link);
// EXTERNAL MODULE: ./node_modules/next/dist/api/image.js
var api_image = __webpack_require__(66766);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(35695);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/gallery-vertical-end.js
var gallery_vertical_end = __webpack_require__(65895);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/audio-waveform.js
var audio_waveform = __webpack_require__(20402);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/command.js
var command = __webpack_require__(54785);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/square-terminal.js
var square_terminal = __webpack_require__(62978);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/house.js
var house = __webpack_require__(57340);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/message-square.js
var message_square = __webpack_require__(81497);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/file-text.js
var file_text = __webpack_require__(57434);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/mail.js
var mail = __webpack_require__(28883);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/bot.js
var bot = __webpack_require__(25657);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/book-open.js
var book_open = __webpack_require__(5040);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chart-pie.js
var chart_pie = __webpack_require__(84355);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/frame.js
var icons_frame = __webpack_require__(57665);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/map.js
var map = __webpack_require__(63578);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/shield.js
var shield = __webpack_require__(75525);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/users.js
var users = __webpack_require__(17580);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/search.js
var search = __webpack_require__(47924);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-up.js
var chevron_up = __webpack_require__(47863);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevrons-up-down.js
var chevrons_up_down = __webpack_require__(10081);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/user.js
var icons_user = __webpack_require__(71007);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/settings.js
var settings = __webpack_require__(381);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/log-out.js
var log_out = __webpack_require__(34835);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-avatar/dist/index.mjs + 1 modules
var dist = __webpack_require__(54011);
// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(36680);
;// ./components/ui/avatar.tsx
/* __next_internal_client_entry_do_not_use__ Avatar,AvatarImage,AvatarFallback auto */ 



function Avatar(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(dist/* Root */.bL, {
        "data-slot": "avatar",
        className: (0,utils.cn)("relative flex size-8 shrink-0 overflow-hidden rounded-full", className),
        ...props
    });
}
function AvatarImage(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(dist/* Image */._V, {
        "data-slot": "avatar-image",
        className: (0,utils.cn)("aspect-square size-full", className),
        ...props
    });
}
function AvatarFallback(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(dist/* Fallback */.H4, {
        "data-slot": "avatar-fallback",
        className: (0,utils.cn)("bg-muted flex size-full items-center justify-center rounded-full", className),
        ...props
    });
}


// EXTERNAL MODULE: ./node_modules/@radix-ui/react-slot/dist/index.mjs
var react_slot_dist = __webpack_require__(99708);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-right.js
var chevron_right = __webpack_require__(13052);
;// ./components/ui/breadcrumb.tsx





function Breadcrumb(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("nav", {
        "aria-label": "breadcrumb",
        "data-slot": "breadcrumb",
        ...props
    });
}
function BreadcrumbList(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("ol", {
        "data-slot": "breadcrumb-list",
        className: (0,utils.cn)("text-muted-foreground flex flex-wrap items-center gap-1.5 text-sm break-words sm:gap-2.5", className),
        ...props
    });
}
function BreadcrumbItem(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
        "data-slot": "breadcrumb-item",
        className: (0,utils.cn)("inline-flex items-center gap-1.5", className),
        ...props
    });
}
function BreadcrumbLink(param) {
    let { asChild, className, ...props } = param;
    const Comp = asChild ? react_slot_dist/* Slot */.DX : "a";
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(Comp, {
        "data-slot": "breadcrumb-link",
        className: (0,utils.cn)("hover:text-foreground transition-colors", className),
        ...props
    });
}
function BreadcrumbPage(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
        "data-slot": "breadcrumb-page",
        role: "link",
        "aria-disabled": "true",
        "aria-current": "page",
        className: (0,utils.cn)("text-foreground font-normal", className),
        ...props
    });
}
function BreadcrumbSeparator(param) {
    let { children, className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
        "data-slot": "breadcrumb-separator",
        role: "presentation",
        "aria-hidden": "true",
        className: (0,utils.cn)("[&>svg]:size-3.5", className),
        ...props,
        children: children !== null && children !== void 0 ? children : /*#__PURE__*/ (0,jsx_runtime.jsx)(chevron_right/* default */.A, {})
    });
}
function BreadcrumbEllipsis(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ _jsxs("span", {
        "data-slot": "breadcrumb-ellipsis",
        role: "presentation",
        "aria-hidden": "true",
        className: cn("flex size-9 items-center justify-center", className),
        ...props,
        children: [
            /*#__PURE__*/ _jsx(MoreHorizontal, {
                className: "size-4"
            }),
            /*#__PURE__*/ _jsx("span", {
                className: "sr-only",
                children: "More"
            })
        ]
    });
}


// EXTERNAL MODULE: ./node_modules/@radix-ui/react-collapsible/dist/index.mjs
var react_collapsible_dist = __webpack_require__(88106);
;// ./components/ui/collapsible.tsx
/* __next_internal_client_entry_do_not_use__ Collapsible,CollapsibleTrigger,CollapsibleContent auto */ 

function Collapsible(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_collapsible_dist/* Root */.bL, {
        "data-slot": "collapsible",
        ...props
    });
}
function CollapsibleTrigger(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_collapsible_dist/* CollapsibleTrigger */.R6, {
        "data-slot": "collapsible-trigger",
        ...props
    });
}
function CollapsibleContent(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_collapsible_dist/* CollapsibleContent */.Ke, {
        "data-slot": "collapsible-content",
        ...props
    });
}


// EXTERNAL MODULE: ./node_modules/@radix-ui/react-dropdown-menu/dist/index.mjs + 1 modules
var react_dropdown_menu_dist = __webpack_require__(48698);
;// ./components/ui/dropdown-menu.tsx
/* __next_internal_client_entry_do_not_use__ DropdownMenu,DropdownMenuPortal,DropdownMenuTrigger,DropdownMenuContent,DropdownMenuGroup,DropdownMenuLabel,DropdownMenuItem,DropdownMenuCheckboxItem,DropdownMenuRadioGroup,DropdownMenuRadioItem,DropdownMenuSeparator,DropdownMenuShortcut,DropdownMenuSub,DropdownMenuSubTrigger,DropdownMenuSubContent auto */ 




function DropdownMenu(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dropdown_menu_dist/* Root */.bL, {
        "data-slot": "dropdown-menu",
        ...props
    });
}
function DropdownMenuPortal(param) {
    let { ...props } = param;
    return /*#__PURE__*/ _jsx(DropdownMenuPrimitive.Portal, {
        "data-slot": "dropdown-menu-portal",
        ...props
    });
}
function DropdownMenuTrigger(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dropdown_menu_dist/* Trigger */.l9, {
        "data-slot": "dropdown-menu-trigger",
        ...props
    });
}
function DropdownMenuContent(param) {
    let { className, sideOffset = 4, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dropdown_menu_dist/* Portal */.ZL, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dropdown_menu_dist/* Content */.UC, {
            "data-slot": "dropdown-menu-content",
            sideOffset: sideOffset,
            className: (0,utils.cn)("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--radix-dropdown-menu-content-available-height) min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md", className),
            ...props
        })
    });
}
function DropdownMenuGroup(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dropdown_menu_dist/* Group */.YJ, {
        "data-slot": "dropdown-menu-group",
        ...props
    });
}
function DropdownMenuItem(param) {
    let { className, inset, variant = "default", ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dropdown_menu_dist/* Item */.q7, {
        "data-slot": "dropdown-menu-item",
        "data-inset": inset,
        "data-variant": variant,
        className: (0,utils.cn)("focus:bg-accent focus:text-accent-foreground data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 dark:data-[variant=destructive]:focus:bg-destructive/20 data-[variant=destructive]:focus:text-destructive data-[variant=destructive]:*:[svg]:!text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        ...props
    });
}
function DropdownMenuCheckboxItem(param) {
    let { className, children, checked, ...props } = param;
    return /*#__PURE__*/ _jsxs(DropdownMenuPrimitive.CheckboxItem, {
        "data-slot": "dropdown-menu-checkbox-item",
        className: cn("focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        checked: checked,
        ...props,
        children: [
            /*#__PURE__*/ _jsx("span", {
                className: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center",
                children: /*#__PURE__*/ _jsx(DropdownMenuPrimitive.ItemIndicator, {
                    children: /*#__PURE__*/ _jsx(CheckIcon, {
                        className: "size-4"
                    })
                })
            }),
            children
        ]
    });
}
function DropdownMenuRadioGroup(param) {
    let { ...props } = param;
    return /*#__PURE__*/ _jsx(DropdownMenuPrimitive.RadioGroup, {
        "data-slot": "dropdown-menu-radio-group",
        ...props
    });
}
function DropdownMenuRadioItem(param) {
    let { className, children, ...props } = param;
    return /*#__PURE__*/ _jsxs(DropdownMenuPrimitive.RadioItem, {
        "data-slot": "dropdown-menu-radio-item",
        className: cn("focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        ...props,
        children: [
            /*#__PURE__*/ _jsx("span", {
                className: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center",
                children: /*#__PURE__*/ _jsx(DropdownMenuPrimitive.ItemIndicator, {
                    children: /*#__PURE__*/ _jsx(CircleIcon, {
                        className: "size-2 fill-current"
                    })
                })
            }),
            children
        ]
    });
}
function DropdownMenuLabel(param) {
    let { className, inset, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dropdown_menu_dist/* Label */.JU, {
        "data-slot": "dropdown-menu-label",
        "data-inset": inset,
        className: (0,utils.cn)("px-2 py-1.5 text-sm font-medium data-[inset]:pl-8", className),
        ...props
    });
}
function DropdownMenuSeparator(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dropdown_menu_dist/* Separator */.wv, {
        "data-slot": "dropdown-menu-separator",
        className: (0,utils.cn)("bg-border -mx-1 my-1 h-px", className),
        ...props
    });
}
function DropdownMenuShortcut(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ _jsx("span", {
        "data-slot": "dropdown-menu-shortcut",
        className: cn("text-muted-foreground ml-auto text-xs tracking-widest", className),
        ...props
    });
}
function DropdownMenuSub(param) {
    let { ...props } = param;
    return /*#__PURE__*/ _jsx(DropdownMenuPrimitive.Sub, {
        "data-slot": "dropdown-menu-sub",
        ...props
    });
}
function DropdownMenuSubTrigger(param) {
    let { className, inset, children, ...props } = param;
    return /*#__PURE__*/ _jsxs(DropdownMenuPrimitive.SubTrigger, {
        "data-slot": "dropdown-menu-sub-trigger",
        "data-inset": inset,
        className: cn("focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground flex cursor-default items-center rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[inset]:pl-8", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ _jsx(ChevronRightIcon, {
                className: "ml-auto size-4"
            })
        ]
    });
}
function DropdownMenuSubContent(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ _jsx(DropdownMenuPrimitive.SubContent, {
        "data-slot": "dropdown-menu-sub-content",
        className: cn("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-hidden rounded-md border p-1 shadow-lg", className),
        ...props
    });
}


// EXTERNAL MODULE: ./node_modules/class-variance-authority/dist/index.mjs
var class_variance_authority_dist = __webpack_require__(74466);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/panel-left.js
var panel_left = __webpack_require__(22432);
;// ./hooks/use-mobile.ts

const MOBILE_BREAKPOINT = 768;
function useIsMobile() {
    const [isMobile, setIsMobile] = react.useState(false);
    react.useEffect(()=>{
        const mql = window.matchMedia("(max-width: ".concat(MOBILE_BREAKPOINT - 1, "px)"));
        const onChange = ()=>{
            setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
        };
        mql.addEventListener("change", onChange);
        setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
        return ()=>mql.removeEventListener("change", onChange);
    }, []);
    return isMobile;
}

// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(97168);
// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(89852);
// EXTERNAL MODULE: ./components/ui/separator.tsx
var separator = __webpack_require__(76037);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-dialog/dist/index.mjs
var react_dialog_dist = __webpack_require__(15452);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/x.js
var x = __webpack_require__(54416);
;// ./components/ui/sheet.tsx
/* __next_internal_client_entry_do_not_use__ Sheet,SheetTrigger,SheetClose,SheetContent,SheetHeader,SheetFooter,SheetTitle,SheetDescription auto */ 




function Sheet(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dialog_dist/* Root */.bL, {
        "data-slot": "sheet",
        ...props
    });
}
function SheetTrigger(param) {
    let { ...props } = param;
    return /*#__PURE__*/ _jsx(SheetPrimitive.Trigger, {
        "data-slot": "sheet-trigger",
        ...props
    });
}
function SheetClose(param) {
    let { ...props } = param;
    return /*#__PURE__*/ _jsx(SheetPrimitive.Close, {
        "data-slot": "sheet-close",
        ...props
    });
}
function SheetPortal(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dialog_dist/* Portal */.ZL, {
        "data-slot": "sheet-portal",
        ...props
    });
}
function SheetOverlay(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dialog_dist/* Overlay */.hJ, {
        "data-slot": "sheet-overlay",
        className: (0,utils.cn)("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50", className),
        ...props
    });
}
function SheetContent(param) {
    let { className, children, side = "right", ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(SheetPortal, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(SheetOverlay, {}),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(react_dialog_dist/* Content */.UC, {
                "data-slot": "sheet-content",
                className: (0,utils.cn)("bg-background data-[state=open]:animate-in data-[state=closed]:animate-out fixed z-50 flex flex-col gap-4 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500", side === "right" && "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm", side === "left" && "data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm", side === "top" && "data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b", side === "bottom" && "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t", className),
                ...props,
                children: [
                    children,
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(react_dialog_dist/* Close */.bm, {
                        className: "ring-offset-background focus:ring-ring data-[state=open]:bg-secondary absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(x/* default */.A, {
                                className: "size-4"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                className: "sr-only",
                                children: "Close"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
function SheetHeader(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        "data-slot": "sheet-header",
        className: (0,utils.cn)("flex flex-col gap-1.5 p-4", className),
        ...props
    });
}
function SheetFooter(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ _jsx("div", {
        "data-slot": "sheet-footer",
        className: cn("mt-auto flex flex-col gap-2 p-4", className),
        ...props
    });
}
function SheetTitle(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dialog_dist/* Title */.hE, {
        "data-slot": "sheet-title",
        className: (0,utils.cn)("text-foreground font-semibold", className),
        ...props
    });
}
function SheetDescription(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_dialog_dist/* Description */.VY, {
        "data-slot": "sheet-description",
        className: (0,utils.cn)("text-muted-foreground text-sm", className),
        ...props
    });
}


// EXTERNAL MODULE: ./components/ui/skeleton.tsx
var skeleton = __webpack_require__(27737);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-tooltip/dist/index.mjs
var react_tooltip_dist = __webpack_require__(89613);
;// ./components/ui/tooltip.tsx
/* __next_internal_client_entry_do_not_use__ Tooltip,TooltipTrigger,TooltipContent,TooltipProvider auto */ 



function TooltipProvider(param) {
    let { delayDuration = 0, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_tooltip_dist/* Provider */.Kq, {
        "data-slot": "tooltip-provider",
        delayDuration: delayDuration,
        ...props
    });
}
function Tooltip(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(TooltipProvider, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(react_tooltip_dist/* Root */.bL, {
            "data-slot": "tooltip",
            ...props
        })
    });
}
function TooltipTrigger(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_tooltip_dist/* Trigger */.l9, {
        "data-slot": "tooltip-trigger",
        ...props
    });
}
function TooltipContent(param) {
    let { className, sideOffset = 0, children, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(react_tooltip_dist/* Portal */.ZL, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(react_tooltip_dist/* Content */.UC, {
            "data-slot": "tooltip-content",
            sideOffset: sideOffset,
            className: (0,utils.cn)("bg-primary text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit origin-(--radix-tooltip-content-transform-origin) rounded-md px-3 py-1.5 text-xs text-balance", className),
            ...props,
            children: [
                children,
                /*#__PURE__*/ (0,jsx_runtime.jsx)(react_tooltip_dist/* Arrow */.i3, {
                    className: "bg-primary fill-primary z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px]"
                })
            ]
        })
    });
}


;// ./components/ui/sidebar.tsx
/* __next_internal_client_entry_do_not_use__ Sidebar,SidebarContent,SidebarFooter,SidebarGroup,SidebarGroupAction,SidebarGroupContent,SidebarGroupLabel,SidebarHeader,SidebarInput,SidebarInset,SidebarMenu,SidebarMenuAction,SidebarMenuBadge,SidebarMenuButton,SidebarMenuItem,SidebarMenuSkeleton,SidebarMenuSub,SidebarMenuSubButton,SidebarMenuSubItem,SidebarProvider,SidebarRail,SidebarSeparator,SidebarTrigger,useSidebar auto */ 












const SIDEBAR_COOKIE_NAME = "sidebar_state";
const SIDEBAR_COOKIE_MAX_AGE = 60 * 60 * 24 * 7;
const SIDEBAR_WIDTH = "10rem";
const SIDEBAR_WIDTH_MOBILE = "18rem";
const SIDEBAR_WIDTH_ICON = "3rem";
const SIDEBAR_KEYBOARD_SHORTCUT = "b";
const SidebarContext = /*#__PURE__*/ react.createContext(null);
function useSidebar() {
    const context = react.useContext(SidebarContext);
    if (!context) {
        throw new Error("useSidebar must be used within a SidebarProvider.");
    }
    return context;
}
function SidebarProvider(param) {
    let { defaultOpen = true, open: openProp, onOpenChange: setOpenProp, className, style, children, ...props } = param;
    const isMobile = useIsMobile();
    const [openMobile, setOpenMobile] = react.useState(false);
    // This is the internal state of the sidebar.
    // We use openProp and setOpenProp for control from outside the component.
    const [_open, _setOpen] = react.useState(defaultOpen);
    const open = openProp !== null && openProp !== void 0 ? openProp : _open;
    const setOpen = react.useCallback((value)=>{
        const openState = typeof value === "function" ? value(open) : value;
        if (setOpenProp) {
            setOpenProp(openState);
        } else {
            _setOpen(openState);
        }
        // This sets the cookie to keep the sidebar state.
        if (typeof document !== 'undefined') {
            document.cookie = "".concat(SIDEBAR_COOKIE_NAME, "=").concat(openState, "; path=/; max-age=").concat(SIDEBAR_COOKIE_MAX_AGE);
        }
    }, [
        setOpenProp,
        open
    ]);
    // Helper to toggle the sidebar.
    const toggleSidebar = react.useCallback(()=>{
        return isMobile ? setOpenMobile((open)=>!open) : setOpen((open)=>!open);
    }, [
        isMobile,
        setOpen,
        setOpenMobile
    ]);
    // Adds a keyboard shortcut to toggle the sidebar.
    react.useEffect(()=>{
        if (false) {}
        const handleKeyDown = (event)=>{
            if (event.key === SIDEBAR_KEYBOARD_SHORTCUT && (event.metaKey || event.ctrlKey)) {
                event.preventDefault();
                toggleSidebar();
            }
        };
        window.addEventListener("keydown", handleKeyDown);
        return ()=>window.removeEventListener("keydown", handleKeyDown);
    }, [
        toggleSidebar
    ]);
    // We add a state so that we can do data-state="expanded" or "collapsed".
    // This makes it easier to style the sidebar with Tailwind classes.
    const state = open ? "expanded" : "collapsed";
    const contextValue = react.useMemo(()=>({
            state,
            open,
            setOpen,
            isMobile,
            openMobile,
            setOpenMobile,
            toggleSidebar
        }), [
        state,
        open,
        setOpen,
        isMobile,
        openMobile,
        setOpenMobile,
        toggleSidebar
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarContext.Provider, {
        value: contextValue,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(TooltipProvider, {
            delayDuration: 0,
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                "data-slot": "sidebar-wrapper",
                style: {
                    "--sidebar-width": SIDEBAR_WIDTH,
                    "--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
                    ...style
                },
                className: (0,utils.cn)("group/sidebar-wrapper has-data-[variant=inset]:bg-sidebar flex min-h-svh w-full", className),
                ...props,
                children: children
            })
        })
    });
}
function Sidebar(param) {
    let { side = "left", variant = "sidebar", collapsible = "offcanvas", className, children, ...props } = param;
    const { isMobile, state, openMobile, setOpenMobile } = useSidebar();
    if (collapsible === "none") {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            "data-slot": "sidebar",
            className: (0,utils.cn)("bg-sidebar text-sidebar-foreground flex h-full w-(--sidebar-width) flex-col", className),
            ...props,
            children: children
        });
    }
    if (isMobile) {
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(Sheet, {
            open: openMobile,
            onOpenChange: setOpenMobile,
            ...props,
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(SheetContent, {
                "data-sidebar": "sidebar",
                "data-slot": "sidebar",
                "data-mobile": "true",
                className: "bg-sidebar text-sidebar-foreground w-(--sidebar-width) p-0 [&>button]:hidden",
                style: {
                    "--sidebar-width": SIDEBAR_WIDTH_MOBILE
                },
                side: side,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SheetHeader, {
                        className: "sr-only",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SheetTitle, {
                                children: "Sidebar"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SheetDescription, {
                                children: "Displays the mobile sidebar."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "flex h-full w-full flex-col",
                        children: children
                    })
                ]
            })
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "group peer text-sidebar-foreground hidden md:block",
        "data-state": state,
        "data-collapsible": state === "collapsed" ? collapsible : "",
        "data-variant": variant,
        "data-side": side,
        "data-slot": "sidebar",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                "data-slot": "sidebar-gap",
                className: (0,utils.cn)("relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear", "group-data-[collapsible=offcanvas]:w-0", "group-data-[side=right]:rotate-180", variant === "floating" || variant === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)")
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                "data-slot": "sidebar-container",
                className: (0,utils.cn)("fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear md:flex", side === "left" ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]" : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]", // Adjust the padding for floating and inset variants.
                variant === "floating" || variant === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)", className),
                ...props,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    "data-sidebar": "sidebar",
                    "data-slot": "sidebar-inner",
                    className: "bg-sidebar group-data-[variant=floating]:border-sidebar-border flex h-full w-full flex-col group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:shadow-sm",
                    children: children
                })
            })
        ]
    });
}
function SidebarTrigger(param) {
    let { className, onClick, ...props } = param;
    const { toggleSidebar } = useSidebar();
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(ui_button/* Button */.$, {
        "data-sidebar": "trigger",
        "data-slot": "sidebar-trigger",
        variant: "ghost",
        size: "icon",
        className: (0,utils.cn)("size-7 text-white dark:text-white hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800", className),
        onClick: (event)=>{
            onClick === null || onClick === void 0 ? void 0 : onClick(event);
            toggleSidebar();
        },
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(panel_left/* default */.A, {
                className: "text-white dark:text-white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                className: "sr-only",
                children: "Toggle Sidebar"
            })
        ]
    });
}
function SidebarRail(param) {
    let { className, ...props } = param;
    const { toggleSidebar } = useSidebar();
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        "data-sidebar": "rail",
        "data-slot": "sidebar-rail",
        "aria-label": "Toggle Sidebar",
        tabIndex: -1,
        onClick: toggleSidebar,
        title: "Toggle Sidebar",
        className: (0,utils.cn)("hover:after:bg-sidebar-border absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear group-data-[side=left]:-right-4 group-data-[side=right]:left-0 after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] sm:flex", "in-data-[side=left]:cursor-w-resize in-data-[side=right]:cursor-e-resize", "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize", "hover:group-data-[collapsible=offcanvas]:bg-sidebar group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full", "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2", "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2", className),
        ...props
    });
}
function SidebarInset(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("main", {
        "data-slot": "sidebar-inset",
        className: (0,utils.cn)("bg-background relative flex w-full flex-1 flex-col", "md:peer-data-[variant=inset]:m-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow-sm md:peer-data-[variant=inset]:peer-data-[state=collapsed]:ml-2", className),
        ...props
    });
}
function SidebarInput(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(input/* Input */.p, {
        "data-slot": "sidebar-input",
        "data-sidebar": "input",
        className: (0,utils.cn)("bg-background h-8 w-full shadow-none", className),
        ...props
    });
}
function SidebarHeader(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        "data-slot": "sidebar-header",
        "data-sidebar": "header",
        className: (0,utils.cn)("flex flex-col gap-2 p-2", className),
        ...props
    });
}
function SidebarFooter(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        "data-slot": "sidebar-footer",
        "data-sidebar": "footer",
        className: (0,utils.cn)("flex flex-col gap-2 p-2", className),
        ...props
    });
}
function SidebarSeparator(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ _jsx(Separator, {
        "data-slot": "sidebar-separator",
        "data-sidebar": "separator",
        className: cn("bg-sidebar-border mx-2 w-auto", className),
        ...props
    });
}
function SidebarContent(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        "data-slot": "sidebar-content",
        "data-sidebar": "content",
        className: (0,utils.cn)("flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden", className),
        ...props
    });
}
function SidebarGroup(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        "data-slot": "sidebar-group",
        "data-sidebar": "group",
        className: (0,utils.cn)("relative flex w-full min-w-0 flex-col p-2", className),
        ...props
    });
}
function SidebarGroupLabel(param) {
    let { className, asChild = false, ...props } = param;
    const Comp = asChild ? react_slot_dist/* Slot */.DX : "div";
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(Comp, {
        "data-slot": "sidebar-group-label",
        "data-sidebar": "group-label",
        className: (0,utils.cn)("text-sidebar-foreground/70 ring-sidebar-ring flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium outline-hidden transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0", className),
        ...props
    });
}
function SidebarGroupAction(param) {
    let { className, asChild = false, ...props } = param;
    const Comp = asChild ? Slot : "button";
    return /*#__PURE__*/ _jsx(Comp, {
        "data-slot": "sidebar-group-action",
        "data-sidebar": "group-action",
        className: cn("text-sidebar-foreground ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground absolute top-3.5 right-3 flex aspect-square w-5 items-center justify-center rounded-md p-0 outline-hidden transition-transform focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", // Increases the hit area of the button on mobile.
        "after:absolute after:-inset-2 md:after:hidden", "group-data-[collapsible=icon]:hidden", className),
        ...props
    });
}
function SidebarGroupContent(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ _jsx("div", {
        "data-slot": "sidebar-group-content",
        "data-sidebar": "group-content",
        className: cn("w-full text-sm", className),
        ...props
    });
}
function SidebarMenu(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("ul", {
        "data-slot": "sidebar-menu",
        "data-sidebar": "menu",
        className: (0,utils.cn)("flex w-full min-w-0 flex-col gap-1", className),
        ...props
    });
}
function SidebarMenuItem(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
        "data-slot": "sidebar-menu-item",
        "data-sidebar": "menu-item",
        className: (0,utils.cn)("group/menu-item relative", className),
        ...props
    });
}
const sidebarMenuButtonVariants = (0,class_variance_authority_dist/* cva */.F)("peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-hidden ring-sidebar-ring transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 group-has-data-[sidebar=menu-action]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:size-8! group-data-[collapsible=icon]:p-2! [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0", {
    variants: {
        variant: {
            default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
            outline: "bg-background shadow-[0_0_0_1px_hsl(var(--sidebar-border))] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_hsl(var(--sidebar-accent))]"
        },
        size: {
            default: "h-8 text-sm",
            sm: "h-7 text-xs",
            lg: "h-12 text-sm group-data-[collapsible=icon]:p-0!"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function SidebarMenuButton(param) {
    let { asChild = false, isActive = false, variant = "default", size = "default", tooltip, className, ...props } = param;
    const Comp = asChild ? react_slot_dist/* Slot */.DX : "button";
    const { isMobile, state } = useSidebar();
    const button = /*#__PURE__*/ (0,jsx_runtime.jsx)(Comp, {
        "data-slot": "sidebar-menu-button",
        "data-sidebar": "menu-button",
        "data-size": size,
        "data-active": isActive,
        className: (0,utils.cn)(sidebarMenuButtonVariants({
            variant,
            size
        }), className),
        ...props
    });
    if (!tooltip) {
        return button;
    }
    if (typeof tooltip === "string") {
        tooltip = {
            children: tooltip
        };
    }
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(Tooltip, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(TooltipTrigger, {
                asChild: true,
                children: button
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(TooltipContent, {
                side: "right",
                align: "center",
                hidden: state !== "collapsed" || isMobile,
                ...tooltip
            })
        ]
    });
}
function SidebarMenuAction(param) {
    let { className, asChild = false, showOnHover = false, ...props } = param;
    const Comp = asChild ? Slot : "button";
    return /*#__PURE__*/ _jsx(Comp, {
        "data-slot": "sidebar-menu-action",
        "data-sidebar": "menu-action",
        className: cn("text-sidebar-foreground ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground peer-hover/menu-button:text-sidebar-accent-foreground absolute top-1.5 right-1 flex aspect-square w-5 items-center justify-center rounded-md p-0 outline-hidden transition-transform focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", // Increases the hit area of the button on mobile.
        "after:absolute after:-inset-2 md:after:hidden", "peer-data-[size=sm]/menu-button:top-1", "peer-data-[size=default]/menu-button:top-1.5", "peer-data-[size=lg]/menu-button:top-2.5", "group-data-[collapsible=icon]:hidden", showOnHover && "peer-data-[active=true]/menu-button:text-sidebar-accent-foreground group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 data-[state=open]:opacity-100 md:opacity-0", className),
        ...props
    });
}
function SidebarMenuBadge(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ _jsx("div", {
        "data-slot": "sidebar-menu-badge",
        "data-sidebar": "menu-badge",
        className: cn("text-sidebar-foreground pointer-events-none absolute right-1 flex h-5 min-w-5 items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums select-none", "peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[active=true]/menu-button:text-sidebar-accent-foreground", "peer-data-[size=sm]/menu-button:top-1", "peer-data-[size=default]/menu-button:top-1.5", "peer-data-[size=lg]/menu-button:top-2.5", "group-data-[collapsible=icon]:hidden", className),
        ...props
    });
}
function SidebarMenuSkeleton(param) {
    let { className, showIcon = false, ...props } = param;
    // Random width between 50 to 90%.
    const width = React.useMemo(()=>{
        return "".concat(Math.floor(Math.random() * 40) + 50, "%");
    }, []);
    return /*#__PURE__*/ _jsxs("div", {
        "data-slot": "sidebar-menu-skeleton",
        "data-sidebar": "menu-skeleton",
        className: cn("flex h-8 items-center gap-2 rounded-md px-2", className),
        ...props,
        children: [
            showIcon && /*#__PURE__*/ _jsx(Skeleton, {
                className: "size-4 rounded-md",
                "data-sidebar": "menu-skeleton-icon"
            }),
            /*#__PURE__*/ _jsx(Skeleton, {
                className: "h-4 max-w-(--skeleton-width) flex-1",
                "data-sidebar": "menu-skeleton-text",
                style: {
                    "--skeleton-width": width
                }
            })
        ]
    });
}
function SidebarMenuSub(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ _jsx("ul", {
        "data-slot": "sidebar-menu-sub",
        "data-sidebar": "menu-sub",
        className: cn("border-sidebar-border mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l px-2.5 py-0.5", "group-data-[collapsible=icon]:hidden", className),
        ...props
    });
}
function SidebarMenuSubItem(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ _jsx("li", {
        "data-slot": "sidebar-menu-sub-item",
        "data-sidebar": "menu-sub-item",
        className: cn("group/menu-sub-item relative", className),
        ...props
    });
}
function SidebarMenuSubButton(param) {
    let { asChild = false, size = "md", isActive = false, className, ...props } = param;
    const Comp = asChild ? Slot : "a";
    return /*#__PURE__*/ _jsx(Comp, {
        "data-slot": "sidebar-menu-sub-button",
        "data-sidebar": "menu-sub-button",
        "data-size": size,
        "data-active": isActive,
        className: cn("text-sidebar-foreground ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground active:bg-sidebar-accent active:text-sidebar-accent-foreground [&>svg]:text-sidebar-accent-foreground flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 outline-hidden focus-visible:ring-2 disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0", "data-[active=true]:bg-sidebar-accent data-[active=true]:text-sidebar-accent-foreground", size === "sm" && "text-xs", size === "md" && "text-sm", "group-data-[collapsible=icon]:hidden", className),
        ...props
    });
}


// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(23274);
;// ./components/ui/sticky-banner.tsx
/* __next_internal_client_entry_do_not_use__ StickyBanner auto */ 



const StickyBanner = (param)=>{
    let { showBanner, message, hideOnScroll = false, className, children } = param;
    const [isVisible, setIsVisible] = (0,react.useState)(showBanner);
    const [isScrollHidden, setIsScrollHidden] = (0,react.useState)(false);
    const [lastScrollY, setLastScrollY] = (0,react.useState)(0);
    (0,react.useEffect)(()=>{
        setIsVisible(showBanner);
    }, [
        showBanner
    ]);
    (0,react.useEffect)(()=>{
        if (!hideOnScroll || !isVisible) return;
        const handleScroll = ()=>{
            const currentScrollY = window.scrollY;
            if (currentScrollY > lastScrollY && currentScrollY > 50) {
                // Scrolling down
                setIsScrollHidden(true);
            } else {
                // Scrolling up
                setIsScrollHidden(false);
            }
            setLastScrollY(currentScrollY);
        };
        window.addEventListener("scroll", handleScroll, {
            passive: true
        });
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, [
        lastScrollY,
        hideOnScroll,
        isVisible
    ]);
    const handleClose = ()=>{
        setIsVisible(false);
    };
    if (!isVisible) return null;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: (0,utils.cn)("fixed top-0 left-0 right-0 z-50 transition-transform duration-300 ease-in-out", isScrollHidden ? "-translate-y-full" : "translate-y-0", className),
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "bg-black text-white px-4 py-3 flex items-center justify-between",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center justify-center flex-1",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                            className: "text-sm font-medium",
                            children: message
                        }),
                        children
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                    onClick: handleClose,
                    className: "ml-4 p-1 hover:bg-white/10 rounded-full transition-colors",
                    "aria-label": "Close banner",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(x/* default */.A, {
                        className: "h-4 w-4"
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/loader-circle.js
var loader_circle = __webpack_require__(51154);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/arrow-right.js
var arrow_right = __webpack_require__(92138);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var sonner_dist = __webpack_require__(56671);
;// ./components/EmailVerificationBanner.tsx
/* __next_internal_client_entry_do_not_use__ EmailVerificationBanner auto */ 





const EmailVerificationBanner = ()=>{
    const { user } = (0,AuthContext/* useAuth */.A)();
    const [isLoading, setIsLoading] = (0,react.useState)(false);
    // Only show banner if user exists and email is not verified
    const shouldShowBanner = user && !user.email_verified;
    const handleVerifyClick = async ()=>{
        if (!(user === null || user === void 0 ? void 0 : user.email) || isLoading) return;
        setIsLoading(true);
        try {
            const response = await fetch('/api/auth/resend-verification', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            const data = await response.json();
            if (response.ok) {
                sonner_dist/* toast */.o.success('Verification email sent! Please check your inbox.');
            } else {
                sonner_dist/* toast */.o.error(data.error || 'Failed to send verification email');
            }
        } catch (error) {
            console.error('Error sending verification email:', error);
            sonner_dist/* toast */.o.error('Failed to send verification email. Please try again.');
        } finally{
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(StickyBanner, {
        showBanner: !!shouldShowBanner,
        message: "Please verify your email to get full access to the features",
        hideOnScroll: true,
        className: "bg-black",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
            onClick: handleVerifyClick,
            disabled: isLoading,
            className: "ml-2 inline-flex items-center text-sm font-medium text-white hover:text-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
            "aria-label": "Resend verification email",
            children: isLoading ? /*#__PURE__*/ (0,jsx_runtime.jsx)(loader_circle/* default */.A, {
                className: "h-4 w-4 animate-spin"
            }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(arrow_right/* default */.A, {
                className: "h-4 w-4"
            })
        })
    });
};

;// ./components/authenticated-layout.tsx
/* __next_internal_client_entry_do_not_use__ AuthenticatedLayout,default auto */ 













// This is sample data.
const data = {
    user: {
        name: "PrepBettr User",
        email: "user@prepbettr.com",
        avatar: "/avatars/shadcn.jpg"
    },
    teams: [
        {
            name: "PrepBettr",
            logo: gallery_vertical_end/* default */.A,
            plan: "Enterprise"
        },
        {
            name: "Acme Corp.",
            logo: audio_waveform/* default */.A,
            plan: "Startup"
        },
        {
            name: "Evil Corp.",
            logo: command/* default */.A,
            plan: "Free"
        }
    ],
    navMain: [
        {
            title: "Core Features",
            url: "#",
            icon: square_terminal/* default */.A,
            isActive: true,
            items: [
                {
                    title: "Dashboard",
                    url: "/dashboard",
                    icon: house/* default */.A
                },
                {
                    title: "Interviews",
                    url: "/dashboard/interview",
                    icon: message_square/* default */.A
                },
                {
                    title: "Resume Tailor",
                    url: "/dashboard/resume-tailor",
                    icon: file_text/* default */.A
                },
                {
                    title: "Cover Letter Generator",
                    url: "/dashboard/cover-letter-generator",
                    icon: mail/* default */.A
                },
                {
                    title: "Auto Apply",
                    url: "/dashboard/auto-apply",
                    icon: bot/* default */.A
                }
            ]
        }
    ],
    navSecondary: [
        {
            title: "Support",
            url: "#",
            icon: book_open/* default */.A
        },
        {
            title: "Feedback",
            url: "#",
            icon: chart_pie/* default */.A
        }
    ],
    projects: [
        {
            name: "Design Engineering",
            url: "#",
            icon: icons_frame/* default */.A
        },
        {
            name: "Sales & Marketing",
            url: "#",
            icon: chart_pie/* default */.A
        },
        {
            name: "Travel",
            url: "#",
            icon: map/* default */.A
        }
    ]
};
const AuthenticatedLayout = (param)=>{
    let { children } = param;
    const pathname = (0,navigation.usePathname)();
    const router = (0,navigation.useRouter)();
    const { user } = (0,AuthContext/* useAuth */.A)();
    const [activeTeam, setActiveTeam] = react.useState(data.teams[0]);
    const [interviewNames, setInterviewNames] = react.useState({});
    // Effect to fetch interview names for breadcrumb display
    react.useEffect(()=>{
        // Extract interview IDs from current path
        const pathSegments = (pathname || '').split('/').filter(Boolean);
        const interviewIndex = pathSegments.findIndex((segment)=>segment === 'interview');
        if (interviewIndex !== -1 && pathSegments[interviewIndex + 1]) {
            const interviewId = pathSegments[interviewIndex + 1];
            // Only fetch if we don't already have this interview name
            if (!interviewNames[interviewId] && interviewId.length > 10) {
                // For now, we'll use a mock name since we don't have a real API
                // In a real app, you would fetch from your API
                const mockInterviewName = "".concat(interviewId.substring(0, 8), "... Interview");
                setInterviewNames((prev)=>({
                        ...prev,
                        [interviewId]: mockInterviewName
                    }));
            }
        }
    }, [
        pathname,
        interviewNames
    ]);
    const handleLogout = async ()=>{
        try {
            await fetch("/api/profile/logout", {
                method: "POST"
            });
            router.push("/marketing");
            router.refresh();
        } catch (error) {
            console.error('Logout failed:', error);
        }
    };
    var _pathname_startsWith;
    // Check if current route is admin or account
    const isAdminRoute = (_pathname_startsWith = pathname === null || pathname === void 0 ? void 0 : pathname.startsWith('/admin')) !== null && _pathname_startsWith !== void 0 ? _pathname_startsWith : false;
    // Add admin items to navigation if on admin route
    const navMainWithAdmin = isAdminRoute ? [
        ...data.navMain,
        {
            title: "Administration",
            url: "#",
            icon: shield/* default */.A,
            isActive: false,
            items: [
                {
                    title: "Admin Dashboard",
                    url: "/admin",
                    icon: shield/* default */.A
                },
                {
                    title: "Subscriptions",
                    url: "/admin/subscriptions",
                    icon: users/* default */.A
                }
            ]
        }
    ] : data.navMain;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(SidebarProvider, {
        defaultOpen: false,
        style: {
            "--sidebar-width": "20rem",
            "--sidebar-width-mobile": "22rem",
            "--sidebar-width-icon": "5.5rem"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(Sidebar, {
                variant: "sidebar",
                collapsible: "icon",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarHeader, {
                        className: "group-data-[collapsible=icon]:h-16 group-data-[collapsible=icon]:flex group-data-[collapsible=icon]:items-center",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex items-center justify-center gap-3 px-2 py-2 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0 group-data-[collapsible=icon]:py-0",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex aspect-square size-8 items-center justify-center rounded-lg text-sidebar-primary-foreground group-data-[collapsible=icon]:size-12",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(api_image["default"], {
                                        src: "/logo.svg",
                                        alt: "PrepBettr Logo",
                                        width: 20,
                                        height: 20,
                                        className: "size-5 group-data-[collapsible=icon]:size-8"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                    className: "text-lg font-bold text-sidebar-foreground group-data-[collapsible=icon]:group-data-[state=collapsed]:hidden",
                                    children: "PrepBettr"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(SidebarContent, {
                        className: "group-data-[collapsible=icon]:flex group-data-[collapsible=icon]:flex-col group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:h-full",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarGroup, {
                                className: "py-0 group-data-[collapsible=icon]:hidden",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(SidebarGroupLabel, {
                                    className: "group relative",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(search/* default */.A, {
                                            className: "absolute left-2 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarInput, {
                                            placeholder: "Search...",
                                            className: "pl-8 focus-visible:ring-0"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "group-data-[collapsible=icon]:flex group-data-[collapsible=icon]:flex-col group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:gap-6 group-data-[collapsible=icon]:flex-1",
                                children: navMainWithAdmin.map((item)=>{
                                    var _item_items;
                                    return /*#__PURE__*/ (0,jsx_runtime.jsx)(Collapsible, {
                                        asChild: true,
                                        defaultOpen: item.isActive,
                                        className: "group/collapsible",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(SidebarGroup, {
                                            className: "mt-8",
                                            children: [
                                                " ",
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarGroupLabel, {
                                                    asChild: true,
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(CollapsibleTrigger, {
                                                        className: "group/label text-sm text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(item.icon, {
                                                                className: "size-5 mr-3 group-data-[collapsible=icon]:mr-0"
                                                            }),
                                                            " ",
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                className: "group-data-[collapsible=icon]:hidden",
                                                                children: item.title
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(chevron_up/* default */.A, {
                                                                className: "ml-auto size-4 transition-transform duration-200 group-data-[state=closed]/collapsible:rotate-180 group-data-[collapsible=icon]:hidden"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(CollapsibleContent, {
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarMenu, {
                                                        children: (_item_items = item.items) === null || _item_items === void 0 ? void 0 : _item_items.map((subItem)=>{
                                                            const isActive = pathname === subItem.url || subItem.url !== '/dashboard' && (pathname === null || pathname === void 0 ? void 0 : pathname.startsWith(subItem.url));
                                                            return /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarMenuItem, {
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarMenuButton, {
                                                                    asChild: true,
                                                                    isActive: isActive,
                                                                    className: "group-data-[collapsible=icon]:!h-12 group-data-[collapsible=icon]:!p-0",
                                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                                                        href: subItem.url,
                                                                        className: "flex items-center group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:h-12 group-data-[collapsible=icon]:w-full",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(subItem.icon, {
                                                                                className: "size-5 mr-3 group-data-[collapsible=icon]:mr-0 group-data-[collapsible=icon]:mx-0"
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                                className: "group-data-[collapsible=icon]:hidden",
                                                                                children: subItem.title
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            }, subItem.title);
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    }, item.title);
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SidebarGroup, {
                                className: "mt-auto group-data-[collapsible=icon]:mt-0",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarGroupLabel, {
                                        className: "group-data-[collapsible=icon]:hidden",
                                        children: "Support"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarMenu, {
                                        className: "group-data-[collapsible=icon]:flex group-data-[collapsible=icon]:flex-col group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:gap-4",
                                        children: data.navSecondary.map((item)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarMenuItem, {
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarMenuButton, {
                                                    asChild: true,
                                                    size: "sm",
                                                    className: "group-data-[collapsible=icon]:!h-10 group-data-[collapsible=icon]:!p-0",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                        href: item.url,
                                                        className: "flex items-center group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:items-center group-data-[collapsible=icon]:h-10 group-data-[collapsible=icon]:w-full",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(item.icon, {
                                                                className: "size-5 mr-3 group-data-[collapsible=icon]:mr-0 group-data-[collapsible=icon]:mx-0"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                className: "group-data-[collapsible=icon]:hidden",
                                                                children: item.title
                                                            })
                                                        ]
                                                    })
                                                })
                                            }, item.title))
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarFooter, {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarMenu, {
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarMenuItem, {
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(DropdownMenu, {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(DropdownMenuTrigger, {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(SidebarMenuButton, {
                                                size: "lg",
                                                className: "data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground group-data-[collapsible=icon]:!justify-center group-data-[collapsible=icon]:!items-center group-data-[collapsible=icon]:!h-12 group-data-[collapsible=icon]:!p-0 group-data-[collapsible=icon]:!w-full group-data-[collapsible=icon]:!flex",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(Avatar, {
                                                        className: "h-8 w-8 rounded-lg",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(AvatarImage, {
                                                                src: (user === null || user === void 0 ? void 0 : user.picture) || data.user.avatar,
                                                                alt: (user === null || user === void 0 ? void 0 : user.name) || data.user.name
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(AvatarFallback, {
                                                                className: "rounded-lg",
                                                                children: ((user === null || user === void 0 ? void 0 : user.name) || (user === null || user === void 0 ? void 0 : user.email) || data.user.name).slice(0, 2).toUpperCase()
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "grid flex-1 text-left text-sm leading-tight group-data-[collapsible=icon]:hidden",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                className: "truncate font-semibold",
                                                                children: (user === null || user === void 0 ? void 0 : user.name) || data.user.name
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                className: "truncate text-xs text-muted-foreground",
                                                                children: (user === null || user === void 0 ? void 0 : user.email) || data.user.email
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(chevrons_up_down/* default */.A, {
                                                        className: "ml-auto size-4 group-data-[collapsible=icon]:hidden"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(DropdownMenuContent, {
                                            className: "w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg",
                                            side: "bottom",
                                            align: "end",
                                            sideOffset: 4,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(DropdownMenuLabel, {
                                                    className: "p-0 font-normal",
                                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "flex items-center gap-2 px-1 py-1.5 text-left text-sm",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(Avatar, {
                                                                className: "h-8 w-8 rounded-lg",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(AvatarImage, {
                                                                        src: (user === null || user === void 0 ? void 0 : user.picture) || data.user.avatar,
                                                                        alt: (user === null || user === void 0 ? void 0 : user.name) || data.user.name
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(AvatarFallback, {
                                                                        className: "rounded-lg",
                                                                        children: ((user === null || user === void 0 ? void 0 : user.name) || (user === null || user === void 0 ? void 0 : user.email) || data.user.name).slice(0, 2).toUpperCase()
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                className: "grid flex-1 text-left text-sm leading-tight",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                        className: "truncate font-semibold",
                                                                        children: (user === null || user === void 0 ? void 0 : user.name) || data.user.name
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                        className: "truncate text-xs text-muted-foreground",
                                                                        children: (user === null || user === void 0 ? void 0 : user.email) || data.user.email
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(DropdownMenuSeparator, {}),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(DropdownMenuGroup, {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(DropdownMenuItem, {
                                                            asChild: true,
                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                                                href: "/dashboard/profile",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(icons_user/* default */.A, {
                                                                        className: "mr-2 h-4 w-4"
                                                                    }),
                                                                    "Profile"
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(DropdownMenuItem, {
                                                            asChild: true,
                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                                                href: "/dashboard/settings",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(settings/* default */.A, {
                                                                        className: "mr-2 h-4 w-4"
                                                                    }),
                                                                    "Settings"
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(DropdownMenuSeparator, {}),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)(DropdownMenuItem, {
                                                    onClick: handleLogout,
                                                    className: "cursor-pointer",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)(log_out/* default */.A, {
                                                            className: "mr-2 h-4 w-4"
                                                        }),
                                                        "Log out"
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarRail, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(SidebarInset, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("header", {
                        className: "flex h-16 shrink-0 items-center gap-2 px-6 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-16",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(SidebarTrigger, {
                                    className: "group-data-[collapsible=icon]:ml-0"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)(Breadcrumb, {
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(BreadcrumbList, {
                                        children: (pathname || '').split('/').filter(Boolean).map((segment, index, array)=>{
                                            const href = '/' + array.slice(0, index + 1).join('/');
                                            const isLast = index === array.length - 1;
                                            let title = segment.charAt(0).toUpperCase() + segment.slice(1);
                                            if (array[index - 1] === 'interview' && interviewNames[segment]) {
                                                title = interviewNames[segment];
                                            }
                                            return /*#__PURE__*/ (0,jsx_runtime.jsxs)(react.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(BreadcrumbItem, {
                                                        className: "hidden md:block",
                                                        children: isLast ? /*#__PURE__*/ (0,jsx_runtime.jsx)(BreadcrumbPage, {
                                                            children: title
                                                        }) : /*#__PURE__*/ (0,jsx_runtime.jsx)(BreadcrumbLink, {
                                                            href: href,
                                                            children: title
                                                        })
                                                    }),
                                                    !isLast && /*#__PURE__*/ (0,jsx_runtime.jsx)(BreadcrumbSeparator, {
                                                        className: "hidden md:block"
                                                    })
                                                ]
                                            }, segment);
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-1 flex-col gap-4 p-4 pt-0",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(EmailVerificationBanner, {}),
                            children
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const authenticated_layout = (AuthenticatedLayout);


/***/ }),

/***/ 76037:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   w: () => (/* binding */ Separator)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_separator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(87489);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);
/* __next_internal_client_entry_do_not_use__ Separator auto */ 



function Separator(param) {
    let { className, orientation = "horizontal", decorative = true, ...props } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_separator__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .b, {
        "data-slot": "separator",
        decorative: decorative,
        orientation: orientation,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("bg-border shrink-0 data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px", className),
        ...props
    });
}



/***/ }),

/***/ 89852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);



function Input(param) {
    let { className, type, ...props } = param;
    const isDisabled = props.disabled;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
        type: type,
        "data-slot": "input",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(// Base styles for dark theme
        "bg-gray-800 text-white placeholder-gray-400 border-gray-600", "flex h-9 w-full min-w-0 rounded-md border px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none", "md:text-sm", // File input specific styles
        "file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-white", // Selection styles
        "selection:bg-primary-200 selection:text-dark-100", // Focus states with brand color (primary-200 from globals.css)
        "focus-visible:border-primary-200 focus-visible:ring-primary-200/50 focus-visible:ring-[3px]", // Disabled states with proper contrast
        isDisabled && "disabled:bg-gray-800/50 disabled:text-gray-500 disabled:placeholder-gray-500 disabled:cursor-not-allowed disabled:opacity-75", // Validation error states
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className),
        ...props
    });
}



/***/ }),

/***/ 97168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Button)
/* harmony export */ });
/* unused harmony export buttonVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99708);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74466);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);





const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none", {
    variants: {
        variant: {
            default: "bg-primary-200 text-dark-100 shadow-xs hover:bg-primary-200/90 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            destructive: "bg-destructive-100 text-white shadow-xs hover:bg-destructive-200 focus-visible:ring-destructive-100/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            outline: "border border-gray-600 bg-gray-800 text-white shadow-xs hover:bg-gray-700 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800/50 disabled:text-gray-500 disabled:border-gray-700",
            secondary: "bg-gray-700 text-white shadow-xs hover:bg-gray-600 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800 disabled:text-gray-500",
            ghost: "text-white hover:bg-gray-800 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500",
            link: "text-primary-200 underline-offset-4 hover:underline focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button(param) {
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__/* .Slot */ .DX : "button";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Comp, {
        "data-slot": "button",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    });
}



/***/ })

}]);