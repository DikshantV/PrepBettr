"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[9340],{

/***/ 9340:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  VoiceLiveClient: () => (/* binding */ VoiceLiveClient)
});

// UNUSED EXPORTS: getVoiceLiveClient

// EXTERNAL MODULE: ./lib/azure-ai-foundry/config/foundry-config.ts
var foundry_config = __webpack_require__(89576);
;// ./lib/azure-ai-foundry/voice/foundry-environment.ts
/* provided dependency */ var process = __webpack_require__(87358);
/**
 * Azure AI Foundry Environment Configuration
 * 
 * Provides a getEnv() utility function that fetches Azure AI Foundry configuration
 * from Azure Key Vault with environment variable fallback.
 * Follows the existing pattern from the project's foundry-config.ts.
 */ 
/**
 * Cache for environment configuration to avoid repeated Azure Key Vault calls
 */ let cachedVoiceConfig = null;
/**
 * Get environment configuration for voice services
 * Uses Azure Key Vault with environment variable fallback
 * 
 * @param forceRefresh - Force refresh the cached configuration
 * @returns Promise<VoiceEnvironmentConfig>
 */ async function getEnv() {
    let forceRefresh = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    if (cachedVoiceConfig && !forceRefresh) {
        return cachedVoiceConfig;
    }
    try {
        // Use existing foundry config which already handles Key Vault + env fallback
        const foundryConfig = await (0,foundry_config/* getFoundryConfig */.at)(forceRefresh);
        cachedVoiceConfig = {
            endpoint: foundryConfig.endpoint,
            apiKey: foundryConfig.apiKey,
            projectId: foundryConfig.projectId,
            region: foundryConfig.region,
            resourceId: foundryConfig.resourceId,
            resourceGroup: foundryConfig.resourceGroup,
            deploymentName: process.env.AZURE_FOUNDRY_DEPLOYMENT_NAME || 'gpt-4o'
        };
        // Validate required fields for voice client
        const requiredFields = [
            'endpoint',
            'apiKey',
            'projectId',
            'region'
        ];
        const missingFields = requiredFields.filter((field)=>!cachedVoiceConfig[field]);
        if (missingFields.length > 0) {
            throw new Error("Missing required Azure AI Foundry voice configuration: ".concat(missingFields.join(', ')));
        }
        console.log('✅ Azure AI Foundry voice configuration loaded successfully');
        return cachedVoiceConfig;
    } catch (error) {
        console.error('❌ Failed to load Azure AI Foundry voice configuration:', error);
        // Fallback: try direct environment variables as last resort
        const fallbackConfig = {
            endpoint: process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            region: process.env.AZURE_FOUNDRY_REGION || 'eastus',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            deploymentName: process.env.AZURE_FOUNDRY_DEPLOYMENT_NAME || 'gpt-4o'
        };
        // Final validation
        if (!fallbackConfig.endpoint || !fallbackConfig.apiKey) {
            throw new Error('Critical Azure AI Foundry voice configuration missing. ' + 'Ensure AZURE_FOUNDRY_ENDPOINT and AZURE_FOUNDRY_API_KEY are set.');
        }
        cachedVoiceConfig = fallbackConfig;
        console.warn('⚠️ Using fallback environment configuration for Azure AI Foundry voice');
        return cachedVoiceConfig;
    }
}
/**
 * Clear cached configuration (useful for testing)
 */ function clearVoiceConfigCache() {
    cachedVoiceConfig = null;
}
/**
 * Validate voice environment configuration
 */ function validateVoiceConfig(config) {
    const errors = [];
    if (!config.endpoint) {
        errors.push('Missing endpoint');
    } else if (!config.endpoint.startsWith('https://')) {
        errors.push('Endpoint must use HTTPS');
    }
    if (!config.apiKey) {
        errors.push('Missing API key');
    }
    if (!config.projectId) {
        errors.push('Missing project ID');
    }
    if (!config.region) {
        errors.push('Missing region');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}

// EXTERNAL MODULE: ./lib/azure-ai-foundry/voice/voice-telemetry.ts
var voice_telemetry = __webpack_require__(48560);
;// ./lib/azure-ai-foundry/voice/voice-live-client.ts
/**
 * Azure AI Foundry Voice Live Client
 * 
 * Provides real-time voice streaming capabilities using Azure AI Foundry's voice services.
 * Features WebSocket-based audio streaming, exponential backoff retry logic, and session management.
 */ 

/**
 * WebSocket Manager with exponential backoff and retry logic
 */ class WebSocketManager {
    /**
   * Connect to WebSocket with retry logic
   */ async connect() {
        if (this.connectionState === 'connected' || this.connectionState === 'connecting') {
            return;
        }
        this.connectionState = 'connecting';
        console.log("\uD83D\uDD0C [WebSocketManager] Connecting to ".concat(this.url, "..."));
        // Track connection attempt
        const connectionStartTime = Date.now();
        voice_telemetry.VoiceTelemetry.trackConnection('connecting', 'websocket', {
            retryCount: this.retryCount
        });
        try {
            this.ws = new WebSocket(this.url, this.protocols);
            this.ws.onopen = ()=>{
                const connectionTime = Date.now() - connectionStartTime;
                console.log('✅ [WebSocketManager] Connected successfully');
                this.connectionState = 'connected';
                this.retryCount = 0; // Reset retry count on successful connection
                // Track successful connection
                voice_telemetry.VoiceTelemetry.trackConnection('connected', 'websocket', {
                    connectionTime,
                    retryCount: 0
                });
                this.emit('connected', null);
            };
            this.ws.onclose = (event)=>{
                console.log("\uD83D\uDD0C [WebSocketManager] Connection closed: ".concat(event.code, " ").concat(event.reason));
                this.connectionState = 'disconnected';
                // Track disconnection with reason
                voice_telemetry.VoiceTelemetry.trackConnection('disconnected', 'websocket', {
                    disconnectionReason: "".concat(event.code, ": ").concat(event.reason),
                    retryCount: this.retryCount
                });
                this.emit('disconnected', {
                    code: event.code,
                    reason: event.reason
                });
                // Auto-retry if not a normal closure
                if (event.code !== 1000 && this.retryCount < this.maxRetries) {
                    this.scheduleReconnect();
                }
            };
            this.ws.onerror = (error)=>{
                console.error('❌ [WebSocketManager] Connection error:', error);
                this.connectionState = 'error';
                this.emit('error', error);
            };
            this.ws.onmessage = (event)=>{
                try {
                    const message = JSON.parse(event.data);
                    console.log("\uD83D\uDCE8 [WebSocketManager] Received message type: ".concat(message.type));
                    this.emit('message', message);
                    this.emit(message.type, message.data);
                } catch (error) {
                    console.error('❌ [WebSocketManager] Failed to parse message:', error);
                    // Handle binary audio data
                    if (event.data instanceof ArrayBuffer || event.data instanceof Blob) {
                        this.emit('binaryData', event.data);
                    }
                }
            };
            // Wait for connection to establish or fail
            await this.waitForConnection();
        } catch (error) {
            console.error('❌ [WebSocketManager] Connection failed:', error);
            this.connectionState = 'error';
            // Track connection failure
            const connectionError = new voice_telemetry/* VoiceConnectionError */.Xl("Connection failed: ".concat(error instanceof Error ? error.message : String(error)), 'websocket', this.retryCount, error instanceof Error ? error : undefined);
            voice_telemetry.VoiceTelemetry.trackError(connectionError, 'websocket', 'WebSocket Connection', false);
            if (this.retryCount < this.maxRetries) {
                this.scheduleReconnect();
            } else {
                throw connectionError;
            }
        }
    }
    /**
   * Send data through WebSocket
   */ send(data) {
        if (this.connectionState !== 'connected' || !this.ws) {
            console.warn('⚠️ [WebSocketManager] Cannot send: not connected');
            return false;
        }
        try {
            this.ws.send(data);
            return true;
        } catch (error) {
            console.error('❌ [WebSocketManager] Send failed:', error);
            return false;
        }
    }
    /**
   * Send audio frame with proper formatting
   */ sendAudioFrame(frame) {
        const message = {
            type: 'audio',
            data: {
                audioData: Array.from(new Uint8Array(frame.audioData)),
                timestamp: frame.timestamp,
                sampleRate: frame.sampleRate,
                channels: frame.channels
            },
            timestamp: Date.now()
        };
        return this.send(JSON.stringify(message));
    }
    /**
   * Close WebSocket connection
   */ close() {
        let code = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 1000, reason = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'Normal closure';
        console.log("\uD83D\uDD0C [WebSocketManager] Closing connection: ".concat(code, " ").concat(reason));
        if (this.retryTimeoutId) {
            clearTimeout(this.retryTimeoutId);
            this.retryTimeoutId = null;
        }
        if (this.ws) {
            this.connectionState = 'closed';
            this.ws.close(code, reason);
            this.ws = null;
        }
        this.eventListeners.clear();
    }
    /**
   * Get current connection state
   */ getState() {
        return this.connectionState;
    }
    /**
   * Add event listener
   */ on(event, callback) {
        if (!this.eventListeners.has(event)) {
            this.eventListeners.set(event, new Set());
        }
        this.eventListeners.get(event).add(callback);
    }
    /**
   * Remove event listener
   */ off(event, callback) {
        var _this_eventListeners_get;
        (_this_eventListeners_get = this.eventListeners.get(event)) === null || _this_eventListeners_get === void 0 ? void 0 : _this_eventListeners_get.delete(callback);
    }
    /**
   * Emit event to listeners
   */ emit(event, data) {
        var _this_eventListeners_get;
        (_this_eventListeners_get = this.eventListeners.get(event)) === null || _this_eventListeners_get === void 0 ? void 0 : _this_eventListeners_get.forEach((callback)=>{
            try {
                callback(data);
            } catch (error) {
                console.error("❌ [WebSocketManager] Event listener error for ".concat(event, ":"), error);
            }
        });
    }
    /**
   * Wait for WebSocket connection to establish
   */ waitForConnection() {
        return new Promise((resolve, reject)=>{
            const timeout = setTimeout(()=>{
                reject(new Error('Connection timeout'));
            }, 10000); // 10 second timeout
            const onConnected = ()=>{
                clearTimeout(timeout);
                this.off('connected', onConnected);
                this.off('error', onError);
                resolve();
            };
            const onError = (error)=>{
                clearTimeout(timeout);
                this.off('connected', onConnected);
                this.off('error', onError);
                reject(error);
            };
            this.on('connected', onConnected);
            this.on('error', onError);
        });
    }
    /**
   * Schedule reconnection with exponential backoff
   */ scheduleReconnect() {
        this.retryCount++;
        const delay = Math.min(this.baseDelay * Math.pow(2, this.retryCount - 1) + Math.random() * 1000, this.maxDelay);
        console.log("\uD83D\uDD04 [WebSocketManager] Scheduling reconnect attempt ".concat(this.retryCount, "/").concat(this.maxRetries, " in ").concat(delay, "ms"));
        this.retryTimeoutId = setTimeout(()=>{
            this.connect().catch((error)=>{
                console.error('❌ [WebSocketManager] Reconnection failed:', error);
            });
        }, delay);
    }
    constructor(url, protocols){
        this.url = url;
        this.protocols = protocols;
        this.ws = null;
        this.connectionState = 'disconnected';
        this.retryCount = 0;
        this.maxRetries = 5;
        this.baseDelay = 1000;
        this.maxDelay = 30000;
        this.retryTimeoutId = null;
        this.eventListeners = new Map();
    }
}
/**
 * Azure AI Foundry Voice Live Client
 */ class VoiceLiveClient {
    /**
   * Initialize the client with configuration
   */ async init() {
        let forceRefresh = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
        console.log('🔧 [VoiceLiveClient] Initializing...');
        this.config = await getEnv(forceRefresh);
        const validation = validateVoiceConfig(this.config);
        if (!validation.isValid) {
            throw new Error("Invalid voice configuration: ".concat(validation.errors.join(', ')));
        }
        console.log('✅ [VoiceLiveClient] Initialized successfully');
    }
    /**
   * Create a new voice session with default settings
   */ async createSession() {
        let options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        if (!this.config) {
            await this.init();
        }
        // Apply default settings
        const sessionOptions = {
            voiceName: options.voiceName || 'neural-hd-professional',
            locale: options.locale || 'en-US',
            speakingRate: options.speakingRate || 1.0,
            emotionalTone: options.emotionalTone || 'neutral',
            audioSettings: {
                noiseSuppression: true,
                echoCancellation: true,
                interruptionDetection: true,
                sampleRate: 16000,
                ...options.audioSettings
            }
        };
        console.log('🎤 [VoiceLiveClient] Creating voice session with options:', sessionOptions);
        try {
            var _sessionOptions_audioSettings;
            // Call Azure AI Foundry API to create session
            const response = await fetch("".concat(this.config.endpoint, "/openai/realtime/sessions"), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api-key': this.config.apiKey,
                    'X-Project-ID': this.config.projectId
                },
                body: JSON.stringify({
                    model: this.config.deploymentName || 'gpt-4o-realtime-preview',
                    voice: sessionOptions.voiceName,
                    input_audio_format: 'pcm16',
                    output_audio_format: 'pcm16',
                    turn_detection: ((_sessionOptions_audioSettings = sessionOptions.audioSettings) === null || _sessionOptions_audioSettings === void 0 ? void 0 : _sessionOptions_audioSettings.interruptionDetection) ? {
                        type: 'server_vad',
                        threshold: 0.5,
                        prefix_padding_ms: 300,
                        silence_duration_ms: 800
                    } : null,
                    tools: [],
                    tool_choice: 'none',
                    temperature: 0.7,
                    max_response_output_tokens: 4096
                })
            });
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error("Session creation failed: ".concat(response.status, " ").concat(response.statusText, " - ").concat(errorText));
            }
            const sessionData = await response.json();
            const session = {
                sessionId: sessionData.id,
                wsUrl: sessionData.websocket_url,
                options: sessionOptions,
                createdAt: new Date()
            };
            // Store session for later reference
            this.activeSessions.set(session.sessionId, session);
            console.log("✅ [VoiceLiveClient] Session created: ".concat(session.sessionId));
            return session;
        } catch (error) {
            console.error('❌ [VoiceLiveClient] Session creation failed:', error);
            throw error;
        }
    }
    /**
   * Create WebSocket manager for a session
   */ createWebSocketManager(session) {
        return new WebSocketManager(session.wsUrl, [
            'realtime'
        ]);
    }
    /**
   * Update voice settings for active sessions
   */ updateSettings(sessionId, settings) {
        const session = this.activeSessions.get(sessionId);
        if (!session) {
            console.warn("⚠️ [VoiceLiveClient] Session not found: ".concat(sessionId));
            return false;
        }
        // Update session options
        Object.assign(session.options, settings);
        console.log("\uD83D\uDD27 [VoiceLiveClient] Updated settings for session ".concat(sessionId, ":"), settings);
        return true;
    }
    /**
   * Get active session by ID
   */ getSession(sessionId) {
        return this.activeSessions.get(sessionId);
    }
    /**
   * Remove session from active sessions
   */ removeSession(sessionId) {
        this.activeSessions.delete(sessionId);
        console.log("\uD83D\uDDD1️ [VoiceLiveClient] Removed session: ".concat(sessionId));
    }
    /**
   * Get all active sessions
   */ getActiveSessions() {
        return Array.from(this.activeSessions.values());
    }
    /**
   * Cleanup all sessions
   */ cleanup() {
        console.log('🧹 [VoiceLiveClient] Cleaning up all sessions');
        this.activeSessions.clear();
    }
    constructor(){
        this.config = null;
        this.activeSessions = new Map();
    }
}
// Singleton instance
let voiceLiveClientInstance = null;
/**
 * Get shared VoiceLiveClient instance
 */ function getVoiceLiveClient() {
    if (!voiceLiveClientInstance) {
        voiceLiveClientInstance = new VoiceLiveClient();
    }
    return voiceLiveClientInstance;
}


/***/ }),

/***/ 89576:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ac: () => (/* binding */ getModelConfig),
/* harmony export */   I6: () => (/* binding */ validateFoundryConfig),
/* harmony export */   at: () => (/* binding */ getFoundryConfig),
/* harmony export */   fZ: () => (/* binding */ getDefaultModel)
/* harmony export */ });
/* unused harmony exports clearFoundryConfigCache, getEnvironmentDefaults, getDefaultModelConfigurations, getDefaultConnectionSettings, getFoundryConfigForEnvironment */
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87497);
/* harmony import */ var _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83091);
/* provided dependency */ var process = __webpack_require__(87358);
/**
 * Azure AI Foundry Configuration
 * 
 * This module handles configuration for Azure AI Foundry services,
 * including model configurations, retry policies, and connection settings.
 * Follows the existing pattern established in lib/azure-config.ts.
 */ 

// Client-side safety check
const isClient = "object" !== 'undefined';
if (isClient) {
    console.warn('[Azure AI Foundry Config] Running on client side - using fallback implementations');
}
// Azure Key Vault configuration (reuse existing vault)
const AZURE_KEY_VAULT_URI = process.env.AZURE_KEY_VAULT_URI || 'https://prepbettr-keyvault-083.vault.azure.net/';
let cachedFoundryConfig = null;
/**
 * Initialize Azure Key Vault client (reusing existing pattern)
 */ function createKeyVaultClient() {
    if (!AZURE_KEY_VAULT_URI) {
        throw new Error('AZURE_KEY_VAULT_URI environment variable is required');
    }
    const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_0__/* .DefaultAzureCredential */ .gv();
    return new _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__/* .SecretClient */ ._V(AZURE_KEY_VAULT_URI, credential);
}
/**
 * Clear cached foundry configuration
 */ function clearFoundryConfigCache() {
    if (isClient) return;
    console.log('🔄 Clearing Azure AI Foundry config cache...');
    cachedFoundryConfig = null;
}
/**
 * Fetch Azure AI Foundry configuration from Azure Key Vault with environment variable fallback
 * 
 * @param forceRefresh - Force refresh the cached configuration
 * @returns Promise<FoundryConfig> - The foundry configuration
 */ async function getFoundryConfig() {
    let forceRefresh = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    if (isClient) {
        // Client-side fallback - return empty config with all required fields
        return {
            endpoint: '',
            apiKey: '',
            projectId: '',
            resourceId: '',
            resourceGroup: '',
            region: '',
            models: {},
            connection: getDefaultConnectionSettings(),
            environment: 'development'
        };
    }
    // Clear cache if force refresh is requested
    if (forceRefresh) {
        clearFoundryConfigCache();
    }
    // Return cached configuration if available
    if (cachedFoundryConfig) {
        return cachedFoundryConfig;
    }
    try {
        console.log('🔑 Fetching Azure AI Foundry configuration from Key Vault...');
        const client = createKeyVaultClient();
        // Helper function to suppress expected 404 errors for optional secrets
        const getOptionalSecret = (name)=>client.getSecret(name).catch((err)=>{
                if (err.statusCode !== 404) {
                    console.warn("⚠️ Unexpected error fetching optional secret '".concat(name, "':"), err.message);
                }
                return null;
            });
        // Fetch foundry-specific secrets
        const [foundryEndpoint, foundryApiKey, foundryProjectId, foundryResourceGroup, foundryRegion, foundryDeploymentName, docIntEndpoint, docIntApiKey, docIntProjectId] = await Promise.all([
            getOptionalSecret('azure-foundry-endpoint'),
            getOptionalSecret('azure-foundry-api-key'),
            getOptionalSecret('azure-foundry-project-id'),
            getOptionalSecret('azure-foundry-resource-group'),
            getOptionalSecret('azure-foundry-region'),
            getOptionalSecret('azure-foundry-deployment-name'),
            getOptionalSecret('azure-foundry-docint-endpoint'),
            getOptionalSecret('azure-foundry-docint-api-key'),
            getOptionalSecret('azure-foundry-docint-project-id')
        ]);
        cachedFoundryConfig = {
            endpoint: (foundryEndpoint === null || foundryEndpoint === void 0 ? void 0 : foundryEndpoint.value) || process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: (foundryApiKey === null || foundryApiKey === void 0 ? void 0 : foundryApiKey.value) || process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: (foundryProjectId === null || foundryProjectId === void 0 ? void 0 : foundryProjectId.value) || process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: (foundryResourceGroup === null || foundryResourceGroup === void 0 ? void 0 : foundryResourceGroup.value) || process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            region: (foundryRegion === null || foundryRegion === void 0 ? void 0 : foundryRegion.value) || process.env.AZURE_FOUNDRY_REGION || 'eastus',
            environment: "production" || 0 || 0,
            models: getDefaultModelConfigurations(),
            connection: getDefaultConnectionSettings(),
            docIntelligence: (docIntEndpoint === null || docIntEndpoint === void 0 ? void 0 : docIntEndpoint.value) || (docIntApiKey === null || docIntApiKey === void 0 ? void 0 : docIntApiKey.value) || process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || process.env.AZURE_FOUNDRY_DOCINT_API_KEY ? {
                endpoint: (docIntEndpoint === null || docIntEndpoint === void 0 ? void 0 : docIntEndpoint.value) || process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || '',
                apiKey: (docIntApiKey === null || docIntApiKey === void 0 ? void 0 : docIntApiKey.value) || process.env.AZURE_FOUNDRY_DOCINT_API_KEY || '',
                projectId: (docIntProjectId === null || docIntProjectId === void 0 ? void 0 : docIntProjectId.value) || process.env.AZURE_FOUNDRY_DOCINT_PROJECT_ID,
                region: (foundryRegion === null || foundryRegion === void 0 ? void 0 : foundryRegion.value) || process.env.AZURE_FOUNDRY_REGION || 'eastus'
            } : undefined
        };
        // Validate required configuration
        const requiredFields = [
            'endpoint',
            'apiKey',
            'projectId',
            'resourceGroup'
        ];
        const missingFields = requiredFields.filter((field)=>!cachedFoundryConfig[field]);
        if (missingFields.length > 0) {
            console.warn("⚠️ Azure AI Foundry missing configuration: ".concat(missingFields.join(', ')));
            console.log('💡 Add these secrets to Azure Key Vault or set environment variables:');
            missingFields.forEach((field)=>{
                const envVar = "AZURE_FOUNDRY_".concat(field.toUpperCase());
                console.log("   - ".concat(envVar));
            });
        } else {
            console.log('✅ Azure AI Foundry configuration loaded successfully');
        }
        return cachedFoundryConfig;
    } catch (error) {
        console.error('❌ Failed to fetch Azure AI Foundry configuration:', error);
        // Fallback to environment variables
        console.log('🔄 Falling back to environment variables for Azure AI Foundry...');
        const fallbackConfig = {
            endpoint: process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            region: process.env.AZURE_FOUNDRY_REGION || 'eastus',
            environment: "production" || 0 || 0,
            models: getDefaultModelConfigurations(),
            connection: getDefaultConnectionSettings(),
            docIntelligence: process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || process.env.AZURE_FOUNDRY_DOCINT_API_KEY ? {
                endpoint: process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || '',
                apiKey: process.env.AZURE_FOUNDRY_DOCINT_API_KEY || '',
                projectId: process.env.AZURE_FOUNDRY_DOCINT_PROJECT_ID,
                region: process.env.AZURE_FOUNDRY_REGION || 'eastus'
            } : undefined
        };
        // Log missing critical configuration
        if (!fallbackConfig.endpoint || !fallbackConfig.apiKey) {
            console.error('❌ Critical Azure AI Foundry configuration missing from environment variables');
            console.log('💡 Set AZURE_FOUNDRY_ENDPOINT and AZURE_FOUNDRY_API_KEY environment variables');
        }
        cachedFoundryConfig = fallbackConfig;
        return cachedFoundryConfig;
    }
}
/**
 * Get environment-specific configuration defaults
 */ function getEnvironmentDefaults() {
    const environment = "production" || 0 || 0;
    const defaults = {
        development: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        },
        staging: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        },
        production: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        }
    };
    return defaults[environment] || defaults.development;
}
/**
 * Get default model configurations for Azure AI Foundry
 */ function getDefaultModelConfigurations() {
    return {
        'gpt-4o': {
            deploymentName: process.env.AZURE_FOUNDRY_GPT4O_DEPLOYMENT || 'gpt-4o',
            modelName: 'gpt-4o',
            version: '2024-05-13',
            maxTokens: 4096,
            temperature: 0.7,
            topP: 0.9,
            frequencyPenalty: 0,
            presencePenalty: 0,
            costPerToken: 0.005,
            capabilities: [
                'text-generation',
                'reasoning',
                'coding',
                'analysis'
            ],
            isDefault: true
        },
        'gpt-4-turbo': {
            deploymentName: process.env.AZURE_FOUNDRY_GPT4_TURBO_DEPLOYMENT || 'gpt-4-turbo',
            modelName: 'gpt-4-turbo',
            version: '2024-04-09',
            maxTokens: 4096,
            temperature: 0.7,
            topP: 0.9,
            frequencyPenalty: 0,
            presencePenalty: 0,
            costPerToken: 0.01,
            capabilities: [
                'text-generation',
                'reasoning',
                'coding',
                'analysis',
                'function-calling'
            ]
        },
        'phi-4': {
            deploymentName: process.env.AZURE_FOUNDRY_PHI4_DEPLOYMENT || 'phi-4',
            modelName: 'phi-4',
            version: '2024-12-12',
            maxTokens: 2048,
            temperature: 0.6,
            topP: 0.85,
            frequencyPenalty: 0.1,
            presencePenalty: 0.1,
            costPerToken: 0.001,
            capabilities: [
                'text-generation',
                'reasoning',
                'lightweight-tasks'
            ]
        }
    };
}
/**
 * Get default connection settings
 */ function getDefaultConnectionSettings() {
    const environment = "production" || 0 || 0;
    return {
        timeout: environment === 'production' ? 30000 : 60000,
        keepAlive: true,
        maxConnections: environment === 'production' ? 10 : 5,
        retryPolicy: {
            maxRetries: 3,
            baseDelay: 1000,
            maxDelay: 10000,
            exponentialBase: 2,
            jitter: true
        }
    };
}
/**
 * Get model configuration by name
 */ function getModelConfig(modelName) {
    const models = getDefaultModelConfigurations();
    return models[modelName] || null;
}
/**
 * Get default model configuration
 */ function getDefaultModel() {
    const models = getDefaultModelConfigurations();
    const defaultModel = Object.values(models).find((model)=>model.isDefault);
    return defaultModel || models['gpt-4o'];
}
/**
 * Validate foundry configuration
 */ function validateFoundryConfig(config) {
    const errors = [];
    if (!config.endpoint) {
        errors.push('Missing foundry endpoint');
    }
    if (!config.apiKey) {
        errors.push('Missing foundry API key');
    }
    if (!config.projectId) {
        errors.push('Missing foundry project ID');
    }
    if (!config.resourceGroup) {
        errors.push('Missing foundry resource group');
    }
    // Validate endpoint format
    if (config.endpoint && !config.endpoint.startsWith('https://')) {
        errors.push('Foundry endpoint must use HTTPS');
    }
    // Validate models configuration
    const models = Object.values(config.models);
    if (models.length === 0) {
        errors.push('No models configured');
    }
    const hasDefault = models.some((model)=>model.isDefault);
    if (!hasDefault) {
        errors.push('No default model configured');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * Get foundry configuration for specific environment
 */ async function getFoundryConfigForEnvironment(environment) {
    // Get config without modifying process.env to avoid webpack issues
    const config = await getFoundryConfig(true); // Force refresh
    // Override the environment in the returned config
    return {
        ...config,
        environment
    };
}


/***/ })

}]);