"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[3738],{

/***/ 3131:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  nW: () => (/* binding */ MantineThemeProvider),
  xd: () => (/* binding */ useMantineTheme)
});

// UNUSED EXPORTS: MantineThemeContext, useSafeMantineTheme

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/default-theme.mjs + 3 modules
var default_theme = __webpack_require__(64555);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/utils/deep-merge/deep-merge.mjs
var deep_merge = __webpack_require__(41750);
;// ./node_modules/@mantine/core/esm/core/MantineProvider/merge-mantine-theme/merge-mantine-theme.mjs





const INVALID_PRIMARY_COLOR_ERROR = "[@mantine/core] MantineProvider: Invalid theme.primaryColor, it accepts only key of theme.colors, learn more \u2013 https://mantine.dev/theming/colors/#primary-color";
const INVALID_PRIMARY_SHADE_ERROR = "[@mantine/core] MantineProvider: Invalid theme.primaryShade, it accepts only 0-9 integers or an object { light: 0-9, dark: 0-9 }";
function isValidPrimaryShade(shade) {
  if (shade < 0 || shade > 9) {
    return false;
  }
  return parseInt(shade.toString(), 10) === shade;
}
function validateMantineTheme(theme) {
  if (!(theme.primaryColor in theme.colors)) {
    throw new Error(INVALID_PRIMARY_COLOR_ERROR);
  }
  if (typeof theme.primaryShade === "object") {
    if (!isValidPrimaryShade(theme.primaryShade.dark) || !isValidPrimaryShade(theme.primaryShade.light)) {
      throw new Error(INVALID_PRIMARY_SHADE_ERROR);
    }
  }
  if (typeof theme.primaryShade === "number" && !isValidPrimaryShade(theme.primaryShade)) {
    throw new Error(INVALID_PRIMARY_SHADE_ERROR);
  }
}
function mergeMantineTheme(currentTheme, themeOverride) {
  if (!themeOverride) {
    validateMantineTheme(currentTheme);
    return currentTheme;
  }
  const result = (0,deep_merge/* deepMerge */.$)(currentTheme, themeOverride);
  if (themeOverride.fontFamily && !themeOverride.headings?.fontFamily) {
    result.headings.fontFamily = themeOverride.fontFamily;
  }
  validateMantineTheme(result);
  return result;
}


//# sourceMappingURL=merge-mantine-theme.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/MantineThemeProvider/MantineThemeProvider.mjs
/* __next_internal_client_entry_do_not_use__ MantineThemeContext,MantineThemeProvider,useMantineTheme,useSafeMantineTheme auto */ 



const MantineThemeContext = /*#__PURE__*/ (0,react.createContext)(null);
const useSafeMantineTheme = ()=>(0,react.useContext)(MantineThemeContext) || default_theme/* DEFAULT_THEME */.S;
function useMantineTheme() {
    const ctx = (0,react.useContext)(MantineThemeContext);
    if (!ctx) {
        throw new Error("@mantine/core: MantineProvider was not found in component tree, make sure you have it in your app");
    }
    return ctx;
}
function MantineThemeProvider(param) {
    let { theme, children, inherit = true } = param;
    const parentTheme = useSafeMantineTheme();
    const mergedTheme = (0,react.useMemo)(()=>mergeMantineTheme(inherit ? parentTheme : default_theme/* DEFAULT_THEME */.S, theme), [
        theme,
        parentTheme,
        inherit
    ]);
    return /* @__PURE__ */ (0,jsx_runtime.jsx)(MantineThemeContext.Provider, {
        value: mergedTheme,
        children
    });
}
MantineThemeProvider.displayName = "@mantine/core/MantineThemeProvider";
 //# sourceMappingURL=MantineThemeProvider.mjs.map


/***/ }),

/***/ 5903:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ rem),
/* harmony export */   em: () => (/* binding */ em)
/* harmony export */ });
function scaleRem(remValue) {
  if (remValue === "0rem") {
    return "0rem";
  }
  return `calc(${remValue} * var(--mantine-scale))`;
}
function createConverter(units, { shouldScale = false } = {}) {
  function converter(value) {
    if (value === 0 || value === "0") {
      return `0${units}`;
    }
    if (typeof value === "number") {
      const val = `${value / 16}${units}`;
      return shouldScale ? scaleRem(val) : val;
    }
    if (typeof value === "string") {
      if (value === "") {
        return value;
      }
      if (value.startsWith("calc(") || value.startsWith("clamp(") || value.includes("rgba(")) {
        return value;
      }
      if (value.includes(",")) {
        return value.split(",").map((val) => converter(val)).join(",");
      }
      if (value.includes(" ")) {
        return value.split(" ").map((val) => converter(val)).join(" ");
      }
      const replaced = value.replace("px", "");
      if (!Number.isNaN(Number(replaced))) {
        const val = `${Number(replaced) / 16}${units}`;
        return shouldScale ? scaleRem(val) : val;
      }
    }
    return value;
  }
  return converter;
}
const rem = createConverter("rem", { shouldScale: true });
const em = createConverter("em");


//# sourceMappingURL=rem.mjs.map


/***/ }),

/***/ 13656:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A$: () => (/* binding */ MantineContext),
/* harmony export */   AI: () => (/* binding */ useMantineClassNamesPrefix),
/* harmony export */   FI: () => (/* binding */ useMantineIsHeadless),
/* harmony export */   If: () => (/* binding */ useMantineWithStaticClasses),
/* harmony export */   NL: () => (/* binding */ useMantineSxTransform),
/* harmony export */   OY: () => (/* binding */ useMantineCssVariablesResolver),
/* harmony export */   WV: () => (/* binding */ useMantineStyleNonce),
/* harmony export */   m6: () => (/* binding */ useMantineStylesTransform)
/* harmony export */ });
/* unused harmony exports useMantineContext, useMantineEnv */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12115);
/* __next_internal_client_entry_do_not_use__ MantineContext,useMantineClassNamesPrefix,useMantineContext,useMantineCssVariablesResolver,useMantineEnv,useMantineIsHeadless,useMantineStyleNonce,useMantineStylesTransform,useMantineSxTransform,useMantineWithStaticClasses auto */ 
const MantineContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
function useMantineContext() {
    const ctx = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(MantineContext);
    if (!ctx) {
        throw new Error("[@mantine/core] MantineProvider was not found in tree");
    }
    return ctx;
}
function useMantineCssVariablesResolver() {
    return useMantineContext().cssVariablesResolver;
}
function useMantineClassNamesPrefix() {
    return useMantineContext().classNamesPrefix;
}
function useMantineStyleNonce() {
    return useMantineContext().getStyleNonce;
}
function useMantineWithStaticClasses() {
    return useMantineContext().withStaticClasses;
}
function useMantineIsHeadless() {
    return useMantineContext().headless;
}
function useMantineSxTransform() {
    var _useMantineContext_stylesTransform;
    return (_useMantineContext_stylesTransform = useMantineContext().stylesTransform) === null || _useMantineContext_stylesTransform === void 0 ? void 0 : _useMantineContext_stylesTransform.sx;
}
function useMantineStylesTransform() {
    var _useMantineContext_stylesTransform;
    return (_useMantineContext_stylesTransform = useMantineContext().stylesTransform) === null || _useMantineContext_stylesTransform === void 0 ? void 0 : _useMantineContext_stylesTransform.styles;
}
function useMantineEnv() {
    return useMantineContext().env || "default";
}
 //# sourceMappingURL=Mantine.context.mjs.map


/***/ }),

/***/ 18512:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   v: () => (/* binding */ getGradient)
/* harmony export */ });
/* harmony import */ var _get_theme_color_get_theme_color_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71180);
/* __next_internal_client_entry_do_not_use__ getGradient auto */ 
function getGradient(gradient, theme) {
    var _gradient_deg, _ref;
    const merged = {
        from: (gradient === null || gradient === void 0 ? void 0 : gradient.from) || theme.defaultGradient.from,
        to: (gradient === null || gradient === void 0 ? void 0 : gradient.to) || theme.defaultGradient.to,
        deg: (_ref = (_gradient_deg = gradient === null || gradient === void 0 ? void 0 : gradient.deg) !== null && _gradient_deg !== void 0 ? _gradient_deg : theme.defaultGradient.deg) !== null && _ref !== void 0 ? _ref : 0
    };
    const fromColor = (0,_get_theme_color_get_theme_color_mjs__WEBPACK_IMPORTED_MODULE_0__/* .getThemeColor */ .r)(merged.from, theme);
    const toColor = (0,_get_theme_color_get_theme_color_mjs__WEBPACK_IMPORTED_MODULE_0__/* .getThemeColor */ .r)(merged.to, theme);
    return "linear-gradient(".concat(merged.deg, "deg, ").concat(fromColor, " 0%, ").concat(toColor, " 100%)");
}
 //# sourceMappingURL=get-gradient.mjs.map


/***/ }),

/***/ 19224:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   H: () => (/* binding */ keys)
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ keys auto */ function keys(object) {
    return Object.keys(object);
}
 //# sourceMappingURL=keys.mjs.map


/***/ }),

/***/ 30128:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   g: () => (/* binding */ getPrimaryShade)
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ getPrimaryShade auto */ function getPrimaryShade(theme, colorScheme) {
    if (typeof theme.primaryShade === "number") {
        return theme.primaryShade;
    }
    if (colorScheme === "dark") {
        return theme.primaryShade.dark;
    }
    return theme.primaryShade.light;
}
 //# sourceMappingURL=get-primary-shade.mjs.map


/***/ }),

/***/ 35695:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony import */ var _client_components_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18999);
/* harmony import */ var _client_components_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_client_components_navigation__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (checked) */ if(__webpack_require__.o(_client_components_navigation__WEBPACK_IMPORTED_MODULE_0__, "redirect")) __webpack_require__.d(__webpack_exports__, { redirect: function() { return _client_components_navigation__WEBPACK_IMPORTED_MODULE_0__.redirect; } });
/* harmony reexport (checked) */ if(__webpack_require__.o(_client_components_navigation__WEBPACK_IMPORTED_MODULE_0__, "useParams")) __webpack_require__.d(__webpack_exports__, { useParams: function() { return _client_components_navigation__WEBPACK_IMPORTED_MODULE_0__.useParams; } });
/* harmony reexport (checked) */ if(__webpack_require__.o(_client_components_navigation__WEBPACK_IMPORTED_MODULE_0__, "usePathname")) __webpack_require__.d(__webpack_exports__, { usePathname: function() { return _client_components_navigation__WEBPACK_IMPORTED_MODULE_0__.usePathname; } });
/* harmony reexport (checked) */ if(__webpack_require__.o(_client_components_navigation__WEBPACK_IMPORTED_MODULE_0__, "useRouter")) __webpack_require__.d(__webpack_exports__, { useRouter: function() { return _client_components_navigation__WEBPACK_IMPORTED_MODULE_0__.useRouter; } });
/* harmony reexport (checked) */ if(__webpack_require__.o(_client_components_navigation__WEBPACK_IMPORTED_MODULE_0__, "useSearchParams")) __webpack_require__.d(__webpack_exports__, { useSearchParams: function() { return _client_components_navigation__WEBPACK_IMPORTED_MODULE_0__.useSearchParams; } });


//# sourceMappingURL=navigation.js.map

/***/ }),

/***/ 38792:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   K: () => (/* binding */ toRgba)
/* harmony export */ });
function isHexColor(hex) {
  const HEX_REGEXP = /^#?([0-9A-F]{3}){1,2}([0-9A-F]{2})?$/i;
  return HEX_REGEXP.test(hex);
}
function hexToRgba(color) {
  let hexString = color.replace("#", "");
  if (hexString.length === 3) {
    const shorthandHex = hexString.split("");
    hexString = [
      shorthandHex[0],
      shorthandHex[0],
      shorthandHex[1],
      shorthandHex[1],
      shorthandHex[2],
      shorthandHex[2]
    ].join("");
  }
  if (hexString.length === 8) {
    const alpha = parseInt(hexString.slice(6, 8), 16) / 255;
    return {
      r: parseInt(hexString.slice(0, 2), 16),
      g: parseInt(hexString.slice(2, 4), 16),
      b: parseInt(hexString.slice(4, 6), 16),
      a: alpha
    };
  }
  const parsed = parseInt(hexString, 16);
  const r = parsed >> 16 & 255;
  const g = parsed >> 8 & 255;
  const b = parsed & 255;
  return {
    r,
    g,
    b,
    a: 1
  };
}
function rgbStringToRgba(color) {
  const [r, g, b, a] = color.replace(/[^0-9,./]/g, "").split(/[/,]/).map(Number);
  return { r, g, b, a: a === void 0 ? 1 : a };
}
function hslStringToRgba(hslaString) {
  const hslaRegex = /^hsla?\(\s*(\d+)\s*,\s*(\d+%)\s*,\s*(\d+%)\s*(,\s*(0?\.\d+|\d+(\.\d+)?))?\s*\)$/i;
  const matches = hslaString.match(hslaRegex);
  if (!matches) {
    return {
      r: 0,
      g: 0,
      b: 0,
      a: 1
    };
  }
  const h = parseInt(matches[1], 10);
  const s = parseInt(matches[2], 10) / 100;
  const l = parseInt(matches[3], 10) / 100;
  const a = matches[5] ? parseFloat(matches[5]) : void 0;
  const chroma = (1 - Math.abs(2 * l - 1)) * s;
  const huePrime = h / 60;
  const x = chroma * (1 - Math.abs(huePrime % 2 - 1));
  const m = l - chroma / 2;
  let r;
  let g;
  let b;
  if (huePrime >= 0 && huePrime < 1) {
    r = chroma;
    g = x;
    b = 0;
  } else if (huePrime >= 1 && huePrime < 2) {
    r = x;
    g = chroma;
    b = 0;
  } else if (huePrime >= 2 && huePrime < 3) {
    r = 0;
    g = chroma;
    b = x;
  } else if (huePrime >= 3 && huePrime < 4) {
    r = 0;
    g = x;
    b = chroma;
  } else if (huePrime >= 4 && huePrime < 5) {
    r = x;
    g = 0;
    b = chroma;
  } else {
    r = chroma;
    g = 0;
    b = x;
  }
  return {
    r: Math.round((r + m) * 255),
    g: Math.round((g + m) * 255),
    b: Math.round((b + m) * 255),
    a: a || 1
  };
}
function toRgba(color) {
  if (isHexColor(color)) {
    return hexToRgba(color);
  }
  if (color.startsWith("rgb")) {
    return rgbStringToRgba(color);
  }
  if (color.startsWith("hsl")) {
    return hslStringToRgba(color);
  }
  return {
    r: 0,
    g: 0,
    b: 0,
    a: 1
  };
}


//# sourceMappingURL=to-rgba.mjs.map


/***/ }),

/***/ 41750:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ deepMerge)
/* harmony export */ });
function isObject(item) {
  return item && typeof item === "object" && !Array.isArray(item);
}
function deepMerge(target, source) {
  const result = { ...target };
  const _source = source;
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach((key) => {
      if (isObject(_source[key])) {
        if (!(key in target)) {
          result[key] = _source[key];
        } else {
          result[key] = deepMerge(result[key], _source[key]);
        }
      } else {
        result[key] = _source[key];
      }
    });
  }
  return result;
}


//# sourceMappingURL=deep-merge.mjs.map


/***/ }),

/***/ 64555:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  S: () => (/* binding */ DEFAULT_THEME)
});

// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/utils/units-converters/rem.mjs
var rem = __webpack_require__(5903);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(12115);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(95155);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/to-rgba/to-rgba.mjs
var to_rgba = __webpack_require__(38792);
;// ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/darken/darken.mjs


function darken(color, alpha) {
  if (color.startsWith("var(")) {
    return `color-mix(in srgb, ${color}, black ${alpha * 100}%)`;
  }
  const { r, g, b, a } = (0,to_rgba/* toRgba */.K)(color);
  const f = 1 - alpha;
  const dark = (input) => Math.round(input * f);
  return `rgba(${dark(r)}, ${dark(g)}, ${dark(b)}, ${a})`;
}


//# sourceMappingURL=darken.mjs.map

// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-gradient/get-gradient.mjs
var get_gradient = __webpack_require__(18512);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/parse-theme-color/parse-theme-color.mjs + 1 modules
var parse_theme_color = __webpack_require__(98271);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/rgba/rgba.mjs
var rgba = __webpack_require__(70714);
;// ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/default-variant-colors-resolver/default-variant-colors-resolver.mjs
/* __next_internal_client_entry_do_not_use__ defaultVariantColorsResolver auto */ 







const defaultVariantColorsResolver = (param)=>{
    let { color, theme, variant, gradient, autoContrast } = param;
    const parsed = (0,parse_theme_color/* parseThemeColor */.g)({
        color,
        theme
    });
    const _autoContrast = typeof autoContrast === "boolean" ? autoContrast : theme.autoContrast;
    if (variant === "none") {
        return {
            background: "transparent",
            hover: "transparent",
            color: "inherit",
            border: "none"
        };
    }
    if (variant === "filled") {
        const textColor = _autoContrast ? parsed.isLight ? "var(--mantine-color-black)" : "var(--mantine-color-white)" : "var(--mantine-color-white)";
        if (parsed.isThemeColor) {
            if (parsed.shade === void 0) {
                return {
                    background: "var(--mantine-color-".concat(color, "-filled)"),
                    hover: "var(--mantine-color-".concat(color, "-filled-hover)"),
                    color: textColor,
                    border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
                };
            }
            return {
                background: "var(--mantine-color-".concat(parsed.color, "-").concat(parsed.shade, ")"),
                hover: "var(--mantine-color-".concat(parsed.color, "-").concat(parsed.shade === 9 ? 8 : parsed.shade + 1, ")"),
                color: textColor,
                border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
            };
        }
        return {
            background: color,
            hover: darken(color, 0.1),
            color: textColor,
            border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
        };
    }
    if (variant === "light") {
        if (parsed.isThemeColor) {
            if (parsed.shade === void 0) {
                return {
                    background: "var(--mantine-color-".concat(color, "-light)"),
                    hover: "var(--mantine-color-".concat(color, "-light-hover)"),
                    color: "var(--mantine-color-".concat(color, "-light-color)"),
                    border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
                };
            }
            const parsedColor = theme.colors[parsed.color][parsed.shade];
            return {
                background: (0,rgba/* rgba */.B)(parsedColor, 0.1),
                hover: (0,rgba/* rgba */.B)(parsedColor, 0.12),
                color: "var(--mantine-color-".concat(parsed.color, "-").concat(Math.min(parsed.shade, 6), ")"),
                border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
            };
        }
        return {
            background: (0,rgba/* rgba */.B)(color, 0.1),
            hover: (0,rgba/* rgba */.B)(color, 0.12),
            color,
            border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
        };
    }
    if (variant === "outline") {
        if (parsed.isThemeColor) {
            if (parsed.shade === void 0) {
                return {
                    background: "transparent",
                    hover: "var(--mantine-color-".concat(color, "-outline-hover)"),
                    color: "var(--mantine-color-".concat(color, "-outline)"),
                    border: "".concat((0,rem/* rem */.D)(1), " solid var(--mantine-color-").concat(color, "-outline)")
                };
            }
            return {
                background: "transparent",
                hover: (0,rgba/* rgba */.B)(theme.colors[parsed.color][parsed.shade], 0.05),
                color: "var(--mantine-color-".concat(parsed.color, "-").concat(parsed.shade, ")"),
                border: "".concat((0,rem/* rem */.D)(1), " solid var(--mantine-color-").concat(parsed.color, "-").concat(parsed.shade, ")")
            };
        }
        return {
            background: "transparent",
            hover: (0,rgba/* rgba */.B)(color, 0.05),
            color,
            border: "".concat((0,rem/* rem */.D)(1), " solid ").concat(color)
        };
    }
    if (variant === "subtle") {
        if (parsed.isThemeColor) {
            if (parsed.shade === void 0) {
                return {
                    background: "transparent",
                    hover: "var(--mantine-color-".concat(color, "-light-hover)"),
                    color: "var(--mantine-color-".concat(color, "-light-color)"),
                    border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
                };
            }
            const parsedColor = theme.colors[parsed.color][parsed.shade];
            return {
                background: "transparent",
                hover: (0,rgba/* rgba */.B)(parsedColor, 0.12),
                color: "var(--mantine-color-".concat(parsed.color, "-").concat(Math.min(parsed.shade, 6), ")"),
                border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
            };
        }
        return {
            background: "transparent",
            hover: (0,rgba/* rgba */.B)(color, 0.12),
            color,
            border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
        };
    }
    if (variant === "transparent") {
        if (parsed.isThemeColor) {
            if (parsed.shade === void 0) {
                return {
                    background: "transparent",
                    hover: "transparent",
                    color: "var(--mantine-color-".concat(color, "-light-color)"),
                    border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
                };
            }
            return {
                background: "transparent",
                hover: "transparent",
                color: "var(--mantine-color-".concat(parsed.color, "-").concat(Math.min(parsed.shade, 6), ")"),
                border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
            };
        }
        return {
            background: "transparent",
            hover: "transparent",
            color,
            border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
        };
    }
    if (variant === "white") {
        if (parsed.isThemeColor) {
            if (parsed.shade === void 0) {
                return {
                    background: "var(--mantine-color-white)",
                    hover: darken(theme.white, 0.01),
                    color: "var(--mantine-color-".concat(color, "-filled)"),
                    border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
                };
            }
            return {
                background: "var(--mantine-color-white)",
                hover: darken(theme.white, 0.01),
                color: "var(--mantine-color-".concat(parsed.color, "-").concat(parsed.shade, ")"),
                border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
            };
        }
        return {
            background: "var(--mantine-color-white)",
            hover: darken(theme.white, 0.01),
            color,
            border: "".concat((0,rem/* rem */.D)(1), " solid transparent")
        };
    }
    if (variant === "gradient") {
        return {
            background: (0,get_gradient/* getGradient */.v)(gradient, theme),
            hover: (0,get_gradient/* getGradient */.v)(gradient, theme),
            color: "var(--mantine-color-white)",
            border: "none"
        };
    }
    if (variant === "default") {
        return {
            background: "var(--mantine-color-default)",
            hover: "var(--mantine-color-default-hover)",
            color: "var(--mantine-color-default-color)",
            border: "".concat((0,rem/* rem */.D)(1), " solid var(--mantine-color-default-border)")
        };
    }
    return {};
};
 //# sourceMappingURL=default-variant-colors-resolver.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/default-colors.mjs
const DEFAULT_COLORS = {
  dark: [
    "#C9C9C9",
    "#b8b8b8",
    "#828282",
    "#696969",
    "#424242",
    "#3b3b3b",
    "#2e2e2e",
    "#242424",
    "#1f1f1f",
    "#141414"
  ],
  gray: [
    "#f8f9fa",
    "#f1f3f5",
    "#e9ecef",
    "#dee2e6",
    "#ced4da",
    "#adb5bd",
    "#868e96",
    "#495057",
    "#343a40",
    "#212529"
  ],
  red: [
    "#fff5f5",
    "#ffe3e3",
    "#ffc9c9",
    "#ffa8a8",
    "#ff8787",
    "#ff6b6b",
    "#fa5252",
    "#f03e3e",
    "#e03131",
    "#c92a2a"
  ],
  pink: [
    "#fff0f6",
    "#ffdeeb",
    "#fcc2d7",
    "#faa2c1",
    "#f783ac",
    "#f06595",
    "#e64980",
    "#d6336c",
    "#c2255c",
    "#a61e4d"
  ],
  grape: [
    "#f8f0fc",
    "#f3d9fa",
    "#eebefa",
    "#e599f7",
    "#da77f2",
    "#cc5de8",
    "#be4bdb",
    "#ae3ec9",
    "#9c36b5",
    "#862e9c"
  ],
  violet: [
    "#f3f0ff",
    "#e5dbff",
    "#d0bfff",
    "#b197fc",
    "#9775fa",
    "#845ef7",
    "#7950f2",
    "#7048e8",
    "#6741d9",
    "#5f3dc4"
  ],
  indigo: [
    "#edf2ff",
    "#dbe4ff",
    "#bac8ff",
    "#91a7ff",
    "#748ffc",
    "#5c7cfa",
    "#4c6ef5",
    "#4263eb",
    "#3b5bdb",
    "#364fc7"
  ],
  blue: [
    "#e7f5ff",
    "#d0ebff",
    "#a5d8ff",
    "#74c0fc",
    "#4dabf7",
    "#339af0",
    "#228be6",
    "#1c7ed6",
    "#1971c2",
    "#1864ab"
  ],
  cyan: [
    "#e3fafc",
    "#c5f6fa",
    "#99e9f2",
    "#66d9e8",
    "#3bc9db",
    "#22b8cf",
    "#15aabf",
    "#1098ad",
    "#0c8599",
    "#0b7285"
  ],
  teal: [
    "#e6fcf5",
    "#c3fae8",
    "#96f2d7",
    "#63e6be",
    "#38d9a9",
    "#20c997",
    "#12b886",
    "#0ca678",
    "#099268",
    "#087f5b"
  ],
  green: [
    "#ebfbee",
    "#d3f9d8",
    "#b2f2bb",
    "#8ce99a",
    "#69db7c",
    "#51cf66",
    "#40c057",
    "#37b24d",
    "#2f9e44",
    "#2b8a3e"
  ],
  lime: [
    "#f4fce3",
    "#e9fac8",
    "#d8f5a2",
    "#c0eb75",
    "#a9e34b",
    "#94d82d",
    "#82c91e",
    "#74b816",
    "#66a80f",
    "#5c940d"
  ],
  yellow: [
    "#fff9db",
    "#fff3bf",
    "#ffec99",
    "#ffe066",
    "#ffd43b",
    "#fcc419",
    "#fab005",
    "#f59f00",
    "#f08c00",
    "#e67700"
  ],
  orange: [
    "#fff4e6",
    "#ffe8cc",
    "#ffd8a8",
    "#ffc078",
    "#ffa94d",
    "#ff922b",
    "#fd7e14",
    "#f76707",
    "#e8590c",
    "#d9480f"
  ]
};


//# sourceMappingURL=default-colors.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/default-theme.mjs







const DEFAULT_FONT_FAMILY = "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial, sans-serif, Apple Color Emoji, Segoe UI Emoji";
const DEFAULT_THEME = {
  scale: 1,
  fontSmoothing: true,
  focusRing: "auto",
  white: "#fff",
  black: "#000",
  colors: DEFAULT_COLORS,
  primaryShade: { light: 6, dark: 8 },
  primaryColor: "blue",
  variantColorResolver: defaultVariantColorsResolver,
  autoContrast: false,
  luminanceThreshold: 0.3,
  fontFamily: DEFAULT_FONT_FAMILY,
  fontFamilyMonospace: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, Courier New, monospace",
  respectReducedMotion: false,
  cursorType: "default",
  defaultGradient: { from: "blue", to: "cyan", deg: 45 },
  defaultRadius: "sm",
  activeClassName: "mantine-active",
  focusClassName: "",
  headings: {
    fontFamily: DEFAULT_FONT_FAMILY,
    fontWeight: "700",
    textWrap: "wrap",
    sizes: {
      h1: { fontSize: (0,rem/* rem */.D)(34), lineHeight: "1.3" },
      h2: { fontSize: (0,rem/* rem */.D)(26), lineHeight: "1.35" },
      h3: { fontSize: (0,rem/* rem */.D)(22), lineHeight: "1.4" },
      h4: { fontSize: (0,rem/* rem */.D)(18), lineHeight: "1.45" },
      h5: { fontSize: (0,rem/* rem */.D)(16), lineHeight: "1.5" },
      h6: { fontSize: (0,rem/* rem */.D)(14), lineHeight: "1.5" }
    }
  },
  fontSizes: {
    xs: (0,rem/* rem */.D)(12),
    sm: (0,rem/* rem */.D)(14),
    md: (0,rem/* rem */.D)(16),
    lg: (0,rem/* rem */.D)(18),
    xl: (0,rem/* rem */.D)(20)
  },
  lineHeights: {
    xs: "1.4",
    sm: "1.45",
    md: "1.55",
    lg: "1.6",
    xl: "1.65"
  },
  radius: {
    xs: (0,rem/* rem */.D)(2),
    sm: (0,rem/* rem */.D)(4),
    md: (0,rem/* rem */.D)(8),
    lg: (0,rem/* rem */.D)(16),
    xl: (0,rem/* rem */.D)(32)
  },
  spacing: {
    xs: (0,rem/* rem */.D)(10),
    sm: (0,rem/* rem */.D)(12),
    md: (0,rem/* rem */.D)(16),
    lg: (0,rem/* rem */.D)(20),
    xl: (0,rem/* rem */.D)(32)
  },
  breakpoints: {
    xs: "36em",
    sm: "48em",
    md: "62em",
    lg: "75em",
    xl: "88em"
  },
  shadows: {
    xs: `0 ${(0,rem/* rem */.D)(1)} ${(0,rem/* rem */.D)(3)} rgba(0, 0, 0, 0.05), 0 ${(0,rem/* rem */.D)(1)} ${(0,rem/* rem */.D)(2)} rgba(0, 0, 0, 0.1)`,
    sm: `0 ${(0,rem/* rem */.D)(1)} ${(0,rem/* rem */.D)(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${(0,rem/* rem */.D)(10)} ${(0,rem/* rem */.D)(
      15
    )} ${(0,rem/* rem */.D)(-5)}, rgba(0, 0, 0, 0.04) 0 ${(0,rem/* rem */.D)(7)} ${(0,rem/* rem */.D)(7)} ${(0,rem/* rem */.D)(-5)}`,
    md: `0 ${(0,rem/* rem */.D)(1)} ${(0,rem/* rem */.D)(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${(0,rem/* rem */.D)(20)} ${(0,rem/* rem */.D)(
      25
    )} ${(0,rem/* rem */.D)(-5)}, rgba(0, 0, 0, 0.04) 0 ${(0,rem/* rem */.D)(10)} ${(0,rem/* rem */.D)(10)} ${(0,rem/* rem */.D)(-5)}`,
    lg: `0 ${(0,rem/* rem */.D)(1)} ${(0,rem/* rem */.D)(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${(0,rem/* rem */.D)(28)} ${(0,rem/* rem */.D)(
      23
    )} ${(0,rem/* rem */.D)(-7)}, rgba(0, 0, 0, 0.04) 0 ${(0,rem/* rem */.D)(12)} ${(0,rem/* rem */.D)(12)} ${(0,rem/* rem */.D)(-7)}`,
    xl: `0 ${(0,rem/* rem */.D)(1)} ${(0,rem/* rem */.D)(3)} rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 0 ${(0,rem/* rem */.D)(36)} ${(0,rem/* rem */.D)(
      28
    )} ${(0,rem/* rem */.D)(-7)}, rgba(0, 0, 0, 0.04) 0 ${(0,rem/* rem */.D)(17)} ${(0,rem/* rem */.D)(17)} ${(0,rem/* rem */.D)(-7)}`
  },
  other: {},
  components: {}
};


//# sourceMappingURL=default-theme.mjs.map


/***/ }),

/***/ 70714:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   B: () => (/* binding */ rgba),
/* harmony export */   X: () => (/* binding */ alpha)
/* harmony export */ });
/* harmony import */ var _to_rgba_to_rgba_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(38792);


function rgba(color, alpha2) {
  if (typeof color !== "string" || alpha2 > 1 || alpha2 < 0) {
    return "rgba(0, 0, 0, 1)";
  }
  if (color.startsWith("var(")) {
    const mixPercentage = (1 - alpha2) * 100;
    return `color-mix(in srgb, ${color}, transparent ${mixPercentage}%)`;
  }
  if (color.startsWith("oklch")) {
    if (color.includes("/")) {
      return color.replace(/\/\s*[\d.]+\s*\)/, `/ ${alpha2})`);
    }
    return color.replace(")", ` / ${alpha2})`);
  }
  const { r, g, b } = (0,_to_rgba_to_rgba_mjs__WEBPACK_IMPORTED_MODULE_0__/* .toRgba */ .K)(color);
  return `rgba(${r}, ${g}, ${b}, ${alpha2})`;
}
const alpha = rgba;


//# sourceMappingURL=rgba.mjs.map


/***/ }),

/***/ 71180:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   r: () => (/* binding */ getThemeColor)
/* harmony export */ });
/* harmony import */ var _parse_theme_color_parse_theme_color_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(98271);
/* __next_internal_client_entry_do_not_use__ getThemeColor auto */ 
function getThemeColor(color, theme) {
    const parsed = (0,_parse_theme_color_parse_theme_color_mjs__WEBPACK_IMPORTED_MODULE_0__/* .parseThemeColor */ .g)({
        color: color || theme.primaryColor,
        theme
    });
    return parsed.variable ? "var(".concat(parsed.variable, ")") : color;
}
 //# sourceMappingURL=get-theme-color.mjs.map


/***/ }),

/***/ 89200:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   g: () => (/* binding */ getPrimaryContrastColor),
/* harmony export */   w: () => (/* binding */ getContrastColor)
/* harmony export */ });
/* harmony import */ var _get_primary_shade_get_primary_shade_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(30128);
/* harmony import */ var _parse_theme_color_parse_theme_color_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(98271);
/* __next_internal_client_entry_do_not_use__ getContrastColor,getPrimaryContrastColor auto */ 

function getContrastColor(param) {
    let { color, theme, autoContrast } = param;
    const _autoContrast = typeof autoContrast === "boolean" ? autoContrast : theme.autoContrast;
    if (!_autoContrast) {
        return "var(--mantine-color-white)";
    }
    const parsed = (0,_parse_theme_color_parse_theme_color_mjs__WEBPACK_IMPORTED_MODULE_0__/* .parseThemeColor */ .g)({
        color: color || theme.primaryColor,
        theme
    });
    return parsed.isLight ? "var(--mantine-color-black)" : "var(--mantine-color-white)";
}
function getPrimaryContrastColor(theme, colorScheme) {
    return getContrastColor({
        color: theme.colors[theme.primaryColor][(0,_get_primary_shade_get_primary_shade_mjs__WEBPACK_IMPORTED_MODULE_1__/* .getPrimaryShade */ .g)(theme, colorScheme)],
        theme,
        autoContrast: null
    });
}
 //# sourceMappingURL=get-contrast-color.mjs.map


/***/ }),

/***/ 98271:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  g: () => (/* binding */ parseThemeColor)
});

// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/get-primary-shade/get-primary-shade.mjs
var get_primary_shade = __webpack_require__(30128);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/to-rgba/to-rgba.mjs
var to_rgba = __webpack_require__(38792);
;// ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/luminance/luminance.mjs


function gammaCorrect(c) {
  return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
}
function getLightnessFromOklch(oklchColor) {
  const match = oklchColor.match(/oklch\((.*?)%\s/);
  return match ? parseFloat(match[1]) : null;
}
function luminance(color) {
  if (color.startsWith("oklch(")) {
    return (getLightnessFromOklch(color) || 0) / 100;
  }
  const { r, g, b } = (0,to_rgba/* toRgba */.K)(color);
  const sR = r / 255;
  const sG = g / 255;
  const sB = b / 255;
  const rLinear = gammaCorrect(sR);
  const gLinear = gammaCorrect(sG);
  const bLinear = gammaCorrect(sB);
  return 0.2126 * rLinear + 0.7152 * gLinear + 0.0722 * bLinear;
}
function isLightColor(color, luminanceThreshold = 0.179) {
  if (color.startsWith("var(")) {
    return false;
  }
  return luminance(color) > luminanceThreshold;
}


//# sourceMappingURL=luminance.mjs.map

;// ./node_modules/@mantine/core/esm/core/MantineProvider/color-functions/parse-theme-color/parse-theme-color.mjs
/* __next_internal_client_entry_do_not_use__ parseThemeColor auto */ 

function parseThemeColor(param) {
    let { color, theme, colorScheme } = param;
    if (typeof color !== "string") {
        throw new Error("[@mantine/core] Failed to parse color. Expected color to be a string, instead got ".concat(typeof color));
    }
    if (color === "bright") {
        return {
            color,
            value: colorScheme === "dark" ? theme.white : theme.black,
            shade: void 0,
            isThemeColor: false,
            isLight: isLightColor(colorScheme === "dark" ? theme.white : theme.black, theme.luminanceThreshold),
            variable: "--mantine-color-bright"
        };
    }
    if (color === "dimmed") {
        return {
            color,
            value: colorScheme === "dark" ? theme.colors.dark[2] : theme.colors.gray[7],
            shade: void 0,
            isThemeColor: false,
            isLight: isLightColor(colorScheme === "dark" ? theme.colors.dark[2] : theme.colors.gray[6], theme.luminanceThreshold),
            variable: "--mantine-color-dimmed"
        };
    }
    if (color === "white" || color === "black") {
        return {
            color,
            value: color === "white" ? theme.white : theme.black,
            shade: void 0,
            isThemeColor: false,
            isLight: isLightColor(color === "white" ? theme.white : theme.black, theme.luminanceThreshold),
            variable: "--mantine-color-".concat(color)
        };
    }
    const [_color, shade] = color.split(".");
    const colorShade = shade ? Number(shade) : void 0;
    const isThemeColor = _color in theme.colors;
    if (isThemeColor) {
        const colorValue = colorShade !== void 0 ? theme.colors[_color][colorShade] : theme.colors[_color][(0,get_primary_shade/* getPrimaryShade */.g)(theme, colorScheme || "light")];
        return {
            color: _color,
            value: colorValue,
            shade: colorShade,
            isThemeColor,
            isLight: isLightColor(colorValue, theme.luminanceThreshold),
            variable: shade ? "--mantine-color-".concat(_color, "-").concat(colorShade) : "--mantine-color-".concat(_color, "-filled")
        };
    }
    return {
        color,
        value: color,
        isThemeColor,
        isLight: isLightColor(color, theme.luminanceThreshold),
        shade: colorShade,
        variable: void 0
    };
}
 //# sourceMappingURL=parse-theme-color.mjs.map


/***/ })

}]);