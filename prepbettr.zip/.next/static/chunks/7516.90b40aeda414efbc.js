"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[7516],{

/***/ 27516:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   KBtn: () => (/* binding */ KBtn),
/* harmony export */   Keypad: () => (/* binding */ Keypad),
/* harmony export */   Lid: () => (/* binding */ Lid),
/* harmony export */   MacbookScroll: () => (/* binding */ MacbookScroll),
/* harmony export */   OptionKey: () => (/* binding */ OptionKey),
/* harmony export */   SpeakerGrid: () => (/* binding */ SpeakerGrid),
/* harmony export */   Trackpad: () => (/* binding */ Trackpad)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12115);
/* harmony import */ var motion_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(62720);
/* harmony import */ var motion_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(52681);
/* harmony import */ var motion_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(92236);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36680);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(26202);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(70581);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(49999);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(89243);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4168);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(27920);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(62414);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(22980);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(30282);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5523);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8293);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(33601);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(10353);
/* harmony import */ var _barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(80594);
/* harmony import */ var _barrel_optimize_names_IconSearch_tabler_icons_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(22439);
/* harmony import */ var _barrel_optimize_names_IconWorld_tabler_icons_react__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(51119);
/* harmony import */ var _barrel_optimize_names_IconCommand_tabler_icons_react__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(31808);
/* harmony import */ var _barrel_optimize_names_IconCaretLeftFilled_tabler_icons_react__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(10413);
/* harmony import */ var _barrel_optimize_names_IconCaretDownFilled_tabler_icons_react__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(73074);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(66766);
/* __next_internal_client_entry_do_not_use__ MacbookScroll,Lid,Trackpad,Keypad,KBtn,SpeakerGrid,OptionKey auto */ 










const MacbookScroll = (param)=>{
    let { src, showGradient, title, badge } = param;
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { scrollYProgress } = (0,motion_react__WEBPACK_IMPORTED_MODULE_4__/* .useScroll */ .L)({
        target: ref,
        offset: [
            "start start",
            "end start"
        ]
    });
    const [isMobile, setIsMobile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (window && window.innerWidth < 768) {
            setIsMobile(true);
        }
    }, []);
    const scaleX = (0,motion_react__WEBPACK_IMPORTED_MODULE_5__/* .useTransform */ .G)(scrollYProgress, [
        0,
        0.3
    ], [
        1.2,
        isMobile ? 1 : 1.5
    ]);
    const scaleY = (0,motion_react__WEBPACK_IMPORTED_MODULE_5__/* .useTransform */ .G)(scrollYProgress, [
        0,
        0.3
    ], [
        0.6,
        isMobile ? 1 : 1.5
    ]);
    const translate = (0,motion_react__WEBPACK_IMPORTED_MODULE_5__/* .useTransform */ .G)(scrollYProgress, [
        0,
        1
    ], [
        0,
        1500
    ]);
    const rotate = (0,motion_react__WEBPACK_IMPORTED_MODULE_5__/* .useTransform */ .G)(scrollYProgress, [
        0.1,
        0.12,
        0.3
    ], [
        -28,
        -28,
        0
    ]);
    const textTransform = (0,motion_react__WEBPACK_IMPORTED_MODULE_5__/* .useTransform */ .G)(scrollYProgress, [
        0,
        0.3
    ], [
        0,
        100
    ]);
    const textOpacity = (0,motion_react__WEBPACK_IMPORTED_MODULE_5__/* .useTransform */ .G)(scrollYProgress, [
        0,
        0.2
    ], [
        1,
        0
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "relative z-0",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            ref: ref,
            className: "relative z-0 flex min-h-[100vh] shrink-0 scale-[0.35] transform flex-col items-center justify-start pb-[80vh] [perspective:800px] sm:scale-50 md:scale-100",
            style: {
                isolation: 'isolate'
            },
            children: [
                title && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(motion_react__WEBPACK_IMPORTED_MODULE_6__/* .motion */ .P.h2, {
                    style: {
                        translateY: textTransform,
                        opacity: textOpacity
                    },
                    className: "mb-10 text-center text-3xl font-bold text-neutral-800 dark:text-white",
                    children: title
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Lid, {
                    src: src,
                    scaleX: scaleX,
                    scaleY: scaleY,
                    rotate: rotate,
                    translate: translate
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative -z-10 h-[22rem] w-[32rem] overflow-hidden rounded-2xl bg-gray-200 dark:bg-[#272729]",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "relative h-10 w-full",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "absolute inset-x-0 mx-auto h-4 w-[80%] bg-[#050505]"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative flex",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "mx-auto h-full w-[10%] overflow-hidden",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SpeakerGrid, {})
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "mx-auto h-full w-[80%]",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Keypad, {})
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "mx-auto h-full w-[10%] overflow-hidden",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SpeakerGrid, {})
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Trackpad, {}),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "absolute inset-x-0 bottom-0 mx-auto h-2 w-20 rounded-tl-3xl rounded-tr-3xl bg-gradient-to-t from-[#272729] to-[#050505]"
                        }),
                        showGradient && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "absolute inset-x-0 bottom-0 z-50 h-40 w-full bg-gradient-to-t from-white via-white to-transparent dark:from-black dark:via-black"
                        }),
                        badge && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "absolute bottom-4 left-4",
                            children: badge
                        })
                    ]
                })
            ]
        })
    });
};
const Lid = (param)=>{
    let { scaleX, scaleY, rotate, translate, src } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative [perspective:800px]",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                style: {
                    transform: "perspective(800px) rotateX(-25deg) translateZ(0px)",
                    transformOrigin: "bottom",
                    transformStyle: "preserve-3d"
                },
                className: "relative h-[12rem] w-[32rem] rounded-2xl bg-[#010101] p-2",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    style: {
                        boxShadow: "0px 2px 0px 2px #171717 inset"
                    },
                    className: "absolute inset-0 flex items-center justify-center rounded-lg bg-[#010101]",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                        className: "text-white",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(AceternityLogo, {})
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(motion_react__WEBPACK_IMPORTED_MODULE_6__/* .motion */ .P.div, {
                style: {
                    scaleX: scaleX,
                    scaleY: scaleY,
                    rotateX: rotate,
                    translateY: translate,
                    transformStyle: "preserve-3d",
                    transformOrigin: "top"
                },
                className: "absolute inset-0 h-96 w-[32rem] rounded-2xl bg-[#010101] p-2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "absolute inset-0 rounded-lg bg-[#272729]"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                        src: src,
                        alt: "aceternity logo",
                        className: "absolute inset-0 h-full w-full rounded-lg object-cover object-left-top",
                        fill: true,
                        priority: true
                    })
                ]
            })
        ]
    });
};
const Trackpad = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "mx-auto my-1 h-32 w-[40%] rounded-xl",
        style: {
            boxShadow: "0px 0px 1px 1px #00000020 inset"
        }
    });
};
const Keypad = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mx-1 h-full [transform:translateZ(0)] rounded-md bg-[#050505] p-1 [will-change:transform]",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-[2px] flex w-full shrink-0 gap-[2px]",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        className: "w-10 items-end justify-start pb-[2px] pl-[4px]",
                        childrenClassName: "items-start",
                        children: "esc"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F1"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F2"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F3"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconSearch_tabler_icons_react__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F4"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F5"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F6"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F7"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F8"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F8"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F10"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F11"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .A, {
                                className: "h-[6px] w-[6px]"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 inline-block",
                                children: "F12"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "h-4 w-4 rounded-full bg-gradient-to-b from-neutral-900 from-20% via-black via-50% to-neutral-900 to-95% p-px",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "h-full w-full rounded-full bg-black"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-[2px] flex w-full shrink-0 gap-[2px]",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "~"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "mt-1 block",
                                children: "`"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "!"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "1"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "@"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "2"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "#"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "3"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "$"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "4"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "%"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "5"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "^"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "6"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "&"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "7"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "*"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "8"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "("
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "9"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: ")"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "0"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "—"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "_"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "+"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: " = "
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        className: "w-10 items-end justify-end pr-[4px] pb-[2px]",
                        childrenClassName: "items-end",
                        children: "delete"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-[2px] flex w-full shrink-0 gap-[2px]",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        className: "w-10 items-end justify-start pb-[2px] pl-[4px]",
                        childrenClassName: "items-start",
                        children: "tab"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "Q"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "W"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "E"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "R"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "T"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "Y"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "U"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "I"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "O"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "P"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "{"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "["
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "}"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "]"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "|"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "\\"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-[2px] flex w-full shrink-0 gap-[2px]",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        className: "w-[2.8rem] items-end justify-start pb-[2px] pl-[4px]",
                        childrenClassName: "items-start",
                        children: "caps lock"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "A"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "S"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "D"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "F"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "G"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "H"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "J"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "K"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "L"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: ":"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: ";"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: '"'
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "'"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        className: "w-[2.85rem] items-end justify-end pr-[4px] pb-[2px]",
                        childrenClassName: "items-end",
                        children: "return"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-[2px] flex w-full shrink-0 gap-[2px]",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        className: "w-[3.65rem] items-end justify-start pb-[2px] pl-[4px]",
                        childrenClassName: "items-start",
                        children: "shift"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "Z"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "X"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "C"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "V"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "B"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "N"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "block",
                            children: "M"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "<"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: ","
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: ">"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "?"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                className: "block",
                                children: "/"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        className: "w-[3.65rem] items-end justify-end pr-[4px] pb-[2px]",
                        childrenClassName: "items-end",
                        children: "shift"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-[2px] flex w-full shrink-0 gap-[2px]",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        className: "",
                        childrenClassName: "h-full justify-between py-[4px]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-end pr-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    className: "block",
                                    children: "fn"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-start pl-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconWorld_tabler_icons_react__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .A, {
                                    className: "h-[6px] w-[6px]"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        className: "",
                        childrenClassName: "h-full justify-between py-[4px]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-end pr-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .A, {
                                    className: "h-[6px] w-[6px]"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-start pl-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    className: "block",
                                    children: "control"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        className: "",
                        childrenClassName: "h-full justify-between py-[4px]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-end pr-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(OptionKey, {
                                    className: "h-[6px] w-[6px]"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-start pl-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    className: "block",
                                    children: "option"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        className: "w-8",
                        childrenClassName: "h-full justify-between py-[4px]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-end pr-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconCommand_tabler_icons_react__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .A, {
                                    className: "h-[6px] w-[6px]"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-start pl-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    className: "block",
                                    children: "command"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                        className: "w-[8.2rem]"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        className: "w-8",
                        childrenClassName: "h-full justify-between py-[4px]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-start pl-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconCommand_tabler_icons_react__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .A, {
                                    className: "h-[6px] w-[6px]"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-start pl-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    className: "block",
                                    children: "command"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(KBtn, {
                        className: "",
                        childrenClassName: "h-full justify-between py-[4px]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-start pl-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(OptionKey, {
                                    className: "h-[6px] w-[6px]"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "flex w-full justify-start pl-1",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    className: "block",
                                    children: "option"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-[2px] flex h-6 w-[4.9rem] flex-col items-center justify-end rounded-[4px] p-[0.5px]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                                className: "h-3 w-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .A, {
                                    className: "h-[6px] w-[6px]"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                                        className: "h-3 w-6",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconCaretLeftFilled_tabler_icons_react__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .A, {
                                            className: "h-[6px] w-[6px]"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                                        className: "h-3 w-6",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconCaretDownFilled_tabler_icons_react__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .A, {
                                            className: "h-[6px] w-[6px]"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(KBtn, {
                                        className: "h-3 w-6",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_IconBrightnessDown_IconBrightnessUp_IconCaretRightFilled_IconCaretUpFilled_IconChevronUp_IconMicrophone_IconMoon_IconPlayerSkipForward_IconPlayerTrackNext_IconPlayerTrackPrev_IconTable_IconVolume_IconVolume2_IconVolume3_tabler_icons_react__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .A, {
                                            className: "h-[6px] w-[6px]"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
const KBtn = (param)=>{
    let { className, children, childrenClassName, backlit = true } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("[transform:translateZ(0)] rounded-[4px] p-[0.5px] [will-change:transform]", backlit && "bg-white/[0.2] shadow-xl shadow-white"),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex h-6 w-6 items-center justify-center rounded-[3.5px] bg-[#0A090D]", className),
            style: {
                boxShadow: "0px -0.5px 2px 0 #0D0D0F inset, -0.5px 0px 2px 0 #0D0D0F inset"
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex w-full flex-col items-center justify-center text-[5px] text-neutral-200", childrenClassName, backlit && "text-white"),
                children: children
            })
        })
    });
};
const SpeakerGrid = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "mt-2 flex h-40 gap-[2px] px-[0.5px]",
        style: {
            backgroundImage: "radial-gradient(circle, #08080A 0.5px, transparent 0.5px)",
            backgroundSize: "3px 3px"
        }
    });
};
const OptionKey = (param)=>{
    let { className } = param;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        fill: "none",
        version: "1.1",
        id: "icon",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 32 32",
        className: className,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                stroke: "currentColor",
                strokeWidth: 2,
                x: "18",
                y: "5",
                width: "10",
                height: "2"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("polygon", {
                stroke: "currentColor",
                strokeWidth: 2,
                points: "10.6,5 4,5 4,7 9.4,7 18.4,27 28,27 28,25 19.6,25 "
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                id: "_Transparent_Rectangle_",
                className: "st0",
                width: "32",
                height: "32",
                stroke: "none"
            })
        ]
    });
};
const AceternityLogo = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", {
        width: "66",
        height: "65",
        viewBox: "0 0 66 65",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: "h-3 w-3 text-white",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
            d: "M8 8.05571C8 8.05571 54.9009 18.1782 57.8687 30.062C60.8365 41.9458 9.05432 57.4696 9.05432 57.4696",
            stroke: "currentColor",
            strokeWidth: "15",
            strokeMiterlimit: "3.86874",
            strokeLinecap: "round"
        })
    });
};


/***/ })

}]);