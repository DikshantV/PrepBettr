"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[809],{

/***/ 20809:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95155);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(66766);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(92236);
/* __next_internal_client_entry_do_not_use__ default auto */ 


// Import all logos
const logos = [
    {
        src: "/brand_slide/logo_airbnb.svg",
        alt: "Airbnb"
    },
    {
        src: "/brand_slide/logo_amazon.svg",
        alt: "Amazon"
    },
    {
        src: "/brand_slide/logo_anthropic.svg",
        alt: "Anthropic"
    },
    {
        src: "/brand_slide/logo_canva.svg",
        alt: "Canva"
    },
    {
        src: "/brand_slide/logo_citi.svg",
        alt: "Citi"
    },
    {
        src: "/brand_slide/logo_fedex.svg",
        alt: "FedEx"
    },
    {
        src: "/brand_slide/logo_github.svg",
        alt: "GitHub"
    },
    {
        src: "/brand_slide/logo_google.svg",
        alt: "Google"
    },
    {
        src: "/brand_slide/logo_meta.svg",
        alt: "Meta"
    },
    {
        src: "/brand_slide/logo_microsoft.svg",
        alt: "Microsoft"
    },
    {
        src: "/brand_slide/logo_shopify.svg",
        alt: "Shopify"
    },
    {
        src: "/brand_slide/logo_steam.svg",
        alt: "Steam"
    },
    {
        src: "/brand_slide/logo_tesla.svg",
        alt: "Tesla"
    },
    {
        src: "/brand_slide/logo_twitch.svg",
        alt: "Twitch"
    },
    {
        src: "/brand_slide/logo_ups.svg",
        alt: "UPS"
    },
    {
        src: "/brand_slide/logo_redis.svg",
        alt: "Redis"
    },
    {
        src: "/brand_slide/logo_uber.svg",
        alt: "Uber"
    },
    {
        src: "/brand_slide/logo_walmart.svg",
        alt: "Walmart"
    }
];
const BrandSlide = ()=>{
    // Duplicate the logos array to create a seamless loop
    const duplicatedLogos = [
        ...logos,
        ...logos,
        ...logos
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "py-12 bg-black",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "relative w-full overflow-hidden",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion */ .P.div, {
                className: "flex items-center",
                animate: {
                    x: [
                        0,
                        -1000
                    ]
                },
                transition: {
                    duration: 30,
                    repeat: Infinity,
                    ease: "linear"
                },
                children: duplicatedLogos.map((logo, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "mx-12 flex-shrink-0",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            src: logo.src,
                            alt: logo.alt,
                            width: 120,
                            height: 48,
                            className: "h-12 w-auto object-contain",
                            priority: index < 6
                        })
                    }, "".concat(logo.alt, "-").concat(index)))
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BrandSlide);


/***/ })

}]);