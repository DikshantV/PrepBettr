globalThis.__BUILD_MANIFEST = {
  "polyfillFiles": [
    "static/chunks/polyfills-42372ed130431b0a.js"
  ],
  "devFiles": [],
  "ampDevFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/webpack-fabb64c19f63cd9d.js",
    "static/chunks/4bd1b696-7919cc10b30cba0f.js",
    "static/chunks/1684-cec91fabe86a162d.js",
    "static/chunks/main-app-ff57abdeee66d1db.js"
  ],
  "rootMainFilesTree": {},
  "pages": {
    "/_app": [
      "static/chunks/webpack-fabb64c19f63cd9d.js",
      "static/chunks/framework-2c2be674e67eda3d.js",
      "static/chunks/main-419f5f482e1b221b.js",
      "static/chunks/pages/_app-5d1abe03d322390c.js"
    ],
    "/_error": [
      "static/chunks/webpack-fabb64c19f63cd9d.js",
      "static/chunks/framework-2c2be674e67eda3d.js",
      "static/chunks/main-419f5f482e1b221b.js",
      "static/chunks/pages/_error-3b2a1d523de49635.js"
    ]
  },
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];