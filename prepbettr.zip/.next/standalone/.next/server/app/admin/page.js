(() => {
var exports = {};
exports.id = 3698;
exports.ids = [3698];
exports.modules = {

/***/ 1375:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49441));


/***/ }),

/***/ 3018:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fc: () => (/* binding */ Alert),
/* harmony export */   TN: () => (/* binding */ AlertDescription)
/* harmony export */ });
/* unused harmony export AlertTitle */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24224);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);




const alertVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("relative w-full rounded-lg border p-4 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7", {
    variants: {
        variant: {
            default: "bg-background text-foreground",
            destructive: "border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
const Alert = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, variant, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        role: "alert",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(alertVariants({
            variant
        }), className),
        ...props
    }));
Alert.displayName = "Alert";
const AlertTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h5", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("mb-1 font-medium leading-none tracking-tight", className),
        ...props
    }));
AlertTitle.displayName = "AlertTitle";
const AlertDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-sm [&_p]:leading-relaxed", className),
        ...props
    }));
AlertDescription.displayName = "AlertDescription";



/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 4363:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AQ: () => (/* binding */ __asyncGenerator),
/* harmony export */   Cl: () => (/* binding */ __assign),
/* harmony export */   N3: () => (/* binding */ __await),
/* harmony export */   Tt: () => (/* binding */ __rest),
/* harmony export */   fX: () => (/* binding */ __spreadArray),
/* harmony export */   xN: () => (/* binding */ __asyncValues)
/* harmony export */ });
/* unused harmony exports __extends, __decorate, __param, __esDecorate, __runInitializers, __propKey, __setFunctionName, __metadata, __awaiter, __generator, __createBinding, __exportStar, __values, __read, __spread, __spreadArrays, __asyncDelegator, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet, __classPrivateFieldIn, __addDisposableResource, __disposeResources, __rewriteRelativeImportExtension */
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol, Iterator */

var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf ||
      ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
      function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
  return extendStatics(d, b);
};

function __extends(d, b) {
  if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
  extendStatics(d, b);
  function __() { this.constructor = d; }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
  __assign = Object.assign || function __assign(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
  }
  return __assign.apply(this, arguments);
}

function __rest(s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
      t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function")
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
          if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
              t[p[i]] = s[p[i]];
      }
  return t;
}

function __decorate(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
  return function (target, key) { decorator(target, key, paramIndex); }
}

function __esDecorate(ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
  function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
  var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
  var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
  var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
  var _, done = false;
  for (var i = decorators.length - 1; i >= 0; i--) {
      var context = {};
      for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
      for (var p in contextIn.access) context.access[p] = contextIn.access[p];
      context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
      var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
      if (kind === "accessor") {
          if (result === void 0) continue;
          if (result === null || typeof result !== "object") throw new TypeError("Object expected");
          if (_ = accept(result.get)) descriptor.get = _;
          if (_ = accept(result.set)) descriptor.set = _;
          if (_ = accept(result.init)) initializers.unshift(_);
      }
      else if (_ = accept(result)) {
          if (kind === "field") initializers.unshift(_);
          else descriptor[key] = _;
      }
  }
  if (target) Object.defineProperty(target, contextIn.name, descriptor);
  done = true;
};

function __runInitializers(thisArg, initializers, value) {
  var useValue = arguments.length > 2;
  for (var i = 0; i < initializers.length; i++) {
      value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
  }
  return useValue ? value : void 0;
};

function __propKey(x) {
  return typeof x === "symbol" ? x : "".concat(x);
};

function __setFunctionName(f, name, prefix) {
  if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
  return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};

function __metadata(metadataKey, metadataValue) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
  function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
  return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
      function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
      function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}

function __generator(thisArg, body) {
  var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
  return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
  function verb(n) { return function (v) { return step([n, v]); }; }
  function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];
          switch (op[0]) {
              case 0: case 1: t = op; break;
              case 4: _.label++; return { value: op[1], done: false };
              case 5: _.label++; y = op[1]; op = [0]; continue;
              case 7: op = _.ops.pop(); _.trys.pop(); continue;
              default:
                  if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                  if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                  if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                  if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                  if (t[2]) _.ops.pop();
                  _.trys.pop(); continue;
          }
          op = body.call(thisArg, _);
      } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
      if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
  }
}

var __createBinding = Object.create ? (function(o, m, k, k2) {
  if (k2 === undefined) k2 = k;
  var desc = Object.getOwnPropertyDescriptor(m, k);
  if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
  }
  Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
  if (k2 === undefined) k2 = k;
  o[k2] = m[k];
});

function __exportStar(m, o) {
  for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}

function __values(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m) return m.call(o);
  if (o && typeof o.length === "number") return {
      next: function () {
          if (o && i >= o.length) o = void 0;
          return { value: o && o[i++], done: !o };
      }
  };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
      while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  }
  catch (error) { e = { error: error }; }
  finally {
      try {
          if (r && !r.done && (m = i["return"])) m.call(i);
      }
      finally { if (e) throw e.error; }
  }
  return ar;
}

/** @deprecated */
function __spread() {
  for (var ar = [], i = 0; i < arguments.length; i++)
      ar = ar.concat(__read(arguments[i]));
  return ar;
}

/** @deprecated */
function __spreadArrays() {
  for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
  for (var r = Array(s), k = 0, i = 0; i < il; i++)
      for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
          r[k] = a[j];
  return r;
}

function __spreadArray(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
      }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
}

function __await(v) {
  return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var g = generator.apply(thisArg, _arguments || []), i, q = [];
  return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
  function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
  function verb(n, f) { if (g[n]) { i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; if (f) i[n] = f(i[n]); } }
  function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
  function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
  function fulfill(value) { resume("next", value); }
  function reject(value) { resume("throw", value); }
  function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
  var i, p;
  return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
  function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: false } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var m = o[Symbol.asyncIterator], i;
  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
  function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
  function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
  if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
  return cooked;
};

var __setModuleDefault = Object.create ? (function(o, v) {
  Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
  o["default"] = v;
};

var ownKeys = function(o) {
  ownKeys = Object.getOwnPropertyNames || function (o) {
    var ar = [];
    for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
    return ar;
  };
  return ownKeys(o);
};

function __importStar(mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
  __setModuleDefault(result, mod);
  return result;
}

function __importDefault(mod) {
  return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, state, kind, f) {
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}

function __classPrivateFieldSet(receiver, state, value, kind, f) {
  if (kind === "m") throw new TypeError("Private method is not writable");
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
}

function __classPrivateFieldIn(state, receiver) {
  if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function")) throw new TypeError("Cannot use 'in' operator on non-object");
  return typeof state === "function" ? receiver === state : state.has(receiver);
}

function __addDisposableResource(env, value, async) {
  if (value !== null && value !== void 0) {
    if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
    var dispose, inner;
    if (async) {
      if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
      dispose = value[Symbol.asyncDispose];
    }
    if (dispose === void 0) {
      if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
      dispose = value[Symbol.dispose];
      if (async) inner = dispose;
    }
    if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
    if (inner) dispose = function() { try { inner.call(this); } catch (e) { return Promise.reject(e); } };
    env.stack.push({ value: value, dispose: dispose, async: async });
  }
  else if (async) {
    env.stack.push({ async: true });
  }
  return value;
}

var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
  var e = new Error(message);
  return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

function __disposeResources(env) {
  function fail(e) {
    env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
    env.hasError = true;
  }
  var r, s = 0;
  function next() {
    while (r = env.stack.pop()) {
      try {
        if (!r.async && s === 1) return s = 0, env.stack.push(r), Promise.resolve().then(next);
        if (r.dispose) {
          var result = r.dispose.call(r.value);
          if (r.async) return s |= 2, Promise.resolve(result).then(next, function(e) { fail(e); return next(); });
        }
        else s |= 1;
      }
      catch (e) {
        fail(e);
      }
    }
    if (s === 1) return env.hasError ? Promise.reject(env.error) : Promise.resolve();
    if (env.hasError) throw env.error;
  }
  return next();
}

function __rewriteRelativeImportExtension(path, preserveJsx) {
  if (typeof path === "string" && /^\.\.?\//.test(path)) {
      return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
          return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
      });
  }
  return path;
}

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
  __extends,
  __assign,
  __rest,
  __decorate,
  __param,
  __esDecorate,
  __runInitializers,
  __propKey,
  __setFunctionName,
  __metadata,
  __awaiter,
  __generator,
  __createBinding,
  __exportStar,
  __values,
  __read,
  __spread,
  __spreadArrays,
  __spreadArray,
  __await,
  __asyncGenerator,
  __asyncDelegator,
  __asyncValues,
  __makeTemplateObject,
  __importStar,
  __importDefault,
  __classPrivateFieldGet,
  __classPrivateFieldSet,
  __classPrivateFieldIn,
  __addDisposableResource,
  __disposeResources,
  __rewriteRelativeImportExtension,
});


/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 19121:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/action-async-storage.external.js");

/***/ }),

/***/ 19771:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 21820:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 21857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AdminDashboard)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js
var react_jsx_runtime = __webpack_require__(60687);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./components/ui/card.tsx
var card = __webpack_require__(55192);
// EXTERNAL MODULE: ./node_modules/class-variance-authority/dist/index.mjs
var dist = __webpack_require__(24224);
// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(57048);
;// ./components/ui/badge.tsx




const badgeVariants = (0,dist/* cva */.F)("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
            secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
            destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
            outline: "text-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, ...props }) {
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
        className: (0,utils.cn)(badgeVariants({
            variant
        }), className),
        ...props
    });
}


;// ./components/ui/progress.tsx
/* __next_internal_client_entry_do_not_use__ Progress auto */ 


const Progress = /*#__PURE__*/ react.forwardRef(({ className, value, indicatorClassName, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
        ref: ref,
        className: (0,utils.cn)("relative h-4 w-full overflow-hidden rounded-full bg-secondary", className),
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
            className: (0,utils.cn)("h-full w-full flex-1 bg-primary transition-all", indicatorClassName),
            style: {
                transform: `translateX(-${100 - (value || 0)}%)`
            }
        })
    }));
Progress.displayName = "Progress";


// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/createLucideIcon.js + 3 modules
var createLucideIcon = __webpack_require__(62688);
;// ./node_modules/lucide-react/dist/esm/icons/dollar-sign.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "line",
        {
            x1: "12",
            x2: "12",
            y1: "2",
            y2: "22",
            key: "7eqyqh"
        }
    ],
    [
        "path",
        {
            d: "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
            key: "1b0p4s"
        }
    ]
];
const DollarSign = (0,createLucideIcon/* default */.A)("dollar-sign", __iconNode);
 //# sourceMappingURL=dollar-sign.js.map

// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/users.js
var users = __webpack_require__(41312);
;// ./node_modules/lucide-react/dist/esm/icons/trending-down.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const trending_down_iconNode = [
    [
        "polyline",
        {
            points: "22 17 13.5 8.5 8.5 13.5 2 7",
            key: "1r2t7k"
        }
    ],
    [
        "polyline",
        {
            points: "16 17 22 17 22 11",
            key: "11uiuu"
        }
    ]
];
const TrendingDown = (0,createLucideIcon/* default */.A)("trending-down", trending_down_iconNode);
 //# sourceMappingURL=trending-down.js.map

;// ./node_modules/lucide-react/dist/esm/icons/activity.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const activity_iconNode = [
    [
        "path",
        {
            d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
            key: "169zse"
        }
    ]
];
const Activity = (0,createLucideIcon/* default */.A)("activity", activity_iconNode);
 //# sourceMappingURL=activity.js.map

;// ./components/admin/analytics-charts.tsx
/* __next_internal_client_entry_do_not_use__ AnalyticsCharts auto */ 




function AnalyticsCharts({ data }) {
    const maxRevenue = Math.max(...data.revenue.byDay.map((d)=>d.amount), 1);
    const premiumPercentage = data.subscriptions.byPlan.premium / data.subscriptions.byPlan.total * 100;
    const freePercentage = data.subscriptions.byPlan.free / data.subscriptions.byPlan.total * 100;
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
        className: "grid gap-6 md:grid-cols-2 lg:grid-cols-4",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        className: "flex flex-row items-center justify-between space-y-0 pb-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                className: "text-sm font-medium",
                                children: "Total Revenue"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(DollarSign, {
                                className: "h-4 w-4 text-muted-foreground"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "text-2xl font-bold",
                                children: [
                                    "$",
                                    data.revenue.total.toFixed(2)
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("p", {
                                className: "text-xs text-muted-foreground",
                                children: [
                                    "Last ",
                                    data.period.days,
                                    " days"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        className: "flex flex-row items-center justify-between space-y-0 pb-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                className: "text-sm font-medium",
                                children: "Total Users"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(users/* default */.A, {
                                className: "h-4 w-4 text-muted-foreground"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                className: "text-2xl font-bold",
                                children: data.subscriptions.byPlan.total
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("p", {
                                className: "text-xs text-muted-foreground",
                                children: [
                                    "+",
                                    data.userGrowth.total,
                                    " this period"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        className: "flex flex-row items-center justify-between space-y-0 pb-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                className: "text-sm font-medium",
                                children: "Churn Rate"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(TrendingDown, {
                                className: "h-4 w-4 text-muted-foreground"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "text-2xl font-bold",
                                children: [
                                    data.churn.rate.toFixed(1),
                                    "%"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("p", {
                                className: "text-xs text-muted-foreground",
                                children: [
                                    data.churn.count,
                                    " users churned"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        className: "flex flex-row items-center justify-between space-y-0 pb-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                className: "text-sm font-medium",
                                children: "MRR Estimate"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Activity, {
                                className: "h-4 w-4 text-muted-foreground"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "text-2xl font-bold",
                                children: [
                                    "$",
                                    data.subscriptions.mrr.toFixed(2)
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                className: "text-xs text-muted-foreground",
                                children: "Monthly recurring"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                className: "md:col-span-2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                children: "Daily Revenue"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardDescription */.BT, {
                                children: [
                                    "Revenue over the last ",
                                    data.period.days,
                                    " days"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardContent */.Wu, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                            className: "space-y-2",
                            children: data.revenue.byDay.slice(-7).map((day, index)=>/*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                    className: "flex items-center space-x-2",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                            className: "text-sm w-20",
                                            children: new Date(day.date).toLocaleDateString()
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                            className: "flex-1",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Progress, {
                                                value: day.amount / maxRevenue * 100,
                                                className: "h-2"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                            className: "text-sm font-medium w-16",
                                            children: [
                                                "$",
                                                day.amount.toFixed(2)
                                            ]
                                        })
                                    ]
                                }, day.date))
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                className: "md:col-span-2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                children: "Subscription Breakdown"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardDescription */.BT, {
                                children: "Distribution of users by plan"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardContent */.Wu, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                            className: "flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "flex items-center space-x-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Badge, {
                                                            variant: "secondary",
                                                            children: "Free"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("span", {
                                                            className: "text-sm",
                                                            children: [
                                                                data.subscriptions.byPlan.free,
                                                                " users"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("span", {
                                                    className: "text-sm font-medium",
                                                    children: [
                                                        freePercentage.toFixed(1),
                                                        "%"
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Progress, {
                                            value: freePercentage,
                                            className: "h-2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                            className: "flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "flex items-center space-x-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Badge, {
                                                            variant: "default",
                                                            children: "Premium"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("span", {
                                                            className: "text-sm",
                                                            children: [
                                                                data.subscriptions.byPlan.premium,
                                                                " users"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("span", {
                                                    className: "text-sm font-medium",
                                                    children: [
                                                        premiumPercentage.toFixed(1),
                                                        "%"
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Progress, {
                                            value: premiumPercentage,
                                            className: "h-2"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                className: "md:col-span-4",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardHeader */.aR, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                children: "Recent Subscription Events"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardDescription */.BT, {
                                children: "Latest subscription activity"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardContent */.Wu, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                            className: "space-y-2",
                            children: data.recentEvents.slice(0, 10).map((event, index)=>/*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                    className: "flex items-center justify-between p-2 border rounded",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                            className: "flex items-center space-x-3",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Badge, {
                                                    variant: "outline",
                                                    className: "text-xs",
                                                    children: event.eventType
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                                    className: "text-sm",
                                                    children: event.userId
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                            className: "text-xs text-muted-foreground",
                                            children: new Date(event.timestamp).toLocaleString()
                                        })
                                    ]
                                }, event.id))
                        })
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./components/ui/skeleton.tsx
var skeleton = __webpack_require__(71463);
// EXTERNAL MODULE: ./components/ui/alert.tsx
var ui_alert = __webpack_require__(3018);
// EXTERNAL MODULE: ./components/ui/select.tsx
var ui_select = __webpack_require__(63974);
;// ./app/admin/analytics-client.tsx
/* __next_internal_client_entry_do_not_use__ AdminAnalyticsClient auto */ 





const fetchAnalytics = async (period = '30')=>{
    const response = await fetch(`/api/admin/analytics?period=${period}`);
    if (!response.ok) throw new Error('Failed to load analytics');
    return response.json();
};
function AdminAnalyticsClient() {
    const [data, setData] = (0,react.useState)(null);
    const [loading, setLoading] = (0,react.useState)(true);
    const [error, setError] = (0,react.useState)(null);
    const [period, setPeriod] = (0,react.useState)('30');
    const loadData = async ()=>{
        setLoading(true);
        setError(null);
        try {
            const analyticsData = await fetchAnalytics(period);
            setData(analyticsData);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An error occurred');
        } finally{
            setLoading(false);
        }
    };
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        loadData();
    }, [
        period
    ]);
    if (loading) {
        return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
            className: "space-y-6",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                    className: "flex justify-end",
                    children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                        className: "h-10 w-32"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                    className: "grid gap-6 md:grid-cols-2 lg:grid-cols-4",
                    children: Array.from({
                        length: 4
                    }).map((_, i)=>/*#__PURE__*/ (0,react_jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                            className: "h-32"
                        }, i))
                }),
                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                    className: "grid gap-6 md:grid-cols-2",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                            className: "h-96"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(skeleton/* Skeleton */.E, {
                            className: "h-96"
                        })
                    ]
                })
            ]
        });
    }
    if (error) {
        return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_alert/* Alert */.Fc, {
            variant: "destructive",
            children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_alert/* AlertDescription */.TN, {
                children: [
                    "Error loading analytics: ",
                    error
                ]
            })
        });
    }
    if (!data) {
        return /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
            children: "No data available"
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_select/* Select */.l6, {
                    value: period,
                    onValueChange: setPeriod,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectTrigger */.bq, {
                            className: "w-32",
                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectValue */.yv, {})
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_select/* SelectContent */.gC, {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                    value: "7",
                                    children: "7 days"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                    value: "30",
                                    children: "30 days"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                    value: "90",
                                    children: "90 days"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(AnalyticsCharts, {
                data: data
            })
        ]
    });
}

// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(24934);
// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(68988);
// EXTERNAL MODULE: ./components/ui/label.tsx
var label = __webpack_require__(39390);
// EXTERNAL MODULE: ./components/ui/tabs.tsx
var tabs = __webpack_require__(85910);
;// ./node_modules/lucide-react/dist/esm/icons/circle-x.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const circle_x_iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "path",
        {
            d: "m15 9-6 6",
            key: "1uzhvr"
        }
    ],
    [
        "path",
        {
            d: "m9 9 6 6",
            key: "z0biqf"
        }
    ]
];
const CircleX = (0,createLucideIcon/* default */.A)("circle-x", circle_x_iconNode);
 //# sourceMappingURL=circle-x.js.map

;// ./node_modules/lucide-react/dist/esm/icons/triangle-alert.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const triangle_alert_iconNode = [
    [
        "path",
        {
            d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
            key: "wmoenq"
        }
    ],
    [
        "path",
        {
            d: "M12 9v4",
            key: "juzpu7"
        }
    ],
    [
        "path",
        {
            d: "M12 17h.01",
            key: "p32p05"
        }
    ]
];
const TriangleAlert = (0,createLucideIcon/* default */.A)("triangle-alert", triangle_alert_iconNode);
 //# sourceMappingURL=triangle-alert.js.map

;// ./node_modules/lucide-react/dist/esm/icons/circle-check-big.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const circle_check_big_iconNode = [
    [
        "path",
        {
            d: "M21.801 10A10 10 0 1 1 17 3.335",
            key: "yps3ct"
        }
    ],
    [
        "path",
        {
            d: "m9 11 3 3L22 4",
            key: "1pflzl"
        }
    ]
];
const CircleCheckBig = (0,createLucideIcon/* default */.A)("circle-check-big", circle_check_big_iconNode);
 //# sourceMappingURL=circle-check-big.js.map

;// ./node_modules/lucide-react/dist/esm/icons/refresh-cw.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const refresh_cw_iconNode = [
    [
        "path",
        {
            d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
            key: "v9h5vc"
        }
    ],
    [
        "path",
        {
            d: "M21 3v5h-5",
            key: "1q7to0"
        }
    ],
    [
        "path",
        {
            d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
            key: "3uifl3"
        }
    ],
    [
        "path",
        {
            d: "M8 16H3v5",
            key: "1cv678"
        }
    ]
];
const RefreshCw = (0,createLucideIcon/* default */.A)("refresh-cw", refresh_cw_iconNode);
 //# sourceMappingURL=refresh-cw.js.map

;// ./node_modules/lucide-react/dist/esm/icons/trending-up.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const trending_up_iconNode = [
    [
        "polyline",
        {
            points: "22 7 13.5 15.5 8.5 10.5 2 17",
            key: "126l90"
        }
    ],
    [
        "polyline",
        {
            points: "16 7 22 7 22 13",
            key: "kwv8wd"
        }
    ]
];
const TrendingUp = (0,createLucideIcon/* default */.A)("trending-up", trending_up_iconNode);
 //# sourceMappingURL=trending-up.js.map

;// ./components/admin/FeatureFlagManager.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










function FeatureFlagManager() {
    const [flags, setFlags] = (0,react.useState)(null);
    const [loading, setLoading] = (0,react.useState)(true);
    const [debugInfo, setDebugInfo] = (0,react.useState)(null);
    const [errorBudgets, setErrorBudgets] = (0,react.useState)({});
    const [rolloutPercentages, setRolloutPercentages] = (0,react.useState)({
        autoApplyAzure: 20,
        portalIntegration: 15
    });
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        loadData();
    }, []);
    const loadData = async ()=>{
        setLoading(true);
        try {
            // Use API calls instead of direct service imports
            const [flagsResponse, debugResponse] = await Promise.all([
                fetch('/api/feature-flags'),
                fetch('/api/admin/feature-flags/debug')
            ]);
            let flagsData = null;
            let debugData = null;
            if (flagsResponse.ok) {
                flagsData = await flagsResponse.json();
            }
            if (debugResponse.ok) {
                debugData = await debugResponse.json();
            }
            setFlags(flagsData);
            setDebugInfo(debugData);
            // Note: Error budgets functionality temporarily disabled - requires API endpoint
            setErrorBudgets({});
        } catch (error) {
            console.error('Error loading admin data:', error);
        } finally{
            setLoading(false);
        }
    };
    const updateRolloutPercentage = async (feature, percentage)=>{
        if (percentage < 0 || percentage > 100) return;
        try {
            // Update via API call
            const response = await fetch('/api/admin/rollout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    feature,
                    percentage
                })
            });
            if (response.ok) {
                setRolloutPercentages((prev)=>({
                        ...prev,
                        [feature]: percentage
                    }));
                loadData(); // Refresh data
            } else {
                console.error('Failed to update rollout percentage');
            }
        } catch (error) {
            console.error('Error updating rollout percentage:', error);
        }
    };
    const increaseRollout = (feature, increment = 5)=>{
        const newPercentage = Math.min(100, rolloutPercentages[feature] + increment);
        updateRolloutPercentage(feature, newPercentage);
    };
    const decreaseRollout = (feature, decrement = 5)=>{
        const newPercentage = Math.max(0, rolloutPercentages[feature] - decrement);
        updateRolloutPercentage(feature, newPercentage);
    };
    const getBudgetStatus = (budget)=>{
        if (budget.budgetExceeded) return 'error';
        if (budget.currentErrors > budget.errorThreshold * 0.8) return 'warning';
        return 'ok';
    };
    const getBudgetColor = (status)=>{
        switch(status){
            case 'error':
                return 'text-red-500';
            case 'warning':
                return 'text-yellow-500';
            default:
                return 'text-green-500';
        }
    };
    const getBudgetIcon = (status)=>{
        switch(status){
            case 'error':
                return CircleX;
            case 'warning':
                return TriangleAlert;
            default:
                return CircleCheckBig;
        }
    };
    if (loading) {
        return /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
            className: "p-6 space-y-4",
            children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "animate-pulse space-y-4",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                        className: "h-8 bg-gray-700 rounded w-1/3"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                className: "h-48 bg-gray-800 rounded"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                className: "h-48 bg-gray-800 rounded"
                            })
                        ]
                    })
                ]
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
        className: "p-6 space-y-6",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h1", {
                        className: "text-3xl font-bold text-white",
                        children: "Feature Flag Management"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_button/* Button */.$, {
                        onClick: loadData,
                        variant: "outline",
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(RefreshCw, {
                                className: "h-4 w-4"
                            }),
                            "Refresh"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* Tabs */.tU, {
                defaultValue: "rollout",
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* TabsList */.j7, {
                        className: "grid w-full grid-cols-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "rollout",
                                children: "Rollout Control"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "monitoring",
                                children: "Error Monitoring"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "debug",
                                children: "Debug Info"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "rollout",
                        className: "space-y-4",
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                                    className: "bg-gray-900 border-gray-700",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardHeader */.aR, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardTitle */.ZB, {
                                                className: "text-white flex items-center justify-between",
                                                children: [
                                                    "Auto Apply Azure",
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Badge, {
                                                        variant: flags?.autoApplyAzure ? "default" : "secondary",
                                                        children: flags?.autoApplyAzure ? "Active" : "Inactive"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                            className: "flex items-center justify-between",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                                    className: "text-gray-300",
                                                                    children: "Rollout Percentage"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("span", {
                                                                    className: "text-white font-bold",
                                                                    children: [
                                                                        rolloutPercentages.autoApplyAzure,
                                                                        "%"
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Progress, {
                                                            value: rolloutPercentages.autoApplyAzure,
                                                            className: "h-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "flex gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                            size: "sm",
                                                            variant: "outline",
                                                            onClick: ()=>decreaseRollout('autoApplyAzure'),
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(TrendingDown, {
                                                                    className: "h-3 w-3"
                                                                }),
                                                                "-5%"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                            size: "sm",
                                                            variant: "outline",
                                                            onClick: ()=>increaseRollout('autoApplyAzure'),
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(TrendingUp, {
                                                                    className: "h-3 w-3"
                                                                }),
                                                                "+5%"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                            className: "text-gray-300",
                                                            children: "Custom Percentage"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                            className: "flex gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                                                    type: "number",
                                                                    min: "0",
                                                                    max: "100",
                                                                    value: rolloutPercentages.autoApplyAzure,
                                                                    onChange: (e)=>setRolloutPercentages((prev)=>({
                                                                                ...prev,
                                                                                autoApplyAzure: parseInt(e.target.value) || 0
                                                                            })),
                                                                    className: "bg-gray-800 border-gray-600 text-white"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                                    size: "sm",
                                                                    onClick: ()=>updateRolloutPercentage('autoApplyAzure', rolloutPercentages.autoApplyAzure),
                                                                    children: "Apply"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                                    className: "bg-gray-900 border-gray-700",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardHeader */.aR, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardTitle */.ZB, {
                                                className: "text-white flex items-center justify-between",
                                                children: [
                                                    "Portal Integration",
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Badge, {
                                                        variant: flags?.portalIntegration ? "default" : "secondary",
                                                        children: flags?.portalIntegration ? "Active" : "Inactive"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                            className: "flex items-center justify-between",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                                    className: "text-gray-300",
                                                                    children: "Rollout Percentage"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("span", {
                                                                    className: "text-white font-bold",
                                                                    children: [
                                                                        rolloutPercentages.portalIntegration,
                                                                        "%"
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Progress, {
                                                            value: rolloutPercentages.portalIntegration,
                                                            className: "h-2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "flex gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                            size: "sm",
                                                            variant: "outline",
                                                            onClick: ()=>decreaseRollout('portalIntegration'),
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(TrendingDown, {
                                                                    className: "h-3 w-3"
                                                                }),
                                                                "-5%"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                            size: "sm",
                                                            variant: "outline",
                                                            onClick: ()=>increaseRollout('portalIntegration'),
                                                            className: "flex items-center gap-1",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(TrendingUp, {
                                                                    className: "h-3 w-3"
                                                                }),
                                                                "+5%"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                            className: "text-gray-300",
                                                            children: "Custom Percentage"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                            className: "flex gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                                                    type: "number",
                                                                    min: "0",
                                                                    max: "100",
                                                                    value: rolloutPercentages.portalIntegration,
                                                                    onChange: (e)=>setRolloutPercentages((prev)=>({
                                                                                ...prev,
                                                                                portalIntegration: parseInt(e.target.value) || 0
                                                                            })),
                                                                    className: "bg-gray-800 border-gray-600 text-white"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                                    size: "sm",
                                                                    onClick: ()=>updateRolloutPercentage('portalIntegration', rolloutPercentages.portalIntegration),
                                                                    children: "Apply"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "monitoring",
                        className: "space-y-4",
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                            children: Object.entries(errorBudgets).map(([featureName, budget])=>{
                                const status = getBudgetStatus(budget);
                                const StatusIcon = getBudgetIcon(status);
                                return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                                    className: "bg-gray-900 border-gray-700",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardHeader */.aR, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardTitle */.ZB, {
                                                className: "text-white flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(StatusIcon, {
                                                        className: `h-5 w-5 ${getBudgetColor(status)}`
                                                    }),
                                                    featureName
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* CardContent */.Wu, {
                                            className: "space-y-3",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "flex justify-between items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                                            className: "text-gray-300",
                                                            children: "Error Count"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("span", {
                                                            className: `font-bold ${getBudgetColor(status)}`,
                                                            children: [
                                                                budget.currentErrors,
                                                                " / ",
                                                                budget.errorThreshold
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Progress, {
                                                    value: budget.currentErrors / budget.errorThreshold * 100,
                                                    className: "h-2"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "text-xs text-gray-400",
                                                    children: [
                                                        "Time Window: ",
                                                        budget.timeWindow,
                                                        " minutes"
                                                    ]
                                                }),
                                                budget.budgetExceeded && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_alert/* Alert */.Fc, {
                                                    className: "border-red-600 bg-red-900/20",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(TriangleAlert, {
                                                            className: "h-4 w-4 text-red-400"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_alert/* AlertDescription */.TN, {
                                                            className: "text-red-200",
                                                            children: "Error budget exceeded! Consider reducing rollout."
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }, featureName);
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "debug",
                        className: "space-y-4",
                        children: debugInfo && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(card/* Card */.Zp, {
                            className: "bg-gray-900 border-gray-700",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardHeader */.aR, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardTitle */.ZB, {
                                        className: "text-white",
                                        children: "Debug Information"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(card/* CardContent */.Wu, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("pre", {
                                        className: "bg-gray-800 p-4 rounded text-sm text-gray-300 overflow-auto",
                                        children: JSON.stringify(debugInfo, null, 2)
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

;// ./app/admin/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function AdminDashboard() {
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
        className: "container mx-auto py-6",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "flex items-center justify-between mb-6",
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h1", {
                    className: "text-3xl font-bold text-white",
                    children: "Admin Dashboard"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* Tabs */.tU, {
                defaultValue: "analytics",
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* TabsList */.j7, {
                        className: "grid w-full grid-cols-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "analytics",
                                children: "Analytics"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "feature-flags",
                                children: "Feature Flags"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "analytics",
                        className: "space-y-6 mt-6",
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(AdminAnalyticsClient, {})
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "feature-flags",
                        className: "mt-6",
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(FeatureFlagManager, {})
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 27910:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37366:
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ 39390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ Label)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78148);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);
/* __next_internal_client_entry_do_not_use__ Label auto */ 



function Label({ className, ...props }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .b, {
        "data-slot": "label",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className),
        ...props
    });
}



/***/ }),

/***/ 46675:
/***/ ((module) => {

"use strict";
module.exports = require("firebase-admin");

/***/ }),

/***/ 49441:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/app/admin/page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/app/admin/page.tsx",
"default",
));


/***/ }),

/***/ 55192:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BT: () => (/* binding */ CardDescription),
/* harmony export */   Wu: () => (/* binding */ CardContent),
/* harmony export */   ZB: () => (/* binding */ CardTitle),
/* harmony export */   Zp: () => (/* binding */ Card),
/* harmony export */   aR: () => (/* binding */ CardHeader)
/* harmony export */ });
/* unused harmony export CardFooter */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);



const Card = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    }));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    }));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-sm text-muted-foreground", className),
        ...props
    }));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("p-6 pt-0", className),
        ...props
    }));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center p-6 pt-0", className),
        ...props
    }));
CardFooter.displayName = "CardFooter";



/***/ }),

/***/ 55511:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 63264:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21114));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51108));


/***/ }),

/***/ 63974:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bq: () => (/* binding */ SelectTrigger),
/* harmony export */   eb: () => (/* binding */ SelectItem),
/* harmony export */   gC: () => (/* binding */ SelectContent),
/* harmony export */   l6: () => (/* binding */ Select),
/* harmony export */   yv: () => (/* binding */ SelectValue)
/* harmony export */ });
/* unused harmony exports SelectGroup, SelectLabel, SelectSeparator, SelectScrollUpButton, SelectScrollDownButton */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(72951);
/* harmony import */ var _barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(78272);
/* harmony import */ var _barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3589);
/* harmony import */ var _barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13964);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);





const Select = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .bL;
const SelectGroup = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Group */ .YJ;
const SelectValue = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Value */ .WT;
const SelectTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Icon */ .In, {
                asChild: true,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A, {
                    className: "h-4 w-4 opacity-50"
                })
            })
        ]
    }));
SelectTrigger.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9.displayName;
const SelectScrollUpButton = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollUpButton */ .PP, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A, {
            className: "h-4 w-4"
        })
    }));
SelectScrollUpButton.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollUpButton */ .PP.displayName;
const SelectScrollDownButton = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollDownButton */ .wn, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A, {
            className: "h-4 w-4"
        })
    }));
SelectScrollDownButton.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollDownButton */ .wn.displayName;
const SelectContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, children, position = "popper", ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Portal */ .ZL, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC, {
            ref: ref,
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
            position: position,
            ...props,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SelectScrollUpButton, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Viewport */ .LM, {
                    className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                    children: children
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SelectScrollDownButton, {})
            ]
        })
    }));
SelectContent.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC.displayName;
const SelectLabel = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .JU, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("py-1.5 pl-8 pr-2 text-sm font-semibold", className),
        ...props
    }));
SelectLabel.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .JU.displayName;
const SelectItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Item */ .q7, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ItemIndicator */ .VF, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, {
                        className: "h-4 w-4"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ItemText */ .p4, {
                children: children
            })
        ]
    }));
SelectItem.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Item */ .q7.displayName;
const SelectSeparator = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Separator */ .wv, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("-mx-1 my-1 h-px bg-muted", className),
        ...props
    }));
SelectSeparator.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Separator */ .wv.displayName;



/***/ }),

/***/ 73496:
/***/ ((module) => {

"use strict";
module.exports = require("http2");

/***/ }),

/***/ 74075:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 76416:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52045));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94442));


/***/ }),

/***/ 79551:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 81630:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 85910:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Xi: () => (/* binding */ TabsTrigger),
/* harmony export */   av: () => (/* binding */ TabsContent),
/* harmony export */   j7: () => (/* binding */ TabsList),
/* harmony export */   tU: () => (/* binding */ Tabs)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(55146);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);




const Tabs = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .bL;
const TabsList = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .List */ .B8, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    }));
TabsList.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .List */ .B8.displayName;
const TabsTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    }));
TabsTrigger.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9.displayName;
const TabsContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }));
TabsContent.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC.displayName;



/***/ }),

/***/ 91645:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 95709:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65239);
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(88170);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30893);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
const module0 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76295));
const module1 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 57398, 23));
const module2 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89999, 23));
const module3 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 65284, 23));
const module4 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97786));
const page5 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49441));


// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'admin',
        {
        children: ['__PAGE__', {}, {
          page: [page5, "/Users/dikshantvashistha/PrepBettr/app/admin/page.tsx"],
          
        }]
      },
        {
        'layout': [module4, "/Users/dikshantvashistha/PrepBettr/app/admin/layout.tsx"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [module0, "/Users/dikshantvashistha/PrepBettr/app/layout.tsx"],
'not-found': [module1, "next/dist/client/components/not-found-error"],
'forbidden': [module2, "next/dist/client/components/forbidden-error"],
'unauthorized': [module3, "next/dist/client/components/unauthorized-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["/Users/dikshantvashistha/PrepBettr/app/admin/page.tsx"];


const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/admin/page",
        pathname: "/admin",
        // The following aren't used in production.
        bundlePath: '',
        filename: '',
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 95799:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21857));


/***/ }),

/***/ 97786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ AdminLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37413);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39916);
/* harmony import */ var _lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60940);
/* harmony import */ var _contexts_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(94442);
/* harmony import */ var _components_authenticated_layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(52045);





async function AdminLayout({ children }) {
    // Check authentication
    if (!await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__/* .isAuthenticated */ .wR)()) {
        (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.redirect)('/sign-in');
    }
    // Get the current user to pass to the context
    const user = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__/* .getCurrentUser */ .HW)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_3__.AuthProvider, {
        initialUser: user,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_authenticated_layout__WEBPACK_IMPORTED_MODULE_4__["default"], {
            children: children
        })
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8134,1658,5814,474,4999,8062,7697,3835,9757,8703,8175], () => (__webpack_exec__(95709)));
module.exports = __webpack_exports__;

})();