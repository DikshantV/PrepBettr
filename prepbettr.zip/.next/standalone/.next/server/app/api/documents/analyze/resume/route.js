"use strict";
(() => {
var exports = {};
exports.id = 9413;
exports.ids = [9413];
exports.modules = {

/***/ 1708:
/***/ ((module) => {

module.exports = require("node:process");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 4573:
/***/ ((module) => {

module.exports = require("node:buffer");

/***/ }),

/***/ 7879:
/***/ ((module) => {

module.exports = import("firebase-admin/firestore");;

/***/ }),

/***/ 10756:
/***/ ((module) => {

module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 11997:
/***/ ((module) => {

module.exports = require("punycode");

/***/ }),

/***/ 12412:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 14737:
/***/ ((module) => {

module.exports = import("@azure/storage-blob");;

/***/ }),

/***/ 16141:
/***/ ((module) => {

module.exports = require("node:zlib");

/***/ }),

/***/ 16446:
/***/ ((module) => {

module.exports = import("@azure/app-configuration");;

/***/ }),

/***/ 19771:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 21820:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 26231:
/***/ ((module) => {

module.exports = require("applicationinsights");

/***/ }),

/***/ 27910:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 35672:
/***/ ((module) => {

module.exports = require("@azure/msal-node");

/***/ }),

/***/ 36695:
/***/ ((module) => {

module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37067:
/***/ ((module) => {

module.exports = require("node:http");

/***/ }),

/***/ 37366:
/***/ ((module) => {

module.exports = require("dns");

/***/ }),

/***/ 44708:
/***/ ((module) => {

module.exports = require("node:https");

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 46602:
/***/ ((module) => {

module.exports = import("@azure/cosmos");;

/***/ }),

/***/ 46675:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 48161:
/***/ ((module) => {

module.exports = require("node:os");

/***/ }),

/***/ 51455:
/***/ ((module) => {

module.exports = require("node:fs/promises");

/***/ }),

/***/ 53802:
/***/ ((module) => {

module.exports = require("node:child_process");

/***/ }),

/***/ 55511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 55591:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 57075:
/***/ ((module) => {

module.exports = require("node:stream");

/***/ }),

/***/ 57975:
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ 62201:
/***/ ((module) => {

module.exports = require("@azure/keyvault-secrets");

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 67183:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patchFetch: () => (/* binding */ patchFetch),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),
/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96559);
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37719);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Users_dikshantvashistha_PrepBettr_app_api_documents_analyze_resume_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(88670);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_dikshantvashistha_PrepBettr_app_api_documents_analyze_resume_route_ts__WEBPACK_IMPORTED_MODULE_3__]);
_Users_dikshantvashistha_PrepBettr_app_api_documents_analyze_resume_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,
        page: "/api/documents/analyze/resume/route",
        pathname: "/api/documents/analyze/resume",
        filename: "route",
        bundlePath: "app/api/documents/analyze/resume/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/documents/analyze/resume/route.ts",
    nextConfigOutput,
    userland: _Users_dikshantvashistha_PrepBettr_app_api_documents_analyze_resume_route_ts__WEBPACK_IMPORTED_MODULE_3__
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 73024:
/***/ ((module) => {

module.exports = require("node:fs");

/***/ }),

/***/ 73136:
/***/ ((module) => {

module.exports = require("node:url");

/***/ }),

/***/ 73496:
/***/ ((module) => {

module.exports = require("http2");

/***/ }),

/***/ 74075:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 76760:
/***/ ((module) => {

module.exports = require("node:path");

/***/ }),

/***/ 77598:
/***/ ((module) => {

module.exports = require("node:crypto");

/***/ }),

/***/ 79551:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 79646:
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),

/***/ 81630:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 83997:
/***/ ((module) => {

module.exports = require("tty");

/***/ }),

/***/ 88670:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OPTIONS: () => (/* binding */ OPTIONS),
/* harmony export */   POST: () => (/* binding */ POST),
/* harmony export */   runtime: () => (/* binding */ runtime)
/* harmony export */ });
/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32190);
/* harmony import */ var _lib_services_enhanced_resume_processing_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7075);
/* harmony import */ var _lib_firebase_admin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(63969);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75931);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_enhanced_resume_processing_service__WEBPACK_IMPORTED_MODULE_1__]);
_lib_services_enhanced_resume_processing_service__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Enhanced Resume Analysis API - App Router Endpoint
 * 
 * POST /api/documents/analyze/resume
 * 
 * Enhanced resume upload and analysis using Azure AI Foundry Document Intelligence.
 * Provides backward compatibility with existing upload endpoints while adding
 * advanced capabilities like ATS optimization and job matching.
 */ 



const runtime = 'nodejs';
/**
 * POST /api/documents/analyze/resume
 * Enhanced resume analysis with Azure AI Foundry Document Intelligence
 */ async function POST(request) {
    const startTime = Date.now();
    try {
        console.log('📄 Enhanced resume analysis API called');
        // Handle authentication
        const authHeader = request.headers.get('authorization');
        let userId;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            const idToken = authHeader.split(' ')[1];
            const decodedToken = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_2__.verifyIdToken)(idToken);
            if (!decodedToken) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    success: false,
                    error: 'Unauthorized - Invalid token'
                }, {
                    status: 401
                });
            }
            userId = decodedToken.uid;
        } else if (true) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: 'Unauthorized - No token provided'
            }, {
                status: 401
            });
        } else {}
        // Parse multipart form data
        const formData = await request.formData();
        const file = formData.get('file');
        const jobDescription = formData.get('jobDescription') || undefined;
        const optionsJson = formData.get('options');
        if (!file) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: 'No file uploaded'
            }, {
                status: 400
            });
        }
        // Validate file type and size
        const allowedTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'text/plain'
        ];
        if (!allowedTypes.includes(file.type)) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: 'Unsupported file type. Please upload PDF, DOCX, DOC, or TXT files.'
            }, {
                status: 400
            });
        }
        const maxFileSize = 10 * 1024 * 1024; // 10MB
        if (file.size > maxFileSize) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: 'File size exceeds 10MB limit. Please use a smaller file.'
            }, {
                status: 400
            });
        }
        // Parse options
        let options = {
            generateQuestions: true,
            maxQuestions: 10,
            includeAtsAnalysis: true,
            includeJobMatching: !!jobDescription
        };
        if (optionsJson) {
            try {
                const parsedOptions = JSON.parse(optionsJson);
                options = {
                    ...options,
                    ...parsedOptions
                };
            } catch (parseError) {
                console.warn('⚠️ Failed to parse options JSON:', parseError);
            }
        }
        if (jobDescription) {
            options.jobDescription = jobDescription;
        }
        console.log(`📋 Processing options:`, {
            fileName: file.name,
            fileSize: file.size,
            fileType: file.type,
            hasJobDescription: !!jobDescription,
            ...options
        });
        // Convert File to Buffer
        const fileBuffer = Buffer.from(await file.arrayBuffer());
        // Initialize and process resume using enhanced service
        const result = await _lib_services_enhanced_resume_processing_service__WEBPACK_IMPORTED_MODULE_1__/* .enhancedResumeProcessingService */ .o.processResume(userId, fileBuffer, file.name, file.type, file.size, options);
        const totalTime = Date.now() - startTime;
        if (result.success && result.data) {
            console.log(`✅ Enhanced resume analysis completed in ${totalTime}ms`);
            // Extract recommendations from ATS analysis if available
            let recommendations = [];
            if (result.data.extractedData && 'atsAnalysis' in result.data.extractedData) {
                const atsAnalysis = result.data.extractedData.atsAnalysis;
                if (atsAnalysis && atsAnalysis.recommendations) {
                    recommendations = atsAnalysis.recommendations.map((rec)=>({
                            category: 'ats-optimization',
                            priority: 'medium',
                            suggestion: rec,
                            impact: 'Improve ATS compatibility and keyword matching'
                        }));
                }
            }
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: true,
                data: {
                    ...result.data,
                    recommendations
                },
                message: `Resume analyzed successfully using ${result.data.processingMethod}`
            });
        } else {
            console.error(`❌ Enhanced resume analysis failed in ${totalTime}ms:`, result.error);
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: result.error || 'Failed to analyze resume'
            }, {
                status: 500
            });
        }
    } catch (error) {
        const totalTime = Date.now() - startTime;
        console.error(`❌ Enhanced resume analysis API error (${totalTime}ms):`, error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        (0,_lib_errors__WEBPACK_IMPORTED_MODULE_3__/* .logServerError */ .wh)(error, {
            service: 'enhanced-resume-analysis-api',
            action: 'analyze'
        }, {
            processingTime: totalTime
        });
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: false,
            error: 'Failed to analyze resume',
            message:  false ? 0 : undefined
        }, {
            status: 500
        });
    }
}
/**
 * OPTIONS handler for CORS
 */ async function OPTIONS(request) {
    return new next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse(null, {
        status: 200,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 91645:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

module.exports = require("events");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8384,6716,8180,3969,4633,7075], () => (__webpack_exec__(67183)));
module.exports = __webpack_exports__;

})();