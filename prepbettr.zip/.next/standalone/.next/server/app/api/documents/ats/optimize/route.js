"use strict";
(() => {
var exports = {};
exports.id = 9899;
exports.ids = [9899];
exports.modules = {

/***/ 1708:
/***/ ((module) => {

module.exports = require("node:process");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 4573:
/***/ ((module) => {

module.exports = require("node:buffer");

/***/ }),

/***/ 10756:
/***/ ((module) => {

module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 11997:
/***/ ((module) => {

module.exports = require("punycode");

/***/ }),

/***/ 12412:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 14737:
/***/ ((module) => {

module.exports = import("@azure/storage-blob");;

/***/ }),

/***/ 16446:
/***/ ((module) => {

module.exports = import("@azure/app-configuration");;

/***/ }),

/***/ 19771:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 21673:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ atsOptimizationService)
/* harmony export */ });
/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(40694);
/* harmony import */ var _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(55506);
/* harmony import */ var _prompts_resume_extraction_prompts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(86181);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_1__]);
_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * ATS Optimization Service
 * 
 * Provides comprehensive ATS (Applicant Tracking System) analysis including:
 * - Keyword density analysis and optimization
 * - Skills normalization using industry taxonomies (O*NET, ESCO, SFIA)
 * - Job matching using semantic similarity with embeddings
 * - ATS scoring and recommendations
 */ 


// Industry taxonomy mappings
const INDUSTRY_TAXONOMIES = {
    technology: {
        frameworks: [
            'React',
            'Angular',
            'Vue.js',
            'Node.js',
            'Django',
            'Spring'
        ],
        languages: [
            'JavaScript',
            'Python',
            'Java',
            'TypeScript',
            'Go',
            'Rust'
        ],
        tools: [
            'Git',
            'Docker',
            'Kubernetes',
            'AWS',
            'Azure',
            'Jenkins'
        ],
        concepts: [
            'Agile',
            'DevOps',
            'Microservices',
            'API Design',
            'Cloud Computing'
        ]
    },
    finance: {
        regulations: [
            'SOX',
            'GDPR',
            'Basel III',
            'IFRS',
            'GAAP'
        ],
        tools: [
            'Excel',
            'Bloomberg',
            'SAP',
            'Oracle',
            'Tableau'
        ],
        concepts: [
            'Risk Management',
            'Portfolio Management',
            'Financial Modeling',
            'Compliance'
        ]
    },
    healthcare: {
        regulations: [
            'HIPAA',
            'FDA',
            'CLIA',
            'Joint Commission'
        ],
        systems: [
            'Epic',
            'Cerner',
            'MEDITECH',
            'Allscripts'
        ],
        concepts: [
            'Patient Care',
            'Quality Assurance',
            'Clinical Research',
            'Healthcare Analytics'
        ]
    },
    marketing: {
        platforms: [
            'Google Ads',
            'Facebook Ads',
            'LinkedIn',
            'HubSpot',
            'Salesforce'
        ],
        concepts: [
            'SEO',
            'SEM',
            'Content Marketing',
            'Brand Management',
            'Customer Acquisition'
        ],
        metrics: [
            'CTR',
            'CAC',
            'ROAS',
            'LTV',
            'Conversion Rate'
        ]
    }
};
class ATSOptimizationService {
    constructor(){
        this.openai = null;
        this.initializeOpenAI();
    }
    async initializeOpenAI() {
        try {
            // Try Azure AI Foundry (Migration Client) first
            const migrationClient = new _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_1__/* .MigrationOpenAIClient */ .Ag();
            await migrationClient.init();
            this.openai = migrationClient;
            console.log('✅ ATS Service using Azure AI Foundry client');
        } catch (error) {
            console.warn('Azure AI Foundry not available, falling back to OpenAI:', error);
            // Fallback to standard OpenAI
            if (process.env.OPENAI_API_KEY) {
                this.openai = new openai__WEBPACK_IMPORTED_MODULE_0__/* .OpenAI */ .z4({
                    apiKey: process.env.OPENAI_API_KEY
                });
                console.log('✅ ATS Service using standard OpenAI client');
            } else {
                throw new Error('No AI service available for ATS optimization');
            }
        }
    }
    /**
   * Perform comprehensive ATS analysis of a resume
   */ async analyzeATS(resumeData, jobDescription, targetIndustry) {
        if (!this.openai) {
            await this.initializeOpenAI();
        }
        try {
            const prompt = (0,_prompts_resume_extraction_prompts__WEBPACK_IMPORTED_MODULE_2__/* .formatConditionalPrompt */ .Ml)(_prompts_resume_extraction_prompts__WEBPACK_IMPORTED_MODULE_2__/* .ATS_OPTIMIZATION_PROMPT */ .CD, {
                RESUME_DATA: JSON.stringify(resumeData, null, 2),
                jobDescription,
                targetIndustry
            });
            const completion = await this.openai.chat.completions.create({
                model: process.env.AZURE_OPENAI_DEPLOYMENT || 'gpt-4',
                messages: [
                    {
                        role: 'system',
                        content: 'You are an expert ATS (Applicant Tracking System) analyst. Provide detailed, actionable analysis to improve resume compatibility with ATS systems.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.3,
                max_tokens: 4000
            });
            const response = completion.choices[0].message.content;
            if (!response) {
                throw new Error('No response from AI service');
            }
            // Parse JSON response
            const analysisResult = JSON.parse(response);
            // Enhance with industry-specific analysis
            if (targetIndustry) {
                analysisResult.analysis.keywordAnalysis = await this.enhanceKeywordAnalysis(analysisResult.analysis.keywordAnalysis, resumeData, targetIndustry);
            }
            return analysisResult;
        } catch (error) {
            console.error('ATS analysis failed:', error);
            throw new Error(`ATS analysis failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
   * Normalize and categorize skills using industry taxonomies
   */ async normalizeSkills(skills, targetIndustry, experienceLevel) {
        if (!this.openai) {
            await this.initializeOpenAI();
        }
        try {
            const prompt = (0,_prompts_resume_extraction_prompts__WEBPACK_IMPORTED_MODULE_2__/* .formatConditionalPrompt */ .Ml)(_prompts_resume_extraction_prompts__WEBPACK_IMPORTED_MODULE_2__/* .SKILLS_NORMALIZATION_PROMPT */ .Yn, {
                SKILLS_LIST: skills.join(', '),
                TARGET_INDUSTRY: targetIndustry,
                EXPERIENCE_LEVEL: experienceLevel
            });
            const completion = await this.openai.chat.completions.create({
                model: process.env.AZURE_OPENAI_DEPLOYMENT || 'gpt-4',
                messages: [
                    {
                        role: 'system',
                        content: 'You are an expert in skills taxonomy and industry standards. Use established frameworks like O*NET, ESCO, and SFIA to normalize and categorize skills.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.2,
                max_tokens: 3000
            });
            const response = completion.choices[0].message.content;
            if (!response) {
                throw new Error('No response from AI service');
            }
            const normalizationResult = JSON.parse(response);
            // Enhance with industry-specific mappings
            if (targetIndustry && INDUSTRY_TAXONOMIES[targetIndustry]) {
                normalizationResult.industryAlignment = await this.enhanceIndustryAlignment(normalizationResult.industryAlignment, skills, targetIndustry);
            }
            return normalizationResult;
        } catch (error) {
            console.error('Skills normalization failed:', error);
            throw new Error(`Skills normalization failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
   * Perform job matching analysis using semantic similarity
   */ async analyzeJobMatch(resumeData, jobDescription, targetRole, experienceLevel) {
        if (!this.openai) {
            await this.initializeOpenAI();
        }
        try {
            // First, get semantic embeddings for similarity analysis
            const resumeEmbedding = await this.getResumeEmbedding(resumeData);
            const jobEmbedding = await this.getJobDescriptionEmbedding(jobDescription);
            const semanticSimilarity = this.calculateCosineSimilarity(resumeEmbedding, jobEmbedding);
            const prompt = (0,_prompts_resume_extraction_prompts__WEBPACK_IMPORTED_MODULE_2__/* .formatConditionalPrompt */ .Ml)(_prompts_resume_extraction_prompts__WEBPACK_IMPORTED_MODULE_2__/* .JOB_MATCHING_PROMPT */ .n5, {
                RESUME_DATA: JSON.stringify(resumeData, null, 2),
                JOB_DESCRIPTION: jobDescription,
                targetRole,
                experienceLevel
            });
            const completion = await this.openai.chat.completions.create({
                model: process.env.AZURE_OPENAI_DEPLOYMENT || 'gpt-4',
                messages: [
                    {
                        role: 'system',
                        content: 'You are an expert job matching analyst. Provide detailed analysis of how well a candidate matches a job description, including specific skill gaps and recommendations.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.3,
                max_tokens: 4000
            });
            const response = completion.choices[0].message.content;
            if (!response) {
                throw new Error('No response from AI service');
            }
            const matchResult = JSON.parse(response);
            // Enhance overall score with semantic similarity
            matchResult.overallMatchScore = Math.round(matchResult.overallMatchScore * 0.7 + semanticSimilarity * 100 * 0.3);
            // Extract missing keywords from job description
            matchResult.missingKeywords = await this.extractMissingKeywords(resumeData, jobDescription);
            return matchResult;
        } catch (error) {
            console.error('Job matching analysis failed:', error);
            throw new Error(`Job matching analysis failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
   * Calculate keyword density and relevance
   */ async calculateKeywordDensity(resumeText, targetKeywords) {
        const resumeWords = resumeText.toLowerCase().split(/\s+/);
        const totalWords = resumeWords.length;
        const matches = [];
        const missing = [];
        for (const keyword of targetKeywords){
            const keywordLower = keyword.toLowerCase();
            const keywordWords = keywordLower.split(/\s+/);
            if (keywordWords.length === 1) {
                // Single word keyword
                if (resumeWords.includes(keywordLower)) {
                    matches.push(keyword);
                } else {
                    missing.push(keyword);
                }
            } else {
                // Multi-word keyword - check for phrase
                const keywordRegex = new RegExp(keywordWords.join('\\s+'), 'i');
                if (keywordRegex.test(resumeText)) {
                    matches.push(keyword);
                } else {
                    missing.push(keyword);
                }
            }
        }
        const density = matches.length / totalWords;
        return {
            density,
            matches,
            missing
        };
    }
    /**
   * Get embedding representation of resume for semantic analysis
   */ async getResumeEmbedding(resumeData) {
        // Create a text representation of key resume elements
        const resumeText = [
            resumeData.summary || '',
            resumeData.skills?.map((s)=>s.skill || s).join(' ') || '',
            resumeData.experience?.map((exp)=>`${exp.position} ${exp.company} ${exp.description} ${exp.achievements?.join(' ') || ''} ${exp.technologies?.join(' ') || ''}`).join(' ') || '',
            resumeData.education?.map((edu)=>`${edu.degree} ${edu.field} ${edu.institution}`).join(' ') || ''
        ].join(' ');
        return await this.getTextEmbedding(resumeText);
    }
    /**
   * Get embedding representation of job description
   */ async getJobDescriptionEmbedding(jobDescription) {
        return await this.getTextEmbedding(jobDescription);
    }
    /**
   * Get text embedding using OpenAI's embedding API
   */ async getTextEmbedding(text) {
        try {
            // Check if embeddings API is available
            if (this.openai && 'embeddings' in this.openai) {
                const response = await this.openai.embeddings.create({
                    model: 'text-embedding-ada-002',
                    input: text.slice(0, 8192)
                });
                return response.data[0].embedding;
            } else {
                // Fallback: Use text-based similarity analysis
                console.warn('Embeddings API not available, using text-based fallback');
                return this.getTextBasedVector(text);
            }
        } catch (error) {
            console.error('Failed to get embedding:', error);
            // Return text-based vector as fallback
            return this.getTextBasedVector(text);
        }
    }
    /**
   * Create a simple text-based vector representation
   */ getTextBasedVector(text) {
        // Simple text-based feature extraction
        const words = text.toLowerCase().split(/\s+/);
        const vector = new Array(1536).fill(0);
        // Use word frequency and character patterns to create a pseudo-vector
        words.forEach((word, index)=>{
            const hash = this.simpleHash(word);
            const vectorIndex = Math.abs(hash) % 1536;
            vector[vectorIndex] += 1;
        });
        // Normalize the vector
        const magnitude = Math.sqrt(vector.reduce((sum, val)=>sum + val * val, 0));
        if (magnitude > 0) {
            for(let i = 0; i < vector.length; i++){
                vector[i] = vector[i] / magnitude;
            }
        }
        return vector;
    }
    /**
   * Simple hash function for text
   */ simpleHash(str) {
        let hash = 0;
        for(let i = 0; i < str.length; i++){
            const char = str.charCodeAt(i);
            hash = (hash << 5) - hash + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return hash;
    }
    /**
   * Calculate cosine similarity between two vectors
   */ calculateCosineSimilarity(vector1, vector2) {
        if (vector1.length !== vector2.length) {
            console.warn('Vector lengths do not match');
            return 0;
        }
        let dotProduct = 0;
        let norm1 = 0;
        let norm2 = 0;
        for(let i = 0; i < vector1.length; i++){
            dotProduct += vector1[i] * vector2[i];
            norm1 += vector1[i] * vector1[i];
            norm2 += vector2[i] * vector2[i];
        }
        const magnitude = Math.sqrt(norm1) * Math.sqrt(norm2);
        if (magnitude === 0) {
            return 0;
        }
        return dotProduct / magnitude;
    }
    /**
   * Extract missing keywords from job description that aren't in resume
   */ async extractMissingKeywords(resumeData, jobDescription) {
        // Extract keywords from job description
        const jobKeywords = this.extractKeywordsFromText(jobDescription);
        // Extract keywords from resume
        const resumeText = JSON.stringify(resumeData);
        const resumeKeywords = this.extractKeywordsFromText(resumeText);
        // Find missing keywords
        const missingKeywords = jobKeywords.filter((keyword)=>!resumeKeywords.some((resumeKeyword)=>resumeKeyword.toLowerCase().includes(keyword.toLowerCase()) || keyword.toLowerCase().includes(resumeKeyword.toLowerCase())));
        // Filter to keep only important keywords (remove common words)
        const importantKeywords = missingKeywords.filter((keyword)=>keyword.length > 2 && ![
                'the',
                'and',
                'for',
                'are',
                'but',
                'not',
                'you',
                'all',
                'can',
                'had',
                'her',
                'was',
                'one',
                'our',
                'out',
                'day',
                'had',
                'has',
                'his',
                'how',
                'man',
                'new',
                'now',
                'old',
                'see',
                'two',
                'who',
                'boy',
                'did',
                'its',
                'let',
                'put',
                'say',
                'she',
                'too',
                'use'
            ].includes(keyword.toLowerCase()));
        return importantKeywords.slice(0, 20); // Limit to top 20 missing keywords
    }
    /**
   * Extract keywords from text using simple NLP techniques
   */ extractKeywordsFromText(text) {
        // Remove common punctuation and split into words
        const words = text.toLowerCase().replace(/[^\w\s-]/g, ' ').split(/\s+/).filter((word)=>word.length > 2);
        // Count word frequency
        const wordCount = {};
        words.forEach((word)=>{
            wordCount[word] = (wordCount[word] || 0) + 1;
        });
        // Extract phrases (2-3 word combinations)
        const phrases = [];
        for(let i = 0; i < words.length - 1; i++){
            const twoWordPhrase = `${words[i]} ${words[i + 1]}`;
            phrases.push(twoWordPhrase);
            if (i < words.length - 2) {
                const threeWordPhrase = `${words[i]} ${words[i + 1]} ${words[i + 2]}`;
                phrases.push(threeWordPhrase);
            }
        }
        // Combine single words and phrases, sort by frequency/importance
        const allKeywords = [
            ...Object.keys(wordCount),
            ...phrases
        ];
        // Remove duplicates and sort by length (longer phrases first)
        const uniqueKeywords = Array.from(new Set(allKeywords)).sort((a, b)=>b.length - a.length).slice(0, 100); // Limit to top 100 keywords
        return uniqueKeywords;
    }
    /**
   * Enhance keyword analysis with industry-specific terms
   */ async enhanceKeywordAnalysis(keywordAnalysis, resumeData, targetIndustry) {
        const industryData = INDUSTRY_TAXONOMIES[targetIndustry];
        if (!industryData) {
            return keywordAnalysis;
        }
        // Check for industry-specific keywords
        const industryKeywords = [];
        const resumeText = JSON.stringify(resumeData).toLowerCase();
        // Check technical frameworks/tools
        Object.entries(industryData).forEach(([category, keywords])=>{
            keywords.forEach((keyword)=>{
                const isPresent = resumeText.includes(keyword.toLowerCase());
                industryKeywords.push({
                    keyword,
                    importance: this.getKeywordImportance(keyword, category),
                    category: this.mapCategoryType(category),
                    frequency: isPresent ? 1 : 0,
                    variations: this.getKeywordVariations(keyword)
                });
            });
        });
        return {
            ...keywordAnalysis,
            industryKeywords,
            totalKeywords: keywordAnalysis.totalKeywords + industryKeywords.length
        };
    }
    /**
   * Enhance industry alignment analysis
   */ async enhanceIndustryAlignment(industryAlignment, skills, targetIndustry) {
        const industryData = INDUSTRY_TAXONOMIES[targetIndustry];
        if (!industryData) {
            return industryAlignment;
        }
        const allIndustrySkills = Object.values(industryData).flat();
        const skillsLower = skills.map((s)=>s.toLowerCase());
        const wellAligned = allIndustrySkills.filter((industrySkill)=>skillsLower.some((skill)=>skill.includes(industrySkill.toLowerCase()) || industrySkill.toLowerCase().includes(skill)));
        const missing = allIndustrySkills.filter((industrySkill)=>!skillsLower.some((skill)=>skill.includes(industrySkill.toLowerCase()) || industrySkill.toLowerCase().includes(skill)));
        return {
            ...industryAlignment,
            wellAlignedSkills: [
                ...new Set([
                    ...industryAlignment.wellAlignedSkills,
                    ...wellAligned
                ])
            ],
            missingIndustrySkills: [
                ...new Set([
                    ...industryAlignment.missingIndustrySkills,
                    ...missing.slice(0, 10)
                ])
            ],
            score: Math.round(wellAligned.length / allIndustrySkills.length * 100)
        };
    }
    /**
   * Get keyword importance based on category and context
   */ getKeywordImportance(keyword, category) {
        // High-importance categories
        if ([
            'frameworks',
            'languages',
            'regulations'
        ].includes(category)) {
            return 'high';
        }
        // Medium-importance categories
        if ([
            'tools',
            'platforms'
        ].includes(category)) {
            return 'medium';
        }
        // Default to low importance
        return 'low';
    }
    /**
   * Map category names to standard types
   */ mapCategoryType(category) {
        const technicalCategories = [
            'frameworks',
            'languages',
            'tools',
            'platforms',
            'systems'
        ];
        const industryCategories = [
            'regulations',
            'concepts',
            'metrics'
        ];
        if (technicalCategories.includes(category)) {
            return 'technical';
        }
        if (industryCategories.includes(category)) {
            return 'industry';
        }
        return 'role';
    }
    /**
   * Get common variations of a keyword
   */ getKeywordVariations(keyword) {
        // Common variations and synonyms
        const variations = {
            'React': [
                'React.js',
                'ReactJS',
                'React JS'
            ],
            'Node.js': [
                'NodeJS',
                'Node',
                'Node JS'
            ],
            'JavaScript': [
                'JS',
                'Javascript',
                'ECMAScript'
            ],
            'TypeScript': [
                'TS',
                'Typescript'
            ],
            'Python': [
                'py'
            ],
            'Docker': [
                'Containerization'
            ],
            'Kubernetes': [
                'K8s',
                'K8S'
            ],
            'AWS': [
                'Amazon Web Services'
            ],
            'Azure': [
                'Microsoft Azure'
            ]
        };
        return variations[keyword] || [
            keyword
        ];
    }
}
// Export singleton instance
const atsOptimizationService = new ATSOptimizationService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 21820:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 26231:
/***/ ((module) => {

module.exports = require("applicationinsights");

/***/ }),

/***/ 27910:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 28884:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OPTIONS: () => (/* binding */ OPTIONS),
/* harmony export */   POST: () => (/* binding */ POST),
/* harmony export */   runtime: () => (/* binding */ runtime)
/* harmony export */ });
/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32190);
/* harmony import */ var _lib_firebase_admin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63969);
/* harmony import */ var _lib_services_ats_optimization_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(21673);
/* harmony import */ var _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74798);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(75931);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_ats_optimization_service__WEBPACK_IMPORTED_MODULE_2__]);
_lib_services_ats_optimization_service__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * ATS Optimization API - App Router Endpoint
 * 
 * POST /api/documents/ats/optimize
 * 
 * Provides ATS optimization analysis for resumes including:
 * - ATS compatibility scoring
 * - Job matching with semantic similarity
 * - Keyword analysis and optimization
 * - Skills normalization using industry taxonomies
 * - Detailed recommendations for improvement
 */ 




const runtime = 'nodejs';
/**
 * POST /api/documents/ats/optimize
 * ATS optimization analysis for resume improvement
 */ async function POST(request) {
    const startTime = Date.now();
    try {
        console.log('🎯 ATS optimization API called');
        // Handle authentication
        const authHeader = request.headers.get('authorization');
        let userId;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            const idToken = authHeader.split(' ')[1];
            const decodedToken = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_1__.verifyIdToken)(idToken);
            if (!decodedToken) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    success: false,
                    error: 'Unauthorized - Invalid token'
                }, {
                    status: 401
                });
            }
            userId = decodedToken.uid;
        } else if (true) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: 'Unauthorized - No token provided'
            }, {
                status: 401
            });
        } else {}
        // Parse request data
        const contentType = request.headers.get('content-type') || '';
        let file;
        let resumeData;
        let jobDescription;
        let options = {};
        if (contentType.includes('multipart/form-data')) {
            // Handle file upload with form data
            const formData = await request.formData();
            file = formData.get('file');
            jobDescription = formData.get('jobDescription') || undefined;
            const optionsJson = formData.get('options');
            if (optionsJson) {
                try {
                    options = JSON.parse(optionsJson);
                } catch (parseError) {
                    console.warn('⚠️ Failed to parse options JSON:', parseError);
                }
            }
        } else {
            // Handle JSON request with existing resume data
            const body = await request.json();
            resumeData = body.resumeData;
            jobDescription = body.jobDescription;
            options = body.options || {};
        }
        // Validate input - need either file or resume data
        if (!file && !resumeData) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: 'Either file or resumeData is required'
            }, {
                status: 400
            });
        }
        // Extract resume data if file provided
        if (file && !resumeData) {
            console.log('📄 Extracting resume data from file...');
            // Validate file type
            const allowedTypes = [
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'text/plain'
            ];
            if (!allowedTypes.includes(file.type)) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    success: false,
                    error: 'Unsupported file type. Please upload PDF, DOCX, DOC, or TXT files.'
                }, {
                    status: 400
                });
            }
            // Validate file size
            const maxFileSize = 10 * 1024 * 1024; // 10MB
            if (file.size > maxFileSize) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    success: false,
                    error: 'File size exceeds 10MB limit.'
                }, {
                    status: 400
                });
            }
            try {
                const fileBuffer = Buffer.from(await file.arrayBuffer());
                resumeData = await _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_3__/* .azureFormRecognizer */ .m.extractResumeData(fileBuffer, file.type);
            } catch (extractionError) {
                console.error('❌ Resume data extraction failed:', extractionError);
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    success: false,
                    error: 'Failed to extract resume data from file'
                }, {
                    status: 500
                });
            }
        }
        console.log('🔍 Starting ATS analysis with options:', {
            hasJobDescription: !!jobDescription,
            targetRole: options.targetRole,
            targetIndustry: options.targetIndustry,
            experienceLevel: options.experienceLevel
        });
        // Perform ATS analysis
        const atsAnalysis = await _lib_services_ats_optimization_service__WEBPACK_IMPORTED_MODULE_2__/* .atsOptimizationService */ .Z.analyzeATS(resumeData, jobDescription, options.targetIndustry);
        console.log(`✅ ATS analysis completed with score: ${atsAnalysis.atsScore}/100`);
        // Perform job matching if job description provided
        let jobMatchAnalysis;
        if (jobDescription) {
            console.log('🎯 Performing job matching analysis...');
            try {
                jobMatchAnalysis = await _lib_services_ats_optimization_service__WEBPACK_IMPORTED_MODULE_2__/* .atsOptimizationService */ .Z.analyzeJobMatch(resumeData, jobDescription, options.targetRole, options.experienceLevel);
                console.log(`✅ Job matching completed with score: ${jobMatchAnalysis.overallMatchScore}/100`);
            } catch (matchError) {
                console.warn('⚠️ Job matching analysis failed:', matchError);
            }
        }
        // Perform skills normalization if requested
        let skillsNormalization;
        if (options.includeSkillsNormalization && resumeData.skills) {
            console.log('🔧 Performing skills normalization...');
            try {
                const skillsList = Array.isArray(resumeData.skills) ? resumeData.skills.map((s)=>typeof s === 'string' ? s : s.skill || s.name) : [
                    resumeData.skills
                ];
                skillsNormalization = await _lib_services_ats_optimization_service__WEBPACK_IMPORTED_MODULE_2__/* .atsOptimizationService */ .Z.normalizeSkills(skillsList, options.targetIndustry, options.experienceLevel);
                console.log(`✅ Skills normalization completed for ${skillsList.length} skills`);
            } catch (skillsError) {
                console.warn('⚠️ Skills normalization failed:', skillsError);
            }
        }
        // Generate comprehensive recommendations
        const recommendations = generateRecommendations(atsAnalysis, jobMatchAnalysis, skillsNormalization);
        const processingTime = Date.now() - startTime;
        console.log(`✅ ATS optimization analysis completed in ${processingTime}ms`);
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: true,
            data: {
                atsAnalysis,
                jobMatchAnalysis,
                skillsNormalization,
                resumeData: file ? resumeData : undefined,
                processingTime,
                analysisTimestamp: new Date().toISOString(),
                recommendations
            },
            message: `ATS analysis completed with score ${atsAnalysis.atsScore}/100`
        });
    } catch (error) {
        const processingTime = Date.now() - startTime;
        console.error(`❌ ATS optimization API error (${processingTime}ms):`, error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        (0,_lib_errors__WEBPACK_IMPORTED_MODULE_4__/* .logServerError */ .wh)(error, {
            service: 'ats-optimization-api',
            action: 'optimize'
        }, {
            processingTime
        });
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: false,
            error: 'Failed to perform ATS optimization analysis',
            message:  false ? 0 : undefined
        }, {
            status: 500
        });
    }
}
/**
 * Generate comprehensive recommendations from analysis results
 */ function generateRecommendations(atsAnalysis, jobMatchAnalysis, skillsNormalization) {
    const immediate = [];
    const longTerm = [];
    // Extract immediate recommendations from ATS analysis
    if (atsAnalysis.prioritizedRecommendations) {
        atsAnalysis.prioritizedRecommendations.filter((rec)=>rec.priority === 'high' || rec.priority === 'medium').forEach((rec)=>{
            immediate.push({
                category: rec.category,
                priority: rec.priority,
                action: rec.recommendation,
                expectedImpact: rec.expectedImpact,
                timeToImplement: rec.timeToImplement
            });
        });
    }
    // Extract long-term recommendations from job matching
    if (jobMatchAnalysis?.recommendations) {
        jobMatchAnalysis.recommendations.filter((rec)=>rec.category === 'skills' && rec.priority === 'high').forEach((rec)=>{
            longTerm.push({
                category: rec.category,
                skill: rec.recommendation,
                reasoning: rec.reasoning,
                learningResources: rec.resources,
                timeframe: rec.timeframe
            });
        });
    }
    // Extract skill development recommendations
    if (skillsNormalization?.industryAlignment?.recommendations) {
        skillsNormalization.industryAlignment.recommendations.forEach((rec)=>{
            longTerm.push({
                category: 'skills',
                skill: 'Industry alignment',
                reasoning: rec,
                learningResources: [
                    'Online courses',
                    'Industry certifications'
                ],
                timeframe: '2-6 months'
            });
        });
    }
    return {
        immediate,
        longTerm
    };
}
/**
 * OPTIONS handler for CORS
 */ async function OPTIONS(request) {
    return new next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse(null, {
        status: 200,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 29021:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 35672:
/***/ ((module) => {

module.exports = require("@azure/msal-node");

/***/ }),

/***/ 36463:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patchFetch: () => (/* binding */ patchFetch),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),
/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96559);
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37719);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Users_dikshantvashistha_PrepBettr_app_api_documents_ats_optimize_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28884);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_dikshantvashistha_PrepBettr_app_api_documents_ats_optimize_route_ts__WEBPACK_IMPORTED_MODULE_3__]);
_Users_dikshantvashistha_PrepBettr_app_api_documents_ats_optimize_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,
        page: "/api/documents/ats/optimize/route",
        pathname: "/api/documents/ats/optimize",
        filename: "route",
        bundlePath: "app/api/documents/ats/optimize/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/documents/ats/optimize/route.ts",
    nextConfigOutput,
    userland: _Users_dikshantvashistha_PrepBettr_app_api_documents_ats_optimize_route_ts__WEBPACK_IMPORTED_MODULE_3__
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 36695:
/***/ ((module) => {

module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37067:
/***/ ((module) => {

module.exports = require("node:http");

/***/ }),

/***/ 37366:
/***/ ((module) => {

module.exports = require("dns");

/***/ }),

/***/ 38522:
/***/ ((module) => {

module.exports = require("node:zlib");

/***/ }),

/***/ 44708:
/***/ ((module) => {

module.exports = require("node:https");

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 46602:
/***/ ((module) => {

module.exports = import("@azure/cosmos");;

/***/ }),

/***/ 46675:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 48161:
/***/ ((module) => {

module.exports = require("node:os");

/***/ }),

/***/ 51455:
/***/ ((module) => {

module.exports = require("node:fs/promises");

/***/ }),

/***/ 53802:
/***/ ((module) => {

module.exports = require("node:child_process");

/***/ }),

/***/ 55511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 55591:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 57075:
/***/ ((module) => {

module.exports = require("node:stream");

/***/ }),

/***/ 57975:
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ 62201:
/***/ ((module) => {

module.exports = require("@azure/keyvault-secrets");

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 73024:
/***/ ((module) => {

module.exports = require("node:fs");

/***/ }),

/***/ 73136:
/***/ ((module) => {

module.exports = require("node:url");

/***/ }),

/***/ 73496:
/***/ ((module) => {

module.exports = require("http2");

/***/ }),

/***/ 74075:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 74798:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   m: () => (/* binding */ azureFormRecognizer)
/* harmony export */ });
/* harmony import */ var _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(98180);
/* harmony import */ var _azure_lib_azure_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65868);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75931);



class AzureFormRecognizerService {
    /**
   * Initialize the Azure Form Recognizer service
   */ async initialize() {
        try {
            const secrets = await (0,_azure_lib_azure_config__WEBPACK_IMPORTED_MODULE_1__/* .fetchAzureSecrets */ .lL)();
            const endpoint = process.env.AZURE_FORM_RECOGNIZER_ENDPOINT || secrets.azureFormRecognizerEndpoint;
            const apiKey = process.env.AZURE_FORM_RECOGNIZER_KEY || secrets.azureFormRecognizerKey;
            if (!endpoint || !apiKey) {
                console.warn('⚠️ Azure Form Recognizer credentials not found, will use OpenAI fallback');
                return false;
            }
            this.client = new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_0__/* .DocumentAnalysisClient */ .Pz(endpoint, new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_0__/* .AzureKeyCredential */ .KL(apiKey));
            console.log('✅ Azure Form Recognizer service initialized');
            return true;
        } catch (error) {
            console.error('❌ Failed to initialize Azure Form Recognizer:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
                service: 'azure-form-recognizer',
                action: 'initialize'
            });
            return false;
        }
    }
    /**
   * Check if service is ready
   */ isReady() {
        return this.client !== null;
    }
    /**
   * Extract resume data from buffer using Azure Form Recognizer
   */ async extractResumeData(fileBuffer, mimeType) {
        if (!this.isReady()) {
            throw new Error('Azure Form Recognizer service not initialized');
        }
        try {
            console.log('🔍 Extracting resume data with Azure Form Recognizer...');
            // Analyze the document
            const poller = await this.client.beginAnalyzeDocument(this.modelId, fileBuffer);
            const result = await poller.pollUntilDone();
            // Extract text content from the document
            const fullText = result.content || '';
            // Store raw extraction for GDPR export
            const rawExtraction = {
                content: result.content,
                pages: result.pages,
                tables: result.tables,
                keyValuePairs: result.keyValuePairs,
                styles: result.styles
            };
            // Parse the extracted text to structure data
            const extractedData = await this.parseResumeContent(fullText);
            // Include raw extraction
            extractedData.rawExtraction = rawExtraction;
            console.log('✅ Resume data extracted successfully with Azure Form Recognizer');
            return extractedData;
        } catch (error) {
            console.error('Failed to extract resume data with Azure Form Recognizer:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
                service: 'azure-form-recognizer',
                action: 'extract'
            }, {
                mimeType
            });
            throw error;
        }
    }
    /**
   * Parse resume content using AI to extract structured data
   * This method uses OpenAI as a processing layer on top of Form Recognizer
   */ async parseResumeContent(text) {
        // We'll use tailorResume function as it's the main AI processing function available
        // Use OpenAI function calling to structure the extracted text
        const prompt = `
    Extract the following information from this resume text and return as JSON:
    
    {
      "personalInfo": {
        "name": "Full name",
        "email": "Email address",
        "phone": "Phone number",
        "address": "Address",
        "linkedin": "LinkedIn URL",
        "github": "GitHub URL",
        "website": "Personal website URL"
      },
      "summary": "Professional summary or objective",
      "skills": ["skill1", "skill2", ...],
      "experience": [
        {
          "company": "Company name",
          "position": "Job title",
          "startDate": "Start date",
          "endDate": "End date or 'Present'",
          "isCurrent": true/false,
          "description": "Job description",
          "achievements": ["achievement1", ...],
          "technologies": ["tech1", "tech2", ...],
          "location": "Location"
        }
      ],
      "education": [
        {
          "institution": "School name",
          "degree": "Degree type",
          "field": "Field of study",
          "startDate": "Start date",
          "endDate": "End date",
          "gpa": 3.5,
          "description": "Additional details",
          "location": "Location"
        }
      ],
      "projects": [
        {
          "name": "Project name",
          "description": "Project description",
          "technologies": ["tech1", "tech2", ...],
          "url": "Project URL",
          "github": "GitHub URL",
          "startDate": "Start date",
          "endDate": "End date"
        }
      ],
      "certifications": [
        {
          "name": "Certification name",
          "issuer": "Issuing organization",
          "date": "Issue date",
          "expiryDate": "Expiry date",
          "credentialId": "Credential ID",
          "url": "Verification URL"
        }
      ],
      "languages": [
        {
          "name": "Language name",
          "proficiency": "Proficiency level"
        }
      ]
    }
    
    Resume text:
    ${text}
    `;
        try {
            // Use the AI service to process the text
            const { tailorResume } = await Promise.all(/* import() */[__webpack_require__.e(8833), __webpack_require__.e(5506), __webpack_require__.e(6955), __webpack_require__.e(3685)]).then(__webpack_require__.bind(__webpack_require__, 53685));
            // Create a structured extraction prompt
            const extractionResult = await tailorResume(text, prompt);
            if (extractionResult.success && extractionResult.data) {
                try {
                    // Parse the JSON response
                    const parsedData = typeof extractionResult.data === 'string' ? JSON.parse(extractionResult.data) : extractionResult.data;
                    return {
                        personalInfo: parsedData.personalInfo || {},
                        summary: parsedData.summary,
                        skills: parsedData.skills || [],
                        experience: parsedData.experience || [],
                        education: parsedData.education || [],
                        projects: parsedData.projects || [],
                        certifications: parsedData.certifications || [],
                        languages: parsedData.languages || []
                    };
                } catch (parseError) {
                    console.warn('Failed to parse AI extraction result, using fallback parsing');
                    return this.fallbackTextParsing(text);
                }
            }
            // Fallback to simple text parsing if AI fails
            return this.fallbackTextParsing(text);
        } catch (error) {
            console.warn('AI parsing failed, using fallback text parsing:', error);
            return this.fallbackTextParsing(text);
        }
    }
    /**
   * Fallback text parsing method
   */ fallbackTextParsing(text) {
        const lines = text.split('\n').map((line)=>line.trim()).filter((line)=>line);
        // Simple regex patterns for basic extraction
        const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
        const phoneRegex = /(\+?1?[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}/g;
        const linkedinRegex = /linkedin\.com\/in\/[\w-]+/gi;
        const githubRegex = /github\.com\/[\w-]+/gi;
        const emails = text.match(emailRegex) || [];
        const phones = text.match(phoneRegex) || [];
        const linkedinUrls = text.match(linkedinRegex) || [];
        const githubUrls = text.match(githubRegex) || [];
        // Extract skills (simple keyword matching)
        const skillKeywords = [
            'javascript',
            'typescript',
            'python',
            'java',
            'react',
            'node',
            'express',
            'mongodb',
            'sql',
            'postgresql',
            'mysql',
            'docker',
            'kubernetes',
            'aws',
            'azure',
            'gcp',
            'git',
            'html',
            'css',
            'angular',
            'vue',
            'spring',
            'django',
            'flask',
            'ruby',
            'php',
            'go',
            'rust',
            'c++',
            'c#',
            'swift',
            'kotlin',
            'flutter',
            'dart',
            'tensorflow',
            'pytorch',
            'machine learning',
            'data science',
            'artificial intelligence',
            'blockchain',
            'devops'
        ];
        const detectedSkills = skillKeywords.filter((skill)=>text.toLowerCase().includes(skill.toLowerCase()));
        return {
            personalInfo: {
                email: emails[0],
                phone: phones[0],
                linkedin: linkedinUrls[0] ? `https://${linkedinUrls[0]}` : undefined,
                github: githubUrls[0] ? `https://${githubUrls[0]}` : undefined
            },
            skills: detectedSkills,
            experience: [],
            education: [],
            projects: [],
            certifications: [],
            languages: []
        };
    }
    constructor(){
        this.client = null;
        this.modelId = 'prebuilt-document' // Use prebuilt document model
        ;
    }
}
// Export singleton instance
const azureFormRecognizer = new AzureFormRecognizerService();


/***/ }),

/***/ 75931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   wh: () => (/* binding */ logServerError)
/* harmony export */ });
/* unused harmony exports createErrorResponse, createApiErrorResponse, isRetryableError, mapErrorToResponse, NETWORK_FAILURE_MESSAGE, getUserFriendlyErrorMessage */
// lib/errors.ts
/**
 * Creates a standardized error response
 */ function createErrorResponse(error, status) {
    return {
        error,
        status
    };
}
/**
 * Creates a NextResponse error for API routes
 */ function createApiErrorResponse(error, status) {
    // Import NextResponse dynamically to avoid module issues
    const { NextResponse } = __webpack_require__(32190);
    return NextResponse.json({
        error
    }, {
        status
    });
}
/**
 * Logs server errors with context but never exposes sensitive information
 */ function logServerError(error, context, additionalContext) {
    const errorMessage = error instanceof Error ? error.message : error;
    const errorStack = error instanceof Error ? error.stack : undefined;
    // Create safe logging context (no sensitive data)
    const safeContext = {
        timestamp: context.timestamp || new Date().toISOString(),
        url: context.url,
        method: context.method,
        userId: context.userId ? `user_${context.userId.slice(-8)}` : 'anonymous',
        userAgent: context.userAgent ? context.userAgent.slice(0, 100) : undefined,
        ip: context.ip ? context.ip.replace(/\d+$/, 'xxx') : undefined,
        ...additionalContext
    };
    console.error('Server Error:', {
        message: errorMessage,
        context: safeContext,
        stack: errorStack
    });
    // In production, you might want to send this to a logging service
    // like DataDog, Sentry, etc.
    if (true) {
    // Example: Send to external logging service
    // logger.error(errorMessage, safeContext);
    }
}
/**
 * Determines if an error should be retried
 */ function isRetryableError(status) {
    // Retry for 5xx errors and specific 4xx errors
    return status >= 500 || status === 408 || status === 429;
}
/**
 * Maps common error types to standard error responses
 */ function mapErrorToResponse(error) {
    // Network/Connection errors
    if (error.name === 'AbortError' || error.code === 'ECONNABORTED') {
        return createErrorResponse('Request timeout. Please try again.', 408);
    }
    if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
        return createErrorResponse('Network error. Please check your connection.', 503);
    }
    // Azure OpenAI specific errors
    if (error.status) {
        switch(error.status){
            case 401:
                return createErrorResponse('Service authentication failed. Please try again later.', 500);
            case 429:
                return createErrorResponse('Service temporarily unavailable due to high demand. Please try again later.', 429);
            case 400:
                return createErrorResponse('Invalid request format. Please check your input.', 400);
            default:
                if (error.status >= 500) {
                    return createErrorResponse('Service temporarily unavailable. Please try again later.', 500);
                }
        }
    }
    // Generic API errors
    if (error.message) {
        if (error.message.includes('API key') || error.message.includes('credentials')) {
            return createErrorResponse('Service configuration error. Please contact support.', 500);
        }
        if (error.message.includes('quota') || error.message.includes('limit') || error.message.includes('rate')) {
            return createErrorResponse('Service temporarily unavailable due to usage limits. Please try again later.', 429);
        }
        if (error.message.includes('not initialized')) {
            return createErrorResponse('Service is not properly configured. Please contact support.', 500);
        }
    }
    // Default error response
    return createErrorResponse('An unexpected error occurred. Please try again.', 500);
}
/**
 * Standard fallback message for network failures
 */ const NETWORK_FAILURE_MESSAGE = "Could not fetch job description from the provided URL.";
/**
 * Gets user-friendly error message for frontend display
 */ function getUserFriendlyErrorMessage(error, context) {
    if (error?.error) {
        return error.error;
    }
    if (context === 'url_extraction') {
        return NETWORK_FAILURE_MESSAGE;
    }
    if (error?.message) {
        // Don't expose internal error messages to users
        if (error.message.includes('API key') || error.message.includes('credentials') || error.message.includes('internal') || error.message.includes('database')) {
            return 'Service temporarily unavailable. Please try again later.';
        }
        return error.message;
    }
    return 'An unexpected error occurred. Please try again.';
}


/***/ }),

/***/ 76760:
/***/ ((module) => {

module.exports = require("node:path");

/***/ }),

/***/ 77598:
/***/ ((module) => {

module.exports = require("node:crypto");

/***/ }),

/***/ 79551:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 79646:
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),

/***/ 81630:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 83997:
/***/ ((module) => {

module.exports = require("tty");

/***/ }),

/***/ 86181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CD: () => (/* binding */ ATS_OPTIMIZATION_PROMPT),
/* harmony export */   Ml: () => (/* binding */ formatConditionalPrompt),
/* harmony export */   Yn: () => (/* binding */ SKILLS_NORMALIZATION_PROMPT),
/* harmony export */   n5: () => (/* binding */ JOB_MATCHING_PROMPT)
/* harmony export */ });
/* unused harmony exports RESUME_EXTRACTION_PROMPT, INTERVIEW_QUESTIONS_PROMPT, RESUME_IMPROVEMENT_PROMPT, formatPrompt, PROMPT_CONFIGS */
/**
 * Resume Processing Prompt Templates
 * 
 * Reusable prompt templates for AI-powered resume processing, extraction,
 * and optimization. These templates provide consistent structure across
 * different processing methods.
 */ /**
 * Main resume data extraction prompt for structured information extraction
 */ const RESUME_EXTRACTION_PROMPT = `
Extract the following information from this resume text and return as valid JSON.

Required JSON Structure:
{
  "personalInfo": {
    "name": "Full name",
    "email": "Email address", 
    "phone": "Phone number",
    "address": "Physical address",
    "linkedin": "LinkedIn URL",
    "github": "GitHub URL",
    "website": "Personal website URL",
    "location": "City, State/Country"
  },
  "summary": "Professional summary or objective statement",
  "skills": [
    {
      "skill": "Technical skill or competency",
      "category": "technical|soft|language|certification|tool",
      "proficiency": "beginner|intermediate|advanced|expert",
      "yearsOfExperience": 3
    }
  ],
  "experience": [
    {
      "company": "Company name",
      "position": "Job title", 
      "startDate": "MM/YYYY",
      "endDate": "MM/YYYY or Present",
      "isCurrent": true,
      "location": "City, State",
      "description": "Role description",
      "achievements": ["Quantifiable achievement 1", "Achievement 2"],
      "technologies": ["Technology 1", "Technology 2"],
      "managementScope": {
        "teamSize": 5,
        "budget": "$500K",
        "responsibilities": ["Responsibility 1", "Responsibility 2"]
      },
      "quantifiableResults": [
        {
          "metric": "Revenue increase",
          "value": 25,
          "unit": "percentage", 
          "impact": "Generated $2M additional revenue"
        }
      ]
    }
  ],
  "education": [
    {
      "institution": "School name",
      "degree": "Degree type and level",
      "field": "Field of study", 
      "startDate": "YYYY",
      "endDate": "YYYY",
      "gpa": 3.8,
      "location": "City, State",
      "honors": ["Dean's List", "Magna Cum Laude"],
      "relevantCoursework": ["Course 1", "Course 2"]
    }
  ],
  "projects": [
    {
      "name": "Project name",
      "description": "Project description and impact",
      "technologies": ["Tech stack used"],
      "url": "Project URL",
      "github": "GitHub repository URL",
      "startDate": "MM/YYYY",
      "endDate": "MM/YYYY",
      "role": "Your role in project",
      "teamSize": 3,
      "impact": "Quantifiable impact or outcome"
    }
  ],
  "certifications": [
    {
      "name": "Certification name",
      "issuer": "Issuing organization",
      "date": "Issue date",
      "expiryDate": "Expiry date if applicable",
      "credentialId": "Credential ID",
      "url": "Verification URL",
      "status": "active|expired|pending"
    }
  ],
  "languages": [
    {
      "name": "Language name",
      "proficiency": "native|fluent|conversational|basic",
      "certifications": ["Language certification if any"]
    }
  ],
  "publications": [
    {
      "title": "Publication title",
      "venue": "Journal or conference",
      "date": "Publication date",
      "url": "Publication URL",
      "coAuthors": ["Co-author names"]
    }
  ],
  "awards": [
    {
      "name": "Award name",
      "issuer": "Issuing organization",
      "date": "Award date",
      "description": "Award description"
    }
  ]
}

Extraction Rules:
1. Return ONLY valid JSON, no additional text or formatting
2. If information is not available, use null or empty array
3. Extract actual data from the resume - do not infer or make up information
4. For dates, preserve the original format when clear, otherwise standardize to MM/YYYY
5. For current positions, set isCurrent to true and endDate to null
6. Categorize skills appropriately (technical, soft, language, certification, tool)
7. Extract quantifiable achievements with specific metrics when mentioned
8. Identify management scope including team size, budget, and responsibilities
9. Parse education with GPA only if explicitly mentioned
10. Include all relevant projects with technology stack and impact

Resume Text:
{{RESUME_TEXT}}
`;
/**
 * ATS optimization analysis prompt
 */ const ATS_OPTIMIZATION_PROMPT = `
Analyze this resume for ATS (Applicant Tracking System) compatibility and provide optimization recommendations.

Resume Data: {{RESUME_DATA}}
{{#if jobDescription}}Job Description: {{jobDescription}}{{/if}}

Provide analysis in this JSON structure:
{
  "atsScore": 85,
  "overallGrade": "B",
  "analysis": {
    "keywordAnalysis": {
      "score": 75,
      "totalKeywords": 25,
      "matchedKeywords": ["keyword1", "keyword2"],
      "missingKeywords": ["missing1", "missing2"],
      "keywordDensity": 0.6,
      "recommendations": ["Add more technical keywords", "Include industry-specific terms"]
    },
    "formatAnalysis": {
      "score": 90,
      "issues": [
        {
          "type": "critical|warning|suggestion",
          "issue": "Issue description",
          "solution": "How to fix it",
          "impact": "Why it matters for ATS"
        }
      ],
      "strengths": ["Clear section headers", "Consistent formatting"]
    },
    "structureAnalysis": {
      "score": 85,
      "missingElements": ["Professional summary", "Skills section"],
      "presentElements": ["Contact info", "Work experience", "Education"],
      "recommendations": ["Add a professional summary", "Create dedicated skills section"]
    },
    "contentAnalysis": {
      "score": 80,
      "strengthAreas": ["Strong quantifiable achievements", "Relevant experience"],
      "improvementAreas": ["Limited technical skills", "No certifications mentioned"],
      "recommendations": ["Highlight more technical competencies", "Include relevant certifications"]
    }
  },
  "prioritizedRecommendations": [
    {
      "priority": "high|medium|low",
      "category": "keywords|formatting|structure|content",
      "recommendation": "Specific recommendation",
      "implementation": "How to implement",
      "expectedImpact": "Expected improvement",
      "timeToImplement": "5 minutes|30 minutes|1 hour"
    }
  ]
}

Analysis Guidelines:
1. Score each category from 0-100
2. Overall ATS score is weighted average: keywords (40%), format (25%), structure (20%), content (15%)
3. Identify specific missing keywords if job description provided
4. Flag common ATS parsing issues (complex formatting, images, tables)
5. Recommend industry-standard section headers
6. Prioritize recommendations by impact and ease of implementation
7. Focus on actionable, specific improvements
`;
/**
 * Job matching analysis prompt
 */ const JOB_MATCHING_PROMPT = `
Analyze how well this resume matches the provided job description and provide detailed scoring.

Resume Data: {{RESUME_DATA}}
Job Description: {{JOB_DESCRIPTION}}
{{#if targetRole}}Target Role: {{targetRole}}{{/if}}
{{#if experienceLevel}}Experience Level: {{experienceLevel}}{{/if}}

Provide matching analysis in this JSON structure:
{
  "overallMatchScore": 78,
  "matchGrade": "B+",
  "analysis": {
    "skillsMatch": {
      "score": 85,
      "matchedSkills": [
        {
          "skill": "JavaScript",
          "resumeLevel": "advanced",
          "requiredLevel": "intermediate",
          "match": "exceeds"
        }
      ],
      "missingSkills": [
        {
          "skill": "Docker",
          "importance": "high|medium|low",
          "canLearn": true,
          "timeToLearn": "2-4 weeks"
        }
      ],
      "skillGapAnalysis": {
        "criticalGaps": ["Docker", "Kubernetes"],
        "niceToHaveGaps": ["GraphQL", "Redis"],
        "strengthAreas": ["Frontend development", "Team leadership"]
      }
    },
    "experienceMatch": {
      "score": 75,
      "yearsRequired": 5,
      "yearsCandidate": 6,
      "yearsMatch": "exceeds",
      "industryMatch": {
        "score": 80,
        "relevantIndustries": ["Technology", "E-commerce"],
        "transferableExperience": ["Project management", "Team leadership"]
      },
      "roleSimilarity": {
        "score": 85,
        "similarRoles": ["Senior Developer", "Technical Lead"],
        "levelMatch": "appropriate"
      }
    },
    "educationMatch": {
      "score": 90,
      "degreeMatch": true,
      "fieldRelevance": "high",
      "institutionPrestige": "good",
      "additionalQualifications": ["AWS Certification", "Scrum Master"]
    },
    "culturalFit": {
      "score": 70,
      "indicators": [
        "Team collaboration experience",
        "Startup environment familiarity",
        "Remote work experience"
      ],
      "concerns": ["Limited client-facing experience"],
      "strengths": ["Strong mentoring background"]
    }
  },
  "recommendations": [
    {
      "category": "skills|experience|education|presentation",
      "priority": "high|medium|low",
      "recommendation": "Learn Docker and containerization",
      "reasoning": "Critical skill gap for DevOps responsibilities",
      "resources": ["Docker documentation", "Online courses"],
      "timeframe": "2-4 weeks"
    }
  ],
  "interviewPreparation": [
    "Be ready to discuss Docker and containerization gaps",
    "Highlight your team leadership experience",
    "Prepare examples of scalable systems you've built"
  ]
}

Matching Guidelines:
1. Score each category from 0-100 based on alignment with job requirements
2. Overall match score: skills (35%), experience (30%), education (15%), cultural fit (20%)
3. Identify both hard and soft skill gaps
4. Consider transferable skills and learning potential
5. Provide specific, actionable recommendations
6. Include interview preparation suggestions
7. Account for career growth trajectory and potential
`;
/**
 * Industry-specific skills taxonomy and normalization
 */ const SKILLS_NORMALIZATION_PROMPT = `
Normalize and categorize these extracted skills using industry-standard terminology and frameworks.

Skills to normalize: {{SKILLS_LIST}}
Target Industry: {{TARGET_INDUSTRY}}
Experience Level: {{EXPERIENCE_LEVEL}}

Use these industry frameworks for normalization:
- Technology: SFIA (Skills Framework for the Information Age)
- General: O*NET occupational skills database
- European: ESCO (European Skills, Competences, and Occupations)

Return normalized skills in this JSON structure:
{
  "normalizedSkills": [
    {
      "originalSkill": "React.js",
      "normalizedSkill": "React (JavaScript Framework)",
      "category": "Frontend Development",
      "subcategory": "JavaScript Frameworks",
      "proficiencyLevel": "intermediate",
      "industryStandard": true,
      "frameworks": {
        "sfia": "PROG - Programming/Software Development - Level 4",
        "onet": "15-1252.00 - Software Developers, Applications",
        "esco": "2512.1 - Software developers"
      },
      "relatedSkills": ["JavaScript", "TypeScript", "Redux", "Next.js"],
      "marketDemand": "high",
      "salaryImpact": "positive",
      "learningPath": ["JavaScript basics", "React fundamentals", "Advanced patterns"]
    }
  ],
  "skillCategories": {
    "technical": ["React", "Node.js", "Python"],
    "soft": ["Leadership", "Communication", "Problem Solving"],
    "language": ["English", "Spanish"],
    "certification": ["AWS Certified", "PMP"],
    "tool": ["Git", "Docker", "Kubernetes"]
  },
  "industryAlignment": {
    "score": 85,
    "wellAlignedSkills": ["React", "Node.js", "AWS"],
    "missingIndustrySkills": ["Docker", "Kubernetes", "GraphQL"],
    "emergingSkills": ["Next.js", "Serverless", "Microservices"],
    "recommendations": [
      "Focus on containerization skills (Docker/Kubernetes)",
      "Add cloud-native development experience",
      "Consider learning GraphQL for modern APIs"
    ]
  }
}

Normalization Guidelines:
1. Use industry-standard terminology and spellings
2. Map skills to established frameworks (SFIA, O*NET, ESCO)
3. Categorize skills appropriately for the target industry
4. Identify skill relationships and prerequisites
5. Assess market demand and salary impact
6. Suggest learning paths for skill development
7. Highlight emerging and in-demand skills
`;
/**
 * Interview question generation prompt
 */ const INTERVIEW_QUESTIONS_PROMPT = `
Generate targeted interview questions based on this resume analysis and job context.

Resume Data: {{RESUME_DATA}}
{{#if jobDescription}}Job Description: {{jobDescription}}{{/if}}
{{#if targetRole}}Target Role: {{targetRole}}{{/if}}
{{#if experienceLevel}}Experience Level: {{experienceLevel}}{{/if}}

Generate questions in this JSON structure:
{
  "questionCategories": {
    "technical": [
      {
        "question": "Describe your experience with React and how you've used it in production applications.",
        "focus": "React expertise validation",
        "difficulty": "intermediate",
        "followUp": ["What challenges did you face?", "How did you optimize performance?"],
        "evaluationCriteria": ["Technical depth", "Real-world application", "Problem-solving approach"]
      }
    ],
    "behavioral": [
      {
        "question": "Tell me about a time when you had to lead a team through a challenging project.",
        "focus": "Leadership and project management",
        "difficulty": "intermediate",
        "framework": "STAR (Situation, Task, Action, Result)",
        "evaluationCriteria": ["Leadership style", "Communication", "Results orientation"]
      }
    ],
    "situational": [
      {
        "question": "How would you approach debugging a performance issue in a React application?",
        "focus": "Problem-solving methodology",
        "difficulty": "intermediate",
        "expectedApproach": "Systematic debugging process",
        "evaluationCriteria": ["Analytical thinking", "Technical knowledge", "Process orientation"]
      }
    ],
    "cultural": [
      {
        "question": "What motivates you in your work, and how do you handle remote collaboration?",
        "focus": "Cultural fit and work style",
        "difficulty": "basic",
        "evaluationCriteria": ["Self-motivation", "Communication style", "Collaboration skills"]
      }
    ]
  },
  "prioritizedQuestions": [
    {
      "priority": 1,
      "question": "Walk me through your most challenging technical project.",
      "category": "technical",
      "rationale": "Validates technical depth and problem-solving skills",
      "timeAllocation": "10-15 minutes"
    }
  ],
  "interviewFlow": {
    "warmup": ["Tell me about yourself", "What interests you about this role?"],
    "technical": ["Core technical competencies", "Problem-solving scenarios"],
    "behavioral": ["Past experiences", "Leadership situations"],
    "closing": ["Questions for us", "Next steps discussion"]
  },
  "redFlags": [
    "Inability to explain technical concepts clearly",
    "No specific examples of problem-solving",
    "Poor communication skills",
    "Lack of growth mindset"
  ],
  "strongIndicators": [
    "Clear technical explanations with examples",
    "Proactive problem-solving approach", 
    "Evidence of continuous learning",
    "Strong collaboration and communication skills"
  ]
}

Question Generation Guidelines:
1. Tailor questions to candidate's experience level and role requirements
2. Balance technical, behavioral, and cultural fit questions
3. Include follow-up questions for deeper exploration
4. Provide evaluation criteria for each question
5. Suggest interview flow and time allocation
6. Identify red flags and positive indicators
7. Generate 15-20 total questions across all categories
8. Focus on validating key skills and experiences from the resume
`;
/**
 * Resume improvement recommendations prompt
 */ const RESUME_IMPROVEMENT_PROMPT = `
Analyze this resume and provide specific, actionable improvement recommendations.

Resume Data: {{RESUME_DATA}}
{{#if jobDescription}}Target Job Description: {{jobDescription}}{{/if}}
{{#if targetIndustry}}Target Industry: {{targetIndustry}}{{/if}}

Provide improvement recommendations in this JSON structure:
{
  "overallAssessment": {
    "currentStrength": 75,
    "improvementPotential": 15,
    "targetStrength": 90,
    "keyStrengths": ["Strong technical background", "Clear career progression"],
    "majorWeaknesses": ["Limited quantifiable achievements", "Missing industry keywords"]
  },
  "sectionRecommendations": {
    "professionalSummary": {
      "currentStatus": "missing",
      "priority": "high",
      "recommendation": "Add a 2-3 sentence professional summary highlighting key value propositions",
      "example": "Senior Software Engineer with 6+ years building scalable web applications...",
      "impact": "Immediately communicates value to recruiters and ATS systems"
    },
    "experience": {
      "currentStatus": "good",
      "priority": "medium",
      "recommendations": [
        "Add more quantifiable achievements (percentages, dollar amounts, time saved)",
        "Use stronger action verbs (architected, optimized, delivered)",
        "Include team size and scope of responsibility"
      ],
      "examples": [
        "Before: Worked on improving application performance",
        "After: Optimized application performance by 40%, reducing load times from 3s to 1.8s"
      ]
    }
  },
  "contentImprovements": [
    {
      "category": "quantification",
      "priority": "high",
      "current": "Developed web applications",
      "improved": "Developed 5+ web applications serving 10,000+ users daily",
      "reasoning": "Specific metrics demonstrate scale and impact"
    }
  ],
  "formattingImprovements": [
    {
      "issue": "Inconsistent bullet point formatting",
      "priority": "medium",
      "solution": "Use consistent bullet points throughout",
      "impact": "Improves ATS parsing and visual consistency"
    }
  ],
  "keywordOptimization": [
    {
      "skill": "JavaScript",
      "currentUsage": 2,
      "recommendedUsage": 4,
      "contexts": ["Skills section", "Job descriptions", "Project details"],
      "naturalIntegration": "Mention JavaScript frameworks used in each role"
    }
  ],
  "implementationPlan": [
    {
      "phase": 1,
      "timeframe": "30 minutes",
      "tasks": [
        "Add professional summary",
        "Fix formatting inconsistencies",
        "Add missing contact information"
      ],
      "expectedImprovement": "10-15 point increase in ATS score"
    }
  ]
}

Improvement Guidelines:
1. Provide specific, actionable recommendations
2. Include before/after examples for clarity
3. Prioritize improvements by impact and effort
4. Focus on both ATS optimization and human readability
5. Suggest natural keyword integration
6. Provide implementation timeline and expected impact
7. Address both content and formatting issues
`;
/**
 * Helper function to format prompts with context variables
 */ function formatPrompt(template, context) {
    return template.replace(/\{\{(\w+)\}\}/g, (match, key)=>{
        return context[key] || match;
    });
}
/**
 * Helper function to format conditional sections in prompts
 */ function formatConditionalPrompt(template, context) {
    // Handle {{#if condition}} blocks with multiline support
    let formatted = template.replace(/\{\{#if (\w+)\}\}([\s\S]*?)\{\{\/if\}\}/g, (match, condition, content)=>{
        return context[condition] ? content : '';
    });
    // Handle regular variable substitution
    formatted = formatPrompt(formatted, context);
    return formatted.trim();
}
/**
 * Prompt template configurations for different use cases
 */ const PROMPT_CONFIGS = {
    basic_extraction: {
        template: RESUME_EXTRACTION_PROMPT,
        requiredContext: [
            'resumeText'
        ],
        optionalContext: [
            'targetRole',
            'companyName'
        ]
    },
    ats_optimization: {
        template: ATS_OPTIMIZATION_PROMPT,
        requiredContext: [
            'resumeData'
        ],
        optionalContext: [
            'jobDescription',
            'targetIndustry'
        ]
    },
    job_matching: {
        template: JOB_MATCHING_PROMPT,
        requiredContext: [
            'resumeData',
            'jobDescription'
        ],
        optionalContext: [
            'targetRole',
            'experienceLevel'
        ]
    },
    skills_normalization: {
        template: SKILLS_NORMALIZATION_PROMPT,
        requiredContext: [
            'skillsList'
        ],
        optionalContext: [
            'targetIndustry',
            'experienceLevel'
        ]
    },
    interview_questions: {
        template: INTERVIEW_QUESTIONS_PROMPT,
        requiredContext: [
            'resumeData'
        ],
        optionalContext: [
            'jobDescription',
            'targetRole',
            'experienceLevel'
        ]
    },
    resume_improvement: {
        template: RESUME_IMPROVEMENT_PROMPT,
        requiredContext: [
            'resumeData'
        ],
        optionalContext: [
            'jobDescription',
            'targetIndustry'
        ]
    }
};


/***/ }),

/***/ 91645:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

module.exports = require("events");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8384,8833,6716,8180,3969,5506,4633], () => (__webpack_exec__(36463)));
module.exports = __webpack_exports__;

})();