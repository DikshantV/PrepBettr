"use strict";
(() => {
var exports = {};
exports.id = 2481;
exports.ids = [2481];
exports.modules = {

/***/ 1708:
/***/ ((module) => {

module.exports = require("node:process");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 3674:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OPTIONS: () => (/* binding */ OPTIONS),
/* harmony export */   POST: () => (/* binding */ POST),
/* harmony export */   runtime: () => (/* binding */ runtime)
/* harmony export */ });
/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32190);
/* harmony import */ var _lib_services_enhanced_resume_processing_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7075);
/* harmony import */ var _lib_firebase_admin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(63969);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75931);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_enhanced_resume_processing_service__WEBPACK_IMPORTED_MODULE_1__]);
_lib_services_enhanced_resume_processing_service__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * ATS Optimization API - App Router Endpoint
 * 
 * POST /api/documents/optimize/ats
 * 
 * Provides ATS (Applicant Tracking System) optimization analysis and recommendations
 * for resumes. Can analyze existing resume data or process new documents.
 */ 



const runtime = 'nodejs';
/**
 * POST /api/documents/optimize/ats
 * ATS optimization analysis and recommendations
 */ async function POST(request) {
    const startTime = Date.now();
    try {
        console.log('🎯 ATS optimization API called');
        // Handle authentication
        const authHeader = request.headers.get('authorization');
        let currentUserId;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            const idToken = authHeader.split(' ')[1];
            const decodedToken = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_2__.verifyIdToken)(idToken);
            if (!decodedToken) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    success: false,
                    error: 'Unauthorized - Invalid token'
                }, {
                    status: 401
                });
            }
            currentUserId = decodedToken.uid;
        } else if (true) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: 'Unauthorized - No token provided'
            }, {
                status: 401
            });
        } else {}
        // Parse request data
        const isFormData = request.headers.get('content-type')?.includes('multipart/form-data');
        let userId;
        let file;
        let jobDescription;
        let options = {};
        if (isFormData) {
            // Handle file upload
            const formData = await request.formData();
            file = formData.get('file');
            jobDescription = formData.get('jobDescription');
            const optionsJson = formData.get('options');
            if (optionsJson) {
                try {
                    options = JSON.parse(optionsJson);
                } catch (parseError) {
                    console.warn('⚠️ Failed to parse options JSON:', parseError);
                }
            }
        } else {
            // Handle JSON request
            const body = await request.json();
            userId = body.userId;
            jobDescription = body.jobDescription;
            options = body.options || {};
        }
        // Set default options
        options = {
            includeKeywordDensity: true,
            includeFormatting: true,
            includeStructuralAnalysis: true,
            experienceLevel: 'mid',
            ...options
        };
        console.log(`📋 ATS optimization options:`, {
            hasFile: !!file,
            targetUserId: userId,
            hasJobDescription: !!jobDescription,
            ...options
        });
        let resumeData;
        // Get or process resume data
        if (file) {
            // Process new file upload
            const allowedTypes = [
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'text/plain'
            ];
            if (!allowedTypes.includes(file.type)) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    success: false,
                    error: 'Unsupported file type. Please upload PDF, DOCX, DOC, or TXT files.'
                }, {
                    status: 400
                });
            }
            const maxFileSize = 10 * 1024 * 1024; // 10MB
            if (file.size > maxFileSize) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    success: false,
                    error: 'File size exceeds 10MB limit. Please use a smaller file.'
                }, {
                    status: 400
                });
            }
            // Process file for ATS analysis only
            const fileBuffer = Buffer.from(await file.arrayBuffer());
            const result = await _lib_services_enhanced_resume_processing_service__WEBPACK_IMPORTED_MODULE_1__/* .enhancedResumeProcessingService */ .o.processResume(currentUserId, fileBuffer, file.name, file.type, file.size, {
                generateQuestions: false,
                includeAtsAnalysis: true,
                includeJobMatching: !!jobDescription,
                jobDescription
            });
            if (!result.success || !result.data) {
                throw new Error(result.error || 'Failed to process resume for ATS analysis');
            }
            resumeData = result.data.extractedData;
        } else if (userId) {
            // Use existing resume data
            const targetUserId = userId || currentUserId;
            const existingData = await _lib_services_enhanced_resume_processing_service__WEBPACK_IMPORTED_MODULE_1__/* .enhancedResumeProcessingService */ .o.getUserResumeData(targetUserId);
            if (!existingData) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    success: false,
                    error: 'No resume found for the specified user'
                }, {
                    status: 404
                });
            }
            resumeData = existingData.extractedData;
        } else {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: 'Either provide a file to analyze or specify a userId for existing resume'
            }, {
                status: 400
            });
        }
        // Perform comprehensive ATS analysis
        const atsAnalysis = await performComprehensiveATSAnalysis(resumeData, jobDescription, options);
        const totalTime = Date.now() - startTime;
        console.log(`✅ ATS optimization analysis completed in ${totalTime}ms`);
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: true,
            data: {
                ...atsAnalysis,
                processingTime: totalTime,
                lastAnalyzed: new Date().toISOString()
            },
            message: 'ATS optimization analysis completed successfully'
        });
    } catch (error) {
        const totalTime = Date.now() - startTime;
        console.error(`❌ ATS optimization API error (${totalTime}ms):`, error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        (0,_lib_errors__WEBPACK_IMPORTED_MODULE_3__/* .logServerError */ .wh)(error, {
            service: 'ats-optimization-api',
            action: 'analyze'
        }, {
            processingTime: totalTime
        });
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: false,
            error: 'Failed to perform ATS optimization analysis',
            message:  false ? 0 : undefined
        }, {
            status: 500
        });
    }
}
/**
 * Perform comprehensive ATS analysis
 */ async function performComprehensiveATSAnalysis(resumeData, jobDescription, options = {}) {
    // Extract text content for analysis
    const resumeText = extractResumeText(resumeData);
    // 1. Keyword Analysis
    const keywordAnalysis = analyzeKeywords(resumeText, jobDescription, options);
    // 2. Format Analysis  
    const formatAnalysis = analyzeFormat(resumeData, options);
    // 3. Structural Analysis
    const structuralAnalysis = analyzeStructure(resumeData, options);
    // 4. Industry Alignment (if specified)
    const industryAlignment = options.targetIndustry ? analyzeIndustryAlignment(resumeData, options.targetIndustry, options.experienceLevel) : undefined;
    // Calculate overall ATS score
    const atsScore = calculateOverallATSScore({
        keywordAnalysis,
        formatAnalysis,
        structuralAnalysis,
        industryAlignment
    });
    // Determine grade
    const overallGrade = getGradeFromScore(atsScore);
    // Generate improvement recommendations
    const improvements = generateImprovementRecommendations({
        keywordAnalysis,
        formatAnalysis,
        structuralAnalysis,
        industryAlignment,
        atsScore
    });
    return {
        atsScore,
        overallGrade,
        keywordAnalysis,
        formatAnalysis,
        structuralAnalysis,
        industryAlignment,
        improvements
    };
}
/**
 * Extract text content from resume data
 */ function extractResumeText(resumeData) {
    if (!resumeData) return '';
    let text = '';
    // Handle Foundry extraction format
    if (resumeData.personalInfo && typeof resumeData.personalInfo === 'object') {
        // Extract from Foundry format
        if (resumeData.personalInfo.name?.content) text += resumeData.personalInfo.name.content + ' ';
        if (resumeData.personalInfo.email?.content) text += resumeData.personalInfo.email.content + ' ';
        if (resumeData.skills) {
            text += resumeData.skills.map((s)=>s.skill || s).join(' ') + ' ';
        }
        if (resumeData.experience) {
            resumeData.experience.forEach((exp)=>{
                text += (exp.company?.content || exp.company || '') + ' ';
                text += (exp.position?.content || exp.position || '') + ' ';
                text += (exp.description?.content || exp.description || '') + ' ';
            });
        }
    } else {
        // Handle legacy format
        if (resumeData.personalInfo?.name) text += resumeData.personalInfo.name + ' ';
        if (resumeData.personalInfo?.email) text += resumeData.personalInfo.email + ' ';
        if (resumeData.skills) {
            text += resumeData.skills.join(' ') + ' ';
        }
        if (resumeData.experience) {
            resumeData.experience.forEach((exp)=>{
                text += (exp.company || '') + ' ';
                text += (exp.position || '') + ' ';
                text += (exp.description || '') + ' ';
            });
        }
    }
    return text;
}
/**
 * Analyze keywords and density
 */ function analyzeKeywords(resumeText, jobDescription, options = {}) {
    const resumeWords = extractWords(resumeText);
    if (jobDescription) {
        const jobWords = extractWords(jobDescription);
        const jobKeywords = extractKeywords(jobWords);
        const matchedKeywords = jobKeywords.filter((keyword)=>resumeWords.some((word)=>word.toLowerCase().includes(keyword.toLowerCase())));
        const missingKeywords = jobKeywords.filter((keyword)=>!matchedKeywords.includes(keyword));
        const keywordDensity = matchedKeywords.length / jobKeywords.length;
        return {
            totalKeywords: jobKeywords.length,
            matchedKeywords,
            missingKeywords: missingKeywords.slice(0, 10),
            keywordDensity,
            recommendations: generateKeywordRecommendations(missingKeywords, keywordDensity)
        };
    } else {
        // Generic keyword analysis
        const keywords = extractKeywords(resumeWords);
        return {
            totalKeywords: keywords.length,
            matchedKeywords: keywords,
            missingKeywords: [],
            keywordDensity: 1.0,
            recommendations: [
                'Provide a job description for targeted keyword analysis'
            ]
        };
    }
}
/**
 * Analyze resume format for ATS compatibility
 */ function analyzeFormat(resumeData, options = {}) {
    const issues = [];
    let score = 100;
    // Check for common ATS issues
    if (!resumeData.personalInfo?.email) {
        issues.push({
            type: 'critical',
            issue: 'Missing email address',
            solution: 'Add a professional email address in the contact section',
            impact: 'ATS systems require contact information to process applications'
        });
        score -= 20;
    }
    if (!resumeData.personalInfo?.phone) {
        issues.push({
            type: 'warning',
            issue: 'Missing phone number',
            solution: 'Add your phone number for recruiter contact',
            impact: 'Recruiters may not be able to reach you quickly'
        });
        score -= 10;
    }
    if (!resumeData.skills || resumeData.skills.length < 5) {
        issues.push({
            type: 'warning',
            issue: 'Limited skills section',
            solution: 'Add more relevant technical and soft skills',
            impact: 'ATS systems heavily weight skill keywords for matching'
        });
        score -= 15;
    }
    // Check document structure
    const hasHeaders = resumeData.metadata?.documentStructure?.hasHeaders;
    if (!hasHeaders) {
        issues.push({
            type: 'suggestion',
            issue: 'Unclear section headers',
            solution: 'Use clear, standard section headers like "Experience", "Education", "Skills"',
            impact: 'ATS systems rely on section headers to categorize information'
        });
        score -= 5;
    }
    return {
        score: Math.max(0, score),
        issues
    };
}
/**
 * Analyze resume structure
 */ function analyzeStructure(resumeData, options = {}) {
    const recommendations = [];
    let score = 100;
    const hasContactInfo = !!(resumeData.personalInfo?.email || resumeData.personalInfo?.phone);
    const hasProfessionalSummary = !!resumeData.summary;
    const hasWorkExperience = resumeData.experience && resumeData.experience.length > 0;
    const hasEducation = resumeData.education && resumeData.education.length > 0;
    const hasSkillsSection = resumeData.skills && resumeData.skills.length > 0;
    if (!hasContactInfo) {
        recommendations.push('Add complete contact information including email and phone');
        score -= 20;
    }
    if (!hasProfessionalSummary) {
        recommendations.push('Include a professional summary to highlight your value proposition');
        score -= 15;
    }
    if (!hasWorkExperience) {
        recommendations.push('Add relevant work experience with specific achievements');
        score -= 25;
    }
    if (!hasEducation) {
        recommendations.push('Include your educational background');
        score -= 10;
    }
    if (!hasSkillsSection) {
        recommendations.push('Create a dedicated skills section with relevant keywords');
        score -= 20;
    }
    return {
        score: Math.max(0, score),
        hasContactInfo,
        hasProfessionalSummary,
        hasWorkExperience,
        hasEducation,
        hasSkillsSection,
        recommendations
    };
}
/**
 * Analyze industry alignment
 */ function analyzeIndustryAlignment(resumeData, targetIndustry, experienceLevel) {
    // Industry-specific keywords database (simplified)
    const industryKeywords = {
        'technology': [
            'javascript',
            'python',
            'cloud',
            'api',
            'database',
            'agile',
            'devops'
        ],
        'healthcare': [
            'patient care',
            'medical',
            'clinical',
            'hipaa',
            'healthcare',
            'treatment'
        ],
        'finance': [
            'financial analysis',
            'risk management',
            'compliance',
            'accounting',
            'investment'
        ],
        'marketing': [
            'digital marketing',
            'seo',
            'social media',
            'analytics',
            'campaign',
            'brand'
        ]
    };
    const keywords = industryKeywords[targetIndustry.toLowerCase()] || [];
    const resumeText = extractResumeText(resumeData).toLowerCase();
    const relevantSkills = keywords.filter((keyword)=>resumeText.includes(keyword));
    const suggestedSkills = keywords.filter((keyword)=>!resumeText.includes(keyword)).slice(0, 5);
    const score = keywords.length > 0 ? relevantSkills.length / keywords.length * 100 : 50;
    return {
        score,
        relevantSkills,
        suggestedSkills,
        industryKeywords: keywords
    };
}
/**
 * Calculate overall ATS score
 */ function calculateOverallATSScore(analysis) {
    const weights = {
        keyword: 0.4,
        format: 0.3,
        structure: 0.2,
        industry: 0.1
    };
    let score = 0;
    score += analysis.keywordAnalysis.keywordDensity * 100 * weights.keyword;
    score += analysis.formatAnalysis.score * weights.format;
    score += analysis.structuralAnalysis.score * weights.structure;
    if (analysis.industryAlignment) {
        score += analysis.industryAlignment.score * weights.industry;
    } else {
        // Redistribute industry weight to other factors
        score += analysis.formatAnalysis.score * weights.industry;
    }
    return Math.round(Math.max(0, Math.min(100, score)));
}
/**
 * Convert score to letter grade
 */ function getGradeFromScore(score) {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
}
/**
 * Generate improvement recommendations
 */ function generateImprovementRecommendations(analysis) {
    const improvements = [];
    // Keyword improvements
    if (analysis.keywordAnalysis.keywordDensity < 0.5) {
        improvements.push({
            priority: 'high',
            category: 'keywords',
            description: 'Increase keyword density by including more relevant terms from the job description',
            implementation: `Add these missing keywords: ${analysis.keywordAnalysis.missingKeywords.slice(0, 5).join(', ')}`,
            expectedImpact: 'Significantly improve ATS matching and visibility to recruiters'
        });
    }
    // Format improvements
    if (analysis.formatAnalysis.score < 80) {
        improvements.push({
            priority: 'high',
            category: 'formatting',
            description: 'Address critical formatting issues for better ATS parsing',
            implementation: 'Fix the formatting issues identified in the analysis',
            expectedImpact: 'Ensure ATS systems can properly read and categorize your information'
        });
    }
    // Structure improvements
    if (analysis.structuralAnalysis.score < 70) {
        improvements.push({
            priority: 'medium',
            category: 'structure',
            description: 'Improve resume structure with missing essential sections',
            implementation: analysis.structuralAnalysis.recommendations.join('; '),
            expectedImpact: 'Create a more complete professional profile for ATS systems'
        });
    }
    // Industry alignment improvements
    if (analysis.industryAlignment && analysis.industryAlignment.score < 60) {
        improvements.push({
            priority: 'medium',
            category: 'content',
            description: 'Enhance industry-specific content and keywords',
            implementation: `Consider adding these industry keywords: ${analysis.industryAlignment.suggestedSkills.join(', ')}`,
            expectedImpact: 'Better alignment with industry expectations and job requirements'
        });
    }
    return improvements;
}
// Helper functions
function extractWords(text) {
    return text.toLowerCase().replace(/[^\w\s]/g, ' ').split(/\s+/).filter((word)=>word.length > 2);
}
function extractKeywords(words) {
    const stopWords = new Set([
        'the',
        'and',
        'or',
        'but',
        'in',
        'on',
        'at',
        'to',
        'for',
        'of',
        'with',
        'by'
    ]);
    const wordCount = {};
    words.forEach((word)=>{
        if (!stopWords.has(word)) {
            wordCount[word] = (wordCount[word] || 0) + 1;
        }
    });
    return Object.entries(wordCount).sort((a, b)=>b[1] - a[1]).slice(0, 20).map(([word])=>word);
}
function generateKeywordRecommendations(missingKeywords, density) {
    const recommendations = [];
    if (density < 0.3) {
        recommendations.push('Keyword density is low. Consider incorporating more job-relevant terms throughout your resume.');
    }
    if (missingKeywords.length > 5) {
        recommendations.push(`High number of missing keywords (${missingKeywords.length}). Focus on adding the most relevant ones to your experience descriptions.`);
    }
    if (missingKeywords.length > 0) {
        recommendations.push(`Consider adding these keywords naturally: ${missingKeywords.slice(0, 3).join(', ')}`);
    }
    return recommendations;
}
/**
 * OPTIONS handler for CORS
 */ async function OPTIONS(request) {
    return new next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse(null, {
        status: 200,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4573:
/***/ ((module) => {

module.exports = require("node:buffer");

/***/ }),

/***/ 7879:
/***/ ((module) => {

module.exports = import("firebase-admin/firestore");;

/***/ }),

/***/ 10756:
/***/ ((module) => {

module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 11997:
/***/ ((module) => {

module.exports = require("punycode");

/***/ }),

/***/ 12412:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 12519:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patchFetch: () => (/* binding */ patchFetch),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),
/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96559);
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37719);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Users_dikshantvashistha_PrepBettr_app_api_documents_optimize_ats_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3674);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_dikshantvashistha_PrepBettr_app_api_documents_optimize_ats_route_ts__WEBPACK_IMPORTED_MODULE_3__]);
_Users_dikshantvashistha_PrepBettr_app_api_documents_optimize_ats_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,
        page: "/api/documents/optimize/ats/route",
        pathname: "/api/documents/optimize/ats",
        filename: "route",
        bundlePath: "app/api/documents/optimize/ats/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/documents/optimize/ats/route.ts",
    nextConfigOutput,
    userland: _Users_dikshantvashistha_PrepBettr_app_api_documents_optimize_ats_route_ts__WEBPACK_IMPORTED_MODULE_3__
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 14737:
/***/ ((module) => {

module.exports = import("@azure/storage-blob");;

/***/ }),

/***/ 16141:
/***/ ((module) => {

module.exports = require("node:zlib");

/***/ }),

/***/ 16446:
/***/ ((module) => {

module.exports = import("@azure/app-configuration");;

/***/ }),

/***/ 19771:
/***/ ((module) => {

module.exports = require("process");

/***/ }),

/***/ 21820:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 26231:
/***/ ((module) => {

module.exports = require("applicationinsights");

/***/ }),

/***/ 27910:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 35672:
/***/ ((module) => {

module.exports = require("@azure/msal-node");

/***/ }),

/***/ 36695:
/***/ ((module) => {

module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37067:
/***/ ((module) => {

module.exports = require("node:http");

/***/ }),

/***/ 37366:
/***/ ((module) => {

module.exports = require("dns");

/***/ }),

/***/ 44708:
/***/ ((module) => {

module.exports = require("node:https");

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 46602:
/***/ ((module) => {

module.exports = import("@azure/cosmos");;

/***/ }),

/***/ 46675:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 48161:
/***/ ((module) => {

module.exports = require("node:os");

/***/ }),

/***/ 51455:
/***/ ((module) => {

module.exports = require("node:fs/promises");

/***/ }),

/***/ 53802:
/***/ ((module) => {

module.exports = require("node:child_process");

/***/ }),

/***/ 55511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 55591:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 57075:
/***/ ((module) => {

module.exports = require("node:stream");

/***/ }),

/***/ 57975:
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ 62201:
/***/ ((module) => {

module.exports = require("@azure/keyvault-secrets");

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 73024:
/***/ ((module) => {

module.exports = require("node:fs");

/***/ }),

/***/ 73136:
/***/ ((module) => {

module.exports = require("node:url");

/***/ }),

/***/ 73496:
/***/ ((module) => {

module.exports = require("http2");

/***/ }),

/***/ 74075:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 76760:
/***/ ((module) => {

module.exports = require("node:path");

/***/ }),

/***/ 77598:
/***/ ((module) => {

module.exports = require("node:crypto");

/***/ }),

/***/ 79551:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 79646:
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),

/***/ 81630:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 83997:
/***/ ((module) => {

module.exports = require("tty");

/***/ }),

/***/ 91645:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

module.exports = require("events");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8384,6716,8180,3969,4633,7075], () => (__webpack_exec__(12519)));
module.exports = __webpack_exports__;

})();