(() => {
var exports = {};
exports.id = 2772;
exports.ids = [2772];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 8865:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/health/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
;// ./app/api/health/route.ts

async function checkFirebaseHealth() {
    try {
        const response = await fetch(`${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/api/health/firebase`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        if (!response.ok) {
            return {
                service: 'firebase',
                status: 'unhealthy',
                timestamp: new Date().toISOString(),
                details: {
                    error: `HTTP ${response.status}`
                }
            };
        }
        const data = await response.json();
        return {
            service: 'firebase',
            status: data.status === 'healthy' ? 'healthy' : 'unhealthy',
            timestamp: new Date().toISOString(),
            details: data.details
        };
    } catch (error) {
        return {
            service: 'firebase',
            status: 'unhealthy',
            timestamp: new Date().toISOString(),
            details: {
                error: error instanceof Error ? error.message : 'Unknown error'
            }
        };
    }
}
async function checkDatabaseHealth() {
    // For now, return healthy - can be expanded to check actual database connections
    return {
        service: 'database',
        status: 'healthy',
        timestamp: new Date().toISOString(),
        details: {
            note: 'Basic health check - no database connectivity test implemented'
        }
    };
}
async function checkSystemHealth() {
    const memoryUsage = process.memoryUsage();
    const uptime = process.uptime();
    // Simple memory health check - consider degraded if using > 80% of heap
    const memoryUsagePercent = memoryUsage.heapUsed / memoryUsage.heapTotal * 100;
    const status = memoryUsagePercent > 80 ? 'degraded' : 'healthy';
    return {
        service: 'system',
        status,
        timestamp: new Date().toISOString(),
        details: {
            uptime: Math.round(uptime),
            memory: {
                used: Math.round(memoryUsage.heapUsed / 1024 / 1024),
                total: Math.round(memoryUsage.heapTotal / 1024 / 1024),
                percentage: Math.round(memoryUsagePercent),
                unit: 'MB'
            }
        }
    };
}
async function GET() {
    try {
        console.log('🏥 General health check requested');
        // Check all services in parallel
        const [firebaseHealth, databaseHealth, systemHealth] = await Promise.all([
            checkFirebaseHealth(),
            checkDatabaseHealth(),
            checkSystemHealth()
        ]);
        const services = {
            firebase: firebaseHealth,
            database: databaseHealth,
            system: systemHealth
        };
        // Calculate summary
        const serviceStatuses = Object.values(services);
        const summary = {
            total: serviceStatuses.length,
            healthy: serviceStatuses.filter((s)=>s.status === 'healthy').length,
            unhealthy: serviceStatuses.filter((s)=>s.status === 'unhealthy').length,
            degraded: serviceStatuses.filter((s)=>s.status === 'degraded').length
        };
        // Determine overall status
        let overallStatus;
        if (summary.unhealthy > 0) {
            overallStatus = 'unhealthy';
        } else if (summary.degraded > 0) {
            overallStatus = 'degraded';
        } else {
            overallStatus = 'healthy';
        }
        const response = {
            status: overallStatus,
            timestamp: new Date().toISOString(),
            services,
            summary
        };
        console.log('🏥 General health check result:', {
            status: overallStatus,
            summary
        });
        // Return appropriate HTTP status
        const httpStatus = overallStatus === 'healthy' ? 200 : overallStatus === 'degraded' ? 200 : 503;
        return server.NextResponse.json(response, {
            status: httpStatus,
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache'
            }
        });
    } catch (error) {
        console.error('❌ General health check failed:', error);
        return server.NextResponse.json({
            status: 'unhealthy',
            timestamp: new Date().toISOString(),
            services: {},
            summary: {
                total: 0,
                healthy: 0,
                unhealthy: 1,
                degraded: 0
            },
            error: error instanceof Error ? error.message : 'Unknown error'
        }, {
            status: 503,
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache'
            }
        });
    }
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fhealth%2Froute&name=app%2Fapi%2Fhealth%2Froute&pagePath=private-next-app-dir%2Fapi%2Fhealth%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Fhealth%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/health/route",
        pathname: "/api/health",
        filename: "route",
        bundlePath: "app/api/health/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/health/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 44870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 96559:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (false) {} else {
    if (false) {} else {
        if (false) {} else {
            if (false) {} else {
                module.exports = __webpack_require__(44870);
            }
        }
    }
}

//# sourceMappingURL=module.compiled.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80], () => (__webpack_exec__(8865)));
module.exports = __webpack_exports__;

})();