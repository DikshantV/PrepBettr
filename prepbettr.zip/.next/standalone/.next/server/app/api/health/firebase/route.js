(() => {
var exports = {};
exports.id = 5824;
exports.ids = [5824];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 44870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 46675:
/***/ ((module) => {

"use strict";
module.exports = require("firebase-admin");

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 77311:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/health/firebase/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
// EXTERNAL MODULE: ./lib/services/firebase-user-service.ts
var firebase_user_service = __webpack_require__(88410);
;// ./app/api/health/firebase/route.ts


async function GET() {
    try {
        console.log('🏥 Firebase health check requested');
        // Perform comprehensive health check
        const healthResult = await firebase_user_service/* firebaseUserService */.a.healthCheck();
        const response = {
            service: 'firebase',
            timestamp: new Date().toISOString(),
            status: healthResult.healthy ? 'healthy' : 'unhealthy',
            details: healthResult.details
        };
        console.log('🏥 Firebase health check result:', response);
        return server.NextResponse.json(response, {
            status: healthResult.healthy ? 200 : 503,
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache'
            }
        });
    } catch (error) {
        console.error('❌ Firebase health check failed:', error);
        return server.NextResponse.json({
            service: 'firebase',
            timestamp: new Date().toISOString(),
            status: 'error',
            error: error instanceof Error ? error.message : 'Unknown error',
            details: {
                firebaseAuth: 'error',
                firestore: 'error'
            }
        }, {
            status: 503,
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache'
            }
        });
    }
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fhealth%2Ffirebase%2Froute&name=app%2Fapi%2Fhealth%2Ffirebase%2Froute&pagePath=private-next-app-dir%2Fapi%2Fhealth%2Ffirebase%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Fhealth%2Ffirebase%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/health/firebase/route",
        pathname: "/api/health/firebase",
        filename: "route",
        bundlePath: "app/api/health/firebase/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/health/firebase/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 88410:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ firebaseUserService)
/* harmony export */ });
/* harmony import */ var _lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63969);
/**
 * Firebase User Service - Real Implementation
 * 
 * Handles user profile management using Firebase Authentication and Firestore
 * This is the single source of truth for user identity and profiles
 */ 
class FirebaseUserService {
    static getInstance() {
        if (!FirebaseUserService.instance) {
            FirebaseUserService.instance = new FirebaseUserService();
        }
        return FirebaseUserService.instance;
    }
    /**
   * Get user profile from Firestore
   */ async getUserProfile(uid) {
        try {
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            const userDoc = await firestore.collection('users').doc(uid).get();
            if (!userDoc.exists) {
                console.log(`User profile not found for uid: ${uid}`);
                return null;
            }
            const data = userDoc.data();
            if (!data) {
                console.log(`User profile data is empty for uid: ${uid}`);
                return null;
            }
            // Convert Firestore timestamps to Date objects (handle both Firestore Timestamp and regular dates)
            const profile = {
                uid,
                email: data.email,
                displayName: data.displayName,
                profilePictureUrl: data.profilePictureUrl,
                phoneNumber: data.phoneNumber,
                emailVerified: data.emailVerified || false,
                plan: data.plan || 'free',
                createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : data.createdAt ? new Date(data.createdAt) : new Date(),
                updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : data.updatedAt ? new Date(data.updatedAt) : new Date(),
                about: data.about,
                workplace: data.workplace,
                skills: data.skills || [],
                dateOfBirth: data.dateOfBirth
            };
            console.log(`✅ Retrieved user profile for uid: ${uid}`);
            return profile;
        } catch (error) {
            console.error(`❌ Failed to get user profile for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Create user profile in Firestore
   */ async createUserProfile(uid, userData) {
        try {
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            const now = new Date();
            const profileData = {
                email: userData.email,
                displayName: userData.displayName || userData.email.split('@')[0],
                profilePictureUrl: undefined,
                phoneNumber: userData.phoneNumber || undefined,
                emailVerified: userData.emailVerified || false,
                plan: userData.plan || 'free',
                createdAt: now,
                updatedAt: now,
                about: undefined,
                workplace: undefined,
                skills: [],
                dateOfBirth: undefined
            };
            await firestore.collection('users').doc(uid).set(profileData);
            console.log(`✅ Created user profile for uid: ${uid}, email: ${userData.email}`);
            return {
                uid,
                ...profileData,
                skills: profileData.skills || []
            };
        } catch (error) {
            console.error(`❌ Failed to create user profile for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Update user profile in Firestore
   */ async updateUserProfile(uid, updates) {
        try {
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            // Remove uid from updates to prevent overwriting document ID
            const { uid: _, ...updateData } = updates;
            const updatePayload = {
                ...updateData,
                updatedAt: new Date()
            };
            await firestore.collection('users').doc(uid).update(updatePayload);
            console.log(`✅ Updated user profile for uid: ${uid}`);
        } catch (error) {
            console.error(`❌ Failed to update user profile for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Ensure user profile exists - create if not found
   */ async ensureUserProfile(uid, userData) {
        try {
            // First, try to get existing profile
            const existingProfile = await this.getUserProfile(uid);
            if (existingProfile) {
                console.log(`🔄 User profile already exists for uid: ${uid}`);
                return existingProfile;
            }
            // If not found, create new profile
            console.log(`🆕 Creating new user profile for uid: ${uid}`);
            return await this.createUserProfile(uid, userData);
        } catch (error) {
            console.error(`❌ Failed to ensure user profile for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Get Firebase Auth user record
   */ async getAuthUser(uid) {
        try {
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            const userRecord = await auth.getUser(uid);
            console.log(`✅ Retrieved Firebase Auth user for uid: ${uid}`);
            return userRecord;
        } catch (error) {
            console.error(`❌ Failed to get Firebase Auth user for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Create Firebase Auth user (for email/password signup)
   */ async createAuthUser(userData) {
        try {
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            const userRecord = await auth.createUser({
                email: userData.email,
                password: userData.password,
                displayName: userData.displayName,
                phoneNumber: userData.phoneNumber,
                emailVerified: userData.emailVerified || false
            });
            console.log(`✅ Created Firebase Auth user for email: ${userData.email}, uid: ${userRecord.uid}`);
            return userRecord;
        } catch (error) {
            console.error(`❌ Failed to create Firebase Auth user for email: ${userData.email}`, error);
            throw error;
        }
    }
    /**
   * Sign in with email and password (create custom token)
   */ async signInWithEmailAndPassword(email, password) {
        try {
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            // In a real implementation, you'd verify the password against Firebase Auth
            // For now, we'll create a custom token for the user
            const userRecord = await auth.getUserByEmail(email);
            const customToken = await auth.createCustomToken(userRecord.uid);
            console.log(`✅ Created custom token for email: ${email}, uid: ${userRecord.uid}`);
            return {
                user: {
                    uid: userRecord.uid,
                    email: userRecord.email,
                    displayName: userRecord.displayName,
                    emailVerified: userRecord.emailVerified
                },
                token: customToken
            };
        } catch (error) {
            console.error(`❌ Failed to sign in with email: ${email}`, error);
            throw error;
        }
    }
    /**
   * Delete user profile and auth record
   */ async deleteUser(uid) {
        try {
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            // Delete Firestore profile
            await firestore.collection('users').doc(uid).delete();
            // Delete Firebase Auth user
            await auth.deleteUser(uid);
            console.log(`✅ Deleted user completely for uid: ${uid}`);
        } catch (error) {
            console.error(`❌ Failed to delete user for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Health check - verify Firebase connections
   */ async healthCheck() {
        const details = {};
        let healthy = true;
        try {
            // Test Firebase Auth connection
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            await auth.getUser('test-user-id').catch(()=>{
            // Expected to fail, just testing connectivity
            });
            details.firebaseAuth = 'connected';
        } catch (error) {
            details.firebaseAuth = `error: ${error instanceof Error ? error.message : 'Unknown error'}`;
            healthy = false;
        }
        try {
            // Test Firestore connection
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            await firestore.collection('users').limit(1).get();
            details.firestore = 'connected';
        } catch (error) {
            details.firestore = `error: ${error instanceof Error ? error.message : 'Unknown error'}`;
            healthy = false;
        }
        return {
            healthy,
            details
        };
    }
}
// Export singleton instance
const firebaseUserService = FirebaseUserService.getInstance();
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (firebaseUserService)));


/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 96559:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (false) {} else {
    if (false) {} else {
        if (false) {} else {
            if (false) {} else {
                module.exports = __webpack_require__(44870);
            }
        }
    }
}

//# sourceMappingURL=module.compiled.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,3969], () => (__webpack_exec__(77311)));
module.exports = __webpack_exports__;

})();