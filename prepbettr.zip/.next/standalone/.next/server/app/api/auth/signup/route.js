(() => {
var exports = {};
exports.id = 8887;
exports.ids = [8887];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 21542:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/auth/signup/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
// EXTERNAL MODULE: ./node_modules/next/dist/api/headers.js
var headers = __webpack_require__(44999);
// EXTERNAL MODULE: ./lib/middleware/authMiddleware.ts
var authMiddleware = __webpack_require__(73701);
// EXTERNAL MODULE: ./lib/services/firebase-user-service.ts
var firebase_user_service = __webpack_require__(88410);
;// ./app/api/auth/signup/route.ts




const SESSION_COOKIE_NAME = 'session';
const SESSION_DURATION_S = 7 * 24 * 60 * 60; // 7 days
async function POST(request) {
    const timestamp = new Date().toISOString();
    console.log(`🆕 [${timestamp}] AUTH SIGNUP POST called`);
    try {
        const { email, password, name, idToken } = await request.json();
        console.log(`🆕 [${timestamp}] Signup request details:`, {
            hasEmail: !!email,
            hasPassword: !!password,
            hasName: !!name,
            hasIdToken: !!idToken,
            idTokenPrefix: idToken ? idToken.substring(0, 50) + '...' : 'none'
        });
        if (!email) {
            return server.NextResponse.json({
                error: 'Email is required'
            }, {
                status: 400
            });
        }
        let authResult;
        let sessionToken = idToken;
        let isNewUser = false;
        if (idToken) {
            // Handle Firebase ID token flow (for Google Sign-in)
            console.log(`🔐 [${timestamp}] Verifying Firebase ID token for Google Sign-up`);
            console.log(`🔐 [${timestamp}] ID Token format check:`, {
                length: idToken.length,
                parts: idToken.split('.').length,
                startsCorrectly: idToken.startsWith('eyJ'),
                preview: idToken.substring(0, 100) + '...'
            });
            try {
                authResult = await (0,authMiddleware/* verifyFirebaseToken */.W)(idToken);
                console.log(`🔐 [${timestamp}] Firebase token verification result:`, {
                    success: authResult.success,
                    hasUser: !!authResult.user,
                    uid: authResult.user?.uid,
                    error: authResult.error
                });
            } catch (verifyError) {
                console.error(`🔐 [${timestamp}] Firebase token verification threw error:`, verifyError);
                authResult = {
                    success: false,
                    user: null,
                    error: verifyError instanceof Error ? verifyError.message : 'Token verification failed'
                };
            }
            if (!authResult.success || !authResult.user) {
                console.error(`❌ [${timestamp}] Firebase ID token verification failed:`, {
                    error: authResult.error,
                    success: authResult.success,
                    hasUser: !!authResult.user
                });
                return server.NextResponse.json({
                    error: `Invalid ID token: ${authResult.error}`
                }, {
                    status: 401
                });
            }
            console.log(`✅ [${timestamp}] Firebase ID token verified for uid: ${authResult.user.uid}`);
            console.log(`✅ [${timestamp}] Token claims:`, {
                email: authResult.user.email,
                name: authResult.user.name,
                emailVerified: authResult.user.email_verified
            });
        // For Google sign-in, user already exists in Firebase Auth
        // We just need to ensure the profile exists in Firestore
        } else if (password) {
            // Handle email/password flow - create new Firebase Auth user
            console.log(`🆕 Creating new Firebase Auth user for: ${email}`);
            try {
                const newUserRecord = await firebase_user_service/* firebaseUserService */.a.createAuthUser({
                    email,
                    password,
                    displayName: name,
                    emailVerified: false
                });
                authResult = {
                    success: true,
                    user: {
                        uid: newUserRecord.uid,
                        email: newUserRecord.email,
                        name: newUserRecord.displayName || name,
                        email_verified: newUserRecord.emailVerified
                    }
                };
                // Create a custom token for the new user
                const auth = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 63969)).then((m)=>m.getAdminAuth());
                sessionToken = await auth.createCustomToken(newUserRecord.uid);
                isNewUser = true;
                console.log(`✅ Firebase Auth user created for uid: ${authResult.user.uid}`);
            } catch (error) {
                console.error('❌ Firebase Auth user creation failed:', error);
                // Handle specific Firebase Auth errors
                if (error.code === 'auth/email-already-exists') {
                    return server.NextResponse.json({
                        error: 'Email already in use'
                    }, {
                        status: 409
                    });
                }
                return server.NextResponse.json({
                    error: 'Failed to create account'
                }, {
                    status: 400
                });
            }
        } else {
            return server.NextResponse.json({
                error: 'Password or ID token is required'
            }, {
                status: 400
            });
        }
        if (!authResult.user || !authResult.user.uid) {
            console.error('❌ Authentication failed - no user data');
            return server.NextResponse.json({
                error: 'Authentication failed'
            }, {
                status: 401
            });
        }
        try {
            // Check if user profile already exists in Firestore
            console.log(`🔍 Checking if user profile exists for uid: ${authResult.user.uid}`);
            const existingProfile = await firebase_user_service/* firebaseUserService */.a.getUserProfile(authResult.user.uid);
            if (existingProfile && !isNewUser) {
                console.log(`⚠️ User profile already exists for uid: ${authResult.user.uid}`);
                return server.NextResponse.json({
                    error: 'User already exists'
                }, {
                    status: 409
                });
            }
            // Create or ensure user profile exists in Firestore
            const userProfile = await firebase_user_service/* firebaseUserService */.a.ensureUserProfile(authResult.user.uid, {
                email: authResult.user.email,
                displayName: authResult.user.name || name,
                emailVerified: authResult.user.email_verified,
                plan: 'free'
            });
            console.log(`✅ User profile ${existingProfile ? 'confirmed' : 'created'} for uid: ${authResult.user.uid}`);
            // Set session cookie
            const cookieStore = await (0,headers/* cookies */.UL)();
            cookieStore.set(SESSION_COOKIE_NAME, sessionToken, {
                httpOnly: true,
                secure: "production" === 'production',
                maxAge: SESSION_DURATION_S,
                path: '/',
                sameSite: 'lax'
            });
            console.log(`🍪 Session cookie set for uid: ${authResult.user.uid}`);
            // Return success with user data and token for localStorage
            return server.NextResponse.json({
                success: true,
                token: sessionToken,
                user: {
                    uid: userProfile.uid,
                    email: userProfile.email,
                    name: userProfile.displayName,
                    email_verified: userProfile.emailVerified,
                    plan: userProfile.plan,
                    profilePictureUrl: userProfile.profilePictureUrl,
                    createdAt: userProfile.createdAt,
                    updatedAt: userProfile.updatedAt
                }
            });
        } catch (profileError) {
            console.error('❌ Failed to handle user profile:', profileError);
            return server.NextResponse.json({
                error: 'Failed to create user profile'
            }, {
                status: 500
            });
        }
    } catch (error) {
        console.error('❌ Signup error:', error);
        return server.NextResponse.json({
            error: 'Internal server error'
        }, {
            status: 500
        });
    }
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fauth%2Fsignup%2Froute&name=app%2Fapi%2Fauth%2Fsignup%2Froute&pagePath=private-next-app-dir%2Fapi%2Fauth%2Fsignup%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Fauth%2Fsignup%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/auth/signup/route",
        pathname: "/api/auth/signup",
        filename: "route",
        bundlePath: "app/api/auth/signup/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/auth/signup/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 44870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 46675:
/***/ ((module) => {

"use strict";
module.exports = require("firebase-admin");

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 73701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ verifyFirebaseToken)
/* harmony export */ });
/* unused harmony export extractUserFromToken */
/* harmony import */ var _lib_shared_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8703);
/**
 * Auth Middleware Compatibility Layer
 * 
 * Provides backward compatibility for existing middleware usage
 * Routes to the unified auth system
 */ 
/**
 * Verify Firebase token (legacy compatibility function)
 * @param token - Firebase ID token to verify
 * @returns Promise<AuthResult>
 */ async function verifyFirebaseToken(token) {
    try {
        const result = await (0,_lib_shared_auth__WEBPACK_IMPORTED_MODULE_0__/* .verifyToken */ .nr)(token);
        return {
            success: result.valid,
            user: result.user || null,
            error: result.error
        };
    } catch (error) {
        return {
            success: false,
            user: null,
            error: error instanceof Error ? error.message : 'Token verification failed'
        };
    }
}
/**
 * Extract user from token
 * @param token - Auth token
 * @returns Promise<AuthenticatedUser | null>
 */ async function extractUserFromToken(token) {
    const result = await verifyFirebaseToken(token);
    return result.success ? result.user : null;
}


/***/ }),

/***/ 76926:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "createDedupedByCallsiteServerErrorLoggerDev", ({
    enumerable: true,
    get: function() {
        return createDedupedByCallsiteServerErrorLoggerDev;
    }
}));
const _react = /*#__PURE__*/ _interop_require_wildcard(__webpack_require__(61120));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const errorRef = {
    current: null
};
// React.cache is currently only available in canary/experimental React channels.
const cache = typeof _react.cache === 'function' ? _react.cache : (fn)=>fn;
// When Dynamic IO is enabled, we record these as errors so that they
// are captured by the dev overlay as it's more critical to fix these
// when enabled.
const logErrorOrWarn =  false ? 0 : console.warn;
// We don't want to dedupe across requests.
// The developer might've just attempted to fix the warning so we should warn again if it still happens.
const flushCurrentErrorIfNew = cache(// eslint-disable-next-line @typescript-eslint/no-unused-vars -- cache key
(key)=>{
    try {
        logErrorOrWarn(errorRef.current);
    } finally{
        errorRef.current = null;
    }
});
function createDedupedByCallsiteServerErrorLoggerDev(getMessage) {
    return function logDedupedError(...args) {
        const message = getMessage(...args);
        if (false) { var _stack; } else {
            logErrorOrWarn(message);
        }
    };
}

//# sourceMappingURL=create-deduped-by-callsite-server-error-logger.js.map

/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 88410:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ firebaseUserService)
/* harmony export */ });
/* harmony import */ var _lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63969);
/**
 * Firebase User Service - Real Implementation
 * 
 * Handles user profile management using Firebase Authentication and Firestore
 * This is the single source of truth for user identity and profiles
 */ 
class FirebaseUserService {
    static getInstance() {
        if (!FirebaseUserService.instance) {
            FirebaseUserService.instance = new FirebaseUserService();
        }
        return FirebaseUserService.instance;
    }
    /**
   * Get user profile from Firestore
   */ async getUserProfile(uid) {
        try {
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            const userDoc = await firestore.collection('users').doc(uid).get();
            if (!userDoc.exists) {
                console.log(`User profile not found for uid: ${uid}`);
                return null;
            }
            const data = userDoc.data();
            if (!data) {
                console.log(`User profile data is empty for uid: ${uid}`);
                return null;
            }
            // Convert Firestore timestamps to Date objects (handle both Firestore Timestamp and regular dates)
            const profile = {
                uid,
                email: data.email,
                displayName: data.displayName,
                profilePictureUrl: data.profilePictureUrl,
                phoneNumber: data.phoneNumber,
                emailVerified: data.emailVerified || false,
                plan: data.plan || 'free',
                createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : data.createdAt ? new Date(data.createdAt) : new Date(),
                updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : data.updatedAt ? new Date(data.updatedAt) : new Date(),
                about: data.about,
                workplace: data.workplace,
                skills: data.skills || [],
                dateOfBirth: data.dateOfBirth
            };
            console.log(`✅ Retrieved user profile for uid: ${uid}`);
            return profile;
        } catch (error) {
            console.error(`❌ Failed to get user profile for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Create user profile in Firestore
   */ async createUserProfile(uid, userData) {
        try {
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            const now = new Date();
            const profileData = {
                email: userData.email,
                displayName: userData.displayName || userData.email.split('@')[0],
                profilePictureUrl: undefined,
                phoneNumber: userData.phoneNumber || undefined,
                emailVerified: userData.emailVerified || false,
                plan: userData.plan || 'free',
                createdAt: now,
                updatedAt: now,
                about: undefined,
                workplace: undefined,
                skills: [],
                dateOfBirth: undefined
            };
            await firestore.collection('users').doc(uid).set(profileData);
            console.log(`✅ Created user profile for uid: ${uid}, email: ${userData.email}`);
            return {
                uid,
                ...profileData,
                skills: profileData.skills || []
            };
        } catch (error) {
            console.error(`❌ Failed to create user profile for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Update user profile in Firestore
   */ async updateUserProfile(uid, updates) {
        try {
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            // Remove uid from updates to prevent overwriting document ID
            const { uid: _, ...updateData } = updates;
            const updatePayload = {
                ...updateData,
                updatedAt: new Date()
            };
            await firestore.collection('users').doc(uid).update(updatePayload);
            console.log(`✅ Updated user profile for uid: ${uid}`);
        } catch (error) {
            console.error(`❌ Failed to update user profile for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Ensure user profile exists - create if not found
   */ async ensureUserProfile(uid, userData) {
        try {
            // First, try to get existing profile
            const existingProfile = await this.getUserProfile(uid);
            if (existingProfile) {
                console.log(`🔄 User profile already exists for uid: ${uid}`);
                return existingProfile;
            }
            // If not found, create new profile
            console.log(`🆕 Creating new user profile for uid: ${uid}`);
            return await this.createUserProfile(uid, userData);
        } catch (error) {
            console.error(`❌ Failed to ensure user profile for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Get Firebase Auth user record
   */ async getAuthUser(uid) {
        try {
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            const userRecord = await auth.getUser(uid);
            console.log(`✅ Retrieved Firebase Auth user for uid: ${uid}`);
            return userRecord;
        } catch (error) {
            console.error(`❌ Failed to get Firebase Auth user for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Create Firebase Auth user (for email/password signup)
   */ async createAuthUser(userData) {
        try {
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            const userRecord = await auth.createUser({
                email: userData.email,
                password: userData.password,
                displayName: userData.displayName,
                phoneNumber: userData.phoneNumber,
                emailVerified: userData.emailVerified || false
            });
            console.log(`✅ Created Firebase Auth user for email: ${userData.email}, uid: ${userRecord.uid}`);
            return userRecord;
        } catch (error) {
            console.error(`❌ Failed to create Firebase Auth user for email: ${userData.email}`, error);
            throw error;
        }
    }
    /**
   * Sign in with email and password (create custom token)
   */ async signInWithEmailAndPassword(email, password) {
        try {
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            // In a real implementation, you'd verify the password against Firebase Auth
            // For now, we'll create a custom token for the user
            const userRecord = await auth.getUserByEmail(email);
            const customToken = await auth.createCustomToken(userRecord.uid);
            console.log(`✅ Created custom token for email: ${email}, uid: ${userRecord.uid}`);
            return {
                user: {
                    uid: userRecord.uid,
                    email: userRecord.email,
                    displayName: userRecord.displayName,
                    emailVerified: userRecord.emailVerified
                },
                token: customToken
            };
        } catch (error) {
            console.error(`❌ Failed to sign in with email: ${email}`, error);
            throw error;
        }
    }
    /**
   * Delete user profile and auth record
   */ async deleteUser(uid) {
        try {
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            // Delete Firestore profile
            await firestore.collection('users').doc(uid).delete();
            // Delete Firebase Auth user
            await auth.deleteUser(uid);
            console.log(`✅ Deleted user completely for uid: ${uid}`);
        } catch (error) {
            console.error(`❌ Failed to delete user for uid: ${uid}`, error);
            throw error;
        }
    }
    /**
   * Health check - verify Firebase connections
   */ async healthCheck() {
        const details = {};
        let healthy = true;
        try {
            // Test Firebase Auth connection
            const auth = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminAuth)();
            await auth.getUser('test-user-id').catch(()=>{
            // Expected to fail, just testing connectivity
            });
            details.firebaseAuth = 'connected';
        } catch (error) {
            details.firebaseAuth = `error: ${error instanceof Error ? error.message : 'Unknown error'}`;
            healthy = false;
        }
        try {
            // Test Firestore connection
            const firestore = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_0__.getAdminFirestore)();
            await firestore.collection('users').limit(1).get();
            details.firestore = 'connected';
        } catch (error) {
            details.firestore = `error: ${error instanceof Error ? error.message : 'Unknown error'}`;
            healthy = false;
        }
        return {
            healthy,
            details
        };
    }
}
// Export singleton instance
const firebaseUserService = FirebaseUserService.getInstance();
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (firebaseUserService)));


/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 96559:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (false) {} else {
    if (false) {} else {
        if (false) {} else {
            if (false) {} else {
                module.exports = __webpack_require__(44870);
            }
        }
    }
}

//# sourceMappingURL=module.compiled.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,4999,8703,3969], () => (__webpack_exec__(21542)));
module.exports = __webpack_exports__;

})();