(() => {
var exports = {};
exports.id = 2588;
exports.ids = [2588];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 4131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/auth/verify/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
// EXTERNAL MODULE: ./lib/middleware/authMiddleware.ts
var authMiddleware = __webpack_require__(73701);
;// ./app/api/auth/verify/route.ts


async function GET(request) {
    const timestamp = new Date().toISOString();
    console.log(`🔍 [${timestamp}] AUTH VERIFY GET called - User-Agent: ${request.headers.get('user-agent')?.substring(0, 50)}`);
    try {
        const authHeader = request.headers.get('authorization');
        console.log(`🔍 [${timestamp}] Authorization header check:`, {
            hasAuthHeader: !!authHeader,
            startsWithBearer: authHeader?.startsWith('Bearer ') || false,
            headerPreview: authHeader ? authHeader.substring(0, 20) + '...' : 'none'
        });
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            console.error(`🔍 [${timestamp}] Missing or invalid authorization header`);
            return server.NextResponse.json({
                error: 'Missing or invalid authorization header'
            }, {
                status: 401
            });
        }
        const token = authHeader.substring(7); // Remove 'Bearer ' prefix
        console.log(`🔍 [${timestamp}] Token details:`, {
            tokenLength: token.length,
            tokenParts: token.split('.').length,
            tokenPrefix: token.substring(0, 50) + '...',
            isJWT: token.includes('.')
        });
        console.log(`🔍 [${timestamp}] Calling verifyFirebaseToken...`);
        const authResult = await (0,authMiddleware/* verifyFirebaseToken */.W)(token);
        console.log(`🔍 [${timestamp}] Firebase token verification result:`, {
            success: authResult.success,
            hasUser: !!authResult.user,
            uid: authResult.user?.uid,
            email: authResult.user?.email,
            error: authResult.error
        });
        if (!authResult.success || !authResult.user) {
            console.error(`🔍 [${timestamp}] Token verification failed:`, {
                success: authResult.success,
                hasUser: !!authResult.user,
                error: authResult.error
            });
            // Provide specific error responses for different failure types
            const errorMessage = authResult.error || 'Invalid or expired token';
            let statusCode = 401;
            let shouldRefresh = false;
            // Check if this is a token expiration issue
            if (errorMessage.includes('expired') || errorMessage.includes('kid')) {
                shouldRefresh = true;
            }
            return server.NextResponse.json({
                error: errorMessage,
                shouldRefresh,
                code: 'TOKEN_VERIFICATION_FAILED'
            }, {
                status: statusCode
            });
        }
        console.log(`🔍 [${timestamp}] Token verification successful for uid: ${authResult.user.uid}`);
        return server.NextResponse.json({
            success: true,
            user: authResult.user
        });
    } catch (error) {
        console.error(`🔍 [${timestamp}] Token verification error:`, error);
        return server.NextResponse.json({
            error: `Token verification failed: ${error instanceof Error ? error.message : 'Unknown error'}`
        }, {
            status: 500
        });
    }
}
async function POST(request) {
    // Support both GET and POST for flexibility
    return GET(request);
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fauth%2Fverify%2Froute&name=app%2Fapi%2Fauth%2Fverify%2Froute&pagePath=private-next-app-dir%2Fapi%2Fauth%2Fverify%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Fauth%2Fverify%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/auth/verify/route",
        pathname: "/api/auth/verify",
        filename: "route",
        bundlePath: "app/api/auth/verify/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/auth/verify/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 44870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 46675:
/***/ ((module) => {

"use strict";
module.exports = require("firebase-admin");

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 73701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ verifyFirebaseToken)
/* harmony export */ });
/* unused harmony export extractUserFromToken */
/* harmony import */ var _lib_shared_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8703);
/**
 * Auth Middleware Compatibility Layer
 * 
 * Provides backward compatibility for existing middleware usage
 * Routes to the unified auth system
 */ 
/**
 * Verify Firebase token (legacy compatibility function)
 * @param token - Firebase ID token to verify
 * @returns Promise<AuthResult>
 */ async function verifyFirebaseToken(token) {
    try {
        const result = await (0,_lib_shared_auth__WEBPACK_IMPORTED_MODULE_0__/* .verifyToken */ .nr)(token);
        return {
            success: result.valid,
            user: result.user || null,
            error: result.error
        };
    } catch (error) {
        return {
            success: false,
            user: null,
            error: error instanceof Error ? error.message : 'Token verification failed'
        };
    }
}
/**
 * Extract user from token
 * @param token - Auth token
 * @returns Promise<AuthenticatedUser | null>
 */ async function extractUserFromToken(token) {
    const result = await verifyFirebaseToken(token);
    return result.success ? result.user : null;
}


/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 96559:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (false) {} else {
    if (false) {} else {
        if (false) {} else {
            if (false) {} else {
                module.exports = __webpack_require__(44870);
            }
        }
    }
}

//# sourceMappingURL=module.compiled.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8703], () => (__webpack_exec__(4131)));
module.exports = __webpack_exports__;

})();