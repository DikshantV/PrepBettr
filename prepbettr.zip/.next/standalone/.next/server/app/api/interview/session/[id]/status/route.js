"use strict";
(() => {
var exports = {};
exports.id = 8545;
exports.ids = [8545];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 7328:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/interview/session/[id]/status/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
// EXTERNAL MODULE: ./lib/azure-ai-foundry/workflows/interview-workflow.ts + 6 modules
var interview_workflow = __webpack_require__(97853);
;// ./app/api/interview/session/[id]/status/route.ts


// Lazy initialization to avoid build-time issues
let workflow = null;
function getWorkflow() {
    if (!workflow) {
        workflow = new interview_workflow/* InterviewWorkflow */.X();
    }
    return workflow;
}
/**
 * GET /api/interview/session/[id]/status
 * 
 * Get current status of an interview session
 * 
 * Path Parameters:
 * - id: sessionId (string)
 * 
 * Query Parameters:
 * - refresh?: boolean (force refresh timing data)
 * 
 * Response:
 * - status: WorkflowStatus (complete status object)
 * - timing: real-time timing information
 * - progress: percentage and stage information
 */ async function GET(request, { params }) {
    const resolvedParams = await params;
    const sessionId = resolvedParams.id;
    try {
        const { searchParams } = new URL(request.url);
        const refresh = searchParams.get('refresh') === 'true';
        if (!sessionId) {
            return server.NextResponse.json({
                error: 'Session ID is required'
            }, {
                status: 400
            });
        }
        console.log(`[API] Getting status for session: ${sessionId}${refresh ? ' (refresh)' : ''}`);
        // Get current workflow status
        const status = await getWorkflow().getStatus(sessionId);
        return server.NextResponse.json({
            success: true,
            sessionId,
            status,
            timestamp: Date.now(),
            // Additional computed fields for convenience
            computed: {
                isActive: status.state === 'in-progress',
                isCompleted: status.state === 'completed',
                canAdvance: status.currentStageIndex < status.totalStages && status.state !== 'failed',
                currentStageName: status.currentStage ? status.stages.find((s)=>s.stage.id === status.currentStage)?.stage.name : null,
                nextStageName: status.currentStageIndex < status.totalStages ? status.stages[status.currentStageIndex]?.stage.name : null,
                estimatedCompletionTime: new Date(status.timing.startTime + status.timing.totalEstimatedMinutes * 60000).toISOString(),
                healthStatus: status.error ? 'error' : status.state === 'failed' ? 'failed' : 'healthy'
            }
        });
    } catch (error) {
        console.error(`[API] Error getting session status:`, error);
        if (error.code === 'SESSION_NOT_FOUND') {
            return server.NextResponse.json({
                success: false,
                error: 'Session not found',
                sessionId: resolvedParams.id
            }, {
                status: 404
            });
        }
        return server.NextResponse.json({
            success: false,
            error: error.message || 'Failed to get session status',
            code: error.code || 'UNKNOWN_ERROR',
            sessionId: resolvedParams.id
        }, {
            status: 500
        });
    }
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Finterview%2Fsession%2F%5Bid%5D%2Fstatus%2Froute&name=app%2Fapi%2Finterview%2Fsession%2F%5Bid%5D%2Fstatus%2Froute&pagePath=private-next-app-dir%2Fapi%2Finterview%2Fsession%2F%5Bid%5D%2Fstatus%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Finterview%2Fsession%2F%5Bid%5D%2Fstatus%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/interview/session/[id]/status/route",
        pathname: "/api/interview/session/[id]/status",
        filename: "route",
        bundlePath: "app/api/interview/session/[id]/status/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/interview/session/[id]/status/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,5295], () => (__webpack_exec__(7328)));
module.exports = __webpack_exports__;

})();