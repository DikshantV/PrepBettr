"use strict";
(() => {
var exports = {};
exports.id = 4542;
exports.ids = [4542];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 50664:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/interview/agent/handoff/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
// EXTERNAL MODULE: ./lib/azure-ai-foundry/workflows/interview-workflow.ts + 6 modules
var interview_workflow = __webpack_require__(97853);
;// ./app/api/interview/agent/handoff/route.ts


// Initialize workflow lazily to avoid build-time issues
let workflow = null;
function getWorkflow() {
    if (!workflow) {
        workflow = new interview_workflow/* InterviewWorkflow */.X();
    }
    return workflow;
}
/**
 * POST /api/interview/agent/handoff
 * 
 * Trigger agent handoff and advance to next stage
 * 
 * Request Body:
 * - sessionId: string (required)
 * - fromAgent?: AgentType (current agent)
 * - toAgent?: AgentType (target agent, auto-determined if not provided)
 * - insights?: string[] (key insights to pass to next agent)
 * - focusAreas?: string[] (areas for next agent to focus on)
 * - instructions?: string (additional instructions for handoff)
 * - force?: boolean (force handoff even if current stage incomplete)
 * 
 * Response:
 * - success: boolean
 * - handoff: AgentHandoff information
 * - status: updated WorkflowStatus
 */ async function POST(request) {
    let body = {};
    try {
        body = await request.json();
        if (!body.sessionId) {
            return server.NextResponse.json({
                error: 'Session ID is required'
            }, {
                status: 400
            });
        }
        const sessionId = body.sessionId;
        console.log(`[API] Agent handoff requested for session: ${sessionId}`);
        console.log(`- From: ${body.fromAgent || 'auto'}`);
        console.log(`- To: ${body.toAgent || 'auto'}`);
        console.log(`- Force: ${body.force || false}`);
        // Get workflow instance (initialized lazily)
        const workflowInstance = getWorkflow();
        // Get current status to validate handoff
        const currentStatus = await workflowInstance.getStatus(sessionId);
        // Validate that handoff is possible
        if (!body.force) {
            if (currentStatus.state === 'completed') {
                return server.NextResponse.json({
                    success: false,
                    error: 'Interview is already completed',
                    code: 'INVALID_STATE'
                }, {
                    status: 400
                });
            }
            if (currentStatus.state === 'failed') {
                return server.NextResponse.json({
                    success: false,
                    error: 'Interview has failed, cannot perform handoff',
                    code: 'INVALID_STATE'
                }, {
                    status: 400
                });
            }
            if (currentStatus.pendingAgents.length === 0) {
                return server.NextResponse.json({
                    success: false,
                    error: 'No pending agents for handoff',
                    code: 'INVALID_STATE'
                }, {
                    status: 400
                });
            }
        }
        // Determine agents for handoff
        const fromAgent = body.fromAgent || currentStatus.activeAgents[0];
        const toAgent = body.toAgent || currentStatus.pendingAgents[0];
        // Build handoff context
        const handoffContext = {
            sessionId,
            fromAgent,
            toAgent,
            context: {
                previousQuestions: [],
                insights: body.insights || [
                    `Completed ${currentStatus.currentStage} stage`,
                    `Generated ${currentStatus.metrics.totalQuestionsGenerated} questions so far`
                ],
                focusAreas: body.focusAreas || [],
                instructions: body.instructions
            },
            timestamp: Date.now()
        };
        console.log(`[API] Executing handoff: ${fromAgent} → ${toAgent}`);
        // Trigger stage advancement (which handles the agent transition)
        await workflowInstance.advanceStage(sessionId);
        // Get updated status
        const updatedStatus = await workflowInstance.getStatus(sessionId);
        return server.NextResponse.json({
            success: true,
            sessionId,
            handoff: handoffContext,
            status: updatedStatus,
            message: `Agent handoff completed: ${fromAgent} → ${toAgent}`,
            timing: {
                handoffTimestamp: handoffContext.timestamp,
                nextStageStartTime: updatedStatus.stages[updatedStatus.currentStageIndex - 1]?.startTime
            }
        });
    } catch (error) {
        console.error('[API] Error during agent handoff:', error);
        if (error.code === 'SESSION_NOT_FOUND') {
            return server.NextResponse.json({
                success: false,
                error: 'Session not found',
                sessionId: body.sessionId
            }, {
                status: 404
            });
        }
        return server.NextResponse.json({
            success: false,
            error: error.message || 'Failed to execute agent handoff',
            code: error.code || 'UNKNOWN_ERROR',
            sessionId: body.sessionId,
            recoverable: error.recoverable ?? true
        }, {
            status: 500
        });
    }
}
/**
 * GET /api/interview/agent/handoff
 * 
 * Get handoff API documentation
 */ async function GET() {
    return server.NextResponse.json({
        endpoint: 'POST /api/interview/agent/handoff',
        description: 'Trigger agent handoff and advance to next interview stage',
        requiredFields: [
            'sessionId'
        ],
        optionalFields: [
            'fromAgent',
            'toAgent',
            'insights',
            'focusAreas',
            'instructions',
            'force'
        ],
        agentTypes: [
            'technical',
            'behavioral',
            'industry'
        ],
        validTransitions: {
            technical: [
                'behavioral',
                'industry'
            ],
            behavioral: [
                'industry',
                'wrap-up'
            ],
            industry: [
                'wrap-up'
            ]
        },
        example: {
            sessionId: 'interview_abc123',
            fromAgent: 'technical',
            toAgent: 'behavioral',
            insights: [
                'Candidate shows strong algorithmic thinking',
                'Good understanding of system design principles'
            ],
            focusAreas: [
                'Leadership experience',
                'Team collaboration'
            ],
            instructions: 'Focus on senior-level behavioral scenarios'
        },
        notes: [
            'Agents are automatically determined based on stage progression if not specified',
            'Set force: true to skip validation checks',
            'Handoffs update session state and trigger next agent'
        ]
    });
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Finterview%2Fagent%2Fhandoff%2Froute&name=app%2Fapi%2Finterview%2Fagent%2Fhandoff%2Froute&pagePath=private-next-app-dir%2Fapi%2Finterview%2Fagent%2Fhandoff%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Finterview%2Fagent%2Fhandoff%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/interview/agent/handoff/route",
        pathname: "/api/interview/agent/handoff",
        filename: "route",
        bundlePath: "app/api/interview/agent/handoff/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/interview/agent/handoff/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,5295], () => (__webpack_exec__(50664)));
module.exports = __webpack_exports__;

})();