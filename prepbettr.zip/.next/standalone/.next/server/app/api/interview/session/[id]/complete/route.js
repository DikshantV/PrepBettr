"use strict";
(() => {
var exports = {};
exports.id = 3510;
exports.ids = [3510];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 77296:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/interview/session/[id]/complete/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
// EXTERNAL MODULE: ./lib/azure-ai-foundry/workflows/interview-workflow.ts + 6 modules
var interview_workflow = __webpack_require__(97853);
;// ./app/api/interview/session/[id]/complete/route.ts


// Lazy initialization to avoid build-time issues
let workflow = null;
function getWorkflow() {
    if (!workflow) {
        workflow = new interview_workflow/* InterviewWorkflow */.X();
    }
    return workflow;
}
/**
 * POST /api/interview/session/[id]/complete
 * 
 * Complete an interview session and get comprehensive results
 * 
 * Path Parameters:
 * - id: sessionId (string)
 * 
 * Request Body (optional):
 * - force?: boolean (force completion even if not all stages done)
 * - includeReport?: boolean (generate detailed PDF report)
 * - candidateFeedback?: boolean (include candidate-specific feedback)
 * - sharing?: { recruiterId?, managerEmails? } (sharing configuration)
 * 
 * Response:
 * - result: InterviewResult (comprehensive interview analysis)
 * - exports: available export options
 * - sharing: sharing configuration applied
 */ async function POST(request, { params }) {
    const resolvedParams = await params;
    const sessionId = resolvedParams.id;
    try {
        const body = await request.json().catch(()=>({}));
        if (!sessionId) {
            return server.NextResponse.json({
                error: 'Session ID is required'
            }, {
                status: 400
            });
        }
        console.log(`[API] Completing interview session: ${sessionId}`);
        console.log(`- Force: ${body.force || false}`);
        console.log(`- Include Report: ${body.includeReport || false}`);
        console.log(`- Candidate Feedback: ${body.candidateFeedback || false}`);
        // Get current status for validation
        const currentStatus = await getWorkflow().getStatus(sessionId);
        if (!body.force && currentStatus.state === 'completed') {
            return server.NextResponse.json({
                success: false,
                error: 'Interview is already completed',
                sessionId,
                existingResult: await getWorkflow().completeInterview(sessionId)
            }, {
                status: 400
            });
        }
        if (currentStatus.state === 'failed') {
            return server.NextResponse.json({
                success: false,
                error: 'Interview has failed, cannot complete normally',
                sessionId,
                suggestion: 'Use force: true to get partial results'
            }, {
                status: 400
            });
        }
        // Complete the interview workflow
        const result = await getWorkflow().completeInterview(sessionId);
        // Enhance result with requested features
        if (body.includeReport) {
            result.exports.reportAvailable = true;
        // In production, would generate PDF here
        }
        if (body.candidateFeedback) {
            result.feedback.candidateFeedback = {
                positives: [
                    'Demonstrated strong technical knowledge',
                    'Clear communication throughout the interview'
                ],
                developmentAreas: [
                    'Consider deepening system design knowledge',
                    'Practice explaining complex concepts simply'
                ],
                resources: [
                    'System Design Interview book',
                    'LeetCode practice problems',
                    'Leadership communication courses'
                ],
                encouragement: 'Thank you for your time today. You showed great potential and we appreciate your thoughtful responses.'
            };
        }
        // Handle sharing configuration
        const sharingConfig = {
            recruiterId: body.sharing?.recruiterId,
            managerEmails: body.sharing?.managerEmails || [],
            shareCandidateFeedback: body.candidateFeedback || false,
            shareDetailedReport: body.includeReport || false,
            generatedAt: new Date().toISOString()
        };
        console.log(`[API] Interview completed successfully`);
        console.log(`- Total duration: ${result.summary.totalDurationMinutes} minutes`);
        console.log(`- Stages completed: ${result.summary.stagesCompleted}/${result.summary.totalStages}`);
        console.log(`- Questions asked: ${result.summary.questionsAsked}`);
        console.log(`- Overall outcome: ${result.outcome}`);
        return server.NextResponse.json({
            success: true,
            sessionId,
            result,
            sharing: sharingConfig,
            exports: {
                pdfReportUrl: result.exports.reportAvailable ? `/api/interview/session/${sessionId}/report.pdf` : null,
                candidateSummaryUrl: body.candidateFeedback ? `/api/interview/session/${sessionId}/candidate-summary` : null,
                recruiterReportUrl: `/api/interview/session/${sessionId}/recruiter-report`,
                rawDataUrl: `/api/interview/session/${sessionId}/raw-data`
            },
            metadata: {
                completedAt: new Date().toISOString(),
                processingTime: result.metadata.generationDuration,
                apiVersion: '1.0.0'
            }
        });
    } catch (error) {
        console.error(`[API] Error completing interview:`, error);
        if (error.code === 'SESSION_NOT_FOUND') {
            return server.NextResponse.json({
                success: false,
                error: 'Session not found',
                sessionId: resolvedParams.id
            }, {
                status: 404
            });
        }
        return server.NextResponse.json({
            success: false,
            error: error.message || 'Failed to complete interview',
            code: error.code || 'UNKNOWN_ERROR',
            sessionId: resolvedParams.id,
            recoverable: error.recoverable ?? false
        }, {
            status: 500
        });
    }
}
/**
 * GET /api/interview/session/[id]/complete
 * 
 * Get completion status and available options
 */ async function GET(request, { params }) {
    const resolvedParams = await params;
    const sessionId = resolvedParams.id;
    try {
        // Get current session status
        const status = await getWorkflow().getStatus(sessionId);
        const canComplete = status.state === 'in-progress' || status.state === 'completed';
        const completionOptions = {
            canForceComplete: status.state !== 'completed',
            canGenerateReport: true,
            canProvideCandidateFeedback: true,
            availableExports: [
                'pdf',
                'candidate-summary',
                'recruiter-report',
                'raw-data'
            ]
        };
        return server.NextResponse.json({
            sessionId,
            canComplete,
            currentState: status.state,
            completionOptions,
            progress: {
                stagesCompleted: status.stages.filter((s)=>s.status === 'completed').length,
                totalStages: status.totalStages,
                progressPercentage: status.progressPercentage
            },
            example: {
                force: false,
                includeReport: true,
                candidateFeedback: true,
                sharing: {
                    recruiterId: 'recruiter_123',
                    managerEmails: [
                        'manager@company.com'
                    ]
                }
            }
        });
    } catch (error) {
        if (error.code === 'SESSION_NOT_FOUND') {
            return server.NextResponse.json({
                error: 'Session not found',
                sessionId: resolvedParams.id
            }, {
                status: 404
            });
        }
        return server.NextResponse.json({
            error: error.message || 'Failed to get completion info',
            sessionId: resolvedParams.id
        }, {
            status: 500
        });
    }
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Finterview%2Fsession%2F%5Bid%5D%2Fcomplete%2Froute&name=app%2Fapi%2Finterview%2Fsession%2F%5Bid%5D%2Fcomplete%2Froute&pagePath=private-next-app-dir%2Fapi%2Finterview%2Fsession%2F%5Bid%5D%2Fcomplete%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Finterview%2Fsession%2F%5Bid%5D%2Fcomplete%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/interview/session/[id]/complete/route",
        pathname: "/api/interview/session/[id]/complete",
        filename: "route",
        bundlePath: "app/api/interview/session/[id]/complete/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/interview/session/[id]/complete/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,5295], () => (__webpack_exec__(77296)));
module.exports = __webpack_exports__;

})();