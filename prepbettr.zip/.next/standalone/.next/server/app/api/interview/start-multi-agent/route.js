"use strict";
(() => {
var exports = {};
exports.id = 1722;
exports.ids = [1722];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 35151:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/interview/start-multi-agent/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
// EXTERNAL MODULE: ./lib/azure-ai-foundry/workflows/interview-workflow.ts + 6 modules
var interview_workflow = __webpack_require__(97853);
// EXTERNAL MODULE: external "node:crypto"
var external_node_crypto_ = __webpack_require__(77598);
;// ./node_modules/nanoid/url-alphabet/index.js
const urlAlphabet =
  'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict'

;// ./node_modules/nanoid/index.js



const POOL_SIZE_MULTIPLIER = 128
let pool, poolOffset
function fillPool(bytes) {
  if (!pool || pool.length < bytes) {
    pool = Buffer.allocUnsafe(bytes * POOL_SIZE_MULTIPLIER)
    external_node_crypto_.webcrypto.getRandomValues(pool)
    poolOffset = 0
  } else if (poolOffset + bytes > pool.length) {
    external_node_crypto_.webcrypto.getRandomValues(pool)
    poolOffset = 0
  }
  poolOffset += bytes
}
function random(bytes) {
  fillPool((bytes |= 0))
  return pool.subarray(poolOffset - bytes, poolOffset)
}
function customRandom(alphabet, defaultSize, getRandom) {
  let mask = (2 << (31 - Math.clz32((alphabet.length - 1) | 1))) - 1
  let step = Math.ceil((1.6 * mask * defaultSize) / alphabet.length)
  return (size = defaultSize) => {
    let id = ''
    while (true) {
      let bytes = getRandom(step)
      let i = step
      while (i--) {
        id += alphabet[bytes[i] & mask] || ''
        if (id.length >= size) return id
      }
    }
  }
}
function customAlphabet(alphabet, size = 21) {
  return customRandom(alphabet, size, random)
}
function nanoid(size = 21) {
  fillPool((size |= 0))
  let id = ''
  for (let i = poolOffset - size; i < poolOffset; i++) {
    id += urlAlphabet[pool[i] & 63]
  }
  return id
}

;// ./app/api/interview/start-multi-agent/route.ts



// Lazy initialization to avoid build-time issues
let workflow = null;
function getWorkflow() {
    if (!workflow) {
        workflow = new interview_workflow/* InterviewWorkflow */.X();
    }
    return workflow;
}
/**
 * POST /api/interview/start-multi-agent
 * 
 * Start a new multi-agent interview session
 * 
 * Request Body:
 * - role: string (required)
 * - experienceLevel: 'entry' | 'mid' | 'senior' | 'executive' (required)  
 * - industry?: string
 * - candidateProfile: { name, skills, ... } (required)
 * - companyInfo?: { name, industry, size, culture }
 * - customization?: { enabledStages, stageDurations, ... }
 * - metadata?: { source, recruiterId, ... }
 * 
 * Response: 
 * - sessionId: string
 * - status: WorkflowStatus
 */ async function POST(request) {
    try {
        const body = await request.json();
        // Validate required fields
        if (!body.role || !body.experienceLevel || !body.candidateProfile?.name || !body.candidateProfile?.skills) {
            return server.NextResponse.json({
                error: 'Missing required fields',
                required: [
                    'role',
                    'experienceLevel',
                    'candidateProfile.name',
                    'candidateProfile.skills'
                ]
            }, {
                status: 400
            });
        }
        // Generate session ID if not provided
        const sessionId = body.sessionId || `interview_${nanoid(12)}`;
        // Build interview configuration
        const config = {
            sessionId,
            role: body.role,
            experienceLevel: body.experienceLevel,
            industry: body.industry,
            roleType: body.roleType,
            candidateProfile: {
                name: body.candidateProfile.name,
                email: body.candidateProfile.email,
                skills: body.candidateProfile.skills || [],
                previousRoles: body.candidateProfile.previousRoles || [],
                yearsExperience: body.candidateProfile.yearsExperience,
                education: body.candidateProfile.education,
                certifications: body.candidateProfile.certifications || []
            },
            companyInfo: body.companyInfo,
            customization: {
                enabledStages: body.customization?.enabledStages,
                stageDurations: body.customization?.stageDurations,
                maxDurationMinutes: body.customization?.maxDurationMinutes || 45,
                customInstructions: body.customization?.customInstructions,
                agentOverrides: body.customization?.agentOverrides,
                questionsPerStage: body.customization?.questionsPerStage,
                focusAreas: body.customization?.focusAreas
            },
            metadata: {
                source: body.metadata?.source || 'api',
                recruiterId: body.metadata?.recruiterId,
                jobPostingId: body.metadata?.jobPostingId,
                interviewType: body.metadata?.interviewType || 'screening',
                scheduledAt: body.metadata?.scheduledAt || new Date().toISOString(),
                tags: body.metadata?.tags || []
            }
        };
        console.log(`[API] Starting multi-agent interview for ${config.candidateProfile.name} - Role: ${config.role}`);
        // Start the interview workflow
        const startedSessionId = await getWorkflow().startMultiAgentInterview(config);
        // Get initial status
        const status = await getWorkflow().getStatus(startedSessionId);
        return server.NextResponse.json({
            success: true,
            sessionId: startedSessionId,
            status,
            message: 'Multi-agent interview started successfully'
        }, {
            status: 201
        });
    } catch (error) {
        console.error('[API] Error starting multi-agent interview:', error);
        return server.NextResponse.json({
            success: false,
            error: error.message || 'Failed to start interview',
            code: error.code || 'UNKNOWN_ERROR',
            recoverable: error.recoverable ?? true
        }, {
            status: error.code === 'CONFIGURATION_ERROR' ? 400 : 500
        });
    }
}
/**
 * GET /api/interview/start-multi-agent
 * 
 * Get API documentation and requirements
 */ async function GET() {
    return server.NextResponse.json({
        endpoint: 'POST /api/interview/start-multi-agent',
        description: 'Start a new multi-agent interview session',
        requiredFields: [
            'role',
            'experienceLevel',
            'candidateProfile.name',
            'candidateProfile.skills'
        ],
        optionalFields: [
            'sessionId',
            'industry',
            'roleType',
            'companyInfo',
            'customization',
            'metadata'
        ],
        experienceLevels: [
            'entry',
            'mid',
            'senior',
            'executive'
        ],
        defaultStages: [
            'technical',
            'behavioral',
            'industry',
            'wrap-up'
        ],
        defaultDurations: {
            technical: 15,
            behavioral: 10,
            industry: 10,
            'wrap-up': 5
        },
        example: {
            role: 'Senior Frontend Developer',
            experienceLevel: 'senior',
            candidateProfile: {
                name: 'John Doe',
                skills: [
                    'React',
                    'TypeScript',
                    'Node.js'
                ],
                yearsExperience: 5
            },
            companyInfo: {
                name: 'Tech Corp',
                industry: 'technology',
                size: 'medium'
            },
            customization: {
                enabledStages: [
                    'technical',
                    'behavioral'
                ],
                stageDurations: {
                    technical: 20
                }
            }
        }
    });
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Finterview%2Fstart-multi-agent%2Froute&name=app%2Fapi%2Finterview%2Fstart-multi-agent%2Froute&pagePath=private-next-app-dir%2Fapi%2Finterview%2Fstart-multi-agent%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Finterview%2Fstart-multi-agent%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/interview/start-multi-agent/route",
        pathname: "/api/interview/start-multi-agent",
        filename: "route",
        bundlePath: "app/api/interview/start-multi-agent/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/interview/start-multi-agent/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 77598:
/***/ ((module) => {

module.exports = require("node:crypto");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,5295], () => (__webpack_exec__(35151)));
module.exports = __webpack_exports__;

})();