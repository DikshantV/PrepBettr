(() => {
var exports = {};
exports.id = 7967;
exports.ids = [6502,7967];
exports.modules = {

/***/ 1708:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 4573:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 11997:
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ 12412:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14737:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/storage-blob");;

/***/ }),

/***/ 16446:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/app-configuration");;

/***/ }),

/***/ 19771:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 21820:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 26231:
/***/ ((module) => {

"use strict";
module.exports = require("applicationinsights");

/***/ }),

/***/ 27910:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 30120:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GET: () => (/* binding */ GET),
/* harmony export */   HEAD: () => (/* binding */ HEAD),
/* harmony export */   POST: () => (/* binding */ POST)
/* harmony export */ });
/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32190);
/* harmony import */ var _lib_services_question_bank_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45936);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75931);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_question_bank_service__WEBPACK_IMPORTED_MODULE_1__]);
_lib_services_question_bank_service__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Question Bank Cache Invalidation API
 * 
 * Provides manual cache invalidation for the question bank service.
 * Useful for development, testing, and operational maintenance.
 */ 


// Supported HTTP methods
async function POST(request) {
    try {
        const body = await request.json();
        const { pattern, reason } = body;
        // Validate admin access (basic implementation)
        const authHeader = request.headers.get('authorization');
        if (!isAuthorizedForCacheOps(authHeader)) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                error: 'Unauthorized - admin access required'
            }, {
                status: 401
            });
        }
        // Invalidate cache
        _lib_services_question_bank_service__WEBPACK_IMPORTED_MODULE_1__/* .questionBankService */ .O.invalidateCache(pattern);
        // Get current cache stats
        const stats = _lib_services_question_bank_service__WEBPACK_IMPORTED_MODULE_1__/* .questionBankService */ .O.getCacheStats();
        // Log the cache invalidation
        console.log('🔄 Question bank cache invalidated', {
            pattern: pattern || 'all',
            reason: reason || 'manual-request',
            timestamp: new Date().toISOString(),
            remainingSize: stats.size
        });
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: true,
            message: pattern ? `Cache invalidated for pattern: ${pattern}` : 'Entire question bank cache invalidated',
            stats,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('❌ Error invalidating question bank cache:', error);
        (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
            service: 'question-bank-api',
            action: 'invalidate-cache'
        });
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: false,
            error: error instanceof Error ? error.message : 'Cache invalidation failed'
        }, {
            status: 500
        });
    }
}
async function GET(request) {
    try {
        // Basic auth check for stats access
        const authHeader = request.headers.get('authorization');
        if (!isAuthorizedForCacheOps(authHeader)) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                error: 'Unauthorized - admin access required'
            }, {
                status: 401
            });
        }
        // Get cache statistics
        const stats = _lib_services_question_bank_service__WEBPACK_IMPORTED_MODULE_1__/* .questionBankService */ .O.getCacheStats();
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: true,
            stats,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('❌ Error getting question bank cache stats:', error);
        (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
            service: 'question-bank-api',
            action: 'get-cache-stats'
        });
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: false,
            error: error instanceof Error ? error.message : 'Failed to get cache stats'
        }, {
            status: 500
        });
    }
}
/**
 * Basic authorization check for cache operations
 * In production, this should integrate with proper admin authentication
 */ function isAuthorizedForCacheOps(authHeader) {
    // For development: allow cache invalidation without auth
    if (false) {}
    // For production: check for admin key or proper auth token
    if (!authHeader) {
        return false;
    }
    // Check for admin API key
    const adminKey = process.env.ADMIN_API_KEY;
    if (adminKey && authHeader === `Bearer ${adminKey}`) {
        return true;
    }
    // In a full implementation, you would:
    // 1. Verify JWT tokens
    // 2. Check user roles/permissions
    // 3. Validate against your auth system
    return false;
}
// Health check for the invalidation endpoint
async function HEAD() {
    return new next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse(null, {
        status: 200
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 33873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 35672:
/***/ ((module) => {

"use strict";
module.exports = require("@azure/msal-node");

/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37067:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 37366:
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ 38522:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 44708:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 44870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 46502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   j: () => (/* binding */ RetryWithBackoff),
/* harmony export */   y: () => (/* binding */ retryWithExponentialBackoff)
/* harmony export */ });

class RetryWithBackoff {
    static initialize(instrumentationKey) {
        if (instrumentationKey && "undefined" !== 'undefined') {}
    }
    /**
   * Execute a function with exponential backoff retry logic
   */ static async execute(fn, options = {}) {
        const { maxRetries = 3, baseDelay = 1000, maxDelay = 30000, jitter = true, retryCondition = this.defaultRetryCondition, onRetry, userId, action = 'unknown' } = options;
        const startTime = Date.now();
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                const result = await fn();
                // Log success metrics
                if (attempt > 0) {
                    this.logRetrySuccess({
                        attempt: attempt + 1,
                        totalAttempts: attempt + 1,
                        delay: 0,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                }
                return result;
            } catch (error) {
                lastError = error;
                // Check if we should retry
                if (attempt === maxRetries || !retryCondition(error)) {
                    // Log final failure
                    this.logRetryFailure({
                        attempt: attempt + 1,
                        totalAttempts: maxRetries + 1,
                        delay: 0,
                        error,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                    throw error;
                }
                // Calculate delay for next attempt
                const exponentialDelay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
                const delay = jitter ? exponentialDelay + Math.random() * exponentialDelay * 0.1 // Add 10% jitter
                 : exponentialDelay;
                // Log retry attempt
                this.logRetryAttempt({
                    attempt: attempt + 1,
                    totalAttempts: maxRetries + 1,
                    delay,
                    error,
                    userId,
                    action,
                    startTime
                });
                // Execute retry callback if provided
                if (onRetry) {
                    onRetry(error, attempt + 1);
                }
                // Wait before next attempt
                await this.sleep(delay);
            }
        }
        throw lastError;
    }
    /**
   * Default retry condition - retry on network errors, rate limits, and server errors
   */ static defaultRetryCondition(error) {
        // Network errors
        if (error.code === 'ECONNRESET' || error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
            return true;
        }
        // HTTP status codes that should be retried
        if (error.response?.status) {
            const status = error.response.status;
            return status === 429 || // Rate limit
            status === 502 || // Bad Gateway
            status === 503 || // Service Unavailable
            status === 504; // Gateway Timeout
        }
        // Azure OpenAI specific errors
        if (error.message?.includes('rate limit') || error.message?.includes('throttled') || error.message?.includes('quota exceeded')) {
            return true;
        }
        return false;
    }
    /**
   * Sleep for specified milliseconds
   */ static sleep(ms) {
        return new Promise((resolve)=>setTimeout(resolve, ms));
    }
    /**
   * Log retry attempt
   */ static logRetryAttempt(metrics) {
        const logData = {
            level: 'warn',
            message: `Retry attempt ${metrics.attempt}/${metrics.totalAttempts} for ${metrics.action}`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                delay: metrics.delay,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name
                },
                timestamp: new Date().toISOString()
            }
        };
        console.warn('RETRY_ATTEMPT', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 2,
                properties: logData.properties
            });
        }
    }
    /**
   * Log retry success
   */ static logRetrySuccess(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'info',
            message: `Retry succeeded for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                timestamp: new Date().toISOString()
            }
        };
        console.log('RETRY_SUCCESS', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 1,
                properties: logData.properties
            });
            // Track custom metric for retry success
            this.appInsights.trackMetric({
                name: 'RetrySuccess',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
    /**
   * Log retry failure
   */ static logRetryFailure(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'error',
            message: `Retry failed for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name,
                    stack: metrics.error?.stack
                },
                timestamp: new Date().toISOString()
            }
        };
        console.error('RETRY_FAILURE', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackException({
                exception: metrics.error,
                properties: logData.properties,
                severityLevel: 3 // Error
            });
            // Track custom metric for retry failure
            this.appInsights.trackMetric({
                name: 'RetryFailure',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
}
/**
 * Convenience function for common retry scenarios
 */ async function retryWithExponentialBackoff(fn, action, userId, options) {
    return RetryWithBackoff.execute(fn, {
        action,
        userId,
        ...options
    });
}


/***/ }),

/***/ 46602:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/cosmos");;

/***/ }),

/***/ 47339:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patchFetch: () => (/* binding */ patchFetch),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),
/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96559);
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37719);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Users_dikshantvashistha_PrepBettr_app_api_question_bank_invalidate_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30120);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_dikshantvashistha_PrepBettr_app_api_question_bank_invalidate_route_ts__WEBPACK_IMPORTED_MODULE_3__]);
_Users_dikshantvashistha_PrepBettr_app_api_question_bank_invalidate_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,
        page: "/api/question-bank/invalidate/route",
        pathname: "/api/question-bank/invalidate",
        filename: "route",
        bundlePath: "app/api/question-bank/invalidate/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/question-bank/invalidate/route.ts",
    nextConfigOutput,
    userland: _Users_dikshantvashistha_PrepBettr_app_api_question_bank_invalidate_route_ts__WEBPACK_IMPORTED_MODULE_3__
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 48161:
/***/ ((module) => {

"use strict";
module.exports = require("node:os");

/***/ }),

/***/ 51455:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs/promises");

/***/ }),

/***/ 53802:
/***/ ((module) => {

"use strict";
module.exports = require("node:child_process");

/***/ }),

/***/ 55511:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 55591:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 57075:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 57975:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 62201:
/***/ ((module) => {

"use strict";
module.exports = require("@azure/keyvault-secrets");

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 73024:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 73136:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 73496:
/***/ ((module) => {

"use strict";
module.exports = require("http2");

/***/ }),

/***/ 74075:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 76760:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 77598:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 79551:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 79646:
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ 81630:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 83997:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 91645:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 96559:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (false) {} else {
    if (false) {} else {
        if (false) {} else {
            if (false) {} else {
                module.exports = __webpack_require__(44870);
            }
        }
    }
}

//# sourceMappingURL=module.compiled.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8794,8833,6716,8180,5506,5191,6955,3685,1628], () => (__webpack_exec__(47339)));
module.exports = __webpack_exports__;

})();