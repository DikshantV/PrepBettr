(() => {
var exports = {};
exports.id = 3756;
exports.ids = [3756];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 27916:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/config/[key]/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
;// ./app/api/config/[key]/route.ts
/**
 * GET /api/config/[key]
 * 
 * Unified configuration API endpoint for feature flags and app settings.
 * Used by useUnifiedConfig hook for client-side configuration access.
 */ 
/**
 * Default configuration values
 * This acts as fallback when external configuration services are unavailable
 */ const DEFAULT_CONFIG = {
    // Feature flags
    'features.voiceInterviewV2': false,
    'features.autoApplyAzure': false,
    'features.voiceInterview': true,
    'features.premiumFeatures': true,
    'features.newUI': false,
    // Application core settings
    'core.app.environment': "production" || 0 || 0,
    'core.app.version': '1.0.0',
    'core.app.debug': "production" === 'development',
    'core.app.maintenanceMode': false,
    // Usage quotas (server-side only, safe to expose limits)
    'quotas.freeInterviews': 3,
    'quotas.freeResumes': 5,
    'quotas.premiumInterviews': 50,
    // Performance settings
    'perf.cacheTimeout': 300000,
    'perf.maxRetries': 3,
    'perf.requestTimeout': 30000
};
/**
 * Validate configuration key format
 */ function validateConfigKey(key) {
    if (!key || typeof key !== 'string') {
        return {
            isValid: false,
            error: 'Configuration key is required'
        };
    }
    if (key.length > 100) {
        return {
            isValid: false,
            error: 'Configuration key too long'
        };
    }
    // Allow alphanumeric, dots, underscores, hyphens
    if (!/^[a-zA-Z0-9._-]+$/.test(key)) {
        return {
            isValid: false,
            error: 'Invalid characters in configuration key'
        };
    }
    return {
        isValid: true
    };
}
/**
 * Get configuration value with fallback hierarchy
 */ async function getConfigValue(key) {
    // 1. Try Azure App Configuration (if available in production)
    if (true) {
        try {
            // In a real implementation, this would use Azure App Configuration SDK
            // For now, we'll use environment variables as a proxy
            const envKey = key.replace(/\./g, '_').toUpperCase();
            const envValue = process.env[envKey];
            if (envValue !== undefined) {
                // Parse boolean and numeric values
                let parsedValue = envValue;
                if (envValue === 'true') parsedValue = true;
                else if (envValue === 'false') parsedValue = false;
                else if (/^\d+$/.test(envValue)) parsedValue = parseInt(envValue, 10);
                else if (/^\d+\.\d+$/.test(envValue)) parsedValue = parseFloat(envValue);
                return {
                    value: parsedValue,
                    source: 'environment'
                };
            }
        } catch (error) {
            console.warn(`Failed to fetch config from environment for key ${key}:`, error);
        }
    }
    // 2. Try Firebase Remote Config (fallback)
    try {
    // For client-side feature flags, we can use Firebase Remote Config
    // This would require the Firebase Admin SDK in a real implementation
    // For now, we'll skip this step
    } catch (error) {
        console.warn(`Failed to fetch config from Firebase for key ${key}:`, error);
    }
    // 3. Use default configuration
    const defaultValue = DEFAULT_CONFIG[key];
    if (defaultValue !== undefined) {
        return {
            value: defaultValue,
            source: 'default'
        };
    }
    // 4. Return undefined for unknown keys
    return {
        value: undefined,
        source: 'default'
    };
}
/**
 * GET handler for configuration values
 */ async function GET(request, { params }) {
    const resolvedParams = await params;
    try {
        const key = decodeURIComponent(resolvedParams.key);
        // Validate configuration key
        const keyValidation = validateConfigKey(key);
        if (!keyValidation.isValid) {
            return server.NextResponse.json({
                key,
                value: undefined,
                source: 'default',
                success: false,
                error: keyValidation.error
            }, {
                status: 400
            });
        }
        // Get configuration value
        const { value, source } = await getConfigValue(key);
        return server.NextResponse.json({
            key,
            value,
            source,
            success: true
        });
    } catch (error) {
        console.error('Failed to get configuration value:', error);
        return server.NextResponse.json({
            key: resolvedParams.key || 'unknown',
            value: undefined,
            source: 'default',
            success: false,
            error: error instanceof Error ? error.message : 'Internal server error'
        }, {
            status: 500
        });
    }
}
/**
 * POST handler for updating configuration values (admin only)
 * This would typically require authentication and authorization
 */ async function POST(request, { params }) {
    const resolvedParams = await params;
    // TODO: Add authentication middleware
    // TODO: Add authorization checks for admin users
    // TODO: Implement configuration updates to Azure App Configuration
    return server.NextResponse.json({
        error: 'Configuration updates not yet implemented'
    }, {
        status: 501
    });
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fconfig%2F%5Bkey%5D%2Froute&name=app%2Fapi%2Fconfig%2F%5Bkey%5D%2Froute&pagePath=private-next-app-dir%2Fapi%2Fconfig%2F%5Bkey%5D%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Fconfig%2F%5Bkey%5D%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/config/[key]/route",
        pathname: "/api/config/[key]",
        filename: "route",
        bundlePath: "app/api/config/[key]/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/config/[key]/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 44870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 96559:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (false) {} else {
    if (false) {} else {
        if (false) {} else {
            if (false) {} else {
                module.exports = __webpack_require__(44870);
            }
        }
    }
}

//# sourceMappingURL=module.compiled.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80], () => (__webpack_exec__(27916)));
module.exports = __webpack_exports__;

})();