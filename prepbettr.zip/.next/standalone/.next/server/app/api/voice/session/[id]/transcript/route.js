"use strict";
(() => {
var exports = {};
exports.id = 7350;
exports.ids = [7350];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10756:
/***/ ((module) => {

module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 36695:
/***/ ((module) => {

module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 52179:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DELETE: () => (/* binding */ DELETE),
/* harmony export */   GET: () => (/* binding */ GET)
/* harmony export */ });
/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32190);
/* harmony import */ var _lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49359);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__]);
_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * GET /api/voice/session/[id]/transcript
 * 
 * Retrieves transcript events for an Azure AI Foundry voice session.
 * In future versions, this will use Redis or database for persistence.
 */ 

/**
 * In-memory storage for transcripts (replace with Redis/database in production)
 * Key: sessionId, Value: array of transcript entries
 */ const transcriptStorage = new Map();
/**
 * Add transcript entry to storage
 */ function addTranscriptEntry(sessionId, entry) {
    if (!transcriptStorage.has(sessionId)) {
        transcriptStorage.set(sessionId, []);
    }
    const transcripts = transcriptStorage.get(sessionId);
    transcripts.push(entry);
    // Limit storage to last 1000 entries per session to prevent memory issues
    if (transcripts.length > 1000) {
        transcripts.splice(0, transcripts.length - 1000);
    }
    console.log(`📝 [TranscriptStorage] Added entry for session ${sessionId}: "${entry.text.substring(0, 50)}..."`);
}
/**
 * Clear transcript storage for a session
 */ function clearTranscriptStorage(sessionId) {
    transcriptStorage.delete(sessionId);
    console.log(`🗑️ [TranscriptStorage] Cleared storage for session ${sessionId}`);
}
/**
 * Validate session ID format
 */ function validateSessionId(sessionId) {
    if (!sessionId || typeof sessionId !== 'string') {
        return {
            isValid: false,
            error: 'Session ID is required'
        };
    }
    if (sessionId.length < 10 || sessionId.length > 100) {
        return {
            isValid: false,
            error: 'Invalid session ID format'
        };
    }
    // Basic format validation
    if (!/^[a-zA-Z0-9\-_]+$/.test(sessionId)) {
        return {
            isValid: false,
            error: 'Session ID contains invalid characters'
        };
    }
    return {
        isValid: true
    };
}
/**
 * Parse and validate query parameters
 */ function parseQueryParams(searchParams) {
    let limit = 100; // Default limit
    let offset = 0; // Default offset
    let finalOnly = false;
    let source;
    // Parse limit
    const limitParam = searchParams.get('limit');
    if (limitParam) {
        const parsedLimit = parseInt(limitParam, 10);
        if (isNaN(parsedLimit) || parsedLimit < 1 || parsedLimit > 1000) {
            return {
                limit,
                offset,
                finalOnly,
                source,
                isValid: false,
                error: 'Limit must be between 1 and 1000'
            };
        }
        limit = parsedLimit;
    }
    // Parse offset
    const offsetParam = searchParams.get('offset');
    if (offsetParam) {
        const parsedOffset = parseInt(offsetParam, 10);
        if (isNaN(parsedOffset) || parsedOffset < 0) {
            return {
                limit,
                offset,
                finalOnly,
                source,
                isValid: false,
                error: 'Offset must be a non-negative number'
            };
        }
        offset = parsedOffset;
    }
    // Parse final_only
    const finalOnlyParam = searchParams.get('final_only');
    if (finalOnlyParam) {
        finalOnly = [
            'true',
            '1',
            'yes'
        ].includes(finalOnlyParam.toLowerCase());
    }
    // Parse source filter
    const sourceParam = searchParams.get('source');
    if (sourceParam) {
        if (![
            'user',
            'assistant'
        ].includes(sourceParam)) {
            return {
                limit,
                offset,
                finalOnly,
                source,
                isValid: false,
                error: 'Source must be either "user" or "assistant"'
            };
        }
        source = sourceParam;
    }
    return {
        limit,
        offset,
        finalOnly,
        source,
        isValid: true
    };
}
/**
 * GET handler for retrieving session transcripts
 */ async function GET(request, { params }) {
    try {
        const resolvedParams = await params;
        const sessionId = resolvedParams.id;
        console.log(`📖 [API] Retrieving transcripts for session: ${sessionId}`);
        // Validate session ID
        const sessionValidation = validateSessionId(sessionId);
        if (!sessionValidation.isValid) {
            console.error('❌ [API] Invalid session ID:', sessionValidation.error);
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                sessionId,
                transcripts: [],
                totalEntries: 0,
                error: sessionValidation.error,
                retrievedAt: new Date().toISOString()
            }, {
                status: 400
            });
        }
        // Parse query parameters
        const { searchParams } = new URL(request.url);
        const queryValidation = parseQueryParams(searchParams);
        if (!queryValidation.isValid) {
            console.error('❌ [API] Invalid query parameters:', queryValidation.error);
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                sessionId,
                transcripts: [],
                totalEntries: 0,
                error: queryValidation.error,
                retrievedAt: new Date().toISOString()
            }, {
                status: 400
            });
        }
        const { limit, offset, finalOnly, source } = queryValidation;
        // Check if session exists in voice client
        const voiceClient = (0,_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__/* .getVoiceLiveClient */ .K)();
        const sessionMeta = voiceClient.getSession(sessionId);
        if (!sessionMeta) {
            console.warn(`⚠️ [API] Session not found in voice client: ${sessionId}`);
        // Still check transcript storage in case session was recently stopped
        }
        // Retrieve transcripts from storage
        let transcripts = transcriptStorage.get(sessionId) || [];
        // Apply filters
        if (finalOnly) {
            transcripts = transcripts.filter((entry)=>entry.isFinal);
        }
        if (source) {
            transcripts = transcripts.filter((entry)=>entry.source === source);
        }
        const totalEntries = transcripts.length;
        // Apply pagination
        const paginatedTranscripts = transcripts.slice(offset, offset + limit);
        console.log(`📖 [API] Retrieved ${paginatedTranscripts.length} transcripts (total: ${totalEntries}) for session ${sessionId}`);
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: true,
            sessionId,
            transcripts: paginatedTranscripts,
            totalEntries,
            retrievedAt: new Date().toISOString()
        }, {
            status: 200
        });
    } catch (error) {
        console.error('❌ [API] Failed to retrieve transcripts:', error);
        const resolvedParams = await params;
        const sessionId = resolvedParams.id || 'unknown';
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: false,
            sessionId,
            transcripts: [],
            totalEntries: 0,
            error: error instanceof Error ? error.message : 'Internal server error',
            retrievedAt: new Date().toISOString()
        }, {
            status: 500
        });
    }
}
/**
 * DELETE handler for clearing session transcripts
 */ async function DELETE(request, { params }) {
    try {
        const resolvedParams = await params;
        const sessionId = resolvedParams.id;
        console.log(`🗑️ [API] Clearing transcripts for session: ${sessionId}`);
        // Validate session ID
        const sessionValidation = validateSessionId(sessionId);
        if (!sessionValidation.isValid) {
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                error: sessionValidation.error
            }, {
                status: 400
            });
        }
        // Clear transcript storage
        clearTranscriptStorage(sessionId);
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: true,
            sessionId,
            message: 'Transcripts cleared successfully',
            clearedAt: new Date().toISOString()
        }, {
            status: 200
        });
    } catch (error) {
        console.error('❌ [API] Failed to clear transcripts:', error);
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            error: error instanceof Error ? error.message : 'Internal server error'
        }, {
            status: 500
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 62693:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patchFetch: () => (/* binding */ patchFetch),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),
/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96559);
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37719);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Users_dikshantvashistha_PrepBettr_app_api_voice_session_id_transcript_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52179);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_dikshantvashistha_PrepBettr_app_api_voice_session_id_transcript_route_ts__WEBPACK_IMPORTED_MODULE_3__]);
_Users_dikshantvashistha_PrepBettr_app_api_voice_session_id_transcript_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,
        page: "/api/voice/session/[id]/transcript/route",
        pathname: "/api/voice/session/[id]/transcript",
        filename: "route",
        bundlePath: "app/api/voice/session/[id]/transcript/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/voice/session/[id]/transcript/route.ts",
    nextConfigOutput,
    userland: _Users_dikshantvashistha_PrepBettr_app_api_voice_session_id_transcript_route_ts__WEBPACK_IMPORTED_MODULE_3__
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,1621], () => (__webpack_exec__(62693)));
module.exports = __webpack_exports__;

})();