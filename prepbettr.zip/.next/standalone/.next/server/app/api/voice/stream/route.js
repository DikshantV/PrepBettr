(() => {
var exports = {};
exports.id = 2563;
exports.ids = [2563];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 12412:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 21820:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 27910:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 34631:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 43655:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/voice/stream/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
// EXTERNAL MODULE: ./node_modules/microsoft-cognitiveservices-speech-sdk/distrib/lib/microsoft.cognitiveservices.speech.sdk.js
var microsoft_cognitiveservices_speech_sdk = __webpack_require__(77233);
// EXTERNAL MODULE: ./lib/utils/logger.ts
var logger = __webpack_require__(97502);
// EXTERNAL MODULE: ./lib/utils/error-utils.ts
var error_utils = __webpack_require__(80922);
;// ./app/api/voice/stream/route.ts




/**
 * Azure Speech-to-Text API Endpoint
 * Converts audio blobs to text using Azure Speech Services
 */ async function POST(request) {
    return (0,error_utils/* handleAsyncError */.z$)(async ()=>{
        logger/* logger */.vF.api.request('POST /api/voice/stream', 'Processing audio for speech-to-text');
        try {
            const formData = await request.formData();
            const audioFile = formData.get('audio');
            if (!audioFile) {
                return server.NextResponse.json({
                    error: 'No audio file provided'
                }, {
                    status: 400
                });
            }
            // Validate audio file
            const validTypes = [
                'audio/wav',
                'audio/webm',
                'audio/mp4',
                'audio/ogg'
            ];
            if (!validTypes.includes(audioFile.type)) {
                logger/* logger */.vF.warn('Invalid audio type received', {
                    type: audioFile.type
                });
                return server.NextResponse.json({
                    error: `Invalid audio type: ${audioFile.type}. Supported: ${validTypes.join(', ')}`
                }, {
                    status: 400
                });
            }
            // Get Azure Speech credentials
            const speechKey = process.env.NEXT_PUBLIC_SPEECH_KEY || process.env.AZURE_SPEECH_KEY;
            const speechRegion = process.env.NEXT_PUBLIC_SPEECH_REGION || process.env.AZURE_SPEECH_REGION;
            if (!speechKey || !speechRegion) {
                logger/* logger */.vF.error('Azure Speech Service credentials not found');
                return server.NextResponse.json({
                    error: 'Speech service configuration error'
                }, {
                    status: 500
                });
            }
            // Convert File to ArrayBuffer
            const audioBuffer = await audioFile.arrayBuffer();
            const audioData = new Uint8Array(audioBuffer);
            // Configure Azure Speech SDK
            const speechConfig = microsoft_cognitiveservices_speech_sdk.SpeechConfig.fromSubscription(speechKey, speechRegion);
            speechConfig.speechRecognitionLanguage = 'en-US';
            speechConfig.setProperty(microsoft_cognitiveservices_speech_sdk.PropertyId.SpeechServiceConnection_EnableAudioLogging, "false");
            // Create audio stream from buffer
            const audioFormat = microsoft_cognitiveservices_speech_sdk.AudioStreamFormat.getWaveFormatPCM(16000, 16, 1);
            const audioStream = microsoft_cognitiveservices_speech_sdk.AudioInputStream.createPushStream(audioFormat);
            // Push audio data to stream
            audioStream.write(audioData.buffer);
            audioStream.close();
            const audioConfig = microsoft_cognitiveservices_speech_sdk.AudioConfig.fromStreamInput(audioStream);
            const recognizer = new microsoft_cognitiveservices_speech_sdk.SpeechRecognizer(speechConfig, audioConfig);
            // Perform speech recognition
            const result = await new Promise((resolve, reject)=>{
                recognizer.recognizeOnceAsync((result)=>{
                    recognizer.close();
                    resolve(result);
                }, (error)=>{
                    recognizer.close();
                    reject(error);
                });
            });
            // Process recognition result
            if (result.reason === microsoft_cognitiveservices_speech_sdk.ResultReason.RecognizedSpeech) {
                const transcript = result.text.trim();
                logger/* logger */.vF.api.response('POST /api/voice/stream', 200, {
                    transcriptLength: transcript.length,
                    audioSize: audioFile.size
                });
                return server.NextResponse.json({
                    text: transcript,
                    confidence: 0.95,
                    duration: audioFile.size / 16000 // Rough estimation
                });
            } else if (result.reason === microsoft_cognitiveservices_speech_sdk.ResultReason.NoMatch) {
                logger/* logger */.vF.warn('No speech detected in audio', {
                    audioSize: audioFile.size
                });
                return server.NextResponse.json({
                    text: '',
                    confidence: 0,
                    error: 'No speech detected'
                });
            } else {
                const errorMessage = `Speech recognition failed: ${result.reason}`;
                logger/* logger */.vF.error(errorMessage, {
                    reason: result.reason
                });
                return server.NextResponse.json({
                    error: errorMessage
                }, {
                    status: 422
                });
            }
        } catch (error) {
            logger/* logger */.vF.error('Speech-to-text processing failed', error instanceof Error ? error : new Error(String(error)));
            // Provide helpful error responses
            if (error instanceof Error) {
                if (error.message.includes('authentication')) {
                    return server.NextResponse.json({
                        error: 'Speech service authentication failed'
                    }, {
                        status: 401
                    });
                }
                if (error.message.includes('quota')) {
                    return server.NextResponse.json({
                        error: 'Speech service quota exceeded'
                    }, {
                        status: 429
                    });
                }
            }
            return server.NextResponse.json({
                error: 'Internal speech processing error'
            }, {
                status: 500
            });
        }
    }, 'POST /api/voice/stream');
}
/**
 * Health check endpoint for speech service
 */ async function GET() {
    return server.NextResponse.json({
        service: 'Azure Speech-to-Text',
        status: 'available',
        timestamp: new Date().toISOString()
    });
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fvoice%2Fstream%2Froute&name=app%2Fapi%2Fvoice%2Fstream%2Froute&pagePath=private-next-app-dir%2Fapi%2Fvoice%2Fstream%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Fvoice%2Fstream%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/voice/stream/route",
        pathname: "/api/voice/stream",
        filename: "route",
        bundlePath: "app/api/voice/stream/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/voice/stream/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 44870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 55511:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 55591:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 57104:
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 74075:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 79428:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 79551:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 80922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N7: () => (/* binding */ reportError),
/* harmony export */   p6: () => (/* binding */ showErrorNotification),
/* harmony export */   z$: () => (/* binding */ handleAsyncError)
/* harmony export */ });
/* unused harmony exports withRetry, withTimeout, safeJsonParse, handleApiError, ValidationError, AudioError */
/* harmony import */ var _logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(97502);
/**
 * Error handling utilities to centralize try-catch patterns
 * Reduces duplicate error handling code throughout the application
 */ 
/**
 * Standardized error reporting with context
 */ const reportError = (error, context, additionalContext)=>{
    const err = error instanceof Error ? error : new Error(String(error));
    _logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.error(`${context}: ${err.message}`, err, additionalContext);
    return err;
};
/**
 * Wrap async functions with standardized error handling
 */ const handleAsyncError = async (fn, context, fallback, additionalContext)=>{
    try {
        return await fn();
    } catch (error) {
        reportError(error, context, additionalContext);
        return fallback;
    }
};
/**
 * Retry wrapper with exponential backoff
 */ const withRetry = async (fn, maxAttempts = 3, context = 'Operation', baseDelay = 1000)=>{
    let attempt = 0;
    while(attempt < maxAttempts){
        try {
            return await fn();
        } catch (error) {
            attempt++;
            if (attempt >= maxAttempts) {
                throw reportError(error, `${context} failed after ${maxAttempts} attempts`);
            }
            const delay = Math.pow(2, attempt) * baseDelay;
            logger.warn(`${context} attempt ${attempt} failed, retrying in ${delay}ms`, {
                error
            });
            await new Promise((resolve)=>setTimeout(resolve, delay));
        }
    }
    throw new Error(`${context}: Exhausted all retry attempts`);
};
/**
 * Timeout wrapper for promises
 */ const withTimeout = (promise, timeoutMs, context = 'Operation')=>{
    return Promise.race([
        promise,
        new Promise((_, reject)=>{
            setTimeout(()=>{
                reject(new Error(`${context} timed out after ${timeoutMs}ms`));
            }, timeoutMs);
        })
    ]);
};
/**
 * Safe JSON parsing with error handling
 */ const safeJsonParse = (jsonString, fallback, context = 'JSON parse')=>{
    try {
        return JSON.parse(jsonString);
    } catch (error) {
        reportError(error, `${context} failed`, {
            jsonString: jsonString.slice(0, 100)
        });
        return fallback;
    }
};
/**
 * Network request error handler with user-friendly messages
 */ const handleApiError = (response, context = 'API request')=>{
    const friendlyMessages = {
        400: 'Invalid request. Please check your input and try again.',
        401: 'Authentication failed. Please sign in again.',
        403: 'Access denied. You may not have permission for this action.',
        404: 'The requested resource was not found.',
        429: 'Too many requests. Please wait a moment before trying again.',
        500: 'Server error. Please try again later.',
        502: 'Service temporarily unavailable. Please try again later.',
        503: 'Service temporarily unavailable. Please try again later.'
    };
    const friendlyMessage = friendlyMessages[response.status] || 'An unexpected error occurred.';
    const technicalMessage = `${context}: HTTP ${response.status} ${response.statusText}`;
    const error = new Error(friendlyMessage);
    error.technicalMessage = technicalMessage;
    error.status = response.status;
    return error;
};
/**
 * Show user-friendly error notification (replace alert() calls)
 * This will hook into the app's existing toast system
 */ const showErrorNotification = (error, context)=>{
    const message = typeof error === 'string' ? error : error.message;
    const fullMessage = context ? `${context}: ${message}` : message;
    // Use console.warn for user notifications to reduce error noise
    _logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('User notification: ' + fullMessage);
// TODO: Replace with actual toast notification system
// toast.error(fullMessage);
};
/**
 * Validation error for form/input validation
 */ class ValidationError extends Error {
    constructor(message, field){
        super(message), this.field = field;
        this.name = 'ValidationError';
    }
}
/**
 * Audio processing specific error
 */ class AudioError extends Error {
    constructor(message, audioContext){
        super(message), this.audioContext = audioContext;
        this.name = 'AudioError';
    }
}


/***/ }),

/***/ 81630:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 83997:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 90305:
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ 91645:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 97502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   vF: () => (/* binding */ logger)
/* harmony export */ });
/* unused harmony exports debug, info, success, warn, error */
/**
 * Centralized logging utility with debug flag support
 * Helps reduce verbose console.debug statements throughout the codebase
 */ // Environment-based debug flag
const DEBUG =  false || process.env.DEBUG === 'true';
/**
 * Core logger with emoji prefixes for visual recognition
 */ const logger = {
    debug: (message, context)=>{
        if (DEBUG) {
            context ? console.debug(`🔍 ${message}`, context) : console.debug(`🔍 ${message}`);
        }
    },
    info: (message, context)=>{
        context ? console.info(`ℹ️ ${message}`, context) : console.info(`ℹ️ ${message}`);
    },
    success: (message, context)=>{
        context ? console.log(`✅ ${message}`, context) : console.log(`✅ ${message}`);
    },
    warn: (message, context)=>{
        context ? console.warn(`⚠️ ${message}`, context) : console.warn(`⚠️ ${message}`);
    },
    error: (message, error, context)=>{
        const errorInfo = error instanceof Error ? {
            message: error.message,
            stack: error.stack
        } : error;
        context ? console.error(`❌ ${message}`, {
            error: errorInfo,
            ...context
        }) : console.error(`❌ ${message}`, errorInfo);
    },
    // Audio-specific logging shortcuts
    audio: {
        process: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎵 ${message}`, context) : console.debug(`🎵 ${message}`);
            }
        },
        record: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎤 ${message}`, context) : console.debug(`🎤 ${message}`);
            }
        },
        speak: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🔊 ${message}`, context) : console.debug(`🔊 ${message}`);
            }
        }
    },
    // State management logging
    state: (action, from, to, context)=>{
        if (DEBUG) {
            const message = `State transition: ${from} → ${to}`;
            context ? console.debug(`🔄 [${action}] ${message}`, context) : console.debug(`🔄 [${action}] ${message}`);
        }
    },
    // API request logging
    api: {
        request: (endpoint, method, context)=>{
            if (DEBUG) {
                context ? console.debug(`📤 API ${method} ${endpoint}`, context) : console.debug(`📤 API ${method} ${endpoint}`);
            }
        },
        response: (endpoint, status, context)=>{
            const icon = status >= 200 && status < 300 ? '📥' : '❌';
            if (DEBUG) {
                context ? console.debug(`${icon} API Response ${status} ${endpoint}`, context) : console.debug(`${icon} API Response ${status} ${endpoint}`);
            }
        }
    }
};
// Convenience exports
const { debug, info, success, warn, error } = logger;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8794,2143], () => (__webpack_exec__(43655)));
module.exports = __webpack_exports__;

})();