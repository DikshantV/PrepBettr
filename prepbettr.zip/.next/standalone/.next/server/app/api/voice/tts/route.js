(() => {
var exports = {};
exports.id = 6002;
exports.ids = [6002];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 12412:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 21820:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 27910:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 34631:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 44870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 45807:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./app/api/voice/tts/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  OPTIONS: () => (OPTIONS),
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(96559);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(48088);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(37719);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
// EXTERNAL MODULE: ./node_modules/microsoft-cognitiveservices-speech-sdk/distrib/lib/microsoft.cognitiveservices.speech.sdk.js
var microsoft_cognitiveservices_speech_sdk = __webpack_require__(77233);
// EXTERNAL MODULE: ./lib/utils/logger.ts
var logger = __webpack_require__(97502);
// EXTERNAL MODULE: ./lib/utils/error-utils.ts
var error_utils = __webpack_require__(80922);
;// ./app/api/voice/tts/route.ts




/**
 * Azure Text-to-Speech API Endpoint
 * Converts text to speech using Azure Speech Services
 */ async function POST(request) {
    return (0,error_utils/* handleAsyncError */.z$)(async ()=>{
        try {
            const body = await request.json();
            const { text, voice = 'en-US-SaraNeural', rate = '1.0', pitch = '0Hz' } = body;
            logger/* logger */.vF.api.request('POST /api/voice/tts', `Converting text to speech (${text.length} chars)`);
            if (!text || !text.trim()) {
                return server.NextResponse.json({
                    error: 'Text is required'
                }, {
                    status: 400
                });
            }
            if (text.length > 5000) {
                return server.NextResponse.json({
                    error: 'Text too long (max 5000 characters)'
                }, {
                    status: 400
                });
            }
            // Get Azure Speech credentials
            const speechKey = process.env.NEXT_PUBLIC_SPEECH_KEY || process.env.AZURE_SPEECH_KEY;
            const speechRegion = process.env.NEXT_PUBLIC_SPEECH_REGION || process.env.AZURE_SPEECH_REGION;
            if (!speechKey || !speechRegion) {
                logger/* logger */.vF.error('Azure Speech Service credentials not found');
                return server.NextResponse.json({
                    error: 'Speech service configuration error'
                }, {
                    status: 500
                });
            }
            // Configure Azure Speech SDK
            const speechConfig = microsoft_cognitiveservices_speech_sdk.SpeechConfig.fromSubscription(speechKey, speechRegion);
            speechConfig.speechSynthesisVoiceName = voice;
            speechConfig.speechSynthesisOutputFormat = microsoft_cognitiveservices_speech_sdk.SpeechSynthesisOutputFormat.Audio16Khz32KBitRateMonoMp3;
            // Create synthesizer with null audio config to get raw audio data
            const synthesizer = new microsoft_cognitiveservices_speech_sdk.SpeechSynthesizer(speechConfig, undefined);
            // Create SSML for better control
            const ssml = `
        <speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">
          <voice name="${voice}">
            <prosody rate="${rate}" pitch="${pitch}">
              ${escapeXml(text)}
            </prosody>
          </voice>
        </speak>
      `.trim();
            // Synthesize speech
            const result = await new Promise((resolve, reject)=>{
                synthesizer.speakSsmlAsync(ssml, (result)=>{
                    synthesizer.close();
                    resolve(result);
                }, (error)=>{
                    synthesizer.close();
                    reject(error);
                });
            });
            // Process synthesis result
            if (result.reason === microsoft_cognitiveservices_speech_sdk.ResultReason.SynthesizingAudioCompleted) {
                const audioData = result.audioData;
                logger/* logger */.vF.api.response('POST /api/voice/tts', 200, {
                    textLength: text.length,
                    audioSize: audioData.byteLength,
                    voice: voice
                });
                // Return audio as blob
                return new server.NextResponse(audioData, {
                    status: 200,
                    headers: {
                        'Content-Type': 'audio/mpeg',
                        'Content-Length': audioData.byteLength.toString(),
                        'Cache-Control': 'public, max-age=3600',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                        'Access-Control-Allow-Headers': 'Content-Type'
                    }
                });
            } else if (result.reason === microsoft_cognitiveservices_speech_sdk.ResultReason.Canceled) {
                const cancellationDetails = microsoft_cognitiveservices_speech_sdk.CancellationDetails.fromResult(result);
                const errorMessage = `TTS canceled: ${cancellationDetails.reason} - ${cancellationDetails.errorDetails}`;
                logger/* logger */.vF.error(errorMessage);
                if (cancellationDetails.reason === microsoft_cognitiveservices_speech_sdk.CancellationReason.Error) {
                    if (cancellationDetails.errorDetails?.includes('authentication')) {
                        return server.NextResponse.json({
                            error: 'Speech service authentication failed'
                        }, {
                            status: 401
                        });
                    }
                    if (cancellationDetails.errorDetails?.includes('quota')) {
                        return server.NextResponse.json({
                            error: 'Speech service quota exceeded'
                        }, {
                            status: 429
                        });
                    }
                }
                return server.NextResponse.json({
                    error: 'Speech synthesis failed'
                }, {
                    status: 422
                });
            } else {
                const errorMessage = `TTS failed with reason: ${result.reason}`;
                logger/* logger */.vF.error(errorMessage);
                return server.NextResponse.json({
                    error: errorMessage
                }, {
                    status: 422
                });
            }
        } catch (error) {
            logger/* logger */.vF.error('Text-to-speech processing failed', error instanceof Error ? error : new Error(String(error)));
            // Provide helpful error responses
            if (error instanceof Error) {
                if (error.message.includes('authentication')) {
                    return server.NextResponse.json({
                        error: 'Speech service authentication failed'
                    }, {
                        status: 401
                    });
                }
                if (error.message.includes('quota') || error.message.includes('rate limit')) {
                    return server.NextResponse.json({
                        error: 'Speech service quota exceeded'
                    }, {
                        status: 429
                    });
                }
                if (error.message.includes('timeout')) {
                    return server.NextResponse.json({
                        error: 'Speech service timeout'
                    }, {
                        status: 408
                    });
                }
            }
            return server.NextResponse.json({
                error: 'Internal TTS processing error'
            }, {
                status: 500
            });
        }
    }, 'POST /api/voice/tts');
}
/**
 * GET endpoint to list available voices
 */ async function GET() {
    return server.NextResponse.json({
        service: 'Azure Text-to-Speech',
        status: 'available',
        availableVoices: [
            {
                name: 'en-US-SaraNeural',
                displayName: 'Sara (Neural)',
                gender: 'Female',
                language: 'en-US'
            },
            {
                name: 'en-US-JennyNeural',
                displayName: 'Jenny (Neural)',
                gender: 'Female',
                language: 'en-US'
            },
            {
                name: 'en-US-AriaNeural',
                displayName: 'Aria (Neural)',
                gender: 'Female',
                language: 'en-US'
            },
            {
                name: 'en-US-ChristopherNeural',
                displayName: 'Christopher (Neural)',
                gender: 'Male',
                language: 'en-US'
            },
            {
                name: 'en-US-EricNeural',
                displayName: 'Eric (Neural)',
                gender: 'Male',
                language: 'en-US'
            },
            {
                name: 'en-US-GuyNeural',
                displayName: 'Guy (Neural)',
                gender: 'Male',
                language: 'en-US'
            }
        ],
        timestamp: new Date().toISOString()
    });
}
/**
 * Handle CORS preflight requests
 */ async function OPTIONS() {
    return new server.NextResponse(null, {
        status: 200,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        }
    });
}
/**
 * Escape XML special characters for SSML
 */ function escapeXml(text) {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fvoice%2Ftts%2Froute&name=app%2Fapi%2Fvoice%2Ftts%2Froute&pagePath=private-next-app-dir%2Fapi%2Fvoice%2Ftts%2Froute.ts&appDir=%2FUsers%2Fdikshantvashistha%2FPrepBettr%2Fapp&appPaths=%2Fapi%2Fvoice%2Ftts%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&nextConfigExperimentalUseEarlyImport=&preferredRegion=&middlewareConfig=e30%3D!




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/voice/tts/route",
        pathname: "/api/voice/tts",
        filename: "route",
        bundlePath: "app/api/voice/tts/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/voice/tts/route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 55511:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 55591:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 57104:
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 74075:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 79428:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 79551:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 80922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N7: () => (/* binding */ reportError),
/* harmony export */   p6: () => (/* binding */ showErrorNotification),
/* harmony export */   z$: () => (/* binding */ handleAsyncError)
/* harmony export */ });
/* unused harmony exports withRetry, withTimeout, safeJsonParse, handleApiError, ValidationError, AudioError */
/* harmony import */ var _logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(97502);
/**
 * Error handling utilities to centralize try-catch patterns
 * Reduces duplicate error handling code throughout the application
 */ 
/**
 * Standardized error reporting with context
 */ const reportError = (error, context, additionalContext)=>{
    const err = error instanceof Error ? error : new Error(String(error));
    _logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.error(`${context}: ${err.message}`, err, additionalContext);
    return err;
};
/**
 * Wrap async functions with standardized error handling
 */ const handleAsyncError = async (fn, context, fallback, additionalContext)=>{
    try {
        return await fn();
    } catch (error) {
        reportError(error, context, additionalContext);
        return fallback;
    }
};
/**
 * Retry wrapper with exponential backoff
 */ const withRetry = async (fn, maxAttempts = 3, context = 'Operation', baseDelay = 1000)=>{
    let attempt = 0;
    while(attempt < maxAttempts){
        try {
            return await fn();
        } catch (error) {
            attempt++;
            if (attempt >= maxAttempts) {
                throw reportError(error, `${context} failed after ${maxAttempts} attempts`);
            }
            const delay = Math.pow(2, attempt) * baseDelay;
            logger.warn(`${context} attempt ${attempt} failed, retrying in ${delay}ms`, {
                error
            });
            await new Promise((resolve)=>setTimeout(resolve, delay));
        }
    }
    throw new Error(`${context}: Exhausted all retry attempts`);
};
/**
 * Timeout wrapper for promises
 */ const withTimeout = (promise, timeoutMs, context = 'Operation')=>{
    return Promise.race([
        promise,
        new Promise((_, reject)=>{
            setTimeout(()=>{
                reject(new Error(`${context} timed out after ${timeoutMs}ms`));
            }, timeoutMs);
        })
    ]);
};
/**
 * Safe JSON parsing with error handling
 */ const safeJsonParse = (jsonString, fallback, context = 'JSON parse')=>{
    try {
        return JSON.parse(jsonString);
    } catch (error) {
        reportError(error, `${context} failed`, {
            jsonString: jsonString.slice(0, 100)
        });
        return fallback;
    }
};
/**
 * Network request error handler with user-friendly messages
 */ const handleApiError = (response, context = 'API request')=>{
    const friendlyMessages = {
        400: 'Invalid request. Please check your input and try again.',
        401: 'Authentication failed. Please sign in again.',
        403: 'Access denied. You may not have permission for this action.',
        404: 'The requested resource was not found.',
        429: 'Too many requests. Please wait a moment before trying again.',
        500: 'Server error. Please try again later.',
        502: 'Service temporarily unavailable. Please try again later.',
        503: 'Service temporarily unavailable. Please try again later.'
    };
    const friendlyMessage = friendlyMessages[response.status] || 'An unexpected error occurred.';
    const technicalMessage = `${context}: HTTP ${response.status} ${response.statusText}`;
    const error = new Error(friendlyMessage);
    error.technicalMessage = technicalMessage;
    error.status = response.status;
    return error;
};
/**
 * Show user-friendly error notification (replace alert() calls)
 * This will hook into the app's existing toast system
 */ const showErrorNotification = (error, context)=>{
    const message = typeof error === 'string' ? error : error.message;
    const fullMessage = context ? `${context}: ${message}` : message;
    // Use console.warn for user notifications to reduce error noise
    _logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('User notification: ' + fullMessage);
// TODO: Replace with actual toast notification system
// toast.error(fullMessage);
};
/**
 * Validation error for form/input validation
 */ class ValidationError extends Error {
    constructor(message, field){
        super(message), this.field = field;
        this.name = 'ValidationError';
    }
}
/**
 * Audio processing specific error
 */ class AudioError extends Error {
    constructor(message, audioContext){
        super(message), this.audioContext = audioContext;
        this.name = 'AudioError';
    }
}


/***/ }),

/***/ 81630:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 83997:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 90305:
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ 91645:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 97502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   vF: () => (/* binding */ logger)
/* harmony export */ });
/* unused harmony exports debug, info, success, warn, error */
/**
 * Centralized logging utility with debug flag support
 * Helps reduce verbose console.debug statements throughout the codebase
 */ // Environment-based debug flag
const DEBUG =  false || process.env.DEBUG === 'true';
/**
 * Core logger with emoji prefixes for visual recognition
 */ const logger = {
    debug: (message, context)=>{
        if (DEBUG) {
            context ? console.debug(`🔍 ${message}`, context) : console.debug(`🔍 ${message}`);
        }
    },
    info: (message, context)=>{
        context ? console.info(`ℹ️ ${message}`, context) : console.info(`ℹ️ ${message}`);
    },
    success: (message, context)=>{
        context ? console.log(`✅ ${message}`, context) : console.log(`✅ ${message}`);
    },
    warn: (message, context)=>{
        context ? console.warn(`⚠️ ${message}`, context) : console.warn(`⚠️ ${message}`);
    },
    error: (message, error, context)=>{
        const errorInfo = error instanceof Error ? {
            message: error.message,
            stack: error.stack
        } : error;
        context ? console.error(`❌ ${message}`, {
            error: errorInfo,
            ...context
        }) : console.error(`❌ ${message}`, errorInfo);
    },
    // Audio-specific logging shortcuts
    audio: {
        process: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎵 ${message}`, context) : console.debug(`🎵 ${message}`);
            }
        },
        record: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎤 ${message}`, context) : console.debug(`🎤 ${message}`);
            }
        },
        speak: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🔊 ${message}`, context) : console.debug(`🔊 ${message}`);
            }
        }
    },
    // State management logging
    state: (action, from, to, context)=>{
        if (DEBUG) {
            const message = `State transition: ${from} → ${to}`;
            context ? console.debug(`🔄 [${action}] ${message}`, context) : console.debug(`🔄 [${action}] ${message}`);
        }
    },
    // API request logging
    api: {
        request: (endpoint, method, context)=>{
            if (DEBUG) {
                context ? console.debug(`📤 API ${method} ${endpoint}`, context) : console.debug(`📤 API ${method} ${endpoint}`);
            }
        },
        response: (endpoint, status, context)=>{
            const icon = status >= 200 && status < 300 ? '📥' : '❌';
            if (DEBUG) {
                context ? console.debug(`${icon} API Response ${status} ${endpoint}`, context) : console.debug(`${icon} API Response ${status} ${endpoint}`);
            }
        }
    }
};
// Convenience exports
const { debug, info, success, warn, error } = logger;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8794,2143], () => (__webpack_exec__(45807)));
module.exports = __webpack_exports__;

})();