"use strict";
(() => {
var exports = {};
exports.id = 4376;
exports.ids = [4376];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10756:
/***/ ((module) => {

module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 36695:
/***/ ((module) => {

module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 39649:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patchFetch: () => (/* binding */ patchFetch),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),
/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96559);
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37719);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Users_dikshantvashistha_PrepBettr_app_api_voice_session_id_stop_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53781);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_dikshantvashistha_PrepBettr_app_api_voice_session_id_stop_route_ts__WEBPACK_IMPORTED_MODULE_3__]);
_Users_dikshantvashistha_PrepBettr_app_api_voice_session_id_stop_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,
        page: "/api/voice/session/[id]/stop/route",
        pathname: "/api/voice/session/[id]/stop",
        filename: "route",
        bundlePath: "app/api/voice/session/[id]/stop/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/voice/session/[id]/stop/route.ts",
    nextConfigOutput,
    userland: _Users_dikshantvashistha_PrepBettr_app_api_voice_session_id_stop_route_ts__WEBPACK_IMPORTED_MODULE_3__
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 53153:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ VoiceSession)
/* harmony export */ });
/* harmony import */ var _voice_telemetry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(90342);
/**
 * Azure AI Foundry Voice Session
 * 
 * Manages the lifecycle of a voice streaming session, including audio input/output,
 * transcript handling, and WebSocket communication.
 */ 
/**
 * Voice Session class for managing real-time voice streaming
 */ class VoiceSession {
    constructor(client, sessionMeta){
        this.state = 'idle';
        this.audioContext = null;
        this.mediaStream = null;
        this.audioWorkletNode = null;
        this.transcriptCallbacks = new Set();
        this.responseCallbacks = new Set();
        this.audioConfig = {
            sampleRate: 16000,
            channels: 1,
            chunkDurationMs: 20,
            bufferSize: 320 // 20ms * 16kHz = 320 samples
        };
        // Cleanup handling
        this.cleanupHandlers = new Set();
        this.isPageUnloading = false;
        this.client = client;
        this.sessionMeta = sessionMeta;
        this.websocketManager = client.createWebSocketManager(sessionMeta);
        // Setup page unload cleanup
        this.setupPageUnloadCleanup();
    }
    /**
   * Start the voice session and begin audio streaming
   */ async start(audioStream) {
        if (this.state !== 'idle') {
            console.warn(`⚠️ [VoiceSession] Cannot start: current state is ${this.state}`);
            return;
        }
        this.state = 'starting';
        const sessionStartTime = Date.now();
        console.log(`🚀 [VoiceSession] Starting session ${this.sessionMeta.sessionId}...`);
        // Initialize telemetry for this session
        _voice_telemetry__WEBPACK_IMPORTED_MODULE_0__/* .VoiceTelemetry */ .Ev.startSession(this.sessionMeta.sessionId);
        try {
            // Initialize audio context
            await this.initializeAudioContext();
            // Get audio stream (use provided or request new one)
            if (audioStream) {
                this.mediaStream = audioStream;
            } else {
                await this.requestMicrophoneAccess();
            }
            // Connect WebSocket
            await this.websocketManager.connect();
            // Setup WebSocket event handlers
            this.setupWebSocketHandlers();
            // Start audio processing
            await this.startAudioProcessing();
            this.state = 'active';
            console.log(`✅ [VoiceSession] Session ${this.sessionMeta.sessionId} started successfully`);
        } catch (error) {
            console.error(`❌ [VoiceSession] Failed to start session:`, error);
            this.state = 'error';
            await this.cleanup();
            throw error;
        }
    }
    /**
   * Register callback for transcript events
   */ onTranscript(callback) {
        this.transcriptCallbacks.add(callback);
        // Add cleanup handler
        this.cleanupHandlers.add(()=>{
            this.transcriptCallbacks.delete(callback);
        });
    }
    /**
   * Register callback for audio response events
   */ onResponse(callback) {
        this.responseCallbacks.add(callback);
        // Add cleanup handler
        this.cleanupHandlers.add(()=>{
            this.responseCallbacks.delete(callback);
        });
    }
    /**
   * Stop the session gracefully
   */ async stop(graceful = true) {
        if (this.state === 'stopped' || this.state === 'stopping') {
            return;
        }
        this.state = 'stopping';
        console.log(`🛑 [VoiceSession] Stopping session ${this.sessionMeta.sessionId}...`);
        try {
            if (graceful) {
                // Send final audio chunk and wait for pending responses
                await this.flushAudioBuffers();
                await this.waitForPendingResponses();
            }
            // Close WebSocket connection
            this.websocketManager.close(graceful ? 1000 : 1001, graceful ? 'Normal closure' : 'Forced closure');
            // Clean up audio resources
            await this.cleanup();
            // Remove from client's active sessions
            this.client.removeSession(this.sessionMeta.sessionId);
            this.state = 'stopped';
            console.log(`✅ [VoiceSession] Session ${this.sessionMeta.sessionId} stopped successfully`);
        } catch (error) {
            console.error(`❌ [VoiceSession] Error stopping session:`, error);
            this.state = 'error';
            throw error;
        }
    }
    /**
   * Get current session state
   */ getState() {
        return this.state;
    }
    /**
   * Get session ID
   */ get sessionId() {
        return this.sessionMeta.sessionId;
    }
    /**
   * Get session metadata
   */ getMetadata() {
        return {
            ...this.sessionMeta
        };
    }
    /**
   * Initialize audio context with optimal settings
   */ async initializeAudioContext() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)({
                sampleRate: this.audioConfig.sampleRate,
                latencyHint: 'interactive'
            });
            // Resume context if suspended (required by browser policies)
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }
            console.log(`🎵 [VoiceSession] Audio context initialized: ${this.audioContext.sampleRate}Hz`);
        } catch (error) {
            console.error('❌ [VoiceSession] Failed to initialize audio context:', error);
            throw new Error('Audio context initialization failed');
        }
    }
    /**
   * Request microphone access
   */ async requestMicrophoneAccess() {
        try {
            this.mediaStream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    sampleRate: this.audioConfig.sampleRate,
                    channelCount: this.audioConfig.channels,
                    echoCancellation: this.sessionMeta.options.audioSettings?.echoCancellation ?? true,
                    noiseSuppression: this.sessionMeta.options.audioSettings?.noiseSuppression ?? true,
                    autoGainControl: true
                }
            });
            console.log('🎤 [VoiceSession] Microphone access granted');
        } catch (error) {
            console.error('❌ [VoiceSession] Failed to access microphone:', error);
            throw new Error('Microphone access denied or failed');
        }
    }
    /**
   * Setup WebSocket event handlers
   */ setupWebSocketHandlers() {
        // Handle transcript events
        this.websocketManager.on('transcript', (data)=>{
            const transcriptEvent = {
                text: data.text || '',
                timestamp: data.timestamp || Date.now(),
                confidence: data.confidence,
                isFinal: data.is_final || false
            };
            console.log(`📝 [VoiceSession] Transcript: "${transcriptEvent.text}" (confidence: ${transcriptEvent.confidence})`);
            // Track transcript event with telemetry
            _voice_telemetry__WEBPACK_IMPORTED_MODULE_0__/* .VoiceTelemetry */ .Ev.getInstance().logTranscriptEvent(transcriptEvent.isFinal ? 'transcript_final' : 'transcript_partial', this.sessionMeta.sessionId, transcriptEvent.text, transcriptEvent.confidence);
            this.transcriptCallbacks.forEach((callback)=>{
                try {
                    callback(transcriptEvent);
                } catch (error) {
                    console.error('❌ [VoiceSession] Transcript callback error:', error);
                    _voice_telemetry__WEBPACK_IMPORTED_MODULE_0__/* .VoiceTelemetry */ .Ev.trackError(error, this.sessionMeta.sessionId, 'Transcript callback');
                }
            });
        });
        // Handle audio response events
        this.websocketManager.on('response', async (data)=>{
            if (data.audio_data) {
                try {
                    // Convert audio data to blob
                    const audioData = new Uint8Array(data.audio_data);
                    const audioBlob = new Blob([
                        audioData
                    ], {
                        type: 'audio/wav'
                    });
                    const responseEvent = {
                        audioData: audioBlob,
                        timestamp: data.timestamp || Date.now(),
                        duration: data.duration
                    };
                    console.log(`🔊 [VoiceSession] Audio response received (${audioBlob.size} bytes)`);
                    // Play audio response
                    await this.playAudioResponse(audioBlob);
                    this.responseCallbacks.forEach((callback)=>{
                        try {
                            callback(responseEvent);
                        } catch (error) {
                            console.error('❌ [VoiceSession] Response callback error:', error);
                        }
                    });
                } catch (error) {
                    console.error('❌ [VoiceSession] Failed to process audio response:', error);
                }
            }
        });
        // Handle connection events
        this.websocketManager.on('disconnected', (event)=>{
            console.warn(`⚠️ [VoiceSession] WebSocket disconnected: ${event.code} ${event.reason}`);
            if (this.state === 'active' && !this.isPageUnloading) {
                // Auto-reconnect logic is handled by WebSocketManager
                console.log('🔄 [VoiceSession] WebSocket will attempt to reconnect...');
            }
        });
        // Handle errors
        this.websocketManager.on('error', (error)=>{
            console.error('❌ [VoiceSession] WebSocket error:', error);
            this.state = 'error';
        });
    }
    /**
   * Start audio processing and streaming
   */ async startAudioProcessing() {
        if (!this.audioContext || !this.mediaStream) {
            throw new Error('Audio context or media stream not initialized');
        }
        try {
            // Create audio source from media stream
            const source = this.audioContext.createMediaStreamSource(this.mediaStream);
            // Create processor for audio chunking
            this.audioWorkletNode = await this.createAudioWorkletNode();
            // Connect audio pipeline
            source.connect(this.audioWorkletNode);
            console.log('🎵 [VoiceSession] Audio processing pipeline started');
        } catch (error) {
            console.error('❌ [VoiceSession] Failed to start audio processing:', error);
            throw error;
        }
    }
    /**
   * Create audio worklet node for processing audio chunks
   */ async createAudioWorkletNode() {
        if (!this.audioContext) {
            throw new Error('Audio context not initialized');
        }
        // Create a simple ScriptProcessorNode as fallback if AudioWorklet is not available
        // In production, you'd want to implement a proper AudioWorklet
        const bufferSize = 4096; // Fixed buffer size for ScriptProcessorNode
        const processor = this.audioContext.createScriptProcessor(bufferSize, 1, 1);
        processor.onaudioprocess = (event)=>{
            const inputBuffer = event.inputBuffer.getChannelData(0);
            // Create audio frame
            const audioFrame = {
                audioData: inputBuffer.buffer.slice(0),
                timestamp: Date.now(),
                sampleRate: this.audioConfig.sampleRate,
                channels: this.audioConfig.channels
            };
            // Send audio frame to WebSocket
            if (this.websocketManager.getState() === 'connected') {
                this.websocketManager.sendAudioFrame(audioFrame);
            }
        };
        // Connect to destination to keep the processor active
        processor.connect(this.audioContext.destination);
        return processor; // Type assertion for compatibility
    }
    /**
   * Play audio response through speakers
   */ async playAudioResponse(audioBlob) {
        try {
            if (!this.audioContext) {
                throw new Error('Audio context not available');
            }
            // Convert blob to array buffer
            const arrayBuffer = await audioBlob.arrayBuffer();
            // Decode audio data
            const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
            // Create audio source
            const source = this.audioContext.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(this.audioContext.destination);
            // Play audio
            source.start();
            console.log(`🔊 [VoiceSession] Playing audio response (${audioBuffer.duration.toFixed(2)}s)`);
        } catch (error) {
            console.error('❌ [VoiceSession] Failed to play audio response:', error);
        // Don't throw error to avoid breaking the session
        }
    }
    /**
   * Flush any pending audio buffers
   */ async flushAudioBuffers() {
        // Implementation depends on the audio processing pipeline
        console.log('🔄 [VoiceSession] Flushing audio buffers...');
        // Send a flush signal to the WebSocket
        const flushMessage = {
            type: 'control',
            data: {
                action: 'flush'
            },
            sessionId: this.sessionMeta.sessionId,
            timestamp: Date.now()
        };
        this.websocketManager.send(JSON.stringify(flushMessage));
        // Wait a bit for any pending audio to be processed
        await new Promise((resolve)=>setTimeout(resolve, 100));
    }
    /**
   * Wait for any pending responses to complete
   */ async waitForPendingResponses() {
        console.log('⏳ [VoiceSession] Waiting for pending responses...');
        // Simple timeout-based wait - in production, you'd track pending requests
        await new Promise((resolve)=>setTimeout(resolve, 500));
    }
    /**
   * Setup page unload cleanup
   */ setupPageUnloadCleanup() {
        const handlePageUnload = ()=>{
            this.isPageUnloading = true;
            this.stop(false); // Force stop on page unload
        };
        window.addEventListener('beforeunload', handlePageUnload);
        window.addEventListener('unload', handlePageUnload);
        this.cleanupHandlers.add(()=>{
            window.removeEventListener('beforeunload', handlePageUnload);
            window.removeEventListener('unload', handlePageUnload);
        });
    }
    /**
   * Clean up all resources
   */ async cleanup() {
        console.log('🧹 [VoiceSession] Cleaning up resources...');
        // Stop media stream
        if (this.mediaStream) {
            this.mediaStream.getTracks().forEach((track)=>{
                track.stop();
                console.log(`🛑 [VoiceSession] Stopped ${track.kind} track`);
            });
            this.mediaStream = null;
        }
        // Disconnect audio nodes
        if (this.audioWorkletNode) {
            this.audioWorkletNode.disconnect();
            this.audioWorkletNode = null;
        }
        // Close audio context
        if (this.audioContext && this.audioContext.state !== 'closed') {
            await this.audioContext.close();
            this.audioContext = null;
        }
        // Run cleanup handlers
        this.cleanupHandlers.forEach((handler)=>{
            try {
                handler();
            } catch (error) {
                console.error('❌ [VoiceSession] Cleanup handler error:', error);
            }
        });
        this.cleanupHandlers.clear();
        // Clear callbacks
        this.transcriptCallbacks.clear();
        this.responseCallbacks.clear();
        console.log('✅ [VoiceSession] Cleanup completed');
    }
}


/***/ }),

/***/ 53781:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GET: () => (/* binding */ GET),
/* harmony export */   POST: () => (/* binding */ POST)
/* harmony export */ });
/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32190);
/* harmony import */ var _lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49359);
/* harmony import */ var _lib_azure_ai_foundry_voice_voice_session__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(53153);
/* harmony import */ var _lib_azure_ai_foundry_voice_voice_session_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75717);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__]);
_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * POST /api/voice/session/[id]/stop
 * 
 * Stops an active Azure AI Foundry voice session and cleans up resources.
 */ 



/**
 * Validate session ID format
 */ function validateSessionId(sessionId) {
    if (!sessionId || typeof sessionId !== 'string') {
        return {
            isValid: false,
            error: 'Session ID is required'
        };
    }
    if (sessionId.length < 10 || sessionId.length > 100) {
        return {
            isValid: false,
            error: 'Invalid session ID format'
        };
    }
    // Basic format validation (adjust as needed for Azure session IDs)
    if (!/^[a-zA-Z0-9\-_]+$/.test(sessionId)) {
        return {
            isValid: false,
            error: 'Session ID contains invalid characters'
        };
    }
    return {
        isValid: true
    };
}
/**
 * POST handler for stopping voice sessions
 */ async function POST(request, { params }) {
    try {
        const resolvedParams = await params;
        const sessionId = resolvedParams.id;
        console.log(`🛑 [API] Stopping voice session: ${sessionId}`);
        // Validate session ID
        const sessionValidation = validateSessionId(sessionId);
        if (!sessionValidation.isValid) {
            console.error('❌ [API] Invalid session ID:', sessionValidation.error);
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                sessionId,
                message: 'Failed to stop session',
                error: sessionValidation.error,
                stoppedAt: new Date().toISOString()
            }, {
                status: 400
            });
        }
        // Parse request body
        let body = {};
        try {
            const requestBody = await request.text();
            if (requestBody.trim()) {
                body = JSON.parse(requestBody);
            }
        } catch (error) {
            console.warn('⚠️ [API] Invalid JSON in request body, using defaults:', error);
        // Continue with defaults if JSON is invalid
        }
        const graceful = body.graceful ?? true;
        // Get voice client and find session
        const voiceClient = (0,_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__/* .getVoiceLiveClient */ .K)();
        const sessionMeta = voiceClient.getSession(sessionId);
        if (!sessionMeta) {
            console.warn(`⚠️ [API] Session not found: ${sessionId}`);
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                sessionId,
                message: 'Session not found',
                error: 'Session does not exist or has already been stopped',
                stoppedAt: new Date().toISOString()
            }, {
                status: 404
            });
        }
        // Create VoiceSession instance and stop it
        const voiceSession = new _lib_azure_ai_foundry_voice_voice_session__WEBPACK_IMPORTED_MODULE_2__/* .VoiceSession */ .J(voiceClient, sessionMeta);
        try {
            await voiceSession.stop(graceful);
            // Clean up edge-compatible storage as well
            const sessionStorage = (0,_lib_azure_ai_foundry_voice_voice_session_storage__WEBPACK_IMPORTED_MODULE_3__/* .getVoiceSessionStorage */ .i)();
            sessionStorage.removeSession(sessionId);
            console.log(`✅ [API] Voice session stopped: ${sessionId}`);
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: true,
                sessionId,
                message: graceful ? 'Session stopped gracefully' : 'Session force stopped',
                stoppedAt: new Date().toISOString()
            }, {
                status: 200
            });
        } catch (stopError) {
            console.error(`❌ [API] Error stopping session ${sessionId}:`, stopError);
            // Even if stopping failed, remove from both client's active sessions and edge storage
            voiceClient.removeSession(sessionId);
            const sessionStorage = (0,_lib_azure_ai_foundry_voice_voice_session_storage__WEBPACK_IMPORTED_MODULE_3__/* .getVoiceSessionStorage */ .i)();
            sessionStorage.removeSession(sessionId);
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                sessionId,
                message: 'Session stopped with errors',
                error: stopError instanceof Error ? stopError.message : 'Unknown error during stop',
                stoppedAt: new Date().toISOString()
            }, {
                status: 500
            });
        }
    } catch (error) {
        console.error('❌ [API] Failed to stop voice session:', error);
        const resolvedParams = await params;
        const sessionId = resolvedParams.id || 'unknown';
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: false,
            sessionId,
            message: 'Failed to stop session',
            error: error instanceof Error ? error.message : 'Internal server error',
            stoppedAt: new Date().toISOString()
        }, {
            status: 500
        });
    }
}
/**
 * GET handler for session status check
 */ async function GET(request, { params }) {
    const resolvedParams = await params;
    const sessionId = resolvedParams.id;
    // Validate session ID
    const sessionValidation = validateSessionId(sessionId);
    if (!sessionValidation.isValid) {
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            error: sessionValidation.error
        }, {
            status: 400
        });
    }
    // Get voice client and check session status
    const voiceClient = (0,_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__/* .getVoiceLiveClient */ .K)();
    const sessionMeta = voiceClient.getSession(sessionId);
    if (!sessionMeta) {
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            sessionId,
            exists: false,
            message: 'Session not found'
        }, {
            status: 404
        });
    }
    return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
        sessionId,
        exists: true,
        createdAt: sessionMeta.createdAt.toISOString(),
        options: sessionMeta.options,
        message: 'Session is active'
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 75717:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ getVoiceSessionStorage)
/* harmony export */ });
/**
 * Edge-Compatible Voice Session Storage
 * 
 * Provides session storage for WebSocket proxy routes that need to run in Edge runtime.
 * This avoids Azure Key Vault dependencies by storing only minimal session data.
 */ /**
 * Minimal session data needed for WebSocket proxy
 */ /**
 * In-memory session storage for Edge runtime compatibility
 * In production, this could be backed by Redis or similar edge-compatible storage
 */ class VoiceSessionStorage {
    /**
   * Store a session for WebSocket proxy access
   */ storeSession(session) {
        this.sessions.set(session.sessionId, session);
        // Auto-cleanup old sessions after 1 hour
        setTimeout(()=>{
            this.sessions.delete(session.sessionId);
        }, 60 * 60 * 1000);
    }
    /**
   * Get session by ID for WebSocket proxy
   */ getSession(sessionId) {
        return this.sessions.get(sessionId);
    }
    /**
   * Remove session from storage
   */ removeSession(sessionId) {
        this.sessions.delete(sessionId);
    }
    /**
   * Get all active sessions (for debugging)
   */ getActiveSessions() {
        return Array.from(this.sessions.values());
    }
    /**
   * Clear all sessions
   */ clear() {
        this.sessions.clear();
    }
    constructor(){
        this.sessions = new Map();
    }
}
// Singleton instance for edge runtime
let voiceSessionStorageInstance = null;
/**
 * Get shared voice session storage instance
 */ function getVoiceSessionStorage() {
    if (!voiceSessionStorageInstance) {
        voiceSessionStorageInstance = new VoiceSessionStorage();
    }
    return voiceSessionStorageInstance;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,1621], () => (__webpack_exec__(39649)));
module.exports = __webpack_exports__;

})();