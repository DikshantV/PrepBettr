"use strict";
(() => {
var exports = {};
exports.id = 1416;
exports.ids = [1416];
exports.modules = {

/***/ 1697:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patchFetch: () => (/* binding */ patchFetch),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),
/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96559);
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37719);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Users_dikshantvashistha_PrepBettr_app_api_voice_session_start_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48669);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_dikshantvashistha_PrepBettr_app_api_voice_session_start_route_ts__WEBPACK_IMPORTED_MODULE_3__]);
_Users_dikshantvashistha_PrepBettr_app_api_voice_session_start_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,
        page: "/api/voice/session/start/route",
        pathname: "/api/voice/session/start",
        filename: "route",
        bundlePath: "app/api/voice/session/start/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/voice/session/start/route.ts",
    nextConfigOutput,
    userland: _Users_dikshantvashistha_PrepBettr_app_api_voice_session_start_route_ts__WEBPACK_IMPORTED_MODULE_3__
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 10756:
/***/ ((module) => {

module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 36695:
/***/ ((module) => {

module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 48669:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GET: () => (/* binding */ GET),
/* harmony export */   POST: () => (/* binding */ POST)
/* harmony export */ });
/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32190);
/* harmony import */ var _lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49359);
/* harmony import */ var _lib_azure_ai_foundry_voice_voice_session_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75717);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__]);
_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * POST /api/voice/session/start
 * 
 * Creates a new Azure AI Foundry voice session for real-time streaming.
 * Returns session ID and WebSocket URL for client connection.
 */ 


/**
 * Validate request body
 */ function validateStartSessionRequest(body) {
    const errors = [];
    if (body.voiceName && typeof body.voiceName !== 'string') {
        errors.push('voiceName must be a string');
    }
    if (body.locale && typeof body.locale !== 'string') {
        errors.push('locale must be a string');
    }
    if (body.speakingRate && (typeof body.speakingRate !== 'number' || body.speakingRate <= 0 || body.speakingRate > 3)) {
        errors.push('speakingRate must be a number between 0 and 3');
    }
    if (body.emotionalTone && typeof body.emotionalTone !== 'string') {
        errors.push('emotionalTone must be a string');
    }
    if (body.audioSettings) {
        if (typeof body.audioSettings !== 'object') {
            errors.push('audioSettings must be an object');
        } else {
            const { noiseSuppression, echoCancellation, interruptionDetection, sampleRate } = body.audioSettings;
            if (noiseSuppression !== undefined && typeof noiseSuppression !== 'boolean') {
                errors.push('audioSettings.noiseSuppression must be a boolean');
            }
            if (echoCancellation !== undefined && typeof echoCancellation !== 'boolean') {
                errors.push('audioSettings.echoCancellation must be a boolean');
            }
            if (interruptionDetection !== undefined && typeof interruptionDetection !== 'boolean') {
                errors.push('audioSettings.interruptionDetection must be a boolean');
            }
            if (sampleRate !== undefined && (typeof sampleRate !== 'number' || ![
                8000,
                16000,
                24000,
                48000
            ].includes(sampleRate))) {
                errors.push('audioSettings.sampleRate must be one of: 8000, 16000, 24000, 48000');
            }
        }
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * POST handler for starting voice sessions
 */ async function POST(request) {
    try {
        console.log('🚀 [API] Starting voice session...');
        // Parse request body
        let body;
        try {
            body = await request.json();
        } catch (error) {
            console.error('❌ [API] Invalid JSON in request body:', error);
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: 'Invalid JSON in request body',
                sessionId: '',
                wsUrl: '',
                options: {},
                createdAt: new Date().toISOString()
            }, {
                status: 400
            });
        }
        // Validate request body
        const validation = validateStartSessionRequest(body);
        if (!validation.isValid) {
            console.error('❌ [API] Request validation failed:', validation.errors);
            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                success: false,
                error: `Validation failed: ${validation.errors.join(', ')}`,
                sessionId: '',
                wsUrl: '',
                options: {},
                createdAt: new Date().toISOString()
            }, {
                status: 400
            });
        }
        // Create voice session options
        const sessionOptions = {
            voiceName: body.voiceName,
            locale: body.locale,
            speakingRate: body.speakingRate,
            emotionalTone: body.emotionalTone,
            audioSettings: body.audioSettings
        };
        // Get voice client and create session
        const voiceClient = (0,_lib_azure_ai_foundry_voice_voice_live_client__WEBPACK_IMPORTED_MODULE_1__/* .getVoiceLiveClient */ .K)();
        const session = await voiceClient.createSession(sessionOptions);
        console.log(`✅ [API] Voice session created: ${session.sessionId}`);
        // Store session in edge-compatible storage for WebSocket proxy access
        const sessionStorage = (0,_lib_azure_ai_foundry_voice_voice_session_storage__WEBPACK_IMPORTED_MODULE_2__/* .getVoiceSessionStorage */ .i)();
        sessionStorage.storeSession({
            sessionId: session.sessionId,
            wsUrl: session.wsUrl,
            createdAt: session.createdAt
        });
        // Return session details with proxy WebSocket URL
        const baseUrl = request.nextUrl.origin;
        const proxyWsUrl = `${baseUrl.replace(/^http/, 'ws')}/api/voice/session/${session.sessionId}/ws`;
        const response = {
            success: true,
            sessionId: session.sessionId,
            wsUrl: proxyWsUrl,
            options: session.options,
            createdAt: session.createdAt.toISOString()
        };
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(response, {
            status: 201
        });
    } catch (error) {
        console.error('❌ [API] Failed to create voice session:', error);
        // Determine error message and status code
        let errorMessage = 'Internal server error';
        let statusCode = 500;
        if (error instanceof Error) {
            errorMessage = error.message;
            // Handle specific error types
            if (error.message.includes('configuration')) {
                statusCode = 503; // Service Unavailable
                errorMessage = 'Voice service configuration error';
            } else if (error.message.includes('Session creation failed')) {
                statusCode = 502; // Bad Gateway  
                errorMessage = 'Failed to create session with Azure AI Foundry';
            }
        }
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            success: false,
            error: errorMessage,
            sessionId: '',
            wsUrl: '',
            options: {},
            createdAt: new Date().toISOString()
        }, {
            status: statusCode
        });
    }
}
/**
 * GET handler for health check
 */ async function GET() {
    return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
        endpoint: '/api/voice/session/start',
        method: 'POST',
        description: 'Create a new Azure AI Foundry voice session',
        status: 'available'
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 75717:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ getVoiceSessionStorage)
/* harmony export */ });
/**
 * Edge-Compatible Voice Session Storage
 * 
 * Provides session storage for WebSocket proxy routes that need to run in Edge runtime.
 * This avoids Azure Key Vault dependencies by storing only minimal session data.
 */ /**
 * Minimal session data needed for WebSocket proxy
 */ /**
 * In-memory session storage for Edge runtime compatibility
 * In production, this could be backed by Redis or similar edge-compatible storage
 */ class VoiceSessionStorage {
    /**
   * Store a session for WebSocket proxy access
   */ storeSession(session) {
        this.sessions.set(session.sessionId, session);
        // Auto-cleanup old sessions after 1 hour
        setTimeout(()=>{
            this.sessions.delete(session.sessionId);
        }, 60 * 60 * 1000);
    }
    /**
   * Get session by ID for WebSocket proxy
   */ getSession(sessionId) {
        return this.sessions.get(sessionId);
    }
    /**
   * Remove session from storage
   */ removeSession(sessionId) {
        this.sessions.delete(sessionId);
    }
    /**
   * Get all active sessions (for debugging)
   */ getActiveSessions() {
        return Array.from(this.sessions.values());
    }
    /**
   * Clear all sessions
   */ clear() {
        this.sessions.clear();
    }
    constructor(){
        this.sessions = new Map();
    }
}
// Singleton instance for edge runtime
let voiceSessionStorageInstance = null;
/**
 * Get shared voice session storage instance
 */ function getVoiceSessionStorage() {
    if (!voiceSessionStorageInstance) {
        voiceSessionStorageInstance = new VoiceSessionStorage();
    }
    return voiceSessionStorageInstance;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,1621], () => (__webpack_exec__(1697)));
module.exports = __webpack_exports__;

})();