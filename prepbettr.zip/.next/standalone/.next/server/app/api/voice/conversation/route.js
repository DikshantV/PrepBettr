"use strict";
(() => {
var exports = {};
exports.id = 2654;
exports.ids = [2654];
exports.modules = {

/***/ 1708:
/***/ ((module) => {

module.exports = require("node:process");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 4573:
/***/ ((module) => {

module.exports = require("node:buffer");

/***/ }),

/***/ 8615:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patchFetch: () => (/* binding */ patchFetch),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),
/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96559);
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37719);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Users_dikshantvashistha_PrepBettr_app_api_voice_conversation_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19403);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_dikshantvashistha_PrepBettr_app_api_voice_conversation_route_ts__WEBPACK_IMPORTED_MODULE_3__]);
_Users_dikshantvashistha_PrepBettr_app_api_voice_conversation_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,
        page: "/api/voice/conversation/route",
        pathname: "/api/voice/conversation",
        filename: "route",
        bundlePath: "app/api/voice/conversation/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/voice/conversation/route.ts",
    nextConfigOutput,
    userland: _Users_dikshantvashistha_PrepBettr_app_api_voice_conversation_route_ts__WEBPACK_IMPORTED_MODULE_3__
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 10756:
/***/ ((module) => {

module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 11997:
/***/ ((module) => {

module.exports = require("punycode");

/***/ }),

/***/ 12412:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 14737:
/***/ ((module) => {

module.exports = import("@azure/storage-blob");;

/***/ }),

/***/ 19403:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GET: () => (/* binding */ GET),
/* harmony export */   POST: () => (/* binding */ POST)
/* harmony export */ });
/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32190);
/* harmony import */ var _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28697);
/* harmony import */ var _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__]);
_azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/**
 * Azure OpenAI Conversation API Endpoint
 * Handles interview conversation flow using Azure OpenAI
 */ async function POST(request) {
    try {
        const body = await request.json();
        const { action } = body;
        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.api.request('POST /api/voice/conversation', `Action: ${action}`);
        console.log('🎯 [CONVERSATION API] Processing request', {
            action,
            timestamp: new Date().toISOString()
        });
        // Initialize Azure OpenAI service if needed
        if (!_azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.isReady()) {
            console.log('🔧 [CONVERSATION API] Initializing Azure OpenAI service...');
            const initialized = await _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.initialize();
            if (!initialized) {
                console.error('❌ [CONVERSATION API] Failed to initialize Azure OpenAI service');
                _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.error('Failed to initialize Azure OpenAI service');
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    error: 'AI service unavailable'
                }, {
                    status: 503
                });
            }
            console.log('✅ [CONVERSATION API] Azure OpenAI service initialized successfully');
        }
        switch(action){
            case 'start':
                {
                    const { interviewContext } = body;
                    if (!interviewContext) {
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                            error: 'Interview context required for start action'
                        }, {
                            status: 400
                        });
                    }
                    // Set interview context in the service
                    _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.setInterviewContext({
                        type: mapInterviewType(interviewContext.type),
                        position: extractJobRole(interviewContext),
                        company: extractCompanyName(interviewContext),
                        difficulty: 'medium',
                        preliminaryCollected: false,
                        currentQuestionCount: 0,
                        maxQuestions: 10
                    });
                    // Start the interview conversation
                    const response = await _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.startInterviewConversation();
                    _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.api.response('POST /api/voice/conversation', 200, {
                        action: 'start',
                        questionNumber: response.questionNumber,
                        isComplete: response.isComplete
                    });
                    return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                        message: response.content,
                        questionNumber: response.questionNumber,
                        isComplete: response.isComplete,
                        hasAudio: false,
                        followUpSuggestions: response.followUpSuggestions
                    });
                }
            case 'process':
                {
                    const { userTranscript } = body;
                    if (!userTranscript || !userTranscript.trim()) {
                        console.warn('📝 [CONVERSATION API] Empty transcript received');
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                            error: 'User transcript required for process action'
                        }, {
                            status: 400
                        });
                    }
                    console.log('🧪 [CONVERSATION API] Processing user transcript', {
                        length: userTranscript.trim().length,
                        preview: userTranscript.trim().substring(0, 50) + '...'
                    });
                    try {
                        // Process user response and get AI reply
                        const response = await _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.processUserResponse(userTranscript.trim());
                        console.log('✅ [CONVERSATION API] Successfully processed response', {
                            contentLength: response.content?.length,
                            questionNumber: response.questionNumber,
                            isComplete: response.isComplete
                        });
                        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.api.response('POST /api/voice/conversation', 200, {
                            action: 'process',
                            questionNumber: response.questionNumber,
                            isComplete: response.isComplete,
                            transcriptLength: userTranscript.length
                        });
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                            message: response.content,
                            questionNumber: response.questionNumber,
                            isComplete: response.isComplete,
                            hasAudio: false,
                            followUpSuggestions: response.followUpSuggestions
                        });
                    } catch (processError) {
                        console.error('❌ [CONVERSATION API] Process user response failed:', processError);
                        throw processError; // Re-throw to be caught by outer error handler
                    }
                }
            case 'summary':
                {
                    try {
                        // Generate interview summary
                        const summary = await _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.generateInterviewSummary();
                        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.api.response('POST /api/voice/conversation', 200, {
                            action: 'summary',
                            hasSummary: !!summary
                        });
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                            summary,
                            conversationHistory: _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.getConversationHistory()
                        });
                    } catch (error) {
                        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.warn('Failed to generate summary, returning empty response', {
                            error: error instanceof Error ? error.message : String(error)
                        });
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                            summary: null,
                            error: 'Summary generation failed'
                        });
                    }
                }
            default:
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    error: `Invalid action: ${action}`
                }, {
                    status: 400
                });
        }
    } catch (error) {
        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.error('Conversation processing failed', error instanceof Error ? error : new Error(String(error)));
        // Provide helpful error responses
        if (error instanceof Error) {
            if (error.message.includes('quota') || error.message.includes('rate limit')) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    error: 'AI service quota exceeded. Please try again later.'
                }, {
                    status: 429
                });
            }
            if (error.message.includes('authentication') || error.message.includes('unauthorized')) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    error: 'AI service authentication failed'
                }, {
                    status: 401
                });
            }
            if (error.message.includes('timeout')) {
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                    error: 'AI service timeout. Please try again.'
                }, {
                    status: 408
                });
            }
        }
        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
            error: 'Internal AI processing error'
        }, {
            status: 500
        });
    }
}
/**
 * Health check endpoint for conversation service
 */ async function GET() {
    const isReady = _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.isReady();
    return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
        service: 'Azure OpenAI Conversation',
        status: isReady ? 'ready' : 'not_initialized',
        timestamp: new Date().toISOString()
    }, {
        status: isReady ? 200 : 503
    });
}
// Helper functions
function mapInterviewType(type) {
    const normalizedType = type.toLowerCase();
    if (normalizedType.includes('technical')) return 'technical';
    if (normalizedType.includes('behavioral')) return 'behavioral';
    return 'general';
}
function extractJobRole(context) {
    // Try to extract job role from various sources
    if (context.resumeInfo?.candidateName) return context.resumeInfo.candidateName;
    if (context.questions && context.questions.length > 0) {
        // Look for role mentions in questions
        const roleMatch = context.questions[0].match(/(\w+\s+\w+)\s+(developer|engineer|manager|analyst|designer)/i);
        if (roleMatch) return roleMatch[0];
    }
    return undefined;
}
function extractCompanyName(context) {
    // Extract company name from context if available
    // This could be enhanced to parse from resume info or questions
    return undefined;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 21820:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 27910:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 28697:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   w: () => (/* binding */ azureOpenAIServiceServer)
/* harmony export */ });
/* unused harmony export AzureOpenAIServiceServer */
/* harmony import */ var _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(55506);
/* harmony import */ var _azure_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65868);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__]);
_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


class AzureOpenAIServiceServer {
    /**
   * Initialize the Azure OpenAI service using server-side credential loading
   */ async initialize() {
        try {
            console.log('🔑 Initializing Azure OpenAI service on server...');
            const secrets = await (0,_azure_config__WEBPACK_IMPORTED_MODULE_1__/* .fetchAzureSecrets */ .lL)();
            if (!secrets.azureOpenAIKey || !secrets.azureOpenAIEndpoint || !secrets.azureOpenAIDeployment) {
                console.warn('⚠️ Azure OpenAI credentials not available');
                return false;
            }
            this.client = new _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__/* .MigrationOpenAIClient */ .Ag();
            await this.client.init(); // Initialize the migration client
            // Store the deployment name for use as model in API calls
            this.modelDeployment = secrets.azureOpenAIDeployment;
            this.isInitialized = true;
            console.log('✅ Azure OpenAI Service (server-side) initialized successfully');
            return true;
        } catch (error) {
            console.error('❌ Failed to initialize Azure OpenAI Service (server-side):', error);
            return false;
        }
    }
    /**
   * Check if the service is ready to use
   */ isReady() {
        return this.isInitialized && this.client !== null;
    }
    /**
   * Set interview context for conversation management
   */ setInterviewContext(context) {
        // Merge context while preserving defaults
        this.interviewContext = {
            ...this.interviewContext,
            ...context,
            // Ensure defaults are set if not provided
            preliminaryCollected: context.preliminaryCollected ?? this.interviewContext.preliminaryCollected ?? false,
            currentQuestionCount: context.currentQuestionCount ?? this.interviewContext.currentQuestionCount ?? 0,
            maxQuestions: context.maxQuestions ?? this.interviewContext.maxQuestions ?? 10
        };
        console.log('📋 Interview context updated:', this.interviewContext);
    }
    /**
   * Build system context from candidate profile
   */ buildSystemContext() {
        const { currentRole, techStack, yearsExperience, keySkills } = this.candidateProfile;
        const { type, position, company, difficulty, currentQuestionCount, maxQuestions } = this.interviewContext;
        let systemPrompt = `You are an AI interviewer conducting a ${type} interview with a candidate.\n\n`;
        systemPrompt += `Candidate Profile:\n`;
        systemPrompt += `- Current Role: ${currentRole}\n`;
        systemPrompt += `- Tech Stack: ${techStack}\n`;
        systemPrompt += `- Years of Experience: ${yearsExperience}\n`;
        systemPrompt += `- Key Skills: ${keySkills}\n\n`;
        systemPrompt += `Interview Guidelines:\n`;
        systemPrompt += `1. Ask relevant, engaging questions tailored to their experience level\n`;
        systemPrompt += `2. Follow up on answers with clarifying questions\n`;
        systemPrompt += `3. Maintain a professional but friendly tone\n`;
        systemPrompt += `4. Keep responses concise and focused\n`;
        systemPrompt += `5. Adapt difficulty based on their experience and responses\n\n`;
        systemPrompt += `Interview Flow Control:\n`;
        systemPrompt += `• Preliminary questions have already been collected - do NOT ask them again\n`;
        systemPrompt += `• You are currently on interview question ${(currentQuestionCount || 0) + 1} of ${maxQuestions}\n`;
        systemPrompt += `• Continue with interview questions based on the candidate's profile\n`;
        systemPrompt += `• After question ${maxQuestions}, conclude the interview and thank the candidate\n`;
        systemPrompt += `• Do NOT exceed ${maxQuestions} interview questions\n\n`;
        if (position) {
            systemPrompt += `Position: ${position}\n`;
        }
        if (company) {
            systemPrompt += `Company: ${company}\n`;
        }
        if (difficulty) {
            systemPrompt += `Difficulty Level: ${difficulty}\n`;
        }
        switch(type){
            case 'technical':
                systemPrompt += `\nFocus on technical skills relevant to their tech stack (${techStack}), problem-solving, coding concepts, and system design appropriate for someone with ${yearsExperience} years of experience.`;
                break;
            case 'behavioral':
                systemPrompt += `\nFocus on behavioral questions about teamwork, leadership, conflict resolution, and past experiences relevant to someone in a ${currentRole} role.`;
                break;
            default:
                systemPrompt += `\nAsk a mix of questions about background, experience, goals, and general fit for the role, considering their ${yearsExperience} years of experience in ${currentRole}.`;
        }
        systemPrompt += `\n\nKeep your responses under 100 words and ask one question at a time.`;
        return systemPrompt;
    }
    /**
   * Start a new interview conversation
   */ async startInterviewConversation() {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        // Reset conversation history and preliminary questions state
        this.conversationHistory = [];
        this.prelimIndex = 0;
        this.candidateProfile = {};
        // Reset interview context flags
        this.interviewContext.preliminaryCollected = false;
        this.interviewContext.currentQuestionCount = 0;
        // Send greeting + first preliminary question
        const greeting = "Hello! Welcome to your interview practice session. Before we begin, I'd like to learn a bit about you.";
        const firstQuestion = this.prelimQuestions[0];
        const openingMessage = `${greeting}\n\n${firstQuestion}`;
        return {
            content: openingMessage,
            questionNumber: 0,
            isComplete: false
        };
    }
    /**
   * Get opening message based on interview type
   * Uses generateInterviewQuestion helper for domain-specific questions
   */ async getOpeningMessage() {
        const { position } = this.interviewContext;
        let greeting = "";
        if (position) {
            greeting += `Let's discuss the ${position} position. `;
        }
        try {
            // Use the helper to generate a domain-specific opening question
            const question = await this.generateInterviewQuestion();
            return greeting + question;
        } catch (error) {
            console.warn('⚠️ Falling back to default opening question');
            // Fallback to a simpler approach if generation fails
            return greeting + this.getFallbackQuestion();
        }
    }
    /**
   * Process user response and generate next question or comment
   */ async processUserResponse(userResponse) {
        console.log('🧪 [AZURE OPENAI] Processing user response', {
            responseLength: userResponse.length,
            preliminaryCollected: this.interviewContext.preliminaryCollected,
            currentQuestionCount: this.interviewContext.currentQuestionCount
        });
        if (!this.isInitialized || !this.client) {
            console.error('❌ [AZURE OPENAI] Service not initialized');
            throw new Error('Azure OpenAI Service not initialized');
        }
        // Check if we're still collecting preliminary information
        if (!this.interviewContext.preliminaryCollected) {
            // We're in preliminary phase - check if we still have questions to ask
            if (this.prelimIndex < this.prelimQuestions.length) {
                // Store the user's answer to the current preliminary question
                const questionKeys = [
                    'currentRole',
                    'techStack',
                    'yearsExperience',
                    'keySkills',
                    'questionCount'
                ];
                this.candidateProfile[questionKeys[this.prelimIndex]] = userResponse;
                // Increment to next preliminary question
                this.prelimIndex++;
                // If there are more preliminary questions, return the next one
                if (this.prelimIndex < this.prelimQuestions.length) {
                    const nextQuestion = this.prelimQuestions[this.prelimIndex];
                    return {
                        content: `Thank you! ${nextQuestion}`,
                        questionNumber: 0,
                        isComplete: false
                    };
                } else {
                    // All preliminary questions collected - mark as complete
                    this.interviewContext.preliminaryCollected = true;
                    // Keep currentQuestionCount at 0 as we haven't asked real questions yet
                    this.interviewContext.currentQuestionCount = 0;
                    // Build system context from collected profile
                    const systemContext = this.buildSystemContext();
                    // Initialize conversation history with system context
                    this.conversationHistory = [
                        {
                            role: 'system',
                            content: systemContext
                        }
                    ];
                    // Set max questions from user's response
                    const requestedQuestions = parseInt(this.candidateProfile.questionCount) || 10;
                    this.interviewContext.maxQuestions = Math.min(Math.max(requestedQuestions, 5), 20); // Between 5 and 20
                    // Generate the first real interview question
                    const openingMessage = await this.getOpeningMessage();
                    this.conversationHistory.push({
                        role: 'assistant',
                        content: openingMessage
                    });
                    // Increment question count for the first real question
                    this.interviewContext.currentQuestionCount = 1;
                    return {
                        content: `Great! I now have a better understanding of your background. Let's begin the interview.\n\n${openingMessage}`,
                        questionNumber: 1,
                        isComplete: false
                    };
                }
            }
        }
        // Normal interview flow - preliminary info has been collected
        // Add user response to conversation history
        this.conversationHistory.push({
            role: 'user',
            content: userResponse
        });
        try {
            console.log('🧪 [AZURE OPENAI] Calling OpenAI API with', {
                model: this.modelDeployment,
                messagesCount: this.conversationHistory.length,
                currentQuestionCount: this.interviewContext.currentQuestionCount
            });
            const completion = await this.client.chat.completions.create({
                model: this.modelDeployment,
                messages: this.conversationHistory,
                temperature: 0.7,
                max_tokens: 200,
                top_p: 0.9,
                frequency_penalty: 0.1,
                presence_penalty: 0.1
            });
            const assistantResponse = completion.choices[0]?.message?.content || 'I\'m sorry, I didn\'t catch that. Could you repeat your answer?';
            console.log('✅ [AZURE OPENAI] Got response from OpenAI', {
                responseLength: assistantResponse.length,
                tokensUsed: completion.usage?.total_tokens || 'unknown'
            });
            // Add assistant response to conversation history
            this.conversationHistory.push({
                role: 'assistant',
                content: assistantResponse
            });
            // Increment question count for the next question
            const currentQuestionCount = (this.interviewContext.currentQuestionCount || 0) + 1;
            const maxQuestions = this.interviewContext.maxQuestions || 10;
            // Update question count in context
            this.interviewContext.currentQuestionCount = currentQuestionCount;
            return {
                content: assistantResponse,
                questionNumber: currentQuestionCount,
                isComplete: currentQuestionCount >= maxQuestions,
                followUpSuggestions: this.generateFollowUpSuggestions()
            };
        } catch (error) {
            console.error('❌ [AZURE OPENAI] Error generating OpenAI response:', error);
            // Provide more detailed error information
            if (error && typeof error === 'object' && 'status' in error) {
                const apiError = error;
                console.error('❌ [AZURE OPENAI] API Error Details:', {
                    status: apiError.status,
                    code: apiError.code,
                    type: apiError.type,
                    message: apiError.message
                });
                if (apiError.status === 429) {
                    throw new Error('Rate limit exceeded - please try again in a moment');
                } else if (apiError.status === 401) {
                    throw new Error('Authentication failed - please check Azure OpenAI credentials');
                } else if (apiError.status === 404) {
                    throw new Error(`Model deployment '${this.modelDeployment}' not found`);
                }
            }
            throw new Error(`Failed to generate response: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    /**
   * Generate follow-up suggestions based on conversation
   */ generateFollowUpSuggestions() {
        const { type } = this.interviewContext;
        switch(type){
            case 'technical':
                return [
                    "Can you explain your thought process?",
                    "What would you do differently?",
                    "How would this scale?"
                ];
            case 'behavioral':
                return [
                    "What was the outcome?",
                    "What did you learn?",
                    "How would you handle it now?"
                ];
            default:
                return [
                    "Can you elaborate on that?",
                    "What was your biggest challenge?",
                    "What motivates you?"
                ];
        }
    }
    /**
   * Generate a domain-specific interview question based on context and conversation history
   */ async generateInterviewQuestion() {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        // Build the appropriate system prompt based on interview type and profile
        const { type, difficulty, position } = this.interviewContext;
        const { currentRole, techStack, yearsExperience, keySkills } = this.candidateProfile;
        let questionPrompt = `Generate one concise interview question. `;
        // Add context-specific instructions based on interview type
        switch(type){
            case 'technical':
                questionPrompt += `Focus on technical skills and problem-solving.\n`;
                questionPrompt += `Consider the candidate's tech stack: ${techStack || 'various technologies'}.\n`;
                questionPrompt += `Experience level: ${yearsExperience || 'mid-level'} years.\n`;
                questionPrompt += `Include specific technical scenarios such as:\n`;
                questionPrompt += `- Code/architecture design challenges\n`;
                questionPrompt += `- Debugging or optimization problems\n`;
                questionPrompt += `- Technology-specific best practices\n`;
                questionPrompt += `- System scalability considerations\n`;
                break;
            case 'behavioral':
                questionPrompt += `Focus on behavioral assessment using STAR method.\n`;
                questionPrompt += `Consider the candidate's role: ${currentRole || 'general position'}.\n`;
                questionPrompt += `Ask about situations involving:\n`;
                questionPrompt += `- Leadership and teamwork\n`;
                questionPrompt += `- Conflict resolution\n`;
                questionPrompt += `- Problem-solving under pressure\n`;
                questionPrompt += `- Learning from failures\n`;
                break;
            default:
                questionPrompt += `Ask a general interview question.\n`;
                questionPrompt += `Consider the candidate's background: ${currentRole || 'various roles'} with ${yearsExperience || 'some'} years experience.\n`;
                questionPrompt += `Focus on motivation, goals, and cultural fit.\n`;
        }
        if (difficulty) {
            questionPrompt += `Difficulty level: ${difficulty}.\n`;
        }
        if (position) {
            questionPrompt += `Position being interviewed for: ${position}.\n`;
        }
        questionPrompt += `\nReturn only the question text, no additional formatting or explanations.`;
        try {
            const completion = await this.client.chat.completions.create({
                model: this.modelDeployment,
                messages: [
                    {
                        role: 'user',
                        content: questionPrompt
                    }
                ],
                temperature: 0.8,
                max_tokens: 100,
                top_p: 0.9
            });
            const question = completion.choices[0]?.message?.content?.trim() || this.getFallbackQuestion();
            return question;
        } catch (error) {
            console.warn('⚠️ Failed to generate interview question, using fallback');
            return this.getFallbackQuestion();
        }
    }
    /**
   * Get fallback question when generation fails
   */ getFallbackQuestion() {
        const { type } = this.interviewContext;
        switch(type){
            case 'technical':
                return "Tell me about a challenging technical problem you've solved recently.";
            case 'behavioral':
                return "Can you describe a time when you had to work with a difficult team member?";
            default:
                return "What interests you most about this role?";
        }
    }
    /**
   * Generate interview summary
   */ async generateInterviewSummary() {
        if (!this.isInitialized || !this.client || this.conversationHistory.length === 0) {
            return null;
        }
        const summaryPrompt = `Based on the following interview conversation, provide a brief summary of the candidate's performance, strengths, and areas for improvement. Keep it concise and professional.\n\nConversation:\n${this.conversationHistory.map((msg)=>`${msg.role}: ${msg.content}`).join('\n')}`;
        try {
            const completion = await this.client.chat.completions.create({
                model: this.modelDeployment,
                messages: [
                    {
                        role: 'user',
                        content: summaryPrompt
                    }
                ],
                temperature: 0.5,
                max_tokens: 300
            });
            return completion.choices[0]?.message?.content?.trim() || null;
        } catch (error) {
            console.error('❌ Error generating interview summary:', error);
            return null;
        }
    }
    /**
   * Get conversation history
   */ getConversationHistory() {
        return this.conversationHistory;
    }
    /**
   * Reset the service state
   */ reset() {
        this.conversationHistory = [];
        this.prelimIndex = 0;
        this.candidateProfile = {};
        this.interviewContext = {
            type: 'general',
            preliminaryCollected: false,
            currentQuestionCount: 0,
            maxQuestions: 10
        };
        console.log('🔄 Azure OpenAI Service state reset');
    }
    constructor(){
        this.client = null;
        this.isInitialized = false;
        this.modelDeployment = 'gpt-4o' // Store the deployment name as model
        ;
        this.conversationHistory = [];
        this.interviewContext = {
            type: 'general',
            preliminaryCollected: false,
            currentQuestionCount: 0,
            maxQuestions: 10
        };
        // Preliminary questions for gathering candidate profile
        this.prelimQuestions = [
            'What is your current role?',
            'What primary tech stack do you use?',
            'How many years of experience do you have?',
            'What are your key skills?',
            'How many interview questions would you like?'
        ];
        this.prelimIndex = 0;
        this.candidateProfile = {};
    }
}
// Create and export a singleton instance for use across the application
const azureOpenAIServiceServer = new AzureOpenAIServiceServer();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 29021:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

module.exports = require("tls");

/***/ }),

/***/ 35672:
/***/ ((module) => {

module.exports = require("@azure/msal-node");

/***/ }),

/***/ 36695:
/***/ ((module) => {

module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37067:
/***/ ((module) => {

module.exports = require("node:http");

/***/ }),

/***/ 38522:
/***/ ((module) => {

module.exports = require("node:zlib");

/***/ }),

/***/ 44708:
/***/ ((module) => {

module.exports = require("node:https");

/***/ }),

/***/ 44870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 48161:
/***/ ((module) => {

module.exports = require("node:os");

/***/ }),

/***/ 51455:
/***/ ((module) => {

module.exports = require("node:fs/promises");

/***/ }),

/***/ 53802:
/***/ ((module) => {

module.exports = require("node:child_process");

/***/ }),

/***/ 55591:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 57075:
/***/ ((module) => {

module.exports = require("node:stream");

/***/ }),

/***/ 57975:
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ 62201:
/***/ ((module) => {

module.exports = require("@azure/keyvault-secrets");

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 73024:
/***/ ((module) => {

module.exports = require("node:fs");

/***/ }),

/***/ 73136:
/***/ ((module) => {

module.exports = require("node:url");

/***/ }),

/***/ 74075:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 76760:
/***/ ((module) => {

module.exports = require("node:path");

/***/ }),

/***/ 77598:
/***/ ((module) => {

module.exports = require("node:crypto");

/***/ }),

/***/ 79551:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 79646:
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),

/***/ 81630:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 83997:
/***/ ((module) => {

module.exports = require("tty");

/***/ }),

/***/ 91645:
/***/ ((module) => {

module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 97502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   vF: () => (/* binding */ logger)
/* harmony export */ });
/* unused harmony exports debug, info, success, warn, error */
/**
 * Centralized logging utility with debug flag support
 * Helps reduce verbose console.debug statements throughout the codebase
 */ // Environment-based debug flag
const DEBUG =  false || process.env.DEBUG === 'true';
/**
 * Core logger with emoji prefixes for visual recognition
 */ const logger = {
    debug: (message, context)=>{
        if (DEBUG) {
            context ? console.debug(`🔍 ${message}`, context) : console.debug(`🔍 ${message}`);
        }
    },
    info: (message, context)=>{
        context ? console.info(`ℹ️ ${message}`, context) : console.info(`ℹ️ ${message}`);
    },
    success: (message, context)=>{
        context ? console.log(`✅ ${message}`, context) : console.log(`✅ ${message}`);
    },
    warn: (message, context)=>{
        context ? console.warn(`⚠️ ${message}`, context) : console.warn(`⚠️ ${message}`);
    },
    error: (message, error, context)=>{
        const errorInfo = error instanceof Error ? {
            message: error.message,
            stack: error.stack
        } : error;
        context ? console.error(`❌ ${message}`, {
            error: errorInfo,
            ...context
        }) : console.error(`❌ ${message}`, errorInfo);
    },
    // Audio-specific logging shortcuts
    audio: {
        process: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎵 ${message}`, context) : console.debug(`🎵 ${message}`);
            }
        },
        record: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎤 ${message}`, context) : console.debug(`🎤 ${message}`);
            }
        },
        speak: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🔊 ${message}`, context) : console.debug(`🔊 ${message}`);
            }
        }
    },
    // State management logging
    state: (action, from, to, context)=>{
        if (DEBUG) {
            const message = `State transition: ${from} → ${to}`;
            context ? console.debug(`🔄 [${action}] ${message}`, context) : console.debug(`🔄 [${action}] ${message}`);
        }
    },
    // API request logging
    api: {
        request: (endpoint, method, context)=>{
            if (DEBUG) {
                context ? console.debug(`📤 API ${method} ${endpoint}`, context) : console.debug(`📤 API ${method} ${endpoint}`);
            }
        },
        response: (endpoint, status, context)=>{
            const icon = status >= 200 && status < 300 ? '📥' : '❌';
            if (DEBUG) {
                context ? console.debug(`${icon} API Response ${status} ${endpoint}`, context) : console.debug(`${icon} API Response ${status} ${endpoint}`);
            }
        }
    }
};
// Convenience exports
const { debug, info, success, warn, error } = logger;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8384,8833,6716,5506,4633], () => (__webpack_exec__(8615)));
module.exports = __webpack_exports__;

})();