(() => {
var exports = {};
exports.id = 2654;
exports.ids = [2654];
exports.modules = {

/***/ 1708:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 4573:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 8615:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   patchFetch: () => (/* binding */ patchFetch),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   serverHooks: () => (/* binding */ serverHooks),
/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),
/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96559);
/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37719);
/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Users_dikshantvashistha_PrepBettr_app_api_voice_conversation_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19403);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_dikshantvashistha_PrepBettr_app_api_voice_conversation_route_ts__WEBPACK_IMPORTED_MODULE_3__]);
_Users_dikshantvashistha_PrepBettr_app_api_voice_conversation_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,
        page: "/api/voice/conversation/route",
        pathname: "/api/voice/conversation",
        filename: "route",
        bundlePath: "app/api/voice/conversation/route"
    },
    resolvedPagePath: "/Users/dikshantvashistha/PrepBettr/app/api/voice/conversation/route.ts",
    nextConfigOutput,
    userland: _Users_dikshantvashistha_PrepBettr_app_api_voice_conversation_route_ts__WEBPACK_IMPORTED_MODULE_3__
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}


//# sourceMappingURL=app-route.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 11997:
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ 12412:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14737:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/storage-blob");;

/***/ }),

/***/ 19403:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GET: () => (/* binding */ GET),
/* harmony export */   POST: () => (/* binding */ POST)
/* harmony export */ });
/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32190);
/* harmony import */ var _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28697);
/* harmony import */ var _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97502);
/* harmony import */ var _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53313);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__]);
_azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




/**
 * Azure OpenAI Conversation API Endpoint
 * Handles interview conversation flow using Azure OpenAI
 */ async function POST(request) {
    try {
        const body = await request.json();
        const { action } = body;
        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.api.request('POST /api/voice/conversation', `Action: ${action}`);
        console.log('🎯 [CONVERSATION API] Processing request', {
            action,
            timestamp: new Date().toISOString()
        });
        // Initialize Azure OpenAI service if needed
        if (!_azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.isReady()) {
            console.log('🔧 [CONVERSATION API] Initializing Azure OpenAI service...');
            const initialized = await _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.initialize();
            if (!initialized) {
                console.error('❌ [CONVERSATION API] Failed to initialize Azure OpenAI service');
                _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.error('Failed to initialize Azure OpenAI service');
                const err = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .createErrorResponse */ .WX)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .ErrorCode */ .O4.SERVICE_UNAVAILABLE, {
                    service: 'azure-openai'
                }, 'AI service unavailable');
                const status = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .getHTTPStatusFromErrorCode */ .Mn)(err.error.code);
                const res = next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(err, {
                    status
                });
                if (err.error.retryable && err.error.retryAfter) {
                    res.headers.set('Retry-After', String(err.error.retryAfter));
                    res.headers.set('X-Retry-After', String(err.error.retryAfter));
                }
                return res;
            }
            console.log('✅ [CONVERSATION API] Azure OpenAI service initialized successfully');
        }
        switch(action){
            case 'start':
                {
                    const { interviewContext } = body;
                    if (!interviewContext) {
                        const err = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .createErrorResponse */ .WX)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .ErrorCode */ .O4.MISSING_REQUIRED_FIELD, {
                            field: 'interviewContext'
                        }, 'Interview context required for start action');
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(err, {
                            status: (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .getHTTPStatusFromErrorCode */ .Mn)(err.error.code)
                        });
                    }
                    // Set interview context in the service
                    _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.setInterviewContext({
                        type: mapInterviewType(interviewContext.type),
                        position: extractJobRole(interviewContext),
                        company: extractCompanyName(interviewContext),
                        difficulty: 'medium',
                        preliminaryCollected: false,
                        currentQuestionCount: 0,
                        maxQuestions: 10
                    });
                    // Start the interview conversation
                    const response = await _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.startInterviewConversation();
                    _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.api.response('POST /api/voice/conversation', 200, {
                        action: 'start',
                        questionNumber: response.questionNumber,
                        isComplete: response.isComplete
                    });
                    return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                        message: response.content,
                        questionNumber: response.questionNumber,
                        isComplete: response.isComplete,
                        hasAudio: false,
                        followUpSuggestions: response.followUpSuggestions
                    });
                }
            case 'process':
                {
                    const { userTranscript } = body;
                    if (!userTranscript || !userTranscript.trim()) {
                        console.warn('📝 [CONVERSATION API] Empty transcript received');
                        const err = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .createErrorResponse */ .WX)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .ErrorCode */ .O4.MISSING_REQUIRED_FIELD, {
                            field: 'userTranscript'
                        }, 'User transcript required for process action');
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(err, {
                            status: (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .getHTTPStatusFromErrorCode */ .Mn)(err.error.code)
                        });
                    }
                    console.log('🧪 [CONVERSATION API] Processing user transcript', {
                        length: userTranscript.trim().length,
                        preview: userTranscript.trim().substring(0, 50) + '...'
                    });
                    try {
                        // Process user response and get AI reply
                        const response = await _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.processUserResponse(userTranscript.trim());
                        console.log('✅ [CONVERSATION API] Successfully processed response', {
                            contentLength: response.content?.length,
                            questionNumber: response.questionNumber,
                            isComplete: response.isComplete
                        });
                        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.api.response('POST /api/voice/conversation', 200, {
                            action: 'process',
                            questionNumber: response.questionNumber,
                            isComplete: response.isComplete,
                            transcriptLength: userTranscript.length
                        });
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                            message: response.content,
                            questionNumber: response.questionNumber,
                            isComplete: response.isComplete,
                            hasAudio: false,
                            followUpSuggestions: response.followUpSuggestions
                        });
                    } catch (processError) {
                        console.error('❌ [CONVERSATION API] Process user response failed:', processError);
                        throw processError; // Re-throw to be caught by outer error handler
                    }
                }
            case 'summary':
                {
                    try {
                        // Generate interview summary
                        const summary = await _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.generateInterviewSummary();
                        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.api.response('POST /api/voice/conversation', 200, {
                            action: 'summary',
                            hasSummary: !!summary
                        });
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                            summary,
                            conversationHistory: _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.getConversationHistory()
                        });
                    } catch (error) {
                        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.warn('Failed to generate summary, returning empty response', {
                            error: error instanceof Error ? error.message : String(error)
                        });
                        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
                            summary: null,
                            error: 'Summary generation failed'
                        });
                    }
                }
            default:
                const err = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .createErrorResponse */ .WX)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .ErrorCode */ .O4.INVALID_PARAMETER, {
                    action
                }, `Invalid action: ${action}`);
                return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(err, {
                    status: (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .getHTTPStatusFromErrorCode */ .Mn)(err.error.code)
                });
        }
    } catch (error) {
        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_2__/* .logger */ .vF.error('Conversation processing failed', error instanceof Error ? error : new Error(String(error)));
        // Provide helpful structured error responses
        let code = _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .ErrorCode */ .O4.INTERNAL_SERVER_ERROR;
        const message = error instanceof Error ? error.message.toLowerCase() : '';
        if (message.includes('quota') || message.includes('rate limit')) {
            code = _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .ErrorCode */ .O4.RATE_LIMIT_EXCEEDED;
        } else if (message.includes('authentication') || message.includes('unauthorized')) {
            code = _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .ErrorCode */ .O4.AUTH_TOKEN_INVALID;
        } else if (message.includes('timeout')) {
            code = _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .ErrorCode */ .O4.SERVICE_TIMEOUT;
        } else if (message.includes('azure') || message.includes('openai')) {
            code = _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .ErrorCode */ .O4.AZURE_OPENAI_ERROR;
        }
        const err = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .createErrorResponse */ .WX)(code, {
            context: 'voice.conversation'
        });
        const status = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_3__/* .getHTTPStatusFromErrorCode */ .Mn)(code);
        const res = next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(err, {
            status
        });
        if (err.error.retryable && err.error.retryAfter) {
            res.headers.set('Retry-After', String(err.error.retryAfter));
            res.headers.set('X-Retry-After', String(err.error.retryAfter));
        }
        return res;
    }
}
/**
 * Health check endpoint for conversation service
 */ async function GET() {
    const isReady = _azure_lib_services_azure_openai_service_server__WEBPACK_IMPORTED_MODULE_1__/* .azureOpenAIServiceServer */ .w.isReady();
    return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({
        service: 'Azure OpenAI Conversation',
        status: isReady ? 'ready' : 'not_initialized',
        timestamp: new Date().toISOString()
    }, {
        status: isReady ? 200 : 503
    });
}
// Helper functions
function mapInterviewType(type) {
    const normalizedType = type.toLowerCase();
    if (normalizedType.includes('technical')) return 'technical';
    if (normalizedType.includes('behavioral')) return 'behavioral';
    return 'general';
}
function extractJobRole(context) {
    // Try to extract job role from various sources
    if (context.resumeInfo?.candidateName) return context.resumeInfo.candidateName;
    if (context.questions && context.questions.length > 0) {
        // Look for role mentions in questions
        const roleMatch = context.questions[0].match(/(\w+\s+\w+)\s+(developer|engineer|manager|analyst|designer)/i);
        if (roleMatch) return roleMatch[0];
    }
    return undefined;
}
function extractCompanyName(context) {
    // Extract company name from context if available
    // This could be enhanced to parse from resume info or questions
    return undefined;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 21820:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 27910:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 28697:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   w: () => (/* binding */ azureOpenAIServiceServer)
/* harmony export */ });
/* unused harmony export AzureOpenAIServiceServer */
/* harmony import */ var _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(55506);
/* harmony import */ var _azure_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65868);
/* harmony import */ var _lib_utils_template_engine__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(43731);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(33873);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(53313);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75931);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__]);
_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






class AzureOpenAIServiceServer {
    /**
   * Initialize the Azure OpenAI service using server-side credential loading
   */ async initialize() {
        try {
            console.log('🔑 Initializing Azure OpenAI service on server...');
            const secrets = await (0,_azure_config__WEBPACK_IMPORTED_MODULE_1__/* .fetchAzureSecrets */ .lL)();
            if (!secrets.azureOpenAIKey || !secrets.azureOpenAIEndpoint || !secrets.azureOpenAIDeployment) {
                console.warn('⚠️ Azure OpenAI credentials not available');
                const error = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .createStructuredError */ .Kg)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.SERVICE_NOT_CONFIGURED, {
                    service: 'azure-openai',
                    missingCredentials: [
                        'key',
                        'endpoint',
                        'deployment'
                    ]
                }, 'Azure OpenAI credentials not available');
                (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(new Error(error.message), {
                    errorCode: error.code,
                    category: error.category,
                    details: error.details
                });
                return false;
            }
            this.client = new _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__/* .MigrationOpenAIClient */ .Ag();
            await this.client.init(); // Initialize the migration client
            // Store the deployment name for use as model in API calls
            this.modelDeployment = secrets.azureOpenAIDeployment;
            this.isInitialized = true;
            console.log('✅ Azure OpenAI Service (server-side) initialized successfully');
            return true;
        } catch (error) {
            console.error('❌ Failed to initialize Azure OpenAI Service (server-side):', error);
            const structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .toStructuredError */ .Bx)(error, _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.CONFIGURATION_ERROR);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(error instanceof Error ? error : new Error(String(error)), {
                errorCode: structuredError.code,
                category: structuredError.category,
                details: structuredError.details
            });
            return false;
        }
    }
    /**
   * Check if the service is ready to use
   */ isReady() {
        return this.isInitialized && this.client !== null;
    }
    /**
   * Set interview context for conversation management
   */ setInterviewContext(context) {
        // Merge context while preserving defaults
        this.interviewContext = {
            ...this.interviewContext,
            ...context,
            // Ensure defaults are set if not provided
            preliminaryCollected: context.preliminaryCollected ?? this.interviewContext.preliminaryCollected ?? false,
            currentQuestionCount: context.currentQuestionCount ?? this.interviewContext.currentQuestionCount ?? 0,
            maxQuestions: context.maxQuestions ?? this.interviewContext.maxQuestions ?? 10
        };
        console.log('📋 Interview context updated:', this.interviewContext);
    }
    /**
   * Build system context from candidate profile using template engine
   */ buildSystemContext() {
        try {
            // Load the interview prompts template
            const templatePath = path__WEBPACK_IMPORTED_MODULE_3___default().resolve(process.cwd(), 'config/templates/interview-prompts.yaml');
            const template = _lib_utils_template_engine__WEBPACK_IMPORTED_MODULE_2__/* .templateEngine */ .zz.loadTemplate(templatePath);
            // Build context for template rendering
            const context = {
                candidate: {
                    name: this.candidateProfile.currentRole || 'candidate'
                },
                role: this.candidateProfile.currentRole,
                company: this.interviewContext.company,
                interview_type: this.interviewContext.type,
                experience_level: this.candidateProfile.yearsExperience,
                tech_stack: this.candidateProfile.techStack ? this.candidateProfile.techStack.split(',').map((s)=>s.trim()) : [],
                custom_instructions: this.buildCustomInstructions(),
                sample_questions: this.getSampleQuestions(),
                duration: '45-60 minutes',
                tone: 'professional and encouraging'
            };
            return _lib_utils_template_engine__WEBPACK_IMPORTED_MODULE_2__/* .templateEngine */ .zz.renderFromConfig(template, context);
        } catch (error) {
            console.warn('⚠️ Template engine failed, falling back to legacy prompt building:', error);
            return this.buildSystemContextLegacy();
        }
    }
    /**
   * Build custom instructions based on interview context
   */ buildCustomInstructions() {
        const { currentQuestionCount, maxQuestions } = this.interviewContext;
        return [
            'Preliminary questions have already been collected - do NOT ask them again',
            `You are currently on interview question ${(currentQuestionCount || 0) + 1} of ${maxQuestions}`,
            'Continue with interview questions based on the candidate\'s profile',
            `After question ${maxQuestions}, conclude the interview and thank the candidate`,
            `Do NOT exceed ${maxQuestions} interview questions`,
            'Keep your responses under 100 words and ask one question at a time'
        ].join('\n');
    }
    /**
   * Get sample questions based on interview type
   */ getSampleQuestions() {
        const { type } = this.interviewContext;
        const { techStack, yearsExperience, currentRole } = this.candidateProfile;
        switch(type){
            case 'technical':
                return [
                    `Tell me about a challenging technical problem you've solved using ${techStack}`,
                    'How do you approach debugging complex issues?',
                    'Describe your experience with system design and scalability',
                    'What are your thoughts on code review and best practices?'
                ];
            case 'behavioral':
                return [
                    'Tell me about a time when you had to work with a difficult team member',
                    'Describe a situation where you had to learn a new technology quickly',
                    'How do you handle conflicting priorities and tight deadlines?',
                    'Give me an example of when you mentored or helped a colleague'
                ];
            default:
                return [
                    'What interests you most about this position?',
                    `How has your experience in ${currentRole} prepared you for this role?`,
                    'What are your career goals for the next few years?',
                    'What motivates you in your work?'
                ];
        }
    }
    /**
   * Legacy system context builder (fallback)
   */ buildSystemContextLegacy() {
        const { currentRole, techStack, yearsExperience, keySkills } = this.candidateProfile;
        const { type, position, company, difficulty, currentQuestionCount, maxQuestions } = this.interviewContext;
        let systemPrompt = `You are an AI interviewer conducting a ${type} interview with a candidate.\n\n`;
        systemPrompt += `Candidate Profile:\n`;
        systemPrompt += `- Current Role: ${currentRole}\n`;
        systemPrompt += `- Tech Stack: ${techStack}\n`;
        systemPrompt += `- Years of Experience: ${yearsExperience}\n`;
        systemPrompt += `- Key Skills: ${keySkills}\n\n`;
        systemPrompt += `Interview Guidelines:\n`;
        systemPrompt += `1. Ask relevant, engaging questions tailored to their experience level\n`;
        systemPrompt += `2. Follow up on answers with clarifying questions\n`;
        systemPrompt += `3. Maintain a professional but friendly tone\n`;
        systemPrompt += `4. Keep responses concise and focused\n`;
        systemPrompt += `5. Adapt difficulty based on their experience and responses\n\n`;
        systemPrompt += `Interview Flow Control:\n`;
        systemPrompt += `• Preliminary questions have already been collected - do NOT ask them again\n`;
        systemPrompt += `• You are currently on interview question ${(currentQuestionCount || 0) + 1} of ${maxQuestions}\n`;
        systemPrompt += `• Continue with interview questions based on the candidate's profile\n`;
        systemPrompt += `• After question ${maxQuestions}, conclude the interview and thank the candidate\n`;
        systemPrompt += `• Do NOT exceed ${maxQuestions} interview questions\n\n`;
        if (position) {
            systemPrompt += `Position: ${position}\n`;
        }
        if (company) {
            systemPrompt += `Company: ${company}\n`;
        }
        if (difficulty) {
            systemPrompt += `Difficulty Level: ${difficulty}\n`;
        }
        switch(type){
            case 'technical':
                systemPrompt += `\nFocus on technical skills relevant to their tech stack (${techStack}), problem-solving, coding concepts, and system design appropriate for someone with ${yearsExperience} years of experience.`;
                break;
            case 'behavioral':
                systemPrompt += `\nFocus on behavioral questions about teamwork, leadership, conflict resolution, and past experiences relevant to someone in a ${currentRole} role.`;
                break;
            default:
                systemPrompt += `\nAsk a mix of questions about background, experience, goals, and general fit for the role, considering their ${yearsExperience} years of experience in ${currentRole}.`;
        }
        systemPrompt += `\n\nKeep your responses under 100 words and ask one question at a time.`;
        return systemPrompt;
    }
    /**
   * Start a new interview conversation
   */ async startInterviewConversation() {
        if (!this.isInitialized || !this.client) {
            const error = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .createStructuredError */ .Kg)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.SERVICE_UNAVAILABLE, {
                service: 'azure-openai'
            }, 'Azure OpenAI Service not initialized');
            throw error;
        }
        // Reset conversation history and preliminary questions state
        this.conversationHistory = [];
        this.prelimIndex = 0;
        this.candidateProfile = {};
        // Reset interview context flags
        this.interviewContext.preliminaryCollected = false;
        this.interviewContext.currentQuestionCount = 0;
        // Send greeting + first preliminary question
        const greeting = "Hello! Welcome to your interview practice session. Before we begin, I'd like to learn a bit about you.";
        const firstQuestion = this.prelimQuestions[0];
        const openingMessage = `${greeting}\n\n${firstQuestion}`;
        return {
            content: openingMessage,
            questionNumber: 0,
            isComplete: false
        };
    }
    /**
   * Get opening message based on interview type
   * Uses generateInterviewQuestion helper for domain-specific questions
   */ async getOpeningMessage() {
        const { position } = this.interviewContext;
        let greeting = "";
        if (position) {
            greeting += `Let's discuss the ${position} position. `;
        }
        try {
            // Use the helper to generate a domain-specific opening question
            const question = await this.generateInterviewQuestion();
            return greeting + question;
        } catch (error) {
            console.warn('⚠️ Falling back to default opening question');
            // Fallback to a simpler approach if generation fails
            return greeting + this.getFallbackQuestion();
        }
    }
    /**
   * Process user response and generate next question or comment
   */ async processUserResponse(userResponse) {
        console.log('🧪 [AZURE OPENAI] Processing user response', {
            responseLength: userResponse.length,
            preliminaryCollected: this.interviewContext.preliminaryCollected,
            currentQuestionCount: this.interviewContext.currentQuestionCount
        });
        if (!this.isInitialized || !this.client) {
            console.error('❌ [AZURE OPENAI] Service not initialized');
            const error = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .createStructuredError */ .Kg)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.SERVICE_UNAVAILABLE, {
                service: 'azure-openai',
                context: 'process-user-response'
            }, 'Azure OpenAI Service not initialized');
            throw error;
        }
        // Check if we're still collecting preliminary information
        if (!this.interviewContext.preliminaryCollected) {
            // We're in preliminary phase - check if we still have questions to ask
            if (this.prelimIndex < this.prelimQuestions.length) {
                // Store the user's answer to the current preliminary question
                const questionKeys = [
                    'currentRole',
                    'techStack',
                    'yearsExperience',
                    'keySkills',
                    'questionCount'
                ];
                this.candidateProfile[questionKeys[this.prelimIndex]] = userResponse;
                // Increment to next preliminary question
                this.prelimIndex++;
                // If there are more preliminary questions, return the next one
                if (this.prelimIndex < this.prelimQuestions.length) {
                    const nextQuestion = this.prelimQuestions[this.prelimIndex];
                    return {
                        content: `Thank you! ${nextQuestion}`,
                        questionNumber: 0,
                        isComplete: false
                    };
                } else {
                    // All preliminary questions collected - mark as complete
                    this.interviewContext.preliminaryCollected = true;
                    // Keep currentQuestionCount at 0 as we haven't asked real questions yet
                    this.interviewContext.currentQuestionCount = 0;
                    // Build system context from collected profile
                    const systemContext = this.buildSystemContext();
                    // Initialize conversation history with system context
                    this.conversationHistory = [
                        {
                            role: 'system',
                            content: systemContext
                        }
                    ];
                    // Set max questions from user's response
                    const requestedQuestions = parseInt(this.candidateProfile.questionCount) || 10;
                    this.interviewContext.maxQuestions = Math.min(Math.max(requestedQuestions, 5), 20); // Between 5 and 20
                    // Generate the first real interview question
                    const openingMessage = await this.getOpeningMessage();
                    this.conversationHistory.push({
                        role: 'assistant',
                        content: openingMessage
                    });
                    // Increment question count for the first real question
                    this.interviewContext.currentQuestionCount = 1;
                    return {
                        content: `Great! I now have a better understanding of your background. Let's begin the interview.\n\n${openingMessage}`,
                        questionNumber: 1,
                        isComplete: false
                    };
                }
            }
        }
        // Normal interview flow - preliminary info has been collected
        // Add user response to conversation history
        this.conversationHistory.push({
            role: 'user',
            content: userResponse
        });
        try {
            console.log('🧪 [AZURE OPENAI] Calling OpenAI API with', {
                model: this.modelDeployment,
                messagesCount: this.conversationHistory.length,
                currentQuestionCount: this.interviewContext.currentQuestionCount
            });
            if (!this.client) {
                throw new Error('OpenAI client not initialized');
            }
            const completion = await this.client.chat.completions.create({
                model: this.modelDeployment,
                messages: this.conversationHistory,
                temperature: 0.7,
                max_tokens: 200,
                top_p: 0.9,
                frequency_penalty: 0.1,
                presence_penalty: 0.1
            });
            const assistantResponse = completion.choices[0]?.message?.content || 'I\'m sorry, I didn\'t catch that. Could you repeat your answer?';
            console.log('✅ [AZURE OPENAI] Got response from OpenAI', {
                responseLength: assistantResponse.length,
                tokensUsed: completion.usage?.total_tokens || 'unknown'
            });
            // Add assistant response to conversation history
            this.conversationHistory.push({
                role: 'assistant',
                content: assistantResponse
            });
            // Increment question count for the next question
            const currentQuestionCount = (this.interviewContext.currentQuestionCount || 0) + 1;
            const maxQuestions = this.interviewContext.maxQuestions || 10;
            // Update question count in context
            this.interviewContext.currentQuestionCount = currentQuestionCount;
            return {
                content: assistantResponse,
                questionNumber: currentQuestionCount,
                isComplete: currentQuestionCount >= maxQuestions,
                followUpSuggestions: this.generateFollowUpSuggestions()
            };
        } catch (error) {
            console.error('❌ [AZURE OPENAI] Error generating OpenAI response:', error);
            // Map to structured error codes
            let structuredError;
            if (error && typeof error === 'object' && 'status' in error) {
                const apiError = error;
                console.error('❌ [AZURE OPENAI] API Error Details:', {
                    status: apiError.status,
                    code: apiError.code,
                    type: apiError.type,
                    message: apiError.message
                });
                if (apiError.status === 429) {
                    structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .createStructuredError */ .Kg)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.RATE_LIMIT_EXCEEDED, {
                        service: 'azure-openai',
                        apiStatus: apiError.status,
                        apiCode: apiError.code
                    }, 'Rate limit exceeded - please try again in a moment');
                } else if (apiError.status === 401 || apiError.status === 403) {
                    structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .createStructuredError */ .Kg)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.AUTH_TOKEN_INVALID, {
                        service: 'azure-openai',
                        apiStatus: apiError.status
                    }, 'Authentication failed - please check Azure OpenAI credentials');
                } else if (apiError.status === 404) {
                    structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .createStructuredError */ .Kg)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.CONFIGURATION_ERROR, {
                        service: 'azure-openai',
                        deployment: this.modelDeployment,
                        apiStatus: apiError.status
                    }, `Model deployment '${this.modelDeployment}' not found`);
                } else if (apiError.status >= 500) {
                    structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .createStructuredError */ .Kg)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.AZURE_OPENAI_ERROR, {
                        service: 'azure-openai',
                        apiStatus: apiError.status,
                        apiType: apiError.type
                    }, 'Azure OpenAI service error');
                } else {
                    structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .toStructuredError */ .Bx)(error, _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.AZURE_OPENAI_ERROR);
                }
            } else {
                structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .toStructuredError */ .Bx)(error, _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.AZURE_OPENAI_ERROR);
            }
            // Log the error for monitoring
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(error instanceof Error ? error : new Error(String(error)), {
                errorCode: structuredError.code,
                category: structuredError.category,
                details: structuredError.details,
                context: 'azure-openai-process-response'
            });
            throw structuredError;
        }
    }
    /**
   * Generate follow-up suggestions based on conversation
   */ generateFollowUpSuggestions() {
        const { type } = this.interviewContext;
        switch(type){
            case 'technical':
                return [
                    "Can you explain your thought process?",
                    "What would you do differently?",
                    "How would this scale?"
                ];
            case 'behavioral':
                return [
                    "What was the outcome?",
                    "What did you learn?",
                    "How would you handle it now?"
                ];
            default:
                return [
                    "Can you elaborate on that?",
                    "What was your biggest challenge?",
                    "What motivates you?"
                ];
        }
    }
    /**
   * Generate a domain-specific interview question using template engine
   */ async generateInterviewQuestion() {
        if (!this.isInitialized || !this.client) {
            const error = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .createStructuredError */ .Kg)(_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.SERVICE_UNAVAILABLE, {
                service: 'azure-openai',
                context: 'generate-interview-question'
            }, 'Azure OpenAI Service not initialized');
            throw error;
        }
        try {
            // Load the question generation template
            const templatePath = path__WEBPACK_IMPORTED_MODULE_3___default().resolve(process.cwd(), 'config/templates/question-templates.yaml');
            const template = _lib_utils_template_engine__WEBPACK_IMPORTED_MODULE_2__/* .templateEngine */ .zz.loadTemplate(templatePath);
            // Build context for template rendering
            const context = {
                role: this.candidateProfile.currentRole || 'Software Developer',
                category: this.interviewContext.type || 'general',
                difficulty: this.getDifficultyLevel(),
                count: 1,
                tech_stack: this.candidateProfile.techStack ? this.candidateProfile.techStack.split(',').map((s)=>s.trim()) : [],
                experience_level: this.candidateProfile.yearsExperience || 'mid-level',
                custom_requirements: this.interviewContext.position ? `Focus on requirements for ${this.interviewContext.position} position` : undefined
            };
            const questionPrompt = _lib_utils_template_engine__WEBPACK_IMPORTED_MODULE_2__/* .templateEngine */ .zz.renderFromConfig(template, context);
            if (!this.client) {
                throw new Error('OpenAI client not initialized');
            }
            const completion = await this.client.chat.completions.create({
                model: this.modelDeployment,
                messages: [
                    {
                        role: 'user',
                        content: questionPrompt
                    }
                ],
                temperature: 0.8,
                max_tokens: 100,
                top_p: 0.9
            });
            const question = completion.choices[0]?.message?.content?.trim() || this.getFallbackQuestion();
            return question;
        } catch (error) {
            console.warn('⚠️ Template-based question generation failed, using legacy method:', error);
            // Log but don't throw - fallback to legacy method
            const structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .toStructuredError */ .Bx)(error, _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.AZURE_OPENAI_ERROR);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(error instanceof Error ? error : new Error(String(error)), {
                errorCode: structuredError.code,
                category: structuredError.category,
                details: {
                    ...structuredError.details,
                    context: 'template-question-generation'
                },
                context: 'azure-openai-question-template-fallback'
            });
            return this.generateInterviewQuestionLegacy();
        }
    }
    /**
   * Get difficulty level mapping
   */ getDifficultyLevel() {
        const experience = parseInt(this.candidateProfile.yearsExperience || '3');
        if (experience <= 2) return 'junior';
        if (experience <= 5) return 'mid';
        if (experience <= 10) return 'senior';
        return 'principal';
    }
    /**
   * Legacy question generation method (fallback)
   */ async generateInterviewQuestionLegacy() {
        const { type, difficulty, position } = this.interviewContext;
        const { currentRole, techStack, yearsExperience, keySkills } = this.candidateProfile;
        let questionPrompt = `Generate one concise interview question. `;
        // Add context-specific instructions based on interview type
        switch(type){
            case 'technical':
                questionPrompt += `Focus on technical skills and problem-solving.\n`;
                questionPrompt += `Consider the candidate's tech stack: ${techStack || 'various technologies'}.\n`;
                questionPrompt += `Experience level: ${yearsExperience || 'mid-level'} years.\n`;
                questionPrompt += `Include specific technical scenarios such as:\n`;
                questionPrompt += `- Code/architecture design challenges\n`;
                questionPrompt += `- Debugging or optimization problems\n`;
                questionPrompt += `- Technology-specific best practices\n`;
                questionPrompt += `- System scalability considerations\n`;
                break;
            case 'behavioral':
                questionPrompt += `Focus on behavioral assessment using STAR method.\n`;
                questionPrompt += `Consider the candidate's role: ${currentRole || 'general position'}.\n`;
                questionPrompt += `Ask about situations involving:\n`;
                questionPrompt += `- Leadership and teamwork\n`;
                questionPrompt += `- Conflict resolution\n`;
                questionPrompt += `- Problem-solving under pressure\n`;
                questionPrompt += `- Learning from failures\n`;
                break;
            default:
                questionPrompt += `Ask a general interview question.\n`;
                questionPrompt += `Consider the candidate's background: ${currentRole || 'various roles'} with ${yearsExperience || 'some'} years experience.\n`;
                questionPrompt += `Focus on motivation, goals, and cultural fit.\n`;
        }
        if (difficulty) {
            questionPrompt += `Difficulty level: ${difficulty}.\n`;
        }
        if (position) {
            questionPrompt += `Position being interviewed for: ${position}.\n`;
        }
        questionPrompt += `\nReturn only the question text, no additional formatting or explanations.`;
        try {
            if (!this.client) {
                throw new Error('OpenAI client not initialized');
            }
            const completion = await this.client.chat.completions.create({
                model: this.modelDeployment,
                messages: [
                    {
                        role: 'user',
                        content: questionPrompt
                    }
                ],
                temperature: 0.8,
                max_tokens: 100,
                top_p: 0.9
            });
            const question = completion.choices[0]?.message?.content?.trim() || this.getFallbackQuestion();
            return question;
        } catch (error) {
            console.warn('⚠️ Failed to generate interview question, using fallback');
            // Log the error for monitoring but return fallback instead of throwing
            const structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .toStructuredError */ .Bx)(error, _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.AZURE_OPENAI_ERROR);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(error instanceof Error ? error : new Error(String(error)), {
                errorCode: structuredError.code,
                category: structuredError.category,
                details: {
                    ...structuredError.details,
                    context: 'legacy-question-generation'
                },
                context: 'azure-openai-question-legacy-fallback'
            });
            return this.getFallbackQuestion();
        }
    }
    /**
   * Get fallback question when generation fails
   */ getFallbackQuestion() {
        const { type } = this.interviewContext;
        switch(type){
            case 'technical':
                return "Tell me about a challenging technical problem you've solved recently.";
            case 'behavioral':
                return "Can you describe a time when you had to work with a difficult team member?";
            default:
                return "What interests you most about this role?";
        }
    }
    /**
   * Generate interview summary
   */ async generateInterviewSummary() {
        if (!this.isInitialized || !this.client || this.conversationHistory.length === 0) {
            return null;
        }
        const summaryPrompt = `Based on the following interview conversation, provide a brief summary of the candidate's performance, strengths, and areas for improvement. Keep it concise and professional.\n\nConversation:\n${this.conversationHistory.map((msg)=>`${msg.role}: ${msg.content}`).join('\n')}`;
        try {
            if (!this.client) {
                throw new Error('OpenAI client not initialized');
            }
            const completion = await this.client.chat.completions.create({
                model: this.modelDeployment,
                messages: [
                    {
                        role: 'user',
                        content: summaryPrompt
                    }
                ],
                temperature: 0.5,
                max_tokens: 300
            });
            return completion.choices[0]?.message?.content?.trim() || null;
        } catch (error) {
            console.error('❌ Error generating interview summary:', error);
            // Log the error for monitoring but return null instead of throwing
            const structuredError = (0,_lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .toStructuredError */ .Bx)(error, _lib_utils_structured_errors__WEBPACK_IMPORTED_MODULE_4__/* .ErrorCode */ .O4.AZURE_OPENAI_ERROR);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(error instanceof Error ? error : new Error(String(error)), {
                errorCode: structuredError.code,
                category: structuredError.category,
                details: {
                    ...structuredError.details,
                    context: 'interview-summary-generation'
                },
                context: 'azure-openai-summary-generation'
            });
            return null;
        }
    }
    /**
   * Get conversation history
   */ getConversationHistory() {
        return this.conversationHistory;
    }
    /**
   * Reset the service state
   */ reset() {
        this.conversationHistory = [];
        this.prelimIndex = 0;
        this.candidateProfile = {};
        this.interviewContext = {
            type: 'general',
            preliminaryCollected: false,
            currentQuestionCount: 0,
            maxQuestions: 10
        };
        console.log('🔄 Azure OpenAI Service state reset');
    }
    constructor(){
        this.client = null;
        this.isInitialized = false;
        this.modelDeployment = 'gpt-4o' // Store the deployment name as model
        ;
        this.conversationHistory = [];
        this.interviewContext = {
            type: 'general',
            preliminaryCollected: false,
            currentQuestionCount: 0,
            maxQuestions: 10
        };
        // Preliminary questions for gathering candidate profile
        this.prelimQuestions = [
            'What is your current role?',
            'What primary tech stack do you use?',
            'How many years of experience do you have?',
            'What are your key skills?',
            'How many interview questions would you like?'
        ];
        this.prelimIndex = 0;
        this.candidateProfile = {};
    }
}
// Create and export a singleton instance for use across the application
const azureOpenAIServiceServer = new AzureOpenAIServiceServer();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 35672:
/***/ ((module) => {

"use strict";
module.exports = require("@azure/msal-node");

/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37067:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 38522:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 43731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   zz: () => (/* binding */ templateEngine)
/* harmony export */ });
/* unused harmony exports createTemplateEngine, renderTemplate, loadAndRenderTemplate */
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12360);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29021);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(33873);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/**
 * Dynamic Template Engine for PrepBettr
 * 
 * Provides advanced template processing with variable interpolation, 
 * conditional rendering, loops, and structured YAML template support.
 * 
 * Features:
 * - Variable interpolation: {{variable}}
 * - Conditional blocks: {{#if condition}}...{{/if}}
 * - Loop blocks: {{#each items}}...{{/each}}
 * - Nested object access: {{user.profile.name}}
 * - Helper functions: {{uppercase(text)}}
 * - YAML template loading and caching
 * 
 * @version 1.0.0
 */ 


// ===== TEMPLATE ENGINE IMPLEMENTATION =====
class PrepBettrTemplateEngine {
    constructor(){
        this.templateCache = new Map();
        this.helpers = new Map();
        this.registerDefaultHelpers();
    }
    /**
   * Register default helper functions
   */ registerDefaultHelpers() {
        // String helpers
        this.registerHelper('uppercase', (value)=>String(value).toUpperCase());
        this.registerHelper('lowercase', (value)=>String(value).toLowerCase());
        this.registerHelper('capitalize', (value)=>{
            const str = String(value);
            return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
        });
        this.registerHelper('trim', (value)=>String(value).trim());
        // Array helpers
        this.registerHelper('length', (value)=>String(Array.isArray(value) ? value.length : 0));
        this.registerHelper('join', (value, separator = ', ')=>Array.isArray(value) ? value.join(separator) : String(value));
        this.registerHelper('first', (value)=>String(Array.isArray(value) ? value[0] : value));
        this.registerHelper('last', (value)=>String(Array.isArray(value) ? value[value.length - 1] : value));
        // Logic helpers
        this.registerHelper('default', (value, defaultValue)=>String(value || defaultValue));
        this.registerHelper('eq', (a, b)=>String(a === b));
        this.registerHelper('neq', (a, b)=>String(a !== b));
        this.registerHelper('gt', (a, b)=>String(a > b));
        this.registerHelper('lt', (a, b)=>String(a < b));
        // Formatting helpers
        this.registerHelper('dateFormat', (value, format = 'YYYY-MM-DD')=>{
            const date = new Date(value);
            return date.toISOString().split('T')[0]; // Basic formatting
        });
        this.registerHelper('pluralize', (count, singular, plural)=>{
            return count === 1 ? singular : plural || `${singular}s`;
        });
        this.registerHelper('increment', (value)=>String(value + 1));
    }
    /**
   * Register a custom helper function
   */ registerHelper(name, fn) {
        this.helpers.set(name, fn);
    }
    /**
   * Render a template string with context
   */ render(template, context = {}) {
        if (!template) {
            return '';
        }
        try {
            let result = template;
            let previousResult = '';
            let iterations = 0;
            const maxIterations = 10; // Prevent infinite loops in nested processing
            // Keep processing until no more changes occur or max iterations reached
            while(result !== previousResult && iterations < maxIterations){
                previousResult = result;
                // Process conditional blocks first
                result = this.processConditionals(result, context);
                // Process loop blocks
                result = this.processLoops(result, context);
                // Process variable interpolations and helper functions
                result = this.processInterpolations(result, context);
                iterations++;
            }
            return result;
        } catch (error) {
            console.error('Template rendering error:', error);
            throw new Error(`Template rendering failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
   * Render template from config with merged context
   */ renderFromConfig(config, context = {}) {
        const mergedContext = {
            ...config.variables,
            ...context
        };
        return this.render(config.template, mergedContext);
    }
    /**
   * Load template from YAML file
   */ loadTemplate(filePath) {
        const cacheKey = path__WEBPACK_IMPORTED_MODULE_2__.resolve(filePath);
        if (this.templateCache.has(cacheKey)) {
            return this.templateCache.get(cacheKey);
        }
        try {
            const content = fs__WEBPACK_IMPORTED_MODULE_1__.readFileSync(filePath, 'utf8');
            const config = js_yaml__WEBPACK_IMPORTED_MODULE_0__/* .load */ .Hh(content);
            if (!config.template) {
                throw new Error('Template config must have a "template" field');
            }
            this.templateCache.set(cacheKey, config);
            return config;
        } catch (error) {
            throw new Error(`Failed to load template from ${filePath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
   * Load all templates from a directory
   */ loadTemplateSet(directoryPath) {
        const templates = {};
        try {
            const files = fs__WEBPACK_IMPORTED_MODULE_1__.readdirSync(directoryPath);
            for (const file of files){
                if (file.endsWith('.yaml') || file.endsWith('.yml')) {
                    const filePath = path__WEBPACK_IMPORTED_MODULE_2__.join(directoryPath, file);
                    const templateName = path__WEBPACK_IMPORTED_MODULE_2__.basename(file, path__WEBPACK_IMPORTED_MODULE_2__.extname(file));
                    templates[templateName] = this.loadTemplate(filePath);
                }
            }
            return templates;
        } catch (error) {
            throw new Error(`Failed to load templates from ${directoryPath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
   * Process conditional blocks: {{#if condition}}...{{/if}}
   */ processConditionals(template, context) {
        const conditionalRegex = /\{\{#if\s+([^}]+)\}\}([\s\S]*?)\{\{\/if\}\}/g;
        return template.replace(conditionalRegex, (match, condition, content)=>{
            try {
                const isTrue = this.evaluateCondition(condition.trim(), context);
                return isTrue ? content : '';
            } catch (error) {
                console.warn(`Conditional evaluation error: ${error}`);
                return '';
            }
        });
    }
    /**
   * Process loop blocks: {{#each items}}...{{/each}}
   */ processLoops(template, context) {
        const loopRegex = /\{\{#each\s+([^}]+)\}\}([\s\S]*?)\{\{\/each\}\}/g;
        return template.replace(loopRegex, (match, arrayPath, content)=>{
            try {
                const array = this.getNestedValue(context, arrayPath.trim());
                if (!Array.isArray(array)) {
                    return '';
                }
                return array.map((item, index)=>{
                    const loopContext = {
                        ...context,
                        '@item': item,
                        '@index': index,
                        '@first': index === 0,
                        '@last': index === array.length - 1,
                        ...typeof item === 'object' && item !== null ? item : {
                            '@value': item
                        }
                    };
                    // Only process interpolations here - nested processing will be handled in main render loop
                    return this.processInterpolations(content, loopContext);
                }).join('');
            } catch (error) {
                console.warn(`Loop processing error: ${error}`);
                return '';
            }
        });
    }
    /**
   * Process variable interpolations and helper functions
   */ processInterpolations(template, context) {
        const interpolationRegex = /\{\{([^}]+)\}\}/g;
        return template.replace(interpolationRegex, (match, expression)=>{
            try {
                return this.evaluateExpression(expression.trim(), context);
            } catch (error) {
                console.warn(`Interpolation error for "${expression}": ${error}`);
                return match; // Return original expression on error
            }
        });
    }
    /**
   * Evaluate a condition expression
   */ evaluateCondition(condition, context) {
        // Handle simple variable existence
        if (!condition.includes(' ')) {
            const value = this.getNestedValue(context, condition);
            return Boolean(value);
        }
        // Handle comparison operations
        const comparisonMatch = condition.match(/^([^<>=!]+)\s*([<>=!]+)\s*(.+)$/);
        if (comparisonMatch) {
            const [, left, operator, right] = comparisonMatch;
            const leftValue = this.getNestedValue(context, left.trim());
            const rightValue = this.parseValue(right.trim(), context);
            switch(operator.trim()){
                case '===':
                case '==':
                    return leftValue === rightValue;
                case '!==':
                case '!=':
                    return leftValue !== rightValue;
                case '>':
                    return Number(leftValue) > Number(rightValue);
                case '<':
                    return Number(leftValue) < Number(rightValue);
                case '>=':
                    return Number(leftValue) >= Number(rightValue);
                case '<=':
                    return Number(leftValue) <= Number(rightValue);
                default:
                    return Boolean(leftValue);
            }
        }
        // Fallback: evaluate as variable
        return Boolean(this.getNestedValue(context, condition));
    }
    /**
   * Evaluate an expression (variable or helper function)
   */ evaluateExpression(expression, context) {
        // Check if it's a helper function call
        const helperMatch = expression.match(/^([a-zA-Z_][a-zA-Z0-9_]*)\s*\(([^)]*)\)$/);
        if (helperMatch) {
            const [, helperName, argsString] = helperMatch;
            if (this.helpers.has(helperName)) {
                try {
                    const helper = this.helpers.get(helperName);
                    const args = this.parseArguments(argsString, context);
                    const firstArg = args.length > 0 ? args[0] : undefined;
                    const restArgs = args.slice(1);
                    return String(helper(firstArg, ...restArgs));
                } catch (error) {
                    console.warn(`Helper function '${helperName}' error:`, error);
                    return `{{${expression}}}`; // Return original expression on helper error
                }
            } else {
                // Unknown helper function - return original expression
                return `{{${expression}}}`;
            }
        }
        // Regular variable interpolation
        const value = this.getNestedValue(context, expression);
        return value != null ? String(value) : '';
    }
    /**
   * Parse helper function arguments
   */ parseArguments(argsString, context) {
        if (!argsString.trim()) {
            return [];
        }
        return argsString.split(',').map((arg)=>this.parseValue(arg.trim(), context));
    }
    /**
   * Parse a value (string literal, number, variable reference)
   */ parseValue(value, context) {
        // String literal
        if (value.startsWith('"') && value.endsWith('"') || value.startsWith("'") && value.endsWith("'")) {
            return value.slice(1, -1);
        }
        // Number literal
        if (/^-?\d*\.?\d+$/.test(value)) {
            return Number(value);
        }
        // Boolean literal
        if (value === 'true' || value === 'false') {
            return value === 'true';
        }
        // Variable reference
        return this.getNestedValue(context, value);
    }
    /**
   * Get nested value from context (e.g., "user.profile.name")
   */ getNestedValue(context, path) {
        if (!path) {
            return undefined;
        }
        const keys = path.split('.');
        let current = context;
        for (const key of keys){
            if (current == null || typeof current !== 'object') {
                return undefined;
            }
            current = current[key];
        }
        return current;
    }
    /**
   * Clear template cache
   */ clearCache() {
        this.templateCache.clear();
    }
    /**
   * Get cache statistics
   */ getCacheStats() {
        return {
            size: this.templateCache.size,
            keys: Array.from(this.templateCache.keys())
        };
    }
}
// ===== EXPORTS =====
// Singleton instance
const templateEngine = new PrepBettrTemplateEngine();
// Factory function for custom instances
const createTemplateEngine = ()=>{
    return new PrepBettrTemplateEngine();
};
// Utility functions
const renderTemplate = (template, context = {})=>{
    return templateEngine.render(template, context);
};
const loadAndRenderTemplate = (filePath, context = {})=>{
    const config = templateEngine.loadTemplate(filePath);
    return templateEngine.renderFromConfig(config, context);
};


/***/ }),

/***/ 44708:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 44870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 48161:
/***/ ((module) => {

"use strict";
module.exports = require("node:os");

/***/ }),

/***/ 51455:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs/promises");

/***/ }),

/***/ 53313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bx: () => (/* binding */ toStructuredError),
/* harmony export */   Kg: () => (/* binding */ createStructuredError),
/* harmony export */   Mn: () => (/* binding */ getHTTPStatusFromErrorCode),
/* harmony export */   O4: () => (/* binding */ ErrorCode),
/* harmony export */   WX: () => (/* binding */ createErrorResponse)
/* harmony export */ });
/* unused harmony exports ErrorCategory, RetryStrategy, createSuccessResponse, getErrorCodeFromHTTPStatus, isRetryableError, getRetryDelay, sendErrorResponse, sendSuccessResponse */
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75931);
/**
 * Structured Error System for PrepBettr
 * 
 * Provides consistent error handling with standardized error codes,
 * retry hints, and structured response formats across all API routes.
 * 
 * Features:
 * - Standardized error codes with categories
 * - Retry hints and backoff strategies
 * - Structured API response format
 * - Client-friendly error messages
 * - Logging integration
 * 
 * @version 1.0.0
 */ 
// ===== ERROR CATEGORIES =====
var ErrorCategory = /*#__PURE__*/ function(ErrorCategory) {
    ErrorCategory["AUTHENTICATION"] = "AUTHENTICATION";
    ErrorCategory["AUTHORIZATION"] = "AUTHORIZATION";
    ErrorCategory["VALIDATION"] = "VALIDATION";
    ErrorCategory["RATE_LIMIT"] = "RATE_LIMIT";
    ErrorCategory["SERVICE_UNAVAILABLE"] = "SERVICE_UNAVAILABLE";
    ErrorCategory["EXTERNAL_SERVICE"] = "EXTERNAL_SERVICE";
    ErrorCategory["CONFIGURATION"] = "CONFIGURATION";
    ErrorCategory["NOT_FOUND"] = "NOT_FOUND";
    ErrorCategory["CONFLICT"] = "CONFLICT";
    ErrorCategory["INTERNAL"] = "INTERNAL";
    return ErrorCategory;
}({});
// ===== ERROR CODES =====
var ErrorCode = /*#__PURE__*/ function(ErrorCode) {
    // Authentication errors (4xx)
    ErrorCode["AUTH_TOKEN_MISSING"] = "AUTH_TOKEN_MISSING";
    ErrorCode["AUTH_TOKEN_INVALID"] = "AUTH_TOKEN_INVALID";
    ErrorCode["AUTH_TOKEN_EXPIRED"] = "AUTH_TOKEN_EXPIRED";
    ErrorCode["AUTH_SESSION_EXPIRED"] = "AUTH_SESSION_EXPIRED";
    // Authorization errors (4xx)
    ErrorCode["ACCESS_DENIED"] = "ACCESS_DENIED";
    ErrorCode["INSUFFICIENT_PERMISSIONS"] = "INSUFFICIENT_PERMISSIONS";
    ErrorCode["QUOTA_EXCEEDED"] = "QUOTA_EXCEEDED";
    ErrorCode["LICENSE_REQUIRED"] = "LICENSE_REQUIRED";
    // Validation errors (4xx)
    ErrorCode["INVALID_REQUEST"] = "INVALID_REQUEST";
    ErrorCode["MISSING_REQUIRED_FIELD"] = "MISSING_REQUIRED_FIELD";
    ErrorCode["INVALID_FILE_TYPE"] = "INVALID_FILE_TYPE";
    ErrorCode["FILE_TOO_LARGE"] = "FILE_TOO_LARGE";
    ErrorCode["INVALID_PARAMETER"] = "INVALID_PARAMETER";
    // Rate limiting (4xx)
    ErrorCode["RATE_LIMIT_EXCEEDED"] = "RATE_LIMIT_EXCEEDED";
    ErrorCode["CONCURRENT_REQUEST_LIMIT"] = "CONCURRENT_REQUEST_LIMIT";
    // Resource errors (4xx)
    ErrorCode["NOT_FOUND"] = "NOT_FOUND";
    ErrorCode["RESOURCE_CONFLICT"] = "RESOURCE_CONFLICT";
    ErrorCode["RESOURCE_LOCKED"] = "RESOURCE_LOCKED";
    // Service errors (5xx)
    ErrorCode["SERVICE_UNAVAILABLE"] = "SERVICE_UNAVAILABLE";
    ErrorCode["SERVICE_TIMEOUT"] = "SERVICE_TIMEOUT";
    ErrorCode["SERVICE_OVERLOADED"] = "SERVICE_OVERLOADED";
    // External service errors (5xx)
    ErrorCode["AZURE_OPENAI_ERROR"] = "AZURE_OPENAI_ERROR";
    ErrorCode["AZURE_SPEECH_ERROR"] = "AZURE_SPEECH_ERROR";
    ErrorCode["FIREBASE_ERROR"] = "FIREBASE_ERROR";
    ErrorCode["STORAGE_ERROR"] = "STORAGE_ERROR";
    // Configuration errors (5xx)
    ErrorCode["CONFIGURATION_ERROR"] = "CONFIGURATION_ERROR";
    ErrorCode["SERVICE_NOT_CONFIGURED"] = "SERVICE_NOT_CONFIGURED";
    // Internal errors (5xx)
    ErrorCode["INTERNAL_SERVER_ERROR"] = "INTERNAL_SERVER_ERROR";
    ErrorCode["UNHANDLED_ERROR"] = "UNHANDLED_ERROR";
    return ErrorCode;
}({});
// ===== RETRY STRATEGIES =====
var RetryStrategy = /*#__PURE__*/ function(RetryStrategy) {
    RetryStrategy["NONE"] = "NONE";
    RetryStrategy["IMMEDIATE"] = "IMMEDIATE";
    RetryStrategy["LINEAR"] = "LINEAR";
    RetryStrategy["EXPONENTIAL"] = "EXPONENTIAL";
    RetryStrategy["EXPONENTIAL_JITTER"] = "EXPONENTIAL_JITTER"; // Exponential with random jitter
    return RetryStrategy;
}({});
// ===== ERROR DEFINITIONS =====
const ERROR_DEFINITIONS = {
    // Authentication errors
    ["AUTH_TOKEN_MISSING"]: {
        code: "AUTH_TOKEN_MISSING",
        category: "AUTHENTICATION",
        message: 'Authentication token is required but was not provided.',
        retryable: false
    },
    ["AUTH_TOKEN_INVALID"]: {
        code: "AUTH_TOKEN_INVALID",
        category: "AUTHENTICATION",
        message: 'The provided authentication token is invalid.',
        retryable: false
    },
    ["AUTH_TOKEN_EXPIRED"]: {
        code: "AUTH_TOKEN_EXPIRED",
        category: "AUTHENTICATION",
        message: 'Authentication token has expired. Please sign in again.',
        retryable: false
    },
    ["AUTH_SESSION_EXPIRED"]: {
        code: "AUTH_SESSION_EXPIRED",
        category: "AUTHENTICATION",
        message: 'Your session has expired. Please sign in again.',
        retryable: false
    },
    // Authorization errors
    ["ACCESS_DENIED"]: {
        code: "ACCESS_DENIED",
        category: "AUTHORIZATION",
        message: 'Access denied. You do not have permission to perform this action.',
        retryable: false
    },
    ["INSUFFICIENT_PERMISSIONS"]: {
        code: "INSUFFICIENT_PERMISSIONS",
        category: "AUTHORIZATION",
        message: 'Insufficient permissions to access this resource.',
        retryable: false
    },
    ["QUOTA_EXCEEDED"]: {
        code: "QUOTA_EXCEEDED",
        category: "AUTHORIZATION",
        message: 'Usage quota exceeded. Please upgrade your plan or wait for quota reset.',
        retryable: false
    },
    ["LICENSE_REQUIRED"]: {
        code: "LICENSE_REQUIRED",
        category: "AUTHORIZATION",
        message: 'A valid license is required to access this feature.',
        retryable: false
    },
    // Validation errors
    ["INVALID_REQUEST"]: {
        code: "INVALID_REQUEST",
        category: "VALIDATION",
        message: 'The request is invalid or malformed.',
        retryable: false
    },
    ["MISSING_REQUIRED_FIELD"]: {
        code: "MISSING_REQUIRED_FIELD",
        category: "VALIDATION",
        message: 'Required field is missing from the request.',
        retryable: false
    },
    ["INVALID_FILE_TYPE"]: {
        code: "INVALID_FILE_TYPE",
        category: "VALIDATION",
        message: 'Invalid file type. Please upload a supported file format.',
        retryable: false
    },
    ["FILE_TOO_LARGE"]: {
        code: "FILE_TOO_LARGE",
        category: "VALIDATION",
        message: 'File size exceeds the maximum allowed limit.',
        retryable: false
    },
    ["INVALID_PARAMETER"]: {
        code: "INVALID_PARAMETER",
        category: "VALIDATION",
        message: 'One or more parameters are invalid.',
        retryable: false
    },
    // Rate limiting
    ["RATE_LIMIT_EXCEEDED"]: {
        code: "RATE_LIMIT_EXCEEDED",
        category: "RATE_LIMIT",
        message: 'Rate limit exceeded. Please try again later.',
        retryable: true,
        retryStrategy: "EXPONENTIAL",
        retryAfter: 60,
        maxRetries: 3
    },
    ["CONCURRENT_REQUEST_LIMIT"]: {
        code: "CONCURRENT_REQUEST_LIMIT",
        category: "RATE_LIMIT",
        message: 'Too many concurrent requests. Please wait and try again.',
        retryable: true,
        retryStrategy: "LINEAR",
        retryAfter: 5,
        maxRetries: 5
    },
    // Resource errors
    ["NOT_FOUND"]: {
        code: "NOT_FOUND",
        category: "NOT_FOUND",
        message: 'The requested resource was not found.',
        retryable: false
    },
    ["RESOURCE_CONFLICT"]: {
        code: "RESOURCE_CONFLICT",
        category: "CONFLICT",
        message: 'Resource conflict. The resource is in an inconsistent state.',
        retryable: true,
        retryStrategy: "LINEAR",
        retryAfter: 2,
        maxRetries: 3
    },
    ["RESOURCE_LOCKED"]: {
        code: "RESOURCE_LOCKED",
        category: "CONFLICT",
        message: 'Resource is currently locked by another process.',
        retryable: true,
        retryStrategy: "EXPONENTIAL",
        retryAfter: 5,
        maxRetries: 3
    },
    // Service errors
    ["SERVICE_UNAVAILABLE"]: {
        code: "SERVICE_UNAVAILABLE",
        category: "SERVICE_UNAVAILABLE",
        message: 'Service is temporarily unavailable. Please try again later.',
        retryable: true,
        retryStrategy: "EXPONENTIAL",
        retryAfter: 30,
        maxRetries: 3
    },
    ["SERVICE_TIMEOUT"]: {
        code: "SERVICE_TIMEOUT",
        category: "SERVICE_UNAVAILABLE",
        message: 'Service request timed out. Please try again.',
        retryable: true,
        retryStrategy: "LINEAR",
        retryAfter: 10,
        maxRetries: 2
    },
    ["SERVICE_OVERLOADED"]: {
        code: "SERVICE_OVERLOADED",
        category: "SERVICE_UNAVAILABLE",
        message: 'Service is currently overloaded. Please try again later.',
        retryable: true,
        retryStrategy: "EXPONENTIAL_JITTER",
        retryAfter: 60,
        maxRetries: 3
    },
    // External service errors
    ["AZURE_OPENAI_ERROR"]: {
        code: "AZURE_OPENAI_ERROR",
        category: "EXTERNAL_SERVICE",
        message: 'Azure OpenAI service error. Please try again.',
        retryable: true,
        retryStrategy: "EXPONENTIAL",
        retryAfter: 5,
        maxRetries: 3
    },
    ["AZURE_SPEECH_ERROR"]: {
        code: "AZURE_SPEECH_ERROR",
        category: "EXTERNAL_SERVICE",
        message: 'Azure Speech service error. Please try again.',
        retryable: true,
        retryStrategy: "EXPONENTIAL",
        retryAfter: 5,
        maxRetries: 3
    },
    ["FIREBASE_ERROR"]: {
        code: "FIREBASE_ERROR",
        category: "EXTERNAL_SERVICE",
        message: 'Firebase service error. Please try again.',
        retryable: true,
        retryStrategy: "LINEAR",
        retryAfter: 10,
        maxRetries: 2
    },
    ["STORAGE_ERROR"]: {
        code: "STORAGE_ERROR",
        category: "EXTERNAL_SERVICE",
        message: 'File storage error. Please try again.',
        retryable: true,
        retryStrategy: "EXPONENTIAL",
        retryAfter: 15,
        maxRetries: 3
    },
    // Configuration errors
    ["CONFIGURATION_ERROR"]: {
        code: "CONFIGURATION_ERROR",
        category: "CONFIGURATION",
        message: 'Service configuration error. Please contact support.',
        retryable: false
    },
    ["SERVICE_NOT_CONFIGURED"]: {
        code: "SERVICE_NOT_CONFIGURED",
        category: "CONFIGURATION",
        message: 'Service is not properly configured. Please contact support.',
        retryable: false
    },
    // Internal errors
    ["INTERNAL_SERVER_ERROR"]: {
        code: "INTERNAL_SERVER_ERROR",
        category: "INTERNAL",
        message: 'An internal server error occurred. Please try again later.',
        retryable: true,
        retryStrategy: "EXPONENTIAL",
        retryAfter: 30,
        maxRetries: 2
    },
    ["UNHANDLED_ERROR"]: {
        code: "UNHANDLED_ERROR",
        category: "INTERNAL",
        message: 'An unexpected error occurred. Please try again later.',
        retryable: true,
        retryStrategy: "LINEAR",
        retryAfter: 10,
        maxRetries: 1
    }
};
// ===== ERROR FACTORY FUNCTIONS =====
/**
 * Create a structured error with optional details
 */ function createStructuredError(code, details, customMessage, requestId) {
    const definition = ERROR_DEFINITIONS[code];
    return {
        ...definition,
        message: customMessage || definition.message,
        details,
        timestamp: new Date().toISOString(),
        requestId
    };
}
/**
 * Create an API error response
 */ function createErrorResponse(code, details, customMessage, requestId) {
    const error = createStructuredError(code, details, customMessage, requestId);
    // Log server errors for monitoring
    if (error.category === "INTERNAL" || error.category === "EXTERNAL_SERVICE" || error.category === "CONFIGURATION") {
        (0,_lib_errors__WEBPACK_IMPORTED_MODULE_0__/* .logServerError */ .wh)(new Error(error.message), {
            errorCode: error.code,
            category: error.category,
            details: error.details,
            requestId: error.requestId
        });
    }
    return {
        error,
        success: false,
        data: null
    };
}
/**
 * Create a success API response
 */ function createSuccessResponse(data) {
    return {
        error: null,
        success: true,
        data
    };
}
/**
 * Convert HTTP status to appropriate error code
 */ function getErrorCodeFromHTTPStatus(status) {
    switch(status){
        case 400:
            return "INVALID_REQUEST";
        case 401:
            return "AUTH_TOKEN_INVALID";
        case 403:
            return "ACCESS_DENIED";
        case 404:
            return "NOT_FOUND";
        case 409:
            return "RESOURCE_CONFLICT";
        case 413:
            return "FILE_TOO_LARGE";
        case 429:
            return "RATE_LIMIT_EXCEEDED";
        case 500:
            return "INTERNAL_SERVER_ERROR";
        case 502:
            return "SERVICE_UNAVAILABLE";
        case 503:
            return "SERVICE_OVERLOADED";
        case 504:
            return "SERVICE_TIMEOUT";
        default:
            return "UNHANDLED_ERROR";
    }
}
/**
 * Get HTTP status from error code
 */ function getHTTPStatusFromErrorCode(code) {
    const error = ERROR_DEFINITIONS[code];
    switch(error.category){
        case "AUTHENTICATION":
            return 401;
        case "AUTHORIZATION":
            return 403;
        case "VALIDATION":
            return 400;
        case "RATE_LIMIT":
            return 429;
        case "NOT_FOUND":
            return 404;
        case "CONFLICT":
            return 409;
        case "SERVICE_UNAVAILABLE":
        case "EXTERNAL_SERVICE":
            return 503;
        case "CONFIGURATION":
        case "INTERNAL":
        default:
            return 500;
    }
}
/**
 * Check if an error is retryable
 */ function isRetryableError(error) {
    return error.retryable === true;
}
/**
 * Get retry delay in milliseconds based on attempt number
 */ function getRetryDelay(error, attemptNumber, baseDelay) {
    const base = baseDelay || (error.retryAfter || 1) * 1000; // Convert to milliseconds
    switch(error.retryStrategy){
        case "IMMEDIATE":
            return 0;
        case "LINEAR":
            return base * attemptNumber;
        case "EXPONENTIAL":
            return base * Math.pow(2, attemptNumber - 1);
        case "EXPONENTIAL_JITTER":
            const exponentialDelay = base * Math.pow(2, attemptNumber - 1);
            const jitter = Math.random() * 0.1 * exponentialDelay; // ±10% jitter
            return exponentialDelay + jitter;
        case "NONE":
        default:
            return base;
    }
}
/**
 * Convert unknown error to structured error
 */ function toStructuredError(error, defaultCode = "UNHANDLED_ERROR", requestId) {
    if (error && typeof error === 'object' && 'code' in error) {
        // Already a structured error
        return error;
    }
    if (error instanceof Error) {
        return createStructuredError(defaultCode, {
            originalMessage: error.message,
            stack: error.stack
        }, error.message, requestId);
    }
    return createStructuredError(defaultCode, {
        originalError: String(error)
    }, String(error), requestId);
}
// ===== NEXT.JS RESPONSE HELPERS =====
/**
 * Send a structured error response in Next.js API routes
 */ function sendErrorResponse(res, code, details, customMessage, requestId) {
    const errorResponse = createErrorResponse(code, details, customMessage, requestId);
    const status = getHTTPStatusFromErrorCode(code);
    // Set retry headers if applicable
    if (errorResponse.error.retryable && errorResponse.error.retryAfter) {
        res.headers.set('X-Retry-After', String(errorResponse.error.retryAfter));
        res.headers.set('Retry-After', String(errorResponse.error.retryAfter));
    }
    return new Response(JSON.stringify(errorResponse), {
        status,
        headers: {
            'Content-Type': 'application/json',
            ...Object.fromEntries(res.headers || [])
        }
    });
}
/**
 * Send a structured success response in Next.js API routes
 */ function sendSuccessResponse(data, status = 200) {
    const successResponse = createSuccessResponse(data);
    return new Response(JSON.stringify(successResponse), {
        status,
        headers: {
            'Content-Type': 'application/json'
        }
    });
}


/***/ }),

/***/ 53802:
/***/ ((module) => {

"use strict";
module.exports = require("node:child_process");

/***/ }),

/***/ 55591:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 57075:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 57975:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 62201:
/***/ ((module) => {

"use strict";
module.exports = require("@azure/keyvault-secrets");

/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 73024:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 73136:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 74075:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 76760:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 77598:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 79551:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 79646:
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ 81630:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 83997:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 91645:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 97502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   vF: () => (/* binding */ logger)
/* harmony export */ });
/* unused harmony exports debug, info, success, warn, error */
/**
 * Centralized logging utility with debug flag support
 * Helps reduce verbose console.debug statements throughout the codebase
 */ // Environment-based debug flag
const DEBUG =  false || process.env.DEBUG === 'true';
/**
 * Core logger with emoji prefixes for visual recognition
 */ const logger = {
    debug: (message, context)=>{
        if (DEBUG) {
            context ? console.debug(`🔍 ${message}`, context) : console.debug(`🔍 ${message}`);
        }
    },
    info: (message, context)=>{
        context ? console.info(`ℹ️ ${message}`, context) : console.info(`ℹ️ ${message}`);
    },
    success: (message, context)=>{
        context ? console.log(`✅ ${message}`, context) : console.log(`✅ ${message}`);
    },
    warn: (message, context)=>{
        context ? console.warn(`⚠️ ${message}`, context) : console.warn(`⚠️ ${message}`);
    },
    error: (message, error, context)=>{
        const errorInfo = error instanceof Error ? {
            message: error.message,
            stack: error.stack
        } : error;
        context ? console.error(`❌ ${message}`, {
            error: errorInfo,
            ...context
        }) : console.error(`❌ ${message}`, errorInfo);
    },
    // Audio-specific logging shortcuts
    audio: {
        process: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎵 ${message}`, context) : console.debug(`🎵 ${message}`);
            }
        },
        record: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎤 ${message}`, context) : console.debug(`🎤 ${message}`);
            }
        },
        speak: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🔊 ${message}`, context) : console.debug(`🔊 ${message}`);
            }
        }
    },
    // State management logging
    state: (action, from, to, context)=>{
        if (DEBUG) {
            const message = `State transition: ${from} → ${to}`;
            context ? console.debug(`🔄 [${action}] ${message}`, context) : console.debug(`🔄 [${action}] ${message}`);
        }
    },
    // API request logging
    api: {
        request: (endpoint, method, context)=>{
            if (DEBUG) {
                context ? console.debug(`📤 API ${method} ${endpoint}`, context) : console.debug(`📤 API ${method} ${endpoint}`);
            }
        },
        response: (endpoint, status, context)=>{
            const icon = status >= 200 && status < 300 ? '📥' : '❌';
            if (DEBUG) {
                context ? console.debug(`${icon} API Response ${status} ${endpoint}`, context) : console.debug(`${icon} API Response ${status} ${endpoint}`);
            }
        }
    }
};
// Convenience exports
const { debug, info, success, warn, error } = logger;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8794,8833,6716,2530,5506,5191], () => (__webpack_exec__(8615)));
module.exports = __webpack_exports__;

})();