(() => {
var exports = {};
exports.id = 4941;
exports.ids = [4941];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 6231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  AuthSync: () => (/* binding */ AuthSync)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./node_modules/firebase/auth/dist/index.mjs + 2 modules
var dist = __webpack_require__(91042);
// EXTERNAL MODULE: ./firebase/client.ts
var client = __webpack_require__(82897);
// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(51108);
;// ./lib/utils/firebase-auth-debug.ts
/**
 * Firebase Auth Debug Utility (Stub)
 * 
 * Provides mock debugging functionality for Firebase authentication
 * This is a compatibility layer since Firebase is being phased out
 */ function debugFirebaseAuth(auth) {
    console.log('Firebase Auth Debug (stub) - Firebase services are deprecated');
    console.log('Auth object:', auth);
}
function logAuthState(user) {
    console.log('Auth State Debug (stub):', user);
}
function validateAuthToken(token) {
    console.warn('Firebase auth token validation is deprecated - use unified auth system');
    return !!token; // Basic validation
}
/* harmony default export */ const firebase_auth_debug = ({
    debugFirebaseAuth,
    logAuthState,
    validateAuthToken
});

;// ./components/AuthSync.tsx
/* __next_internal_client_entry_do_not_use__ AuthSync auto */ 




function AuthSync() {
    const { user } = (0,AuthContext/* useAuth */.A)();
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        async function syncAuth() {
            // Only run in development for debugging
            if (false) {}
            // If we have a user from server context but no Firebase user, 
            // there's an authentication mismatch
            if (user && client/* auth */.j2 && !client/* auth */.j2.currentUser) {
                console.warn('Authentication mismatch detected: Server has user but Firebase client does not');
                console.warn('This may cause Firestore permission errors');
                console.warn('User ID from server:', user.uid);
                // Try to get a fresh token from the server to sync Firebase auth
                try {
                    const response = await fetch('/api/auth/sync-firebase');
                    if (response.ok) {
                        const { customToken } = await response.json();
                        if (customToken) {
                            await (0,dist/* signInWithCustomToken */.p)(client/* auth */.j2, customToken);
                            console.log('Successfully synced Firebase authentication');
                        }
                    }
                } catch (error) {
                    console.error('Failed to sync Firebase authentication:', error);
                }
            }
        }
        // Run auth sync after a short delay to allow Firebase to initialize
        const timer = setTimeout(syncAuth, 1000);
        return ()=>clearTimeout(timer);
    }, [
        user
    ]);
    return null; // This component doesn't render anything
}


/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 19121:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/action-async-storage.external.js");

/***/ }),

/***/ 19771:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 21295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65239);
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(88170);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30893);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
const module0 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76295));
const module1 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 57398, 23));
const module2 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89999, 23));
const module3 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 65284, 23));
const module4 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83249));
const page5 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99842));


// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'dashboard',
        {
        children: [
        'interview',
        {
        children: ['__PAGE__', {}, {
          page: [page5, "/Users/dikshantvashistha/PrepBettr/app/dashboard/interview/page.tsx"],
          
        }]
      },
        {
        
        
      }
      ]
      },
        {
        'layout': [module4, "/Users/dikshantvashistha/PrepBettr/app/dashboard/layout.tsx"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [module0, "/Users/dikshantvashistha/PrepBettr/app/layout.tsx"],
'not-found': [module1, "next/dist/client/components/not-found-error"],
'forbidden': [module2, "next/dist/client/components/forbidden-error"],
'unauthorized': [module3, "next/dist/client/components/unauthorized-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["/Users/dikshantvashistha/PrepBettr/app/dashboard/interview/page.tsx"];


const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/dashboard/interview/page",
        pathname: "/dashboard/interview",
        // The following aren't used in production.
        bundlePath: '',
        filename: '',
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 21820:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 27910:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 32765:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 70586));


/***/ }),

/***/ 33873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 36994:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99842));


/***/ }),

/***/ 37366:
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ 46675:
/***/ ((module) => {

"use strict";
module.exports = require("firebase-admin");

/***/ }),

/***/ 55511:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 60214:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21114));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6231));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51108));


/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 70586:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js
var react_jsx_runtime = __webpack_require__(60687);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(16189);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-down.js
var chevron_down = __webpack_require__(78272);
// EXTERNAL MODULE: ./components/Agent.tsx + 10 modules
var Agent = __webpack_require__(21530);
// EXTERNAL MODULE: ./components/CodeEditorWrapper.tsx
var CodeEditorWrapper = __webpack_require__(91090);
// EXTERNAL MODULE: ./node_modules/next/dist/api/app-dynamic.js
var app_dynamic = __webpack_require__(30036);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/createLucideIcon.js + 3 modules
var createLucideIcon = __webpack_require__(62688);
;// ./node_modules/lucide-react/dist/esm/icons/cloud-upload.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M12 13v8",
            key: "1l5pq0"
        }
    ],
    [
        "path",
        {
            d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
            key: "1pljnt"
        }
    ],
    [
        "path",
        {
            d: "m8 17 4-4 4 4",
            key: "1quai1"
        }
    ]
];
const CloudUpload = (0,createLucideIcon/* default */.A)("cloud-upload", __iconNode);
 //# sourceMappingURL=cloud-upload.js.map

;// ./components/dynamic/PdfUploadButtonDynamic.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const PdfUploadButton = (0,app_dynamic["default"])(async ()=>{
     true && /*require.resolve*/(null /* weak dependency, without id */);
}, {
    loadableGenerated: {
        modules: [
            "components/dynamic/PdfUploadButtonDynamic.tsx -> " + "../PdfUploadButtonWrapper"
        ]
    },
    ssr: false,
    loading: ()=>/*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
            className: "relative",
            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                type: "button",
                disabled: true,
                className: "p-2 text-gray-400 border border-gray-600 rounded-lg bg-gray-800 cursor-not-allowed opacity-50",
                "aria-label": "Loading upload button...",
                title: "Loading upload button...",
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(CloudUpload, {
                    className: "w-6 h-6 animate-pulse"
                })
            })
        })
});
function PdfUploadButtonDynamic(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(PdfUploadButton, {
        ...props
    });
}

// EXTERNAL MODULE: ./components/ui/BanterLoader.tsx
var BanterLoader = __webpack_require__(36371);
;// ./app/dashboard/interview/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





// Removed server-only import - auth handled by middleware and client auth state


const SUPPORTED_LANGUAGES = [
    {
        value: 'javascript',
        label: 'JavaScript'
    },
    {
        value: 'typescript',
        label: 'TypeScript'
    },
    {
        value: 'python',
        label: 'Python'
    },
    {
        value: 'java',
        label: 'Java'
    },
    {
        value: 'csharp',
        label: 'C#'
    },
    {
        value: 'cpp',
        label: 'C++'
    },
    {
        value: 'go',
        label: 'Go'
    },
    {
        value: 'ruby',
        label: 'Ruby'
    }
];
const Page = ()=>{
    const router = (0,navigation.useRouter)();
    const [isEditorExpanded, setIsEditorExpanded] = (0,react.useState)(false);
    const [selectedLanguage, setSelectedLanguage] = (0,react.useState)('javascript');
    const [isLanguageDropdownOpen, setIsLanguageDropdownOpen] = (0,react.useState)(false);
    const [user, setUser] = (0,react.useState)(null);
    const [isLoading, setIsLoading] = (0,react.useState)(true);
    const [resumeData, setResumeData] = (0,react.useState)(null);
    (0,react.useEffect)(()=>{
        // Check for user auth via API call instead of direct import
        const fetchUser = async ()=>{
            try {
                const response = await fetch('/api/auth/user');
                if (!response.ok) {
                    console.error('Auth API failed with status:', response.status);
                    router.push('/sign-in');
                    return;
                }
                const userData = await response.json();
                if (!userData.user) {
                    console.error('No user data received from auth API');
                    router.push('/sign-in');
                    return;
                }
                setUser({
                    id: userData.user.uid || userData.user.id,
                    name: userData.user.name || userData.user.displayName || 'User',
                    email: userData.user.email || ''
                });
            } catch (error) {
                console.error('Error fetching user:', error);
                router.push('/sign-in');
            } finally{
                setIsLoading(false);
            }
        };
        fetchUser();
    }, [
        router
    ]);
    // Handle successful resume upload
    const handleResumeUpload = (uploadResult)=>{
        console.log('Resume uploaded successfully:', uploadResult);
        setResumeData(uploadResult);
    };
    // Handle resume replacement
    const handleResumeReplaced = ()=>{
        console.log('Resume being replaced...');
    // Could show a confirmation dialog here if needed
    };
    if (isLoading) {
        return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(BanterLoader/* default */.A, {
            overlay: true
        });
    }
    if (!user) {
        return null; // Redirecting to sign-in
    }
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
        className: "flex flex-col gap-8",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "mb-6 p-4 border-b border-gray-700",
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                            className: "flex items-center gap-3",
                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h2", {
                                className: "text-2xl font-bold text-white",
                                children: "AI-Powered Mock Interview"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                            className: "flex items-center gap-4"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "flex justify-between items-center mb-6",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                                className: "text-xl font-semibold text-white",
                                children: "Interview Panel"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "flex items-center gap-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(PdfUploadButtonDynamic, {
                                        onQuestionsGenerated: handleResumeUpload,
                                        onResumeReplaced: handleResumeReplaced
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                        className: "flex items-center gap-2",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                                            onClick: ()=>setIsEditorExpanded(!isEditorExpanded),
                                            className: "p-2 text-gray-300 hover:text-white rounded-lg border border-gray-600 hover:bg-gray-700 transition-colors shadow-sm",
                                            "aria-label": isEditorExpanded ? 'Hide code editor' : 'Show code editor',
                                            title: isEditorExpanded ? 'Hide code editor' : 'Show code editor',
                                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("svg", {
                                                className: "w-6 h-6",
                                                "aria-hidden": "true",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                width: "24",
                                                height: "24",
                                                fill: "none",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
                                                    stroke: "currentColor",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: "2",
                                                    d: "m8 8-4 4 4 4m8 0 4-4-4-4m-2-3-4 14"
                                                })
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                        className: "space-y-4",
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Agent/* default */.A, {
                            userName: user.name,
                            userId: user.id,
                            type: "generate",
                            resumeInfo: resumeData?.extractedData,
                            resumeQuestions: resumeData?.questions
                        })
                    })
                ]
            }),
            isEditorExpanded && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "flex justify-between items-center mb-4",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                                className: "text-xl font-semibold text-white",
                                children: "Code Editor"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("button", {
                                        type: "button",
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            setIsLanguageDropdownOpen(!isLanguageDropdownOpen);
                                        },
                                        className: "flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-gray-200 bg-gray-800 border border-gray-600 rounded-lg hover:bg-gray-700 transition-colors",
                                        children: [
                                            SUPPORTED_LANGUAGES.find((lang)=>lang.value === selectedLanguage)?.label || 'Language',
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(chevron_down/* default */.A, {
                                                className: "w-4 h-4 ml-1"
                                            })
                                        ]
                                    }),
                                    isLanguageDropdownOpen && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                        className: "absolute right-0 z-10 mt-1 w-40 origin-top-right rounded-md bg-gray-800 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                            className: "py-1",
                                            children: SUPPORTED_LANGUAGES.map((language)=>/*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                                                    onClick: (e)=>{
                                                        e.stopPropagation();
                                                        setSelectedLanguage(language.value);
                                                        setIsLanguageDropdownOpen(false);
                                                    },
                                                    className: `block w-full text-left px-4 py-2 text-sm ${selectedLanguage === language.value ? 'bg-gray-700 text-white' : 'text-gray-200 hover:bg-gray-700'}`,
                                                    children: language.label
                                                }, language.value))
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(CodeEditorWrapper/* CodeEditorWrapper */.k, {
                        initialValue: `// Write your ${SUPPORTED_LANGUAGES.find((lang)=>lang.value === selectedLanguage)?.label || 'code'} here\n// The interviewer may ask you to solve coding problems\n// Use this editor to write and test your solutions`,
                        language: selectedLanguage,
                        className: "h-[500px] transition-all duration-300",
                        isExpanded: true,
                        onToggleExpand: ()=>setIsEditorExpanded(false)
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 73496:
/***/ ((module) => {

"use strict";
module.exports = require("http2");

/***/ }),

/***/ 74075:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 79551:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 80694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthSync: () => (/* binding */ AuthSync)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

const AuthSync = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call AuthSync() from the server but AuthSync is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/AuthSync.tsx",
"AuthSync",
);

/***/ }),

/***/ 81630:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 83249:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Layout),
/* harmony export */   dynamic: () => (/* binding */ dynamic),
/* harmony export */   revalidate: () => (/* binding */ revalidate)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37413);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39916);
/* harmony import */ var _lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60940);
/* harmony import */ var _components_authenticated_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52045);
/* harmony import */ var _contexts_AuthContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94442);
/* harmony import */ var _components_AuthSync__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(80694);






// Force dynamic rendering since we use cookies
const dynamic = 'force-dynamic'; // Required for cookie access
const revalidate = 0; // Disable caching for auth
async function Layout({ children }) {
    console.log('🏠 Dashboard layout: Starting authentication check...');
    // Check authentication
    const isAuth = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__/* .isAuthenticated */ .wR)();
    console.log('🏠 Dashboard layout: Authentication result:', isAuth);
    if (!isAuth) {
        console.log('🏠 Dashboard layout: User not authenticated, redirecting to sign-in');
        (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.redirect)('/sign-in');
    }
    // Get the current user to pass to the context
    console.log('🏠 Dashboard layout: Getting current user...');
    const user = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__/* .getCurrentUser */ .HW)();
    console.log('🏠 Dashboard layout: Current user:', user ? {
        uid: user.uid,
        email: user.email
    } : null);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_4__.AuthProvider, {
        initialUser: user,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_AuthSync__WEBPACK_IMPORTED_MODULE_5__.AuthSync, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_authenticated_layout__WEBPACK_IMPORTED_MODULE_3__["default"], {
                children: children
            })
        ]
    });
}


/***/ }),

/***/ 91645:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 97166:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52045));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 80694));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94442));


/***/ }),

/***/ 99842:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/app/dashboard/interview/page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/app/dashboard/interview/page.tsx",
"default",
));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8134,1658,5814,474,4999,1012,8062,7697,7055,9757,8703,8175,3733], () => (__webpack_exec__(21295)));
module.exports = __webpack_exports__;

})();