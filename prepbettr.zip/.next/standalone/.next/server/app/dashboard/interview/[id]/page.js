(() => {
var exports = {};
exports.id = 4001;
exports.ids = [4001];
exports.modules = {

/***/ 2240:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16965));


/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 6231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  AuthSync: () => (/* binding */ AuthSync)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./node_modules/firebase/auth/dist/index.mjs + 2 modules
var dist = __webpack_require__(91042);
// EXTERNAL MODULE: ./firebase/client.ts
var client = __webpack_require__(82897);
// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(51108);
;// ./lib/utils/firebase-auth-debug.ts
/**
 * Firebase Auth Debug Utility (Stub)
 * 
 * Provides mock debugging functionality for Firebase authentication
 * This is a compatibility layer since Firebase is being phased out
 */ function debugFirebaseAuth(auth) {
    console.log('Firebase Auth Debug (stub) - Firebase services are deprecated');
    console.log('Auth object:', auth);
}
function logAuthState(user) {
    console.log('Auth State Debug (stub):', user);
}
function validateAuthToken(token) {
    console.warn('Firebase auth token validation is deprecated - use unified auth system');
    return !!token; // Basic validation
}
/* harmony default export */ const firebase_auth_debug = ({
    debugFirebaseAuth,
    logAuthState,
    validateAuthToken
});

;// ./components/AuthSync.tsx
/* __next_internal_client_entry_do_not_use__ AuthSync auto */ 




function AuthSync() {
    const { user } = (0,AuthContext/* useAuth */.A)();
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        async function syncAuth() {
            // Only run in development for debugging
            if (false) {}
            // If we have a user from server context but no Firebase user, 
            // there's an authentication mismatch
            if (user && client/* auth */.j2 && !client/* auth */.j2.currentUser) {
                console.warn('Authentication mismatch detected: Server has user but Firebase client does not');
                console.warn('This may cause Firestore permission errors');
                console.warn('User ID from server:', user.uid);
                // Try to get a fresh token from the server to sync Firebase auth
                try {
                    const response = await fetch('/api/auth/sync-firebase');
                    if (response.ok) {
                        const { customToken } = await response.json();
                        if (customToken) {
                            await (0,dist/* signInWithCustomToken */.p)(client/* auth */.j2, customToken);
                            console.log('Successfully synced Firebase authentication');
                        }
                    }
                } catch (error) {
                    console.error('Failed to sync Firebase authentication:', error);
                }
            }
        }
        // Run auth sync after a short delay to allow Firebase to initialize
        const timer = setTimeout(syncAuth, 1000);
        return ()=>clearTimeout(timer);
    }, [
        user
    ]);
    return null; // This component doesn't render anything
}


/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 16965:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ InterviewClient)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(30036);
/* __next_internal_client_entry_do_not_use__ default auto */ 

// Dynamically import the client component with no SSR
const InterviewContent = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_1__["default"])(async ()=>{
     true && /*require.resolve*/(null /* weak dependency, without id */);
}, {
    loadableGenerated: {
        modules: [
            "app/dashboard/interview/[id]/InterviewClient.tsx -> " + "./InterviewContent"
        ]
    },
    ssr: false
});
function InterviewClient({ interview, feedback, user }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(InterviewContent, {
        interview: interview,
        feedback: feedback,
        user: user
    });
}


/***/ }),

/***/ 19121:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/action-async-storage.external.js");

/***/ }),

/***/ 19587:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "encodeURIPath", ({
    enumerable: true,
    get: function() {
        return encodeURIPath;
    }
}));
function encodeURIPath(file) {
    return file.split('/').map((p)=>encodeURIComponent(p)).join('/');
} //# sourceMappingURL=encode-uri-path.js.map


/***/ }),

/***/ 19771:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 21820:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 27910:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 30036:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport default from dynamic */ _shared_lib_app_dynamic__WEBPACK_IMPORTED_MODULE_0___default.a)
/* harmony export */ });
/* harmony import */ var _shared_lib_app_dynamic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49587);
/* harmony import */ var _shared_lib_app_dynamic__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_shared_lib_app_dynamic__WEBPACK_IMPORTED_MODULE_0__);



//# sourceMappingURL=app-dynamic.js.map

/***/ }),

/***/ 33873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 36407:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/app/dashboard/interview/[id]/InterviewClient.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/app/dashboard/interview/[id]/InterviewClient.tsx",
"default",
));


/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37366:
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ 38688:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 36407));


/***/ }),

/***/ 42318:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Page),
/* harmony export */   generateStaticParams: () => (/* binding */ generateStaticParams)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37413);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(60940);
/* harmony import */ var _InterviewClient__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36407);
// export const dynamic = 'force-dynamic'; // Commented out for static export



async function getInterviewData(id) {
    try {
        // Check if this is a mock interview ID and generate appropriate data
        if (id.startsWith('mock-interview-')) {
            const mockIndex = parseInt(id.split('-')[2]) - 1;
            const mockInterviews = [
                {
                    role: 'Frontend Developer',
                    type: 'Technical',
                    techstack: [
                        'React',
                        'TypeScript',
                        'Next.js',
                        'Tailwind CSS'
                    ],
                    questions: [
                        'Explain the concept of React hooks and provide examples',
                        'What is the virtual DOM and how does it work?',
                        'How do you handle state management in React applications?'
                    ]
                },
                {
                    role: 'Backend Developer',
                    type: 'Technical',
                    techstack: [
                        'Node.js',
                        'Express',
                        'MongoDB',
                        'JavaScript'
                    ],
                    questions: [
                        'Explain RESTful API design principles',
                        'How do you handle database relationships in MongoDB?',
                        'What are middleware functions in Express.js?'
                    ]
                },
                {
                    role: 'Full Stack Developer',
                    type: 'Mixed',
                    techstack: [
                        'Python',
                        'Django',
                        'PostgreSQL',
                        'Redis'
                    ],
                    questions: [
                        'Describe your experience with full-stack development',
                        'How do you optimize database queries?',
                        'What is your approach to handling user authentication?'
                    ]
                },
                {
                    role: 'Software Engineer',
                    type: 'Behavioral',
                    techstack: [
                        'Vue.js',
                        'Nuxt.js',
                        'Vuex',
                        'SCSS'
                    ],
                    questions: [
                        'Tell me about a challenging project you worked on',
                        'How do you handle conflicts in a team environment?',
                        'Describe a time when you had to learn a new technology quickly'
                    ]
                },
                {
                    role: 'DevOps Engineer',
                    type: 'Technical',
                    techstack: [
                        'Docker',
                        'Kubernetes',
                        'AWS',
                        'Jenkins'
                    ],
                    questions: [
                        'Explain containerization and its benefits',
                        'How do you implement CI/CD pipelines?',
                        'What is Infrastructure as Code?'
                    ]
                },
                {
                    role: 'Data Scientist',
                    type: 'Technical',
                    techstack: [
                        'Python',
                        'TensorFlow',
                        'Pandas',
                        'SQL'
                    ],
                    questions: [
                        'Explain the difference between supervised and unsupervised learning',
                        'How do you handle missing data in datasets?',
                        'What is feature engineering and why is it important?'
                    ]
                },
                {
                    role: 'Mobile Developer',
                    type: 'Mixed',
                    techstack: [
                        'React Native',
                        'JavaScript',
                        'Firebase',
                        'Redux'
                    ],
                    questions: [
                        'What are the advantages of React Native over native development?',
                        'How do you handle offline functionality in mobile apps?',
                        'Describe your experience with mobile app deployment'
                    ]
                },
                {
                    role: 'QA Engineer',
                    type: 'Technical',
                    techstack: [
                        'Selenium',
                        'Jest',
                        'Cypress',
                        'JavaScript'
                    ],
                    questions: [
                        'What is the difference between unit testing and integration testing?',
                        'How do you design test cases for a new feature?',
                        'Explain automation testing strategies you have used'
                    ]
                }
            ];
            const selectedMock = mockInterviews[mockIndex % mockInterviews.length];
            const mockData = {
                interview: {
                    id,
                    role: selectedMock.role,
                    type: selectedMock.type,
                    questions: selectedMock.questions.map((q, idx)=>({
                            id: `${idx + 1}`,
                            content: q,
                            type: selectedMock.type.toLowerCase(),
                            difficulty: 'medium',
                            techStack: selectedMock.techstack
                        })),
                    techstack: selectedMock.techstack,
                    createdAt: new Date().toISOString()
                },
                feedback: null
            };
            const currentUser = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_1__/* .getCurrentUser */ .HW)();
            return {
                ...mockData,
                user: currentUser ? {
                    id: currentUser.uid || currentUser.id || 'static-user',
                    name: currentUser.name || currentUser.displayName || 'User',
                    email: currentUser.email || 'user@example.com'
                } : {
                    id: 'static-user',
                    name: 'User',
                    email: 'user@example.com'
                }
            };
        }
        // In a real app, you would fetch this data from the database
        // const response = await fetch(`/api/interview/${id}`);
        // const result = await response.json();
        // Default mock data for non-mock interviews
        const mockData = {
            interview: {
                id,
                role: 'Developer',
                type: 'Technical',
                questions: [
                    {
                        id: '1',
                        content: 'Explain the concept of React hooks',
                        type: 'technical',
                        difficulty: 'medium',
                        techStack: [
                            'React',
                            'JavaScript'
                        ]
                    },
                    {
                        id: '2',
                        content: 'What is the virtual DOM?',
                        type: 'technical',
                        difficulty: 'easy',
                        techStack: [
                            'React',
                            'JavaScript'
                        ]
                    }
                ],
                techstack: [
                    'JavaScript',
                    'React',
                    'Node.js'
                ],
                createdAt: new Date().toISOString()
            },
            feedback: null
        };
        const currentUser = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_1__/* .getCurrentUser */ .HW)();
        return {
            ...mockData,
            user: currentUser ? {
                id: currentUser.uid || currentUser.id || 'static-user',
                name: currentUser.name || currentUser.displayName || 'User',
                email: currentUser.email || 'user@example.com'
            } : {
                id: 'static-user',
                name: 'User',
                email: 'user@example.com'
            }
        };
    } catch (error) {
        console.error('Error fetching interview data:', error);
        throw error;
    }
}
async function generateStaticParams() {
    // Generate static params for mock interviews only
    // In production, you'd fetch actual interview IDs from the database
    return [
        {
            id: 'mock-interview-1'
        },
        {
            id: 'mock-interview-2'
        },
        {
            id: 'mock-interview-3'
        },
        {
            id: 'mock-interview-4'
        },
        {
            id: 'mock-interview-5'
        },
        {
            id: 'mock-interview-6'
        },
        {
            id: 'mock-interview-7'
        },
        {
            id: 'mock-interview-8'
        }
    ];
}
async function Page({ params }) {
    const { id } = await params;
    const interviewData = await getInterviewData(id);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_InterviewClient__WEBPACK_IMPORTED_MODULE_2__["default"], {
        interview: interviewData.interview,
        feedback: interviewData.feedback,
        user: interviewData.user
    });
}


/***/ }),

/***/ 46675:
/***/ ((module) => {

"use strict";
module.exports = require("firebase-admin");

/***/ }),

/***/ 49587:
/***/ ((module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "default", ({
    enumerable: true,
    get: function() {
        return dynamic;
    }
}));
const _interop_require_default = __webpack_require__(14985);
const _loadable = /*#__PURE__*/ _interop_require_default._(__webpack_require__(64963));
function dynamic(dynamicOptions, options) {
    var _mergedOptions_loadableGenerated;
    const loadableOptions = {};
    if (typeof dynamicOptions === 'function') {
        loadableOptions.loader = dynamicOptions;
    }
    const mergedOptions = {
        ...loadableOptions,
        ...options
    };
    return (0, _loadable.default)({
        ...mergedOptions,
        modules: (_mergedOptions_loadableGenerated = mergedOptions.loadableGenerated) == null ? void 0 : _mergedOptions_loadableGenerated.modules
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dynamic.js.map


/***/ }),

/***/ 55511:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 56780:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* __next_internal_client_entry_do_not_use__  cjs */ 
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "BailoutToCSR", ({
    enumerable: true,
    get: function() {
        return BailoutToCSR;
    }
}));
const _bailouttocsr = __webpack_require__(81208);
function BailoutToCSR(param) {
    let { reason, children } = param;
    if (true) {
        throw Object.defineProperty(new _bailouttocsr.BailoutToCSRError(reason), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
    }
    return children;
} //# sourceMappingURL=dynamic-bailout-to-csr.js.map


/***/ }),

/***/ 60214:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21114));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6231));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51108));


/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 64777:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* __next_internal_client_entry_do_not_use__  cjs */ 
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "PreloadChunks", ({
    enumerable: true,
    get: function() {
        return PreloadChunks;
    }
}));
const _jsxruntime = __webpack_require__(60687);
const _reactdom = __webpack_require__(51215);
const _workasyncstorageexternal = __webpack_require__(29294);
const _encodeuripath = __webpack_require__(19587);
function PreloadChunks(param) {
    let { moduleIds } = param;
    // Early return in client compilation and only load requestStore on server side
    if (false) {}
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    if (workStore === undefined) {
        return null;
    }
    const allFiles = [];
    // Search the current dynamic call unique key id in react loadable manifest,
    // and find the corresponding CSS files to preload
    if (workStore.reactLoadableManifest && moduleIds) {
        const manifest = workStore.reactLoadableManifest;
        for (const key of moduleIds){
            if (!manifest[key]) continue;
            const chunks = manifest[key].files;
            allFiles.push(...chunks);
        }
    }
    if (allFiles.length === 0) {
        return null;
    }
    const dplId =  false ? 0 : '';
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
        children: allFiles.map((chunk)=>{
            const href = workStore.assetPrefix + "/_next/" + (0, _encodeuripath.encodeURIPath)(chunk) + dplId;
            const isCss = chunk.endsWith('.css');
            // If it's stylesheet we use `precedence` o help hoist with React Float.
            // For stylesheets we actually need to render the CSS because nothing else is going to do it so it needs to be part of the component tree.
            // The `preload` for stylesheet is not optional.
            if (isCss) {
                return /*#__PURE__*/ (0, _jsxruntime.jsx)("link", {
                    // @ts-ignore
                    precedence: "dynamic",
                    href: href,
                    rel: "stylesheet",
                    as: "style"
                }, chunk);
            } else {
                // If it's script we use ReactDOM.preload to preload the resources
                (0, _reactdom.preload)(href, {
                    as: 'script',
                    fetchPriority: 'low'
                });
                return null;
            }
        })
    });
} //# sourceMappingURL=preload-chunks.js.map


/***/ }),

/***/ 64963:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "default", ({
    enumerable: true,
    get: function() {
        return _default;
    }
}));
const _jsxruntime = __webpack_require__(60687);
const _react = __webpack_require__(43210);
const _dynamicbailouttocsr = __webpack_require__(56780);
const _preloadchunks = __webpack_require__(64777);
// Normalize loader to return the module as form { default: Component } for `React.lazy`.
// Also for backward compatible since next/dynamic allows to resolve a component directly with loader
// Client component reference proxy need to be converted to a module.
function convertModule(mod) {
    // Check "default" prop before accessing it, as it could be client reference proxy that could break it reference.
    // Cases:
    // mod: { default: Component }
    // mod: Component
    // mod: { default: proxy(Component) }
    // mod: proxy(Component)
    const hasDefault = mod && 'default' in mod;
    return {
        default: hasDefault ? mod.default : mod
    };
}
const defaultOptions = {
    loader: ()=>Promise.resolve(convertModule(()=>null)),
    loading: null,
    ssr: true
};
function Loadable(options) {
    const opts = {
        ...defaultOptions,
        ...options
    };
    const Lazy = /*#__PURE__*/ (0, _react.lazy)(()=>opts.loader().then(convertModule));
    const Loading = opts.loading;
    function LoadableComponent(props) {
        const fallbackElement = Loading ? /*#__PURE__*/ (0, _jsxruntime.jsx)(Loading, {
            isLoading: true,
            pastDelay: true,
            error: null
        }) : null;
        // If it's non-SSR or provided a loading component, wrap it in a suspense boundary
        const hasSuspenseBoundary = !opts.ssr || !!opts.loading;
        const Wrap = hasSuspenseBoundary ? _react.Suspense : _react.Fragment;
        const wrapProps = hasSuspenseBoundary ? {
            fallback: fallbackElement
        } : {};
        const children = opts.ssr ? /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
            children: [
                 true ? /*#__PURE__*/ (0, _jsxruntime.jsx)(_preloadchunks.PreloadChunks, {
                    moduleIds: opts.modules
                }) : 0,
                /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                    ...props
                })
            ]
        }) : /*#__PURE__*/ (0, _jsxruntime.jsx)(_dynamicbailouttocsr.BailoutToCSR, {
            reason: "next/dynamic",
            children: /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                ...props
            })
        });
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(Wrap, {
            ...wrapProps,
            children: children
        });
    }
    LoadableComponent.displayName = 'LoadableComponent';
    return LoadableComponent;
}
const _default = Loadable; //# sourceMappingURL=loadable.js.map


/***/ }),

/***/ 73496:
/***/ ((module) => {

"use strict";
module.exports = require("http2");

/***/ }),

/***/ 74075:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 79551:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 80694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthSync: () => (/* binding */ AuthSync)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

const AuthSync = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call AuthSync() from the server but AuthSync is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/AuthSync.tsx",
"AuthSync",
);

/***/ }),

/***/ 81630:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 82305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65239);
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(88170);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30893);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
const module0 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76295));
const module1 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 57398, 23));
const module2 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89999, 23));
const module3 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 65284, 23));
const module4 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83249));
const page5 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42318));


// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'dashboard',
        {
        children: [
        'interview',
        {
        children: [
        '[id]',
        {
        children: ['__PAGE__', {}, {
          page: [page5, "/Users/dikshantvashistha/PrepBettr/app/dashboard/interview/[id]/page.tsx"],
          
        }]
      },
        {
        
        
      }
      ]
      },
        {
        
        
      }
      ]
      },
        {
        'layout': [module4, "/Users/dikshantvashistha/PrepBettr/app/dashboard/layout.tsx"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [module0, "/Users/dikshantvashistha/PrepBettr/app/layout.tsx"],
'not-found': [module1, "next/dist/client/components/not-found-error"],
'forbidden': [module2, "next/dist/client/components/forbidden-error"],
'unauthorized': [module3, "next/dist/client/components/unauthorized-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["/Users/dikshantvashistha/PrepBettr/app/dashboard/interview/[id]/page.tsx"];


const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/dashboard/interview/[id]/page",
        pathname: "/dashboard/interview/[id]",
        // The following aren't used in production.
        bundlePath: '',
        filename: '',
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 82897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   db: () => (/* binding */ db),
/* harmony export */   hJ: () => (/* binding */ googleProvider),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(67989);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91042);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75535);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  false ? 0 : null;
    const windowProjectId =  false ? 0 : null;
    const windowAuthDomain =  false ? 0 : null;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || `${finalProjectId}.firebaseapp.com`;
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (true) {
        console.log('🔥 Firebase initialization skipped on server side');
        return;
    }
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = getApps();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = initializeApp(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = getAuth(app);
        db = getFirestore(app);
        // Initialize Google Auth Provider
        googleProvider = new GoogleAuthProvider();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (false) {}
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (false) {}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});


/***/ }),

/***/ 83249:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Layout),
/* harmony export */   dynamic: () => (/* binding */ dynamic),
/* harmony export */   revalidate: () => (/* binding */ revalidate)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37413);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39916);
/* harmony import */ var _lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60940);
/* harmony import */ var _components_authenticated_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52045);
/* harmony import */ var _contexts_AuthContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94442);
/* harmony import */ var _components_AuthSync__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(80694);






// Force dynamic rendering since we use cookies
const dynamic = 'force-dynamic'; // Required for cookie access
const revalidate = 0; // Disable caching for auth
async function Layout({ children }) {
    console.log('🏠 Dashboard layout: Starting authentication check...');
    // Check authentication
    const isAuth = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__/* .isAuthenticated */ .wR)();
    console.log('🏠 Dashboard layout: Authentication result:', isAuth);
    if (!isAuth) {
        console.log('🏠 Dashboard layout: User not authenticated, redirecting to sign-in');
        (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.redirect)('/sign-in');
    }
    // Get the current user to pass to the context
    console.log('🏠 Dashboard layout: Getting current user...');
    const user = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__/* .getCurrentUser */ .HW)();
    console.log('🏠 Dashboard layout: Current user:', user ? {
        uid: user.uid,
        email: user.email
    } : null);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_4__.AuthProvider, {
        initialUser: user,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_AuthSync__WEBPACK_IMPORTED_MODULE_5__.AuthSync, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_authenticated_layout__WEBPACK_IMPORTED_MODULE_3__["default"], {
                children: children
            })
        ]
    });
}


/***/ }),

/***/ 91645:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 97166:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52045));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 80694));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94442));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8134,1658,5814,474,4999,1012,8062,7697,9757,8703,8175], () => (__webpack_exec__(82305)));
module.exports = __webpack_exports__;

})();