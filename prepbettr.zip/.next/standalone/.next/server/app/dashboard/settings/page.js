(() => {
var exports = {};
exports.id = 4631;
exports.ids = [4631];
exports.modules = {

/***/ 3018:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fc: () => (/* binding */ Alert),
/* harmony export */   TN: () => (/* binding */ AlertDescription)
/* harmony export */ });
/* unused harmony export AlertTitle */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24224);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);




const alertVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("relative w-full rounded-lg border p-4 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7", {
    variants: {
        variant: {
            default: "bg-background text-foreground",
            destructive: "border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
const Alert = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, variant, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        role: "alert",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(alertVariants({
            variant
        }), className),
        ...props
    }));
Alert.displayName = "Alert";
const AlertTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h5", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("mb-1 font-medium leading-none tracking-tight", className),
        ...props
    }));
AlertTitle.displayName = "AlertTitle";
const AlertDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("text-sm [&_p]:leading-relaxed", className),
        ...props
    }));
AlertDescription.displayName = "AlertDescription";



/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 6231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  AuthSync: () => (/* binding */ AuthSync)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./node_modules/firebase/auth/dist/index.mjs + 2 modules
var dist = __webpack_require__(91042);
// EXTERNAL MODULE: ./firebase/client.ts
var client = __webpack_require__(82897);
// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(51108);
;// ./lib/utils/firebase-auth-debug.ts
/**
 * Firebase Auth Debug Utility (Stub)
 * 
 * Provides mock debugging functionality for Firebase authentication
 * This is a compatibility layer since Firebase is being phased out
 */ function debugFirebaseAuth(auth) {
    console.log('Firebase Auth Debug (stub) - Firebase services are deprecated');
    console.log('Auth object:', auth);
}
function logAuthState(user) {
    console.log('Auth State Debug (stub):', user);
}
function validateAuthToken(token) {
    console.warn('Firebase auth token validation is deprecated - use unified auth system');
    return !!token; // Basic validation
}
/* harmony default export */ const firebase_auth_debug = ({
    debugFirebaseAuth,
    logAuthState,
    validateAuthToken
});

;// ./components/AuthSync.tsx
/* __next_internal_client_entry_do_not_use__ AuthSync auto */ 




function AuthSync() {
    const { user } = (0,AuthContext/* useAuth */.A)();
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        async function syncAuth() {
            // Only run in development for debugging
            if (false) {}
            // If we have a user from server context but no Firebase user, 
            // there's an authentication mismatch
            if (user && client/* auth */.j2 && !client/* auth */.j2.currentUser) {
                console.warn('Authentication mismatch detected: Server has user but Firebase client does not');
                console.warn('This may cause Firestore permission errors');
                console.warn('User ID from server:', user.uid);
                // Try to get a fresh token from the server to sync Firebase auth
                try {
                    const response = await fetch('/api/auth/sync-firebase');
                    if (response.ok) {
                        const { customToken } = await response.json();
                        if (customToken) {
                            await (0,dist/* signInWithCustomToken */.p)(client/* auth */.j2, customToken);
                            console.log('Successfully synced Firebase authentication');
                        }
                    }
                } catch (error) {
                    console.error('Failed to sync Firebase authentication:', error);
                }
            }
        }
        // Run auth sync after a short delay to allow Firebase to initialize
        const timer = setTimeout(syncAuth, 1000);
        return ()=>clearTimeout(timer);
    }, [
        user
    ]);
    return null; // This component doesn't render anything
}


/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 19121:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/action-async-storage.external.js");

/***/ }),

/***/ 19771:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 21820:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 27910:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37366:
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ 39390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ Label)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78148);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);
/* __next_internal_client_entry_do_not_use__ Label auto */ 



function Label({ className, ...props }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .b, {
        "data-slot": "label",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className),
        ...props
    });
}



/***/ }),

/***/ 46675:
/***/ ((module) => {

"use strict";
module.exports = require("firebase-admin");

/***/ }),

/***/ 55511:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 56093:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65239);
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(88170);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30893);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
const module0 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76295));
const module1 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 57398, 23));
const module2 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89999, 23));
const module3 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 65284, 23));
const module4 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83249));
const page5 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 58144));


// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'dashboard',
        {
        children: [
        'settings',
        {
        children: ['__PAGE__', {}, {
          page: [page5, "/Users/dikshantvashistha/PrepBettr/app/dashboard/settings/page.tsx"],
          
        }]
      },
        {
        
        
      }
      ]
      },
        {
        'layout': [module4, "/Users/dikshantvashistha/PrepBettr/app/dashboard/layout.tsx"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [module0, "/Users/dikshantvashistha/PrepBettr/app/layout.tsx"],
'not-found': [module1, "next/dist/client/components/not-found-error"],
'forbidden': [module2, "next/dist/client/components/forbidden-error"],
'unauthorized': [module3, "next/dist/client/components/unauthorized-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["/Users/dikshantvashistha/PrepBettr/app/dashboard/settings/page.tsx"];


const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/dashboard/settings/page",
        pathname: "/dashboard/settings",
        // The following aren't used in production.
        bundlePath: '',
        filename: '',
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 58144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/app/dashboard/settings/page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/app/dashboard/settings/page.tsx",
"default",
));


/***/ }),

/***/ 60214:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21114));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6231));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51108));


/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 63974:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bq: () => (/* binding */ SelectTrigger),
/* harmony export */   eb: () => (/* binding */ SelectItem),
/* harmony export */   gC: () => (/* binding */ SelectContent),
/* harmony export */   l6: () => (/* binding */ Select),
/* harmony export */   yv: () => (/* binding */ SelectValue)
/* harmony export */ });
/* unused harmony exports SelectGroup, SelectLabel, SelectSeparator, SelectScrollUpButton, SelectScrollDownButton */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(72951);
/* harmony import */ var _barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(78272);
/* harmony import */ var _barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3589);
/* harmony import */ var _barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13964);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);





const Select = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .bL;
const SelectGroup = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Group */ .YJ;
const SelectValue = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Value */ .WT;
const SelectTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Icon */ .In, {
                asChild: true,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A, {
                    className: "h-4 w-4 opacity-50"
                })
            })
        ]
    }));
SelectTrigger.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9.displayName;
const SelectScrollUpButton = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollUpButton */ .PP, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A, {
            className: "h-4 w-4"
        })
    }));
SelectScrollUpButton.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollUpButton */ .PP.displayName;
const SelectScrollDownButton = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollDownButton */ .wn, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A, {
            className: "h-4 w-4"
        })
    }));
SelectScrollDownButton.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ScrollDownButton */ .wn.displayName;
const SelectContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, children, position = "popper", ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Portal */ .ZL, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC, {
            ref: ref,
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
            position: position,
            ...props,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SelectScrollUpButton, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Viewport */ .LM, {
                    className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                    children: children
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(SelectScrollDownButton, {})
            ]
        })
    }));
SelectContent.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC.displayName;
const SelectLabel = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .JU, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("py-1.5 pl-8 pr-2 text-sm font-semibold", className),
        ...props
    }));
SelectLabel.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Label */ .JU.displayName;
const SelectItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Item */ .q7, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ItemIndicator */ .VF, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_barrel_optimize_names_Check_ChevronDown_ChevronUp_lucide_react__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, {
                        className: "h-4 w-4"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .ItemText */ .p4, {
                children: children
            })
        ]
    }));
SelectItem.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Item */ .q7.displayName;
const SelectSeparator = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Separator */ .wv, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("-mx-1 my-1 h-px bg-muted", className),
        ...props
    }));
SelectSeparator.displayName = _radix_ui_react_select__WEBPACK_IMPORTED_MODULE_3__/* .Separator */ .wv.displayName;



/***/ }),

/***/ 67874:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 58144));


/***/ }),

/***/ 73496:
/***/ ((module) => {

"use strict";
module.exports = require("http2");

/***/ }),

/***/ 74075:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 74598:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SettingsPage)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js
var react_jsx_runtime = __webpack_require__(60687);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/createLucideIcon.js + 3 modules
var createLucideIcon = __webpack_require__(62688);
;// ./node_modules/lucide-react/dist/esm/icons/zap.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const __iconNode = [
    [
        "path",
        {
            d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
            key: "1xq2db"
        }
    ]
];
const Zap = (0,createLucideIcon/* default */.A)("zap", __iconNode);
 //# sourceMappingURL=zap.js.map

;// ./node_modules/lucide-react/dist/esm/icons/circle-alert.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const circle_alert_iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "line",
        {
            x1: "12",
            x2: "12",
            y1: "8",
            y2: "12",
            key: "1pkeuh"
        }
    ],
    [
        "line",
        {
            x1: "12",
            x2: "12.01",
            y1: "16",
            y2: "16",
            key: "4dfq90"
        }
    ]
];
const CircleAlert = (0,createLucideIcon/* default */.A)("circle-alert", circle_alert_iconNode);
 //# sourceMappingURL=circle-alert.js.map

;// ./node_modules/lucide-react/dist/esm/icons/clock.js
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ 
const clock_iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "polyline",
        {
            points: "12 6 12 12 16 14",
            key: "68esgv"
        }
    ]
];
const Clock = (0,createLucideIcon/* default */.A)("clock", clock_iconNode);
 //# sourceMappingURL=clock.js.map

// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/log-out.js
var log_out = __webpack_require__(40083);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(16189);
// EXTERNAL MODULE: ./components/ui/tabs.tsx
var tabs = __webpack_require__(85910);
// EXTERNAL MODULE: ./node_modules/@radix-ui/primitive/dist/index.mjs
var dist = __webpack_require__(70569);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-compose-refs/dist/index.mjs
var react_compose_refs_dist = __webpack_require__(98599);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-context/dist/index.mjs
var react_context_dist = __webpack_require__(11273);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var react_use_controllable_state_dist = __webpack_require__(65551);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-use-previous/dist/index.mjs
var react_use_previous_dist = __webpack_require__(83721);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-use-size/dist/index.mjs
var react_use_size_dist = __webpack_require__(18853);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-primitive/dist/index.mjs
var react_primitive_dist = __webpack_require__(14163);
;// ./node_modules/@radix-ui/react-switch/dist/index.mjs
/* __next_internal_client_entry_do_not_use__ Root,Switch,SwitchThumb,Thumb,createSwitchScope auto */ // src/switch.tsx









var SWITCH_NAME = "Switch";
var [createSwitchContext, createSwitchScope] = (0,react_context_dist/* createContextScope */.A)(SWITCH_NAME);
var [SwitchProvider, useSwitchContext] = createSwitchContext(SWITCH_NAME);
var Switch = /*#__PURE__*/ react.forwardRef((props, forwardedRef)=>{
    const { __scopeSwitch, name, checked: checkedProp, defaultChecked, required, disabled, value = "on", onCheckedChange, form, ...switchProps } = props;
    const [button, setButton] = react.useState(null);
    const composedRefs = (0,react_compose_refs_dist/* useComposedRefs */.s)(forwardedRef, (node)=>setButton(node));
    const hasConsumerStoppedPropagationRef = react.useRef(false);
    const isFormControl = button ? form || !!button.closest("form") : true;
    const [checked, setChecked] = (0,react_use_controllable_state_dist/* useControllableState */.i)({
        prop: checkedProp,
        defaultProp: defaultChecked ?? false,
        onChange: onCheckedChange,
        caller: SWITCH_NAME
    });
    return /* @__PURE__ */ (0,react_jsx_runtime.jsxs)(SwitchProvider, {
        scope: __scopeSwitch,
        checked,
        disabled,
        children: [
            /* @__PURE__ */ (0,react_jsx_runtime.jsx)(react_primitive_dist/* Primitive */.sG.button, {
                type: "button",
                role: "switch",
                "aria-checked": checked,
                "aria-required": required,
                "data-state": getState(checked),
                "data-disabled": disabled ? "" : void 0,
                disabled,
                value,
                ...switchProps,
                ref: composedRefs,
                onClick: (0,dist/* composeEventHandlers */.mK)(props.onClick, (event)=>{
                    setChecked((prevChecked)=>!prevChecked);
                    if (isFormControl) {
                        hasConsumerStoppedPropagationRef.current = event.isPropagationStopped();
                        if (!hasConsumerStoppedPropagationRef.current) event.stopPropagation();
                    }
                })
            }),
            isFormControl && /* @__PURE__ */ (0,react_jsx_runtime.jsx)(SwitchBubbleInput, {
                control: button,
                bubbles: !hasConsumerStoppedPropagationRef.current,
                name,
                value,
                checked,
                required,
                disabled,
                form,
                style: {
                    transform: "translateX(-100%)"
                }
            })
        ]
    });
});
Switch.displayName = SWITCH_NAME;
var THUMB_NAME = "SwitchThumb";
var SwitchThumb = /*#__PURE__*/ react.forwardRef((props, forwardedRef)=>{
    const { __scopeSwitch, ...thumbProps } = props;
    const context = useSwitchContext(THUMB_NAME, __scopeSwitch);
    return /* @__PURE__ */ (0,react_jsx_runtime.jsx)(react_primitive_dist/* Primitive */.sG.span, {
        "data-state": getState(context.checked),
        "data-disabled": context.disabled ? "" : void 0,
        ...thumbProps,
        ref: forwardedRef
    });
});
SwitchThumb.displayName = THUMB_NAME;
var BUBBLE_INPUT_NAME = "SwitchBubbleInput";
var SwitchBubbleInput = /*#__PURE__*/ react.forwardRef(({ __scopeSwitch, control, checked, bubbles = true, ...props }, forwardedRef)=>{
    const ref = react.useRef(null);
    const composedRefs = (0,react_compose_refs_dist/* useComposedRefs */.s)(ref, forwardedRef);
    const prevChecked = (0,react_use_previous_dist/* usePrevious */.Z)(checked);
    const controlSize = (0,react_use_size_dist/* useSize */.X)(control);
    react.useEffect(()=>{
        const input = ref.current;
        if (!input) return;
        const inputProto = window.HTMLInputElement.prototype;
        const descriptor = Object.getOwnPropertyDescriptor(inputProto, "checked");
        const setChecked = descriptor.set;
        if (prevChecked !== checked && setChecked) {
            const event = new Event("click", {
                bubbles
            });
            setChecked.call(input, checked);
            input.dispatchEvent(event);
        }
    }, [
        prevChecked,
        checked,
        bubbles
    ]);
    return /* @__PURE__ */ (0,react_jsx_runtime.jsx)("input", {
        type: "checkbox",
        "aria-hidden": true,
        defaultChecked: checked,
        ...props,
        tabIndex: -1,
        ref: composedRefs,
        style: {
            ...props.style,
            ...controlSize,
            position: "absolute",
            pointerEvents: "none",
            opacity: 0,
            margin: 0
        }
    });
});
SwitchBubbleInput.displayName = BUBBLE_INPUT_NAME;
function getState(checked) {
    return checked ? "checked" : "unchecked";
}
var Root = Switch;
var Thumb = SwitchThumb;
 //# sourceMappingURL=index.mjs.map

// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(57048);
;// ./components/ui/switch.tsx




const switch_Switch = /*#__PURE__*/ react.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime.jsx)(Root, {
        className: (0,utils.cn)("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
        ...props,
        ref: ref,
        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Thumb, {
            className: (0,utils.cn)("pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0")
        })
    }));
switch_Switch.displayName = Root.displayName;


// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(68988);
// EXTERNAL MODULE: ./components/ui/label.tsx
var label = __webpack_require__(39390);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(24934);
// EXTERNAL MODULE: ./components/ui/separator.tsx
var separator = __webpack_require__(78377);
// EXTERNAL MODULE: ./components/ui/select.tsx
var ui_select = __webpack_require__(63974);
// EXTERNAL MODULE: ./lib/hooks/useUnifiedConfig.ts
var hooks_useUnifiedConfig = __webpack_require__(79042);
;// ./lib/hooks/useFeatureFlags.ts


/**
 * Client-safe feature flags hook that uses API calls instead of direct service imports
 * This avoids bundling server-only modules for the client
 */ const useFeatureFlags = ()=>{
    const [flags, setFlags] = (0,react.useState)(null);
    const [loading, setLoading] = (0,react.useState)(true);
    const [error, setError] = (0,react.useState)(null);
    // Load feature flags on component mount using API instead of direct service import
    (0,react.useEffect)(()=>{
        const loadFlags = async ()=>{
            try {
                setLoading(true);
                setError(null);
                // Fetch from API endpoint instead of direct service import
                const response = await fetch('/api/feature-flags');
                if (!response.ok) {
                    throw new Error('Failed to fetch feature flags');
                }
                const enhancedFlags = await response.json();
                setFlags(enhancedFlags);
                setLoading(false);
            } catch (err) {
                console.error('Error loading feature flags:', err);
                setError(err instanceof Error ? err.message : 'Failed to load feature flags');
                setLoading(false);
                // Set default flags if loading fails
                if (!flags) {
                    setFlags({
                        autoApplyAzure: false,
                        portalIntegration: false,
                        voiceInterview: false,
                        premiumFeatures: false,
                        newUI: false,
                        rolloutStatus: {
                            autoApplyAzure: false,
                            portalIntegration: false,
                            voiceInterview: false,
                            premiumFeatures: false,
                            newUI: false
                        }
                    });
                }
            }
        };
        loadFlags();
    }, []);
    const getFeatureFlag = (flagName)=>{
        return flags?.[flagName] || false;
    };
    const refreshFlags = async ()=>{
        try {
            setLoading(true);
            setError(null);
            const response = await fetch('/api/feature-flags?refresh=true');
            if (!response.ok) {
                throw new Error('Failed to refresh feature flags');
            }
            const newFlags = await response.json();
            setFlags(newFlags);
            setLoading(false);
        } catch (err) {
            console.error('Error refreshing feature flags:', err);
            setError(err instanceof Error ? err.message : 'Failed to refresh feature flags');
            setLoading(false);
        }
    };
    return {
        flags,
        loading,
        error,
        getFeatureFlag,
        refreshFlags,
        // Convenience methods for specific flags
        isAutoApplyAzureEnabled: ()=>getFeatureFlag('autoApplyAzure'),
        isPortalIntegrationEnabled: ()=>getFeatureFlag('portalIntegration'),
        isVoiceInterviewEnabled: ()=>getFeatureFlag('voiceInterview'),
        isPremiumFeaturesEnabled: ()=>getFeatureFlag('premiumFeatures'),
        isNewUIEnabled: ()=>getFeatureFlag('newUI')
    };
};
/**
 * Simplified hook for individual feature flags using unified config directly
 * More performant for components that only need specific flags
 */ const useUnifiedFeatureFlag = (flagName)=>{
    const configKey = `features.${flagName}`;
    return useUnifiedConfig(configKey, false);
};
/**
 * Hook for getting multiple feature flags at once
 */ const useUnifiedFeatureFlags = (flagNames)=>{
    const results = flagNames.reduce((acc, flagName)=>{
        const configKey = `features.${flagName}`;
        // eslint-disable-next-line react-hooks/rules-of-hooks
        acc[flagName] = useUnifiedConfig(configKey, false);
        return acc;
    }, {});
    return results;
};

// EXTERNAL MODULE: ./components/ui/alert.tsx
var ui_alert = __webpack_require__(3018);
;// ./app/dashboard/settings/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 












function SettingsPage() {
    const [reminderTime, setReminderTime] = (0,react.useState)('08:00');
    const timeInputRef = (0,react.useRef)(null);
    const router = (0,navigation.useRouter)();
    const { flags, loading, refreshFlags, isAutoApplyAzureEnabled, isPortalIntegrationEnabled } = useFeatureFlags();
    const handleLogout = async ()=>{
        try {
            // Clear any local storage or session data
            localStorage.clear();
            sessionStorage.clear();
            // Call logout API and redirect to marketing page
            await fetch("/api/profile/logout", {
                method: "POST"
            });
            router.push('/marketing');
            router.refresh();
        } catch (error) {
            console.error('Error during logout:', error);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
        className: "max-w-4xl mx-auto px-6 py-10",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h1", {
                className: "text-3xl font-bold mb-6 text-white dark:text-white",
                children: "Settings"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* Tabs */.tU, {
                defaultValue: "interview",
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* TabsList */.j7, {
                        className: "grid w-full grid-cols-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "interview",
                                children: "Interview"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "ai",
                                children: "AI"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "notifications",
                                children: "Notifications"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "privacy",
                                children: "Privacy"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsTrigger */.Xi, {
                                value: "account",
                                children: "Account"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* TabsContent */.av, {
                        value: "interview",
                        className: "space-y-4 bg-gray-900 p-6 rounded-lg border border-gray-700",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        htmlFor: "target-roles",
                                        className: "text-gray-300",
                                        children: "Target Roles"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                        id: "target-roles",
                                        placeholder: "e.g. Frontend Engineer, PM",
                                        className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus-visible:ring-blue-500"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        className: "text-gray-300",
                                        children: "Experience Level"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_select/* Select */.l6, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectTrigger */.bq, {
                                                className: "bg-gray-800 border-gray-600 text-white",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectValue */.yv, {
                                                    placeholder: "Choose experience level"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_select/* SelectContent */.gC, {
                                                className: "bg-gray-800 border-gray-600",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "fresher",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Fresher"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "mid",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Mid-level"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "senior",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Senior"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        className: "text-gray-300",
                                        children: "Preferred Question Types"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                        placeholder: "e.g. Coding, Behavioral",
                                        className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus-visible:ring-blue-500"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        className: "text-gray-300",
                                        children: "Preferred Domain"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                        placeholder: "e.g. Fintech, Edtech",
                                        className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus-visible:ring-blue-500"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* TabsContent */.av, {
                        value: "ai",
                        className: "space-y-4 bg-gray-900 p-6 rounded-lg border border-gray-700",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("h3", {
                                                className: "text-lg font-semibold text-white mb-4 flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Zap, {
                                                        className: "h-5 w-5 text-blue-400"
                                                    }),
                                                    "New AI Engine (Beta)"
                                                ]
                                            }),
                                            loading ? /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                className: "animate-pulse bg-gray-800 h-4 w-full rounded mb-2"
                                            }) : /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                        className: "space-y-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                                className: "flex items-center justify-between p-3 bg-gray-800 rounded-lg border border-gray-700",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                                        className: "flex-1",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                                                className: "text-white font-medium",
                                                                                children: "Auto-Apply with Azure AI"
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                                                                className: "text-sm text-gray-400 mt-1",
                                                                                children: "Automatically apply to jobs using advanced Azure OpenAI integration"
                                                                            }),
                                                                            flags?.rolloutStatus?.autoApplyAzure && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                                                                className: "inline-block mt-1 px-2 py-1 text-xs bg-blue-900 text-blue-200 rounded",
                                                                                children: "You're in the beta rollout!"
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                                        className: "flex items-center ml-4",
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {
                                                                            checked: isAutoApplyAzureEnabled(),
                                                                            disabled: !flags?.rolloutStatus?.autoApplyAzure
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                                className: "flex items-center justify-between p-3 bg-gray-800 rounded-lg border border-gray-700",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                                        className: "flex-1",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                                                className: "text-white font-medium",
                                                                                children: "Enhanced Portal Integration"
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                                                                className: "text-sm text-gray-400 mt-1",
                                                                                children: "Seamless integration with LinkedIn, Indeed, and other job portals"
                                                                            }),
                                                                            flags?.rolloutStatus?.portalIntegration && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                                                                className: "inline-block mt-1 px-2 py-1 text-xs bg-blue-900 text-blue-200 rounded",
                                                                                children: "You're in the beta rollout!"
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                                        className: "flex items-center ml-4",
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {
                                                                            checked: isPortalIntegrationEnabled(),
                                                                            disabled: !flags?.rolloutStatus?.portalIntegration
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    !flags?.rolloutStatus?.autoApplyAzure && !flags?.rolloutStatus?.portalIntegration && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_alert/* Alert */.Fc, {
                                                        className: "mt-4 border-blue-600 bg-blue-900/20",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(CircleAlert, {
                                                                className: "h-4 w-4 text-blue-400"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_alert/* AlertDescription */.TN, {
                                                                className: "text-blue-200",
                                                                children: "These features are currently in beta rollout. You'll be automatically included as we expand to more users."
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                        variant: "outline",
                                                        size: "sm",
                                                        onClick: refreshFlags,
                                                        className: "mt-2 bg-gray-800 border-gray-600 text-white hover:bg-gray-700",
                                                        children: "Check for Updates"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(separator/* Separator */.w, {
                                        className: "border-gray-600"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                        className: "space-y-3",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h4", {
                                                className: "text-white font-medium",
                                                children: "General AI Settings"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                        className: "text-white",
                                                        children: "Enable Smart Feedback"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                        className: "flex items-center",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {
                                                            defaultChecked: true
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                        className: "text-white",
                                                        children: "Adaptive Difficulty"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                        className: "flex items-center",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {
                                                            defaultChecked: true
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                        className: "text-white",
                                                        children: "Use Past Performance"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                        className: "flex items-center",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {})
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        className: "text-gray-300",
                                        children: "Preferred Language"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_select/* Select */.l6, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectTrigger */.bq, {
                                                className: "bg-gray-800 border-gray-600 text-white",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectValue */.yv, {
                                                    placeholder: "Choose a language"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_select/* SelectContent */.gC, {
                                                className: "bg-gray-800 border-gray-600",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "en",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "English"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "zh",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Chinese (Mandarin)"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "hi",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Hindi"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "es",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Spanish"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "fr",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "French"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "ar",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Arabic"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "bn",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Bengali"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "pt",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Portuguese"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "ru",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Russian"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "ja",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Japanese"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "de",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "German"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "ko",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Korean"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "it",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Italian"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "tr",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Turkish"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "nl",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Dutch"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "pl",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Polish"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "uk",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Ukrainian"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "vi",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Vietnamese"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "th",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Thai"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_select/* SelectItem */.eb, {
                                                        value: "fa",
                                                        className: "text-white hover:bg-gray-700",
                                                        children: "Persian"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* TabsContent */.av, {
                        value: "notifications",
                        className: "space-y-4 bg-gray-900 p-6 rounded-lg border border-gray-700",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        className: "text-white",
                                        children: "Daily Practice Reminder"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                        className: "flex items-center",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {
                                            defaultChecked: true
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        className: "text-gray-300",
                                        children: "Reminder Time"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                        className: "relative w-40",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                                ref: timeInputRef,
                                                type: "time",
                                                value: reminderTime,
                                                onChange: (e)=>setReminderTime(e.target.value),
                                                className: "pl-10 pr-3 py-2 w-full bg-gray-800 border-gray-600 text-white [&::-webkit-calendar-picker-indicator]:hidden [&::-webkit-inner-spin-button]:hidden [&::-webkit-clear-button]:hidden"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                                                type: "button",
                                                onClick: ()=>timeInputRef.current?.showPicker(),
                                                className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 hover:text-white transition-colors",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Clock, {
                                                    className: "h-4 w-4"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        className: "text-white",
                                        children: "Email Notifications"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                        className: "flex items-center",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {})
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(tabs/* TabsContent */.av, {
                        value: "privacy",
                        className: "space-y-4 bg-gray-900 p-6 rounded-lg border border-gray-700",
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                            className: "space-y-6",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                                            className: "text-lg font-semibold text-white mb-4",
                                            children: "Data Consent Preferences"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                            className: "space-y-3",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                                    className: "text-white",
                                                                    children: "Analytics & Performance"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                                                    className: "text-sm text-gray-400",
                                                                    children: "Help us improve the platform by sharing usage analytics"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                            className: "flex items-center",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {
                                                                defaultChecked: true
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                                    className: "text-white",
                                                                    children: "Marketing Communications"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                                                    className: "text-sm text-gray-400",
                                                                    children: "Receive updates about new features and tips"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                            className: "flex items-center",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {})
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                                                    className: "text-white",
                                                                    children: "Functional Cookies"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                                                    className: "text-sm text-gray-400",
                                                                    children: "Essential for the platform to work properly"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                            className: "flex items-center",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(switch_Switch, {
                                                                defaultChecked: true,
                                                                disabled: true
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(separator/* Separator */.w, {
                                    className: "border-gray-600"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                                            className: "text-lg font-semibold text-white mb-4",
                                            children: "Data Management"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                            className: "space-y-3",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                    className: "flex flex-col sm:flex-row gap-3",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                            variant: "outline",
                                                            className: "bg-gray-800 border-gray-600 text-white hover:bg-gray-700",
                                                            children: "Download My Data"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                            variant: "outline",
                                                            className: "bg-gray-800 border-gray-600 text-white hover:bg-gray-700",
                                                            children: "View Data Usage"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                                    className: "text-sm text-gray-400",
                                                    children: "You can export all your personal data or view how your data is being used."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(separator/* Separator */.w, {
                                    className: "border-gray-600"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                                            className: "text-lg font-semibold text-white mb-4",
                                            children: "Right to be Forgotten"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                            className: "space-y-3",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                    variant: "destructive",
                                                    className: "bg-red-600 hover:bg-red-700 text-white",
                                                    children: "Request Data Deletion"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                                    className: "text-sm text-gray-400",
                                                    children: "Permanently delete all your personal data within 30 days. This action cannot be undone."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(separator/* Separator */.w, {
                                    className: "border-gray-600"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                                            className: "text-lg font-semibold text-white mb-4",
                                            children: "Privacy Information"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("a", {
                                                    href: "/marketing/privacy",
                                                    className: "text-blue-400 hover:text-blue-300 text-sm underline",
                                                    children: "Privacy Policy"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("br", {}),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("a", {
                                                    href: "/marketing/cookies",
                                                    className: "text-blue-400 hover:text-blue-300 text-sm underline",
                                                    children: "Cookie Policy"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("br", {}),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("a", {
                                                    href: "/marketing/terms",
                                                    className: "text-blue-400 hover:text-blue-300 text-sm underline",
                                                    children: "Terms of Service"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(tabs/* TabsContent */.av, {
                        value: "account",
                        className: "space-y-4 bg-gray-900 p-6 rounded-lg border border-gray-700",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        className: "text-gray-300",
                                        children: "Change Password"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                        type: "password",
                                        placeholder: "New Password",
                                        className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus-visible:ring-blue-500"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                                        className: "mt-2 bg-blue-600 hover:bg-blue-700 text-white border-blue-500",
                                        children: "Update Password"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(separator/* Separator */.w, {
                                className: "my-4 border-gray-600"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        className: "text-gray-300",
                                        children: "Account Actions"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                        className: "flex gap-4",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                                onClick: handleLogout,
                                                variant: "outline",
                                                className: "bg-gray-800 border-gray-600 text-white hover:bg-gray-700 hover:text-white border-gray-500 flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(log_out/* default */.A, {
                                                        className: "h-4 w-4"
                                                    }),
                                                    "Sign Out"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                                                variant: "destructive",
                                                className: "bg-red-600 hover:bg-red-700 text-white border-red-500",
                                                children: "Delete My Account"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 79042:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   u: () => (/* binding */ useFeatureFlag)
/* harmony export */ });
/* unused harmony exports useUnifiedConfig, useUnifiedConfigs, useFeatureFlags, useAppConfig, useQuotaConfig */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* __next_internal_client_entry_do_not_use__ useUnifiedConfig,useUnifiedConfigs,useFeatureFlag,useFeatureFlags,useAppConfig,useQuotaConfig,default auto */ /**
 * Client-side React hook for unified configuration service
 * 
 * This provides a clean React interface to the unified config service
 * with proper state management, caching, and error handling.
 */ 
/**
 * Hook to get a single configuration value with reactivity using API calls
 * This avoids bundling server-only modules for the client
 */ function useUnifiedConfig(key, defaultValue) {
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultValue);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const fetchValue = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async ()=>{
        try {
            setLoading(true);
            setError(null);
            // Use API endpoint instead of direct service import
            const response = await fetch(`/api/config/${encodeURIComponent(key)}`);
            if (!response.ok) {
                throw new Error(`Failed to fetch config: ${response.statusText}`);
            }
            const data = await response.json();
            setValue(data.value !== undefined ? data.value : defaultValue);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Unknown error');
            setValue(defaultValue);
        } finally{
            setLoading(false);
        }
    }, [
        key,
        defaultValue
    ]);
    const refresh = async ()=>{
        await fetchValue();
    };
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        fetchValue();
    }, [
        fetchValue
    ]);
    return {
        value,
        loading,
        error,
        refresh
    };
}
/**
 * Hook to get multiple configuration values at once
 */ function useUnifiedConfigs(keys, defaultValues) {
    const [values, setValues] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const fetchValues = useCallback(async ()=>{
        try {
            setLoading(true);
            setError(null);
            // Use API endpoints for each config key
            const configPromises = keys.map(async (key)=>{
                const response = await fetch(`/api/config/${encodeURIComponent(String(key))}`);
                if (!response.ok) {
                    throw new Error(`Failed to fetch config for ${String(key)}: ${response.statusText}`);
                }
                const data = await response.json();
                return {
                    key,
                    value: data.value !== undefined ? data.value : defaultValues?.[key]
                };
            });
            const configResults = await Promise.all(configPromises);
            const result = {};
            configResults.forEach(({ key, value })=>{
                result[key] = value;
            });
            setValues(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Unknown error');
            setValues({
                ...defaultValues
            });
        } finally{
            setLoading(false);
        }
    }, [
        keys,
        defaultValues
    ]);
    const refresh = async ()=>{
        await fetchValues();
    };
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && useEffect(()=>{
        fetchValues();
    }, [
        fetchValues
    ]);
    return {
        values,
        loading,
        error,
        refresh
    };
}
/**
 * Hook for feature flags specifically
 */ function useFeatureFlag(flagName) {
    const configKey = `features.${flagName}`;
    const { value, loading, error } = useUnifiedConfig(configKey, false);
    return {
        enabled: value,
        loading,
        error
    };
}
/**
 * Hook for multiple feature flags
 */ function useFeatureFlags(flagNames) {
    const configKeys = flagNames.map((name)=>`features.${String(name)}`);
    const defaultFlags = flagNames.reduce((acc, name)=>{
        acc[name] = false;
        return acc;
    }, {});
    const { values, loading, error } = useUnifiedConfigs(configKeys, defaultFlags);
    // Transform config keys back to flag names
    const flags = {};
    flagNames.forEach((flagName, index)=>{
        const configKey = configKeys[index];
        flags[flagName] = values[configKey] || false;
    });
    return {
        flags,
        loading,
        error
    };
}
/**
 * Hook for application configuration
 */ function useAppConfig() {
    const configKeys = [
        'core.app.environment',
        'core.app.version',
        'core.app.debug',
        'core.app.maintenanceMode'
    ];
    const { values, loading, error } = useUnifiedConfigs([
        ...configKeys
    ], {
        'core.app.environment': 'development',
        'core.app.version': '1.0.0',
        'core.app.debug': false,
        'core.app.maintenanceMode': false
    });
    return {
        environment: values['core.app.environment'],
        version: values['core.app.version'],
        debug: values['core.app.debug'],
        maintenanceMode: values['core.app.maintenanceMode'],
        loading,
        error
    };
}
/**
 * Hook for quotas and limits
 */ function useQuotaConfig() {
    const configKeys = [
        'quotas.freeInterviews',
        'quotas.freeResumes',
        'quotas.premiumInterviews',
        'quotas.premiumResumes'
    ];
    const { values, loading, error } = useUnifiedConfigs([
        ...configKeys
    ], {
        'quotas.freeInterviews': 3,
        'quotas.freeResumes': 2,
        'quotas.premiumInterviews': 100,
        'quotas.premiumResumes': 20
    });
    return {
        freeInterviews: values['quotas.freeInterviews'],
        freeResumes: values['quotas.freeResumes'],
        premiumInterviews: values['quotas.premiumInterviews'],
        premiumResumes: values['quotas.premiumResumes'],
        loading,
        error
    };
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useUnifiedConfig)));


/***/ }),

/***/ 79551:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 80694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthSync: () => (/* binding */ AuthSync)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

const AuthSync = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call AuthSync() from the server but AuthSync is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/AuthSync.tsx",
"AuthSync",
);

/***/ }),

/***/ 81630:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 82897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   db: () => (/* binding */ db),
/* harmony export */   hJ: () => (/* binding */ googleProvider),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(67989);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91042);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75535);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  false ? 0 : null;
    const windowProjectId =  false ? 0 : null;
    const windowAuthDomain =  false ? 0 : null;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || `${finalProjectId}.firebaseapp.com`;
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (true) {
        console.log('🔥 Firebase initialization skipped on server side');
        return;
    }
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = getApps();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = initializeApp(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = getAuth(app);
        db = getFirestore(app);
        // Initialize Google Auth Provider
        googleProvider = new GoogleAuthProvider();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (false) {}
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (false) {}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});


/***/ }),

/***/ 83249:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Layout),
/* harmony export */   dynamic: () => (/* binding */ dynamic),
/* harmony export */   revalidate: () => (/* binding */ revalidate)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37413);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39916);
/* harmony import */ var _lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60940);
/* harmony import */ var _components_authenticated_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52045);
/* harmony import */ var _contexts_AuthContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94442);
/* harmony import */ var _components_AuthSync__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(80694);






// Force dynamic rendering since we use cookies
const dynamic = 'force-dynamic'; // Required for cookie access
const revalidate = 0; // Disable caching for auth
async function Layout({ children }) {
    console.log('🏠 Dashboard layout: Starting authentication check...');
    // Check authentication
    const isAuth = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__/* .isAuthenticated */ .wR)();
    console.log('🏠 Dashboard layout: Authentication result:', isAuth);
    if (!isAuth) {
        console.log('🏠 Dashboard layout: User not authenticated, redirecting to sign-in');
        (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.redirect)('/sign-in');
    }
    // Get the current user to pass to the context
    console.log('🏠 Dashboard layout: Getting current user...');
    const user = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__/* .getCurrentUser */ .HW)();
    console.log('🏠 Dashboard layout: Current user:', user ? {
        uid: user.uid,
        email: user.email
    } : null);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_4__.AuthProvider, {
        initialUser: user,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_AuthSync__WEBPACK_IMPORTED_MODULE_5__.AuthSync, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_authenticated_layout__WEBPACK_IMPORTED_MODULE_3__["default"], {
                children: children
            })
        ]
    });
}


/***/ }),

/***/ 85910:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Xi: () => (/* binding */ TabsTrigger),
/* harmony export */   av: () => (/* binding */ TabsContent),
/* harmony export */   j7: () => (/* binding */ TabsList),
/* harmony export */   tU: () => (/* binding */ Tabs)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(55146);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);




const Tabs = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .bL;
const TabsList = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .List */ .B8, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    }));
TabsList.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .List */ .B8.displayName;
const TabsTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    }));
TabsTrigger.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Trigger */ .l9.displayName;
const TabsContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }));
TabsContent.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_3__/* .Content */ .UC.displayName;



/***/ }),

/***/ 86026:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 74598));


/***/ }),

/***/ 91645:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 97166:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52045));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 80694));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94442));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8134,1658,5814,474,4999,1012,8062,7697,3835,9757,8703,8175], () => (__webpack_exec__(56093)));
module.exports = __webpack_exports__;

})();