(() => {
var exports = {};
exports.id = 3468;
exports.ids = [3468];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 4536:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const { createProxy } = __webpack_require__(39844)

module.exports = createProxy("/Users/dikshantvashistha/PrepBettr/node_modules/next/dist/client/app-dir/link.js")


/***/ }),

/***/ 6797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ LogoutButton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16189);
/* __next_internal_client_entry_do_not_use__ default auto */ 

function LogoutButton() {
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const handleLogout = async ()=>{
        try {
            await fetch("/api/profile/logout", {
                method: "POST"
            });
            router.push("/marketing");
            router.refresh();
        } catch (error) {
            console.error('Logout failed:', error);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
        onClick: handleLogout,
        className: "p-2 hover:bg-primary-100/10 dark:hover:bg-white/10 rounded-full transition-colors flex items-center justify-center",
        "aria-label": "Logout",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            className: "w-6 h-6 text-primary-100",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
                d: "M17 16L21 12M21 12L17 8M21 12H7M13 16V17C13 17.7956 12.6839 18.5587 12.1213 19.1213C11.5587 19.6839 10.7956 20 10 20H6C5.20435 20 4.44129 19.6839 3.87868 19.1213C3.31607 18.5587 3 17.7956 3 17V7C3 6.20435 3.31607 5.44129 3.87868 4.87868C4.44129 4.31607 5.20435 4 6 4H10C10.7956 4 11.5587 4.31607 12.1213 4.87868C12.6839 5.44129 13 6.20435 13 7V8",
                stroke: "currentColor",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        })
    });
}


/***/ }),

/***/ 10756:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/identity");;

/***/ }),

/***/ 10846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 16519:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65239);
/* harmony import */ var next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48088);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(88170);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30893);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
const module0 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76295));
const module1 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 57398, 23));
const module2 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89999, 23));
const module3 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 65284, 23));
const module4 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 27470));
const module5 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 57398, 23));
const module6 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89999, 23));
const module7 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 65284, 23));
const page8 = () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72511));


// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        '(auth)',
        {
        children: [
        'profile',
        {
        children: ['__PAGE__', {}, {
          page: [page8, "/Users/dikshantvashistha/PrepBettr/app/(auth)/profile/page.tsx"],
          
        }]
      },
        {
        
        
      }
      ]
      },
        {
        'layout': [module4, "/Users/dikshantvashistha/PrepBettr/app/(auth)/layout.tsx"],
'not-found': [module5, "next/dist/client/components/not-found-error"],
'forbidden': [module6, "next/dist/client/components/forbidden-error"],
'unauthorized': [module7, "next/dist/client/components/unauthorized-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [module0, "/Users/dikshantvashistha/PrepBettr/app/layout.tsx"],
'not-found': [module1, "next/dist/client/components/not-found-error"],
'forbidden': [module2, "next/dist/client/components/forbidden-error"],
'unauthorized': [module3, "next/dist/client/components/unauthorized-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46055))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["/Users/dikshantvashistha/PrepBettr/app/(auth)/profile/page.tsx"];


const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new next_dist_server_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/(auth)/profile/page",
        pathname: "/profile",
        // The following aren't used in production.
        bundlePath: '',
        filename: '',
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 19121:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/action-async-storage.external.js");

/***/ }),

/***/ 19771:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 21820:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 24934:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Button)
/* harmony export */ });
/* unused harmony export buttonVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8730);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24224);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);





const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none", {
    variants: {
        variant: {
            default: "bg-primary-200 text-dark-100 shadow-xs hover:bg-primary-200/90 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            destructive: "bg-destructive-100 text-white shadow-xs hover:bg-destructive-200 focus-visible:ring-destructive-100/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            outline: "border border-gray-600 bg-gray-800 text-white shadow-xs hover:bg-gray-700 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800/50 disabled:text-gray-500 disabled:border-gray-700",
            secondary: "bg-gray-700 text-white shadow-xs hover:bg-gray-600 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800 disabled:text-gray-500",
            ghost: "text-white hover:bg-gray-800 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500",
            link: "text-primary-200 underline-offset-4 hover:underline focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__/* .Slot */ .DX : "button";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Comp, {
        "data-slot": "button",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    });
}



/***/ }),

/***/ 27470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37413);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const AuthLayout = ({ children })=>{
    // Authentication redirect is now handled by middleware
    // This layout just provides the structure for auth pages
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "min-h-screen relative",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "min-h-screen flex items-center justify-center p-4 relative z-10 overflow-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-full max-w-lg",
                children: children
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthLayout);


/***/ }),

/***/ 27910:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 28354:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 29021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 29294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 33873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 34631:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 36695:
/***/ ((module) => {

"use strict";
module.exports = import("@azure/keyvault-secrets");;

/***/ }),

/***/ 37152:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/components/ProfileForm.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/ProfileForm.tsx",
"default",
));


/***/ }),

/***/ 37366:
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ 39390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ Label)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78148);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);
/* __next_internal_client_entry_do_not_use__ Label auto */ 



function Label({ className, ...props }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .b, {
        "data-slot": "label",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className),
        ...props
    });
}



/***/ }),

/***/ 46055:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(31658);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (props) => {
    const imageData = {"type":"image/x-icon","sizes":"256x256"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", await props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 46675:
/***/ ((module) => {

"use strict";
module.exports = require("firebase-admin");

/***/ }),

/***/ 48051:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/components/LogoutButton.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/LogoutButton.tsx",
"default",
));


/***/ }),

/***/ 54498:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48051));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 37152));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4536, 23));


/***/ }),

/***/ 55511:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 56949:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ProfileForm)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js
var react_jsx_runtime = __webpack_require__(60687);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(24934);
// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(68988);
// EXTERNAL MODULE: ./components/ui/label.tsx
var label = __webpack_require__(39390);
// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(57048);
;// ./components/ui/textarea.tsx



const Textarea = /*#__PURE__*/ react.forwardRef(({ className, ...props }, ref)=>{
    const isDisabled = props.disabled;
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)("textarea", {
        className: (0,utils.cn)(// Base styles for dark theme
        "bg-gray-800 text-white placeholder-gray-400 border-gray-600", "flex min-h-[80px] w-full rounded-md border px-3 py-2 text-sm transition-[color,box-shadow] outline-none", // Selection styles
        "selection:bg-primary-200 selection:text-dark-100", // Focus states with brand color
        "focus-visible:border-primary-200 focus-visible:ring-primary-200/50 focus-visible:ring-[3px]", // Disabled states with proper contrast
        isDisabled && "disabled:bg-gray-800/50 disabled:text-gray-500 disabled:placeholder-gray-500 disabled:cursor-not-allowed disabled:opacity-75", // Validation error states
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className),
        ref: ref,
        ...props
    });
});
Textarea.displayName = "Textarea";


// EXTERNAL MODULE: ./components/ui/BanterLoader.tsx
var BanterLoader = __webpack_require__(36371);
// EXTERNAL MODULE: ./node_modules/next/dist/api/image.js
var api_image = __webpack_require__(30474);
// EXTERNAL MODULE: ./firebase/client.ts
var client = __webpack_require__(82897);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(52581);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/loader-circle.js
var loader_circle = __webpack_require__(41862);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/mail.js
var mail = __webpack_require__(41550);
;// ./components/ProfileForm.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










function ProfileForm({ user }) {
    // Remove debug logging in production
    // console.log('ProfileForm user data:', user);
    // console.log('EmailVerified status:', user?.emailVerified);
    const [name, setName] = (0,react.useState)(user?.name || "");
    const [email] = (0,react.useState)(user?.email || "");
    const [password, setPassword] = (0,react.useState)("");
    const [about, setAbout] = (0,react.useState)(user?.about || "");
    const [phone, setPhone] = (0,react.useState)(user?.phone || "");
    const [workplace, setWorkplace] = (0,react.useState)(user?.workplace || "");
    const [skills, setSkills] = (0,react.useState)(user?.skills || []);
    const [skillInput, setSkillInput] = (0,react.useState)("");
    const [suggestions, setSuggestions] = (0,react.useState)([]);
    const [experience, setExperience] = (0,react.useState)(user?.experience || "");
    const [dateOfBirth, setDateOfBirth] = (0,react.useState)(user?.dateOfBirth || "");
    const defaultProfilePic = /*#__PURE__*/ (0,react_jsx_runtime.jsx)("svg", {
        className: "w-full h-full text-gray-800 dark:text-white",
        "aria-hidden": "true",
        xmlns: "http://www.w3.org/2000/svg",
        width: "24",
        height: "24",
        fill: "none",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
            d: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0 0a8.949 8.949 0 0 0 4.951-1.488A3.987 3.987 0 0 0 13 16h-2a3.987 3.987 0 0 0-3.951 3.512A8.948 8.948 0 0 0 12 21Zm3-11a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
        })
    });
    const [profilePic, setProfilePic] = (0,react.useState)(user?.image || null);
    const [profilePicFile, setProfilePicFile] = (0,react.useState)(null);
    const [loading, setLoading] = (0,react.useState)(false);
    const [resendingVerification, setResendingVerification] = (0,react.useState)(false);
    const fileInputRef = (0,react.useRef)(null);
    const handleProfilePicChange = async (e)=>{
        if (!e.target.files?.[0]) return;
        const file = e.target.files[0];
        setProfilePic(URL.createObjectURL(file));
        setProfilePicFile(file);
    };
    const handleResendVerification = async ()=>{
        if (!email || resendingVerification) return;
        setResendingVerification(true);
        try {
            const response = await fetch('/api/auth/resend-verification', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            const data = await response.json();
            if (response.ok) {
                dist/* toast */.o.success('Verification email sent!', {
                    description: 'Please check your inbox and click the verification link.',
                    duration: 5000
                });
            } else {
                dist/* toast */.o.error('Failed to send verification email', {
                    description: data.error || 'Please try again later.',
                    duration: 5000
                });
            }
        } catch (error) {
            console.error('Error sending verification email:', error);
            dist/* toast */.o.error('Failed to send verification email', {
                description: 'Please try again later.',
                duration: 5000
            });
        } finally{
            setResendingVerification(false);
        }
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        setLoading(true);
        // Get the current user's ID token with force refresh
        let idToken = '';
        try {
            const currentUser = client/* auth */.j2?.currentUser;
            if (!currentUser) {
                throw new Error("User not authenticated");
            }
            idToken = await currentUser.getIdToken(true); // Force token refresh
        } catch (error) {
            console.error('Error getting ID token:', error);
            dist/* toast */.o.error("Authentication Error", {
                description: error instanceof Error ? error.message : "Your session has expired. Please sign in again.",
                duration: 5000
            });
            // Redirect to the sign-in page after showing the error
            window.location.href = '/sign-in';
            return;
        }
        try {
            let profilePicUrl = profilePic;
            // If there's a new profile picture file selected
            if (profilePicFile) {
                // Create form data for file upload
                const formData = new FormData();
                formData.append('file', profilePicFile);
                // Upload the file to the server (Azure-centric via abstraction)
                const uploadRes = await fetch('/api/upload-profile-pic', {
                    method: 'POST',
                    headers: {
                        Authorization: `Bearer ${idToken}`
                    },
                    body: formData
                });
                if (!uploadRes.ok) {
                    const errorData = await uploadRes.json();
                    throw new Error(errorData.error || 'Failed to upload profile picture');
                }
                const { url } = await uploadRes.json();
                profilePicUrl = url;
            }
            // Update the profile with the new data
            const res = await fetch("/api/profile/update", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    name,
                    password: password || undefined,
                    profilePic: profilePicUrl,
                    about,
                    phone,
                    workplace,
                    skills,
                    experience,
                    dateOfBirth,
                    idToken
                })
            });
            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || "Failed to update profile");
            }
            // Show success toast
            dist/* toast */.o.success("Profile Updated", {
                description: "Your changes have been saved successfully.",
                duration: 3000,
                position: "top-center",
                style: {
                    background: 'hsl(var(--background))',
                    color: 'hsl(var(--foreground))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '0.5rem',
                    padding: '1rem'
                }
            });
            // If the password was changed, redirect to the sign-in page to get a fresh session
            if (password) {
                dist/* toast */.o.success("Password Updated", {
                    description: "Please sign in again with your new password.",
                    duration: 3000
                });
                // Sign out and redirect to the sign-in page
                await fetch('/api/auth/signout', {
                    method: 'POST'
                });
                window.location.href = '/sign-in';
            } else {
            // For non-password updates, the page will already show the updated data
            // No need to reload since the state is already updated
            }
        } catch (error) {
            console.error('Error updating profile:', error);
            dist/* toast */.o.error("Update Failed", {
                description: error instanceof Error ? error.message : 'An unexpected error occurred',
                duration: 5000,
                position: "top-center",
                style: {
                    background: 'hsl(var(--destructive))',
                    color: 'hsl(var(--destructive-foreground))',
                    border: '1px solid hsl(var(--destructive))',
                    borderRadius: '0.5rem',
                    padding: '1rem'
                }
            });
        } finally{
            setLoading(false);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("form", {
        onSubmit: handleSubmit,
        className: "w-full max-w-lg mx-auto space-y-6 p-8 bg-gray-900 border border-gray-700 rounded-2xl shadow-lg",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "flex flex-col items-center gap-4 mb-8",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "relative group",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                className: "rounded-full border-4 border-blue-500 w-32 h-32 flex items-center justify-center bg-gray-800",
                                children: profilePic ? /*#__PURE__*/ (0,react_jsx_runtime.jsx)(api_image["default"], {
                                    src: profilePic,
                                    alt: "Profile Picture",
                                    width: 120,
                                    height: 120,
                                    className: "rounded-full object-cover w-full h-full"
                                }) : /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                    className: "w-3/4 h-3/4 text-gray-400",
                                    children: defaultProfilePic
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                className: "absolute inset-0 flex items-center justify-center bg-black/60 rounded-full opacity-0 group-hover:opacity-100 transition-opacity",
                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(ui_button/* Button */.$, {
                                    type: "button",
                                    variant: "ghost",
                                    size: "icon",
                                    className: "text-white hover:bg-blue-500/20",
                                    onClick: ()=>fileInputRef.current?.click(),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "24",
                                            height: "24",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "w-6 h-6",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
                                                    d: "M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("line", {
                                                    x1: "16",
                                                    x2: "22",
                                                    y1: "5",
                                                    y2: "5"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("line", {
                                                    x1: "19",
                                                    x2: "19",
                                                    y1: "2",
                                                    y2: "8"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("circle", {
                                                    cx: "9",
                                                    cy: "9",
                                                    r: "2"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
                                                    d: "m21 15-3.1-3.1a2 2 0 0 0-2.814.014L6 21"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                            className: "sr-only",
                                            children: "Change profile picture"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("input", {
                        ref: fileInputRef,
                        type: "file",
                        accept: "image/*",
                        className: "hidden",
                        onChange: handleProfilePicChange
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "space-y-5",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "space-y-1.5 pb-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                htmlFor: "name",
                                className: "text-gray-200 font-medium",
                                children: "Name"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                id: "name",
                                value: name,
                                onChange: (e)=>setName(e.target.value),
                                className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus-visible:ring-blue-500 focus-visible:ring-offset-0 focus:border-blue-500"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "space-y-1.5 pb-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                htmlFor: "email",
                                className: "text-gray-200 font-medium",
                                children: "Email"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                id: "email",
                                value: email,
                                disabled: true,
                                className: "bg-gray-800/50 border-gray-600 text-gray-400 cursor-not-allowed"
                            }),
                            user?.emailVerified === false && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                className: "mt-2",
                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                                    type: "button",
                                    variant: "outline",
                                    size: "sm",
                                    onClick: handleResendVerification,
                                    disabled: resendingVerification,
                                    className: "text-blue-400 border-blue-400 hover:bg-blue-400/10 hover:text-blue-300 transition-colors",
                                    children: resendingVerification ? /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(loader_circle/* default */.A, {
                                                className: "w-4 h-4 mr-2 animate-spin"
                                            }),
                                            "Sending..."
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(mail/* default */.A, {
                                                className: "w-4 h-4 mr-2"
                                            }),
                                            "Resend verification link"
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "space-y-1.5 pb-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                htmlFor: "password",
                                className: "text-gray-200 font-medium",
                                children: "New Password (leave blank to keep current)"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                id: "password",
                                type: "password",
                                value: password,
                                onChange: (e)=>setPassword(e.target.value),
                                placeholder: "••••••••",
                                className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus-visible:ring-blue-500 focus-visible:ring-offset-0 focus:border-blue-500"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "space-y-1.5 pb-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                htmlFor: "about",
                                className: "text-gray-200 font-medium",
                                children: "About Me"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Textarea, {
                                id: "about",
                                value: about,
                                onChange: (e)=>setAbout(e.target.value),
                                placeholder: "Tell us about yourself...",
                                rows: 3,
                                className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus-visible:ring-blue-500 focus:border-blue-500 w-full"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-3 pb-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-1.5 pb-3",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        htmlFor: "phone",
                                        className: "text-gray-200 font-medium",
                                        children: "Phone Number"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                        id: "phone",
                                        type: "tel",
                                        value: phone,
                                        onChange: (e)=>setPhone(e.target.value),
                                        placeholder: "+1 (555) 123-4567",
                                        className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus-visible:ring-blue-500 focus-visible:ring-offset-0 focus:border-blue-500"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "space-y-1.5 pb-3",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                        htmlFor: "dateOfBirth",
                                        className: "text-gray-200 font-medium",
                                        children: "Date of Birth"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                                id: "dateOfBirth",
                                                type: "date",
                                                value: dateOfBirth,
                                                onChange: (e)=>setDateOfBirth(e.target.value),
                                                className: "appearance-none bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus-visible:ring-blue-500 focus-visible:ring-offset-0 focus:border-blue-500 pr-10 [&::-webkit-calendar-picker-indicator]:hidden"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                                                type: "button",
                                                onClick: ()=>document.getElementById('dateOfBirth')?.showPicker(),
                                                className: "absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors",
                                                "aria-label": "Open date picker",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "18",
                                                    height: "18",
                                                    viewBox: "0 0 24 24",
                                                    fill: "none",
                                                    stroke: "currentColor",
                                                    strokeWidth: "2",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("rect", {
                                                            x: "3",
                                                            y: "4",
                                                            width: "18",
                                                            height: "18",
                                                            rx: "2",
                                                            ry: "2"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("line", {
                                                            x1: "16",
                                                            y1: "2",
                                                            x2: "16",
                                                            y2: "6"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("line", {
                                                            x1: "8",
                                                            y1: "2",
                                                            x2: "8",
                                                            y2: "6"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("line", {
                                                            x1: "3",
                                                            y1: "10",
                                                            x2: "21",
                                                            y2: "10"
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "space-y-1.5 pb-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                htmlFor: "workplace",
                                className: "text-gray-200 font-medium",
                                children: "Current Workplace"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                id: "workplace",
                                type: "text",
                                value: workplace,
                                onChange: (e)=>setWorkplace(e.target.value),
                                placeholder: "Company Name",
                                className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus-visible:ring-blue-500 focus-visible:ring-offset-0 focus:border-blue-500"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "space-y-1.5 pb-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                htmlFor: "skills",
                                className: "text-gray-200 font-medium",
                                children: "Skills & Tools"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                        className: "flex flex-wrap gap-2 mb-2",
                                        children: skills.map((skill, index)=>/*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                                className: "flex items-center bg-blue-600 text-white px-3 py-1 rounded-full text-sm border border-blue-500",
                                                children: [
                                                    skill,
                                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                                                        type: "button",
                                                        onClick: ()=>setSkills(skills.filter((_, i)=>i !== index)),
                                                        className: "ml-2 text-blue-200 hover:text-white",
                                                        children: "\xd7"
                                                    })
                                                ]
                                            }, index))
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                                                id: "skills",
                                                type: "text",
                                                value: skillInput,
                                                onChange: (e)=>{
                                                    const value = e.target.value;
                                                    setSkillInput(value);
                                                    if (value) {
                                                        // Simple autocomplete suggestions
                                                        const techStack = [
                                                            'JavaScript',
                                                            'TypeScript',
                                                            'React',
                                                            'Node.js',
                                                            'Python',
                                                            'Java',
                                                            'C#',
                                                            'C++',
                                                            'Ruby',
                                                            'PHP',
                                                            'Go',
                                                            'Rust',
                                                            'Swift',
                                                            'Kotlin',
                                                            'Docker',
                                                            'Kubernetes',
                                                            'AWS',
                                                            'Azure',
                                                            'GCP',
                                                            'Git',
                                                            'HTML',
                                                            'CSS',
                                                            'SASS',
                                                            'Tailwind CSS',
                                                            'Bootstrap',
                                                            'jQuery',
                                                            'Angular',
                                                            'Vue.js',
                                                            'Next.js',
                                                            'Express',
                                                            'Django',
                                                            'Flask',
                                                            'Spring',
                                                            'Ruby on Rails',
                                                            'Laravel',
                                                            'ASP.NET',
                                                            'GraphQL',
                                                            'REST API',
                                                            'MongoDB',
                                                            'PostgreSQL',
                                                            'MySQL',
                                                            'SQL Server',
                                                            'SQLite',
                                                            'Firebase',
                                                            'Redis',
                                                            'Machine Learning',
                                                            'Data Science',
                                                            'Artificial Intelligence',
                                                            'Blockchain',
                                                            'Cybersecurity',
                                                            'DevOps',
                                                            'CI/CD',
                                                            'Agile',
                                                            'Scrum',
                                                            'Project Management'
                                                        ];
                                                        const filtered = techStack.filter((tech)=>tech.toLowerCase().includes(value.toLowerCase()));
                                                        setSuggestions(filtered);
                                                    } else {
                                                        setSuggestions([]);
                                                    }
                                                },
                                                onKeyDown: (e)=>{
                                                    if (e.key === 'Enter' && skillInput.trim() && !skills.includes(skillInput.trim())) {
                                                        e.preventDefault();
                                                        setSkills([
                                                            ...skills,
                                                            skillInput.trim()
                                                        ]);
                                                        setSkillInput('');
                                                        setSuggestions([]);
                                                    } else if (e.key === 'Backspace' && !skillInput && skills.length > 0) {
                                                        e.preventDefault();
                                                        setSkills(skills.slice(0, -1));
                                                    }
                                                },
                                                placeholder: "Add skills (e.g., JavaScript, Python, Project Management)",
                                                className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus-visible:ring-blue-500 focus-visible:ring-offset-0 focus:border-blue-500"
                                            }),
                                            suggestions.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                className: "absolute z-10 mt-1 w-full bg-gray-800 border border-gray-600 rounded-md shadow-lg max-h-60 overflow-auto",
                                                children: suggestions.map((suggestion, index)=>/*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                        className: "px-4 py-2 text-white hover:bg-gray-700 cursor-pointer",
                                                        onClick: ()=>{
                                                            if (!skills.includes(suggestion)) {
                                                                setSkills([
                                                                    ...skills,
                                                                    suggestion
                                                                ]);
                                                                setSkillInput('');
                                                                setSuggestions([]);
                                                            }
                                                        },
                                                        children: suggestion
                                                    }, index))
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                        className: "mt-1 text-xs text-gray-400",
                                        children: "Press Enter to add a skill"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "space-y-1.5 pb-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
                                htmlFor: "experience",
                                className: "text-gray-200 font-medium",
                                children: "Professional Experience"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Textarea, {
                                id: "experience",
                                value: experience,
                                onChange: (e)=>setExperience(e.target.value),
                                placeholder: "Describe your professional background and experience...",
                                rows: 4,
                                className: "bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus-visible:ring-blue-500 focus:border-blue-500 w-full"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "flex justify-center pt-4",
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                    type: "submit",
                    disabled: loading,
                    className: "bg-blue-600 hover:bg-blue-700 text-white border-blue-600 disabled:bg-gray-700 disabled:text-gray-400 w-full max-w-xs py-6 text-lg font-semibold transition-colors",
                    children: loading ? /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(BanterLoader/* default */.A, {
                                className: "mr-3 w-4 h-4"
                            }),
                            "Saving..."
                        ]
                    }) : 'Save Changes'
                })
            })
        ]
    });
}


/***/ }),

/***/ 60940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HW: () => (/* binding */ getCurrentUser),
/* harmony export */   wR: () => (/* binding */ isAuthenticated)
/* harmony export */ });
/* unused harmony exports signOut, signIn, verifyFirebaseToken */
/* harmony import */ var _lib_shared_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8703);
/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44999);
/**
 * Authentication Actions
 * 
 * Compatibility layer that bridges components with the unified auth system
 */ 

/**
 * Check if the current user is authenticated
 * @param token - Optional token to verify
 * @returns Promise<boolean>
 */ async function isAuthenticated(token) {
    try {
        const auth = (0,_lib_shared_auth__WEBPACK_IMPORTED_MODULE_0__/* .getUnifiedAuth */ .fd)();
        if (token) {
            const result = await (0,_lib_shared_auth__WEBPACK_IMPORTED_MODULE_0__/* .verifyToken */ .nr)(token);
            return result.valid;
        }
        // For server-side checks, read session cookie
        const cookieStore = await (0,next_headers__WEBPACK_IMPORTED_MODULE_1__/* .cookies */ .UL)();
        const sessionCookie = cookieStore.get('session');
        if (!sessionCookie?.value) {
            console.log('🔒 Server auth check: No session cookie found');
            return false;
        }
        const sessionValue = sessionCookie.value.trim();
        // Accept mock tokens for development
        if (sessionValue.startsWith('mock-token-')) {
            console.log('🔒 Server auth check: Found mock token');
            return true;
        }
        // For Firebase session cookies/tokens, validate structure
        if (sessionValue.includes('.')) {
            const parts = sessionValue.split('.');
            if (parts.length >= 3) {
                try {
                    // Try to decode the payload without verification (for performance)
                    const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
                    // Check if token is not obviously expired
                    const now = Math.floor(Date.now() / 1000);
                    if (payload.exp && payload.exp < now) {
                        console.log('🔒 Server auth check: Token expired');
                        return false;
                    }
                    console.log('🔒 Server auth check: Valid JWT structure found');
                    return true;
                } catch (decodeError) {
                    console.error('🔒 Server auth check: Failed to decode token payload:', decodeError);
                    return false;
                }
            }
        }
        // Fallback for non-JWT tokens
        const hasValidLength = sessionValue.length > 0;
        console.log('🔒 Server auth check: Non-JWT token validation:', hasValidLength);
        return hasValidLength;
    } catch (error) {
        console.error('🔒 Server auth check error:', error);
        return false;
    }
}
/**
 * Get the current authenticated user
 * @param token - Auth token
 * @returns Promise<AuthenticatedUser | null>
 */ async function getCurrentUser(token) {
    try {
        if (token) {
            const result = await (0,_lib_shared_auth__WEBPACK_IMPORTED_MODULE_0__/* .verifyToken */ .nr)(token);
            return result.valid ? result.user || null : null;
        }
        // For server-side, try to extract user from session cookie
        const cookieStore = await (0,next_headers__WEBPACK_IMPORTED_MODULE_1__/* .cookies */ .UL)();
        const sessionCookie = cookieStore.get('session');
        if (!sessionCookie?.value) {
            console.log('🔒 Server getCurrentUser: No session cookie found');
            return null;
        }
        const sessionValue = sessionCookie.value.trim();
        // Handle mock tokens for development
        if (sessionValue.startsWith('mock-token-')) {
            console.log('🔒 Server getCurrentUser: Using mock user');
            return {
                uid: 'mock-user',
                email: 'mock@example.com',
                email_verified: true
            };
        }
        // For Firebase session cookies/tokens, extract user from payload
        if (sessionValue.includes('.')) {
            const parts = sessionValue.split('.');
            if (parts.length >= 3) {
                try {
                    const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
                    // Check if token is expired
                    const now = Math.floor(Date.now() / 1000);
                    if (payload.exp && payload.exp < now) {
                        console.log('🔒 Server getCurrentUser: Token expired');
                        return null;
                    }
                    console.log('🔒 Server getCurrentUser: Extracted user from session cookie');
                    return {
                        uid: payload.uid || payload.sub || 'unknown',
                        email: payload.email || 'unknown@session.com',
                        email_verified: payload.email_verified || false,
                        name: payload.name || payload.display_name
                    };
                } catch (decodeError) {
                    console.error('🔒 Server getCurrentUser: Failed to decode session payload:', decodeError);
                    return null;
                }
            }
        }
        // Fallback for non-JWT tokens - return minimal user info
        if (sessionValue.length > 0) {
            console.log('🔒 Server getCurrentUser: Using fallback session user');
            return {
                uid: 'session-user',
                email: 'unknown@session.com',
                email_verified: false
            };
        }
        return null;
    } catch (error) {
        console.error('🔒 Server getCurrentUser error:', error);
        return null;
    }
}
/**
 * Sign out the current user (client-side)
 * This is a compatibility function - actual sign out happens on client
 */ async function signOut() {
    // In a real implementation, this would handle server-side logout
    // For now, this is a placeholder for client-side logout
    if (false) {}
}
/**
 * Sign in with credentials (server-side validation)
 * @param token - Firebase ID token
 * @returns Promise<AuthResult>
 */ async function signIn(token) {
    try {
        const result = await verifyToken(token);
        return {
            success: result.valid,
            user: result.user || null,
            error: result.error
        };
    } catch (error) {
        return {
            success: false,
            user: null,
            error: error instanceof Error ? error.message : 'Authentication failed'
        };
    }
}
/**
 * Verify Firebase token (legacy compatibility)
 * @param token - Firebase ID token
 * @returns Promise<AuthResult>
 */ async function verifyFirebaseToken(token) {
    return signIn(token);
}


/***/ }),

/***/ 63033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 68988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);



function Input({ className, type, ...props }) {
    const isDisabled = props.disabled;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
        type: type,
        "data-slot": "input",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(// Base styles for dark theme
        "bg-gray-800 text-white placeholder-gray-400 border-gray-600", "flex h-9 w-full min-w-0 rounded-md border px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none", "md:text-sm", // File input specific styles
        "file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-white", // Selection styles
        "selection:bg-primary-200 selection:text-dark-100", // Focus states with brand color (primary-200 from globals.css)
        "focus-visible:border-primary-200 focus-visible:ring-primary-200/50 focus-visible:ring-[3px]", // Disabled states with proper contrast
        isDisabled && "disabled:bg-gray-800/50 disabled:text-gray-500 disabled:placeholder-gray-500 disabled:cursor-not-allowed disabled:opacity-75", // Validation error states
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className),
        ...props
    });
}



/***/ }),

/***/ 72511:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProfilePage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37413);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ProfileForm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(37152);
/* harmony import */ var _lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60940);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(39916);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4536);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_LogoutButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(48051);
// export const dynamic = 'force-dynamic'; // Commented out for static export






async function ProfilePage() {
    const user = await (0,_lib_actions_auth_action__WEBPACK_IMPORTED_MODULE_2__/* .getCurrentUser */ .HW)();
    if (!user) (0,next_navigation__WEBPACK_IMPORTED_MODULE_3__.redirect)('/sign-in');
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "fixed left-0 top-0 p-4 z-10",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: "/",
                    className: "text-primary-100 font-semibold text-2xl hover:bg-primary-100/10 dark:hover:bg-white/10 p-2 rounded-full transition-colors inline-flex items-center justify-center w-10 h-10",
                    "aria-label": "Back to Home",
                    children: "←"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "fixed right-0 top-0 p-4 z-10",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_LogoutButton__WEBPACK_IMPORTED_MODULE_5__["default"], {})
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "max-w-4xl mx-auto py-10 px-4 relative min-h-screen",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "text-center mb-8",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
                            className: "text-3xl font-bold text-foreground",
                            children: "My Profile"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_ProfileForm__WEBPACK_IMPORTED_MODULE_1__["default"], {
                        user: user
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 73496:
/***/ ((module) => {

"use strict";
module.exports = require("http2");

/***/ }),

/***/ 74075:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 78148:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   b: () => (/* binding */ Root)
/* harmony export */ });
/* unused harmony export Label */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(43210);
/* harmony import */ var _radix_ui_react_primitive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14163);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(60687);
/* __next_internal_client_entry_do_not_use__ Label,Root auto */ // src/label.tsx



var NAME = "Label";
var Label = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0__.forwardRef((props, forwardedRef)=>{
    return /* @__PURE__ */ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_radix_ui_react_primitive__WEBPACK_IMPORTED_MODULE_2__/* .Primitive */ .sG.label, {
        ...props,
        ref: forwardedRef,
        onMouseDown: (event)=>{
            const target = event.target;
            if (target.closest("button, input, select, textarea")) return;
            props.onMouseDown?.(event);
            if (!event.defaultPrevented && event.detail > 1) event.preventDefault();
        }
    });
});
Label.displayName = NAME;
var Root = Label;
 //# sourceMappingURL=index.mjs.map


/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 79551:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 81630:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 82897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   db: () => (/* binding */ db),
/* harmony export */   hJ: () => (/* binding */ googleProvider),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(67989);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91042);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75535);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  false ? 0 : null;
    const windowProjectId =  false ? 0 : null;
    const windowAuthDomain =  false ? 0 : null;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || `${finalProjectId}.firebaseapp.com`;
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (true) {
        console.log('🔥 Firebase initialization skipped on server side');
        return;
    }
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = getApps();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = initializeApp(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = getAuth(app);
        db = getFirestore(app);
        // Initialize Google Auth Provider
        googleProvider = new GoogleAuthProvider();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (false) {}
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (false) {}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});


/***/ }),

/***/ 89002:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6797));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 56949));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 85814, 23));


/***/ }),

/***/ 91645:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 94735:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 96487:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [80,8134,1658,5814,474,4999,1012,8062,9757,8703], () => (__webpack_exec__(16519)));
module.exports = __webpack_exports__;

})();