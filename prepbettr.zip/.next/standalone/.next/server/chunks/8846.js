"use strict";
exports.id = 8846;
exports.ids = [8846];
exports.modules = {

/***/ 4514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   lL: () => (/* binding */ fetchAzureSecrets)
/* harmony export */ });
/* unused harmony exports getAzureConfig, isBrowser, clearCache */
// Browser-compatible Azure configuration
// This file only uses environment variables and doesn't import server-only Azure Identity libraries
let cachedSecrets = null;
/**
 * Fetch Azure secrets from environment variables (browser-safe version)
 * This function only uses NEXT_PUBLIC_ environment variables available in the browser
 */ async function fetchAzureSecrets() {
    // Return cached secrets if available
    if (cachedSecrets) {
        return cachedSecrets;
    }
    try {
        console.log('🔑 Loading Azure configuration from environment variables...');
        const secrets = {
            speechKey: process.env.NEXT_PUBLIC_SPEECH_KEY || '',
            speechEndpoint: process.env.NEXT_PUBLIC_SPEECH_ENDPOINT || '',
            azureOpenAIKey: process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY || '',
            azureOpenAIEndpoint: process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT || '',
            azureOpenAIDeployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT || 'gpt-4o',
            azureOpenAIGpt35Deployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            azureOpenAIGpt4oDeployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o',
            azureAppConfigConnectionString: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            azureAppConfigEndpoint: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        };
        // Validate that required secrets are available
        if (!secrets.speechKey || !secrets.speechEndpoint) {
            console.warn('⚠️ Azure Speech credentials not available in browser environment');
        }
        if (!secrets.azureOpenAIKey || !secrets.azureOpenAIEndpoint) {
            console.warn('⚠️ Azure OpenAI credentials not available in browser environment');
        }
        if (!secrets.azureAppConfigConnectionString && !secrets.azureAppConfigEndpoint) {
            console.warn('⚠️ Azure App Configuration credentials not available in browser environment');
        }
        cachedSecrets = secrets;
        console.log('✅ Azure configuration loaded from environment variables');
        return cachedSecrets;
    } catch (error) {
        console.error('❌ Failed to load Azure configuration:', error);
        // Return empty secrets as fallback
        const fallbackSecrets = {
            speechKey: '',
            speechEndpoint: '',
            azureOpenAIKey: '',
            azureOpenAIEndpoint: '',
            azureOpenAIDeployment: 'gpt-4o',
            azureOpenAIGpt35Deployment: 'gpt-4o',
            azureOpenAIGpt4oDeployment: 'gpt-4o',
            azureAppConfigConnectionString: undefined,
            azureAppConfigEndpoint: undefined
        };
        cachedSecrets = fallbackSecrets;
        return cachedSecrets;
    }
}
/**
 * Get current Azure configuration (for debugging)
 */ function getAzureConfig() {
    return {
        environment: 'browser',
        hasSecretsCache: !!cachedSecrets,
        configuration: {
            speechKey: !!process.env.NEXT_PUBLIC_SPEECH_KEY,
            speechEndpoint: !!process.env.NEXT_PUBLIC_SPEECH_ENDPOINT,
            azureOpenAIKey: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY,
            azureOpenAIEndpoint: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT,
            azureOpenAIDeployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT,
            azureOpenAIGpt35Deployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT,
            azureOpenAIGpt4oDeployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT,
            azureAppConfigConnectionString: !!process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            azureAppConfigEndpoint: !!process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        },
        deployments: {
            default: process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT,
            gpt35Turbo: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            gpt4o: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o'
        },
        appConfiguration: {
            connectionString: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            endpoint: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        }
    };
}
/**
 * Check if we're running in a browser environment
 */ function isBrowser() {
    return "undefined" !== 'undefined';
}
/**
 * Clear cached secrets (useful for testing or re-initialization)
 */ function clearCache() {
    cachedSecrets = null;
    console.log('🧹 Azure configuration cache cleared');
}


/***/ }),

/***/ 18846:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   generateQuestions: () => (/* binding */ generateQuestions),
/* harmony export */   tailorResume: () => (/* binding */ tailorResume)
/* harmony export */ });
/* unused harmony exports generateCoverLetter, calculateRelevancy, getProviderInfo, switchProvider, dispose */
/* harmony import */ var _azureOpenAI__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50169);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azureOpenAI__WEBPACK_IMPORTED_MODULE_0__]);
_azureOpenAI__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Azure-Centric AI Service Layer
 * 
 * This module provides a unified interface for AI operations backed
 * by Azure OpenAI services. Optimized for enterprise-grade AI functionality.
 */ 
/**
 * AI Service Manager - Azure OpenAI focused service manager
 */ class AIServiceManager {
    constructor(){
        this.currentProvider = null;
        this.providers = new Map();
        this.initialized = false;
        // Register Azure OpenAI as the primary provider
        this.providers.set('azure-openai', new _azureOpenAI__WEBPACK_IMPORTED_MODULE_0__/* .AzureOpenAIAdapter */ .x());
    }
    /**
   * Initialize the AI service with Azure OpenAI
   */ async initialize() {
        const providerName = 'azure-openai';
        console.log(`🚀 Initializing AI Service with provider: ${providerName}`);
        const provider = this.providers.get(providerName);
        if (!provider) {
            console.error(`❌ Azure OpenAI provider not found`);
            return false;
        }
        try {
            const success = await provider.initialize();
            if (success) {
                this.currentProvider = provider;
                this.initialized = true;
                console.log(`✅ AI Service initialized successfully with ${provider.name}`);
                return true;
            }
        } catch (error) {
            console.error(`❌ Failed to initialize Azure OpenAI provider:`, error);
        }
        console.error('❌ Azure OpenAI provider failed to initialize');
        return false;
    }
    /**
   * Get the current provider
   */ getCurrentProvider() {
        return this.currentProvider;
    }
    /**
   * Check if the service is ready
   */ isReady() {
        return this.initialized && this.currentProvider?.isReady() === true;
    }
    /**
   * Get current provider name
   */ getProviderName() {
        return this.currentProvider?.name || 'none';
    }
    /**
   * Switch to a different provider at runtime
   */ async switchProvider(providerName) {
        console.log(`🔄 Switching to provider: ${providerName}`);
        const provider = this.providers.get(providerName);
        if (!provider) {
            console.error(`❌ Provider '${providerName}' not found`);
            return false;
        }
        // Clean up current provider
        if (this.currentProvider) {
            this.currentProvider.dispose();
        }
        try {
            const success = await provider.initialize();
            if (success) {
                this.currentProvider = provider;
                console.log(`✅ Successfully switched to ${provider.name}`);
                return true;
            }
        } catch (error) {
            console.error(`❌ Failed to switch to provider '${providerName}':`, error);
        }
        return false;
    }
    /**
   * Dispose of all resources
   */ dispose() {
        if (this.currentProvider) {
            this.currentProvider.dispose();
        }
        this.currentProvider = null;
        this.initialized = false;
        console.log('🧹 AI Service Manager disposed');
    }
}
// Singleton instance
const aiServiceManager = new AIServiceManager();
/**
 * Ensure the AI service is initialized
 */ async function ensureInitialized() {
    if (!aiServiceManager.isReady()) {
        const success = await aiServiceManager.initialize();
        if (!success) {
            throw new Error('Failed to initialize AI service - no providers available');
        }
    }
}
/**
 * Generate a cover letter based on resume and job description
 */ async function generateCoverLetter(resumeText, jobDescription) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const coverLetter = await provider.generateCoverLetter(resumeText, jobDescription);
        return {
            success: true,
            data: coverLetter,
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error generating cover letter:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Calculate relevancy score between resume and job description (0-100)
 */ async function calculateRelevancy(resumeText, jobDescription) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const score = await provider.calculateRelevancy(resumeText, jobDescription);
        return {
            success: true,
            data: Math.max(0, Math.min(100, score)),
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error calculating relevancy:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Tailor resume to match job description
 */ async function tailorResume(resumeText, jobDescription) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const tailoredResume = await provider.tailorResume(resumeText, jobDescription);
        return {
            success: true,
            data: tailoredResume,
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error tailoring resume:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Generate interview questions based on resume information
 */ async function generateQuestions(resumeInfo) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const questions = await provider.generateQuestions(resumeInfo);
        return {
            success: true,
            data: questions,
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error generating questions:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Get current AI provider information
 */ function getProviderInfo() {
    return {
        name: aiServiceManager.getProviderName(),
        isReady: aiServiceManager.isReady()
    };
}
/**
 * Switch AI provider at runtime (for testing or hot-swapping)
 */ async function switchProvider(providerName) {
    try {
        const success = await aiServiceManager.switchProvider(providerName);
        return {
            success,
            data: success,
            provider: aiServiceManager.getProviderName()
        };
    } catch (error) {
        console.error('❌ Error switching provider:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Dispose of AI service resources
 */ function dispose() {
    aiServiceManager.dispose();
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 22531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   y: () => (/* binding */ retryWithExponentialBackoff)
/* harmony export */ });
/* unused harmony export RetryWithBackoff */
/* harmony import */ var _microsoft_applicationinsights_web__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61031);
/* harmony import */ var _microsoft_applicationinsights_web__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_applicationinsights_web__WEBPACK_IMPORTED_MODULE_0__);

class RetryWithBackoff {
    static initialize(instrumentationKey) {
        if (instrumentationKey && "undefined" !== 'undefined') {}
    }
    /**
   * Execute a function with exponential backoff retry logic
   */ static async execute(fn, options = {}) {
        const { maxRetries = 3, baseDelay = 1000, maxDelay = 30000, jitter = true, retryCondition = this.defaultRetryCondition, onRetry, userId, action = 'unknown' } = options;
        const startTime = Date.now();
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                const result = await fn();
                // Log success metrics
                if (attempt > 0) {
                    this.logRetrySuccess({
                        attempt: attempt + 1,
                        totalAttempts: attempt + 1,
                        delay: 0,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                }
                return result;
            } catch (error) {
                lastError = error;
                // Check if we should retry
                if (attempt === maxRetries || !retryCondition(error)) {
                    // Log final failure
                    this.logRetryFailure({
                        attempt: attempt + 1,
                        totalAttempts: maxRetries + 1,
                        delay: 0,
                        error,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                    throw error;
                }
                // Calculate delay for next attempt
                const exponentialDelay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
                const delay = jitter ? exponentialDelay + Math.random() * exponentialDelay * 0.1 // Add 10% jitter
                 : exponentialDelay;
                // Log retry attempt
                this.logRetryAttempt({
                    attempt: attempt + 1,
                    totalAttempts: maxRetries + 1,
                    delay,
                    error,
                    userId,
                    action,
                    startTime
                });
                // Execute retry callback if provided
                if (onRetry) {
                    onRetry(error, attempt + 1);
                }
                // Wait before next attempt
                await this.sleep(delay);
            }
        }
        throw lastError;
    }
    /**
   * Default retry condition - retry on network errors, rate limits, and server errors
   */ static defaultRetryCondition(error) {
        // Network errors
        if (error.code === 'ECONNRESET' || error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
            return true;
        }
        // HTTP status codes that should be retried
        if (error.response?.status) {
            const status = error.response.status;
            return status === 429 || // Rate limit
            status === 502 || // Bad Gateway
            status === 503 || // Service Unavailable
            status === 504; // Gateway Timeout
        }
        // Azure OpenAI specific errors
        if (error.message?.includes('rate limit') || error.message?.includes('throttled') || error.message?.includes('quota exceeded')) {
            return true;
        }
        return false;
    }
    /**
   * Sleep for specified milliseconds
   */ static sleep(ms) {
        return new Promise((resolve)=>setTimeout(resolve, ms));
    }
    /**
   * Log retry attempt
   */ static logRetryAttempt(metrics) {
        const logData = {
            level: 'warn',
            message: `Retry attempt ${metrics.attempt}/${metrics.totalAttempts} for ${metrics.action}`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                delay: metrics.delay,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name
                },
                timestamp: new Date().toISOString()
            }
        };
        console.warn('RETRY_ATTEMPT', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 2,
                properties: logData.properties
            });
        }
    }
    /**
   * Log retry success
   */ static logRetrySuccess(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'info',
            message: `Retry succeeded for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                timestamp: new Date().toISOString()
            }
        };
        console.log('RETRY_SUCCESS', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 1,
                properties: logData.properties
            });
            // Track custom metric for retry success
            this.appInsights.trackMetric({
                name: 'RetrySuccess',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
    /**
   * Log retry failure
   */ static logRetryFailure(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'error',
            message: `Retry failed for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name,
                    stack: metrics.error?.stack
                },
                timestamp: new Date().toISOString()
            }
        };
        console.error('RETRY_FAILURE', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackException({
                exception: metrics.error,
                properties: logData.properties,
                severityLevel: 3 // Error
            });
            // Track custom metric for retry failure
            this.appInsights.trackMetric({
                name: 'RetryFailure',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
}
/**
 * Convenience function for common retry scenarios
 */ async function retryWithExponentialBackoff(fn, action, userId, options) {
    return RetryWithBackoff.execute(fn, {
        action,
        userId,
        ...options
    });
}


/***/ }),

/***/ 50169:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   x: () => (/* binding */ AzureOpenAIAdapter)
/* harmony export */ });
/* harmony import */ var _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89134);
/* harmony import */ var _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(94279);
/* harmony import */ var _lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(22531);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__]);
([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure OpenAI Provider Adapter
 * 
 * This adapter wraps Azure OpenAI API to provide a consistent interface
 * for the AI service layer. Reuses the existing AzureOpenAIService for
 * consistent configuration and error handling.
 */ 


class AzureOpenAIAdapter {
    /**
   * Initialize the Azure OpenAI service
   */ async initialize() {
        try {
            // Try enhanced service first, fallback to standard service
            if (this.useEnhancedService) {
                this.isInitialized = await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.initialize();
                if (this.isInitialized) {
                    console.log('✅ Azure OpenAI adapter initialized with enhanced service');
                    return true;
                }
                console.warn('⚠️ Enhanced service failed, falling back to standard service');
                this.useEnhancedService = false;
            }
            // Fallback to standard service
            this.isInitialized = await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.initialize();
            if (this.isInitialized) {
                console.log('✅ Azure OpenAI adapter initialized with standard service');
            } else {
                console.warn('⚠️ Azure OpenAI adapter failed to initialize');
            }
            return this.isInitialized;
        } catch (error) {
            console.error('❌ Failed to initialize Azure OpenAI adapter:', error);
            return false;
        }
    }
    /**
   * Check if the adapter is ready
   */ isReady() {
        if (this.useEnhancedService) {
            return this.isInitialized && _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.isReady();
        }
        return this.isInitialized && _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.isReady();
    }
    /**
   * Generate a cover letter using Azure OpenAI with retry logic
   */ async generateCoverLetter(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service if available for optimal model selection
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateCoverLetter(resumeText, jobDescription);
            }
            // Fallback to custom implementation
            return await this.generateWithAzureOpenAI(this.getCoverLetterPrompt(resumeText, jobDescription));
        }, 'generate_cover_letter', userId, {
            maxRetries: 3,
            baseDelay: 2000,
            maxDelay: 60000 // 1 minute max delay
        });
    }
    /**
   * Calculate relevancy score between resume and job description with retry logic
   */ async calculateRelevancy(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service for efficient gpt-35-turbo scoring
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.calculateRelevancy(resumeText, jobDescription);
            }
            // Fallback implementation
            const prompt = this.getRelevancyPrompt(resumeText, jobDescription);
            const response = await this.generateWithAzureOpenAI(prompt, this.RELEVANCY_TEMPERATURE, this.RELEVANCY_MAX_TOKENS);
            // Extract number from response
            const scoreMatch = response.trim().match(/\d+/);
            if (!scoreMatch) {
                throw new Error('Could not extract relevancy score from response');
            }
            const score = parseInt(scoreMatch[0], 10);
            return Math.max(0, Math.min(100, score)); // Ensure score is between 0-100
        }, 'calculate_relevancy', userId, {
            maxRetries: 2,
            baseDelay: 1000,
            maxDelay: 30000
        });
    }
    /**
   * Tailor resume to match job description with retry logic
   */ async tailorResume(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service for optimal gpt-4o quality
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.tailorResume(resumeText, jobDescription);
            }
            // Fallback to standard service
            return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.tailorResume(resumeText, jobDescription);
        }, 'tailor_resume', userId, {
            maxRetries: 3,
            baseDelay: 3000,
            maxDelay: 90000 // 1.5 minutes max delay
        });
    }
    /**
   * Generate interview questions based on resume information with retry logic
   */ async generateQuestions(resumeInfo, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service for efficient gpt-35-turbo question generation
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateQuestions(resumeInfo);
            }
            // Fallback to standard service
            return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.generateQuestions(resumeInfo);
        }, 'generate_questions', userId, {
            maxRetries: 2,
            baseDelay: 1500,
            maxDelay: 45000
        });
    }
    /**
   * Generate content using Azure OpenAI with retry logic
   * Uses optimized parameters for consistent high-quality responses
   */ async generateWithAzureOpenAI(prompt, temperature = this.DEFAULT_TEMPERATURE, maxTokens = this.DEFAULT_MAX_TOKENS) {
        const messages = [
            {
                role: 'user',
                content: prompt
            }
        ];
        try {
            const completion = await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.createCompletion(messages, {
                temperature,
                maxTokens,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1 // Encourage diverse content
            });
            const content = completion.choices[0]?.message?.content;
            if (!content) {
                throw new Error('Empty response from Azure OpenAI');
            }
            return content;
        } catch (error) {
            console.error('❌ Error generating content with Azure OpenAI:', error);
            throw error;
        }
    }
    /**
   * Get cover letter generation prompt with optimized structure
   */ getCoverLetterPrompt(resumeText, jobDescription) {
        return `You are an expert career coach and professional writer. Please generate a compelling cover letter based on the provided resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Please generate a cover letter that:
1. Is tailored to the specific job description
2. Highlights the most relevant skills and experiences from the resume
3. Has a professional and engaging tone
4. Is well-structured and easy to read
5. Is approximately 3-4 paragraphs long

Return ONLY the cover letter content with no additional commentary or explanations.`;
    }
    /**
   * Get relevancy analysis prompt with structured requirements
   */ getRelevancyPrompt(resumeText, jobDescription) {
        return `You are an expert ATS (Applicant Tracking System) analyzer. Please analyze the relevancy between this resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Analyze the match between the resume and job description considering:
1. Skills alignment (technical and soft skills)
2. Experience relevance (years and type of experience)
3. Education and certifications match
4. Industry experience
5. Role responsibilities alignment
6. Keywords and terminology match

Return ONLY a single number between 0 and 100 representing the percentage match/relevancy score. No explanations or additional text.`;
    }
    /**
   * Dispose of resources
   */ dispose() {
        // The underlying service manages its own resources
        this.isInitialized = false;
        this.useEnhancedService = true; // Reset for next initialization
        console.log('🧹 Azure OpenAI adapter disposed');
    }
    constructor(){
        this.name = 'Azure OpenAI (Enhanced)';
        this.isInitialized = false;
        this.useEnhancedService = true // Feature flag for enhanced multi-deployment service
        ;
        // Default parameters for optimal Azure OpenAI performance
        this.DEFAULT_TEMPERATURE = 0.7 // Balanced creativity
        ;
        this.DEFAULT_MAX_TOKENS = 1500 // Comprehensive responses
        ;
        this.RELEVANCY_TEMPERATURE = 0.1 // For precise scoring
        ;
        this.RELEVANCY_MAX_TOKENS = 50 // Short numeric response
        ;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 94279:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   h: () => (/* binding */ enhancedAzureOpenAIService)
/* harmony export */ });
/* unused harmony export EnhancedAzureOpenAIService */
/* harmony import */ var _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95951);
/* harmony import */ var _lib_azure_config_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4514);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__]);
_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Enhanced Azure OpenAI Service with Multi-Deployment Support
 * 
 * This service provides intelligent model selection based on task type:
 * - gpt-35-turbo: Fast, cost-effective for simple tasks (relevancy scoring, basic Q&A)
 * - gpt-4o: Advanced reasoning for complex tasks (cover letters, resume tailoring)
 */ 

class EnhancedAzureOpenAIService {
    /**
   * Initialize the service with multiple deployment clients
   */ async initialize() {
        try {
            this.secrets = await (0,_lib_azure_config_browser__WEBPACK_IMPORTED_MODULE_1__/* .fetchAzureSecrets */ .lL)();
            if (!this.secrets.azureOpenAIKey || !this.secrets.azureOpenAIEndpoint) {
                console.warn('⚠️ Azure OpenAI credentials not available');
                return false;
            }
            // Initialize clients for different deployments
            const deployments = [
                {
                    name: 'gpt-4o',
                    deployment: this.secrets.azureOpenAIGpt35Deployment || 'gpt-4o'
                },
                {
                    name: 'gpt-4o',
                    deployment: this.secrets.azureOpenAIGpt4oDeployment || 'gpt-4o'
                },
                {
                    name: 'default',
                    deployment: this.secrets.azureOpenAIDeployment
                }
            ];
            for (const { name, deployment } of deployments){
                if (deployment) {
                    const client = new _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__/* .MigrationOpenAIClient */ .Ag();
                    await client.init(); // Initialize the migration client
                    this.clients.set(name, client);
                    console.log(`✅ Azure OpenAI client initialized for ${name} (${deployment})`);
                }
            }
            this.isInitialized = this.clients.size > 0;
            if (this.isInitialized) {
                console.log(`✅ Enhanced Azure OpenAI Service initialized with ${this.clients.size} clients`);
            }
            return this.isInitialized;
        } catch (error) {
            console.error('❌ Failed to initialize Enhanced Azure OpenAI Service:', error);
            return false;
        }
    }
    /**
   * Generate content using the optimal model for the task
   */ async generateContent(prompt, taskType, customOptions) {
        if (!this.isInitialized) {
            throw new Error('Enhanced Azure OpenAI Service not initialized');
        }
        const config = {
            ...this.taskConfigurations[taskType],
            ...customOptions
        };
        const client = this.clients.get(config.deployment) || this.clients.get('default');
        if (!client) {
            throw new Error(`No client available for deployment: ${config.deployment}`);
        }
        console.log(`🎯 Using ${config.deployment} for ${taskType} task`);
        const messages = [
            {
                role: 'user',
                content: prompt
            }
        ];
        try {
            const completion = await this.retryWithBackoff(async ()=>{
                return await client.chat.completions.create({
                    model: config.deployment,
                    messages,
                    temperature: config.temperature,
                    max_tokens: config.maxTokens,
                    top_p: config.topP || 0.9,
                    frequency_penalty: config.frequencyPenalty || 0.1,
                    presence_penalty: config.presencePenalty || 0.1
                });
            });
            const content = completion.choices[0]?.message?.content;
            if (!content) {
                throw new Error(`Empty response from Azure OpenAI (${config.deployment})`);
            }
            return content;
        } catch (error) {
            console.error(`❌ Error generating content with ${config.deployment}:`, error);
            throw error;
        }
    }
    /**
   * Generate cover letter using gpt-4o for high quality
   */ async generateCoverLetter(resumeText, jobDescription) {
        const prompt = `You are an expert career coach and professional writer. Please generate a compelling cover letter based on the provided resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Please generate a cover letter that:
1. Is tailored to the specific job description
2. Highlights the most relevant skills and experiences from the resume
3. Has a professional and engaging tone
4. Is well-structured and easy to read
5. Is approximately 3-4 paragraphs long

Return ONLY the cover letter content with no additional commentary or explanations.`;
        return await this.generateContent(prompt, 'cover-letter');
    }
    /**
   * Calculate relevancy score using gpt-35-turbo for efficiency
   */ async calculateRelevancy(resumeText, jobDescription) {
        const prompt = `You are an expert ATS (Applicant Tracking System) analyzer. Please analyze the relevancy between this resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Analyze the match between the resume and job description considering:
1. Skills alignment (technical and soft skills)
2. Experience relevance (years and type of experience)
3. Education and certifications match
4. Industry experience
5. Role responsibilities alignment
6. Keywords and terminology match

Return ONLY a single number between 0 and 100 representing the percentage match/relevancy score. No explanations or additional text.`;
        const response = await this.generateContent(prompt, 'relevancy');
        // Extract number from response
        const scoreMatch = response.trim().match(/\d+/);
        if (!scoreMatch) {
            throw new Error('Could not extract relevancy score from response');
        }
        const score = parseInt(scoreMatch[0], 10);
        return Math.max(0, Math.min(100, score)); // Ensure score is between 0-100
    }
    /**
   * Tailor resume using gpt-4o for quality
   */ async tailorResume(resumeText, jobDescription) {
        const prompt = `You are an expert resume writer and ATS optimization specialist. Please tailor this resume to better match the following job description for maximum ATS compatibility and relevance.

JOB DESCRIPTION:
${jobDescription}

CURRENT RESUME:
${resumeText}

Please provide a tailored version of the resume that:
1. Uses keywords and phrases directly from the job description
2. Highlights relevant skills and experiences that match the job requirements
3. Maintains professional formatting and ATS-friendly structure
4. Uses strong action verbs and quantifiable achievements
5. Keeps the same overall length and format structure
6. Optimizes for Applicant Tracking Systems (ATS)
7. Ensures keyword density without keyword stuffing

Return ONLY the tailored resume content with no additional commentary or explanations.`;
        return await this.generateContent(prompt, 'resume-tailor');
    }
    /**
   * Generate interview questions using gpt-35-turbo for efficiency
   */ async generateQuestions(resumeInfo) {
        const prompt = `You are an experienced interviewer. Based on the following resume information, generate 5 relevant interview questions that would help assess this candidate's qualifications and fit for their field.

RESUME INFORMATION:
Name: ${resumeInfo.name}
Experience: ${resumeInfo.experience}
Education: ${resumeInfo.education}
Skills: ${resumeInfo.skills}

Generate questions that:
1. Are specific to their experience level and field
2. Assess both technical and behavioral competencies
3. Are professional and engaging
4. Would help determine cultural fit
5. Allow the candidate to showcase their strengths

Format: Return exactly 5 questions, each on a new line, numbered 1-5. No additional text or explanations.`;
        const response = await this.generateContent(prompt, 'questions');
        // Parse questions from response
        const questions = response.split('\n').map((line)=>line.trim()).filter((line)=>line.length > 0).map((line)=>line.replace(/^\d+\.\s*/, '')) // Remove numbering
        .filter((line)=>line.length > 0).slice(0, 5); // Ensure max 5 questions
        if (questions.length === 0) {
            throw new Error('No questions could be parsed from response');
        }
        return questions;
    }
    /**
   * Retry mechanism with exponential backoff for rate limiting
   */ async retryWithBackoff(operation, maxRetries = 3, baseDelay = 1000) {
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                return await operation();
            } catch (error) {
                lastError = error;
                // Don't retry on non-retryable errors
                if (error.status && ![
                    429,
                    500,
                    502,
                    503,
                    504
                ].includes(error.status)) {
                    throw error;
                }
                if (attempt === maxRetries) {
                    throw error;
                }
                // Calculate delay with exponential backoff
                const delay = error.status === 429 ? parseInt(error.headers?.['retry-after'] || '10') * 1000 : baseDelay * Math.pow(2, attempt);
                console.log(`⏳ Retrying in ${delay}ms (attempt ${attempt + 1}/${maxRetries + 1})`);
                await new Promise((resolve)=>setTimeout(resolve, delay));
            }
        }
        throw lastError;
    }
    /**
   * Check if service is ready
   */ isReady() {
        return this.isInitialized && this.clients.size > 0;
    }
    /**
   * Get available deployments
   */ getAvailableDeployments() {
        return Array.from(this.clients.keys());
    }
    /**
   * Dispose of resources
   */ dispose() {
        this.clients.clear();
        this.isInitialized = false;
        console.log('🧹 Enhanced Azure OpenAI Service disposed');
    }
    constructor(){
        this.clients = new Map();
        this.isInitialized = false;
        this.secrets = null;
        // Task-specific configurations optimized for different models
        this.taskConfigurations = {
            // Fast tasks - use gpt-35-turbo for efficiency
            'relevancy': {
                deployment: 'gpt-4o',
                temperature: 0.1,
                maxTokens: 50,
                topP: 0.9,
                frequencyPenalty: 0.0,
                presencePenalty: 0.0
            },
            'questions': {
                deployment: 'gpt-4o',
                temperature: 0.5,
                maxTokens: 300,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            // Complex tasks - use gpt-4o for quality
            'cover-letter': {
                deployment: 'gpt-4o',
                temperature: 0.7,
                maxTokens: 1500,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            'resume-tailor': {
                deployment: 'gpt-4o',
                temperature: 0.3,
                maxTokens: 2000,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            // Interview tasks - use gpt-4o for nuanced conversation
            'interview': {
                deployment: 'gpt-4o',
                temperature: 0.7,
                maxTokens: 200,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            }
        };
    }
}
// Export singleton instance
const enhancedAzureOpenAIService = new EnhancedAzureOpenAIService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;