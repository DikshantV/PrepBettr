"use strict";
exports.id = 8846;
exports.ids = [8846];
exports.modules = {

/***/ 4514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   lL: () => (/* binding */ fetchAzureSecrets)
/* harmony export */ });
/* unused harmony exports getAzureConfig, isBrowser, clearCache */
// Browser-compatible Azure configuration
// This file only uses environment variables and doesn't import server-only Azure Identity libraries
let cachedSecrets = null;
/**
 * Fetch Azure secrets from environment variables (browser-safe version)
 * This function only uses NEXT_PUBLIC_ environment variables available in the browser
 */ async function fetchAzureSecrets() {
    // Return cached secrets if available
    if (cachedSecrets) {
        return cachedSecrets;
    }
    try {
        console.log('🔑 Loading Azure configuration from environment variables...');
        const secrets = {
            speechKey: process.env.NEXT_PUBLIC_SPEECH_KEY || '',
            speechEndpoint: process.env.NEXT_PUBLIC_SPEECH_ENDPOINT || '',
            azureOpenAIKey: process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY || '',
            azureOpenAIEndpoint: process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT || '',
            azureOpenAIDeployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT || 'gpt-4o',
            azureOpenAIGpt35Deployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            azureOpenAIGpt4oDeployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o',
            azureAppConfigConnectionString: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            azureAppConfigEndpoint: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        };
        // Validate that required secrets are available
        if (!secrets.speechKey || !secrets.speechEndpoint) {
            console.warn('⚠️ Azure Speech credentials not available in browser environment');
        }
        if (!secrets.azureOpenAIKey || !secrets.azureOpenAIEndpoint) {
            console.warn('⚠️ Azure OpenAI credentials not available in browser environment');
        }
        if (!secrets.azureAppConfigConnectionString && !secrets.azureAppConfigEndpoint) {
            console.warn('⚠️ Azure App Configuration credentials not available in browser environment');
        }
        cachedSecrets = secrets;
        console.log('✅ Azure configuration loaded from environment variables');
        return cachedSecrets;
    } catch (error) {
        console.error('❌ Failed to load Azure configuration:', error);
        // Return empty secrets as fallback
        const fallbackSecrets = {
            speechKey: '',
            speechEndpoint: '',
            azureOpenAIKey: '',
            azureOpenAIEndpoint: '',
            azureOpenAIDeployment: 'gpt-4o',
            azureOpenAIGpt35Deployment: 'gpt-4o',
            azureOpenAIGpt4oDeployment: 'gpt-4o',
            azureAppConfigConnectionString: undefined,
            azureAppConfigEndpoint: undefined
        };
        cachedSecrets = fallbackSecrets;
        return cachedSecrets;
    }
}
/**
 * Get current Azure configuration (for debugging)
 */ function getAzureConfig() {
    return {
        environment: 'browser',
        hasSecretsCache: !!cachedSecrets,
        configuration: {
            speechKey: !!process.env.NEXT_PUBLIC_SPEECH_KEY,
            speechEndpoint: !!process.env.NEXT_PUBLIC_SPEECH_ENDPOINT,
            azureOpenAIKey: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY,
            azureOpenAIEndpoint: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT,
            azureOpenAIDeployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT,
            azureOpenAIGpt35Deployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT,
            azureOpenAIGpt4oDeployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT,
            azureAppConfigConnectionString: !!process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            azureAppConfigEndpoint: !!process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        },
        deployments: {
            default: process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT,
            gpt35Turbo: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            gpt4o: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o'
        },
        appConfiguration: {
            connectionString: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            endpoint: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        }
    };
}
/**
 * Check if we're running in a browser environment
 */ function isBrowser() {
    return "undefined" !== 'undefined';
}
/**
 * Clear cached secrets (useful for testing or re-initialization)
 */ function clearCache() {
    cachedSecrets = null;
    console.log('🧹 Azure configuration cache cleared');
}


/***/ }),

/***/ 18846:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   generateQuestions: () => (/* binding */ generateQuestions),
/* harmony export */   tailorResume: () => (/* binding */ tailorResume)
/* harmony export */ });
/* unused harmony exports generateCoverLetter, calculateRelevancy, getProviderInfo, switchProvider, dispose */
/* harmony import */ var _azureOpenAI__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50169);
/* harmony import */ var _azure_ai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(70598);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azureOpenAI__WEBPACK_IMPORTED_MODULE_0__, _azure_ai__WEBPACK_IMPORTED_MODULE_1__]);
([_azureOpenAI__WEBPACK_IMPORTED_MODULE_0__, _azure_ai__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure-Centric AI Service Layer
 * 
 * This module provides a unified interface for AI operations backed
 * by Azure OpenAI services. Optimized for enterprise-grade AI functionality.
 * 
 * Updated to use the new unified Azure AI facade for improved service
 * management and intelligent routing between Azure services.
 */ 

/**
 * AI Service Manager - Azure OpenAI focused service manager
 */ class AIServiceManager {
    constructor(){
        this.currentProvider = null;
        this.providers = new Map();
        this.initialized = false;
        // Register Azure OpenAI as the primary provider
        this.providers.set('azure-openai', new _azureOpenAI__WEBPACK_IMPORTED_MODULE_0__/* .AzureOpenAIAdapter */ .x());
    }
    /**
   * Initialize the AI service with Azure OpenAI
   */ async initialize() {
        const providerName = 'azure-openai';
        console.log(`🚀 Initializing AI Service with provider: ${providerName}`);
        const provider = this.providers.get(providerName);
        if (!provider) {
            console.error(`❌ Azure OpenAI provider not found`);
            return false;
        }
        try {
            const success = await provider.initialize();
            if (success) {
                this.currentProvider = provider;
                this.initialized = true;
                console.log(`✅ AI Service initialized successfully with ${provider.name}`);
                return true;
            }
        } catch (error) {
            console.error(`❌ Failed to initialize Azure OpenAI provider:`, error);
        }
        console.error('❌ Azure OpenAI provider failed to initialize');
        return false;
    }
    /**
   * Get the current provider
   */ getCurrentProvider() {
        return this.currentProvider;
    }
    /**
   * Check if the service is ready
   */ isReady() {
        return this.initialized && this.currentProvider?.isReady() === true;
    }
    /**
   * Get current provider name
   */ getProviderName() {
        return this.currentProvider?.name || 'none';
    }
    /**
   * Switch to a different provider at runtime
   */ async switchProvider(providerName) {
        console.log(`🔄 Switching to provider: ${providerName}`);
        const provider = this.providers.get(providerName);
        if (!provider) {
            console.error(`❌ Provider '${providerName}' not found`);
            return false;
        }
        // Clean up current provider
        if (this.currentProvider) {
            this.currentProvider.dispose();
        }
        try {
            const success = await provider.initialize();
            if (success) {
                this.currentProvider = provider;
                console.log(`✅ Successfully switched to ${provider.name}`);
                return true;
            }
        } catch (error) {
            console.error(`❌ Failed to switch to provider '${providerName}':`, error);
        }
        return false;
    }
    /**
   * Dispose of all resources
   */ dispose() {
        if (this.currentProvider) {
            this.currentProvider.dispose();
        }
        this.currentProvider = null;
        this.initialized = false;
        console.log('🧹 AI Service Manager disposed');
    }
}
// Singleton instance
const aiServiceManager = new AIServiceManager();
/**
 * Ensure the AI service is initialized
 */ async function ensureInitialized() {
    if (!aiServiceManager.isReady()) {
        const success = await aiServiceManager.initialize();
        if (!success) {
            throw new Error('Failed to initialize AI service - no providers available');
        }
    }
}
/**
 * Generate a cover letter based on resume and job description
 */ async function generateCoverLetter(resumeText, jobDescription) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const coverLetter = await provider.generateCoverLetter(resumeText, jobDescription);
        return {
            success: true,
            data: coverLetter,
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error generating cover letter:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Calculate relevancy score between resume and job description (0-100)
 */ async function calculateRelevancy(resumeText, jobDescription) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const score = await provider.calculateRelevancy(resumeText, jobDescription);
        return {
            success: true,
            data: Math.max(0, Math.min(100, score)),
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error calculating relevancy:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Tailor resume to match job description
 */ async function tailorResume(resumeText, jobDescription) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const tailoredResume = await provider.tailorResume(resumeText, jobDescription);
        return {
            success: true,
            data: tailoredResume,
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error tailoring resume:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Generate interview questions based on resume information
 */ async function generateQuestions(resumeInfo) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const questions = await provider.generateQuestions(resumeInfo);
        return {
            success: true,
            data: questions,
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error generating questions:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Get current AI provider information
 */ function getProviderInfo() {
    return {
        name: aiServiceManager.getProviderName(),
        isReady: aiServiceManager.isReady()
    };
}
/**
 * Switch AI provider at runtime (for testing or hot-swapping)
 */ async function switchProvider(providerName) {
    try {
        const success = await aiServiceManager.switchProvider(providerName);
        return {
            success,
            data: success,
            provider: aiServiceManager.getProviderName()
        };
    } catch (error) {
        console.error('❌ Error switching provider:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Dispose of AI service resources
 */ function dispose() {
    aiServiceManager.dispose();
}
// Export the unified Azure AI service for modern usage

 // Alias for clarity
// Re-export individual services for direct access if needed


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 22531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   y: () => (/* binding */ retryWithExponentialBackoff)
/* harmony export */ });
/* unused harmony export RetryWithBackoff */
/* harmony import */ var _microsoft_applicationinsights_web__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61031);
/* harmony import */ var _microsoft_applicationinsights_web__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_applicationinsights_web__WEBPACK_IMPORTED_MODULE_0__);

class RetryWithBackoff {
    static initialize(instrumentationKey) {
        if (instrumentationKey && "undefined" !== 'undefined') {}
    }
    /**
   * Execute a function with exponential backoff retry logic
   */ static async execute(fn, options = {}) {
        const { maxRetries = 3, baseDelay = 1000, maxDelay = 30000, jitter = true, retryCondition = this.defaultRetryCondition, onRetry, userId, action = 'unknown' } = options;
        const startTime = Date.now();
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                const result = await fn();
                // Log success metrics
                if (attempt > 0) {
                    this.logRetrySuccess({
                        attempt: attempt + 1,
                        totalAttempts: attempt + 1,
                        delay: 0,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                }
                return result;
            } catch (error) {
                lastError = error;
                // Check if we should retry
                if (attempt === maxRetries || !retryCondition(error)) {
                    // Log final failure
                    this.logRetryFailure({
                        attempt: attempt + 1,
                        totalAttempts: maxRetries + 1,
                        delay: 0,
                        error,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                    throw error;
                }
                // Calculate delay for next attempt
                const exponentialDelay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
                const delay = jitter ? exponentialDelay + Math.random() * exponentialDelay * 0.1 // Add 10% jitter
                 : exponentialDelay;
                // Log retry attempt
                this.logRetryAttempt({
                    attempt: attempt + 1,
                    totalAttempts: maxRetries + 1,
                    delay,
                    error,
                    userId,
                    action,
                    startTime
                });
                // Execute retry callback if provided
                if (onRetry) {
                    onRetry(error, attempt + 1);
                }
                // Wait before next attempt
                await this.sleep(delay);
            }
        }
        throw lastError;
    }
    /**
   * Default retry condition - retry on network errors, rate limits, and server errors
   */ static defaultRetryCondition(error) {
        // Network errors
        if (error.code === 'ECONNRESET' || error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
            return true;
        }
        // HTTP status codes that should be retried
        if (error.response?.status) {
            const status = error.response.status;
            return status === 429 || // Rate limit
            status === 502 || // Bad Gateway
            status === 503 || // Service Unavailable
            status === 504; // Gateway Timeout
        }
        // Azure OpenAI specific errors
        if (error.message?.includes('rate limit') || error.message?.includes('throttled') || error.message?.includes('quota exceeded')) {
            return true;
        }
        return false;
    }
    /**
   * Sleep for specified milliseconds
   */ static sleep(ms) {
        return new Promise((resolve)=>setTimeout(resolve, ms));
    }
    /**
   * Log retry attempt
   */ static logRetryAttempt(metrics) {
        const logData = {
            level: 'warn',
            message: `Retry attempt ${metrics.attempt}/${metrics.totalAttempts} for ${metrics.action}`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                delay: metrics.delay,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name
                },
                timestamp: new Date().toISOString()
            }
        };
        console.warn('RETRY_ATTEMPT', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 2,
                properties: logData.properties
            });
        }
    }
    /**
   * Log retry success
   */ static logRetrySuccess(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'info',
            message: `Retry succeeded for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                timestamp: new Date().toISOString()
            }
        };
        console.log('RETRY_SUCCESS', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 1,
                properties: logData.properties
            });
            // Track custom metric for retry success
            this.appInsights.trackMetric({
                name: 'RetrySuccess',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
    /**
   * Log retry failure
   */ static logRetryFailure(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'error',
            message: `Retry failed for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name,
                    stack: metrics.error?.stack
                },
                timestamp: new Date().toISOString()
            }
        };
        console.error('RETRY_FAILURE', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackException({
                exception: metrics.error,
                properties: logData.properties,
                severityLevel: 3 // Error
            });
            // Track custom metric for retry failure
            this.appInsights.trackMetric({
                name: 'RetryFailure',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
}
/**
 * Convenience function for common retry scenarios
 */ async function retryWithExponentialBackoff(fn, action, userId, options) {
    return RetryWithBackoff.execute(fn, {
        action,
        userId,
        ...options
    });
}


/***/ }),

/***/ 43334:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ foundryDocumentIntelligenceService)
/* harmony export */ });
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10756);
/* harmony import */ var _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28594);
/* harmony import */ var _config_foundry_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11359);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65044);
/* harmony import */ var _lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22531);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_1__, _config_foundry_config__WEBPACK_IMPORTED_MODULE_2__]);
([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_1__, _config_foundry_config__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure AI Foundry Document Intelligence Client
 * 
 * Enhanced document analysis using Azure AI Foundry's Document Intelligence service.
 * Provides advanced OCR, layout analysis, and structured extraction capabilities.
 * Replaces and enhances the existing Azure Form Recognizer implementation.
 */ 




// Client-side safety check
const isClient = "undefined" !== 'undefined';
if (isClient) {
    console.warn('[Document Intelligence Client] Running on client side - clients will not be initialized');
}
/**
 * Azure AI Foundry Document Intelligence Service
 */ class FoundryDocumentIntelligenceService {
    /**
   * Initialize the Azure AI Foundry Document Intelligence service
   */ async initialize() {
        if (isClient) {
            console.warn('⚠️ Document Intelligence client cannot be initialized on client side');
            return false;
        }
        if (this.isInitialized) {
            return true;
        }
        try {
            const config = await (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_2__/* .getFoundryConfig */ .at)();
            // Check if Document Intelligence is configured in Foundry config
            const docIntEndpoint = process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || config.docIntelligence?.endpoint;
            const docIntApiKey = process.env.AZURE_FOUNDRY_DOCINT_API_KEY || config.docIntelligence?.apiKey;
            if (!docIntEndpoint || !docIntApiKey) {
                console.warn('⚠️ Azure AI Foundry Document Intelligence credentials not found');
                console.log('💡 Configure AZURE_FOUNDRY_DOCINT_ENDPOINT and AZURE_FOUNDRY_DOCINT_API_KEY');
                return false;
            }
            console.log('🔧 Initializing Azure AI Foundry Document Intelligence client...');
            // Create client with either API key or managed identity
            const credential = docIntApiKey.startsWith('https://') ? new _azure_identity__WEBPACK_IMPORTED_MODULE_0__.DefaultAzureCredential() : new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_1__.AzureKeyCredential(docIntApiKey);
            this.client = new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_1__.DocumentAnalysisClient(docIntEndpoint, credential, {
                additionalPolicies: [
                    {
                        policy: {
                            name: 'PrepBettrDocumentIntelligence',
                            sendRequest: async (request, next)=>{
                                // Add custom headers for tracking
                                request.headers.set('X-Client-Name', 'PrepBettr');
                                request.headers.set('X-Client-Version', '2.0');
                                return next(request);
                            }
                        },
                        position: 'perCall'
                    }
                ],
                retryOptions: {
                    maxRetries: config.connection.retryPolicy.maxRetries,
                    retryDelayInMs: config.connection.retryPolicy.baseDelay
                }
            });
            this.isInitialized = true;
            console.log('✅ Azure AI Foundry Document Intelligence service initialized');
            return true;
        } catch (error) {
            console.error('❌ Failed to initialize Document Intelligence service:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_3__/* .logServerError */ .wh)(error, {
                service: 'foundry-document-intelligence',
                action: 'initialize'
            });
            return false;
        }
    }
    /**
   * Check if service is ready
   */ isReady() {
        return !isClient && this.isInitialized && this.client !== null;
    }
    /**
   * Analyze resume document with enhanced extraction
   */ async analyzeResume(documentBuffer, mimeType, options) {
        if (!this.isReady()) {
            throw new Error('Document Intelligence service not initialized');
        }
        const startTime = Date.now();
        const modelType = options?.modelType || 'resume-analysis';
        const modelConfig = this.modelConfigs[modelType];
        try {
            console.log(`🔍 Analyzing resume with model: ${modelConfig.modelId}`);
            const result = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_4__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                const poller = await this.client.beginAnalyzeDocument(modelConfig.modelId, documentBuffer, {
                    locale: modelConfig.locale
                });
                return await poller.pollUntilDone();
            }, 'document-intelligence-analyze', undefined, {
                maxRetries: 3,
                baseDelay: 2000,
                maxDelay: 30000
            });
            const processingTime = Date.now() - startTime;
            // Extract structured data from the analysis result
            const extraction = await this.extractStructuredData(result, processingTime);
            // Add ATS analysis if requested
            if (options?.includeAtsAnalysis) {
                extraction.atsAnalysis = await this.performAtsAnalysis(extraction);
            }
            console.log(`✅ Resume analysis completed in ${processingTime}ms`);
            return extraction;
        } catch (error) {
            console.error('❌ Failed to analyze resume with Document Intelligence:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_3__/* .logServerError */ .wh)(error, {
                service: 'foundry-document-intelligence',
                action: 'analyze-resume'
            }, {
                mimeType,
                modelType,
                processingTime: Date.now() - startTime
            });
            throw error;
        }
    }
    /**
   * Compare resume against job description for matching analysis
   */ async compareWithJobDescription(resumeExtraction, jobDescription) {
        try {
            console.log('🎯 Performing job match analysis...');
            // Extract job requirements from description
            const jobRequirements = await this.extractJobRequirements(jobDescription);
            // Perform multi-dimensional matching
            const skillsMatch = this.analyzeSkillsMatch(resumeExtraction.skills, jobRequirements.skills);
            const experienceMatch = this.analyzeExperienceMatch(resumeExtraction.experience, jobRequirements);
            const educationMatch = this.analyzeEducationMatch(resumeExtraction.education, jobRequirements);
            const keywordAnalysis = this.analyzeKeywords(resumeExtraction, jobDescription);
            // Calculate overall score
            const overallScore = this.calculateOverallMatchScore({
                skillsMatch,
                experienceMatch,
                educationMatch,
                keywordAnalysis
            });
            // Generate recommendations
            const recommendations = this.generateMatchRecommendations({
                skillsMatch,
                experienceMatch,
                educationMatch,
                keywordAnalysis
            });
            return {
                overallScore,
                skillsMatch,
                experienceMatch,
                educationMatch,
                keywordAnalysis,
                recommendations
            };
        } catch (error) {
            console.error('❌ Failed to perform job match analysis:', error);
            throw error;
        }
    }
    /**
   * Extract structured data from Document Intelligence result
   */ async extractStructuredData(result, processingTime) {
        const pages = result.pages || [];
        const keyValuePairs = result.keyValuePairs || [];
        const entities = result.entities || [];
        const content = result.content || '';
        // Extract personal information using key-value pairs and patterns
        const personalInfo = this.extractPersonalInfo(keyValuePairs, content, entities);
        // Extract skills with proficiency assessment
        const skills = this.extractEnhancedSkills(content, entities);
        // Extract work experience with quantifiable results
        const experience = this.extractWorkExperience(content, entities);
        // Extract education with validation
        const education = this.extractEducation(content, entities);
        // Extract projects with impact assessment
        const projects = this.extractProjects(content, entities);
        // Extract certifications
        const certifications = this.extractCertifications(content, entities);
        // Extract languages
        const languages = this.extractLanguages(content, entities);
        // Analyze document structure
        const documentStructure = this.analyzeDocumentStructure(result);
        return {
            personalInfo,
            skills,
            experience,
            education,
            projects,
            certifications,
            languages,
            metadata: {
                processingTime,
                pageCount: pages.length,
                modelUsed: 'azure-foundry-document-intelligence',
                overallConfidence: this.calculateOverallConfidence(result),
                languageDetected: result.languages?.[0]?.locale,
                documentStructure
            },
            rawExtraction: result // Store for debugging/export
        };
    }
    /**
   * Extract personal information with confidence scores
   */ extractPersonalInfo(keyValuePairs, content, entities) {
        const personalInfo = {};
        // Extract from key-value pairs first (highest confidence)
        keyValuePairs.forEach((pair)=>{
            const key = pair.key?.content?.toLowerCase() || '';
            const value = pair.value;
            if (key.includes('name') && !personalInfo.name) {
                personalInfo.name = {
                    content: value.content,
                    confidence: value.confidence || 0.9
                };
            } else if (key.includes('email') && !personalInfo.email) {
                personalInfo.email = {
                    content: value.content,
                    confidence: value.confidence || 0.95
                };
            } else if (key.includes('phone') && !personalInfo.phone) {
                personalInfo.phone = {
                    content: value.content,
                    confidence: value.confidence || 0.9
                };
            }
        });
        // Extract from entities if not found in key-value pairs
        entities.forEach((entity)=>{
            if (entity.category === 'Person' && !personalInfo.name) {
                personalInfo.name = {
                    content: entity.content,
                    confidence: entity.confidence
                };
            } else if (entity.category === 'Email' && !personalInfo.email) {
                personalInfo.email = {
                    content: entity.content,
                    confidence: entity.confidence
                };
            } else if (entity.category === 'PhoneNumber' && !personalInfo.phone) {
                personalInfo.phone = {
                    content: entity.content,
                    confidence: entity.confidence
                };
            }
        });
        // Fallback to regex patterns with lower confidence
        if (!personalInfo.email) {
            const emailMatch = content.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/);
            if (emailMatch) {
                personalInfo.email = {
                    content: emailMatch[0],
                    confidence: 0.8
                };
            }
        }
        if (!personalInfo.phone) {
            const phoneMatch = content.match(/(\+?1?[-. \s]?)?\(?[0-9]{3}\)?[-. \s]?[0-9]{3}[-. \s]?[0-9]{4}/);
            if (phoneMatch) {
                personalInfo.phone = {
                    content: phoneMatch[0],
                    confidence: 0.75
                };
            }
        }
        // Extract LinkedIn and GitHub URLs
        const linkedinMatch = content.match(/linkedin\.com\/in\/[\w-]+/i);
        if (linkedinMatch) {
            personalInfo.linkedin = {
                content: `https://${linkedinMatch[0]}`,
                confidence: 0.9
            };
        }
        const githubMatch = content.match(/github\.com\/[\w-]+/i);
        if (githubMatch) {
            personalInfo.github = {
                content: `https://${githubMatch[0]}`,
                confidence: 0.9
            };
        }
        return personalInfo;
    }
    /**
   * Extract skills with proficiency levels and categorization
   */ extractEnhancedSkills(content, entities) {
        const skills = [];
        // Technical skills database for categorization
        const technicalSkills = [
            'javascript',
            'typescript',
            'python',
            'java',
            'react',
            'node',
            'angular',
            'vue',
            'sql',
            'mongodb',
            'postgresql',
            'mysql',
            'docker',
            'kubernetes',
            'aws',
            'azure',
            'tensorflow',
            'pytorch',
            'machine learning',
            'data science',
            'blockchain'
        ];
        const softSkills = [
            'leadership',
            'teamwork',
            'communication',
            'problem solving',
            'critical thinking',
            'project management',
            'agile',
            'scrum'
        ];
        // Extract from content with pattern matching
        const skillsSection = content.match(/(?:skills?|technologies|competencies)[:\s]*([^]*?)(?=\n\s*[A-Z][^:]*:|$)/i);
        if (skillsSection) {
            const skillsText = skillsSection[1];
            // Split by common delimiters
            const detectedSkills = skillsText.replace(/[•\\-\\*]/g, ',').split(/[,\\n]/).map((skill)=>skill.trim()).filter((skill)=>skill.length > 0 && skill.length < 50);
            detectedSkills.forEach((skill)=>{
                const lowerSkill = skill.toLowerCase();
                let category = 'tool';
                let proficiency;
                // Categorize skill
                if (technicalSkills.some((tech)=>lowerSkill.includes(tech))) {
                    category = 'technical';
                } else if (softSkills.some((soft)=>lowerSkill.includes(soft))) {
                    category = 'soft';
                }
                // Detect proficiency indicators
                if (skill.match(/expert|advanced|senior|lead/i)) {
                    proficiency = 'expert';
                } else if (skill.match(/intermediate|mid|experienced/i)) {
                    proficiency = 'intermediate';
                } else if (skill.match(/beginner|basic|junior/i)) {
                    proficiency = 'beginner';
                } else if (skill.match(/proficient|skilled/i)) {
                    proficiency = 'advanced';
                }
                skills.push({
                    skill: skill,
                    proficiency,
                    category,
                    confidence: 0.8,
                    yearsOfExperience: this.extractYearsOfExperience(skill, content)
                });
            });
        }
        return skills;
    }
    /**
   * Extract work experience with quantifiable results and management scope
   */ extractWorkExperience(content, entities) {
        const experience = [];
        // Pattern to match experience sections
        const expSection = content.match(/(?:experience|employment|work history)[:\s]*([^]*?)(?=\n\s*(?:education|skills?|projects?)[:\s]|$)/i);
        if (!expSection) return experience;
        const expText = expSection[1];
        // Split into individual job entries (basic pattern)
        const jobEntries = expText.split(/\n(?=[A-Z].*(?:Inc\.|Corp\.|LLC|Ltd\.|Company|\d{4}))/);
        jobEntries.forEach((entry)=>{
            if (entry.trim().length < 50) return; // Skip short entries
            const job = this.parseJobEntry(entry.trim());
            if (job.company.content && job.position.content) {
                experience.push(job);
            }
        });
        return experience;
    }
    /**
   * Parse individual job entry
   */ parseJobEntry(entry) {
        const lines = entry.split('\n').map((line)=>line.trim());
        // Extract company and position (usually first few lines)
        const companyMatch = lines[0].match(/^(.+?)(?:\s+[-–—]\s+(.+))?$/);
        const company = companyMatch ? companyMatch[1] : lines[0];
        const position = companyMatch ? companyMatch[2] || lines[1] : lines[1];
        // Extract dates
        const datePattern = /(\d{1,2}\/\d{4}|\w+\s+\d{4}|\d{4})\s*[-–—]\s*(\d{1,2}\/\d{4}|\w+\s+\d{4}|\d{4}|present)/i;
        const dateMatch = entry.match(datePattern);
        // Extract achievements and quantifiable results
        const achievements = lines.filter((line)=>line.match(/^[•\\-\\*]/) || line.includes('achieved') || line.includes('%') || line.includes('$')).map((line)=>({
                content: line.replace(/^[•\\-\\*]\s*/, ''),
                confidence: 0.8
            }));
        // Extract quantifiable results
        const quantifiableResults = this.extractQuantifiableResults(entry);
        // Extract management scope
        const managementScope = this.extractManagementScope(entry);
        return {
            company: {
                content: company,
                confidence: 0.9
            },
            position: {
                content: position,
                confidence: 0.9
            },
            startDate: dateMatch ? {
                content: dateMatch[1],
                confidence: 0.8
            } : undefined,
            endDate: dateMatch ? {
                content: dateMatch[2],
                confidence: 0.8
            } : undefined,
            isCurrent: dateMatch ? dateMatch[2].toLowerCase().includes('present') : false,
            description: {
                content: lines.slice(2).join(' '),
                confidence: 0.7
            },
            achievements,
            technologies: this.extractTechnologies(entry),
            managementScope,
            quantifiableResults,
            confidence: 0.8
        };
    }
    /**
   * Extract quantifiable results from job description
   */ extractQuantifiableResults(text) {
        const results = [];
        // Pattern for percentages
        const percentMatches = text.match(/(\w+[^.]*?)(\d+)%/g);
        percentMatches?.forEach((match)=>{
            const parts = match.match(/(\w+[^.]*?)(\d+)%/);
            if (parts) {
                results.push({
                    metric: parts[1].trim(),
                    value: parseInt(parts[2]),
                    unit: 'percentage',
                    impact: match
                });
            }
        });
        // Pattern for monetary values
        const moneyMatches = text.match(/\$[\d,]+(?:\.\d{2})?[KMB]?/g);
        moneyMatches?.forEach((match)=>{
            const value = match.replace(/[\$,]/g, '');
            results.push({
                metric: 'revenue/savings',
                value: parseFloat(value),
                unit: 'currency',
                impact: match
            });
        });
        return results;
    }
    /**
   * Extract management scope information
   */ extractManagementScope(text) {
        const teamSizeMatch = text.match(/(?:managed|led|supervised).*?(\d+).*?(?:people|team|members|employees)/i);
        const budgetMatch = text.match(/budget.*?\$[\d,]+(?:\.\d{2})?[KMB]?/i);
        if (teamSizeMatch || budgetMatch) {
            return {
                teamSize: teamSizeMatch ? parseInt(teamSizeMatch[1]) : undefined,
                budget: budgetMatch ? budgetMatch[0] : undefined,
                responsibilities: text.match(/(?:managed|led|supervised|oversaw)[^.]+/gi) || []
            };
        }
        return undefined;
    }
    /**
   * Extract technologies from text
   */ extractTechnologies(text) {
        const techKeywords = [
            'javascript',
            'typescript',
            'python',
            'java',
            'react',
            'angular',
            'vue',
            'node',
            'sql',
            'mongodb',
            'postgresql',
            'docker',
            'kubernetes',
            'aws',
            'azure',
            'git'
        ];
        return techKeywords.filter((tech)=>text.toLowerCase().includes(tech.toLowerCase()));
    }
    /**
   * Extract years of experience for a skill from context
   */ extractYearsOfExperience(skill, content) {
        const skillPattern = new RegExp(`${skill}.*?(\\d+)\\s*years?`, 'i');
        const match = content.match(skillPattern);
        return match ? parseInt(match[1]) : undefined;
    }
    /**
   * Extract education information
   */ extractEducation(content, entities) {
        const education = [];
        const eduSection = content.match(/(?:education|academic)[:\s]*([^]*?)(?=\n\s*(?:experience|skills?|projects?)[:\s]|$)/i);
        if (!eduSection) return education;
        const eduText = eduSection[1];
        const lines = eduText.split('\n').filter((line)=>line.trim());
        let currentEdu = {};
        lines.forEach((line)=>{
            line = line.trim();
            if (!line) return;
            // Check if this looks like a new education entry
            if (line.match(/university|college|institute|school/i)) {
                if (currentEdu.institution) {
                    education.push(currentEdu);
                }
                currentEdu = {
                    institution: {
                        content: line,
                        confidence: 0.9
                    },
                    confidence: 0.8
                };
            } else if (line.match(/bachelor|master|phd|doctorate|degree/i)) {
                currentEdu.degree = {
                    content: line,
                    confidence: 0.9
                };
            } else if (line.match(/\d{4}/)) {
                const dateMatch = line.match(/(\d{4})\s*[-–—]\s*(\d{4})/);
                if (dateMatch) {
                    currentEdu.startDate = {
                        content: dateMatch[1],
                        confidence: 0.8
                    };
                    currentEdu.endDate = {
                        content: dateMatch[2],
                        confidence: 0.8
                    };
                }
            }
        });
        if (currentEdu.institution) {
            education.push(currentEdu);
        }
        return education;
    }
    /**
   * Extract projects information
   */ extractProjects(content, entities) {
        const projects = [];
        const projSection = content.match(/(?:projects?)[:\s]*([^]*?)(?=\n\s*(?:experience|education|skills?)[:\s]|$)/i);
        if (!projSection) return projects;
        const projText = projSection[1];
        const projectEntries = projText.split(/\n(?=[A-Z][^:\n]+)/);
        projectEntries.forEach((entry)=>{
            if (entry.trim().length < 20) return;
            const lines = entry.split('\n').map((line)=>line.trim());
            const projectName = lines[0];
            const description = lines.slice(1).join(' ');
            projects.push({
                name: {
                    content: projectName,
                    confidence: 0.8
                },
                description: {
                    content: description,
                    confidence: 0.7
                },
                technologies: this.extractTechnologies(entry),
                confidence: 0.7
            });
        });
        return projects;
    }
    /**
   * Extract certifications
   */ extractCertifications(content, entities) {
        const certifications = [];
        const certSection = content.match(/(?:certifications?|certificates)[:\s]*([^]*?)(?=\n\s*(?:experience|education|skills?|projects?)[:\s]|$)/i);
        if (!certSection) return certifications;
        const certText = certSection[1];
        const lines = certText.split('\n').filter((line)=>line.trim());
        lines.forEach((line)=>{
            line = line.trim();
            if (line.length < 10) return;
            const parts = line.split(/[-–—,]/);
            const name = parts[0]?.trim();
            const issuer = parts[1]?.trim();
            if (name) {
                certifications.push({
                    name: {
                        content: name,
                        confidence: 0.8
                    },
                    issuer: {
                        content: issuer || 'Unknown',
                        confidence: issuer ? 0.7 : 0.3
                    },
                    status: 'unknown',
                    confidence: 0.7
                });
            }
        });
        return certifications;
    }
    /**
   * Extract languages
   */ extractLanguages(content, entities) {
        const languages = [];
        const langSection = content.match(/(?:languages?)[:\s]*([^]*?)(?=\n\s*[A-Z][^:]*:|$)/i);
        if (!langSection) return languages;
        const langText = langSection[1];
        const langEntries = langText.split(/[,\n]/).filter((entry)=>entry.trim());
        langEntries.forEach((entry)=>{
            entry = entry.trim();
            const parts = entry.split(/[-–—:]/);
            const name = parts[0]?.trim();
            const proficiencyText = parts[1]?.trim().toLowerCase();
            let proficiency = 'conversational';
            if (proficiencyText) {
                if (proficiencyText.includes('native') || proficiencyText.includes('mother tongue')) {
                    proficiency = 'native';
                } else if (proficiencyText.includes('fluent') || proficiencyText.includes('advanced')) {
                    proficiency = 'fluent';
                } else if (proficiencyText.includes('basic') || proficiencyText.includes('beginner')) {
                    proficiency = 'basic';
                }
            }
            if (name && name.length > 2) {
                languages.push({
                    name: name,
                    proficiency,
                    confidence: 0.7
                });
            }
        });
        return languages;
    }
    /**
   * Analyze document structure
   */ analyzeDocumentStructure(result) {
        const content = result.content || '';
        return {
            hasHeaders: /^[A-Z][^a-z]*$/m.test(content),
            hasBulletPoints: /[•\\-\\*]/.test(content),
            hasTables: result.tables && result.tables.length > 0,
            columnLayout: content.includes('\t') || content.match(/\s{4,}/) !== null
        };
    }
    /**
   * Calculate overall confidence score
   */ calculateOverallConfidence(result) {
        const pages = result.pages || [];
        if (pages.length === 0) return 0;
        let totalConfidence = 0;
        let totalElements = 0;
        pages.forEach((page)=>{
            const lines = page.lines || [];
            lines.forEach((line)=>{
                totalConfidence += line.confidence || 0;
                totalElements++;
            });
        });
        return totalElements > 0 ? totalConfidence / totalElements : 0;
    }
    /**
   * Perform ATS optimization analysis
   */ async performAtsAnalysis(extraction) {
        // Simplified ATS analysis - can be enhanced with more sophisticated algorithms
        const recommendations = [];
        const formatIssues = [];
        const structuralOptimizations = [];
        // Check for common ATS issues
        if (!extraction.personalInfo.email) {
            formatIssues.push('Missing email address');
        }
        if (!extraction.personalInfo.phone) {
            formatIssues.push('Missing phone number');
        }
        if (extraction.skills.length < 5) {
            recommendations.push('Add more relevant skills to improve keyword matching');
        }
        if (extraction.experience.length === 0) {
            structuralOptimizations.push('Add work experience section');
        }
        // Calculate keyword density
        const keywordDensity = {};
        const allText = JSON.stringify(extraction).toLowerCase();
        // Common job keywords
        const jobKeywords = [
            'experience',
            'skills',
            'manage',
            'develop',
            'lead',
            'project',
            'team'
        ];
        jobKeywords.forEach((keyword)=>{
            const matches = (allText.match(new RegExp(keyword, 'g')) || []).length;
            keywordDensity[keyword] = matches;
        });
        // Calculate ATS score (simplified)
        let score = 70; // Base score
        if (extraction.personalInfo.email) score += 5;
        if (extraction.personalInfo.phone) score += 5;
        if (extraction.skills.length >= 10) score += 10;
        if (extraction.experience.length >= 2) score += 10;
        score -= formatIssues.length * 5;
        return {
            score: Math.max(0, Math.min(100, score)),
            recommendations,
            keywordDensity,
            formatIssues,
            structuralOptimizations
        };
    }
    // Placeholder methods for job matching (to be implemented)
    async extractJobRequirements(jobDescription) {
        // TODO: Implement job requirements extraction
        return {
            skills: [],
            experience: [],
            education: []
        };
    }
    analyzeSkillsMatch(resumeSkills, jobSkills) {
        // TODO: Implement skills matching algorithm
        return {
            matchedSkills: [],
            missingSkills: [],
            skillGapScore: 0
        };
    }
    analyzeExperienceMatch(experience, jobRequirements) {
        // TODO: Implement experience matching
        return {
            yearsMatch: false,
            industryMatch: false,
            roleMatch: false,
            seniorityMatch: false
        };
    }
    analyzeEducationMatch(education, jobRequirements) {
        // TODO: Implement education matching
        return {
            degreeMatch: false,
            fieldMatch: false
        };
    }
    analyzeKeywords(extraction, jobDescription) {
        // TODO: Implement keyword analysis
        return {
            totalKeywords: 0,
            matchedKeywords: 0,
            missedKeywords: [],
            keywordDensity: 0
        };
    }
    calculateOverallMatchScore(analysis) {
        // TODO: Implement overall score calculation
        return 0;
    }
    generateMatchRecommendations(analysis) {
        // TODO: Implement recommendation generation
        return [];
    }
    /**
   * Dispose of resources
   */ dispose() {
        this.client = null;
        this.isInitialized = false;
        console.log('🧹 Document Intelligence service disposed');
    }
    constructor(){
        this.client = null;
        this.isInitialized = false;
        // Model configurations for different document types
        this.modelConfigs = {
            'resume-analysis': {
                modelId: 'prebuilt-layout'
            },
            'resume-structured': {
                modelId: 'prebuilt-document'
            },
            'general-document': {
                modelId: 'prebuilt-read'
            }
        };
    }
}
// Export singleton instance
const foundryDocumentIntelligenceService = new FoundryDocumentIntelligenceService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 50169:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   x: () => (/* binding */ AzureOpenAIAdapter)
/* harmony export */ });
/* harmony import */ var _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89134);
/* harmony import */ var _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(94279);
/* harmony import */ var _lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(22531);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__]);
([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure OpenAI Provider Adapter
 * 
 * This adapter wraps Azure OpenAI API to provide a consistent interface
 * for the AI service layer. Reuses the existing AzureOpenAIService for
 * consistent configuration and error handling.
 */ 


class AzureOpenAIAdapter {
    /**
   * Initialize the Azure OpenAI service
   */ async initialize() {
        try {
            // Try enhanced service first, fallback to standard service
            if (this.useEnhancedService) {
                this.isInitialized = await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.initialize();
                if (this.isInitialized) {
                    console.log('✅ Azure OpenAI adapter initialized with enhanced service');
                    return true;
                }
                console.warn('⚠️ Enhanced service failed, falling back to standard service');
                this.useEnhancedService = false;
            }
            // Fallback to standard service
            this.isInitialized = await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.initialize();
            if (this.isInitialized) {
                console.log('✅ Azure OpenAI adapter initialized with standard service');
            } else {
                console.warn('⚠️ Azure OpenAI adapter failed to initialize');
            }
            return this.isInitialized;
        } catch (error) {
            console.error('❌ Failed to initialize Azure OpenAI adapter:', error);
            return false;
        }
    }
    /**
   * Check if the adapter is ready
   */ isReady() {
        if (this.useEnhancedService) {
            return this.isInitialized && _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.isReady();
        }
        return this.isInitialized && _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.isReady();
    }
    /**
   * Generate a cover letter using Azure OpenAI with retry logic
   */ async generateCoverLetter(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service if available for optimal model selection
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateCoverLetter(resumeText, jobDescription);
            }
            // Fallback to custom implementation
            return await this.generateWithAzureOpenAI(this.getCoverLetterPrompt(resumeText, jobDescription));
        }, 'generate_cover_letter', userId, {
            maxRetries: 3,
            baseDelay: 2000,
            maxDelay: 60000 // 1 minute max delay
        });
    }
    /**
   * Calculate relevancy score between resume and job description with retry logic
   */ async calculateRelevancy(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service for efficient gpt-35-turbo scoring
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.calculateRelevancy(resumeText, jobDescription);
            }
            // Fallback implementation
            const prompt = this.getRelevancyPrompt(resumeText, jobDescription);
            const response = await this.generateWithAzureOpenAI(prompt, this.RELEVANCY_TEMPERATURE, this.RELEVANCY_MAX_TOKENS);
            // Extract number from response
            const scoreMatch = response.trim().match(/\d+/);
            if (!scoreMatch) {
                throw new Error('Could not extract relevancy score from response');
            }
            const score = parseInt(scoreMatch[0], 10);
            return Math.max(0, Math.min(100, score)); // Ensure score is between 0-100
        }, 'calculate_relevancy', userId, {
            maxRetries: 2,
            baseDelay: 1000,
            maxDelay: 30000
        });
    }
    /**
   * Tailor resume to match job description with retry logic
   */ async tailorResume(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service for optimal gpt-4o quality
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.tailorResume(resumeText, jobDescription);
            }
            // Fallback to standard service
            return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.tailorResume(resumeText, jobDescription);
        }, 'tailor_resume', userId, {
            maxRetries: 3,
            baseDelay: 3000,
            maxDelay: 90000 // 1.5 minutes max delay
        });
    }
    /**
   * Generate interview questions based on resume information with retry logic
   */ async generateQuestions(resumeInfo, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service for efficient gpt-35-turbo question generation
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateQuestions(resumeInfo);
            }
            // Fallback to standard service
            return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.generateQuestions(resumeInfo);
        }, 'generate_questions', userId, {
            maxRetries: 2,
            baseDelay: 1500,
            maxDelay: 45000
        });
    }
    /**
   * Generate content using Azure OpenAI with retry logic
   * Uses optimized parameters for consistent high-quality responses
   */ async generateWithAzureOpenAI(prompt, temperature = this.DEFAULT_TEMPERATURE, maxTokens = this.DEFAULT_MAX_TOKENS) {
        const messages = [
            {
                role: 'user',
                content: prompt
            }
        ];
        try {
            const completion = await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.createCompletion(messages, {
                temperature,
                maxTokens,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1 // Encourage diverse content
            });
            const content = completion.choices[0]?.message?.content;
            if (!content) {
                throw new Error('Empty response from Azure OpenAI');
            }
            return content;
        } catch (error) {
            console.error('❌ Error generating content with Azure OpenAI:', error);
            throw error;
        }
    }
    /**
   * Get cover letter generation prompt with optimized structure
   */ getCoverLetterPrompt(resumeText, jobDescription) {
        return `You are an expert career coach and professional writer. Please generate a compelling cover letter based on the provided resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Please generate a cover letter that:
1. Is tailored to the specific job description
2. Highlights the most relevant skills and experiences from the resume
3. Has a professional and engaging tone
4. Is well-structured and easy to read
5. Is approximately 3-4 paragraphs long

Return ONLY the cover letter content with no additional commentary or explanations.`;
    }
    /**
   * Get relevancy analysis prompt with structured requirements
   */ getRelevancyPrompt(resumeText, jobDescription) {
        return `You are an expert ATS (Applicant Tracking System) analyzer. Please analyze the relevancy between this resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Analyze the match between the resume and job description considering:
1. Skills alignment (technical and soft skills)
2. Experience relevance (years and type of experience)
3. Education and certifications match
4. Industry experience
5. Role responsibilities alignment
6. Keywords and terminology match

Return ONLY a single number between 0 and 100 representing the percentage match/relevancy score. No explanations or additional text.`;
    }
    /**
   * Dispose of resources
   */ dispose() {
        // The underlying service manages its own resources
        this.isInitialized = false;
        this.useEnhancedService = true; // Reset for next initialization
        console.log('🧹 Azure OpenAI adapter disposed');
    }
    constructor(){
        this.name = 'Azure OpenAI (Enhanced)';
        this.isInitialized = false;
        this.useEnhancedService = true // Feature flag for enhanced multi-deployment service
        ;
        // Default parameters for optimal Azure OpenAI performance
        this.DEFAULT_TEMPERATURE = 0.7 // Balanced creativity
        ;
        this.DEFAULT_MAX_TOKENS = 1500 // Comprehensive responses
        ;
        this.RELEVANCY_TEMPERATURE = 0.1 // For precise scoring
        ;
        this.RELEVANCY_MAX_TOKENS = 50 // Short numeric response
        ;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 70598:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony export azureAI */
/* harmony import */ var _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89134);
/* harmony import */ var _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(94279);
/* harmony import */ var _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(51795);
/* harmony import */ var _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(43334);
/* harmony import */ var _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(67327);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65044);
/* harmony import */ var _lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(22531);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__, _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_2__, _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__, _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__]);
([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__, _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_2__, _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__, _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Unified Azure AI Facade
 * 
 * Central entry point for all Azure AI services including OpenAI, Cognitive Services,
 * and Azure AI Foundry. Provides simplified access to Azure's AI capabilities
 * with intelligent routing and fallback mechanisms.
 */ 






/**
 * Azure AI Unified Service
 * Provides centralized access to all Azure AI capabilities
 */ class AzureAIService {
    /**
   * Initialize all Azure AI services
   */ async initialize() {
        if (this.initialized) {
            return;
        }
        console.log('🚀 Initializing Azure AI unified service...');
        const startTime = Date.now();
        try {
            // Initialize Azure OpenAI services
            const [openaiReady, enhancedReady, formRecognizerReady] = await Promise.allSettled([
                _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.initialize(),
                _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.initialize(),
                _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_2__/* .azureFormRecognizer */ .m.initialize()
            ]);
            this.availableServices.openai = openaiReady.status === 'fulfilled' && openaiReady.value;
            this.availableServices.enhanced = enhancedReady.status === 'fulfilled' && enhancedReady.value;
            this.availableServices.formRecognizer = formRecognizerReady.status === 'fulfilled' && formRecognizerReady.value;
            // Initialize Azure AI Foundry if feature flag is enabled
            try {
                const foundryEnabled = await _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__/* .unifiedConfigService */ .Um.get('features.foundryResumeProcessing', false);
                if (foundryEnabled) {
                    this.availableServices.foundry = await _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__/* .foundryDocumentIntelligenceService */ .P.initialize();
                }
            } catch (error) {
                console.warn('⚠️ Foundry initialization skipped:', error);
            }
            this.initialized = true;
            const initTime = Date.now() - startTime;
            console.log('✅ Azure AI unified service initialized', {
                duration: `${initTime}ms`,
                services: this.availableServices
            });
        } catch (error) {
            console.error('❌ Azure AI service initialization failed:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(error, {
                service: 'azure-ai-unified',
                action: 'initialize'
            });
            throw error;
        }
    }
    /**
   * Get service status information
   */ getStatus() {
        return {
            initialized: this.initialized,
            services: this.availableServices
        };
    }
    /**
   * Generate text completions using Azure OpenAI
   */ async generateCompletion(prompt, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            // Use enhanced service if available, fallback to standard
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const result = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateContent(prompt, 'general');
                } else {
                    // Fall back to basic service, but it doesn't have generateCompletion
                    throw new Error('Basic Azure OpenAI service does not support completion generation');
                }
            }, 'azure_ai_completion', options.userId, {
                maxRetries: 3,
                baseDelay: 1000
            });
            return {
                success: true,
                data: result,
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        } catch (error) {
            console.error('❌ Azure AI completion failed:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Completion failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Generate interview questions from resume data
   */ async generateQuestions(resumeData, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            // Use enhanced service if available
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const questions = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateQuestions(resumeData);
                } else {
                    return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.generateQuestions(resumeData);
                }
            }, 'azure_ai_questions', undefined, {
                maxRetries: 2,
                baseDelay: 1000
            });
            // Filter to max questions if specified
            const filteredQuestions = options.maxQuestions ? questions.slice(0, options.maxQuestions) : questions;
            return {
                success: true,
                data: filteredQuestions,
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        } catch (error) {
            console.error('❌ Azure AI question generation failed:', error);
            // Return default questions as fallback
            const defaultQuestions = [
                "Tell me about yourself and your professional background.",
                "What interests you most about this position?",
                "Describe a challenging project you've worked on.",
                "How do you stay updated with industry trends?",
                "Where do you see yourself in 5 years?",
                "What are your greatest strengths?",
                "Describe a time when you had to work under pressure.",
                "How do you handle feedback and criticism?"
            ];
            return {
                success: false,
                data: defaultQuestions.slice(0, options.maxQuestions || 8),
                error: error instanceof Error ? error.message : 'Question generation failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Extract data from resume documents
   */ async extractResumeData(fileBuffer, mimeType, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            // Use Azure AI Foundry if available and enabled
            if (this.availableServices.foundry && (options.forceFoundryProcessing || await _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__/* .unifiedConfigService */ .Um.get('features.foundryResumeProcessing', false))) {
                const extraction = await _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__/* .foundryDocumentIntelligenceService */ .P.analyzeResume(fileBuffer, mimeType, {
                    includeAtsAnalysis: options.includeAtsAnalysis,
                    modelType: 'resume-analysis'
                });
                return {
                    success: true,
                    data: extraction,
                    provider: 'azure-foundry',
                    processingTime: Date.now() - startTime,
                    confidence: extraction.metadata?.overallConfidence
                };
            }
            // Fallback to Azure Form Recognizer
            if (this.availableServices.formRecognizer) {
                const extraction = await _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_2__/* .azureFormRecognizer */ .m.extractResumeData(fileBuffer, mimeType);
                return {
                    success: true,
                    data: extraction,
                    provider: 'azure-form-recognizer',
                    processingTime: Date.now() - startTime,
                    confidence: 0.85 // Default confidence for Form Recognizer
                };
            }
            throw new Error('No Azure document extraction services available');
        } catch (error) {
            console.error('❌ Azure resume extraction failed:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Extraction failed',
                provider: this.availableServices.foundry ? 'azure-foundry' : 'azure-form-recognizer',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Generate tailored resume content
   */ async tailorResume(resumeText, jobDescription, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const tailoredContent = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.tailorResume(resumeText, jobDescription);
                } else {
                    return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.tailorResume(resumeText, jobDescription);
                }
            }, 'azure_ai_tailor', options.userId, {
                maxRetries: 3,
                baseDelay: 2000
            });
            return {
                success: true,
                data: tailoredContent,
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        } catch (error) {
            console.error('❌ Azure AI resume tailoring failed:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Resume tailoring failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Generate cover letters
   */ async generateCoverLetter(resumeText, jobDescription, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const coverLetter = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateCoverLetter(resumeText, jobDescription);
                } else {
                    throw new Error('Cover letter generation requires enhanced Azure OpenAI service');
                }
            }, 'azure_ai_cover_letter', options.userId, {
                maxRetries: 3,
                baseDelay: 2000
            });
            return {
                success: true,
                data: coverLetter,
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        } catch (error) {
            console.error('❌ Azure AI cover letter generation failed:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Cover letter generation failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Calculate relevancy score between resume and job description
   */ async calculateRelevancy(resumeText, jobDescription) {
        await this.initialize();
        const startTime = Date.now();
        try {
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const score = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.calculateRelevancy(resumeText, jobDescription);
                } else {
                    throw new Error('Relevancy calculation requires enhanced Azure OpenAI service');
                }
            }, 'azure_ai_relevancy', undefined, {
                maxRetries: 2,
                baseDelay: 1000
            });
            return {
                success: true,
                data: Math.max(0, Math.min(100, score)),
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime,
                confidence: 0.9
            };
        } catch (error) {
            console.error('❌ Azure AI relevancy calculation failed:', error);
            return {
                success: false,
                data: 50,
                error: error instanceof Error ? error.message : 'Relevancy calculation failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    constructor(){
        this.initialized = false;
        this.availableServices = {
            openai: false,
            enhanced: false,
            formRecognizer: false,
            foundry: false
        };
    }
}
// Export singleton instance
const azureAI = new AzureAIService();
// For backward compatibility, export individual service references


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 94279:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   h: () => (/* binding */ enhancedAzureOpenAIService)
/* harmony export */ });
/* unused harmony export EnhancedAzureOpenAIService */
/* harmony import */ var _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95951);
/* harmony import */ var _lib_azure_config_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4514);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__]);
_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Enhanced Azure OpenAI Service with Multi-Deployment Support
 * 
 * This service provides intelligent model selection based on task type:
 * - gpt-35-turbo: Fast, cost-effective for simple tasks (relevancy scoring, basic Q&A)
 * - gpt-4o: Advanced reasoning for complex tasks (cover letters, resume tailoring)
 */ 

class EnhancedAzureOpenAIService {
    /**
   * Initialize the service with multiple deployment clients
   */ async initialize() {
        try {
            this.secrets = await (0,_lib_azure_config_browser__WEBPACK_IMPORTED_MODULE_1__/* .fetchAzureSecrets */ .lL)();
            if (!this.secrets.azureOpenAIKey || !this.secrets.azureOpenAIEndpoint) {
                console.warn('⚠️ Azure OpenAI credentials not available');
                return false;
            }
            // Initialize clients for different deployments
            const deployments = [
                {
                    name: 'gpt-4o',
                    deployment: this.secrets.azureOpenAIGpt35Deployment || 'gpt-4o'
                },
                {
                    name: 'gpt-4o',
                    deployment: this.secrets.azureOpenAIGpt4oDeployment || 'gpt-4o'
                },
                {
                    name: 'default',
                    deployment: this.secrets.azureOpenAIDeployment
                }
            ];
            for (const { name, deployment } of deployments){
                if (deployment) {
                    const client = new _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__/* .MigrationOpenAIClient */ .Ag();
                    await client.init(); // Initialize the migration client
                    this.clients.set(name, client);
                    console.log(`✅ Azure OpenAI client initialized for ${name} (${deployment})`);
                }
            }
            this.isInitialized = this.clients.size > 0;
            if (this.isInitialized) {
                console.log(`✅ Enhanced Azure OpenAI Service initialized with ${this.clients.size} clients`);
            }
            return this.isInitialized;
        } catch (error) {
            console.error('❌ Failed to initialize Enhanced Azure OpenAI Service:', error);
            return false;
        }
    }
    /**
   * Generate content using the optimal model for the task
   */ async generateContent(prompt, taskType, customOptions) {
        if (!this.isInitialized) {
            throw new Error('Enhanced Azure OpenAI Service not initialized');
        }
        const config = {
            ...this.taskConfigurations[taskType],
            ...customOptions
        };
        const client = this.clients.get(config.deployment) || this.clients.get('default');
        if (!client) {
            throw new Error(`No client available for deployment: ${config.deployment}`);
        }
        console.log(`🎯 Using ${config.deployment} for ${taskType} task`);
        const messages = [
            {
                role: 'user',
                content: prompt
            }
        ];
        try {
            const completion = await this.retryWithBackoff(async ()=>{
                return await client.chat.completions.create({
                    model: config.deployment,
                    messages,
                    temperature: config.temperature,
                    max_tokens: config.maxTokens,
                    top_p: config.topP || 0.9,
                    frequency_penalty: config.frequencyPenalty || 0.1,
                    presence_penalty: config.presencePenalty || 0.1
                });
            });
            const content = completion.choices[0]?.message?.content;
            if (!content) {
                throw new Error(`Empty response from Azure OpenAI (${config.deployment})`);
            }
            return content;
        } catch (error) {
            console.error(`❌ Error generating content with ${config.deployment}:`, error);
            throw error;
        }
    }
    /**
   * Generate cover letter using gpt-4o for high quality
   */ async generateCoverLetter(resumeText, jobDescription) {
        const prompt = `You are an expert career coach and professional writer. Please generate a compelling cover letter based on the provided resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Please generate a cover letter that:
1. Is tailored to the specific job description
2. Highlights the most relevant skills and experiences from the resume
3. Has a professional and engaging tone
4. Is well-structured and easy to read
5. Is approximately 3-4 paragraphs long

Return ONLY the cover letter content with no additional commentary or explanations.`;
        return await this.generateContent(prompt, 'cover-letter');
    }
    /**
   * Calculate relevancy score using gpt-35-turbo for efficiency
   */ async calculateRelevancy(resumeText, jobDescription) {
        const prompt = `You are an expert ATS (Applicant Tracking System) analyzer. Please analyze the relevancy between this resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Analyze the match between the resume and job description considering:
1. Skills alignment (technical and soft skills)
2. Experience relevance (years and type of experience)
3. Education and certifications match
4. Industry experience
5. Role responsibilities alignment
6. Keywords and terminology match

Return ONLY a single number between 0 and 100 representing the percentage match/relevancy score. No explanations or additional text.`;
        const response = await this.generateContent(prompt, 'relevancy');
        // Extract number from response
        const scoreMatch = response.trim().match(/\d+/);
        if (!scoreMatch) {
            throw new Error('Could not extract relevancy score from response');
        }
        const score = parseInt(scoreMatch[0], 10);
        return Math.max(0, Math.min(100, score)); // Ensure score is between 0-100
    }
    /**
   * Tailor resume using gpt-4o for quality
   */ async tailorResume(resumeText, jobDescription) {
        const prompt = `You are an expert resume writer and ATS optimization specialist. Please tailor this resume to better match the following job description for maximum ATS compatibility and relevance.

JOB DESCRIPTION:
${jobDescription}

CURRENT RESUME:
${resumeText}

Please provide a tailored version of the resume that:
1. Uses keywords and phrases directly from the job description
2. Highlights relevant skills and experiences that match the job requirements
3. Maintains professional formatting and ATS-friendly structure
4. Uses strong action verbs and quantifiable achievements
5. Keeps the same overall length and format structure
6. Optimizes for Applicant Tracking Systems (ATS)
7. Ensures keyword density without keyword stuffing

Return ONLY the tailored resume content with no additional commentary or explanations.`;
        return await this.generateContent(prompt, 'resume-tailor');
    }
    /**
   * Generate interview questions using gpt-35-turbo for efficiency
   */ async generateQuestions(resumeInfo) {
        const prompt = `You are an experienced interviewer. Based on the following resume information, generate 5 relevant interview questions that would help assess this candidate's qualifications and fit for their field.

RESUME INFORMATION:
Name: ${resumeInfo.name}
Experience: ${resumeInfo.experience}
Education: ${resumeInfo.education}
Skills: ${resumeInfo.skills}

Generate questions that:
1. Are specific to their experience level and field
2. Assess both technical and behavioral competencies
3. Are professional and engaging
4. Would help determine cultural fit
5. Allow the candidate to showcase their strengths

Format: Return exactly 5 questions, each on a new line, numbered 1-5. No additional text or explanations.`;
        const response = await this.generateContent(prompt, 'questions');
        // Parse questions from response
        const questions = response.split('\n').map((line)=>line.trim()).filter((line)=>line.length > 0).map((line)=>line.replace(/^\d+\.\s*/, '')) // Remove numbering
        .filter((line)=>line.length > 0).slice(0, 5); // Ensure max 5 questions
        if (questions.length === 0) {
            throw new Error('No questions could be parsed from response');
        }
        return questions;
    }
    /**
   * Retry mechanism with exponential backoff for rate limiting
   */ async retryWithBackoff(operation, maxRetries = 3, baseDelay = 1000) {
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                return await operation();
            } catch (error) {
                lastError = error;
                // Don't retry on non-retryable errors
                if (error.status && ![
                    429,
                    500,
                    502,
                    503,
                    504
                ].includes(error.status)) {
                    throw error;
                }
                if (attempt === maxRetries) {
                    throw error;
                }
                // Calculate delay with exponential backoff
                const delay = error.status === 429 ? parseInt(error.headers?.['retry-after'] || '10') * 1000 : baseDelay * Math.pow(2, attempt);
                console.log(`⏳ Retrying in ${delay}ms (attempt ${attempt + 1}/${maxRetries + 1})`);
                await new Promise((resolve)=>setTimeout(resolve, delay));
            }
        }
        throw lastError;
    }
    /**
   * Check if service is ready
   */ isReady() {
        return this.isInitialized && this.clients.size > 0;
    }
    /**
   * Get available deployments
   */ getAvailableDeployments() {
        return Array.from(this.clients.keys());
    }
    /**
   * Dispose of resources
   */ dispose() {
        this.clients.clear();
        this.isInitialized = false;
        console.log('🧹 Enhanced Azure OpenAI Service disposed');
    }
    constructor(){
        this.clients = new Map();
        this.isInitialized = false;
        this.secrets = null;
        // Task-specific configurations optimized for different models
        this.taskConfigurations = {
            // Fast tasks - use gpt-35-turbo for efficiency
            'relevancy': {
                deployment: 'gpt-4o',
                temperature: 0.1,
                maxTokens: 50,
                topP: 0.9,
                frequencyPenalty: 0.0,
                presencePenalty: 0.0
            },
            'questions': {
                deployment: 'gpt-4o',
                temperature: 0.5,
                maxTokens: 300,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            // Complex tasks - use gpt-4o for quality
            'cover-letter': {
                deployment: 'gpt-4o',
                temperature: 0.7,
                maxTokens: 1500,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            'resume-tailor': {
                deployment: 'gpt-4o',
                temperature: 0.3,
                maxTokens: 2000,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            // Interview tasks - use gpt-4o for nuanced conversation
            'interview': {
                deployment: 'gpt-4o',
                temperature: 0.7,
                maxTokens: 200,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            }
        };
    }
}
// Export singleton instance
const enhancedAzureOpenAIService = new EnhancedAzureOpenAIService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;