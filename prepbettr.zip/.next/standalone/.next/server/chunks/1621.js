exports.id = 1621;
exports.ids = [1621];
exports.modules = {

/***/ 22082:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ac: () => (/* binding */ getModelConfig),
/* harmony export */   I6: () => (/* binding */ validateFoundryConfig),
/* harmony export */   at: () => (/* binding */ getFoundryConfig),
/* harmony export */   fZ: () => (/* binding */ getDefaultModel)
/* harmony export */ });
/* unused harmony exports clearFoundryConfigCache, getEnvironmentDefaults, getDefaultModelConfigurations, getDefaultConnectionSettings, getFoundryConfigForEnvironment */
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10756);
/* harmony import */ var _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36695);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__]);
([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure AI Foundry Configuration
 * 
 * This module handles configuration for Azure AI Foundry services,
 * including model configurations, retry policies, and connection settings.
 * Follows the existing pattern established in lib/azure-config.ts.
 */ 

// Client-side safety check
const isClient = "undefined" !== 'undefined';
if (isClient) {
    console.warn('[Azure AI Foundry Config] Running on client side - using fallback implementations');
}
// Azure Key Vault configuration (reuse existing vault)
const AZURE_KEY_VAULT_URI = process.env.AZURE_KEY_VAULT_URI || 'https://prepbettr-keyvault-083.vault.azure.net/';
let cachedFoundryConfig = null;
/**
 * Initialize Azure Key Vault client (reusing existing pattern)
 */ function createKeyVaultClient() {
    if (!AZURE_KEY_VAULT_URI) {
        throw new Error('AZURE_KEY_VAULT_URI environment variable is required');
    }
    const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_0__.DefaultAzureCredential();
    return new _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__.SecretClient(AZURE_KEY_VAULT_URI, credential);
}
/**
 * Clear cached foundry configuration
 */ function clearFoundryConfigCache() {
    if (isClient) return;
    console.log('🔄 Clearing Azure AI Foundry config cache...');
    cachedFoundryConfig = null;
}
/**
 * Fetch Azure AI Foundry configuration from Azure Key Vault with environment variable fallback
 * 
 * @param forceRefresh - Force refresh the cached configuration
 * @returns Promise<FoundryConfig> - The foundry configuration
 */ async function getFoundryConfig(forceRefresh = false) {
    if (isClient) {
        // Client-side fallback - return empty config with all required fields
        return {
            endpoint: '',
            apiKey: '',
            projectId: '',
            resourceId: '',
            resourceGroup: '',
            region: '',
            models: {},
            connection: getDefaultConnectionSettings(),
            environment: 'development'
        };
    }
    // Clear cache if force refresh is requested
    if (forceRefresh) {
        clearFoundryConfigCache();
    }
    // Return cached configuration if available
    if (cachedFoundryConfig) {
        return cachedFoundryConfig;
    }
    try {
        console.log('🔑 Fetching Azure AI Foundry configuration from Key Vault...');
        const client = createKeyVaultClient();
        // Helper function to suppress expected 404 errors for optional secrets
        const getOptionalSecret = (name)=>client.getSecret(name).catch((err)=>{
                if (err.statusCode !== 404) {
                    console.warn(`⚠️ Unexpected error fetching optional secret '${name}':`, err.message);
                }
                return null;
            });
        // Fetch foundry-specific secrets
        const [foundryEndpoint, foundryApiKey, foundryProjectId, foundryResourceGroup, foundryRegion, foundryDeploymentName, docIntEndpoint, docIntApiKey, docIntProjectId] = await Promise.all([
            getOptionalSecret('azure-foundry-endpoint'),
            getOptionalSecret('azure-foundry-api-key'),
            getOptionalSecret('azure-foundry-project-id'),
            getOptionalSecret('azure-foundry-resource-group'),
            getOptionalSecret('azure-foundry-region'),
            getOptionalSecret('azure-foundry-deployment-name'),
            getOptionalSecret('azure-foundry-docint-endpoint'),
            getOptionalSecret('azure-foundry-docint-api-key'),
            getOptionalSecret('azure-foundry-docint-project-id')
        ]);
        cachedFoundryConfig = {
            endpoint: foundryEndpoint?.value || process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: foundryApiKey?.value || process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: foundryProjectId?.value || process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: foundryResourceGroup?.value || process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            region: foundryRegion?.value || process.env.AZURE_FOUNDRY_REGION || 'eastus',
            environment: "production" || 0 || 0,
            models: getDefaultModelConfigurations(),
            connection: getDefaultConnectionSettings(),
            docIntelligence: docIntEndpoint?.value || docIntApiKey?.value || process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || process.env.AZURE_FOUNDRY_DOCINT_API_KEY ? {
                endpoint: docIntEndpoint?.value || process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || '',
                apiKey: docIntApiKey?.value || process.env.AZURE_FOUNDRY_DOCINT_API_KEY || '',
                projectId: docIntProjectId?.value || process.env.AZURE_FOUNDRY_DOCINT_PROJECT_ID,
                region: foundryRegion?.value || process.env.AZURE_FOUNDRY_REGION || 'eastus'
            } : undefined
        };
        // Validate required configuration
        const requiredFields = [
            'endpoint',
            'apiKey',
            'projectId',
            'resourceGroup'
        ];
        const missingFields = requiredFields.filter((field)=>!cachedFoundryConfig[field]);
        if (missingFields.length > 0) {
            console.warn(`⚠️ Azure AI Foundry missing configuration: ${missingFields.join(', ')}`);
            console.log('💡 Add these secrets to Azure Key Vault or set environment variables:');
            missingFields.forEach((field)=>{
                const envVar = `AZURE_FOUNDRY_${field.toUpperCase()}`;
                console.log(`   - ${envVar}`);
            });
        } else {
            console.log('✅ Azure AI Foundry configuration loaded successfully');
        }
        return cachedFoundryConfig;
    } catch (error) {
        console.error('❌ Failed to fetch Azure AI Foundry configuration:', error);
        // Fallback to environment variables
        console.log('🔄 Falling back to environment variables for Azure AI Foundry...');
        const fallbackConfig = {
            endpoint: process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            region: process.env.AZURE_FOUNDRY_REGION || 'eastus',
            environment: "production" || 0 || 0,
            models: getDefaultModelConfigurations(),
            connection: getDefaultConnectionSettings(),
            docIntelligence: process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || process.env.AZURE_FOUNDRY_DOCINT_API_KEY ? {
                endpoint: process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || '',
                apiKey: process.env.AZURE_FOUNDRY_DOCINT_API_KEY || '',
                projectId: process.env.AZURE_FOUNDRY_DOCINT_PROJECT_ID,
                region: process.env.AZURE_FOUNDRY_REGION || 'eastus'
            } : undefined
        };
        // Log missing critical configuration
        if (!fallbackConfig.endpoint || !fallbackConfig.apiKey) {
            console.error('❌ Critical Azure AI Foundry configuration missing from environment variables');
            console.log('💡 Set AZURE_FOUNDRY_ENDPOINT and AZURE_FOUNDRY_API_KEY environment variables');
        }
        cachedFoundryConfig = fallbackConfig;
        return cachedFoundryConfig;
    }
}
/**
 * Get environment-specific configuration defaults
 */ function getEnvironmentDefaults() {
    const environment = "production" || 0 || 0;
    const defaults = {
        development: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        },
        staging: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        },
        production: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        }
    };
    return defaults[environment] || defaults.development;
}
/**
 * Get default model configurations for Azure AI Foundry
 */ function getDefaultModelConfigurations() {
    return {
        'gpt-4o': {
            deploymentName: process.env.AZURE_FOUNDRY_GPT4O_DEPLOYMENT || 'gpt-4o',
            modelName: 'gpt-4o',
            version: '2024-05-13',
            maxTokens: 4096,
            temperature: 0.7,
            topP: 0.9,
            frequencyPenalty: 0,
            presencePenalty: 0,
            costPerToken: 0.005,
            capabilities: [
                'text-generation',
                'reasoning',
                'coding',
                'analysis'
            ],
            isDefault: true
        },
        'gpt-4-turbo': {
            deploymentName: process.env.AZURE_FOUNDRY_GPT4_TURBO_DEPLOYMENT || 'gpt-4-turbo',
            modelName: 'gpt-4-turbo',
            version: '2024-04-09',
            maxTokens: 4096,
            temperature: 0.7,
            topP: 0.9,
            frequencyPenalty: 0,
            presencePenalty: 0,
            costPerToken: 0.01,
            capabilities: [
                'text-generation',
                'reasoning',
                'coding',
                'analysis',
                'function-calling'
            ]
        },
        'phi-4': {
            deploymentName: process.env.AZURE_FOUNDRY_PHI4_DEPLOYMENT || 'phi-4',
            modelName: 'phi-4',
            version: '2024-12-12',
            maxTokens: 2048,
            temperature: 0.6,
            topP: 0.85,
            frequencyPenalty: 0.1,
            presencePenalty: 0.1,
            costPerToken: 0.001,
            capabilities: [
                'text-generation',
                'reasoning',
                'lightweight-tasks'
            ]
        }
    };
}
/**
 * Get default connection settings
 */ function getDefaultConnectionSettings() {
    const environment = "production" || 0 || 0;
    return {
        timeout: environment === 'production' ? 30000 : 60000,
        keepAlive: true,
        maxConnections: environment === 'production' ? 10 : 5,
        retryPolicy: {
            maxRetries: 3,
            baseDelay: 1000,
            maxDelay: 10000,
            exponentialBase: 2,
            jitter: true
        }
    };
}
/**
 * Get model configuration by name
 */ function getModelConfig(modelName) {
    const models = getDefaultModelConfigurations();
    return models[modelName] || null;
}
/**
 * Get default model configuration
 */ function getDefaultModel() {
    const models = getDefaultModelConfigurations();
    const defaultModel = Object.values(models).find((model)=>model.isDefault);
    return defaultModel || models['gpt-4o'];
}
/**
 * Validate foundry configuration
 */ function validateFoundryConfig(config) {
    const errors = [];
    if (!config.endpoint) {
        errors.push('Missing foundry endpoint');
    }
    if (!config.apiKey) {
        errors.push('Missing foundry API key');
    }
    if (!config.projectId) {
        errors.push('Missing foundry project ID');
    }
    if (!config.resourceGroup) {
        errors.push('Missing foundry resource group');
    }
    // Validate endpoint format
    if (config.endpoint && !config.endpoint.startsWith('https://')) {
        errors.push('Foundry endpoint must use HTTPS');
    }
    // Validate models configuration
    const models = Object.values(config.models);
    if (models.length === 0) {
        errors.push('No models configured');
    }
    const hasDefault = models.some((model)=>model.isDefault);
    if (!hasDefault) {
        errors.push('No default model configured');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * Get foundry configuration for specific environment
 */ async function getFoundryConfigForEnvironment(environment) {
    // Get config without modifying process.env to avoid webpack issues
    const config = await getFoundryConfig(true); // Force refresh
    // Override the environment in the returned config
    return {
        ...config,
        environment
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 49359:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   K: () => (/* binding */ getVoiceLiveClient)
/* harmony export */ });
/* unused harmony export VoiceLiveClient */
/* harmony import */ var _foundry_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(64383);
/* harmony import */ var _voice_telemetry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(90342);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_foundry_environment__WEBPACK_IMPORTED_MODULE_0__]);
_foundry_environment__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Azure AI Foundry Voice Live Client
 * 
 * Provides real-time voice streaming capabilities using Azure AI Foundry's voice services.
 * Features WebSocket-based audio streaming, exponential backoff retry logic, and session management.
 */ 

/**
 * WebSocket Manager with exponential backoff and retry logic
 */ class WebSocketManager {
    constructor(url, protocols){
        this.url = url;
        this.protocols = protocols;
        this.ws = null;
        this.connectionState = 'disconnected';
        this.retryCount = 0;
        this.maxRetries = 5;
        this.baseDelay = 1000;
        this.maxDelay = 30000;
        this.retryTimeoutId = null;
        this.eventListeners = new Map();
    }
    /**
   * Connect to WebSocket with retry logic
   */ async connect() {
        if (this.connectionState === 'connected' || this.connectionState === 'connecting') {
            return;
        }
        this.connectionState = 'connecting';
        console.log(`🔌 [WebSocketManager] Connecting to ${this.url}...`);
        // Track connection attempt
        const connectionStartTime = Date.now();
        _voice_telemetry__WEBPACK_IMPORTED_MODULE_1__/* .VoiceTelemetry */ .Ev.trackConnection('connecting', 'websocket', {
            retryCount: this.retryCount
        });
        try {
            this.ws = new WebSocket(this.url, this.protocols);
            this.ws.onopen = ()=>{
                const connectionTime = Date.now() - connectionStartTime;
                console.log('✅ [WebSocketManager] Connected successfully');
                this.connectionState = 'connected';
                this.retryCount = 0; // Reset retry count on successful connection
                // Track successful connection
                _voice_telemetry__WEBPACK_IMPORTED_MODULE_1__/* .VoiceTelemetry */ .Ev.trackConnection('connected', 'websocket', {
                    connectionTime,
                    retryCount: 0
                });
                this.emit('connected', null);
            };
            this.ws.onclose = (event)=>{
                console.log(`🔌 [WebSocketManager] Connection closed: ${event.code} ${event.reason}`);
                this.connectionState = 'disconnected';
                // Track disconnection with reason
                _voice_telemetry__WEBPACK_IMPORTED_MODULE_1__/* .VoiceTelemetry */ .Ev.trackConnection('disconnected', 'websocket', {
                    disconnectionReason: `${event.code}: ${event.reason}`,
                    retryCount: this.retryCount
                });
                this.emit('disconnected', {
                    code: event.code,
                    reason: event.reason
                });
                // Auto-retry if not a normal closure
                if (event.code !== 1000 && this.retryCount < this.maxRetries) {
                    this.scheduleReconnect();
                }
            };
            this.ws.onerror = (error)=>{
                console.error('❌ [WebSocketManager] Connection error:', error);
                this.connectionState = 'error';
                this.emit('error', error);
            };
            this.ws.onmessage = (event)=>{
                try {
                    const message = JSON.parse(event.data);
                    console.log(`📨 [WebSocketManager] Received message type: ${message.type}`);
                    this.emit('message', message);
                    this.emit(message.type, message.data);
                } catch (error) {
                    console.error('❌ [WebSocketManager] Failed to parse message:', error);
                    // Handle binary audio data
                    if (event.data instanceof ArrayBuffer || event.data instanceof Blob) {
                        this.emit('binaryData', event.data);
                    }
                }
            };
            // Wait for connection to establish or fail
            await this.waitForConnection();
        } catch (error) {
            console.error('❌ [WebSocketManager] Connection failed:', error);
            this.connectionState = 'error';
            // Track connection failure
            const connectionError = new _voice_telemetry__WEBPACK_IMPORTED_MODULE_1__/* .VoiceConnectionError */ .Xl(`Connection failed: ${error instanceof Error ? error.message : String(error)}`, 'websocket', this.retryCount, error instanceof Error ? error : undefined);
            _voice_telemetry__WEBPACK_IMPORTED_MODULE_1__/* .VoiceTelemetry */ .Ev.trackError(connectionError, 'websocket', 'WebSocket Connection', false);
            if (this.retryCount < this.maxRetries) {
                this.scheduleReconnect();
            } else {
                throw connectionError;
            }
        }
    }
    /**
   * Send data through WebSocket
   */ send(data) {
        if (this.connectionState !== 'connected' || !this.ws) {
            console.warn('⚠️ [WebSocketManager] Cannot send: not connected');
            return false;
        }
        try {
            this.ws.send(data);
            return true;
        } catch (error) {
            console.error('❌ [WebSocketManager] Send failed:', error);
            return false;
        }
    }
    /**
   * Send audio frame with proper formatting
   */ sendAudioFrame(frame) {
        const message = {
            type: 'audio',
            data: {
                audioData: Array.from(new Uint8Array(frame.audioData)),
                timestamp: frame.timestamp,
                sampleRate: frame.sampleRate,
                channels: frame.channels
            },
            timestamp: Date.now()
        };
        return this.send(JSON.stringify(message));
    }
    /**
   * Close WebSocket connection
   */ close(code = 1000, reason = 'Normal closure') {
        console.log(`🔌 [WebSocketManager] Closing connection: ${code} ${reason}`);
        if (this.retryTimeoutId) {
            clearTimeout(this.retryTimeoutId);
            this.retryTimeoutId = null;
        }
        if (this.ws) {
            this.connectionState = 'closed';
            this.ws.close(code, reason);
            this.ws = null;
        }
        this.eventListeners.clear();
    }
    /**
   * Get current connection state
   */ getState() {
        return this.connectionState;
    }
    /**
   * Add event listener
   */ on(event, callback) {
        if (!this.eventListeners.has(event)) {
            this.eventListeners.set(event, new Set());
        }
        this.eventListeners.get(event).add(callback);
    }
    /**
   * Remove event listener
   */ off(event, callback) {
        this.eventListeners.get(event)?.delete(callback);
    }
    /**
   * Emit event to listeners
   */ emit(event, data) {
        this.eventListeners.get(event)?.forEach((callback)=>{
            try {
                callback(data);
            } catch (error) {
                console.error(`❌ [WebSocketManager] Event listener error for ${event}:`, error);
            }
        });
    }
    /**
   * Wait for WebSocket connection to establish
   */ waitForConnection() {
        return new Promise((resolve, reject)=>{
            const timeout = setTimeout(()=>{
                reject(new Error('Connection timeout'));
            }, 10000); // 10 second timeout
            const onConnected = ()=>{
                clearTimeout(timeout);
                this.off('connected', onConnected);
                this.off('error', onError);
                resolve();
            };
            const onError = (error)=>{
                clearTimeout(timeout);
                this.off('connected', onConnected);
                this.off('error', onError);
                reject(error);
            };
            this.on('connected', onConnected);
            this.on('error', onError);
        });
    }
    /**
   * Schedule reconnection with exponential backoff
   */ scheduleReconnect() {
        this.retryCount++;
        const delay = Math.min(this.baseDelay * Math.pow(2, this.retryCount - 1) + Math.random() * 1000, this.maxDelay);
        console.log(`🔄 [WebSocketManager] Scheduling reconnect attempt ${this.retryCount}/${this.maxRetries} in ${delay}ms`);
        this.retryTimeoutId = setTimeout(()=>{
            this.connect().catch((error)=>{
                console.error('❌ [WebSocketManager] Reconnection failed:', error);
            });
        }, delay);
    }
}
/**
 * Azure AI Foundry Voice Live Client
 */ class VoiceLiveClient {
    /**
   * Initialize the client with configuration
   */ async init(forceRefresh = false) {
        console.log('🔧 [VoiceLiveClient] Initializing...');
        this.config = await (0,_foundry_environment__WEBPACK_IMPORTED_MODULE_0__/* .getEnv */ ._$)(forceRefresh);
        const validation = (0,_foundry_environment__WEBPACK_IMPORTED_MODULE_0__/* .validateVoiceConfig */ .LJ)(this.config);
        if (!validation.isValid) {
            throw new Error(`Invalid voice configuration: ${validation.errors.join(', ')}`);
        }
        console.log('✅ [VoiceLiveClient] Initialized successfully');
    }
    /**
   * Create a new voice session with default settings
   */ async createSession(options = {}) {
        if (!this.config) {
            await this.init();
        }
        // Apply default settings
        const sessionOptions = {
            voiceName: options.voiceName || 'neural-hd-professional',
            locale: options.locale || 'en-US',
            speakingRate: options.speakingRate || 1.0,
            emotionalTone: options.emotionalTone || 'neutral',
            audioSettings: {
                noiseSuppression: true,
                echoCancellation: true,
                interruptionDetection: true,
                sampleRate: 16000,
                ...options.audioSettings
            }
        };
        console.log('🎤 [VoiceLiveClient] Creating voice session with options:', sessionOptions);
        try {
            // Call Azure AI Foundry API to create session
            const response = await fetch(`${this.config.endpoint}/openai/realtime/sessions`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api-key': this.config.apiKey,
                    'X-Project-ID': this.config.projectId
                },
                body: JSON.stringify({
                    model: this.config.deploymentName || 'gpt-4o-realtime-preview',
                    voice: sessionOptions.voiceName,
                    input_audio_format: 'pcm16',
                    output_audio_format: 'pcm16',
                    turn_detection: sessionOptions.audioSettings?.interruptionDetection ? {
                        type: 'server_vad',
                        threshold: 0.5,
                        prefix_padding_ms: 300,
                        silence_duration_ms: 800
                    } : null,
                    tools: [],
                    tool_choice: 'none',
                    temperature: 0.7,
                    max_response_output_tokens: 4096
                })
            });
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Session creation failed: ${response.status} ${response.statusText} - ${errorText}`);
            }
            const sessionData = await response.json();
            const session = {
                sessionId: sessionData.id,
                wsUrl: sessionData.websocket_url,
                options: sessionOptions,
                createdAt: new Date()
            };
            // Store session for later reference
            this.activeSessions.set(session.sessionId, session);
            console.log(`✅ [VoiceLiveClient] Session created: ${session.sessionId}`);
            return session;
        } catch (error) {
            console.error('❌ [VoiceLiveClient] Session creation failed:', error);
            throw error;
        }
    }
    /**
   * Create WebSocket manager for a session
   */ createWebSocketManager(session) {
        return new WebSocketManager(session.wsUrl, [
            'realtime'
        ]);
    }
    /**
   * Update voice settings for active sessions
   */ updateSettings(sessionId, settings) {
        const session = this.activeSessions.get(sessionId);
        if (!session) {
            console.warn(`⚠️ [VoiceLiveClient] Session not found: ${sessionId}`);
            return false;
        }
        // Update session options
        Object.assign(session.options, settings);
        console.log(`🔧 [VoiceLiveClient] Updated settings for session ${sessionId}:`, settings);
        return true;
    }
    /**
   * Get active session by ID
   */ getSession(sessionId) {
        return this.activeSessions.get(sessionId);
    }
    /**
   * Remove session from active sessions
   */ removeSession(sessionId) {
        this.activeSessions.delete(sessionId);
        console.log(`🗑️ [VoiceLiveClient] Removed session: ${sessionId}`);
    }
    /**
   * Get all active sessions
   */ getActiveSessions() {
        return Array.from(this.activeSessions.values());
    }
    /**
   * Cleanup all sessions
   */ cleanup() {
        console.log('🧹 [VoiceLiveClient] Cleaning up all sessions');
        this.activeSessions.clear();
    }
    constructor(){
        this.config = null;
        this.activeSessions = new Map();
    }
}
// Singleton instance
let voiceLiveClientInstance = null;
/**
 * Get shared VoiceLiveClient instance
 */ function getVoiceLiveClient() {
    if (!voiceLiveClientInstance) {
        voiceLiveClientInstance = new VoiceLiveClient();
    }
    return voiceLiveClientInstance;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 64383:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LJ: () => (/* binding */ validateVoiceConfig),
/* harmony export */   _$: () => (/* binding */ getEnv)
/* harmony export */ });
/* unused harmony export clearVoiceConfigCache */
/* harmony import */ var _config_foundry_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(22082);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_foundry_config__WEBPACK_IMPORTED_MODULE_0__]);
_config_foundry_config__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Azure AI Foundry Environment Configuration
 * 
 * Provides a getEnv() utility function that fetches Azure AI Foundry configuration
 * from Azure Key Vault with environment variable fallback.
 * Follows the existing pattern from the project's foundry-config.ts.
 */ 
/**
 * Cache for environment configuration to avoid repeated Azure Key Vault calls
 */ let cachedVoiceConfig = null;
/**
 * Get environment configuration for voice services
 * Uses Azure Key Vault with environment variable fallback
 * 
 * @param forceRefresh - Force refresh the cached configuration
 * @returns Promise<VoiceEnvironmentConfig>
 */ async function getEnv(forceRefresh = false) {
    if (cachedVoiceConfig && !forceRefresh) {
        return cachedVoiceConfig;
    }
    try {
        // Use existing foundry config which already handles Key Vault + env fallback
        const foundryConfig = await (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_0__/* .getFoundryConfig */ .at)(forceRefresh);
        cachedVoiceConfig = {
            endpoint: foundryConfig.endpoint,
            apiKey: foundryConfig.apiKey,
            projectId: foundryConfig.projectId,
            region: foundryConfig.region,
            resourceId: foundryConfig.resourceId,
            resourceGroup: foundryConfig.resourceGroup,
            deploymentName: process.env.AZURE_FOUNDRY_DEPLOYMENT_NAME || 'gpt-4o'
        };
        // Validate required fields for voice client
        const requiredFields = [
            'endpoint',
            'apiKey',
            'projectId',
            'region'
        ];
        const missingFields = requiredFields.filter((field)=>!cachedVoiceConfig[field]);
        if (missingFields.length > 0) {
            throw new Error(`Missing required Azure AI Foundry voice configuration: ${missingFields.join(', ')}`);
        }
        console.log('✅ Azure AI Foundry voice configuration loaded successfully');
        return cachedVoiceConfig;
    } catch (error) {
        console.error('❌ Failed to load Azure AI Foundry voice configuration:', error);
        // Fallback: try direct environment variables as last resort
        const fallbackConfig = {
            endpoint: process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            region: process.env.AZURE_FOUNDRY_REGION || 'eastus',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            deploymentName: process.env.AZURE_FOUNDRY_DEPLOYMENT_NAME || 'gpt-4o'
        };
        // Final validation
        if (!fallbackConfig.endpoint || !fallbackConfig.apiKey) {
            throw new Error('Critical Azure AI Foundry voice configuration missing. ' + 'Ensure AZURE_FOUNDRY_ENDPOINT and AZURE_FOUNDRY_API_KEY are set.');
        }
        cachedVoiceConfig = fallbackConfig;
        console.warn('⚠️ Using fallback environment configuration for Azure AI Foundry voice');
        return cachedVoiceConfig;
    }
}
/**
 * Clear cached configuration (useful for testing)
 */ function clearVoiceConfigCache() {
    cachedVoiceConfig = null;
}
/**
 * Validate voice environment configuration
 */ function validateVoiceConfig(config) {
    const errors = [];
    if (!config.endpoint) {
        errors.push('Missing endpoint');
    } else if (!config.endpoint.startsWith('https://')) {
        errors.push('Endpoint must use HTTPS');
    }
    if (!config.apiKey) {
        errors.push('Missing API key');
    }
    if (!config.projectId) {
        errors.push('Missing project ID');
    }
    if (!config.region) {
        errors.push('Missing region');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 80922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N7: () => (/* binding */ reportError),
/* harmony export */   p6: () => (/* binding */ showErrorNotification),
/* harmony export */   z$: () => (/* binding */ handleAsyncError)
/* harmony export */ });
/* unused harmony exports withRetry, withTimeout, safeJsonParse, handleApiError, ValidationError, AudioError */
/* harmony import */ var _logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(97502);
/**
 * Error handling utilities to centralize try-catch patterns
 * Reduces duplicate error handling code throughout the application
 */ 
/**
 * Standardized error reporting with context
 */ const reportError = (error, context, additionalContext)=>{
    const err = error instanceof Error ? error : new Error(String(error));
    _logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.error(`${context}: ${err.message}`, err, additionalContext);
    return err;
};
/**
 * Wrap async functions with standardized error handling
 */ const handleAsyncError = async (fn, context, fallback, additionalContext)=>{
    try {
        return await fn();
    } catch (error) {
        reportError(error, context, additionalContext);
        return fallback;
    }
};
/**
 * Retry wrapper with exponential backoff
 */ const withRetry = async (fn, maxAttempts = 3, context = 'Operation', baseDelay = 1000)=>{
    let attempt = 0;
    while(attempt < maxAttempts){
        try {
            return await fn();
        } catch (error) {
            attempt++;
            if (attempt >= maxAttempts) {
                throw reportError(error, `${context} failed after ${maxAttempts} attempts`);
            }
            const delay = Math.pow(2, attempt) * baseDelay;
            logger.warn(`${context} attempt ${attempt} failed, retrying in ${delay}ms`, {
                error
            });
            await new Promise((resolve)=>setTimeout(resolve, delay));
        }
    }
    throw new Error(`${context}: Exhausted all retry attempts`);
};
/**
 * Timeout wrapper for promises
 */ const withTimeout = (promise, timeoutMs, context = 'Operation')=>{
    return Promise.race([
        promise,
        new Promise((_, reject)=>{
            setTimeout(()=>{
                reject(new Error(`${context} timed out after ${timeoutMs}ms`));
            }, timeoutMs);
        })
    ]);
};
/**
 * Safe JSON parsing with error handling
 */ const safeJsonParse = (jsonString, fallback, context = 'JSON parse')=>{
    try {
        return JSON.parse(jsonString);
    } catch (error) {
        reportError(error, `${context} failed`, {
            jsonString: jsonString.slice(0, 100)
        });
        return fallback;
    }
};
/**
 * Network request error handler with user-friendly messages
 */ const handleApiError = (response, context = 'API request')=>{
    const friendlyMessages = {
        400: 'Invalid request. Please check your input and try again.',
        401: 'Authentication failed. Please sign in again.',
        403: 'Access denied. You may not have permission for this action.',
        404: 'The requested resource was not found.',
        429: 'Too many requests. Please wait a moment before trying again.',
        500: 'Server error. Please try again later.',
        502: 'Service temporarily unavailable. Please try again later.',
        503: 'Service temporarily unavailable. Please try again later.'
    };
    const friendlyMessage = friendlyMessages[response.status] || 'An unexpected error occurred.';
    const technicalMessage = `${context}: HTTP ${response.status} ${response.statusText}`;
    const error = new Error(friendlyMessage);
    error.technicalMessage = technicalMessage;
    error.status = response.status;
    return error;
};
/**
 * Show user-friendly error notification (replace alert() calls)
 * This will hook into the app's existing toast system
 */ const showErrorNotification = (error, context)=>{
    const message = typeof error === 'string' ? error : error.message;
    const fullMessage = context ? `${context}: ${message}` : message;
    // Use console.warn for user notifications to reduce error noise
    _logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('User notification: ' + fullMessage);
// TODO: Replace with actual toast notification system
// toast.error(fullMessage);
};
/**
 * Validation error for form/input validation
 */ class ValidationError extends Error {
    constructor(message, field){
        super(message), this.field = field;
        this.name = 'ValidationError';
    }
}
/**
 * Audio processing specific error
 */ class AudioError extends Error {
    constructor(message, audioContext){
        super(message), this.audioContext = audioContext;
        this.name = 'AudioError';
    }
}


/***/ }),

/***/ 90342:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ev: () => (/* binding */ VoiceTelemetry),
/* harmony export */   Xl: () => (/* binding */ VoiceConnectionError)
/* harmony export */ });
/* unused harmony exports VoiceAudioError, VoiceSessionError, VoiceTelemetryService, getVoiceTelemetry, voiceTelemetry */
/* harmony import */ var _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(97502);
/* harmony import */ var _lib_utils_error_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(80922);
/**
 * Azure AI Foundry Voice Telemetry
 * 
 * Provides structured logging, error handling, and metrics collection
 * specifically for the voice system with Application Insights integration.
 */ 

/**
 * Voice system specific errors with context
 */ class VoiceConnectionError extends Error {
    constructor(message, sessionId, retryCount, lastError){
        super(message), this.sessionId = sessionId, this.retryCount = retryCount, this.lastError = lastError;
        this.name = 'VoiceConnectionError';
    }
}
class VoiceAudioError extends Error {
    constructor(message, sessionId, audioContext, sampleRate){
        super(message), this.sessionId = sessionId, this.audioContext = audioContext, this.sampleRate = sampleRate;
        this.name = 'VoiceAudioError';
    }
}
class VoiceSessionError extends Error {
    constructor(message, sessionId, sessionState, lastAction){
        super(message), this.sessionId = sessionId, this.sessionState = sessionState, this.lastAction = lastAction;
        this.name = 'VoiceSessionError';
    }
}
/**
 * Voice Telemetry Service
 */ class VoiceTelemetryService {
    /**
   * Initialize telemetry for a session
   */ startSession(sessionId, userId) {
        this.sessionStartTime = Date.now();
        this.lastEventTime = this.sessionStartTime;
        this.logEvent('voice_session_started', {
            sessionId,
            userId,
            userAgent: navigator.userAgent,
            timestamp: this.sessionStartTime
        });
        // Initialize metrics
        this.connectionMetrics = {};
        this.audioMetrics = {
            bufferUnderruns: 0
        };
        this.sessionMetrics = {
            messageCount: 0,
            errorCount: 0
        };
    }
    /**
   * Log connection events with metrics
   */ logConnectionEvent(event, sessionId, metrics) {
        const now = Date.now();
        const latency = now - this.lastEventTime;
        this.logEvent(`voice_connection_${event}`, {
            sessionId,
            latency,
            ...metrics
        }, {
            connection_time: metrics?.connectionTime || 0,
            retry_count: metrics?.retryCount || 0,
            network_latency: metrics?.networkLatency || latency
        });
        // Update connection metrics
        Object.assign(this.connectionMetrics, metrics);
        // Log specific connection issues
        if (event === 'failed' || event === 'disconnected') {
            this.sessionMetrics.errorCount = (this.sessionMetrics.errorCount || 0) + 1;
            if (metrics?.disconnectionReason) {
                _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn(`Voice connection ${event}: ${metrics.disconnectionReason}`, {
                    sessionId,
                    retryCount: metrics.retryCount,
                    ...metrics
                });
            }
        }
        this.lastEventTime = now;
    }
    /**
   * Log audio processing events with performance metrics
   */ logAudioEvent(event, sessionId, metrics) {
        const now = Date.now();
        const eventLatency = now - this.lastEventTime;
        this.logEvent(`voice_audio_${event}`, {
            sessionId,
            eventLatency,
            ...metrics
        }, {
            stt_latency: metrics?.sttLatency || 0,
            tts_latency: metrics?.ttsLatency || 0,
            audio_quality: metrics?.audioQuality || 0,
            voice_activity: metrics?.voiceActivity || 0
        });
        // Update audio metrics
        Object.assign(this.audioMetrics, metrics);
        // Track buffer issues
        if (event === 'buffer_underrun') {
            this.audioMetrics.bufferUnderruns = (this.audioMetrics.bufferUnderruns || 0) + 1;
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('Audio buffer underrun detected', {
                sessionId,
                ...metrics
            });
        }
        // Log performance warnings
        if (metrics?.sttLatency && metrics.sttLatency > 2000) {
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('High STT latency detected', {
                sessionId,
                latency: metrics.sttLatency,
                threshold: 2000
            });
        }
        if (metrics?.ttsLatency && metrics.ttsLatency > 1500) {
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('High TTS latency detected', {
                sessionId,
                latency: metrics.ttsLatency,
                threshold: 1500
            });
        }
        this.lastEventTime = now;
    }
    /**
   * Log transcript events with accuracy metrics
   */ logTranscriptEvent(event, sessionId, text, confidence) {
        this.logEvent(`voice_${event}`, {
            sessionId,
            textLength: text.length,
            confidence,
            preview: text.substring(0, 50) + (text.length > 50 ? '...' : '')
        }, {
            text_length: text.length,
            confidence: confidence || 0
        });
        // Track message count and accuracy
        if (event === 'transcript_final') {
            this.sessionMetrics.messageCount = (this.sessionMetrics.messageCount || 0) + 1;
            if (confidence) {
                const currentAccuracy = this.sessionMetrics.transcriptAccuracy || 0;
                const messageCount = this.sessionMetrics.messageCount || 1;
                this.sessionMetrics.transcriptAccuracy = (currentAccuracy * (messageCount - 1) + confidence) / messageCount;
            }
        }
        // Log low confidence warnings
        if (confidence && confidence < 0.7) {
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('Low transcript confidence', {
                sessionId,
                confidence,
                text: text.substring(0, 100),
                threshold: 0.7
            });
        }
    }
    /**
   * Log session lifecycle events
   */ logSessionEvent(event, sessionId, details) {
        const now = Date.now();
        const sessionDuration = this.sessionStartTime ? now - this.sessionStartTime : 0;
        this.logEvent(`voice_${event}`, {
            sessionId,
            sessionDuration,
            ...details
        }, {
            session_duration: sessionDuration,
            message_count: this.sessionMetrics.messageCount || 0,
            error_count: this.sessionMetrics.errorCount || 0
        });
        // Update session metrics
        if (event === 'session_stopped') {
            this.sessionMetrics.sessionDuration = sessionDuration;
            this.generateSessionSummary(sessionId);
        }
    }
    /**
   * Handle and log voice system errors with context
   */ logError(error, sessionId, context, shouldNotifyUser = false) {
        const errorContext = {
            sessionId,
            context,
            errorType: error.constructor.name,
            ...error.additionalContext
        };
        // Log structured error
        this.logEvent('voice_error', {
            sessionId,
            errorMessage: error.message,
            errorType: error.constructor.name,
            context,
            stack: error.stack?.substring(0, 500) // Truncate stack trace
        });
        // Report to centralized error handling
        (0,_lib_utils_error_utils__WEBPACK_IMPORTED_MODULE_1__/* .reportError */ .N7)(error, context || 'Voice System Error', errorContext);
        // Update error count
        this.sessionMetrics.errorCount = (this.sessionMetrics.errorCount || 0) + 1;
        // Show user notification for critical errors
        if (shouldNotifyUser) {
            let userMessage = 'Voice system error occurred';
            if (error instanceof VoiceConnectionError) {
                userMessage = 'Connection to voice service lost. Attempting to reconnect...';
            } else if (error instanceof VoiceAudioError) {
                userMessage = 'Audio processing error. Please check your microphone permissions.';
            } else if (error instanceof VoiceSessionError) {
                userMessage = 'Voice session error. Please try restarting the interview.';
            }
            (0,_lib_utils_error_utils__WEBPACK_IMPORTED_MODULE_1__/* .showErrorNotification */ .p6)(userMessage, context);
        }
    }
    /**
   * Log performance metrics
   */ logPerformanceMetric(metricName, value, sessionId, unit = 'ms') {
        this.logEvent('voice_performance_metric', {
            sessionId,
            metricName,
            value,
            unit
        }, {
            [metricName]: value
        });
        // Log performance warnings
        const thresholds = {
            'connection_time': 3000,
            'stt_latency': 2000,
            'tts_latency': 1500,
            'session_init_time': 5000
        };
        if (thresholds[metricName] && value > thresholds[metricName]) {
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn(`Performance threshold exceeded: ${metricName}`, {
                sessionId,
                value,
                threshold: thresholds[metricName],
                unit
            });
        }
    }
    /**
   * Generate session summary for analytics
   */ generateSessionSummary(sessionId) {
        const properties = {
            sessionId
        };
        const measurements = {
            duration: this.sessionMetrics.sessionDuration || 0,
            messageCount: this.sessionMetrics.messageCount || 0,
            errorCount: this.sessionMetrics.errorCount || 0,
            transcriptAccuracy: this.sessionMetrics.transcriptAccuracy || 0,
            connectionRetries: this.connectionMetrics.retryCount || 0,
            audioBufferIssues: this.audioMetrics.bufferUnderruns || 0,
            averageSttLatency: this.audioMetrics.sttLatency || 0,
            averageTtsLatency: this.audioMetrics.ttsLatency || 0
        };
        this.logEvent('voice_session_summary', properties, measurements);
        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.info('Voice session summary', {
            ...properties,
            ...measurements
        });
    }
    /**
   * Core event logging with Application Insights integration
   */ logEvent(name, properties, measurements) {
        const event = {
            name,
            timestamp: Date.now(),
            properties,
            measurements
        };
        // Store locally
        this.events.push(event);
        // Keep only last 100 events in memory
        if (this.events.length > 100) {
            this.events = this.events.slice(-100);
        }
        // Log to console for development
        if (false) {}
        // TODO: Integration with Azure Application Insights
        // if (window.appInsights) {
        //   window.appInsights.trackEvent({
        //     name: `voice_${name}`,
        //     properties,
        //     measurements
        //   });
        // }
        // Standard logging
        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.info(`Voice telemetry: ${name}`, {
            properties,
            measurements
        });
    }
    /**
   * Get current session metrics
   */ getMetrics() {
        return {
            connection: this.connectionMetrics,
            audio: this.audioMetrics,
            session: this.sessionMetrics
        };
    }
    /**
   * Export telemetry data for analysis
   */ exportTelemetryData() {
        return [
            ...this.events
        ];
    }
    /**
   * Clear telemetry data
   */ clearTelemetryData() {
        this.events = [];
        this.connectionMetrics = {};
        this.audioMetrics = {
            bufferUnderruns: 0
        };
        this.sessionMetrics = {
            messageCount: 0,
            errorCount: 0
        };
    }
    constructor(){
        this.events = [];
        this.sessionStartTime = 0;
        this.lastEventTime = 0;
        // Metrics aggregation
        this.connectionMetrics = {};
        this.audioMetrics = {};
        this.sessionMetrics = {};
    }
}
// Singleton instance
let voiceTelemetryInstance = null;
/**
 * Get shared VoiceTelemetryService instance
 */ function getVoiceTelemetry() {
    if (!voiceTelemetryInstance) {
        voiceTelemetryInstance = new VoiceTelemetryService();
    }
    return voiceTelemetryInstance;
}
/**
 * Utility functions for common voice telemetry operations
 */ const VoiceTelemetry = {
    // Connection tracking
    trackConnection: (event, sessionId, metrics)=>{
        getVoiceTelemetry().logConnectionEvent(event, sessionId, metrics);
    },
    // Audio performance tracking
    trackAudioLatency: (type, latency, sessionId)=>{
        const metrics = type === 'stt' ? {
            sttLatency: latency
        } : {
            ttsLatency: latency
        };
        getVoiceTelemetry().logAudioEvent(`${type}_complete`, sessionId, metrics);
    },
    // Error tracking with user notifications
    trackError: (error, sessionId, context, notifyUser = false)=>{
        getVoiceTelemetry().logError(error, sessionId, context, notifyUser);
    },
    // Performance monitoring
    trackPerformance: (metric, value, sessionId)=>{
        getVoiceTelemetry().logPerformanceMetric(metric, value, sessionId);
    },
    // Session lifecycle
    startSession: (sessionId, userId)=>{
        getVoiceTelemetry().startSession(sessionId, userId);
    },
    endSession: (sessionId)=>{
        getVoiceTelemetry().logSessionEvent('session_stopped', sessionId);
    },
    // Singleton access methods
    getInstance: ()=>getVoiceTelemetry()
};
/**
 * Export singleton instance for convenience
 */ const voiceTelemetry = getVoiceTelemetry();


/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 96559:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (false) {} else {
    if (false) {} else {
        if (false) {} else {
            if (false) {} else {
                module.exports = __webpack_require__(44870);
            }
        }
    }
}

//# sourceMappingURL=module.compiled.js.map

/***/ }),

/***/ 97502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   vF: () => (/* binding */ logger)
/* harmony export */ });
/* unused harmony exports debug, info, success, warn, error */
/**
 * Centralized logging utility with debug flag support
 * Helps reduce verbose console.debug statements throughout the codebase
 */ // Environment-based debug flag
const DEBUG =  false || process.env.DEBUG === 'true';
/**
 * Core logger with emoji prefixes for visual recognition
 */ const logger = {
    debug: (message, context)=>{
        if (DEBUG) {
            context ? console.debug(`🔍 ${message}`, context) : console.debug(`🔍 ${message}`);
        }
    },
    info: (message, context)=>{
        context ? console.info(`ℹ️ ${message}`, context) : console.info(`ℹ️ ${message}`);
    },
    success: (message, context)=>{
        context ? console.log(`✅ ${message}`, context) : console.log(`✅ ${message}`);
    },
    warn: (message, context)=>{
        context ? console.warn(`⚠️ ${message}`, context) : console.warn(`⚠️ ${message}`);
    },
    error: (message, error, context)=>{
        const errorInfo = error instanceof Error ? {
            message: error.message,
            stack: error.stack
        } : error;
        context ? console.error(`❌ ${message}`, {
            error: errorInfo,
            ...context
        }) : console.error(`❌ ${message}`, errorInfo);
    },
    // Audio-specific logging shortcuts
    audio: {
        process: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎵 ${message}`, context) : console.debug(`🎵 ${message}`);
            }
        },
        record: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎤 ${message}`, context) : console.debug(`🎤 ${message}`);
            }
        },
        speak: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🔊 ${message}`, context) : console.debug(`🔊 ${message}`);
            }
        }
    },
    // State management logging
    state: (action, from, to, context)=>{
        if (DEBUG) {
            const message = `State transition: ${from} → ${to}`;
            context ? console.debug(`🔄 [${action}] ${message}`, context) : console.debug(`🔄 [${action}] ${message}`);
        }
    },
    // API request logging
    api: {
        request: (endpoint, method, context)=>{
            if (DEBUG) {
                context ? console.debug(`📤 API ${method} ${endpoint}`, context) : console.debug(`📤 API ${method} ${endpoint}`);
            }
        },
        response: (endpoint, status, context)=>{
            const icon = status >= 200 && status < 300 ? '📥' : '❌';
            if (DEBUG) {
                context ? console.debug(`${icon} API Response ${status} ${endpoint}`, context) : console.debug(`${icon} API Response ${status} ${endpoint}`);
            }
        }
    }
};
// Convenience exports
const { debug, info, success, warn, error } = logger;


/***/ })

};
;