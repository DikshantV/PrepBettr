"use strict";
exports.id = 4085;
exports.ids = [4085];
exports.modules = {

/***/ 12078:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ AzureBlobStorageService)
/* harmony export */ });
/* harmony import */ var _azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(14737);
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10756);
/* harmony import */ var _opentelemetry_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(56472);
/* harmony import */ var _opentelemetry_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_opentelemetry_api__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _IStorageService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(55452);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__, _azure_identity__WEBPACK_IMPORTED_MODULE_1__]);
([_azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__, _azure_identity__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const TRACER_NAME = 'AzureBlobStorageService';
class AzureBlobStorageService {
    constructor(storageAccountName, containerName){
        this.containerName = containerName;
        this.isInitialized = false;
        this.storageAccountName = storageAccountName;
        const blobServiceUrl = `https://${this.storageAccountName}.blob.core.windows.net`;
        // Use DefaultAzureCredential in production, fallback to connection string for local dev
        const credential = process.env.AZURE_STORAGE_CONNECTION_STRING ? new _azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__.StorageSharedKeyCredential(this.storageAccountName, process.env.AZURE_STORAGE_ACCOUNT_KEY) : new _azure_identity__WEBPACK_IMPORTED_MODULE_1__.DefaultAzureCredential();
        const blobServiceClient = new _azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__.BlobServiceClient(blobServiceUrl, credential);
        this.containerClient = blobServiceClient.getContainerClient(this.containerName);
    }
    async initialize() {
        if (this.isInitialized) return;
        const tracer = _opentelemetry_api__WEBPACK_IMPORTED_MODULE_2__.trace.getTracer(TRACER_NAME);
        const span = tracer.startSpan('initialize');
        try {
            await this.containerClient.createIfNotExists(); // Private access by default
            this.isInitialized = true;
            span.setStatus({
                code: 1
            }); // OK
        } catch (error) {
            span.recordException(error);
            span.setStatus({
                code: 2,
                message: error.message
            }); // ERROR
            throw new _IStorageService__WEBPACK_IMPORTED_MODULE_3__/* .StorageError */ .a('Failed to initialize Azure Blob Storage container', _IStorageService__WEBPACK_IMPORTED_MODULE_3__/* .StorageProvider */ .L.Azure, error);
        } finally{
            span.end();
        }
    }
    async upload(file, path, mimeType) {
        await this.initialize();
        const blockBlobClient = this.containerClient.getBlockBlobClient(path);
        const tracer = _opentelemetry_api__WEBPACK_IMPORTED_MODULE_2__.trace.getTracer(TRACER_NAME);
        const span = tracer.startSpan('upload');
        span.setAttributes({
            path,
            mimeType,
            size: file.length
        });
        try {
            await blockBlobClient.upload(file, file.length, {
                blobHTTPHeaders: {
                    blobContentType: mimeType
                }
            });
            const fileMeta = {
                provider: _IStorageService__WEBPACK_IMPORTED_MODULE_3__/* .StorageProvider */ .L.Azure,
                url: blockBlobClient.url,
                path,
                size: file.length,
                mimeType: mimeType || 'application/octet-stream',
                createdAt: new Date()
            };
            span.setStatus({
                code: 1
            });
            return fileMeta;
        } catch (error) {
            span.recordException(error);
            span.setStatus({
                code: 2,
                message: error.message
            });
            throw new _IStorageService__WEBPACK_IMPORTED_MODULE_3__/* .StorageError */ .a(`Failed to upload to Azure Blob Storage: ${path}`, _IStorageService__WEBPACK_IMPORTED_MODULE_3__/* .StorageProvider */ .L.Azure, error);
        } finally{
            span.end();
        }
    }
    async download(path) {
        await this.initialize();
        const blockBlobClient = this.containerClient.getBlockBlobClient(path);
        const tracer = _opentelemetry_api__WEBPACK_IMPORTED_MODULE_2__.trace.getTracer(TRACER_NAME);
        const span = tracer.startSpan('download');
        span.setAttribute('path', path);
        try {
            const buffer = await blockBlobClient.downloadToBuffer();
            span.setStatus({
                code: 1
            });
            return buffer;
        } catch (error) {
            span.recordException(error);
            span.setStatus({
                code: 2,
                message: error.message
            });
            throw new _IStorageService__WEBPACK_IMPORTED_MODULE_3__/* .StorageError */ .a(`Failed to download from Azure Blob Storage: ${path}`, _IStorageService__WEBPACK_IMPORTED_MODULE_3__/* .StorageProvider */ .L.Azure, error);
        } finally{
            span.end();
        }
    }
    async delete(path) {
        await this.initialize();
        const blockBlobClient = this.containerClient.getBlockBlobClient(path);
        const tracer = _opentelemetry_api__WEBPACK_IMPORTED_MODULE_2__.trace.getTracer(TRACER_NAME);
        const span = tracer.startSpan('delete');
        span.setAttribute('path', path);
        try {
            await blockBlobClient.delete();
            span.setStatus({
                code: 1
            });
        } catch (error) {
            span.recordException(error);
            span.setStatus({
                code: 2,
                message: error.message
            });
            throw new _IStorageService__WEBPACK_IMPORTED_MODULE_3__/* .StorageError */ .a(`Failed to delete from Azure Blob Storage: ${path}`, _IStorageService__WEBPACK_IMPORTED_MODULE_3__/* .StorageProvider */ .L.Azure, error);
        } finally{
            span.end();
        }
    }
    async getPublicUrl(path, options) {
        await this.initialize();
        const blockBlobClient = this.containerClient.getBlockBlobClient(path);
        const permissions = new _azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__.BlobSASPermissions();
        permissions.read = options?.accessType === 'read' || !options?.accessType;
        permissions.write = options?.accessType === 'write';
        const expiryDate = new Date();
        expiryDate.setSeconds(expiryDate.getSeconds() + (options?.expiresIn || 3600)); // Default to 1 hour
        const sasQueryParameters = (0,_azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__.generateBlobSASQueryParameters)({
            containerName: this.containerName,
            blobName: path,
            permissions,
            startsOn: new Date(),
            expiresOn: expiryDate
        }, this.containerClient.credential);
        return `${blockBlobClient.url}?${sasQueryParameters.toString()}`;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 14085:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ResumeStorageService: () => (/* binding */ ResumeStorageService),
/* harmony export */   getStorageService: () => (/* binding */ getStorageService),
/* harmony export */   resetStorageService: () => (/* binding */ resetStorageService),
/* harmony export */   resumeStorageService: () => (/* binding */ resumeStorageService)
/* harmony export */ });
/* harmony import */ var _IStorageService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(55452);
/* harmony import */ var _providers_AzureBlobStorageService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12078);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_providers_AzureBlobStorageService__WEBPACK_IMPORTED_MODULE_1__]);
_providers_AzureBlobStorageService__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// Client-side safety check
const isClient = "undefined" !== 'undefined';
// Only import server-side dependencies when running on server
let getConfiguration = null;
if (!isClient) {
    const azureConfig = __webpack_require__(73905);
    getConfiguration = azureConfig.getConfiguration;
}
// Singleton storage service instance
let storageServiceInstance = null;
/**
 * Gets the Azure Blob Storage service instance.
 * All storage operations now use Azure exclusively.
 */ async function getStorageService() {
    if (isClient) {
        throw new Error('Storage service not available on client side');
    }
    if (storageServiceInstance) {
        return storageServiceInstance;
    }
    storageServiceInstance = await createAzureStorageService();
    return storageServiceInstance;
}
/**
 * Creates an Azure Blob Storage service instance with proper configuration.
 */ async function createAzureStorageService() {
    if (isClient) {
        throw new Error('Storage service not available on client side');
    }
    try {
        const config = await getConfiguration();
        const storageAccountName = config['AZURE_STORAGE_ACCOUNT'] || process.env.AZURE_STORAGE_ACCOUNT || 'prepbettrstorage684';
        const containerName = config['AZURE_STORAGE_CONTAINER'] || process.env.AZURE_STORAGE_CONTAINER || 'resumes';
        return new _providers_AzureBlobStorageService__WEBPACK_IMPORTED_MODULE_1__/* .AzureBlobStorageService */ .$(storageAccountName, containerName);
    } catch (error) {
        console.error('Failed to create Azure storage service:', error);
        throw error;
    }
}
/**
 * Resets the singleton storage service instance.
 * Useful for testing or configuration changes.
 */ function resetStorageService() {
    storageServiceInstance = null;
}
/**
 * Resume-specific utilities for backward compatibility
 */ class ResumeStorageService {
    async getService() {
        if (!this.storageService) {
            this.storageService = await getStorageService();
        }
        return this.storageService;
    }
    /**
   * Upload a resume file with proper path organization
   */ async uploadResume(userId, fileBuffer, fileName, mimeType) {
        const service = await this.getService();
        const filePath = `resumes/${userId}/${fileName}`;
        const result = await service.upload(fileBuffer, filePath, mimeType);
        return {
            fileUrl: result.url,
            filePath: result.path,
            sasUrl: result.sasUrl,
            provider: _IStorageService__WEBPACK_IMPORTED_MODULE_0__/* .StorageProvider */ .L.Azure
        };
    }
    /**
   * Delete a resume file
   */ async deleteResume(filePath) {
        const service = await this.getService();
        await service.delete(filePath);
    }
    /**
   * Generate a secure URL for resume access
   */ async getResumeUrl(filePath, expiresInHours = 24) {
        const service = await this.getService();
        return await service.getPublicUrl(filePath, {
            expiresIn: expiresInHours * 3600,
            accessType: 'read'
        });
    }
    constructor(){
        this.storageService = null;
    }
}
// Export singleton instance for resume operations
const resumeStorageService = new ResumeStorageService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 55452:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L: () => (/* binding */ StorageProvider),
/* harmony export */   a: () => (/* binding */ StorageError)
/* harmony export */ });
/**
 * @file Defines the universal interface for storage services.
 * This abstraction allows for a seamless switch between different storage providers (e.g., Azure, Firebase).
 */ /**
 * Enumeration for the storage providers.
 */ var StorageProvider = /*#__PURE__*/ function(StorageProvider) {
    StorageProvider["Azure"] = "azure";
    StorageProvider["Firebase"] = "firebase";
    StorageProvider["Dual"] = "dual";
    return StorageProvider;
}({});
/**
 * Custom error class for storage operations.
 */ class StorageError extends Error {
    constructor(message, provider, originalError){
        super(message), this.provider = provider, this.originalError = originalError;
        this.name = 'StorageError';
    }
}


/***/ })

};
;