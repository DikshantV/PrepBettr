exports.id = 4633;
exports.ids = [4633];
exports.modules = {

/***/ 22082:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ac: () => (/* binding */ getModelConfig),
/* harmony export */   I6: () => (/* binding */ validateFoundryConfig),
/* harmony export */   at: () => (/* binding */ getFoundryConfig),
/* harmony export */   fZ: () => (/* binding */ getDefaultModel)
/* harmony export */ });
/* unused harmony exports clearFoundryConfigCache, getEnvironmentDefaults, getDefaultModelConfigurations, getDefaultConnectionSettings, getFoundryConfigForEnvironment */
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10756);
/* harmony import */ var _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36695);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__]);
([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure AI Foundry Configuration
 * 
 * This module handles configuration for Azure AI Foundry services,
 * including model configurations, retry policies, and connection settings.
 * Follows the existing pattern established in lib/azure-config.ts.
 */ 

// Client-side safety check
const isClient = "undefined" !== 'undefined';
if (isClient) {
    console.warn('[Azure AI Foundry Config] Running on client side - using fallback implementations');
}
// Azure Key Vault configuration (reuse existing vault)
const AZURE_KEY_VAULT_URI = process.env.AZURE_KEY_VAULT_URI || 'https://prepbettr-keyvault-083.vault.azure.net/';
let cachedFoundryConfig = null;
/**
 * Initialize Azure Key Vault client (reusing existing pattern)
 */ function createKeyVaultClient() {
    if (!AZURE_KEY_VAULT_URI) {
        throw new Error('AZURE_KEY_VAULT_URI environment variable is required');
    }
    const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_0__.DefaultAzureCredential();
    return new _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__.SecretClient(AZURE_KEY_VAULT_URI, credential);
}
/**
 * Clear cached foundry configuration
 */ function clearFoundryConfigCache() {
    if (isClient) return;
    console.log('🔄 Clearing Azure AI Foundry config cache...');
    cachedFoundryConfig = null;
}
/**
 * Fetch Azure AI Foundry configuration from Azure Key Vault with environment variable fallback
 * 
 * @param forceRefresh - Force refresh the cached configuration
 * @returns Promise<FoundryConfig> - The foundry configuration
 */ async function getFoundryConfig(forceRefresh = false) {
    if (isClient) {
        // Client-side fallback - return empty config with all required fields
        return {
            endpoint: '',
            apiKey: '',
            projectId: '',
            resourceId: '',
            resourceGroup: '',
            region: '',
            models: {},
            connection: getDefaultConnectionSettings(),
            environment: 'development'
        };
    }
    // Clear cache if force refresh is requested
    if (forceRefresh) {
        clearFoundryConfigCache();
    }
    // Return cached configuration if available
    if (cachedFoundryConfig) {
        return cachedFoundryConfig;
    }
    try {
        console.log('🔑 Fetching Azure AI Foundry configuration from Key Vault...');
        const client = createKeyVaultClient();
        // Helper function to suppress expected 404 errors for optional secrets
        const getOptionalSecret = (name)=>client.getSecret(name).catch((err)=>{
                if (err.statusCode !== 404) {
                    console.warn(`⚠️ Unexpected error fetching optional secret '${name}':`, err.message);
                }
                return null;
            });
        // Fetch foundry-specific secrets
        const [foundryEndpoint, foundryApiKey, foundryProjectId, foundryResourceGroup, foundryRegion, foundryDeploymentName, docIntEndpoint, docIntApiKey, docIntProjectId] = await Promise.all([
            getOptionalSecret('azure-foundry-endpoint'),
            getOptionalSecret('azure-foundry-api-key'),
            getOptionalSecret('azure-foundry-project-id'),
            getOptionalSecret('azure-foundry-resource-group'),
            getOptionalSecret('azure-foundry-region'),
            getOptionalSecret('azure-foundry-deployment-name'),
            getOptionalSecret('azure-foundry-docint-endpoint'),
            getOptionalSecret('azure-foundry-docint-api-key'),
            getOptionalSecret('azure-foundry-docint-project-id')
        ]);
        cachedFoundryConfig = {
            endpoint: foundryEndpoint?.value || process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: foundryApiKey?.value || process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: foundryProjectId?.value || process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: foundryResourceGroup?.value || process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            region: foundryRegion?.value || process.env.AZURE_FOUNDRY_REGION || 'eastus',
            environment: "production" || 0 || 0,
            models: getDefaultModelConfigurations(),
            connection: getDefaultConnectionSettings(),
            docIntelligence: docIntEndpoint?.value || docIntApiKey?.value || process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || process.env.AZURE_FOUNDRY_DOCINT_API_KEY ? {
                endpoint: docIntEndpoint?.value || process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || '',
                apiKey: docIntApiKey?.value || process.env.AZURE_FOUNDRY_DOCINT_API_KEY || '',
                projectId: docIntProjectId?.value || process.env.AZURE_FOUNDRY_DOCINT_PROJECT_ID,
                region: foundryRegion?.value || process.env.AZURE_FOUNDRY_REGION || 'eastus'
            } : undefined
        };
        // Validate required configuration
        const requiredFields = [
            'endpoint',
            'apiKey',
            'projectId',
            'resourceGroup'
        ];
        const missingFields = requiredFields.filter((field)=>!cachedFoundryConfig[field]);
        if (missingFields.length > 0) {
            console.warn(`⚠️ Azure AI Foundry missing configuration: ${missingFields.join(', ')}`);
            console.log('💡 Add these secrets to Azure Key Vault or set environment variables:');
            missingFields.forEach((field)=>{
                const envVar = `AZURE_FOUNDRY_${field.toUpperCase()}`;
                console.log(`   - ${envVar}`);
            });
        } else {
            console.log('✅ Azure AI Foundry configuration loaded successfully');
        }
        return cachedFoundryConfig;
    } catch (error) {
        console.error('❌ Failed to fetch Azure AI Foundry configuration:', error);
        // Fallback to environment variables
        console.log('🔄 Falling back to environment variables for Azure AI Foundry...');
        const fallbackConfig = {
            endpoint: process.env.AZURE_FOUNDRY_ENDPOINT || '',
            apiKey: process.env.AZURE_FOUNDRY_API_KEY || '',
            projectId: process.env.AZURE_FOUNDRY_PROJECT_ID || 'prepbettr-interview-agents',
            resourceId: process.env.AZURE_FOUNDRY_RESOURCE_ID || '',
            resourceGroup: process.env.AZURE_FOUNDRY_RESOURCE_GROUP || 'PrepBettr_group',
            region: process.env.AZURE_FOUNDRY_REGION || 'eastus',
            environment: "production" || 0 || 0,
            models: getDefaultModelConfigurations(),
            connection: getDefaultConnectionSettings(),
            docIntelligence: process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || process.env.AZURE_FOUNDRY_DOCINT_API_KEY ? {
                endpoint: process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || '',
                apiKey: process.env.AZURE_FOUNDRY_DOCINT_API_KEY || '',
                projectId: process.env.AZURE_FOUNDRY_DOCINT_PROJECT_ID,
                region: process.env.AZURE_FOUNDRY_REGION || 'eastus'
            } : undefined
        };
        // Log missing critical configuration
        if (!fallbackConfig.endpoint || !fallbackConfig.apiKey) {
            console.error('❌ Critical Azure AI Foundry configuration missing from environment variables');
            console.log('💡 Set AZURE_FOUNDRY_ENDPOINT and AZURE_FOUNDRY_API_KEY environment variables');
        }
        cachedFoundryConfig = fallbackConfig;
        return cachedFoundryConfig;
    }
}
/**
 * Get environment-specific configuration defaults
 */ function getEnvironmentDefaults() {
    const environment = "production" || 0 || 0;
    const defaults = {
        development: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        },
        staging: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        },
        production: {
            region: 'eastus2',
            resourceGroup: 'PrepBettr_group'
        }
    };
    return defaults[environment] || defaults.development;
}
/**
 * Get default model configurations for Azure AI Foundry
 */ function getDefaultModelConfigurations() {
    return {
        'gpt-4o': {
            deploymentName: process.env.AZURE_FOUNDRY_GPT4O_DEPLOYMENT || 'gpt-4o',
            modelName: 'gpt-4o',
            version: '2024-05-13',
            maxTokens: 4096,
            temperature: 0.7,
            topP: 0.9,
            frequencyPenalty: 0,
            presencePenalty: 0,
            costPerToken: 0.005,
            capabilities: [
                'text-generation',
                'reasoning',
                'coding',
                'analysis'
            ],
            isDefault: true
        },
        'gpt-4-turbo': {
            deploymentName: process.env.AZURE_FOUNDRY_GPT4_TURBO_DEPLOYMENT || 'gpt-4-turbo',
            modelName: 'gpt-4-turbo',
            version: '2024-04-09',
            maxTokens: 4096,
            temperature: 0.7,
            topP: 0.9,
            frequencyPenalty: 0,
            presencePenalty: 0,
            costPerToken: 0.01,
            capabilities: [
                'text-generation',
                'reasoning',
                'coding',
                'analysis',
                'function-calling'
            ]
        },
        'phi-4': {
            deploymentName: process.env.AZURE_FOUNDRY_PHI4_DEPLOYMENT || 'phi-4',
            modelName: 'phi-4',
            version: '2024-12-12',
            maxTokens: 2048,
            temperature: 0.6,
            topP: 0.85,
            frequencyPenalty: 0.1,
            presencePenalty: 0.1,
            costPerToken: 0.001,
            capabilities: [
                'text-generation',
                'reasoning',
                'lightweight-tasks'
            ]
        }
    };
}
/**
 * Get default connection settings
 */ function getDefaultConnectionSettings() {
    const environment = "production" || 0 || 0;
    return {
        timeout: environment === 'production' ? 30000 : 60000,
        keepAlive: true,
        maxConnections: environment === 'production' ? 10 : 5,
        retryPolicy: {
            maxRetries: 3,
            baseDelay: 1000,
            maxDelay: 10000,
            exponentialBase: 2,
            jitter: true
        }
    };
}
/**
 * Get model configuration by name
 */ function getModelConfig(modelName) {
    const models = getDefaultModelConfigurations();
    return models[modelName] || null;
}
/**
 * Get default model configuration
 */ function getDefaultModel() {
    const models = getDefaultModelConfigurations();
    const defaultModel = Object.values(models).find((model)=>model.isDefault);
    return defaultModel || models['gpt-4o'];
}
/**
 * Validate foundry configuration
 */ function validateFoundryConfig(config) {
    const errors = [];
    if (!config.endpoint) {
        errors.push('Missing foundry endpoint');
    }
    if (!config.apiKey) {
        errors.push('Missing foundry API key');
    }
    if (!config.projectId) {
        errors.push('Missing foundry project ID');
    }
    if (!config.resourceGroup) {
        errors.push('Missing foundry resource group');
    }
    // Validate endpoint format
    if (config.endpoint && !config.endpoint.startsWith('https://')) {
        errors.push('Foundry endpoint must use HTTPS');
    }
    // Validate models configuration
    const models = Object.values(config.models);
    if (models.length === 0) {
        errors.push('No models configured');
    }
    const hasDefault = models.some((model)=>model.isDefault);
    if (!hasDefault) {
        errors.push('No default model configured');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * Get foundry configuration for specific environment
 */ async function getFoundryConfigForEnvironment(environment) {
    // Get config without modifying process.env to avoid webpack issues
    const config = await getFoundryConfig(true); // Force refresh
    // Override the environment in the returned config
    return {
        ...config,
        environment
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 65868:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   lL: () => (/* binding */ fetchAzureSecrets)
/* harmony export */ });
/* unused harmony exports initializeAzureEnvironment, getAzureConfig */
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91193);
/* harmony import */ var _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62201);
/* harmony import */ var _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__);


// Azure Key Vault configuration
const AZURE_KEY_VAULT_URI = process.env.AZURE_KEY_VAULT_URI || 'https://prepbettr-keyvault-083.vault.azure.net/';
let cachedSecrets = null;
/**
 * Initialize Azure Key Vault client
 */ function createKeyVaultClient() {
    if (!AZURE_KEY_VAULT_URI) {
        throw new Error('AZURE_KEY_VAULT_URI environment variable is required');
    }
    try {
        const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_0__/* .DefaultAzureCredential */ .gv();
        return new _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__.SecretClient(AZURE_KEY_VAULT_URI, credential);
    } catch (error) {
        console.error('❌ Failed to create DefaultAzureCredential:', error);
        console.error('💡 Hint: Ensure you are logged in with "az login" for local development');
        throw error;
    }
}
/**
 * Fetch secrets from Azure Key Vault
 */ async function fetchAzureSecrets() {
    // Return cached secrets if available
    if (cachedSecrets) {
        return cachedSecrets;
    }
    try {
        console.log('🔑 Fetching secrets from Azure Key Vault...');
        const client = createKeyVaultClient();
        // Fetch all required secrets
        const [speechKey, speechEndpoint, azureOpenAIKey, azureOpenAIEndpoint, azureOpenAIDeployment, azureOpenAIGpt35, azureOpenAIGpt4o, storageAccountName, storageAccountKey, formRecognizerEndpoint, formRecognizerKey] = await Promise.all([
            client.getSecret('speech-key'),
            client.getSecret('speech-endpoint'),
            client.getSecret('azure-openai-key'),
            client.getSecret('azure-openai-endpoint'),
            client.getSecret('azure-openai-deployment'),
            client.getSecret('azure-openai-gpt35-deployment').catch(()=>null),
            client.getSecret('azure-openai-gpt4o-deployment').catch(()=>null),
            client.getSecret('azure-storage-account-name').catch(()=>null),
            client.getSecret('azure-storage-account-key').catch(()=>null),
            client.getSecret('azure-form-recognizer-endpoint').catch(()=>null),
            client.getSecret('azure-form-recognizer-key').catch(()=>null) // Optional
        ]);
        if (!speechKey.value || !speechEndpoint.value || !azureOpenAIKey.value || !azureOpenAIEndpoint.value || !azureOpenAIDeployment.value) {
            throw new Error('One or more required secrets are missing from Azure Key Vault');
        }
        cachedSecrets = {
            speechKey: speechKey.value,
            speechEndpoint: speechEndpoint.value,
            azureOpenAIKey: azureOpenAIKey.value,
            azureOpenAIEndpoint: azureOpenAIEndpoint.value,
            azureOpenAIDeployment: azureOpenAIDeployment.value,
            azureOpenAIGpt35Deployment: azureOpenAIGpt35?.value || 'gpt-4o',
            azureOpenAIGpt4oDeployment: azureOpenAIGpt4o?.value || 'gpt-4o',
            azureStorageAccountName: storageAccountName?.value,
            azureStorageAccountKey: storageAccountKey?.value,
            azureFormRecognizerEndpoint: formRecognizerEndpoint?.value,
            azureFormRecognizerKey: formRecognizerKey?.value
        };
        console.log('✅ Azure secrets loaded successfully');
        return cachedSecrets;
    } catch (error) {
        console.error('❌ Failed to fetch Azure secrets:', error);
        // Fallback to environment variables if Key Vault fails
        console.log('🔄 Falling back to environment variables...');
        const fallbackSecrets = {
            speechKey: process.env.SPEECH_KEY || process.env.NEXT_PUBLIC_SPEECH_KEY || '',
            speechEndpoint: process.env.SPEECH_ENDPOINT || process.env.NEXT_PUBLIC_SPEECH_ENDPOINT || '',
            azureOpenAIKey: process.env.AZURE_OPENAI_KEY || '',
            azureOpenAIEndpoint: process.env.AZURE_OPENAI_ENDPOINT || '',
            azureOpenAIDeployment: process.env.AZURE_OPENAI_DEPLOYMENT || '',
            azureOpenAIGpt35Deployment: process.env.AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            azureOpenAIGpt4oDeployment: process.env.AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o',
            azureStorageAccountName: process.env.AZURE_STORAGE_ACCOUNT_NAME,
            azureStorageAccountKey: process.env.AZURE_STORAGE_ACCOUNT_KEY,
            azureFormRecognizerEndpoint: process.env.AZURE_FORM_RECOGNIZER_ENDPOINT,
            azureFormRecognizerKey: process.env.AZURE_FORM_RECOGNIZER_KEY
        };
        if (!fallbackSecrets.speechKey || !fallbackSecrets.azureOpenAIKey) {
            console.warn('⚠️ Some secrets are missing from both Key Vault and environment variables');
        }
        cachedSecrets = fallbackSecrets;
        return cachedSecrets;
    }
}
/**
 * Initialize environment variables from Azure Key Vault
 * This should be called at application startup
 */ async function initializeAzureEnvironment() {
    try {
        const secrets = await fetchAzureSecrets();
        // Set environment variables for the application
        process.env.NEXT_PUBLIC_SPEECH_KEY = secrets.speechKey;
        process.env.NEXT_PUBLIC_SPEECH_ENDPOINT = secrets.speechEndpoint;
        process.env.AZURE_OPENAI_KEY = secrets.azureOpenAIKey;
        process.env.AZURE_OPENAI_ENDPOINT = secrets.azureOpenAIEndpoint;
        process.env.AZURE_OPENAI_DEPLOYMENT = secrets.azureOpenAIDeployment;
        process.env.AZURE_OPENAI_GPT35_DEPLOYMENT = secrets.azureOpenAIGpt35Deployment;
        process.env.AZURE_OPENAI_GPT4O_DEPLOYMENT = secrets.azureOpenAIGpt4oDeployment;
        // Set Azure OpenAI keys for public environment
        process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY = secrets.azureOpenAIKey;
        process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT = secrets.azureOpenAIEndpoint;
        process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT = secrets.azureOpenAIDeployment;
        process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT = secrets.azureOpenAIGpt35Deployment;
        process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT = secrets.azureOpenAIGpt4oDeployment;
        console.log('🌟 Azure environment initialized successfully');
    } catch (error) {
        console.error('❌ Failed to initialize Azure environment:', error);
        throw error;
    }
}
/**
 * Get current Azure configuration (for debugging)
 */ function getAzureConfig() {
    return {
        keyVaultUri: AZURE_KEY_VAULT_URI,
        hasSecretsCache: !!cachedSecrets,
        environment: {
            speechKey: !!process.env.NEXT_PUBLIC_SPEECH_KEY,
            speechEndpoint: !!process.env.NEXT_PUBLIC_SPEECH_ENDPOINT,
            azureOpenAIKey: !!process.env.AZURE_OPENAI_KEY,
            azureOpenAIEndpoint: !!process.env.AZURE_OPENAI_ENDPOINT,
            azureOpenAIDeployment: !!process.env.AZURE_OPENAI_DEPLOYMENT,
            azureOpenAIGpt35Deployment: !!process.env.AZURE_OPENAI_GPT35_DEPLOYMENT,
            azureOpenAIGpt4oDeployment: !!process.env.AZURE_OPENAI_GPT4O_DEPLOYMENT
        },
        deployments: {
            default: process.env.AZURE_OPENAI_DEPLOYMENT,
            gpt35Turbo: process.env.AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            gpt4o: process.env.AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o'
        }
    };
}


/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 96487:
/***/ (() => {



/***/ })

};
;