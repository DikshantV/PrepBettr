"use strict";
exports.id = 3733;
exports.ids = [3733];
exports.modules = {

/***/ 8008:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N7: () => (/* binding */ reportError),
/* harmony export */   bD: () => (/* binding */ withRetry),
/* harmony export */   hS: () => (/* binding */ handleApiError),
/* harmony export */   p6: () => (/* binding */ showErrorNotification),
/* harmony export */   vZ: () => (/* binding */ AudioError),
/* harmony export */   z$: () => (/* binding */ handleAsyncError)
/* harmony export */ });
/* unused harmony exports withTimeout, safeJsonParse, ValidationError */
/* harmony import */ var _logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(39764);
/**
 * Error handling utilities to centralize try-catch patterns
 * Reduces duplicate error handling code throughout the application
 */ 
/**
 * Standardized error reporting with context
 */ const reportError = (error, context, additionalContext)=>{
    const err = error instanceof Error ? error : new Error(String(error));
    _logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.error(`${context}: ${err.message}`, err, additionalContext);
    return err;
};
/**
 * Wrap async functions with standardized error handling
 */ const handleAsyncError = async (fn, context, fallback, additionalContext)=>{
    try {
        return await fn();
    } catch (error) {
        reportError(error, context, additionalContext);
        return fallback;
    }
};
/**
 * Retry wrapper with exponential backoff
 */ const withRetry = async (fn, maxAttempts = 3, context = 'Operation', baseDelay = 1000)=>{
    let attempt = 0;
    while(attempt < maxAttempts){
        try {
            return await fn();
        } catch (error) {
            attempt++;
            if (attempt >= maxAttempts) {
                throw reportError(error, `${context} failed after ${maxAttempts} attempts`);
            }
            const delay = Math.pow(2, attempt) * baseDelay;
            _logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn(`${context} attempt ${attempt} failed, retrying in ${delay}ms`, {
                error
            });
            await new Promise((resolve)=>setTimeout(resolve, delay));
        }
    }
    throw new Error(`${context}: Exhausted all retry attempts`);
};
/**
 * Timeout wrapper for promises
 */ const withTimeout = (promise, timeoutMs, context = 'Operation')=>{
    return Promise.race([
        promise,
        new Promise((_, reject)=>{
            setTimeout(()=>{
                reject(new Error(`${context} timed out after ${timeoutMs}ms`));
            }, timeoutMs);
        })
    ]);
};
/**
 * Safe JSON parsing with error handling
 */ const safeJsonParse = (jsonString, fallback, context = 'JSON parse')=>{
    try {
        return JSON.parse(jsonString);
    } catch (error) {
        reportError(error, `${context} failed`, {
            jsonString: jsonString.slice(0, 100)
        });
        return fallback;
    }
};
/**
 * Network request error handler with user-friendly messages
 */ const handleApiError = (response, context = 'API request')=>{
    const friendlyMessages = {
        400: 'Invalid request. Please check your input and try again.',
        401: 'Authentication failed. Please sign in again.',
        403: 'Access denied. You may not have permission for this action.',
        404: 'The requested resource was not found.',
        429: 'Too many requests. Please wait a moment before trying again.',
        500: 'Server error. Please try again later.',
        502: 'Service temporarily unavailable. Please try again later.',
        503: 'Service temporarily unavailable. Please try again later.'
    };
    const friendlyMessage = friendlyMessages[response.status] || 'An unexpected error occurred.';
    const technicalMessage = `${context}: HTTP ${response.status} ${response.statusText}`;
    const error = new Error(friendlyMessage);
    error.technicalMessage = technicalMessage;
    error.status = response.status;
    return error;
};
/**
 * Show user-friendly error notification (replace alert() calls)
 * This will hook into the app's existing toast system
 */ const showErrorNotification = (error, context)=>{
    const message = typeof error === 'string' ? error : error.message;
    const fullMessage = context ? `${context}: ${message}` : message;
    // Use console.warn for user notifications to reduce error noise
    _logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('User notification: ' + fullMessage);
// TODO: Replace with actual toast notification system
// toast.error(fullMessage);
};
/**
 * Validation error for form/input validation
 */ class ValidationError extends Error {
    constructor(message, field){
        super(message), this.field = field;
        this.name = 'ValidationError';
    }
}
/**
 * Audio processing specific error
 */ class AudioError extends Error {
    constructor(message, audioContext){
        super(message), this.audioContext = audioContext;
        this.name = 'AudioError';
    }
}


/***/ }),

/***/ 21530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  A: () => (/* binding */ components_Agent)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js
var react_jsx_runtime = __webpack_require__(60687);
// EXTERNAL MODULE: ./node_modules/next/dist/api/image.js
var api_image = __webpack_require__(30474);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(16189);
// EXTERNAL MODULE: ./lib/hooks/useUnifiedConfig.ts
var useUnifiedConfig = __webpack_require__(79042);
// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(57048);
;// ./lib/actions/general.action.ts
// Static export stubs
async function startVoiceConversation() {
    return {
        error: 'Static mode'
    };
}
async function createFeedback(params) {
    return {
        success: false,
        feedbackId: null,
        error: 'Static mode'
    };
}
async function getFeedbackByInterviewId(params) {
    // Return null for static mode - no feedback available
    return null;
}

// EXTERNAL MODULE: ./lib/utils/logger.ts
var utils_logger = __webpack_require__(39764);
// EXTERNAL MODULE: ./lib/utils/error-utils.ts
var error_utils = __webpack_require__(8008);
// EXTERNAL MODULE: ./lib/azure-ai-foundry/voice/voice-telemetry.ts
var voice_telemetry = __webpack_require__(99728);
;// ./lib/azure-ai-foundry/voice/voice-agent-bridge.ts
/**
 * Voice Agent Bridge
 * Connects VoiceSession with AgentOrchestrator to enable voice-controlled agent interactions
 */ 
// Event emitter for voice bridge
class VoiceEventEmitter {
    on(event, handler) {
        if (!this.handlers.has(event)) {
            this.handlers.set(event, []);
        }
        this.handlers.get(event).push(handler);
    }
    emit(event, data) {
        const handlers = this.handlers.get(event);
        if (handlers) {
            handlers.forEach((handler)=>handler(data));
        }
    }
    off(event, handler) {
        const handlers = this.handlers.get(event);
        if (handlers) {
            const index = handlers.indexOf(handler);
            if (index !== -1) {
                handlers.splice(index, 1);
            }
        }
    }
    constructor(){
        this.handlers = new Map();
    }
}
class VoiceAgentBridge extends VoiceEventEmitter {
    constructor(voiceSession, agentOrchestrator, config){
        super(), this.transcript = [], this.recording = null;
        this.voiceSession = voiceSession;
        this.agentOrchestrator = agentOrchestrator;
        this.config = {
            sessionTimeout: 1800000,
            maxRetries: 3,
            errorRecoveryMode: 'graceful',
            sentimentMonitoring: true,
            recordingEnabled: true,
            transcriptStorage: 'both',
            ...config
        };
        this.state = {
            currentAgent: null,
            sessionActive: false,
            lastActivity: Date.now(),
            pendingHandoff: false,
            errorCount: 0,
            recovery: {
                inProgress: false,
                attempts: 0,
                lastAttempt: 0
            }
        };
        this.setupVoiceSessionHandlers();
        this.initializeRecording();
        // Use VoiceTelemetry.startSession instead of trackSessionCreated
        voice_telemetry.VoiceTelemetry.startSession(this.voiceSession.sessionId);
        console.log('🌉 [VOICE BRIDGE] Bridge created', {
            sessionId: this.voiceSession.sessionId,
            config: this.config
        });
    }
    /**
   * Start the voice bridge and begin listening
   */ async start() {
        try {
            console.log('🚀 [VOICE BRIDGE] Starting bridge', {
                sessionId: this.voiceSession.sessionId
            });
            await this.voiceSession.start();
            this.state.sessionActive = true;
            this.state.lastActivity = Date.now();
            this.emit('session:started', {
                sessionId: this.voiceSession.sessionId,
                agent: this.state.currentAgent || 'initial'
            });
            // Set up activity timeout
            this.setupActivityTimeout();
            // Session already tracked in constructor, no need to track again
            console.log('✅ [VOICE BRIDGE] Bridge started successfully');
        } catch (error) {
            const bridgeError = error instanceof Error ? error : new Error('Failed to start bridge');
            voice_telemetry.VoiceTelemetry.trackError(bridgeError, this.voiceSession.sessionId, 'BRIDGE_START_FAILED');
            this.handleError(bridgeError);
            throw bridgeError;
        }
    }
    /**
   * Stop the voice bridge
   */ stop() {
        console.log('🛑 [VOICE BRIDGE] Stopping bridge', {
            sessionId: this.voiceSession.sessionId
        });
        this.state.sessionActive = false;
        this.voiceSession.stop();
        if (this.recording) {
            this.finalizeRecording();
        }
        this.emit('session:ended', {
            sessionId: this.voiceSession.sessionId,
            reason: 'user_stopped'
        });
        console.log('🏁 [VOICE BRIDGE] Bridge stopped');
    }
    /**
   * Handle agent handoff
   */ async handoffToAgent(agentName, context) {
        if (this.state.pendingHandoff) {
            console.warn('⚠️ [VOICE BRIDGE] Handoff already in progress');
            return;
        }
        try {
            this.state.pendingHandoff = true;
            const previousAgent = this.state.currentAgent;
            console.log('🔄 [VOICE BRIDGE] Handing off to agent', {
                from: previousAgent,
                to: agentName,
                sessionId: this.voiceSession.sessionId
            });
            // Notify agent orchestrator about handoff
            if (this.agentOrchestrator?.handoff) {
                await this.agentOrchestrator.handoff(agentName, context);
            }
            this.state.currentAgent = agentName;
            this.state.pendingHandoff = false;
            this.state.lastActivity = Date.now();
            this.emit('agent:handoff', {
                from: previousAgent || 'none',
                to: agentName,
                context
            });
            // Update voice session with agent-specific settings if available
            const agentVoiceSettings = this.getAgentVoiceSettings(agentName);
            if (agentVoiceSettings) {
                // TODO: Implement updateSettings method in VoiceSession
                console.log('🎛️ [VOICE BRIDGE] Would update voice settings for agent:', agentName, agentVoiceSettings);
            // this.voiceSession.updateSettings(agentVoiceSettings);
            }
            console.log('✅ [VOICE BRIDGE] Handoff completed', {
                currentAgent: agentName
            });
        } catch (error) {
            this.state.pendingHandoff = false;
            const handoffError = error instanceof Error ? error : new Error('Agent handoff failed');
            voice_telemetry.VoiceTelemetry.trackError(handoffError, this.voiceSession.sessionId, 'AGENT_HANDOFF_FAILED');
            this.handleError(handoffError);
            throw handoffError;
        }
    }
    /**
   * Send synthesized audio response
   */ async sendAudioResponse(text, audioData) {
        try {
            this.state.lastActivity = Date.now();
            this.emit('agent:response', {
                agent: this.state.currentAgent || 'unknown',
                text,
                audioData
            });
            // Add to transcript
            this.addToTranscript('agent', text);
            // Add to recording if enabled
            if (audioData && this.config.recordingEnabled) {
                this.addAudioToRecording('agent', audioData);
            }
            // Perform sentiment analysis if enabled
            if (this.config.sentimentMonitoring) {
                this.performSentimentAnalysis(text, 'agent');
            }
            console.log('🎵 [VOICE BRIDGE] Audio response sent', {
                agent: this.state.currentAgent,
                textLength: text.length,
                hasAudio: !!audioData
            });
        } catch (error) {
            const responseError = error instanceof Error ? error : new Error('Failed to send audio response');
            voice_telemetry.VoiceTelemetry.trackError(responseError, this.voiceSession.sessionId, 'AUDIO_RESPONSE_FAILED');
            this.handleError(responseError);
        }
    }
    /**
   * Get current session state
   */ getState() {
        return {
            ...this.state
        };
    }
    /**
   * Get current transcript
   */ getTranscript() {
        return [
            ...this.transcript
        ];
    }
    /**
   * Get current recording
   */ getRecording() {
        return this.recording ? {
            ...this.recording
        } : null;
    }
    // ===== PRIVATE METHODS =====
    setupVoiceSessionHandlers() {
        // Handle transcript from voice session
        this.voiceSession.onTranscript((event)=>{
            this.handleUserTranscript(event.text);
        });
        // Handle audio responses using onResponse callback
        this.voiceSession.onResponse((event)=>{
            this.handleAudioResponse(event.audioData.toString()); // Convert Blob to string if needed
        });
        // TODO: Add session ready, error, and disconnect handlers when VoiceSession API is complete
        console.log('🔗 [VOICE BRIDGE] Voice session handlers setup complete');
    }
    async handleUserTranscript(transcript) {
        try {
            this.state.lastActivity = Date.now();
            console.log('📝 [VOICE BRIDGE] User transcript received', {
                transcript: transcript.substring(0, 100) + (transcript.length > 100 ? '...' : ''),
                length: transcript.length
            });
            // Add to transcript
            this.addToTranscript('user', transcript);
            // Emit transcript event
            const transcriptEntry = {
                id: `transcript-${Date.now()}`,
                timestamp: Date.now(),
                speaker: 'user',
                text: transcript,
                confidence: 0.95 // Will be real confidence from Azure
            };
            this.emit('transcript:final', {
                sessionId: this.voiceSession.sessionId,
                entry: transcriptEntry
            });
            // Perform sentiment analysis if enabled
            if (this.config.sentimentMonitoring) {
                this.performSentimentAnalysis(transcript, 'user');
            }
            // Route to agent orchestrator if available
            if (this.agentOrchestrator?.handleInput) {
                this.emit('agent:thinking', {
                    agent: this.state.currentAgent || 'system',
                    isThinking: true
                });
                const response = await this.agentOrchestrator.handleInput(transcript, {
                    sessionId: this.voiceSession.sessionId,
                    currentAgent: this.state.currentAgent,
                    context: this.getConversationContext()
                });
                this.emit('agent:thinking', {
                    agent: this.state.currentAgent || 'system',
                    isThinking: false
                });
                if (response) {
                    await this.sendAudioResponse(response.text, response.audioData);
                }
            }
        } catch (error) {
            const transcriptError = error instanceof Error ? error : new Error('Failed to handle transcript');
            voice_telemetry.VoiceTelemetry.trackError(transcriptError, this.voiceSession.sessionId, 'TRANSCRIPT_PROCESSING_FAILED');
            this.handleError(transcriptError);
        }
    }
    handleAudioResponse(audioData) {
        this.state.lastActivity = Date.now();
        this.emit('audio:synthesis:complete', {
            sessionId: this.voiceSession.sessionId,
            audioData
        });
        // Add to recording if enabled
        if (this.config.recordingEnabled) {
            this.addAudioToRecording('agent', audioData);
        }
    }
    addToTranscript(speaker, text) {
        const entry = {
            id: `transcript-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            timestamp: Date.now(),
            speaker,
            text,
            confidence: speaker === 'user' ? 0.95 : 1.0
        };
        this.transcript.push(entry);
        // Store transcript based on configuration
        if (this.config.transcriptStorage === 'persistent' || this.config.transcriptStorage === 'both') {
            this.persistTranscript(entry);
        }
        console.log(`📝 [VOICE BRIDGE] Added to transcript`, {
            speaker,
            length: text.length,
            totalEntries: this.transcript.length
        });
    }
    initializeRecording() {
        if (!this.config.recordingEnabled) {
            return;
        }
        this.recording = {
            sessionId: this.voiceSession.sessionId,
            startTime: Date.now(),
            totalDuration: 0,
            chunks: [],
            storageLocation: {
                containerName: 'voice-recordings',
                blobName: `session-${this.voiceSession.sessionId}-${Date.now()}.wav`
            },
            processingStatus: 'uploading'
        };
        console.log('🎙️ [VOICE BRIDGE] Recording initialized', {
            sessionId: this.voiceSession.sessionId,
            blobName: this.recording.storageLocation.blobName
        });
    }
    addAudioToRecording(speaker, audioData) {
        if (!this.recording || !this.config.recordingEnabled) {
            return;
        }
        try {
            // Decode base64 audio data
            const audioBuffer = this.base64ToArrayBuffer(audioData);
            const chunk = {
                id: `chunk-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                sessionId: this.voiceSession.sessionId,
                timestamp: Date.now(),
                duration: 1000,
                format: 'pcm16',
                sampleRate: 16000,
                data: audioBuffer,
                metadata: {
                    speaker,
                    quality: 'medium',
                    noiseLevel: 0.1
                }
            };
            this.recording.chunks.push(chunk);
            this.recording.totalDuration += chunk.duration;
            console.log('🎵 [VOICE BRIDGE] Audio chunk added to recording', {
                speaker,
                chunkId: chunk.id,
                totalChunks: this.recording.chunks.length
            });
        } catch (error) {
            console.error('❌ [VOICE BRIDGE] Failed to add audio to recording:', error);
        }
    }
    finalizeRecording() {
        if (!this.recording) {
            return;
        }
        this.recording.endTime = Date.now();
        this.recording.processingStatus = 'processing';
        // In a real implementation, this would upload to blob storage
        console.log('📦 [VOICE BRIDGE] Recording finalized', {
            sessionId: this.voiceSession.sessionId,
            duration: this.recording.totalDuration,
            chunks: this.recording.chunks.length
        });
    }
    performSentimentAnalysis(text, speaker) {
        // Simple sentiment analysis implementation
        // In production, this would use Azure Cognitive Services
        const stressWords = [
            'nervous',
            'worried',
            'difficult',
            'hard',
            'struggle',
            'confused',
            'stuck'
        ];
        const positiveWords = [
            'good',
            'great',
            'excellent',
            'confident',
            'sure',
            'excited',
            'happy'
        ];
        const words = text.toLowerCase().split(' ');
        const stressWordCount = words.filter((word)=>stressWords.includes(word)).length;
        const positiveWordCount = words.filter((word)=>positiveWords.includes(word)).length;
        let score = 0;
        if (positiveWordCount > stressWordCount) {
            score = 0.7;
        } else if (stressWordCount > positiveWordCount) {
            score = -0.5;
        }
        const sentiment = {
            score,
            magnitude: Math.abs(score),
            label: score > 0.5 ? 'positive' : score < -0.3 ? 'negative' : 'neutral',
            confidence: 0.8,
            stressIndicators: {
                hasHighStressWords: stressWordCount > 0,
                stressWords: words.filter((word)=>stressWords.includes(word)),
                speechPattern: stressWordCount > 2 ? 'hesitant' : 'normal',
                emotionalState: score > 0.5 ? 'calm' : score < -0.3 ? 'nervous' : 'calm'
            }
        };
        this.emit('sentiment:analysis', {
            sessionId: this.voiceSession.sessionId,
            sentiment
        });
        if (sentiment.stressIndicators.hasHighStressWords && speaker === 'user') {
            this.emit('sentiment:stress:detected', {
                sessionId: this.voiceSession.sessionId,
                level: stressWordCount > 2 ? 'high' : 'moderate',
                suggestions: [
                    'Consider taking a brief pause',
                    'Remind the candidate to take their time',
                    'Ask if they need clarification'
                ]
            });
        }
    }
    getAgentVoiceSettings(agentName) {
        // Return agent-specific voice settings
        // This would be expanded when agent classes are implemented
        const agentSettings = {
            'technical': {
                voice: 'en-US-JennyNeural',
                temperature: 0.7,
                responseStyle: 'detailed'
            },
            'behavioral': {
                voice: 'en-US-AvaMultilingualNeural',
                temperature: 0.8,
                responseStyle: 'empathetic'
            },
            'general': {
                voice: 'en-US-AriaNeural',
                temperature: 0.6,
                responseStyle: 'conversational'
            }
        };
        return agentSettings[agentName] || {};
    }
    getConversationContext() {
        return {
            transcriptLength: this.transcript.length,
            lastMessages: this.transcript.slice(-5),
            sessionDuration: Date.now() - (this.recording?.startTime || Date.now()),
            currentAgent: this.state.currentAgent,
            errorCount: this.state.errorCount
        };
    }
    persistTranscript(entry) {
        // In production, this would save to persistent storage
        console.log('💾 [VOICE BRIDGE] Transcript entry persisted', {
            id: entry.id,
            speaker: entry.speaker,
            length: entry.text.length
        });
    }
    setupActivityTimeout() {
        const checkActivity = ()=>{
            const timeSinceActivity = Date.now() - this.state.lastActivity;
            if (timeSinceActivity > this.config.sessionTimeout) {
                console.log('⏰ [VOICE BRIDGE] Session timeout reached');
                this.stop();
                return;
            }
            setTimeout(checkActivity, 60000); // Check every minute
        };
        setTimeout(checkActivity, 60000);
    }
    handleError(error) {
        this.state.errorCount++;
        console.error('💥 [VOICE BRIDGE] Error occurred', {
            message: error.message,
            errorCount: this.state.errorCount
        });
        this.emit('session:error', {
            sessionId: this.voiceSession.sessionId,
            error
        });
        // Implement recovery based on configuration
        if (this.config.errorRecoveryMode === 'graceful' && this.state.errorCount < this.config.maxRetries) {
            this.attemptRecovery();
        }
    }
    async attemptRecovery() {
        if (this.state.recovery.inProgress) {
            return;
        }
        this.state.recovery.inProgress = true;
        this.state.recovery.attempts++;
        this.state.recovery.lastAttempt = Date.now();
        try {
            console.log('🔧 [VOICE BRIDGE] Attempting recovery', {
                attempt: this.state.recovery.attempts,
                maxRetries: this.config.maxRetries
            });
            // Simple recovery: try to reconnect voice session
            if (this.voiceSession.getState() !== 'active') {
                await this.voiceSession.start();
            }
            this.state.recovery.inProgress = false;
            console.log('✅ [VOICE BRIDGE] Recovery successful');
        } catch (error) {
            this.state.recovery.inProgress = false;
            console.error('❌ [VOICE BRIDGE] Recovery failed:', error);
            if (this.state.recovery.attempts >= this.config.maxRetries) {
                console.error('🚨 [VOICE BRIDGE] Max recovery attempts reached, stopping bridge');
                this.stop();
            }
        }
    }
    base64ToArrayBuffer(base64) {
        const binaryString = atob(base64);
        const bytes = new Uint8Array(binaryString.length);
        for(let i = 0; i < binaryString.length; i++){
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes.buffer;
    }
}

;// ./lib/azure-ai-foundry/voice/voice-session.ts
/**
 * Azure AI Foundry Voice Session
 * 
 * Manages the lifecycle of a voice streaming session, including audio input/output,
 * transcript handling, and WebSocket communication.
 */ 
/**
 * Voice Session class for managing real-time voice streaming
 */ class VoiceSession {
    constructor(client, sessionMeta){
        this.state = 'idle';
        this.audioContext = null;
        this.mediaStream = null;
        this.audioWorkletNode = null;
        this.transcriptCallbacks = new Set();
        this.responseCallbacks = new Set();
        this.audioConfig = {
            sampleRate: 16000,
            channels: 1,
            chunkDurationMs: 20,
            bufferSize: 320 // 20ms * 16kHz = 320 samples
        };
        // Cleanup handling
        this.cleanupHandlers = new Set();
        this.isPageUnloading = false;
        this.client = client;
        this.sessionMeta = sessionMeta;
        this.websocketManager = client.createWebSocketManager(sessionMeta);
        // Setup page unload cleanup
        this.setupPageUnloadCleanup();
    }
    /**
   * Start the voice session and begin audio streaming
   */ async start(audioStream) {
        if (this.state !== 'idle') {
            console.warn(`⚠️ [VoiceSession] Cannot start: current state is ${this.state}`);
            return;
        }
        this.state = 'starting';
        const sessionStartTime = Date.now();
        console.log(`🚀 [VoiceSession] Starting session ${this.sessionMeta.sessionId}...`);
        // Initialize telemetry for this session
        voice_telemetry.VoiceTelemetry.startSession(this.sessionMeta.sessionId);
        try {
            // Initialize audio context
            await this.initializeAudioContext();
            // Get audio stream (use provided or request new one)
            if (audioStream) {
                this.mediaStream = audioStream;
            } else {
                await this.requestMicrophoneAccess();
            }
            // Connect WebSocket
            await this.websocketManager.connect();
            // Setup WebSocket event handlers
            this.setupWebSocketHandlers();
            // Start audio processing
            await this.startAudioProcessing();
            this.state = 'active';
            console.log(`✅ [VoiceSession] Session ${this.sessionMeta.sessionId} started successfully`);
        } catch (error) {
            console.error(`❌ [VoiceSession] Failed to start session:`, error);
            this.state = 'error';
            await this.cleanup();
            throw error;
        }
    }
    /**
   * Register callback for transcript events
   */ onTranscript(callback) {
        this.transcriptCallbacks.add(callback);
        // Add cleanup handler
        this.cleanupHandlers.add(()=>{
            this.transcriptCallbacks.delete(callback);
        });
    }
    /**
   * Register callback for audio response events
   */ onResponse(callback) {
        this.responseCallbacks.add(callback);
        // Add cleanup handler
        this.cleanupHandlers.add(()=>{
            this.responseCallbacks.delete(callback);
        });
    }
    /**
   * Stop the session gracefully
   */ async stop(graceful = true) {
        if (this.state === 'stopped' || this.state === 'stopping') {
            return;
        }
        this.state = 'stopping';
        console.log(`🛑 [VoiceSession] Stopping session ${this.sessionMeta.sessionId}...`);
        try {
            if (graceful) {
                // Send final audio chunk and wait for pending responses
                await this.flushAudioBuffers();
                await this.waitForPendingResponses();
            }
            // Close WebSocket connection
            this.websocketManager.close(graceful ? 1000 : 1001, graceful ? 'Normal closure' : 'Forced closure');
            // Clean up audio resources
            await this.cleanup();
            // Remove from client's active sessions
            this.client.removeSession(this.sessionMeta.sessionId);
            this.state = 'stopped';
            console.log(`✅ [VoiceSession] Session ${this.sessionMeta.sessionId} stopped successfully`);
        } catch (error) {
            console.error(`❌ [VoiceSession] Error stopping session:`, error);
            this.state = 'error';
            throw error;
        }
    }
    /**
   * Get current session state
   */ getState() {
        return this.state;
    }
    /**
   * Get session ID
   */ get sessionId() {
        return this.sessionMeta.sessionId;
    }
    /**
   * Get session metadata
   */ getMetadata() {
        return {
            ...this.sessionMeta
        };
    }
    /**
   * Initialize audio context with optimal settings
   */ async initializeAudioContext() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)({
                sampleRate: this.audioConfig.sampleRate,
                latencyHint: 'interactive'
            });
            // Resume context if suspended (required by browser policies)
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }
            console.log(`🎵 [VoiceSession] Audio context initialized: ${this.audioContext.sampleRate}Hz`);
        } catch (error) {
            console.error('❌ [VoiceSession] Failed to initialize audio context:', error);
            throw new Error('Audio context initialization failed');
        }
    }
    /**
   * Request microphone access
   */ async requestMicrophoneAccess() {
        try {
            this.mediaStream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    sampleRate: this.audioConfig.sampleRate,
                    channelCount: this.audioConfig.channels,
                    echoCancellation: this.sessionMeta.options.audioSettings?.echoCancellation ?? true,
                    noiseSuppression: this.sessionMeta.options.audioSettings?.noiseSuppression ?? true,
                    autoGainControl: true
                }
            });
            console.log('🎤 [VoiceSession] Microphone access granted');
        } catch (error) {
            console.error('❌ [VoiceSession] Failed to access microphone:', error);
            throw new Error('Microphone access denied or failed');
        }
    }
    /**
   * Setup WebSocket event handlers
   */ setupWebSocketHandlers() {
        // Handle transcript events
        this.websocketManager.on('transcript', (data)=>{
            const transcriptEvent = {
                text: data.text || '',
                timestamp: data.timestamp || Date.now(),
                confidence: data.confidence,
                isFinal: data.is_final || false
            };
            console.log(`📝 [VoiceSession] Transcript: "${transcriptEvent.text}" (confidence: ${transcriptEvent.confidence})`);
            // Track transcript event with telemetry
            voice_telemetry.VoiceTelemetry.getInstance().logTranscriptEvent(transcriptEvent.isFinal ? 'transcript_final' : 'transcript_partial', this.sessionMeta.sessionId, transcriptEvent.text, transcriptEvent.confidence);
            this.transcriptCallbacks.forEach((callback)=>{
                try {
                    callback(transcriptEvent);
                } catch (error) {
                    console.error('❌ [VoiceSession] Transcript callback error:', error);
                    voice_telemetry.VoiceTelemetry.trackError(error, this.sessionMeta.sessionId, 'Transcript callback');
                }
            });
        });
        // Handle audio response events
        this.websocketManager.on('response', async (data)=>{
            if (data.audio_data) {
                try {
                    // Convert audio data to blob
                    const audioData = new Uint8Array(data.audio_data);
                    const audioBlob = new Blob([
                        audioData
                    ], {
                        type: 'audio/wav'
                    });
                    const responseEvent = {
                        audioData: audioBlob,
                        timestamp: data.timestamp || Date.now(),
                        duration: data.duration
                    };
                    console.log(`🔊 [VoiceSession] Audio response received (${audioBlob.size} bytes)`);
                    // Play audio response
                    await this.playAudioResponse(audioBlob);
                    this.responseCallbacks.forEach((callback)=>{
                        try {
                            callback(responseEvent);
                        } catch (error) {
                            console.error('❌ [VoiceSession] Response callback error:', error);
                        }
                    });
                } catch (error) {
                    console.error('❌ [VoiceSession] Failed to process audio response:', error);
                }
            }
        });
        // Handle connection events
        this.websocketManager.on('disconnected', (event)=>{
            console.warn(`⚠️ [VoiceSession] WebSocket disconnected: ${event.code} ${event.reason}`);
            if (this.state === 'active' && !this.isPageUnloading) {
                // Auto-reconnect logic is handled by WebSocketManager
                console.log('🔄 [VoiceSession] WebSocket will attempt to reconnect...');
            }
        });
        // Handle errors
        this.websocketManager.on('error', (error)=>{
            console.error('❌ [VoiceSession] WebSocket error:', error);
            this.state = 'error';
        });
    }
    /**
   * Start audio processing and streaming
   */ async startAudioProcessing() {
        if (!this.audioContext || !this.mediaStream) {
            throw new Error('Audio context or media stream not initialized');
        }
        try {
            // Create audio source from media stream
            const source = this.audioContext.createMediaStreamSource(this.mediaStream);
            // Create processor for audio chunking
            this.audioWorkletNode = await this.createAudioWorkletNode();
            // Connect audio pipeline
            source.connect(this.audioWorkletNode);
            console.log('🎵 [VoiceSession] Audio processing pipeline started');
        } catch (error) {
            console.error('❌ [VoiceSession] Failed to start audio processing:', error);
            throw error;
        }
    }
    /**
   * Create audio worklet node for processing audio chunks
   */ async createAudioWorkletNode() {
        if (!this.audioContext) {
            throw new Error('Audio context not initialized');
        }
        // Create a simple ScriptProcessorNode as fallback if AudioWorklet is not available
        // In production, you'd want to implement a proper AudioWorklet
        const bufferSize = 4096; // Fixed buffer size for ScriptProcessorNode
        const processor = this.audioContext.createScriptProcessor(bufferSize, 1, 1);
        processor.onaudioprocess = (event)=>{
            const inputBuffer = event.inputBuffer.getChannelData(0);
            // Create audio frame
            const audioFrame = {
                audioData: inputBuffer.buffer.slice(0),
                timestamp: Date.now(),
                sampleRate: this.audioConfig.sampleRate,
                channels: this.audioConfig.channels
            };
            // Send audio frame to WebSocket
            if (this.websocketManager.getState() === 'connected') {
                this.websocketManager.sendAudioFrame(audioFrame);
            }
        };
        // Connect to destination to keep the processor active
        processor.connect(this.audioContext.destination);
        return processor; // Type assertion for compatibility
    }
    /**
   * Play audio response through speakers
   */ async playAudioResponse(audioBlob) {
        try {
            if (!this.audioContext) {
                throw new Error('Audio context not available');
            }
            // Convert blob to array buffer
            const arrayBuffer = await audioBlob.arrayBuffer();
            // Decode audio data
            const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
            // Create audio source
            const source = this.audioContext.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(this.audioContext.destination);
            // Play audio
            source.start();
            console.log(`🔊 [VoiceSession] Playing audio response (${audioBuffer.duration.toFixed(2)}s)`);
        } catch (error) {
            console.error('❌ [VoiceSession] Failed to play audio response:', error);
        // Don't throw error to avoid breaking the session
        }
    }
    /**
   * Flush any pending audio buffers
   */ async flushAudioBuffers() {
        // Implementation depends on the audio processing pipeline
        console.log('🔄 [VoiceSession] Flushing audio buffers...');
        // Send a flush signal to the WebSocket
        const flushMessage = {
            type: 'control',
            data: {
                action: 'flush'
            },
            sessionId: this.sessionMeta.sessionId,
            timestamp: Date.now()
        };
        this.websocketManager.send(JSON.stringify(flushMessage));
        // Wait a bit for any pending audio to be processed
        await new Promise((resolve)=>setTimeout(resolve, 100));
    }
    /**
   * Wait for any pending responses to complete
   */ async waitForPendingResponses() {
        console.log('⏳ [VoiceSession] Waiting for pending responses...');
        // Simple timeout-based wait - in production, you'd track pending requests
        await new Promise((resolve)=>setTimeout(resolve, 500));
    }
    /**
   * Setup page unload cleanup
   */ setupPageUnloadCleanup() {
        const handlePageUnload = ()=>{
            this.isPageUnloading = true;
            this.stop(false); // Force stop on page unload
        };
        window.addEventListener('beforeunload', handlePageUnload);
        window.addEventListener('unload', handlePageUnload);
        this.cleanupHandlers.add(()=>{
            window.removeEventListener('beforeunload', handlePageUnload);
            window.removeEventListener('unload', handlePageUnload);
        });
    }
    /**
   * Clean up all resources
   */ async cleanup() {
        console.log('🧹 [VoiceSession] Cleaning up resources...');
        // Stop media stream
        if (this.mediaStream) {
            this.mediaStream.getTracks().forEach((track)=>{
                track.stop();
                console.log(`🛑 [VoiceSession] Stopped ${track.kind} track`);
            });
            this.mediaStream = null;
        }
        // Disconnect audio nodes
        if (this.audioWorkletNode) {
            this.audioWorkletNode.disconnect();
            this.audioWorkletNode = null;
        }
        // Close audio context
        if (this.audioContext && this.audioContext.state !== 'closed') {
            await this.audioContext.close();
            this.audioContext = null;
        }
        // Run cleanup handlers
        this.cleanupHandlers.forEach((handler)=>{
            try {
                handler();
            } catch (error) {
                console.error('❌ [VoiceSession] Cleanup handler error:', error);
            }
        });
        this.cleanupHandlers.clear();
        // Clear callbacks
        this.transcriptCallbacks.clear();
        this.responseCallbacks.clear();
        console.log('✅ [VoiceSession] Cleanup completed');
    }
}

// EXTERNAL MODULE: ./node_modules/@microsoft/applicationinsights-web/dist-es5/AISku.js + 101 modules
var AISku = __webpack_require__(66145);
;// ./lib/azure-ai-foundry/voice/voice-insights.ts
/**
 * Voice Insights - Application Insights integration for voice system
 * 
 * Provides structured logging, metrics collection, and error tracking
 * for the Azure AI Foundry voice interview system.
 */ 

class VoiceInsights {
    /**
   * Initialize Application Insights for voice telemetry
   */ initialize(connectionString) {
        try {
            // Get connection string from environment or parameter
            const insightsConnectionString = connectionString || process.env.NEXT_PUBLIC_APPLICATIONINSIGHTS_CONNECTION_STRING || process.env.APPLICATIONINSIGHTS_CONNECTION_STRING;
            if (!insightsConnectionString) {
                utils_logger/* logger */.vF.warn('[Voice Insights] Application Insights connection string not provided, using console fallback');
                this.isInitialized = true; // Still mark as initialized for local development
                return;
            }
            this.appInsights = new AISku/* AppInsightsSku */.M({
                config: {
                    connectionString: insightsConnectionString,
                    // Voice-specific configuration
                    disableFetchTracking: false,
                    disableAjaxTracking: false,
                    disableExceptionTracking: false,
                    enableAutoRouteTracking: true,
                    enableCorsCorrelation: true,
                    enableRequestHeaderTracking: true,
                    enableResponseHeaderTracking: true,
                    // Performance optimizations
                    samplingPercentage:  true ? 10 : 0,
                    maxBatchInterval: 2000,
                    maxBatchSizeInBytes: 64000
                }
            });
            this.appInsights.loadAppInsights();
            this.setupCustomTelemetryProcessor();
            this.isInitialized = true;
            utils_logger/* logger */.vF.success('[Voice Insights] Application Insights initialized successfully');
            // Track initialization
            this.trackEvent('voice_insights_initialized', {
                environment: "production" || 0,
                version: process.env.NEXT_PUBLIC_APP_VERSION || '1.0.0'
            });
        } catch (error) {
            utils_logger/* logger */.vF.error('[Voice Insights] Failed to initialize Application Insights', error);
            this.isInitialized = true; // Fallback to console logging
        }
    }
    /**
   * Set up custom telemetry processor for voice-specific data
   */ setupCustomTelemetryProcessor() {
        if (!this.appInsights) return;
        // TODO: Find correct method name for adding telemetry processor in web SDK
        // this.appInsights.addTelemetryProcessor((envelope) => {
        //   // Add voice system context to all telemetry
        //   if (envelope.data && envelope.data.baseData) {
        //     envelope.data.baseData.properties = {
        //       ...envelope.data.baseData.properties,
        //       system: 'voice-interview',
        //       timestamp: new Date().toISOString()
        //     };
        //   }
        //   
        //   return true;
        // });
        utils_logger/* logger */.vF.info('[Voice Insights] Custom telemetry processor setup skipped (not supported in web SDK)');
    }
    /**
   * Track voice session lifecycle events
   */ trackVoiceSession(event, data) {
        const eventName = `voice_${event}`;
        const properties = {
            sessionId: data.sessionId,
            userId: data.userId || 'anonymous',
            interviewType: data.interviewType || 'general',
            connectionState: data.connectionState,
            duration: data.duration?.toString(),
            audioLatency: data.audioLatency?.toString(),
            transcriptionAccuracy: data.transcriptionAccuracy?.toString(),
            errorCount: data.errorCount?.toString(),
            retryAttempts: data.retryAttempts?.toString()
        };
        const measurements = {
            duration: data.duration || 0,
            audioLatency: data.audioLatency || 0,
            transcriptionAccuracy: data.transcriptionAccuracy || 0,
            errorCount: data.errorCount || 0,
            retryAttempts: data.retryAttempts || 0
        };
        this.trackEvent(eventName, properties, measurements);
        // Log for development
        utils_logger/* logger */.vF.info(`[Voice Insights] ${eventName}`, {
            sessionId: data.sessionId,
            state: data.connectionState,
            duration: data.duration
        });
    }
    /**
   * Track voice system errors with detailed context
   */ trackVoiceError(error) {
        const properties = {
            sessionId: error.sessionId,
            errorType: error.errorType,
            errorCode: error.errorCode || 'unknown',
            errorMessage: error.errorMessage,
            isRecoverable: error.isRecoverable.toString(),
            stackTrace: error.stackTrace,
            ...error.context
        };
        // Track as both event and exception
        this.trackEvent('voice_error', properties);
        if (this.appInsights && error.stackTrace) {
            this.appInsights.trackException({
                exception: new Error(error.errorMessage),
                properties,
                severityLevel: error.isRecoverable ? 1 : 3 // Warning vs Error
            });
        }
        utils_logger/* logger */.vF.error(`[Voice Insights] Voice error - ${error.errorType}`, {
            sessionId: error.sessionId,
            errorCode: error.errorCode,
            message: error.errorMessage,
            recoverable: error.isRecoverable
        });
    }
    /**
   * Track voice performance metrics
   */ trackVoiceMetric(metric) {
        const properties = {
            sessionId: metric.sessionId,
            metricName: metric.metricName,
            unit: metric.unit,
            timestamp: metric.timestamp.toString(),
            ...metric.tags
        };
        const measurements = {
            [metric.metricName]: metric.value
        };
        this.trackEvent('voice_metric', properties, measurements);
        // Track as custom metric if available
        if (this.appInsights) {
            this.appInsights.trackMetric({
                name: `voice_${metric.metricName}`,
                average: metric.value
            }, properties);
        }
        // Log significant metrics
        if (metric.metricName === 'stt_latency' && metric.value > 1000) {
            utils_logger/* logger */.vF.warn('[Voice Insights] High STT latency detected', {
                sessionId: metric.sessionId,
                latency: metric.value
            });
        }
    }
    /**
   * Track feature usage for quota and analytics
   */ trackVoiceUsage(usage) {
        const properties = {
            sessionId: usage.sessionId,
            userId: usage.userId,
            featureUsed: usage.featureUsed,
            interactionCount: usage.interactionCount.toString(),
            duration: usage.duration.toString(),
            quotaUsed: usage.quotaUsed?.toString(),
            quotaRemaining: usage.quotaRemaining?.toString()
        };
        const measurements = {
            interactionCount: usage.interactionCount,
            duration: usage.duration,
            quotaUsed: usage.quotaUsed || 0,
            quotaRemaining: usage.quotaRemaining || 0
        };
        this.trackEvent('voice_usage', properties, measurements);
        utils_logger/* logger */.vF.info('[Voice Insights] Feature usage tracked', {
            feature: usage.featureUsed,
            user: usage.userId,
            interactions: usage.interactionCount
        });
    }
    /**
   * Track custom voice events
   */ trackVoiceEvent(eventName, properties, measurements) {
        this.trackEvent(`voice_${eventName}`, properties, measurements);
    }
    /**
   * Batch track multiple events for performance
   */ batchTrackEvents(sessionId, events) {
        if (!this.isInitialized) return;
        // Add to session buffer
        if (!this.sessionBuffer.has(sessionId)) {
            this.sessionBuffer.set(sessionId, []);
        }
        const buffer = this.sessionBuffer.get(sessionId);
        buffer.push(...events);
        // Flush if buffer is full
        if (buffer.length >= this.maxBufferSize) {
            this.flushSessionBuffer(sessionId);
        }
    }
    /**
   * Flush buffered events for a session
   */ flushSessionBuffer(sessionId) {
        const buffer = this.sessionBuffer.get(sessionId);
        if (!buffer || buffer.length === 0) return;
        utils_logger/* logger */.vF.info('[Voice Insights] Flushing session buffer', {
            sessionId,
            eventCount: buffer.length
        });
        // Track all buffered events
        for (const event of buffer){
            this.trackEvent(event.name, event.properties, event.measurements);
        }
        // Clear buffer
        this.sessionBuffer.delete(sessionId);
    }
    /**
   * Generic event tracking with fallback
   */ trackEvent(eventName, properties, measurements) {
        if (!this.isInitialized) {
            utils_logger/* logger */.vF.info(`[Voice Insights] ${eventName}`, {
                properties,
                measurements
            });
            return;
        }
        try {
            if (this.appInsights) {
                this.appInsights.trackEvent({
                    name: eventName,
                    properties: properties || {},
                    measurements: measurements || {}
                });
            } else {
                // Fallback to console logging
                utils_logger/* logger */.vF.info(`[Voice Insights] ${eventName}`, {
                    properties,
                    measurements
                });
            }
        } catch (error) {
            utils_logger/* logger */.vF.error('[Voice Insights] Failed to track event', error);
        }
    }
    /**
   * Set user context for telemetry correlation
   */ setUser(userId, accountId) {
        if (!this.appInsights) return;
        this.appInsights.setAuthenticatedUserContext(userId, accountId);
        utils_logger/* logger */.vF.info('[Voice Insights] User context set', {
            userId,
            accountId
        });
    }
    /**
   * Clear user context
   */ clearUser() {
        if (!this.appInsights) return;
        this.appInsights.clearAuthenticatedUserContext();
        utils_logger/* logger */.vF.info('[Voice Insights] User context cleared');
    }
    /**
   * Force flush all pending telemetry
   */ flush() {
        if (!this.appInsights) return;
        this.appInsights.flush();
        // Flush all session buffers
        for (const sessionId of this.sessionBuffer.keys()){
            this.flushSessionBuffer(sessionId);
        }
        utils_logger/* logger */.vF.info('[Voice Insights] Telemetry flushed');
    }
    /**
   * Get initialization status
   */ get initialized() {
        return this.isInitialized;
    }
    /**
   * Get Application Insights instance
   */ get instance() {
        return this.appInsights;
    }
    constructor(){
        this.appInsights = null;
        this.isInitialized = false;
        this.instrumentationKey = null;
        this.sessionBuffer = new Map();
        this.maxBufferSize = 100;
    }
}
// Export singleton instance
const voiceInsights = new VoiceInsights();
// Auto-initialize with environment variables
if (false) {}
/* harmony default export */ const voice_insights = ((/* unused pure expression or super */ null && (voiceInsights)));

;// ./lib/voice/agent-state.ts
/**
 * Centralized state management for Agent component
 * Replaces scattered useState calls with a unified reducer pattern
 */ // Interview state enum
var InterviewState = /*#__PURE__*/ function(InterviewState) {
    InterviewState["READY"] = "READY";
    InterviewState["ACTIVE"] = "ACTIVE";
    InterviewState["FINISHED"] = "FINISHED";
    return InterviewState;
}({});
// Audio processing state
var AudioState = /*#__PURE__*/ function(AudioState) {
    AudioState["IDLE"] = "IDLE";
    AudioState["RECORDING"] = "RECORDING";
    AudioState["PROCESSING"] = "PROCESSING";
    AudioState["SPEAKING"] = "SPEAKING";
    AudioState["WAITING"] = "WAITING";
    return AudioState;
}({});
// Initial state
const initialAgentState = {
    interviewState: "READY",
    audioState: "IDLE",
    messages: [],
    questionNumber: 0,
    hasUserSpoken: false,
    isInterviewComplete: false,
    userImage: "",
    feedbackGenerated: false,
    generatedFeedbackId: null,
    audioStream: null
};
// State reducer with comprehensive action handling
const agentReducer = (state, action)=>{
    switch(action.type){
        case 'SET_INTERVIEW_STATE':
            return {
                ...state,
                interviewState: action.payload
            };
        case 'SET_AUDIO_STATE':
            return {
                ...state,
                audioState: action.payload
            };
        case 'ADD_MESSAGE':
            return {
                ...state,
                messages: [
                    ...state.messages,
                    action.payload
                ]
            };
        case 'ADD_MESSAGES':
            return {
                ...state,
                messages: [
                    ...state.messages,
                    ...action.payload
                ]
            };
        case 'SET_USER_SPOKEN':
            return {
                ...state,
                hasUserSpoken: action.payload
            };
        case 'SET_QUESTION_NUMBER':
            return {
                ...state,
                questionNumber: action.payload
            };
        case 'SET_INTERVIEW_COMPLETE':
            return {
                ...state,
                isInterviewComplete: action.payload
            };
        case 'SET_USER_IMAGE':
            return {
                ...state,
                userImage: action.payload
            };
        case 'SET_FEEDBACK_GENERATED':
            return {
                ...state,
                feedbackGenerated: action.payload.generated,
                generatedFeedbackId: action.payload.id
            };
        case 'SET_AUDIO_STREAM':
            return {
                ...state,
                audioStream: action.payload
            };
        case 'START_RECORDING':
            return {
                ...state,
                audioState: "RECORDING"
            };
        case 'STOP_RECORDING':
            return {
                ...state,
                audioState: "PROCESSING"
            };
        case 'START_AI_PROCESSING':
            return {
                ...state,
                audioState: "PROCESSING"
            };
        case 'START_SPEAKING':
            return {
                ...state,
                audioState: "SPEAKING"
            };
        case 'RESET_TO_WAITING':
            return {
                ...state,
                audioState: "WAITING"
            };
        case 'END_INTERVIEW':
            return {
                ...state,
                interviewState: "FINISHED",
                audioState: "IDLE",
                audioStream: null
            };
        case 'RESET_INTERVIEW':
            return {
                ...initialAgentState,
                userImage: state.userImage
            };
        default:
            return state;
    }
};
// Derived state selectors (computed properties)
const selectIsRecording = (state)=>state.audioState === "RECORDING";
const selectIsProcessing = (state)=>state.audioState === "PROCESSING";
const selectIsSpeaking = (state)=>state.audioState === "SPEAKING";
const selectIsWaiting = (state)=>state.audioState === "WAITING";
const selectIsInterviewActive = (state)=>state.interviewState === "ACTIVE";
const selectIsInterviewFinished = (state)=>state.interviewState === "FINISHED";
const selectCanStartRecording = (state)=>state.interviewState === "ACTIVE" && state.audioState === "WAITING";
const selectShouldShowFeedback = (state)=>state.feedbackGenerated && state.generatedFeedbackId !== null && state.interviewState === "FINISHED";
// Action creators for common state transitions
const createStartInterviewAction = ()=>({
        type: 'SET_INTERVIEW_STATE',
        payload: "ACTIVE"
    });
const createEndInterviewAction = ()=>({
        type: 'END_INTERVIEW'
    });
const createStartRecordingAction = ()=>({
        type: 'START_RECORDING'
    });
const createStopRecordingAction = ()=>({
        type: 'STOP_RECORDING'
    });
const createAddUserMessageAction = (content)=>({
        type: 'ADD_MESSAGE',
        payload: {
            role: 'user',
            content
        }
    });
const createAddAIMessageAction = (content)=>({
        type: 'ADD_MESSAGE',
        payload: {
            role: 'assistant',
            content
        }
    });
const createUserSpokeAction = ()=>({
        type: 'SET_USER_SPOKEN',
        payload: true
    });
const createProcessingCompleteAction = (aiMessage, questionNumber, isComplete)=>{
    const actions = [
        {
            type: 'ADD_MESSAGE',
            payload: {
                role: 'assistant',
                content: aiMessage
            }
        },
        {
            type: 'RESET_TO_WAITING'
        }
    ];
    if (questionNumber !== undefined) {
        actions.push({
            type: 'SET_QUESTION_NUMBER',
            payload: questionNumber
        });
    }
    if (isComplete !== undefined) {
        actions.push({
            type: 'SET_INTERVIEW_COMPLETE',
            payload: isComplete
        });
    }
    return actions;
};

;// ./lib/azure-ai-foundry/voice/useVoiceAgentBridge.ts
/**
 * Voice Agent Bridge React Hook
 * 
 * Integrates Azure AI Foundry voice system with existing agent state management.
 * Provides a seamless bridge between real-time voice interactions and React state.
 */ 





// Import existing agent state management

const initialVoiceBridgeState = {
    bridge: null,
    voiceSession: null,
    sessionId: null,
    connectionState: 'idle',
    lastError: null,
    retryCount: 0,
    isInitializing: false
};
function voiceBridgeReducer(state, action) {
    switch(action.type){
        case 'BRIDGE_INITIALIZING':
            return {
                ...state,
                isInitializing: true,
                lastError: null,
                connectionState: 'connecting'
            };
        case 'BRIDGE_CREATED':
            return {
                ...state,
                bridge: action.payload.bridge,
                voiceSession: action.payload.voiceSession,
                sessionId: action.payload.sessionId,
                connectionState: 'connected',
                isInitializing: false,
                lastError: null,
                retryCount: 0
            };
        case 'CONNECTION_STATE_CHANGED':
            return {
                ...state,
                connectionState: action.payload
            };
        case 'ERROR_OCCURRED':
            return {
                ...state,
                lastError: action.payload,
                connectionState: 'error',
                isInitializing: false
            };
        case 'RETRY_ATTEMPTED':
            return {
                ...state,
                retryCount: state.retryCount + 1,
                connectionState: 'connecting',
                lastError: null
            };
        case 'BRIDGE_DESTROYED':
            return {
                ...initialVoiceBridgeState
            };
        default:
            return state;
    }
}
// ===== MAIN HOOK IMPLEMENTATION =====
function useVoiceAgentBridge(config) {
    // Existing agent state management
    const [agentState, agentDispatch] = (0,react.useReducer)(agentReducer, initialAgentState);
    // Voice bridge state management
    const [voiceBridgeState, voiceBridgeDispatch] = (0,react.useReducer)(voiceBridgeReducer, initialVoiceBridgeState);
    // Session metrics tracking with Application Insights integration
    const [sessionMetrics, setSessionMetrics] = (0,react.useState)(null);
    // Initialize voice insights with user context
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        if (config.userId) {
            voiceInsights.setUser(config.userId, config.interviewId);
        }
        return ()=>{
            voiceInsights.clearUser();
        };
    }, [
        config.userId,
        config.interviewId
    ]);
    // Refs for cleanup and avoiding stale closures
    const bridgeRef = (0,react.useRef)(null);
    const voiceSessionRef = (0,react.useRef)(null);
    const configRef = (0,react.useRef)(config);
    // Update config ref when config changes
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        configRef.current = config;
    }, [
        config
    ]);
    // ===== VOICE SESSION MANAGEMENT =====
    const createVoiceSession = (0,react.useCallback)(async ()=>{
        const currentConfig = configRef.current;
        try {
            utils_logger/* logger */.vF.info('🚀 [Voice Bridge Hook] Creating voice session', {
                userId: currentConfig.userId,
                type: currentConfig.type
            });
            // Create voice session via API
            const response = await fetch('/api/voice/session/start', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    voiceName: currentConfig.voiceSettings?.voice || 'en-US-AriaNeural',
                    locale: currentConfig.voiceSettings?.language || 'en-US',
                    speakingRate: 1.0,
                    emotionalTone: currentConfig.voiceSettings?.personality || 'professional',
                    audioSettings: {
                        noiseSuppression: true,
                        echoCancellation: true,
                        interruptionDetection: true,
                        sampleRate: currentConfig.voiceSettings?.inputSampleRate || 16000
                    }
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to create voice session');
            }
            const sessionData = await response.json();
            const sessionId = sessionData.sessionId;
            // Create VoiceLiveClient instance
            const { VoiceLiveClient } = await __webpack_require__.e(/* import() */ 3097).then(__webpack_require__.bind(__webpack_require__, 93097));
            const voiceClient = new VoiceLiveClient();
            await voiceClient.init();
            // Create session metadata from API response
            const sessionMetadata = {
                sessionId,
                wsUrl: sessionData.wsUrl || sessionData.endpoint,
                options: {
                    voiceName: currentConfig.voiceSettings?.voice || 'neural-hd-professional',
                    locale: currentConfig.voiceSettings?.language || 'en-US',
                    speakingPace: currentConfig.voiceSettings?.speakingPace || 'normal',
                    emotionalTone: currentConfig.voiceSettings?.personality || 'professional',
                    audioSettings: {
                        noiseSuppression: true,
                        echoCancellation: true,
                        interruptionDetection: true,
                        sampleRate: currentConfig.voiceSettings?.inputSampleRate || 16000
                    }
                },
                createdAt: new Date()
            };
            // Create VoiceSession wrapper with client and metadata
            const voiceSession = new VoiceSession(voiceClient, sessionMetadata);
            // Create mock agent orchestrator for now
            const mockAgentOrchestrator = {
                handleInput: async (transcript, context)=>{
                    // This would normally route to the actual agent system
                    // For now, we'll use the existing conversation processing
                    utils_logger/* logger */.vF.info('🤖 [Voice Bridge Hook] Processing agent input', {
                        transcriptLength: transcript.length,
                        sessionId: context.sessionId
                    });
                    // Add user message to agent state
                    agentDispatch(createAddUserMessageAction(transcript));
                    // Generate a simple response for now
                    // In a real implementation, this would call the existing conversation system
                    const aiResponse = `Thank you for your response. Let me ask you another question about your experience.`;
                    return {
                        text: aiResponse,
                        audioData: undefined // Will be synthesized by Azure
                    };
                },
                handoff: async (agentName, context)=>{
                    utils_logger/* logger */.vF.info('🔄 [Voice Bridge Hook] Agent handoff requested', {
                        agentName,
                        sessionId: context.sessionId
                    });
                // Handle agent switching logic here
                }
            };
            // Create voice agent bridge
            const bridge = new VoiceAgentBridge(voiceSession, mockAgentOrchestrator, {
                sessionTimeout: 1800000,
                maxRetries: 3,
                errorRecoveryMode: 'graceful',
                sentimentMonitoring: true,
                recordingEnabled: true,
                transcriptStorage: 'both',
                ...currentConfig.bridgeConfig
            });
            // Set up bridge event handlers
            setupBridgeEventHandlers(bridge, agentDispatch, currentConfig);
            utils_logger/* logger */.vF.success('✅ [Voice Bridge Hook] Voice session created', {
                sessionId,
                agentType: currentConfig.type
            });
            return {
                bridge,
                voiceSession,
                sessionId
            };
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Failed to create voice session';
            utils_logger/* logger */.vF.error('❌ [Voice Bridge Hook] Failed to create voice session', error);
            // Note: VoiceTelemetry.trackError expects sessionId as second param
            const sessionId = 'creation_failed_' + Date.now();
            // Import VoiceTelemetry directly from voice-telemetry
            const { VoiceTelemetry } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 99728));
            VoiceTelemetry.trackError(error instanceof Error ? error : new Error(errorMessage), sessionId, 'SESSION_CREATION_FAILED', false // don't notify user - this will be handled by the caller
            );
            throw new Error(errorMessage);
        }
    }, []);
    // ===== BRIDGE EVENT HANDLERS =====
    const setupBridgeEventHandlers = (0,react.useCallback)((bridge, dispatch, currentConfig)=>{
        // Transcript events
        bridge.on('transcript:final', (event)=>{
            utils_logger/* logger */.vF.info('📝 [Voice Bridge Hook] Transcript received', {
                speaker: event.entry.speaker,
                textLength: event.entry.text.length,
                confidence: event.entry.confidence
            });
            if (event.entry.speaker === 'user') {
                // Mark user as having spoken if first speech detected
                if (!agentState.hasUserSpoken) {
                    dispatch(createUserSpokeAction());
                }
                dispatch(createAddUserMessageAction(event.entry.text));
                dispatch({
                    type: 'STOP_RECORDING'
                });
                dispatch({
                    type: 'START_PROCESSING'
                });
            }
            // Call user callback if provided
            currentConfig.onTranscriptReceived?.(event.entry);
        });
        // Agent response events
        bridge.on('agent:response', (event)=>{
            utils_logger/* logger */.vF.info('🗣️ [Voice Bridge Hook] Agent response received', {
                agent: event.agent,
                textLength: event.text.length,
                hasAudio: !!event.audioData
            });
            dispatch(createAddAIMessageAction(event.text));
            dispatch({
                type: 'START_SPEAKING'
            });
            // Call user callback if provided
            currentConfig.onAgentResponse?.(event);
            // Auto-transition back to waiting after response
            setTimeout(()=>{
                dispatch({
                    type: 'RESET_TO_WAITING'
                });
                // Auto-start recording for next user input if interview is still active
                if (agentState.interviewState === InterviewState.ACTIVE) {
                    setTimeout(()=>{
                        if (voiceBridgeState.connectionState === 'connected') {
                            dispatch({
                                type: 'START_RECORDING'
                            });
                        }
                    }, 1000);
                }
            }, 2000);
        });
        // Session events
        bridge.on('session:started', (event)=>{
            utils_logger/* logger */.vF.info('🎙️ [Voice Bridge Hook] Voice session started', {
                sessionId: event.sessionId,
                agent: event.agent
            });
            voiceBridgeDispatch({
                type: 'CONNECTION_STATE_CHANGED',
                payload: 'connected'
            });
        });
        bridge.on('session:ended', (event)=>{
            utils_logger/* logger */.vF.info('🏁 [Voice Bridge Hook] Voice session ended', {
                sessionId: event.sessionId,
                reason: event.reason
            });
            voiceBridgeDispatch({
                type: 'CONNECTION_STATE_CHANGED',
                payload: 'disconnected'
            });
        });
        bridge.on('session:error', (event)=>{
            utils_logger/* logger */.vF.error('💥 [Voice Bridge Hook] Voice session error', event.error);
            voiceBridgeDispatch({
                type: 'ERROR_OCCURRED',
                payload: event.error.message
            });
            // Call user callback if provided
            currentConfig.onSessionError?.(event.error);
            (0,error_utils/* showErrorNotification */.p6)(event.error);
        });
        // Sentiment analysis events
        bridge.on('sentiment:analysis', (event)=>{
            utils_logger/* logger */.vF.info('💭 [Voice Bridge Hook] Sentiment analysis', {
                sessionId: event.sessionId,
                sentiment: event.sentiment.label,
                score: event.sentiment.score
            });
            // Update session metrics
            setSessionMetrics((prev)=>({
                    connectionLatency: prev?.connectionLatency || 0,
                    audioLatency: prev?.audioLatency || 0,
                    transcriptionAccuracy: event.sentiment.confidence
                }));
            // Call user callback if provided
            currentConfig.onSentimentAnalysis?.(event.sentiment);
        });
        // Audio synthesis events
        bridge.on('audio:synthesis:complete', (event)=>{
            utils_logger/* logger */.vF.info('🎵 [Voice Bridge Hook] Audio synthesis complete', {
                sessionId: event.sessionId,
                hasAudioData: !!event.audioData
            });
        });
    }, [
        agentState.hasUserSpoken,
        agentState.interviewState,
        voiceBridgeState.connectionState
    ]);
    // ===== SESSION CONTROL FUNCTIONS =====
    const startVoiceSession = (0,react.useCallback)(async ()=>{
        if (voiceBridgeState.isInitializing) {
            utils_logger/* logger */.vF.warn('⚠️ [Voice Bridge Hook] Session creation already in progress');
            return;
        }
        try {
            voiceBridgeDispatch({
                type: 'BRIDGE_INITIALIZING'
            });
            const { bridge, voiceSession, sessionId } = await createVoiceSession();
            // Store references
            bridgeRef.current = bridge;
            voiceSessionRef.current = voiceSession;
            // Start the bridge
            await bridge.start();
            voiceBridgeDispatch({
                type: 'BRIDGE_CREATED',
                payload: {
                    bridge,
                    voiceSession,
                    sessionId
                }
            });
            // Start the interview in agent state
            agentDispatch(createStartInterviewAction());
            utils_logger/* logger */.vF.success('✅ [Voice Bridge Hook] Voice session started successfully');
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Failed to start voice session';
            voiceBridgeDispatch({
                type: 'ERROR_OCCURRED',
                payload: errorMessage
            });
            throw error;
        }
    }, [
        voiceBridgeState.isInitializing,
        createVoiceSession
    ]);
    const stopVoiceSession = (0,react.useCallback)(async ()=>{
        try {
            if (bridgeRef.current) {
                bridgeRef.current.stop();
                bridgeRef.current = null;
            }
            if (voiceSessionRef.current) {
                voiceSessionRef.current.stop();
                voiceSessionRef.current = null;
            }
            voiceBridgeDispatch({
                type: 'BRIDGE_DESTROYED'
            });
            agentDispatch(createEndInterviewAction());
            utils_logger/* logger */.vF.success('✅ [Voice Bridge Hook] Voice session stopped successfully');
        } catch (error) {
            utils_logger/* logger */.vF.error('❌ [Voice Bridge Hook] Failed to stop voice session', error);
            throw error;
        }
    }, []);
    const retryConnection = (0,react.useCallback)(async ()=>{
        utils_logger/* logger */.vF.info('🔄 [Voice Bridge Hook] Retrying connection');
        voiceBridgeDispatch({
            type: 'RETRY_ATTEMPTED'
        });
        try {
            // Stop existing session if any
            if (bridgeRef.current) {
                bridgeRef.current.stop();
            }
            // Wait a bit before retrying
            await new Promise((resolve)=>setTimeout(resolve, 1000));
            // Start new session
            await startVoiceSession();
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Retry failed';
            voiceBridgeDispatch({
                type: 'ERROR_OCCURRED',
                payload: errorMessage
            });
            throw error;
        }
    }, [
        startVoiceSession
    ]);
    // ===== RECORDING CONTROLS =====
    const startRecording = (0,react.useCallback)(()=>{
        if (voiceBridgeState.connectionState === 'connected' && bridgeRef.current) {
            agentDispatch({
                type: 'START_RECORDING'
            });
            utils_logger/* logger */.vF.audio.record('🎤 [Voice Bridge Hook] Started recording via bridge');
        }
    }, [
        voiceBridgeState.connectionState
    ]);
    const stopRecording = (0,react.useCallback)(()=>{
        if (voiceBridgeState.connectionState === 'connected' && bridgeRef.current) {
            agentDispatch({
                type: 'STOP_RECORDING'
            });
            utils_logger/* logger */.vF.audio.record('⏹️ [Voice Bridge Hook] Stopped recording via bridge');
        }
    }, [
        voiceBridgeState.connectionState
    ]);
    // ===== AGENT CONTROLS =====
    const handoffToAgent = (0,react.useCallback)(async (agentName, context)=>{
        if (bridgeRef.current) {
            await bridgeRef.current.handoffToAgent(agentName, context);
        }
    }, []);
    const sendResponse = (0,react.useCallback)(async (text, audioData)=>{
        if (bridgeRef.current) {
            await bridgeRef.current.sendAudioResponse(text, audioData);
        }
    }, []);
    // ===== CLEANUP ON UNMOUNT =====
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        return ()=>{
            if (bridgeRef.current) {
                bridgeRef.current.stop();
            }
            if (voiceSessionRef.current) {
                voiceSessionRef.current.stop();
            }
        };
    }, []);
    // ===== DERIVED STATE SELECTORS =====
    const isRecording = selectIsRecording(agentState);
    const isProcessing = selectIsProcessing(agentState);
    const isSpeaking = selectIsSpeaking(agentState);
    const isWaiting = selectIsWaiting(agentState);
    const isInterviewActive = selectIsInterviewActive(agentState);
    const isInterviewFinished = selectIsInterviewFinished(agentState);
    const shouldShowFeedback = selectShouldShowFeedback(agentState);
    const isVoiceConnected = voiceBridgeState.connectionState === 'connected';
    const canStartRecording = isVoiceConnected && !isRecording && (isWaiting || isInterviewActive);
    // ===== RETURN HOOK RESULT =====
    return {
        // Agent State (existing compatibility)
        state: agentState,
        dispatch: agentDispatch,
        // Voice Bridge State
        voiceBridge: voiceBridgeState,
        // Session Controls
        startVoiceSession,
        stopVoiceSession,
        retryConnection,
        // Recording Controls
        startRecording,
        stopRecording,
        // Agent Controls
        handoffToAgent,
        sendResponse,
        // State Selectors (existing compatibility)
        isRecording,
        isProcessing,
        isSpeaking,
        isWaiting,
        isInterviewActive,
        isInterviewFinished,
        shouldShowFeedback,
        // Voice-specific State
        isVoiceConnected,
        canStartRecording,
        sessionMetrics
    };
}
/* harmony default export */ const voice_useVoiceAgentBridge = ((/* unused pure expression or super */ null && (useVoiceAgentBridge)));

;// ./components/FoundryVoiceAgent.tsx
/**
 * FoundryVoiceAgent Component
 * 
 * Azure AI Foundry-powered voice interview agent that replaces the legacy
 * Speech SDK + OpenAI pipeline with unified real-time voice capabilities.
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 







// Import new voice agent bridge hook

const FoundryVoiceAgent = ({ userName, userId, interviewId, feedbackId, type, questions, resumeInfo, resumeQuestions })=>{
    const router = (0,navigation.useRouter)();
    // Voice configuration for Azure AI Foundry
    const voiceSettings = {
        voice: 'en-US-AriaNeural',
        language: 'en-US',
        personality: 'professional',
        speakingPace: 'normal',
        responseStyle: 'conversational',
        inputSampleRate: 16000,
        outputSampleRate: 24000
    };
    // Hook configuration
    const bridgeConfig = {
        userName,
        userId,
        interviewId,
        feedbackId,
        type,
        questions,
        resumeInfo,
        resumeQuestions,
        voiceSettings,
        bridgeConfig: {
            sessionTimeout: 1800000,
            maxRetries: 3,
            errorRecoveryMode: 'graceful',
            sentimentMonitoring: true,
            recordingEnabled: true,
            transcriptStorage: 'both'
        },
        // Event callbacks
        onTranscriptReceived: (entry)=>{
            utils_logger/* logger */.vF.info('📝 [FoundryVoiceAgent] Transcript received', {
                speaker: entry.speaker,
                textLength: entry.text.length,
                confidence: entry.confidence
            });
        },
        onSentimentAnalysis: (sentiment)=>{
            if (sentiment.stressIndicators.hasHighStressWords) {
                utils_logger/* logger */.vF.warn('😟 [FoundryVoiceAgent] User stress detected', {
                    level: sentiment.label,
                    score: sentiment.score,
                    stressWords: sentiment.stressIndicators.stressWords
                });
            }
        },
        onAgentResponse: (response)=>{
            utils_logger/* logger */.vF.info('🤖 [FoundryVoiceAgent] Agent response', {
                agent: response.agent,
                textLength: response.text.length,
                hasAudio: !!response.audioData
            });
        },
        onSessionError: (error)=>{
            utils_logger/* logger */.vF.error('❌ [FoundryVoiceAgent] Session error', error);
            (0,error_utils/* showErrorNotification */.p6)(error);
        }
    };
    // Use the voice agent bridge hook
    const { state, dispatch, voiceBridge, startVoiceSession, stopVoiceSession, retryConnection, startRecording, stopRecording, handoffToAgent, sendResponse, isRecording, isProcessing, isSpeaking, isWaiting, isInterviewActive, isInterviewFinished, shouldShowFeedback, isVoiceConnected, canStartRecording, sessionMetrics } = useVoiceAgentBridge(bridgeConfig);
    // Load user profile image (reusing existing logic)
    (0,react.useEffect)(()=>{
        const loadUserProfileImage = async ()=>{
            try {
                const response = await fetch("/api/auth/user");
                if (response.ok) {
                    const userData = await response.json();
                    const user = userData?.user;
                    if (user) {
                        const profileImage = user.photoURL || user.image || user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.displayName || user.name || userName)}&background=6366f1&color=fff&size=40`;
                        if (profileImage) {
                            dispatch({
                                type: 'SET_USER_IMAGE',
                                payload: profileImage
                            });
                        }
                    }
                } else {
                    const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&background=6366f1&color=fff&size=40`;
                    dispatch({
                        type: 'SET_USER_IMAGE',
                        payload: fallbackImage
                    });
                }
            } catch (error) {
                const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&background=6366f1&color=fff&size=40`;
                dispatch({
                    type: 'SET_USER_IMAGE',
                    payload: fallbackImage
                });
            }
        };
        const timeoutPromise = new Promise((_, reject)=>{
            setTimeout(()=>reject(new Error('Profile image request timeout')), 5000);
        });
        Promise.race([
            loadUserProfileImage(),
            timeoutPromise
        ]).catch(()=>{
            const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&background=6366f1&color=fff&size=40`;
            dispatch({
                type: 'SET_USER_IMAGE',
                payload: fallbackImage
            });
        });
    }, [
        userName,
        dispatch
    ]);
    // Voice session handlers and controls are now managed by the hook
    // The hook handles all voice session lifecycle, transcript processing, and agent communication
    /**
   * Start the voice interview with Azure AI Foundry
   */ const handleStartInterview = async ()=>{
        try {
            utils_logger/* logger */.vF.info('Starting Azure AI Foundry voice interview', {
                userName,
                type,
                interviewId
            });
            // Start the voice session via the bridge hook
            await startVoiceSession();
            // Send initial greeting
            await sendResponse(`Hello ${userName}! I'm excited to conduct your interview today. Please introduce yourself and tell me a bit about your background.`);
            utils_logger/* logger */.vF.success('Azure AI Foundry voice interview started successfully');
        } catch (error) {
            utils_logger/* logger */.vF.error('Failed to start Foundry voice interview', error);
            (0,error_utils/* showErrorNotification */.p6)(error instanceof Error ? error : new Error('Failed to start interview'));
        }
    };
    /**
   * End the voice interview
   */ const handleEndInterview = async ()=>{
        try {
            utils_logger/* logger */.vF.info('Ending Azure AI Foundry interview', {
                totalMessages: state.messages.length,
                questionNumber: state.questionNumber
            });
            // Stop the voice session via the bridge hook
            await stopVoiceSession();
            utils_logger/* logger */.vF.success('Azure AI Foundry interview ended successfully');
        } catch (error) {
            utils_logger/* logger */.vF.error('Failed to end Foundry interview properly', error);
            (0,error_utils/* showErrorNotification */.p6)(error instanceof Error ? error : new Error('Failed to end interview'));
        }
    };
    // Auto-end interview when complete
    (0,react.useEffect)(()=>{
        if (state.isInterviewComplete && isInterviewActive) {
            utils_logger/* logger */.vF.success('Interview completed - auto-ending in 2 seconds');
            const timeoutId = setTimeout(()=>{
                handleEndInterview();
            }, 2000);
            return ()=>clearTimeout(timeoutId);
        }
    }, [
        state.isInterviewComplete,
        isInterviewActive,
        handleEndInterview
    ]);
    // Generate feedback when interview finishes (reusing existing logic)
    (0,react.useEffect)(()=>{
        if (isInterviewFinished && state.messages.length > 0 && interviewId && type !== "generate") {
            (0,error_utils/* handleAsyncError */.z$)(async ()=>{
                const { success, feedbackId: id } = await createFeedback({
                    interviewId: interviewId,
                    userId: userId,
                    transcript: state.messages,
                    feedbackId
                });
                if (success && id) {
                    dispatch({
                        type: 'SET_FEEDBACK_GENERATED',
                        payload: {
                            generated: true,
                            id
                        }
                    });
                    utils_logger/* logger */.vF.success('Feedback generated successfully', {
                        id
                    });
                }
            }, 'Failed to generate feedback');
        }
    }, [
        isInterviewFinished,
        state.messages.length,
        interviewId,
        userId,
        type,
        feedbackId
    ]);
    // Manual recording controls (bridge hook handles cleanup automatically)
    const handleStartRecording = ()=>{
        startRecording();
    };
    const handleStopRecording = ()=>{
        stopRecording();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
        className: (0,utils.cn)("flex flex-col items-center justify-center min-h-screen p-8 bg-gradient-to-br from-indigo-50 to-blue-100", "dark:from-slate-900 dark:to-indigo-950"),
        children: [
            voiceBridge.lastError && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "mb-6 p-4 bg-red-50 border border-red-200 rounded-lg",
                "data-testid": "connection-error",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("p", {
                        className: "text-red-700 text-sm",
                        children: [
                            "⚠️ Connection Error: ",
                            voiceBridge.lastError
                        ]
                    }),
                    voiceBridge.retryCount > 0 && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("p", {
                        className: "text-red-600 text-xs mt-1",
                        children: [
                            "Retry attempts: ",
                            voiceBridge.retryCount,
                            "/3"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                        onClick: retryConnection,
                        className: "mt-2 px-3 py-1 text-xs bg-red-600 text-white rounded hover:bg-red-700",
                        disabled: voiceBridge.isInitializing,
                        "data-testid": "retry-connection-btn",
                        children: voiceBridge.isInitializing ? 'Retrying...' : 'Retry Connection'
                    })
                ]
            }),
            !voiceBridge.lastError && voiceBridge.retryCount > 0 && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "mb-4 text-center",
                "data-testid": "connection-restored",
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                    className: "text-green-600 text-sm",
                    children: "✅ Connection Restored"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "mb-6 text-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "text-sm text-gray-600 dark:text-gray-300",
                        children: [
                            "Session: ",
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                className: "font-medium capitalize",
                                "data-testid": "connection-state",
                                children: voiceBridge.connectionState
                            })
                        ]
                    }),
                    isVoiceConnected && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "text-xs text-green-600 dark:text-green-400 mt-1",
                        "data-testid": "voice-ready-indicator",
                        children: [
                            "\uD83C\uDFA4 Azure AI Foundry Connected",
                            voiceBridge.sessionId && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("span", {
                                className: "ml-2 font-mono",
                                "data-testid": "session-id",
                                "data-session-id": voiceBridge.sessionId,
                                children: [
                                    "#",
                                    voiceBridge.sessionId.slice(-8)
                                ]
                            })
                        ]
                    }),
                    sessionMetrics && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "text-xs text-gray-500 dark:text-gray-400 mt-1",
                        "data-testid": "session-metrics",
                        children: [
                            "Latency: ",
                            sessionMetrics.connectionLatency,
                            "ms | Accuracy: ",
                            (sessionMetrics.transcriptionAccuracy * 100).toFixed(1),
                            "%"
                        ]
                    })
                ]
            }),
            isRecording && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "mb-4 text-center",
                "data-testid": "voice-active-indicator",
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                    className: "text-red-500 animate-pulse",
                    children: "\uD83C\uDFA4 Recording Active"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "relative mb-8",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                        className: (0,utils.cn)("w-32 h-32 rounded-full border-4 transition-all duration-300", isSpeaking ? "border-blue-500 shadow-lg animate-pulse" : "border-gray-300", isRecording ? "border-red-500 shadow-red-200 shadow-lg" : "", isProcessing ? "border-yellow-500 shadow-yellow-200 shadow-lg animate-spin" : ""),
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(api_image["default"], {
                            src: "/ai-agent-avatar.png",
                            alt: "AI Interview Agent",
                            width: 120,
                            height: 120,
                            className: "rounded-full object-cover w-full h-full",
                            priority: true
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                        className: (0,utils.cn)("absolute bottom-2 right-2 w-6 h-6 rounded-full border-2 border-white", isVoiceConnected ? "bg-green-500" : "bg-gray-400")
                    })
                ]
            }),
            state.userImage && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "mb-6",
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                    className: (0,utils.cn)("w-16 h-16 rounded-full border-2 transition-all", isRecording ? "border-red-400 shadow-lg" : "border-gray-300"),
                    children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(api_image["default"], {
                        src: state.userImage,
                        alt: userName,
                        width: 64,
                        height: 64,
                        className: "rounded-full object-cover w-full h-full"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "flex flex-col items-center space-y-4",
                "data-testid": isInterviewActive ? "interview-session-active" : "interview-session-inactive",
                children: !isInterviewActive ? /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                    onClick: handleStartInterview,
                    disabled: voiceBridge.isInitializing,
                    className: (0,utils.cn)("px-8 py-3 rounded-lg font-medium transition-all", "bg-blue-600 hover:bg-blue-700 text-white", "disabled:opacity-50 disabled:cursor-not-allowed", voiceBridge.isInitializing && "animate-pulse"),
                    "data-testid": "start-interview-btn",
                    children: voiceBridge.isInitializing ? "Initializing..." : "Start Interview"
                }) : /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                    className: "flex space-x-4",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                            onClick: handleStartRecording,
                            disabled: !canStartRecording,
                            className: "px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium disabled:opacity-50",
                            "data-testid": "voice-record-btn",
                            children: "\uD83C\uDFA4 Start Recording"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                            onClick: handleStopRecording,
                            disabled: !isRecording || !isVoiceConnected,
                            className: "px-6 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium disabled:opacity-50",
                            "data-testid": "voice-stop-btn",
                            children: "⏹️ Stop Recording"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                            onClick: handleEndInterview,
                            className: "px-6 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium",
                            "data-testid": "end-interview-btn",
                            children: "End Interview"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "mt-8 text-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "text-lg font-medium text-gray-800 dark:text-gray-200",
                        "data-testid": "interview-status",
                        children: [
                            isRecording && "🎤 Listening...",
                            isProcessing && "🤔 Processing...",
                            isSpeaking && "🗣️ Speaking...",
                            isWaiting && "⏳ Ready for your response...",
                            isInterviewFinished && shouldShowFeedback && "✅ Interview completed!"
                        ]
                    }),
                    state.questionNumber !== undefined && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "mt-2 text-sm text-gray-600 dark:text-gray-400",
                        "data-testid": "question-progress",
                        children: [
                            "Question ",
                            state.questionNumber,
                            " of ",
                            (resumeQuestions || questions)?.length || "?"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "hidden",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "current-agent",
                                children: "AI Foundry Agent"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "current-phase",
                                children: "technical"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "response-processed",
                                className: state.messages.length > 0 ? "processed" : "pending"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "questions-answered-count",
                                children: state.questionNumber || 0
                            }),
                            voiceBridge.isInitializing && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "agent-handoff-pending"
                            }),
                            !voiceBridge.isInitializing && isVoiceConnected && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "agent-handoff-complete"
                            }),
                            voiceBridge.lastError && voiceBridge.retryCount > 0 && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "backup-agent-active"
                            }),
                            !voiceBridge.lastError && voiceBridge.retryCount === 0 && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "system-recovered"
                            })
                        ]
                    })
                ]
            }),
            state.messages.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "mt-8 w-full max-w-2xl",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                        className: "text-lg font-medium mb-4 text-gray-800 dark:text-gray-200",
                        children: "Conversation History"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                        className: "space-y-3 max-h-60 overflow-y-auto",
                        "data-testid": "conversation-transcript",
                        children: state.messages.slice(-5).map((message, index)=>{
                            const isLastMessage = index === state.messages.slice(-5).length - 1;
                            const isCurrentQuestion = message.role !== 'user' && isLastMessage;
                            return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: (0,utils.cn)("p-3 rounded-lg", message.role === 'user' ? "bg-blue-100 dark:bg-blue-900 ml-8" : "bg-gray-100 dark:bg-gray-800 mr-8"),
                                "data-testid": isCurrentQuestion ? "current-question" : `message-${index}`,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                        className: "text-xs text-gray-500 mb-1",
                                        children: message.role === 'user' ? '👤 You' : '🤖 AI'
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                        className: "text-sm",
                                        children: message.content
                                    })
                                ]
                            }, index);
                        })
                    })
                ]
            }),
             false && /*#__PURE__*/ 0
        ]
    });
};
/* harmony default export */ const components_FoundryVoiceAgent = (FoundryVoiceAgent);

;// ./lib/voice/audio-utils.ts
/**
 * Audio processing utilities for voice interview system
 * Extracted from Agent.tsx to reduce redundancy and improve maintainability
 */ 

// Audio configuration constants
const AUDIO_CONFIG = {
    SAMPLE_RATE: 16000,
    CHANNEL_COUNT: 1,
    RING_BUFFER_SIZE: 32,
    SILENCE_THRESHOLD_RMS: 0.01,
    SILENCE_WINDOW_MS: 200,
    CHUNK_SIZE: 4096,
    RECORDING_TIMEOUT_MS: 8000
};
/**
 * Get the best supported MIME type for MediaRecorder
 */ const getSupportedMimeType = ()=>{
    const preferredTypes = [
        'audio/webm;codecs=pcm',
        'audio/wav',
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/ogg;codecs=opus',
        'audio/ogg'
    ];
    for (const mimeType of preferredTypes){
        if (MediaRecorder.isTypeSupported(mimeType)) {
            logger.success(`Selected MIME type: ${mimeType}`);
            return mimeType;
        }
    }
    logger.warn('No preferred MIME types supported, using default');
    return null;
};
/**
 * Trim initial silence from audio chunks
 */ const trimInitialSilence = (audioChunks, sampleRate)=>{
    const windowSamples = Math.floor(sampleRate * AUDIO_CONFIG.SILENCE_WINDOW_MS / 1000);
    // Concatenate all chunks for analysis
    const totalLength = audioChunks.reduce((acc, chunk)=>acc + chunk.length, 0);
    const combinedAudio = new Float32Array(totalLength);
    let offset = 0;
    for (const chunk of audioChunks){
        combinedAudio.set(chunk, offset);
        offset += chunk.length;
    }
    let startIndex = 0;
    let hasNonSilence = false;
    // Find first non-silent window
    for(let i = 0; i <= combinedAudio.length - windowSamples; i += windowSamples / 4){
        let windowRMS = 0;
        const actualWindowSize = Math.min(windowSamples, combinedAudio.length - i);
        for(let j = 0; j < actualWindowSize; j++){
            windowRMS += combinedAudio[i + j] * combinedAudio[i + j];
        }
        windowRMS = Math.sqrt(windowRMS / actualWindowSize);
        if (windowRMS > AUDIO_CONFIG.SILENCE_THRESHOLD_RMS) {
            startIndex = i;
            hasNonSilence = true;
            utils_logger/* logger */.vF.audio.process(`Non-silence detected at sample ${startIndex}, RMS: ${windowRMS.toFixed(4)}`);
            break;
        }
    }
    if (!hasNonSilence) {
        utils_logger/* logger */.vF.warn('No speech detected in audio');
        return {
            trimmedChunks: [],
            hasNonSilence: false
        };
    }
    const trimmedAudio = combinedAudio.slice(startIndex);
    // Split back into chunks for consistent processing
    const trimmedChunks = [];
    for(let i = 0; i < trimmedAudio.length; i += AUDIO_CONFIG.CHUNK_SIZE){
        const chunk = trimmedAudio.slice(i, i + AUDIO_CONFIG.CHUNK_SIZE);
        trimmedChunks.push(chunk);
    }
    utils_logger/* logger */.vF.audio.process(`Silence trimmed - processed ${trimmedChunks.length} chunks`);
    return {
        trimmedChunks,
        hasNonSilence
    };
};
/**
 * Convert Float32Array chunks to WAV blob
 */ const convertToWav = (audioChunks, sampleRate)=>{
    try {
        const totalLength = audioChunks.reduce((acc, chunk)=>acc + chunk.length, 0);
        const combinedAudio = new Float32Array(totalLength);
        let offset = 0;
        for (const chunk of audioChunks){
            combinedAudio.set(chunk, offset);
            offset += chunk.length;
        }
        // Convert float samples to 16-bit PCM
        const pcmData = new Int16Array(combinedAudio.length);
        for(let i = 0; i < combinedAudio.length; i++){
            const sample = Math.max(-1, Math.min(1, combinedAudio[i]));
            pcmData[i] = sample * 32767;
        }
        // Create WAV header
        const wavHeader = createWavHeader(pcmData.length, sampleRate);
        const wavBlob = new Blob([
            wavHeader,
            pcmData
        ], {
            type: 'audio/wav'
        });
        utils_logger/* logger */.vF.audio.process(`WAV conversion complete - ${wavBlob.size} bytes`);
        return wavBlob;
    } catch (error) {
        throw new error_utils/* AudioError */.vZ('WAV conversion failed', {
            error,
            chunksLength: audioChunks.length
        });
    }
};
/**
 * Create WAV file header
 */ const createWavHeader = (dataLength, sampleRate)=>{
    const wavHeader = new ArrayBuffer(44);
    const view = new DataView(wavHeader);
    const writeString = (offset, string)=>{
        for(let i = 0; i < string.length; i++){
            view.setUint8(offset + i, string.charCodeAt(i));
        }
    };
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + dataLength * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true); // PCM format
    view.setUint16(22, 1, true); // mono
    view.setUint32(24, sampleRate, true); // sample rate
    view.setUint32(28, sampleRate * 2, true); // byte rate
    view.setUint16(32, 2, true); // block align
    view.setUint16(34, 16, true); // bits per sample
    writeString(36, 'data');
    view.setUint32(40, dataLength * 2, true);
    return wavHeader;
};
/**
 * Prepare audio for upload - combines trimming and WAV conversion
 */ const prepareAudioForUpload = (audioChunks, sampleRate)=>{
    if (!audioChunks || audioChunks.length === 0) {
        utils_logger/* logger */.vF.warn('No audio chunks provided for processing');
        return {
            blob: new Blob(),
            hasValidAudio: false
        };
    }
    try {
        const { trimmedChunks, hasNonSilence } = trimInitialSilence(audioChunks, sampleRate);
        if (!hasNonSilence || trimmedChunks.length === 0) {
            utils_logger/* logger */.vF.warn('No valid speech detected in audio');
            return {
                blob: new Blob(),
                hasValidAudio: false
            };
        }
        const wavBlob = convertToWav(trimmedChunks, sampleRate);
        return {
            blob: wavBlob,
            hasValidAudio: true
        };
    } catch (error) {
        (0,error_utils/* reportError */.N7)(error, 'Audio preparation failed', {
            chunksProvided: audioChunks.length,
            sampleRate
        });
        return {
            blob: new Blob(),
            hasValidAudio: false
        };
    }
};
/**
 * Setup audio context with optimal settings
 */ const createOptimizedAudioContext = async ()=>{
    try {
        // Get microphone stream
        const stream = await navigator.mediaDevices.getUserMedia({
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: false,
                sampleRate: AUDIO_CONFIG.SAMPLE_RATE,
                channelCount: AUDIO_CONFIG.CHANNEL_COUNT
            }
        });
        // Create audio context
        const context = new (window.AudioContext || window.webkitAudioContext)({
            sampleRate: AUDIO_CONFIG.SAMPLE_RATE
        });
        // Load audio worklet
        await context.audioWorklet.addModule('/audio-processor.js');
        const source = context.createMediaStreamSource(stream);
        const workletNode = new AudioWorkletNode(context, 'audio-processor');
        source.connect(workletNode);
        const cleanup = async ()=>{
            utils_logger/* logger */.vF.audio.process('Cleaning up audio resources');
            source.disconnect();
            workletNode.port.onmessage = null;
            if (context.state !== 'closed') {
                await context.close();
            }
            stream.getTracks().forEach((track)=>track.stop());
        };
        utils_logger/* logger */.vF.success('Audio context setup complete');
        return {
            context,
            source,
            workletNode,
            cleanup
        };
    } catch (error) {
        throw new error_utils/* AudioError */.vZ('Failed to setup audio context', {
            error
        });
    }
};
/**
 * Resume suspended audio context (for tab visibility changes)
 */ const resumeAudioContext = async (context)=>{
    if (context.state === 'suspended') {
        try {
            await context.resume();
            utils_logger/* logger */.vF.success('AudioContext resumed');
        } catch (error) {
            throw new error_utils/* AudioError */.vZ('Failed to resume AudioContext', {
                error
            });
        }
    }
};
/**
 * Dispose of audio resources safely
 */ const disposeAudioResources = async (resources)=>{
    const { context, stream, workletNode, source } = resources;
    try {
        if (source) {
            source.disconnect();
        }
        if (workletNode) {
            workletNode.port.onmessage = null;
        }
        if (context && context.state !== 'closed') {
            await context.close();
        }
        if (stream) {
            stream.getTracks().forEach((track)=>track.stop());
        }
        logger.success('Audio resources disposed');
    } catch (error) {
        reportError(error, 'Failed to dispose audio resources', resources);
    }
};

;// ./lib/utils/audio-helpers.ts
/**
 * Audio utility helper functions for voice conversation system
 */ /**
 * Play audio from byte array data
 * @param bytes - Audio data as number array or Uint8Array
 * @param mimeType - MIME type of the audio (default: 'audio/wav')
 * @returns Promise that resolves when audio finishes playing
 */ async function playAudioBuffer(bytes, mimeType = 'audio/wav') {
    return new Promise((resolve, reject)=>{
        try {
            // Convert to Uint8Array if needed
            const audioArray = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
            // Create blob from audio data with proper ArrayBuffer
            const arrayBuffer = new ArrayBuffer(audioArray.length);
            const view = new Uint8Array(arrayBuffer);
            view.set(audioArray);
            const audioBlob = new Blob([
                arrayBuffer
            ], {
                type: mimeType
            });
            const audioUrl = URL.createObjectURL(audioBlob);
            // Create and configure audio element
            const audio = new Audio(audioUrl);
            // Set up event listeners
            audio.onended = ()=>{
                console.log('🔊 Audio playback completed');
                URL.revokeObjectURL(audioUrl);
                resolve();
            };
            audio.onerror = (error)=>{
                console.error('❌ Audio playback error:', error);
                URL.revokeObjectURL(audioUrl);
                reject(new Error('Audio playback failed'));
            };
            // Start playback
            audio.play().catch((error)=>{
                console.error('❌ Failed to start audio playback:', error);
                URL.revokeObjectURL(audioUrl);
                reject(error);
            });
        } catch (error) {
            console.error('❌ Error creating audio from buffer:', error);
            reject(error);
        }
    });
}
/**
 * Create an audio blob from byte array
 * @param bytes - Audio data as number array or Uint8Array
 * @param mimeType - MIME type of the audio (default: 'audio/wav')
 * @returns Audio blob
 */ function createAudioBlob(bytes, mimeType = 'audio/wav') {
    const audioArray = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const arrayBuffer = new ArrayBuffer(audioArray.length);
    const view = new Uint8Array(arrayBuffer);
    view.set(audioArray);
    return new Blob([
        arrayBuffer
    ], {
        type: mimeType
    });
}
/**
 * Play audio from blob with promise support
 * @param audioBlob - Audio blob to play
 * @returns Promise that resolves when audio finishes playing
 */ async function playAudioBlob(audioBlob) {
    return new Promise((resolve, reject)=>{
        try {
            const audioUrl = URL.createObjectURL(audioBlob);
            const audio = new Audio(audioUrl);
            audio.onended = ()=>{
                console.log('🔊 Audio blob playback completed');
                URL.revokeObjectURL(audioUrl);
                resolve();
            };
            audio.onerror = (error)=>{
                console.error('❌ Audio blob playback error:', error);
                URL.revokeObjectURL(audioUrl);
                reject(new Error('Audio blob playback failed'));
            };
            audio.play().catch((error)=>{
                console.error('❌ Failed to start audio blob playback:', error);
                URL.revokeObjectURL(audioUrl);
                reject(error);
            });
        } catch (error) {
            console.error('❌ Error playing audio blob:', error);
            reject(error);
        }
    });
}
/**
 * Validate audio buffer data
 * @param bytes - Audio data to validate
 * @returns Whether the audio data is valid
 */ function validateAudioBuffer(bytes) {
    if (!bytes) return false;
    if (Array.isArray(bytes)) return bytes.length > 0;
    if (bytes instanceof Uint8Array) return bytes.length > 0;
    return false;
}
/**
 * Convert audio buffer to different formats
 * @param bytes - Source audio data
 * @param fromMimeType - Source MIME type
 * @param toMimeType - Target MIME type
 * @returns Promise that resolves with converted audio buffer
 */ async function convertAudioBuffer(bytes, fromMimeType, toMimeType) {
    // For now, return as-is since conversion would require audio processing libraries
    // This is a placeholder for future audio format conversion functionality
    console.warn(`Audio conversion from ${fromMimeType} to ${toMimeType} not implemented yet`);
    return bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
}
/**
 * Get audio buffer duration (if possible to determine from header)
 * @param bytes - Audio data
 * @param mimeType - MIME type of the audio
 * @returns Duration in seconds, or null if cannot be determined
 */ function getAudioBufferDuration(bytes, mimeType = 'audio/wav') {
    try {
        const audioArray = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
        if (mimeType === 'audio/wav' && audioArray.length >= 44) {
            // Parse WAV header for duration
            const view = new DataView(audioArray.buffer);
            // Check for RIFF header
            const riffHeader = String.fromCharCode(...audioArray.slice(0, 4));
            if (riffHeader !== 'RIFF') return null;
            // Get sample rate (offset 24, 4 bytes, little endian)
            const sampleRate = view.getUint32(24, true);
            // Get data chunk size (we need to find the data chunk)
            // This is a simplified version - real WAV parsing is more complex
            const dataSize = audioArray.length - 44; // Assume standard 44-byte header
            const duration = dataSize / (sampleRate * 2); // Assume 16-bit mono
            return duration;
        }
        return null;
    } catch (error) {
        console.error('❌ Error getting audio buffer duration:', error);
        return null;
    }
}
/**
 * Preload audio buffer for faster playback
 * @param bytes - Audio data
 * @param mimeType - MIME type of the audio
 * @returns Audio element ready for playback
 */ function preloadAudioBuffer(bytes, mimeType = 'audio/wav') {
    const audioArray = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const arrayBuffer = new ArrayBuffer(audioArray.length);
    const view = new Uint8Array(arrayBuffer);
    view.set(audioArray);
    const audioBlob = new Blob([
        arrayBuffer
    ], {
        type: mimeType
    });
    const audioUrl = URL.createObjectURL(audioBlob);
    const audio = new Audio(audioUrl);
    audio.preload = 'auto';
    // Store cleanup function on the audio element
    audio.__cleanup = ()=>URL.revokeObjectURL(audioUrl);
    return audio;
}
/**
 * Cleanup preloaded audio element
 * @param audio - Audio element to cleanup
 */ function cleanupPreloadedAudio(audio) {
    if (audio.__cleanup) {
        audio.__cleanup();
        delete audio.__cleanup;
    }
}

;// ./lib/voice/azure-adapters.ts
/**
 * Azure API adapters for speech and conversation services
 * Isolates API calls while maintaining existing signatures
 */ 


/**
 * Speech-to-Text adapter with retry logic
 */ const speechToText = async (audioBlob)=>{
    return (0,error_utils/* withRetry */.bD)(async ()=>{
        const formData = new FormData();
        formData.append('audio', audioBlob, 'recording.wav');
        utils_logger/* logger */.vF.api.request('/api/voice/stream', 'POST', {
            size: audioBlob.size,
            type: audioBlob.type
        });
        const response = await fetch('/api/voice/stream', {
            method: 'POST',
            body: formData
        });
        if (!response.ok) {
            throw (0,error_utils/* handleApiError */.hS)(response, 'Speech-to-text');
        }
        const result = await response.json();
        utils_logger/* logger */.vF.api.response('/api/voice/stream', response.status, {
            textLength: result.text?.length
        });
        if (result.text === undefined) {
            throw new Error('Speech-to-text response missing text field');
        }
        return result.text;
    }, 3, 'Speech-to-text');
};
/**
 * Start conversation adapter
 */ const startConversation = async (interviewContext)=>{
    utils_logger/* logger */.vF.api.request('/api/voice/conversation', 'POST', {
        action: 'start'
    });
    const response = await fetch('/api/voice/conversation', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: "start",
            interviewContext
        })
    });
    if (!response.ok) {
        throw (0,error_utils/* handleApiError */.hS)(response, 'Start conversation');
    }
    const data = await response.json();
    utils_logger/* logger */.vF.api.response('/api/voice/conversation', response.status, {
        hasAudio: !!data.hasAudio,
        messageLength: data.message?.length
    });
    return data;
};
/**
 * Process conversation turn adapter  
 */ const processConversation = async (userTranscript)=>{
    console.log('🧪 [PROCESS CONVERSATION] Starting with transcript:', {
        length: userTranscript.length,
        preview: userTranscript.substring(0, 100) + '...'
    });
    utils_logger/* logger */.vF.api.request('/api/voice/conversation', 'POST', {
        action: 'process',
        transcriptLength: userTranscript.length
    });
    try {
        console.log('🌍 [PROCESS CONVERSATION] Making fetch request to /api/voice/conversation');
        const response = await fetch('/api/voice/conversation', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: "process",
                userTranscript
            })
        });
        console.log('🌍 [PROCESS CONVERSATION] Got response:', {
            status: response.status,
            statusText: response.statusText,
            ok: response.ok
        });
        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ [PROCESS CONVERSATION] API error response:', {
                status: response.status,
                statusText: response.statusText,
                errorBody: errorText.substring(0, 500) + '...'
            });
            throw (0,error_utils/* handleApiError */.hS)(response, 'Process conversation');
        }
        const data = await response.json();
        console.log('✅ [PROCESS CONVERSATION] Successfully parsed JSON response:', {
            hasMessage: !!data.message,
            messageLength: data.message?.length,
            questionNumber: data.questionNumber,
            isComplete: data.isComplete,
            hasAudio: data.hasAudio
        });
        utils_logger/* logger */.vF.api.response('/api/voice/conversation', response.status, {
            hasAudio: !!data.hasAudio,
            messageLength: data.message?.length,
            questionNumber: data.questionNumber,
            isComplete: data.isComplete
        });
        return data;
    } catch (error) {
        console.error('❌ [PROCESS CONVERSATION] Network or parsing error:', {
            errorType: error instanceof Error ? error.constructor.name : typeof error,
            errorMessage: error instanceof Error ? error.message : String(error),
            stack: error instanceof Error ? error.stack : undefined
        });
        throw error;
    }
};
/**
 * End conversation adapter
 */ const endConversation = async ()=>{
    try {
        utils_logger/* logger */.vF.api.request('/api/voice/conversation', 'POST', {
            action: 'summary'
        });
        const response = await fetch('/api/voice/conversation', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: "summary"
            })
        });
        if (response.ok) {
            const data = await response.json();
            utils_logger/* logger */.vF.api.response('/api/voice/conversation', response.status, {
                hasSummary: !!data.summary
            });
            return data;
        } else {
            utils_logger/* logger */.vF.warn('Failed to generate interview summary', {
                status: response.status
            });
            return {};
        }
    } catch (error) {
        utils_logger/* logger */.vF.warn('Error generating interview summary', {
            error: error instanceof Error ? error.message : String(error)
        });
        return {};
    }
};
/**
 * Text-to-Speech adapter
 */ const textToSpeech = async (text)=>{
    return (0,error_utils/* withRetry */.bD)(async ()=>{
        utils_logger/* logger */.vF.api.request('/api/voice/tts', 'POST', {
            textLength: text.length
        });
        const response = await fetch('/api/voice/tts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                text
            })
        });
        if (!response.ok) {
            throw (0,error_utils/* handleApiError */.hS)(response, 'Text-to-speech');
        }
        const audioBlob = await response.blob();
        utils_logger/* logger */.vF.api.response('/api/voice/tts', response.status, {
            blobSize: audioBlob.size
        });
        return audioBlob;
    }, 2, 'Text-to-speech');
};
/**
 * Play AI response using real Azure TTS with fallback handling
 */ const playAIResponse = async (text, onStart, onComplete, onError)=>{
    console.log('🎯 [AZURE TTS] playAIResponse called', {
        textLength: text.length,
        hasOnStart: !!onStart,
        hasOnComplete: !!onComplete
    });
    try {
        // Call onStart callback
        if (onStart) {
            console.log('🎯 [AZURE TTS] Calling onStart callback');
            onStart();
        }
        utils_logger/* logger */.vF.audio.speak('Playing AI response via Azure TTS', {
            textLength: text.length
        });
        // Get audio from Azure TTS
        const audioBlob = await textToSpeech(text);
        if (!audioBlob || audioBlob.size === 0) {
            throw new Error('Empty audio response from TTS service');
        }
        console.log('🔊 [AZURE TTS] Playing audio', {
            text: text.substring(0, 150) + (text.length > 150 ? '...' : ''),
            audioSize: audioBlob.size
        });
        // Play the audio using Web Audio API
        await playAudioFromBlob(audioBlob);
        console.log('🔊 [AZURE TTS] Audio playback completed');
        utils_logger/* logger */.vF.audio.speak('Azure TTS playback completed');
        // Call onComplete callback
        if (onComplete) {
            console.log('🎯 [AZURE TTS] Calling onComplete callback');
            onComplete();
        }
        console.log('🎯 [AZURE TTS] playAIResponse finished successfully');
    } catch (error) {
        console.warn('🔊 [AZURE TTS] TTS service unavailable, using mock audio');
        const audioError = error instanceof Error ? error : new Error('TTS failed');
        utils_logger/* logger */.vF.warn('Azure TTS not available, using fallback audio simulation');
        // Fallback to mock TTS timing simulation
        try {
            // Call onStart if not already called
            if (onStart) {
                onStart();
            }
            const wordsCount = text.split(' ').length;
            const readingDuration = Math.max(2500, wordsCount * 120); // 120ms per word, minimum 2.5 seconds
            console.log('🔊 [FALLBACK] Using audio simulation', {
                wordsCount,
                duration: readingDuration + 'ms'
            });
            await new Promise((resolve)=>setTimeout(resolve, readingDuration));
            if (onComplete) {
                onComplete();
            }
            console.log('🔊 [FALLBACK] Audio simulation completed');
        } catch (fallbackError) {
            utils_logger/* logger */.vF.warn('Fallback audio simulation failed, continuing anyway');
            // Always call onComplete to prevent conversation from hanging
            if (onComplete) {
                onComplete();
            }
        }
    }
};
/**
 * Play audio from blob using Web Audio API
 */ const playAudioFromBlob = async (audioBlob)=>{
    return new Promise((resolve, reject)=>{
        try {
            // Create audio element for playback
            const audio = new Audio();
            const audioUrl = URL.createObjectURL(audioBlob);
            audio.src = audioUrl;
            audio.preload = 'auto';
            // Set up event listeners
            audio.addEventListener('ended', ()=>{
                URL.revokeObjectURL(audioUrl);
                resolve();
            });
            audio.addEventListener('error', (error)=>{
                URL.revokeObjectURL(audioUrl);
                reject(new Error(`Audio playback failed: ${error.message || 'Unknown error'}`));
            });
            // Start playback
            audio.play().catch((error)=>{
                URL.revokeObjectURL(audioUrl);
                reject(new Error(`Audio play failed: ${error.message || 'Unknown error'}`));
            });
        } catch (error) {
            reject(new Error(`Audio setup failed: ${error instanceof Error ? error.message : String(error)}`));
        }
    });
};
/**
 * Play direct audio buffer with TTS fallback
 */ const playDirectAudioWithFallback = async (audioData, fallbackText, onStart, onComplete, onError)=>{
    if (validateAudioBuffer(audioData)) {
        try {
            onStart?.();
            await playAudioBuffer(audioData);
            utils_logger/* logger */.vF.audio.speak('Direct audio playback completed');
            onComplete?.();
            return;
        } catch (error) {
            utils_logger/* logger */.vF.warn('Direct audio failed, falling back to TTS', {
                error: error instanceof Error ? error.message : String(error)
            });
        // Fall through to TTS fallback
        }
    }
    // TTS fallback
    await playAIResponse(fallbackText, onStart, onComplete, onError);
};
/**
 * Combined conversation processing with audio playback
 */ const processAndPlayResponse = async (userTranscript, onStart, onComplete, onError)=>{
    try {
        // Process conversation
        const data = await processConversation(userTranscript);
        // Create message objects
        const userMessage = {
            role: "user",
            content: userTranscript
        };
        const aiMessage = {
            role: "assistant",
            content: data.message
        };
        // Play response audio
        if (data.hasAudio && validateAudioBuffer(data.audioData)) {
            await playDirectAudioWithFallback(data.audioData, data.message, onStart, onComplete, onError);
        } else {
            await playAIResponse(data.message, onStart, onComplete, onError);
        }
        return {
            userMessage,
            aiMessage,
            questionNumber: data.questionNumber,
            isComplete: data.isComplete
        };
    } catch (error) {
        const processError = error instanceof Error ? error : new Error('Processing failed');
        utils_logger/* logger */.vF.error('Conversation processing failed', processError, {
            userTranscript: userTranscript.substring(0, 100),
            errorType: processError.name,
            errorMessage: processError.message
        });
        // Don't throw the error, instead provide fallback behavior
        console.warn('🔄 Conversation processing failed, attempting graceful recovery');
        // Create fallback response to prevent conversation from breaking
        const fallbackUserMessage = {
            role: "user",
            content: userTranscript
        };
        const fallbackAIMessage = {
            role: "assistant",
            content: "I apologize, I'm having some technical difficulties. Could you please repeat that or try rephrasing your response?"
        };
        // Try to play the fallback response
        try {
            await playAIResponse(fallbackAIMessage.content, onStart, onComplete, onError);
        } catch (audioError) {
            console.warn('🔊 Fallback audio also failed, calling completion anyway');
            if (onComplete) onComplete();
        }
        return {
            userMessage: fallbackUserMessage,
            aiMessage: fallbackAIMessage,
            questionNumber: undefined,
            isComplete: false
        };
    }
};

;// ./components/Agent.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



// Feature flag support for Azure AI Foundry voice system









const Agent = ({ userName, userId, interviewId, feedbackId, type, questions, resumeInfo, resumeQuestions })=>{
    // Check for Azure AI Foundry voice system feature flag
    const { enabled: useFoundryVoice, loading: flagLoading } = (0,useUnifiedConfig/* useFeatureFlag */.u)('voiceInterviewV2');
    // Show loading state while feature flag is being fetched
    if (flagLoading) {
        return /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
            className: "flex items-center justify-center min-h-screen",
            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "text-lg text-gray-600 dark:text-gray-300",
                children: "Loading interview system..."
            })
        });
    }
    // Use Azure AI Foundry voice system if feature flag is enabled
    if (useFoundryVoice) {
        console.log('🚀 [Agent] Using Azure AI Foundry voice system');
        return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(components_FoundryVoiceAgent, {
            userName: userName,
            userId: userId,
            interviewId: interviewId,
            feedbackId: feedbackId,
            type: type,
            questions: questions,
            resumeInfo: resumeInfo,
            resumeQuestions: resumeQuestions
        });
    }
    // Fall back to legacy Speech SDK + OpenAI system
    console.log('📻 [Agent] Using legacy Speech SDK + OpenAI system');
    const router = (0,navigation.useRouter)();
    const [state, dispatch] = (0,react.useReducer)(agentReducer, initialAgentState);
    // Audio recording state
    const audioSamplesRef = (0,react.useRef)([]);
    const isCurrentlyRecordingRef = (0,react.useRef)(false);
    const recordingTimeoutRef = (0,react.useRef)(null);
    const audioCleanupRef = (0,react.useRef)(null);
    // Voice activity detection state
    const silenceTimeoutRef = (0,react.useRef)(null);
    const lastVoiceActivityRef = (0,react.useRef)(0);
    const SILENCE_DURATION_MS = 2000; // Stop recording after 2 seconds of silence
    // Derived selectors from state
    const isRecording = selectIsRecording(state);
    const isProcessing = selectIsProcessing(state);
    const isSpeaking = selectIsSpeaking(state);
    const isWaiting = selectIsWaiting(state);
    const isInterviewActive = selectIsInterviewActive(state);
    const isInterviewFinished = selectIsInterviewFinished(state);
    const shouldShowFeedback = selectShouldShowFeedback(state);
    // Load user profile image with fallbacks
    (0,react.useEffect)(()=>{
        const loadUserProfileImage = async ()=>{
            try {
                // Use existing auth endpoint that returns user data
                const response = await fetch("/api/auth/user");
                if (response.ok) {
                    const userData = await response.json();
                    const user = userData?.user;
                    if (user) {
                        // Try multiple sources for profile image
                        const profileImage = user.photoURL || // Firebase photoURL
                        user.image || // Custom image field
                        user.avatar || // Avatar field
                        `https://ui-avatars.com/api/?name=${encodeURIComponent(user.displayName || user.name || userName)}&background=6366f1&color=fff&size=40`; // Generated avatar fallback
                        if (profileImage) {
                            dispatch({
                                type: 'SET_USER_IMAGE',
                                payload: profileImage
                            });
                        }
                    }
                } else {
                    // Silently fall back to generated avatar if auth fails
                    const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&background=6366f1&color=fff&size=40`;
                    dispatch({
                        type: 'SET_USER_IMAGE',
                        payload: fallbackImage
                    });
                }
            } catch (error) {
                // Generate fallback avatar instead of logging error
                // This prevents console spam for a non-critical feature
                const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&background=6366f1&color=fff&size=40`;
                dispatch({
                    type: 'SET_USER_IMAGE',
                    payload: fallbackImage
                });
            }
        };
        // Add timeout to prevent hanging requests
        const timeoutPromise = new Promise((_, reject)=>{
            setTimeout(()=>reject(new Error('Profile image request timeout')), 5000);
        });
        Promise.race([
            loadUserProfileImage(),
            timeoutPromise
        ]).catch(()=>{
            // Timeout fallback - use generated avatar
            const fallbackImage = `https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&background=6366f1&color=fff&size=40`;
            dispatch({
                type: 'SET_USER_IMAGE',
                payload: fallbackImage
            });
        });
    }, [
        userName
    ]);
    // Handle tab visibility changes for audio context
    (0,react.useEffect)(()=>{
        const handleVisibilityChange = ()=>{
            if (!document.hidden && window.audioContext) {
                (0,error_utils/* handleAsyncError */.z$)(()=>resumeAudioContext(window.audioContext), 'Failed to resume audio context on tab focus');
            }
        };
        document.addEventListener('visibilitychange', handleVisibilityChange);
        return ()=>document.removeEventListener('visibilitychange', handleVisibilityChange);
    }, []);
    const handleEndInterview = async ()=>{
        try {
            utils_logger/* logger */.vF.info('Ending interview', {
                totalMessages: state.messages.length,
                questionNumber: state.questionNumber
            });
            dispatch(createEndInterviewAction());
            // Generate summary if possible
            await (0,error_utils/* handleAsyncError */.z$)(async ()=>{
                const summaryData = await endConversation();
                if (summaryData.summary) {
                    utils_logger/* logger */.vF.info('Interview summary generated', {
                        summaryLength: summaryData.summary.length
                    });
                }
            }, 'Failed to generate interview summary');
            // Clean up audio resources
            if (audioCleanupRef.current) {
                await audioCleanupRef.current();
                audioCleanupRef.current = null;
            }
            // Clean up global window functions
            delete window.audioContext;
            delete window.startAudioContextRecording;
            delete window.stopAudioContextRecording;
            // Clear recording timeout if active
            if (recordingTimeoutRef.current) {
                clearTimeout(recordingTimeoutRef.current);
                recordingTimeoutRef.current = null;
            }
            utils_logger/* logger */.vF.success('Interview ended successfully');
        } catch (error) {
            utils_logger/* logger */.vF.error('Failed to end interview properly', error);
            dispatch(createEndInterviewAction()); // Force end on error
        }
    };
    // Auto-end interview when complete
    (0,react.useEffect)(()=>{
        if (state.isInterviewComplete && isInterviewActive) {
            utils_logger/* logger */.vF.success('Interview completed - auto-ending in 2 seconds');
            const timeoutId = setTimeout(()=>{
                handleEndInterview();
            }, 2000);
            return ()=>clearTimeout(timeoutId);
        }
    }, [
        state.isInterviewComplete,
        isInterviewActive
    ]);
    // Generate feedback when interview finishes
    (0,react.useEffect)(()=>{
        if (isInterviewFinished && state.messages.length > 0 && interviewId && type !== "generate") {
            (0,error_utils/* handleAsyncError */.z$)(async ()=>{
                const { success, feedbackId: id } = await createFeedback({
                    interviewId: interviewId,
                    userId: userId,
                    transcript: state.messages,
                    feedbackId
                });
                if (success && id) {
                    dispatch({
                        type: 'SET_FEEDBACK_GENERATED',
                        payload: {
                            generated: true,
                            id
                        }
                    });
                    utils_logger/* logger */.vF.success('Feedback generated successfully', {
                        id
                    });
                }
            }, 'Failed to generate feedback');
        }
    // No cleanup needed for this effect
    }, [
        isInterviewFinished,
        state.messages.length,
        interviewId,
        userId,
        type,
        feedbackId
    ]);
    /**
     * Process audio recording and handle transcription
     */ const processAudioRecording = async (audioChunks, sampleRate)=>{
        const { blob, hasValidAudio } = prepareAudioForUpload(audioChunks, sampleRate);
        if (!hasValidAudio) {
            utils_logger/* logger */.vF.warn('No valid audio detected, resuming waiting state');
            dispatch({
                type: 'RESET_TO_WAITING'
            });
            return;
        }
        try {
            // Convert to text
            const transcript = await speechToText(blob);
            if (!transcript?.trim()) {
                utils_logger/* logger */.vF.warn('Empty transcript received');
                dispatch({
                    type: 'RESET_TO_WAITING'
                });
                return;
            }
            // Mark user as having spoken if first speech detected
            if (!state.hasUserSpoken) {
                dispatch(createUserSpokeAction());
            }
            // Process conversation with AI
            await handleConversationTurn(transcript);
        } catch (error) {
            utils_logger/* logger */.vF.error('Audio processing failed', error);
            dispatch({
                type: 'RESET_TO_WAITING'
            });
            (0,error_utils/* showErrorNotification */.p6)(error instanceof Error ? error : new Error('Audio processing failed'));
        }
    };
    /**
     * Handle conversation turn with Azure services
     */ const handleConversationTurn = async (userTranscript)=>{
        try {
            console.log('🎯 [AGENT] Starting conversation turn with transcript:', userTranscript.substring(0, 50) + '...');
            const response = await processAndPlayResponse(userTranscript, ()=>{
                console.log('🎯 [AGENT] AI response started - dispatching START_SPEAKING');
                dispatch({
                    type: 'START_SPEAKING'
                });
            }, ()=>{
                console.log('🎯 [AGENT] AI response completed - dispatching RESET_TO_WAITING');
                dispatch({
                    type: 'RESET_TO_WAITING'
                });
                // Use response data after it's available
                setTimeout(()=>{
                    if (!response.isComplete && !state.isInterviewComplete && window.startAudioContextRecording) {
                        utils_logger/* logger */.vF.audio.record('Auto-starting recording after AI response');
                        setTimeout(()=>{
                            if (window.startAudioContextRecording) {
                                console.log('🎯 [AGENT] Auto-starting recording after AI response');
                                window.startAudioContextRecording();
                            }
                        }, 500);
                    }
                }, 100); // Small delay to ensure response is available
            }, (error)=>{
                console.warn('🎯 [AGENT] Audio playback had issues:', error.message);
                utils_logger/* logger */.vF.warn('Audio playback had issues, continuing conversation', error);
                dispatch({
                    type: 'RESET_TO_WAITING'
                });
                // Use response data after it's available  
                setTimeout(()=>{
                    if (!response.isComplete && !state.isInterviewComplete && window.startAudioContextRecording) {
                        utils_logger/* logger */.vF.audio.record('Continuing recording despite audio issues');
                        setTimeout(()=>{
                            if (window.startAudioContextRecording) {
                                console.log('🎯 [AGENT] Continuing recording despite audio issues');
                                window.startAudioContextRecording();
                            }
                        }, 1000);
                    }
                }, 100);
            });
            console.log('🎯 [AGENT] Got response:', {
                questionNumber: response.questionNumber,
                isComplete: response.isComplete,
                userMessageLength: response.userMessage.content.length,
                aiMessageLength: response.aiMessage.content.length
            });
            const { userMessage, aiMessage, questionNumber, isComplete } = response;
            // Update state with messages and progress
            dispatch({
                type: 'ADD_MESSAGES',
                payload: [
                    userMessage,
                    aiMessage
                ]
            });
            if (questionNumber !== undefined) {
                dispatch({
                    type: 'SET_QUESTION_NUMBER',
                    payload: questionNumber
                });
            }
            if (isComplete !== undefined) {
                dispatch({
                    type: 'SET_INTERVIEW_COMPLETE',
                    payload: isComplete
                });
            }
        } catch (error) {
            console.error('🎯 [AGENT] Conversation processing failed:', error);
            utils_logger/* logger */.vF.error('Conversation processing failed', error instanceof Error ? error : new Error('Conversation failed'));
            dispatch({
                type: 'RESET_TO_WAITING'
            });
            (0,error_utils/* showErrorNotification */.p6)(error instanceof Error ? error : new Error('Conversation failed'));
        }
    };
    const handleStartInterview = async ()=>{
        try {
            utils_logger/* logger */.vF.info('Starting Azure-powered voice interview', {
                userName,
                type,
                interviewId
            });
            dispatch(createStartInterviewAction());
            // Setup optimized audio context
            const { context, source, workletNode, cleanup } = await createOptimizedAudioContext();
            // Store cleanup function
            audioCleanupRef.current = cleanup;
            window.audioContext = context;
            dispatch({
                type: 'SET_AUDIO_STREAM',
                payload: context.state
            }); // Store reference
            // Build interview context
            const interviewContext = {
                userName,
                questions: resumeQuestions || questions,
                type,
                userId,
                interviewId,
                feedbackId,
                resumeInfo: resumeInfo ? {
                    hasResume: true,
                    candidateName: resumeInfo.personalInfo?.name || userName,
                    summary: resumeInfo.summary,
                    skills: resumeInfo.skills?.join(', ') || '',
                    experience: resumeInfo.experience?.map((exp)=>`${exp.position} at ${exp.company} (${exp.startDate} - ${exp.endDate || 'Present'})`).join(', ') || '',
                    education: resumeInfo.education?.map((edu)=>`${edu.degree} in ${edu.field} from ${edu.institution}`).join(', ') || '',
                    yearsOfExperience: resumeInfo.experience?.length || 0
                } : {
                    hasResume: false
                }
            };
            // Start conversation with Azure
            console.log('🎯 [AGENT DEBUG] About to start conversation...');
            const data = await startConversation(interviewContext);
            console.log('🎯 [AGENT DEBUG] Received conversation data:', {
                messageLength: data.message?.length,
                questionNumber: data.questionNumber,
                isComplete: data.isComplete,
                hasAudio: data.hasAudio
            });
            // Update state with initial AI message and progress
            console.log('🎯 [AGENT DEBUG] Adding AI message to state...');
            dispatch(createAddAIMessageAction(data.message));
            if (data.questionNumber !== undefined) {
                dispatch({
                    type: 'SET_QUESTION_NUMBER',
                    payload: data.questionNumber
                });
            }
            if (data.isComplete !== undefined) {
                dispatch({
                    type: 'SET_INTERVIEW_COMPLETE',
                    payload: data.isComplete
                });
            }
            // Setup audio recording handlers with voice activity detection
            workletNode.port.onmessage = (event)=>{
                if (event.data.type === 'audiodata' && isCurrentlyRecordingRef.current) {
                    audioSamplesRef.current.push(new Float32Array(event.data.audioData));
                    utils_logger/* logger */.vF.audio.record(`Audio chunk received (${event.data.audioData.length} samples)`);
                } else if (event.data.type === 'level') {
                    const rms = event.data.rms;
                    if (isCurrentlyRecordingRef.current) {
                        if (rms > 0.01) {
                            // Voice detected - reset silence timeout
                            lastVoiceActivityRef.current = Date.now();
                            if (silenceTimeoutRef.current) {
                                clearTimeout(silenceTimeoutRef.current);
                                silenceTimeoutRef.current = null;
                            }
                            utils_logger/* logger */.vF.audio.record(`Voice activity: RMS ${rms.toFixed(4)}`);
                        } else if (lastVoiceActivityRef.current > 0) {
                            // Check if we've been silent for too long
                            const silenceDuration = Date.now() - lastVoiceActivityRef.current;
                            if (silenceDuration > SILENCE_DURATION_MS && !silenceTimeoutRef.current) {
                                utils_logger/* logger */.vF.audio.record('Voice activity stopped - auto-stopping recording');
                                silenceTimeoutRef.current = setTimeout(()=>{
                                    if (isCurrentlyRecordingRef.current && window.stopAudioContextRecording) {
                                        utils_logger/* logger */.vF.audio.record('Auto-stopping recording after silence');
                                        window.stopAudioContextRecording();
                                    }
                                }, 100); // Small delay to ensure clean stop
                            }
                        }
                    }
                }
            };
            const startRecording = ()=>{
                if (isCurrentlyRecordingRef.current) return;
                utils_logger/* logger */.vF.audio.record('Starting audio recording');
                audioSamplesRef.current = [];
                isCurrentlyRecordingRef.current = true;
                dispatch({
                    type: 'START_RECORDING'
                });
                recordingTimeoutRef.current = setTimeout(()=>{
                    utils_logger/* logger */.vF.warn('Recording timeout reached (8s)');
                    stopRecording();
                }, 30000); // Increased to 30 seconds for better user experience
            };
            const stopRecording = ()=>{
                if (!isCurrentlyRecordingRef.current) return;
                utils_logger/* logger */.vF.audio.record('Stopping audio recording');
                isCurrentlyRecordingRef.current = false;
                dispatch({
                    type: 'STOP_RECORDING'
                });
                if (recordingTimeoutRef.current) {
                    clearTimeout(recordingTimeoutRef.current);
                    recordingTimeoutRef.current = null;
                }
                if (audioSamplesRef.current.length > 0) {
                    processAudioRecording(audioSamplesRef.current, context.sampleRate);
                }
            };
            // Store global functions for manual control
            window.startAudioContextRecording = startRecording;
            window.stopAudioContextRecording = stopRecording;
            // Play opening message and setup auto-recording
            await (0,error_utils/* handleAsyncError */.z$)(async ()=>{
                if (data.hasAudio) {
                    await playDirectAudioWithFallback(data.audioData, data.message, ()=>dispatch({
                            type: 'START_SPEAKING'
                        }), ()=>{
                        dispatch({
                            type: 'RESET_TO_WAITING'
                        });
                        // Auto-start recording for initial greeting
                        if (data.questionNumber === 0) {
                            utils_logger/* logger */.vF.audio.record('Auto-starting recording after greeting');
                            startRecording();
                        }
                    });
                } else {
                    await playAIResponse(data.message, ()=>dispatch({
                            type: 'START_SPEAKING'
                        }), ()=>{
                        dispatch({
                            type: 'RESET_TO_WAITING'
                        });
                        // Auto-start recording after opening message (first question)
                        if ((data.questionNumber || 0) <= 1 && !data.isComplete) {
                            utils_logger/* logger */.vF.audio.record('Auto-starting recording after AI greeting');
                            setTimeout(()=>startRecording(), 1000); // Small delay
                        }
                    });
                }
            }, 'Failed to play opening message');
            utils_logger/* logger */.vF.success('Voice interview started successfully');
        } catch (error) {
            utils_logger/* logger */.vF.error('Failed to start interview', error);
            dispatch({
                type: 'SET_INTERVIEW_STATE',
                payload: InterviewState.READY
            });
            (0,error_utils/* showErrorNotification */.p6)(error instanceof Error ? error : new Error('Failed to start interview'));
        }
    };
    // Cleanup on unmount
    (0,react.useEffect)(()=>{
        return ()=>{
            if (audioCleanupRef.current) {
                audioCleanupRef.current();
            }
            if (recordingTimeoutRef.current) {
                clearTimeout(recordingTimeoutRef.current);
            }
        };
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
        "data-testid": isInterviewActive ? "interview-session-active" : "interview-session-inactive",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "call-view",
                "data-testid": "session-id",
                "data-session-id": interviewId,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "card-interviewer",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                className: "avatar",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(api_image["default"], {
                                        src: "/ai-avatar.png",
                                        alt: "profile-image",
                                        width: 65,
                                        height: 54,
                                        className: "object-cover"
                                    }),
                                    isSpeaking && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                        className: "animate-speak",
                                        "data-testid": "ai-speaking-indicator"
                                    }),
                                    isProcessing && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                        className: "animate-speak bg-blue-500",
                                        "data-testid": "ai-processing-indicator"
                                    }),
                                    isRecording && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                        className: "animate-speak bg-red-500",
                                        "data-testid": "voice-recording-indicator"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                                "data-testid": "current-agent",
                                children: "AI Interviewer"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                        className: "card-border",
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                            className: "card-content",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                    className: "relative w-[120px] h-[120px] rounded-full overflow-hidden",
                                    children: state.userImage ? /*#__PURE__*/ (0,react_jsx_runtime.jsx)(api_image["default"], {
                                        src: state.userImage,
                                        alt: "profile-image",
                                        fill: true,
                                        sizes: "120px",
                                        className: "object-cover",
                                        onError: (e)=>{
                                            const target = e.target;
                                            target.onerror = null;
                                            target.src = "/user-avatar.png";
                                        }
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                        className: "w-full h-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-full",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("svg", {
                                            className: "w-12 h-12 text-gray-500",
                                            "aria-hidden": "true",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            fill: "none",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
                                                stroke: "currentColor",
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: "2",
                                                d: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0 0a8.949 8.949 0 0 0 4.951-1.488A3.987 3.987 0 0 0 13 16h-2a3.987 3.987 0 0 0-3.951 3.512A8.948 8.948 0 0 0 12 21Zm3-11a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                                    children: userName
                                })
                            ]
                        })
                    })
                ]
            }),
            state.messages.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "transcript-border",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "dark-gradient rounded-2xl min-h-12 px-5 py-3 flex flex-col border-l-4 border-blue-500",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                className: "transcript-header mb-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h4", {
                                    className: "text-sm font-medium text-gray-600 dark:text-gray-400 text-left",
                                    children: "Live Transcript"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                className: "transcript-messages max-h-40 overflow-y-auto space-y-2",
                                "data-testid": "conversation-transcript",
                                children: state.messages.map((message, index)=>{
                                    const isLastMessage = index === state.messages.length - 1;
                                    const isCurrentQuestion = message.role === "assistant" && isLastMessage;
                                    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                                        className: (0,utils.cn)("transcript-message p-2 rounded-lg", message.role === "assistant" ? "bg-blue-50 dark:bg-blue-900/20" : "bg-gray-50 dark:bg-gray-800/50"),
                                        "data-testid": isCurrentQuestion ? "current-question" : `message-${index}`,
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                                className: "flex items-start space-x-2",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                                    className: (0,utils.cn)("text-xs font-medium uppercase tracking-wide", message.role === "assistant" ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-400"),
                                                    children: message.role === "assistant" ? "AI" : "You"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
                                                className: "text-sm text-gray-800 dark:text-gray-200 mt-1",
                                                children: message.content
                                            })
                                        ]
                                    }, index);
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                        className: "hidden",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "response-processed",
                                className: state.messages.length > 0 ? "processed" : "pending"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "current-phase",
                                children: "technical"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                                "data-testid": "questions-answered-count",
                                children: Math.floor(state.messages.length / 2)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "w-full flex justify-center gap-4",
                children: !isInterviewActive ? /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                            className: "relative btn-call",
                            onClick: handleStartInterview,
                            "data-testid": "start-interview-btn",
                            children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                                className: "relative",
                                children: "Start Interview"
                            })
                        }),
                        shouldShowFeedback && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                            className: "btn-secondary",
                            onClick: ()=>router.push(`/dashboard/interview/${interviewId}/feedback`),
                            "data-testid": "view-feedback-btn",
                            children: "View Feedback"
                        })
                    ]
                }) : /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                            className: "btn-disconnect",
                            onClick: handleEndInterview,
                            "data-testid": "end-interview-btn",
                            children: "End Interview"
                        }),
                        isWaiting && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                            className: "btn-record",
                            onClick: ()=>window.startAudioContextRecording && window.startAudioContextRecording(),
                            "data-testid": "voice-record-btn",
                            disabled: !isWaiting,
                            children: "\uD83C\uDFA4 Record"
                        }),
                        isRecording && /*#__PURE__*/ (0,react_jsx_runtime.jsx)("button", {
                            className: "btn-stop",
                            onClick: ()=>window.stopAudioContextRecording && window.stopAudioContextRecording(),
                            "data-testid": "voice-stop-btn",
                            children: "⏹️ Stop"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const components_Agent = (Agent);


/***/ }),

/***/ 39764:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   vF: () => (/* binding */ logger)
/* harmony export */ });
/* unused harmony exports debug, info, success, warn, error */
/**
 * Centralized logging utility with debug flag support
 * Helps reduce verbose console.debug statements throughout the codebase
 */ // Environment-based debug flag
const DEBUG =  false || process.env.DEBUG === 'true';
/**
 * Core logger with emoji prefixes for visual recognition
 */ const logger = {
    debug: (message, context)=>{
        if (DEBUG) {
            context ? console.debug(`🔍 ${message}`, context) : console.debug(`🔍 ${message}`);
        }
    },
    info: (message, context)=>{
        context ? console.info(`ℹ️ ${message}`, context) : console.info(`ℹ️ ${message}`);
    },
    success: (message, context)=>{
        context ? console.log(`✅ ${message}`, context) : console.log(`✅ ${message}`);
    },
    warn: (message, context)=>{
        context ? console.warn(`⚠️ ${message}`, context) : console.warn(`⚠️ ${message}`);
    },
    error: (message, error, context)=>{
        const errorInfo = error instanceof Error ? {
            message: error.message,
            stack: error.stack
        } : error;
        context ? console.error(`❌ ${message}`, {
            error: errorInfo,
            ...context
        }) : console.error(`❌ ${message}`, errorInfo);
    },
    // Audio-specific logging shortcuts
    audio: {
        process: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎵 ${message}`, context) : console.debug(`🎵 ${message}`);
            }
        },
        record: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🎤 ${message}`, context) : console.debug(`🎤 ${message}`);
            }
        },
        speak: (message, context)=>{
            if (DEBUG) {
                context ? console.debug(`🔊 ${message}`, context) : console.debug(`🔊 ${message}`);
            }
        }
    },
    // State management logging
    state: (action, from, to, context)=>{
        if (DEBUG) {
            const message = `State transition: ${from} → ${to}`;
            context ? console.debug(`🔄 [${action}] ${message}`, context) : console.debug(`🔄 [${action}] ${message}`);
        }
    },
    // API request logging
    api: {
        request: (endpoint, method, context)=>{
            if (DEBUG) {
                context ? console.debug(`📤 API ${method} ${endpoint}`, context) : console.debug(`📤 API ${method} ${endpoint}`);
            }
        },
        response: (endpoint, status, context)=>{
            const icon = status >= 200 && status < 300 ? '📥' : '❌';
            if (DEBUG) {
                context ? console.debug(`${icon} API Response ${status} ${endpoint}`, context) : console.debug(`${icon} API Response ${status} ${endpoint}`);
            }
        }
    }
};
// Convenience exports
const { debug, info, success, warn, error } = logger;


/***/ }),

/***/ 79042:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   u: () => (/* binding */ useFeatureFlag)
/* harmony export */ });
/* unused harmony exports useUnifiedConfig, useUnifiedConfigs, useFeatureFlags, useAppConfig, useQuotaConfig */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* __next_internal_client_entry_do_not_use__ useUnifiedConfig,useUnifiedConfigs,useFeatureFlag,useFeatureFlags,useAppConfig,useQuotaConfig,default auto */ /**
 * Client-side React hook for unified configuration service
 * 
 * This provides a clean React interface to the unified config service
 * with proper state management, caching, and error handling.
 */ 
/**
 * Hook to get a single configuration value with reactivity using API calls
 * This avoids bundling server-only modules for the client
 */ function useUnifiedConfig(key, defaultValue) {
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultValue);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const fetchValue = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async ()=>{
        try {
            setLoading(true);
            setError(null);
            // Use API endpoint instead of direct service import
            const response = await fetch(`/api/config/${encodeURIComponent(key)}`);
            if (!response.ok) {
                throw new Error(`Failed to fetch config: ${response.statusText}`);
            }
            const data = await response.json();
            setValue(data.value !== undefined ? data.value : defaultValue);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Unknown error');
            setValue(defaultValue);
        } finally{
            setLoading(false);
        }
    }, [
        key,
        defaultValue
    ]);
    const refresh = async ()=>{
        await fetchValue();
    };
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        fetchValue();
    }, [
        fetchValue
    ]);
    return {
        value,
        loading,
        error,
        refresh
    };
}
/**
 * Hook to get multiple configuration values at once
 */ function useUnifiedConfigs(keys, defaultValues) {
    const [values, setValues] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const fetchValues = useCallback(async ()=>{
        try {
            setLoading(true);
            setError(null);
            // Use API endpoints for each config key
            const configPromises = keys.map(async (key)=>{
                const response = await fetch(`/api/config/${encodeURIComponent(String(key))}`);
                if (!response.ok) {
                    throw new Error(`Failed to fetch config for ${String(key)}: ${response.statusText}`);
                }
                const data = await response.json();
                return {
                    key,
                    value: data.value !== undefined ? data.value : defaultValues?.[key]
                };
            });
            const configResults = await Promise.all(configPromises);
            const result = {};
            configResults.forEach(({ key, value })=>{
                result[key] = value;
            });
            setValues(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Unknown error');
            setValues({
                ...defaultValues
            });
        } finally{
            setLoading(false);
        }
    }, [
        keys,
        defaultValues
    ]);
    const refresh = async ()=>{
        await fetchValues();
    };
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && useEffect(()=>{
        fetchValues();
    }, [
        fetchValues
    ]);
    return {
        values,
        loading,
        error,
        refresh
    };
}
/**
 * Hook for feature flags specifically
 */ function useFeatureFlag(flagName) {
    const configKey = `features.${flagName}`;
    const { value, loading, error } = useUnifiedConfig(configKey, false);
    return {
        enabled: value,
        loading,
        error
    };
}
/**
 * Hook for multiple feature flags
 */ function useFeatureFlags(flagNames) {
    const configKeys = flagNames.map((name)=>`features.${String(name)}`);
    const defaultFlags = flagNames.reduce((acc, name)=>{
        acc[name] = false;
        return acc;
    }, {});
    const { values, loading, error } = useUnifiedConfigs(configKeys, defaultFlags);
    // Transform config keys back to flag names
    const flags = {};
    flagNames.forEach((flagName, index)=>{
        const configKey = configKeys[index];
        flags[flagName] = values[configKey] || false;
    });
    return {
        flags,
        loading,
        error
    };
}
/**
 * Hook for application configuration
 */ function useAppConfig() {
    const configKeys = [
        'core.app.environment',
        'core.app.version',
        'core.app.debug',
        'core.app.maintenanceMode'
    ];
    const { values, loading, error } = useUnifiedConfigs([
        ...configKeys
    ], {
        'core.app.environment': 'development',
        'core.app.version': '1.0.0',
        'core.app.debug': false,
        'core.app.maintenanceMode': false
    });
    return {
        environment: values['core.app.environment'],
        version: values['core.app.version'],
        debug: values['core.app.debug'],
        maintenanceMode: values['core.app.maintenanceMode'],
        loading,
        error
    };
}
/**
 * Hook for quotas and limits
 */ function useQuotaConfig() {
    const configKeys = [
        'quotas.freeInterviews',
        'quotas.freeResumes',
        'quotas.premiumInterviews',
        'quotas.premiumResumes'
    ];
    const { values, loading, error } = useUnifiedConfigs([
        ...configKeys
    ], {
        'quotas.freeInterviews': 3,
        'quotas.freeResumes': 2,
        'quotas.premiumInterviews': 100,
        'quotas.premiumResumes': 20
    });
    return {
        freeInterviews: values['quotas.freeInterviews'],
        freeResumes: values['quotas.freeResumes'],
        premiumInterviews: values['quotas.premiumInterviews'],
        premiumResumes: values['quotas.premiumResumes'],
        loading,
        error
    };
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useUnifiedConfig)));


/***/ }),

/***/ 82897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   db: () => (/* binding */ db),
/* harmony export */   hJ: () => (/* binding */ googleProvider),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(67989);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91042);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75535);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  false ? 0 : null;
    const windowProjectId =  false ? 0 : null;
    const windowAuthDomain =  false ? 0 : null;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || `${finalProjectId}.firebaseapp.com`;
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (true) {
        console.log('🔥 Firebase initialization skipped on server side');
        return;
    }
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = getApps();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = initializeApp(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = getAuth(app);
        db = getFirestore(app);
        // Initialize Google Auth Provider
        googleProvider = new GoogleAuthProvider();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (false) {}
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (false) {}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});


/***/ }),

/***/ 91090:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ CodeEditorWrapper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(30036);
/* __next_internal_client_entry_do_not_use__ CodeEditorWrapper,default auto */ 

const CodeEditor = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_1__["default"])(async ()=>{
     true && /*require.resolve*/(null /* weak dependency, without id */);
}, {
    loadableGenerated: {
        modules: [
            "components/CodeEditorWrapper.tsx -> " + "@/components/CodeEditor"
        ]
    },
    ssr: false,
    loading: ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "h-64 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "animate-pulse text-gray-500",
                children: "Loading editor..."
            })
        })
});
const CodeEditorWrapper = ({ initialValue = "// Write your code here", language = "javascript", className = "", isExpanded = true, onToggleExpand })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: className,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(CodeEditor, {
            initialValue: initialValue,
            language: language,
            isExpanded: isExpanded,
            onToggleExpand: onToggleExpand
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CodeEditorWrapper)));


/***/ }),

/***/ 99728:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VoiceTelemetry: () => (/* binding */ VoiceTelemetry),
/* harmony export */   Xl: () => (/* binding */ VoiceConnectionError)
/* harmony export */ });
/* unused harmony exports VoiceAudioError, VoiceSessionError, VoiceTelemetryService, getVoiceTelemetry, voiceTelemetry */
/* harmony import */ var _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(39764);
/* harmony import */ var _lib_utils_error_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8008);
/**
 * Azure AI Foundry Voice Telemetry
 * 
 * Provides structured logging, error handling, and metrics collection
 * specifically for the voice system with Application Insights integration.
 */ 

/**
 * Voice system specific errors with context
 */ class VoiceConnectionError extends Error {
    constructor(message, sessionId, retryCount, lastError){
        super(message), this.sessionId = sessionId, this.retryCount = retryCount, this.lastError = lastError;
        this.name = 'VoiceConnectionError';
    }
}
class VoiceAudioError extends Error {
    constructor(message, sessionId, audioContext, sampleRate){
        super(message), this.sessionId = sessionId, this.audioContext = audioContext, this.sampleRate = sampleRate;
        this.name = 'VoiceAudioError';
    }
}
class VoiceSessionError extends Error {
    constructor(message, sessionId, sessionState, lastAction){
        super(message), this.sessionId = sessionId, this.sessionState = sessionState, this.lastAction = lastAction;
        this.name = 'VoiceSessionError';
    }
}
/**
 * Voice Telemetry Service
 */ class VoiceTelemetryService {
    /**
   * Initialize telemetry for a session
   */ startSession(sessionId, userId) {
        this.sessionStartTime = Date.now();
        this.lastEventTime = this.sessionStartTime;
        this.logEvent('voice_session_started', {
            sessionId,
            userId,
            userAgent: navigator.userAgent,
            timestamp: this.sessionStartTime
        });
        // Initialize metrics
        this.connectionMetrics = {};
        this.audioMetrics = {
            bufferUnderruns: 0
        };
        this.sessionMetrics = {
            messageCount: 0,
            errorCount: 0
        };
    }
    /**
   * Log connection events with metrics
   */ logConnectionEvent(event, sessionId, metrics) {
        const now = Date.now();
        const latency = now - this.lastEventTime;
        this.logEvent(`voice_connection_${event}`, {
            sessionId,
            latency,
            ...metrics
        }, {
            connection_time: metrics?.connectionTime || 0,
            retry_count: metrics?.retryCount || 0,
            network_latency: metrics?.networkLatency || latency
        });
        // Update connection metrics
        Object.assign(this.connectionMetrics, metrics);
        // Log specific connection issues
        if (event === 'failed' || event === 'disconnected') {
            this.sessionMetrics.errorCount = (this.sessionMetrics.errorCount || 0) + 1;
            if (metrics?.disconnectionReason) {
                _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn(`Voice connection ${event}: ${metrics.disconnectionReason}`, {
                    sessionId,
                    retryCount: metrics.retryCount,
                    ...metrics
                });
            }
        }
        this.lastEventTime = now;
    }
    /**
   * Log audio processing events with performance metrics
   */ logAudioEvent(event, sessionId, metrics) {
        const now = Date.now();
        const eventLatency = now - this.lastEventTime;
        this.logEvent(`voice_audio_${event}`, {
            sessionId,
            eventLatency,
            ...metrics
        }, {
            stt_latency: metrics?.sttLatency || 0,
            tts_latency: metrics?.ttsLatency || 0,
            audio_quality: metrics?.audioQuality || 0,
            voice_activity: metrics?.voiceActivity || 0
        });
        // Update audio metrics
        Object.assign(this.audioMetrics, metrics);
        // Track buffer issues
        if (event === 'buffer_underrun') {
            this.audioMetrics.bufferUnderruns = (this.audioMetrics.bufferUnderruns || 0) + 1;
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('Audio buffer underrun detected', {
                sessionId,
                ...metrics
            });
        }
        // Log performance warnings
        if (metrics?.sttLatency && metrics.sttLatency > 2000) {
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('High STT latency detected', {
                sessionId,
                latency: metrics.sttLatency,
                threshold: 2000
            });
        }
        if (metrics?.ttsLatency && metrics.ttsLatency > 1500) {
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('High TTS latency detected', {
                sessionId,
                latency: metrics.ttsLatency,
                threshold: 1500
            });
        }
        this.lastEventTime = now;
    }
    /**
   * Log transcript events with accuracy metrics
   */ logTranscriptEvent(event, sessionId, text, confidence) {
        this.logEvent(`voice_${event}`, {
            sessionId,
            textLength: text.length,
            confidence,
            preview: text.substring(0, 50) + (text.length > 50 ? '...' : '')
        }, {
            text_length: text.length,
            confidence: confidence || 0
        });
        // Track message count and accuracy
        if (event === 'transcript_final') {
            this.sessionMetrics.messageCount = (this.sessionMetrics.messageCount || 0) + 1;
            if (confidence) {
                const currentAccuracy = this.sessionMetrics.transcriptAccuracy || 0;
                const messageCount = this.sessionMetrics.messageCount || 1;
                this.sessionMetrics.transcriptAccuracy = (currentAccuracy * (messageCount - 1) + confidence) / messageCount;
            }
        }
        // Log low confidence warnings
        if (confidence && confidence < 0.7) {
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn('Low transcript confidence', {
                sessionId,
                confidence,
                text: text.substring(0, 100),
                threshold: 0.7
            });
        }
    }
    /**
   * Log session lifecycle events
   */ logSessionEvent(event, sessionId, details) {
        const now = Date.now();
        const sessionDuration = this.sessionStartTime ? now - this.sessionStartTime : 0;
        this.logEvent(`voice_${event}`, {
            sessionId,
            sessionDuration,
            ...details
        }, {
            session_duration: sessionDuration,
            message_count: this.sessionMetrics.messageCount || 0,
            error_count: this.sessionMetrics.errorCount || 0
        });
        // Update session metrics
        if (event === 'session_stopped') {
            this.sessionMetrics.sessionDuration = sessionDuration;
            this.generateSessionSummary(sessionId);
        }
    }
    /**
   * Handle and log voice system errors with context
   */ logError(error, sessionId, context, shouldNotifyUser = false) {
        const errorContext = {
            sessionId,
            context,
            errorType: error.constructor.name,
            ...error.additionalContext
        };
        // Log structured error
        this.logEvent('voice_error', {
            sessionId,
            errorMessage: error.message,
            errorType: error.constructor.name,
            context,
            stack: error.stack?.substring(0, 500) // Truncate stack trace
        });
        // Report to centralized error handling
        (0,_lib_utils_error_utils__WEBPACK_IMPORTED_MODULE_1__/* .reportError */ .N7)(error, context || 'Voice System Error', errorContext);
        // Update error count
        this.sessionMetrics.errorCount = (this.sessionMetrics.errorCount || 0) + 1;
        // Show user notification for critical errors
        if (shouldNotifyUser) {
            let userMessage = 'Voice system error occurred';
            if (error instanceof VoiceConnectionError) {
                userMessage = 'Connection to voice service lost. Attempting to reconnect...';
            } else if (error instanceof VoiceAudioError) {
                userMessage = 'Audio processing error. Please check your microphone permissions.';
            } else if (error instanceof VoiceSessionError) {
                userMessage = 'Voice session error. Please try restarting the interview.';
            }
            (0,_lib_utils_error_utils__WEBPACK_IMPORTED_MODULE_1__/* .showErrorNotification */ .p6)(userMessage, context);
        }
    }
    /**
   * Log performance metrics
   */ logPerformanceMetric(metricName, value, sessionId, unit = 'ms') {
        this.logEvent('voice_performance_metric', {
            sessionId,
            metricName,
            value,
            unit
        }, {
            [metricName]: value
        });
        // Log performance warnings
        const thresholds = {
            'connection_time': 3000,
            'stt_latency': 2000,
            'tts_latency': 1500,
            'session_init_time': 5000
        };
        if (thresholds[metricName] && value > thresholds[metricName]) {
            _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.warn(`Performance threshold exceeded: ${metricName}`, {
                sessionId,
                value,
                threshold: thresholds[metricName],
                unit
            });
        }
    }
    /**
   * Generate session summary for analytics
   */ generateSessionSummary(sessionId) {
        const properties = {
            sessionId
        };
        const measurements = {
            duration: this.sessionMetrics.sessionDuration || 0,
            messageCount: this.sessionMetrics.messageCount || 0,
            errorCount: this.sessionMetrics.errorCount || 0,
            transcriptAccuracy: this.sessionMetrics.transcriptAccuracy || 0,
            connectionRetries: this.connectionMetrics.retryCount || 0,
            audioBufferIssues: this.audioMetrics.bufferUnderruns || 0,
            averageSttLatency: this.audioMetrics.sttLatency || 0,
            averageTtsLatency: this.audioMetrics.ttsLatency || 0
        };
        this.logEvent('voice_session_summary', properties, measurements);
        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.info('Voice session summary', {
            ...properties,
            ...measurements
        });
    }
    /**
   * Core event logging with Application Insights integration
   */ logEvent(name, properties, measurements) {
        const event = {
            name,
            timestamp: Date.now(),
            properties,
            measurements
        };
        // Store locally
        this.events.push(event);
        // Keep only last 100 events in memory
        if (this.events.length > 100) {
            this.events = this.events.slice(-100);
        }
        // Log to console for development
        if (false) {}
        // TODO: Integration with Azure Application Insights
        // if (window.appInsights) {
        //   window.appInsights.trackEvent({
        //     name: `voice_${name}`,
        //     properties,
        //     measurements
        //   });
        // }
        // Standard logging
        _lib_utils_logger__WEBPACK_IMPORTED_MODULE_0__/* .logger */ .vF.info(`Voice telemetry: ${name}`, {
            properties,
            measurements
        });
    }
    /**
   * Get current session metrics
   */ getMetrics() {
        return {
            connection: this.connectionMetrics,
            audio: this.audioMetrics,
            session: this.sessionMetrics
        };
    }
    /**
   * Export telemetry data for analysis
   */ exportTelemetryData() {
        return [
            ...this.events
        ];
    }
    /**
   * Clear telemetry data
   */ clearTelemetryData() {
        this.events = [];
        this.connectionMetrics = {};
        this.audioMetrics = {
            bufferUnderruns: 0
        };
        this.sessionMetrics = {
            messageCount: 0,
            errorCount: 0
        };
    }
    constructor(){
        this.events = [];
        this.sessionStartTime = 0;
        this.lastEventTime = 0;
        // Metrics aggregation
        this.connectionMetrics = {};
        this.audioMetrics = {};
        this.sessionMetrics = {};
    }
}
// Singleton instance
let voiceTelemetryInstance = null;
/**
 * Get shared VoiceTelemetryService instance
 */ function getVoiceTelemetry() {
    if (!voiceTelemetryInstance) {
        voiceTelemetryInstance = new VoiceTelemetryService();
    }
    return voiceTelemetryInstance;
}
/**
 * Utility functions for common voice telemetry operations
 */ const VoiceTelemetry = {
    // Connection tracking
    trackConnection: (event, sessionId, metrics)=>{
        getVoiceTelemetry().logConnectionEvent(event, sessionId, metrics);
    },
    // Audio performance tracking
    trackAudioLatency: (type, latency, sessionId)=>{
        const metrics = type === 'stt' ? {
            sttLatency: latency
        } : {
            ttsLatency: latency
        };
        getVoiceTelemetry().logAudioEvent(`${type}_complete`, sessionId, metrics);
    },
    // Error tracking with user notifications
    trackError: (error, sessionId, context, notifyUser = false)=>{
        getVoiceTelemetry().logError(error, sessionId, context, notifyUser);
    },
    // Performance monitoring
    trackPerformance: (metric, value, sessionId)=>{
        getVoiceTelemetry().logPerformanceMetric(metric, value, sessionId);
    },
    // Session lifecycle
    startSession: (sessionId, userId)=>{
        getVoiceTelemetry().startSession(sessionId, userId);
    },
    endSession: (sessionId)=>{
        getVoiceTelemetry().logSessionEvent('session_stopped', sessionId);
    },
    // Singleton access methods
    getInstance: ()=>getVoiceTelemetry()
};
/**
 * Export singleton instance for convenience
 */ const voiceTelemetry = getVoiceTelemetry();


/***/ })

};
;