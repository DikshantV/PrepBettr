"use strict";
exports.id = 5060;
exports.ids = [5060];
exports.modules = {

/***/ 65060:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   app: () => (/* binding */ app),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony exports db, googleProvider */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66551);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86958);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(44337);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  false ? 0 : null;
    const windowProjectId =  false ? 0 : null;
    const windowAuthDomain =  false ? 0 : null;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || `${finalProjectId}.firebaseapp.com`;
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (true) {
        console.log('🔥 Firebase initialization skipped on server side');
        return;
    }
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = getApps();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = initializeApp(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = getAuth(app);
        db = getFirestore(app);
        // Initialize Google Auth Provider
        googleProvider = new GoogleAuthProvider();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (false) {}
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (false) {}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;