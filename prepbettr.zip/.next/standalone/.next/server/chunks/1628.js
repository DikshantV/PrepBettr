"use strict";
exports.id = 1628;
exports.ids = [1628];
exports.modules = {

/***/ 45936:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   O: () => (/* binding */ questionBankService)
/* harmony export */ });
/* unused harmony export MOCK_INTERVIEW_TEMPLATES */
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75931);
/* harmony import */ var _lib_ai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(53685);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_ai__WEBPACK_IMPORTED_MODULE_1__]);
_lib_ai__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Question Bank Service
 * 
 * Centralized service for managing interview questions with caching support.
 * Consolidates mock question data and provides APIs for dynamic question generation.
 */ 

// ===== MOCK DATA =====
const MOCK_INTERVIEW_TEMPLATES = [
    {
        id: 'frontend-dev-1',
        role: 'Frontend Developer',
        type: 'technical',
        techStack: [
            'React',
            'TypeScript',
            'Next.js',
            'Tailwind CSS'
        ],
        questions: [
            'Explain the concept of React hooks and provide examples',
            'What is the virtual DOM and how does it work?',
            'How do you handle state management in React applications?',
            'Describe the differences between TypeScript and JavaScript',
            'How do you implement responsive design with Tailwind CSS?'
        ],
        difficulty: 'medium',
        estimatedDuration: 45,
        description: 'Frontend development interview focusing on React ecosystem'
    },
    {
        id: 'backend-dev-1',
        role: 'Backend Developer',
        type: 'technical',
        techStack: [
            'Node.js',
            'Express',
            'MongoDB',
            'JavaScript'
        ],
        questions: [
            'Explain RESTful API design principles',
            'How do you handle database relationships in MongoDB?',
            'What are middleware functions in Express.js?',
            'How do you implement authentication and authorization?',
            'Describe your approach to error handling in APIs'
        ],
        difficulty: 'medium',
        estimatedDuration: 50,
        description: 'Backend development interview focusing on Node.js stack'
    },
    {
        id: 'fullstack-dev-1',
        role: 'Full Stack Developer',
        type: 'mixed',
        techStack: [
            'Python',
            'Django',
            'PostgreSQL',
            'Redis'
        ],
        questions: [
            'Describe your experience with full-stack development',
            'How do you optimize database queries?',
            'What is your approach to handling user authentication?',
            'How do you implement caching strategies?',
            'Describe a challenging full-stack project you built'
        ],
        difficulty: 'medium',
        estimatedDuration: 60,
        description: 'Full-stack development interview with Python/Django focus'
    },
    {
        id: 'software-eng-behavioral',
        role: 'Software Engineer',
        type: 'behavioral',
        techStack: [
            'Vue.js',
            'Nuxt.js',
            'Vuex',
            'SCSS'
        ],
        questions: [
            'Tell me about a challenging project you worked on',
            'How do you handle conflicts in a team environment?',
            'Describe a time when you had to learn a new technology quickly',
            'How do you prioritize tasks when everything seems urgent?',
            'Tell me about a mistake you made and how you handled it'
        ],
        difficulty: 'medium',
        estimatedDuration: 40,
        description: 'Behavioral interview for software engineering roles'
    },
    {
        id: 'devops-eng-1',
        role: 'DevOps Engineer',
        type: 'technical',
        techStack: [
            'Docker',
            'Kubernetes',
            'AWS',
            'Jenkins'
        ],
        questions: [
            'Explain containerization and its benefits',
            'How do you implement CI/CD pipelines?',
            'What is Infrastructure as Code?',
            'How do you monitor and troubleshoot production systems?',
            'Describe your experience with cloud platforms'
        ],
        difficulty: 'hard',
        estimatedDuration: 55,
        description: 'DevOps engineering interview focusing on containerization and CI/CD'
    },
    {
        id: 'data-scientist-1',
        role: 'Data Scientist',
        type: 'technical',
        techStack: [
            'Python',
            'TensorFlow',
            'Pandas',
            'SQL'
        ],
        questions: [
            'Explain the difference between supervised and unsupervised learning',
            'How do you handle missing data in datasets?',
            'What is feature engineering and why is it important?',
            'Describe your experience with neural networks',
            'How do you validate and test machine learning models?'
        ],
        difficulty: 'hard',
        estimatedDuration: 60,
        description: 'Data science interview covering machine learning fundamentals'
    },
    {
        id: 'mobile-dev-1',
        role: 'Mobile Developer',
        type: 'mixed',
        techStack: [
            'React Native',
            'JavaScript',
            'Firebase',
            'Redux'
        ],
        questions: [
            'What are the advantages of React Native over native development?',
            'How do you handle offline functionality in mobile apps?',
            'Describe your experience with mobile app deployment',
            'How do you optimize mobile app performance?',
            'What are your strategies for handling different screen sizes?'
        ],
        difficulty: 'medium',
        estimatedDuration: 45,
        description: 'Mobile development interview with React Native focus'
    },
    {
        id: 'qa-engineer-1',
        role: 'QA Engineer',
        type: 'technical',
        techStack: [
            'Selenium',
            'Jest',
            'Cypress',
            'JavaScript'
        ],
        questions: [
            'What is the difference between unit testing and integration testing?',
            'How do you design test cases for a new feature?',
            'Explain automation testing strategies you have used',
            'How do you handle flaky tests in your test suite?',
            'Describe your approach to performance testing'
        ],
        difficulty: 'medium',
        estimatedDuration: 40,
        description: 'Quality assurance interview focusing on testing strategies'
    }
];
const CURATED_QUESTIONS = [
    // Technical Questions
    {
        id: 'tech-react-hooks',
        content: 'Explain the concept of React hooks and provide examples',
        type: 'technical',
        difficulty: 'medium',
        techStack: [
            'React',
            'JavaScript'
        ],
        category: 'frontend',
        estimatedTime: 5,
        metadata: {
            tags: [
                'hooks',
                'state-management',
                'functional-components'
            ],
            source: 'curated',
            version: '1.0',
            lastUpdated: new Date()
        }
    },
    {
        id: 'tech-virtual-dom',
        content: 'What is the virtual DOM and how does it work?',
        type: 'technical',
        difficulty: 'medium',
        techStack: [
            'React',
            'JavaScript'
        ],
        category: 'frontend',
        estimatedTime: 4,
        metadata: {
            tags: [
                'virtual-dom',
                'performance',
                'react-internals'
            ],
            source: 'curated',
            version: '1.0',
            lastUpdated: new Date()
        }
    }
];
// ===== SERVICE CLASS =====
class QuestionBankService {
    constructor(config){
        this.cache = new Map();
        this.cacheConfig = {
            enabled: true,
            ttl: 3600,
            maxSize: 1000
        };
        if (config) {
            this.cacheConfig = {
                ...this.cacheConfig,
                ...config
            };
        }
    }
    // ===== CACHE METHODS =====
    getCacheKey(method, params) {
        return `qb:${method}:${JSON.stringify(params)}`;
    }
    getFromCache(key) {
        if (!this.cacheConfig.enabled) return null;
        const cached = this.cache.get(key);
        if (!cached) return null;
        const now = Date.now();
        if (now - cached.timestamp > cached.ttl * 1000) {
            this.cache.delete(key);
            return null;
        }
        return cached.data;
    }
    setCache(key, data, ttl) {
        if (!this.cacheConfig.enabled) return;
        // Clean up if cache is too large
        if (this.cache.size >= this.cacheConfig.maxSize) {
            const oldestKey = this.cache.keys().next().value;
            if (oldestKey) {
                this.cache.delete(oldestKey);
            }
        }
        this.cache.set(key, {
            data,
            timestamp: Date.now(),
            ttl: ttl || this.cacheConfig.ttl
        });
    }
    invalidateCache(pattern) {
        if (pattern) {
            const keys = Array.from(this.cache.keys()).filter((key)=>key.includes(pattern));
            keys.forEach((key)=>this.cache.delete(key));
            console.log(`🗑️ Invalidated ${keys.length} cache entries matching pattern: ${pattern}`);
        } else {
            this.cache.clear();
            console.log('🗑️ Invalidated entire question bank cache');
        }
    }
    // ===== CORE METHODS =====
    /**
   * Get interview template by ID or generate one based on criteria
   */ async getInterviewTemplate(templateId, options) {
        const cacheKey = this.getCacheKey('getInterviewTemplate', {
            templateId,
            options
        });
        const cached = this.getFromCache(cacheKey);
        if (cached) return cached;
        try {
            // First try to find existing template
            const template = MOCK_INTERVIEW_TEMPLATES.find((t)=>t.id === templateId);
            if (template) {
                this.setCache(cacheKey, template);
                return template;
            }
            // If not found and we have enough context, generate one
            if (options?.role) {
                const generatedTemplate = await this.generateInterviewTemplate(options);
                this.setCache(cacheKey, generatedTemplate);
                return generatedTemplate;
            }
            return null;
        } catch (error) {
            console.error('❌ Error getting interview template:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_0__/* .logServerError */ .wh)(error, {
                service: 'question-bank',
                action: 'getInterviewTemplate'
            });
            return null;
        }
    }
    /**
   * Get questions based on criteria
   */ async getQuestions(options = {}) {
        const cacheKey = this.getCacheKey('getQuestions', options);
        const cached = this.getFromCache(cacheKey);
        if (cached) return cached;
        try {
            let questions = [
                ...CURATED_QUESTIONS
            ];
            // Filter by criteria
            if (options.type) {
                questions = questions.filter((q)=>q.type === options.type);
            }
            if (options.difficulty) {
                questions = questions.filter((q)=>q.difficulty === options.difficulty);
            }
            if (options.techStack) {
                questions = questions.filter((q)=>q.techStack.some((tech)=>options.techStack.includes(tech)));
            }
            if (options.excludeIds) {
                questions = questions.filter((q)=>!options.excludeIds.includes(q.id));
            }
            // Generate additional questions if needed and enabled
            if (options.includeGenerated && questions.length < (options.maxQuestions || 10)) {
                const additionalQuestions = await this.generateQuestions({
                    ...options,
                    maxQuestions: (options.maxQuestions || 10) - questions.length
                });
                questions.push(...additionalQuestions);
            }
            // Apply max limit
            if (options.maxQuestions) {
                questions = questions.slice(0, options.maxQuestions);
            }
            this.setCache(cacheKey, questions);
            return questions;
        } catch (error) {
            console.error('❌ Error getting questions:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_0__/* .logServerError */ .wh)(error, {
                service: 'question-bank',
                action: 'getQuestions'
            });
            return CURATED_QUESTIONS.slice(0, options.maxQuestions || 10);
        }
    }
    /**
   * Generate new questions using AI
   */ async generateQuestions(options) {
        try {
            const prompt = this.buildQuestionGenerationPrompt(options);
            const response = await _lib_ai__WEBPACK_IMPORTED_MODULE_1__.azureAI.generateQuestions({
                name: 'Candidate',
                experience: options.role || 'Software Developer',
                education: 'Computer Science',
                skills: (options.techStack || []).join(', ')
            }, {
                maxQuestions: options.maxQuestions || 5,
                difficulty: options.difficulty,
                interviewType: options.type
            });
            if (!response.success || !response.data) {
                throw new Error(response.error || 'Failed to generate questions');
            }
            return response.data.map((content, index)=>({
                    id: `generated-${Date.now()}-${index}`,
                    content,
                    type: options.type || 'mixed',
                    difficulty: options.difficulty || 'medium',
                    techStack: options.techStack || [],
                    category: options.role?.toLowerCase().replace(' ', '-') || 'general',
                    estimatedTime: 5,
                    metadata: {
                        tags: [
                            'generated',
                            'ai'
                        ],
                        source: 'generated',
                        version: '1.0',
                        lastUpdated: new Date()
                    }
                }));
        } catch (error) {
            console.error('❌ Error generating questions:', error);
            return [];
        }
    }
    /**
   * Generate interview template using AI
   */ async generateInterviewTemplate(options) {
        const questions = await this.generateQuestions({
            ...options,
            maxQuestions: 5,
            includeGenerated: true
        });
        return {
            id: `generated-${Date.now()}`,
            role: options.role || 'Software Developer',
            type: options.type || 'mixed',
            techStack: options.techStack || [],
            questions: questions.map((q)=>q.content),
            difficulty: options.difficulty || 'medium',
            estimatedDuration: questions.length * 8,
            description: `Generated interview template for ${options.role || 'Software Developer'}`,
            metadata: {
                popularity: 0,
                successRate: 0,
                lastUsed: new Date()
            }
        };
    }
    /**
   * Get all available interview templates
   */ getAllTemplates() {
        return [
            ...MOCK_INTERVIEW_TEMPLATES
        ];
    }
    /**
   * Get templates by role
   */ getTemplatesByRole(role) {
        return MOCK_INTERVIEW_TEMPLATES.filter((t)=>t.role.toLowerCase().includes(role.toLowerCase()));
    }
    /**
   * Build prompt for question generation
   */ buildQuestionGenerationPrompt(options) {
        const parts = [
            `Generate ${options.maxQuestions || 5} interview questions for a ${options.role || 'Software Developer'} position.`
        ];
        if (options.type) {
            parts.push(`Focus on ${options.type} questions.`);
        }
        if (options.difficulty) {
            parts.push(`Questions should be ${options.difficulty} difficulty level.`);
        }
        if (options.techStack && options.techStack.length > 0) {
            parts.push(`Include questions about: ${options.techStack.join(', ')}.`);
        }
        parts.push('Make questions practical and relevant to real-world scenarios.');
        return parts.join(' ');
    }
    /**
   * Get cache statistics
   */ getCacheStats() {
        return {
            size: this.cache.size,
            maxSize: this.cacheConfig.maxSize,
            enabled: this.cacheConfig.enabled,
            ttl: this.cacheConfig.ttl
        };
    }
}
// ===== EXPORTS =====
// Singleton instance
const questionBankService = new QuestionBankService({
    enabled: true,
    ttl: 3600,
    maxSize: 500 // Reasonable size for questions cache
});
// Export templates for backward compatibility


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 74798:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   m: () => (/* binding */ azureFormRecognizer)
/* harmony export */ });
/* harmony import */ var _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(98180);
/* harmony import */ var _azure_lib_azure_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65868);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75931);



class AzureFormRecognizerService {
    /**
   * Initialize the Azure Form Recognizer service
   */ async initialize() {
        try {
            const secrets = await (0,_azure_lib_azure_config__WEBPACK_IMPORTED_MODULE_1__/* .fetchAzureSecrets */ .lL)();
            const endpoint = process.env.AZURE_FORM_RECOGNIZER_ENDPOINT || secrets.azureFormRecognizerEndpoint;
            const apiKey = process.env.AZURE_FORM_RECOGNIZER_KEY || secrets.azureFormRecognizerKey;
            if (!endpoint || !apiKey) {
                console.warn('⚠️ Azure Form Recognizer credentials not found, will use OpenAI fallback');
                return false;
            }
            this.client = new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_0__/* .DocumentAnalysisClient */ .Pz(endpoint, new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_0__/* .AzureKeyCredential */ .KL(apiKey));
            console.log('✅ Azure Form Recognizer service initialized');
            return true;
        } catch (error) {
            console.error('❌ Failed to initialize Azure Form Recognizer:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
                service: 'azure-form-recognizer',
                action: 'initialize'
            });
            return false;
        }
    }
    /**
   * Check if service is ready
   */ isReady() {
        return this.client !== null;
    }
    /**
   * Extract resume data from buffer using Azure Form Recognizer
   */ async extractResumeData(fileBuffer, mimeType) {
        if (!this.isReady()) {
            throw new Error('Azure Form Recognizer service not initialized');
        }
        try {
            console.log('🔍 Extracting resume data with Azure Form Recognizer...');
            // Analyze the document
            const poller = await this.client.beginAnalyzeDocument(this.modelId, fileBuffer);
            const result = await poller.pollUntilDone();
            // Extract text content from the document
            const fullText = result.content || '';
            // Store raw extraction for GDPR export
            const rawExtraction = {
                content: result.content,
                pages: result.pages,
                tables: result.tables,
                keyValuePairs: result.keyValuePairs,
                styles: result.styles
            };
            // Parse the extracted text to structure data
            const extractedData = await this.parseResumeContent(fullText);
            // Include raw extraction
            extractedData.rawExtraction = rawExtraction;
            console.log('✅ Resume data extracted successfully with Azure Form Recognizer');
            return extractedData;
        } catch (error) {
            console.error('Failed to extract resume data with Azure Form Recognizer:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
                service: 'azure-form-recognizer',
                action: 'extract'
            }, {
                mimeType
            });
            throw error;
        }
    }
    /**
   * Parse resume content using AI to extract structured data
   * This method uses OpenAI as a processing layer on top of Form Recognizer
   */ async parseResumeContent(text) {
        // We'll use tailorResume function as it's the main AI processing function available
        // Use OpenAI function calling to structure the extracted text
        const prompt = `
    Extract the following information from this resume text and return as JSON:
    
    {
      "personalInfo": {
        "name": "Full name",
        "email": "Email address",
        "phone": "Phone number",
        "address": "Address",
        "linkedin": "LinkedIn URL",
        "github": "GitHub URL",
        "website": "Personal website URL"
      },
      "summary": "Professional summary or objective",
      "skills": ["skill1", "skill2", ...],
      "experience": [
        {
          "company": "Company name",
          "position": "Job title",
          "startDate": "Start date",
          "endDate": "End date or 'Present'",
          "isCurrent": true/false,
          "description": "Job description",
          "achievements": ["achievement1", ...],
          "technologies": ["tech1", "tech2", ...],
          "location": "Location"
        }
      ],
      "education": [
        {
          "institution": "School name",
          "degree": "Degree type",
          "field": "Field of study",
          "startDate": "Start date",
          "endDate": "End date",
          "gpa": 3.5,
          "description": "Additional details",
          "location": "Location"
        }
      ],
      "projects": [
        {
          "name": "Project name",
          "description": "Project description",
          "technologies": ["tech1", "tech2", ...],
          "url": "Project URL",
          "github": "GitHub URL",
          "startDate": "Start date",
          "endDate": "End date"
        }
      ],
      "certifications": [
        {
          "name": "Certification name",
          "issuer": "Issuing organization",
          "date": "Issue date",
          "expiryDate": "Expiry date",
          "credentialId": "Credential ID",
          "url": "Verification URL"
        }
      ],
      "languages": [
        {
          "name": "Language name",
          "proficiency": "Proficiency level"
        }
      ]
    }
    
    Resume text:
    ${text}
    `;
        try {
            // Use the AI service to process the text
            const { tailorResume } = await Promise.all(/* import() */[__webpack_require__.e(8833), __webpack_require__.e(5506), __webpack_require__.e(6955), __webpack_require__.e(3685), __webpack_require__.e(6502)]).then(__webpack_require__.bind(__webpack_require__, 53685));
            // Create a structured extraction prompt
            const extractionResult = await tailorResume(text, prompt);
            if (extractionResult.success && extractionResult.data) {
                try {
                    // Parse the JSON response
                    const parsedData = typeof extractionResult.data === 'string' ? JSON.parse(extractionResult.data) : extractionResult.data;
                    return {
                        personalInfo: parsedData.personalInfo || {},
                        summary: parsedData.summary,
                        skills: parsedData.skills || [],
                        experience: parsedData.experience || [],
                        education: parsedData.education || [],
                        projects: parsedData.projects || [],
                        certifications: parsedData.certifications || [],
                        languages: parsedData.languages || []
                    };
                } catch (parseError) {
                    console.warn('Failed to parse AI extraction result, using fallback parsing');
                    return this.fallbackTextParsing(text);
                }
            }
            // Fallback to simple text parsing if AI fails
            return this.fallbackTextParsing(text);
        } catch (error) {
            console.warn('AI parsing failed, using fallback text parsing:', error);
            return this.fallbackTextParsing(text);
        }
    }
    /**
   * Fallback text parsing method
   */ fallbackTextParsing(text) {
        const lines = text.split('\n').map((line)=>line.trim()).filter((line)=>line);
        // Simple regex patterns for basic extraction
        const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
        const phoneRegex = /(\+?1?[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}/g;
        const linkedinRegex = /linkedin\.com\/in\/[\w-]+/gi;
        const githubRegex = /github\.com\/[\w-]+/gi;
        const emails = text.match(emailRegex) || [];
        const phones = text.match(phoneRegex) || [];
        const linkedinUrls = text.match(linkedinRegex) || [];
        const githubUrls = text.match(githubRegex) || [];
        // Extract skills (simple keyword matching)
        const skillKeywords = [
            'javascript',
            'typescript',
            'python',
            'java',
            'react',
            'node',
            'express',
            'mongodb',
            'sql',
            'postgresql',
            'mysql',
            'docker',
            'kubernetes',
            'aws',
            'azure',
            'gcp',
            'git',
            'html',
            'css',
            'angular',
            'vue',
            'spring',
            'django',
            'flask',
            'ruby',
            'php',
            'go',
            'rust',
            'c++',
            'c#',
            'swift',
            'kotlin',
            'flutter',
            'dart',
            'tensorflow',
            'pytorch',
            'machine learning',
            'data science',
            'artificial intelligence',
            'blockchain',
            'devops'
        ];
        const detectedSkills = skillKeywords.filter((skill)=>text.toLowerCase().includes(skill.toLowerCase()));
        return {
            personalInfo: {
                email: emails[0],
                phone: phones[0],
                linkedin: linkedinUrls[0] ? `https://${linkedinUrls[0]}` : undefined,
                github: githubUrls[0] ? `https://${githubUrls[0]}` : undefined
            },
            skills: detectedSkills,
            experience: [],
            education: [],
            projects: [],
            certifications: [],
            languages: []
        };
    }
    constructor(){
        this.client = null;
        this.modelId = 'prebuilt-document' // Use prebuilt document model
        ;
    }
}
// Export singleton instance
const azureFormRecognizer = new AzureFormRecognizerService();


/***/ }),

/***/ 85500:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   clearAzureSecretsCache: () => (/* binding */ clearAzureSecretsCache),
/* harmony export */   fetchAzureSecrets: () => (/* binding */ fetchAzureSecrets),
/* harmony export */   getAzureConfig: () => (/* binding */ getAzureConfig),
/* harmony export */   getConfiguration: () => (/* binding */ getConfiguration),
/* harmony export */   initializeAzureEnvironment: () => (/* binding */ initializeAzureEnvironment)
/* harmony export */ });
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10756);
/* harmony import */ var _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36695);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__]);
([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// Client-side safety check - provide empty implementations when running on client
const isClient = "undefined" !== 'undefined';
if (isClient) {
    console.warn('[Azure Config] Running on client side - using fallback implementations');
}
// Azure Key Vault configuration
const AZURE_KEY_VAULT_URI = process.env.AZURE_KEY_VAULT_URI || 'https://prepbettr-keyvault-083.vault.azure.net/';
let cachedSecrets = null;
/**
 * Initialize Azure Key Vault client
 */ function createKeyVaultClient() {
    if (!AZURE_KEY_VAULT_URI) {
        throw new Error('AZURE_KEY_VAULT_URI environment variable is required');
    }
    const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_0__.DefaultAzureCredential();
    return new _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__.SecretClient(AZURE_KEY_VAULT_URI, credential);
}
/**
 * Clear cached secrets (useful when Azure keys are renewed)
 */ function clearAzureSecretsCache() {
    if (isClient) return;
    console.log('🔄 Clearing Azure secrets cache...');
    cachedSecrets = null;
}
/**
 * Fetch secrets from Azure Key Vault
 */ async function fetchAzureSecrets(forceRefresh = false) {
    if (isClient) {
        return {
            speechKey: '',
            speechEndpoint: '',
            azureOpenAIKey: '',
            azureOpenAIEndpoint: '',
            azureOpenAIDeployment: '',
            firebaseProjectId: '',
            firebaseClientEmail: '',
            firebasePrivateKey: ''
        };
    }
    // Clear cache if force refresh is requested
    if (forceRefresh) {
        clearAzureSecretsCache();
    }
    // Return cached secrets if available
    if (cachedSecrets) {
        return cachedSecrets;
    }
    try {
        console.log('🔑 Fetching secrets from Azure Key Vault...');
        const client = createKeyVaultClient();
        // Helper function to suppress expected 404 errors for optional secrets
        const getOptionalSecret = (name)=>client.getSecret(name).catch((err)=>{
                if (err.statusCode !== 404) {
                    console.warn(`⚠️ Unexpected error fetching optional secret '${name}':`, err.message);
                }
                return null;
            });
        // Fetch all secrets (some are optional)
        const [speechKey, speechEndpoint, azureOpenAIKey, azureOpenAIEndpoint, azureOpenAIDeployment, firebaseProjectId, firebaseClientEmail, firebasePrivateKey, firebaseClientKey, azureFormRecognizerKey, azureFormRecognizerEndpoint, azureStorageAccount, azureStorageAccountKey, azureStorageConnectionString, azureStorageContainer, storageProvider] = await Promise.all([
            client.getSecret('speech-key'),
            client.getSecret('speech-endpoint'),
            client.getSecret('azure-openai-key'),
            client.getSecret('azure-openai-endpoint'),
            client.getSecret('azure-openai-deployment'),
            getOptionalSecret('firebase-project-id'),
            getOptionalSecret('firebase-client-email'),
            getOptionalSecret('firebase-private-key'),
            getOptionalSecret('NEXT-PUBLIC-FIREBASE-CLIENT-KEY'),
            getOptionalSecret('azure-form-recognizer-key'),
            getOptionalSecret('azure-form-recognizer-endpoint'),
            getOptionalSecret('azure-storage-account'),
            getOptionalSecret('azure-storage-account-key'),
            getOptionalSecret('azure-storage-connection-string'),
            getOptionalSecret('azure-storage-container'),
            getOptionalSecret('storage-provider')
        ]);
        // Validate only Azure-related secrets (Firebase can come from env vars)
        const requiredAzureSecrets = {
            speechKey: speechKey?.value,
            speechEndpoint: speechEndpoint?.value,
            azureOpenAIKey: azureOpenAIKey?.value,
            azureOpenAIEndpoint: azureOpenAIEndpoint?.value,
            azureOpenAIDeployment: azureOpenAIDeployment?.value
        };
        const missingAzureSecrets = Object.entries(requiredAzureSecrets).filter(([_, value])=>!value).map(([key, _])=>key);
        if (missingAzureSecrets.length > 0) {
            throw new Error(`Required Azure secrets missing from Key Vault: ${missingAzureSecrets.join(', ')}`);
        }
        cachedSecrets = {
            speechKey: speechKey.value,
            speechEndpoint: speechEndpoint.value,
            azureOpenAIKey: azureOpenAIKey.value,
            azureOpenAIEndpoint: azureOpenAIEndpoint.value,
            azureOpenAIDeployment: azureOpenAIDeployment.value,
            firebaseProjectId: firebaseProjectId?.value || process.env.FIREBASE_PROJECT_ID || '',
            firebaseClientEmail: firebaseClientEmail?.value || process.env.FIREBASE_CLIENT_EMAIL || '',
            firebasePrivateKey: firebasePrivateKey?.value || process.env.FIREBASE_PRIVATE_KEY || '',
            firebaseClientKey: firebaseClientKey?.value || '',
            azureFormRecognizerKey: azureFormRecognizerKey?.value,
            azureFormRecognizerEndpoint: azureFormRecognizerEndpoint?.value,
            azureStorageAccount: azureStorageAccount?.value,
            azureStorageAccountKey: azureStorageAccountKey?.value,
            azureStorageConnectionString: azureStorageConnectionString?.value,
            azureStorageContainer: azureStorageContainer?.value,
            storageProvider: storageProvider?.value
        };
        console.log('✅ Azure secrets loaded successfully');
        return cachedSecrets;
    } catch (error) {
        console.error('❌ Failed to fetch Azure secrets:', error);
        // Fallback to environment variables if Key Vault fails
        console.log('🔄 Falling back to environment variables...');
        const fallbackSecrets = {
            speechKey: process.env.AZURE_SPEECH_KEY || process.env.SPEECH_KEY || '',
            speechEndpoint: process.env.SPEECH_ENDPOINT || 'https://eastus2.api.cognitive.microsoft.com/',
            azureOpenAIKey: process.env.AZURE_OPENAI_API_KEY || process.env.AZURE_OPENAI_KEY || '',
            azureOpenAIEndpoint: process.env.AZURE_OPENAI_ENDPOINT || '',
            azureOpenAIDeployment: process.env.AZURE_OPENAI_DEPLOYMENT || '',
            // Firebase fallbacks
            firebaseProjectId: process.env.FIREBASE_PROJECT_ID || '',
            firebaseClientEmail: process.env.FIREBASE_CLIENT_EMAIL || '',
            firebasePrivateKey: process.env.FIREBASE_PRIVATE_KEY || '',
            firebaseClientKey: '',
            // Optional fallbacks
            azureFormRecognizerKey: process.env.AZURE_FORM_RECOGNIZER_KEY,
            azureFormRecognizerEndpoint: process.env.AZURE_FORM_RECOGNIZER_ENDPOINT,
            azureStorageAccount: process.env.AZURE_STORAGE_ACCOUNT_NAME,
            azureStorageAccountKey: process.env.AZURE_STORAGE_ACCOUNT_KEY
        };
        // Only warn about critical missing secrets
        const missingCritical = [];
        if (!fallbackSecrets.speechKey) missingCritical.push('SPEECH_KEY');
        if (!fallbackSecrets.azureOpenAIKey) missingCritical.push('AZURE_OPENAI_KEY');
        // Only warn about missing optional secrets if not available from environment
        const missingOptional = [];
        if (!fallbackSecrets.firebaseProjectId && !process.env.FIREBASE_PROJECT_ID) missingOptional.push('FIREBASE_PROJECT_ID');
        if (missingCritical.length > 0) {
            console.error(`❌ Critical secrets missing: ${missingCritical.join(', ')}`);
        }
        if (missingOptional.length > 0) {
            console.warn(`⚠️ Optional secrets missing: ${missingOptional.join(', ')}`);
        }
        cachedSecrets = fallbackSecrets;
        return cachedSecrets;
    }
}
/**
 * Initialize environment variables from Azure Key Vault
 * This should be called at application startup
 */ async function initializeAzureEnvironment() {
    if (isClient) return;
    try {
        const secrets = await fetchAzureSecrets();
        // Set Azure service environment variables
        process.env.SPEECH_KEY = secrets.speechKey;
        process.env.SPEECH_ENDPOINT = secrets.speechEndpoint;
        // Set Azure OpenAI environment variables
        process.env.AZURE_OPENAI_KEY = secrets.azureOpenAIKey;
        process.env.AZURE_OPENAI_ENDPOINT = secrets.azureOpenAIEndpoint;
        process.env.AZURE_OPENAI_DEPLOYMENT = secrets.azureOpenAIDeployment;
        // Set Firebase environment variables
        process.env.FIREBASE_PROJECT_ID = secrets.firebaseProjectId;
        process.env.FIREBASE_CLIENT_EMAIL = secrets.firebaseClientEmail;
        process.env.FIREBASE_PRIVATE_KEY = secrets.firebasePrivateKey;
        // Set client-side environment variables using string concatenation to avoid Next.js inlining
        const nextPublicPrefix = 'NEXT_PUBLIC_';
        process.env[nextPublicPrefix + 'SPEECH_KEY'] = secrets.speechKey;
        process.env[nextPublicPrefix + 'SPEECH_ENDPOINT'] = secrets.speechEndpoint;
        process.env[nextPublicPrefix + 'AZURE_OPENAI_API_KEY'] = secrets.azureOpenAIKey;
        process.env[nextPublicPrefix + 'AZURE_OPENAI_ENDPOINT'] = secrets.azureOpenAIEndpoint;
        process.env[nextPublicPrefix + 'AZURE_OPENAI_DEPLOYMENT'] = secrets.azureOpenAIDeployment;
        process.env[nextPublicPrefix + 'FIREBASE_PROJECT_ID'] = secrets.firebaseProjectId;
        // Set the Firebase client key from secrets or environment
        if (secrets.firebaseClientKey) {
            process.env[nextPublicPrefix + 'FIREBASE_CLIENT_KEY'] = secrets.firebaseClientKey;
            console.log('🔑 Firebase client key set from Azure Key Vault');
        } else {
            console.warn('⚠️ Firebase client key not found in Azure Key Vault');
        }
        // Set optional Azure services if available
        if (secrets.azureFormRecognizerKey) {
            process.env.AZURE_FORM_RECOGNIZER_KEY = secrets.azureFormRecognizerKey;
        }
        if (secrets.azureFormRecognizerEndpoint) {
            process.env.AZURE_FORM_RECOGNIZER_ENDPOINT = secrets.azureFormRecognizerEndpoint;
        }
        // Set storage configuration
        if (secrets.azureStorageAccount) {
            process.env.AZURE_STORAGE_ACCOUNT = secrets.azureStorageAccount;
        }
        if (secrets.azureStorageAccountKey) {
            process.env.AZURE_STORAGE_ACCOUNT_KEY = secrets.azureStorageAccountKey;
        }
        if (secrets.azureStorageConnectionString) {
            process.env.AZURE_STORAGE_CONNECTION_STRING = secrets.azureStorageConnectionString;
        }
        if (secrets.azureStorageContainer) {
            process.env.AZURE_STORAGE_CONTAINER = secrets.azureStorageContainer;
        }
        if (secrets.storageProvider) {
            process.env.STORAGE_PROVIDER = secrets.storageProvider;
        }
        console.log('🌟 Azure environment initialized successfully');
    } catch (error) {
        console.error('❌ Failed to initialize Azure environment:', error);
        throw error;
    }
}
/**
 * Get generic configuration values (used by storage abstraction and other services)
 */ async function getConfiguration() {
    try {
        const secrets = await fetchAzureSecrets();
        return {
            // Azure Storage configuration
            'AZURE_STORAGE_ACCOUNT': secrets.azureStorageAccount || process.env.AZURE_STORAGE_ACCOUNT || 'prepbettrstorage684',
            'AZURE_STORAGE_ACCOUNT_KEY': secrets.azureStorageAccountKey || process.env.AZURE_STORAGE_ACCOUNT_KEY || '',
            'AZURE_STORAGE_CONNECTION_STRING': secrets.azureStorageConnectionString || process.env.AZURE_STORAGE_CONNECTION_STRING || '',
            'AZURE_STORAGE_CONTAINER': secrets.azureStorageContainer || process.env.AZURE_STORAGE_CONTAINER || 'resumes',
            'STORAGE_PROVIDER': secrets.storageProvider || process.env.STORAGE_PROVIDER || 'firebase',
            // Azure AI services
            'AZURE_OPENAI_KEY': secrets.azureOpenAIKey,
            'AZURE_OPENAI_ENDPOINT': secrets.azureOpenAIEndpoint,
            'AZURE_OPENAI_DEPLOYMENT': secrets.azureOpenAIDeployment,
            'AZURE_SPEECH_KEY': secrets.speechKey,
            'AZURE_SPEECH_ENDPOINT': secrets.speechEndpoint,
            'AZURE_FORM_RECOGNIZER_KEY': secrets.azureFormRecognizerKey || '',
            'AZURE_FORM_RECOGNIZER_ENDPOINT': secrets.azureFormRecognizerEndpoint || '',
            // Firebase configuration
            'FIREBASE_PROJECT_ID': secrets.firebaseProjectId,
            'FIREBASE_CLIENT_EMAIL': secrets.firebaseClientEmail,
            'FIREBASE_PRIVATE_KEY': secrets.firebasePrivateKey,
            'FIREBASE_CLIENT_KEY': secrets.firebaseClientKey || ''
        };
    } catch (error) {
        console.warn('Failed to get configuration from Azure, using environment variables:', error);
        // Fallback to environment variables only
        return {
            'AZURE_STORAGE_ACCOUNT': process.env.AZURE_STORAGE_ACCOUNT || 'prepbettrstorage684',
            'AZURE_STORAGE_ACCOUNT_KEY': process.env.AZURE_STORAGE_ACCOUNT_KEY || '',
            'AZURE_STORAGE_CONNECTION_STRING': process.env.AZURE_STORAGE_CONNECTION_STRING || '',
            'AZURE_STORAGE_CONTAINER': process.env.AZURE_STORAGE_CONTAINER || 'resumes',
            'STORAGE_PROVIDER': process.env.STORAGE_PROVIDER || 'firebase',
            'AZURE_OPENAI_KEY': process.env.AZURE_OPENAI_KEY || '',
            'AZURE_OPENAI_ENDPOINT': process.env.AZURE_OPENAI_ENDPOINT || '',
            'AZURE_OPENAI_DEPLOYMENT': process.env.AZURE_OPENAI_DEPLOYMENT || '',
            'AZURE_SPEECH_KEY': process.env.AZURE_SPEECH_KEY || process.env.SPEECH_KEY || '',
            'AZURE_SPEECH_ENDPOINT': process.env.SPEECH_ENDPOINT || '',
            'AZURE_FORM_RECOGNIZER_KEY': process.env.AZURE_FORM_RECOGNIZER_KEY || '',
            'AZURE_FORM_RECOGNIZER_ENDPOINT': process.env.AZURE_FORM_RECOGNIZER_ENDPOINT || '',
            'FIREBASE_PROJECT_ID': process.env.FIREBASE_PROJECT_ID || '',
            'FIREBASE_CLIENT_EMAIL': process.env.FIREBASE_CLIENT_EMAIL || '',
            'FIREBASE_PRIVATE_KEY': process.env.FIREBASE_PRIVATE_KEY || '',
            // Use string concatenation to avoid Next.js inlining
            'FIREBASE_CLIENT_KEY': process.env['NEXT_PUBLIC_' + 'FIREBASE_CLIENT_KEY'] || ''
        };
    }
}
/**
 * Get current Azure configuration (for debugging)
 */ function getAzureConfig() {
    const nextPublicPrefix = 'NEXT_PUBLIC_';
    return {
        keyVaultUri: AZURE_KEY_VAULT_URI,
        hasSecretsCache: !!cachedSecrets,
        environment: {
            speechKey: !!process.env[nextPublicPrefix + 'SPEECH_KEY'],
            speechEndpoint: !!process.env[nextPublicPrefix + 'SPEECH_ENDPOINT'],
            azureOpenAIKey: !!process.env.AZURE_OPENAI_KEY,
            azureOpenAIEndpoint: !!process.env.AZURE_OPENAI_ENDPOINT,
            azureOpenAIDeployment: !!process.env.AZURE_OPENAI_DEPLOYMENT
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;