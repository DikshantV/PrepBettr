exports.id = 4622;
exports.ids = [4622,7870];
exports.modules = {

/***/ 12977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/components/AuthForm.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/AuthForm.tsx",
"default",
));


/***/ }),

/***/ 17989:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_AuthForm)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js
var react_jsx_runtime = __webpack_require__(60687);
// EXTERNAL MODULE: ./node_modules/zod/lib/index.mjs
var lib = __webpack_require__(45880);
// EXTERNAL MODULE: ./node_modules/next/dist/client/app-dir/link.js
var app_dir_link = __webpack_require__(85814);
var link_default = /*#__PURE__*/__webpack_require__.n(app_dir_link);
// EXTERNAL MODULE: ./node_modules/next/dist/api/image.js
var api_image = __webpack_require__(30474);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(52581);
// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.mjs
var index_esm = __webpack_require__(27605);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(16189);
// EXTERNAL MODULE: ./node_modules/@hookform/resolvers/zod/dist/zod.mjs + 1 modules
var zod = __webpack_require__(63442);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./components/providers/TelemetryProvider.tsx + 1 modules
var TelemetryProvider = __webpack_require__(10796);
;// ./lib/utils/redirect-guard.ts
/**
 * Redirect guard utility to prevent infinite redirect loops
 * during authentication flows
 */ class RedirectGuard {
    static{
        this.STORAGE_KEY = 'redirect_guard';
    }
    static{
        this.MAX_REDIRECTS = 3;
    }
    static{
        this.RESET_INTERVAL = 30000 // 30 seconds
        ;
    }
    static getRedirectCount() {
        if (true) return 0;
        try {
            const data = sessionStorage.getItem(this.STORAGE_KEY);
            if (!data) return 0;
            const { count, timestamp } = JSON.parse(data);
            const now = Date.now();
            // Reset counter if enough time has passed
            if (now - timestamp > this.RESET_INTERVAL) {
                this.resetCount();
                return 0;
            }
            return count || 0;
        } catch (error) {
            console.error('RedirectGuard: Error reading redirect count:', error);
            return 0;
        }
    }
    static setRedirectCount(count) {
        if (true) return;
        try {
            const data = {
                count,
                timestamp: Date.now()
            };
            sessionStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
        } catch (error) {
            console.error('RedirectGuard: Error setting redirect count:', error);
        }
    }
    static resetCount() {
        if (true) return;
        try {
            sessionStorage.removeItem(this.STORAGE_KEY);
        } catch (error) {
            console.error('RedirectGuard: Error resetting redirect count:', error);
        }
    }
    /**
   * Check if a redirect is allowed based on current redirect count
   * @param targetPath - The path we want to redirect to
   * @returns true if redirect is allowed, false if it should be blocked
   */ static canRedirect(targetPath) {
        const currentCount = this.getRedirectCount();
        if (currentCount >= this.MAX_REDIRECTS) {
            console.warn(`RedirectGuard: Blocking redirect to ${targetPath} - max redirects (${this.MAX_REDIRECTS}) reached`);
            return false;
        }
        return true;
    }
    /**
   * Increment the redirect counter when a redirect is about to happen
   * @param fromPath - Current path
   * @param toPath - Target path
   */ static recordRedirect(fromPath, toPath) {
        const currentCount = this.getRedirectCount();
        const newCount = currentCount + 1;
        console.log(`RedirectGuard: Recording redirect ${newCount}/${this.MAX_REDIRECTS} from ${fromPath} to ${toPath}`);
        this.setRedirectCount(newCount);
    }
    /**
   * Reset the redirect counter (useful after successful authentication)
   */ static reset() {
        console.log('RedirectGuard: Resetting redirect counter');
        this.resetCount();
    }
    /**
   * Check if we're potentially in a redirect loop between two pages
   * @param fromPath - Current path  
   * @param toPath - Target path
   * @returns true if this looks like a loop
   */ static isLoop(fromPath, toPath) {
        // Simple loop detection: if we're redirecting between /sign-in and /dashboard
        const isAuthLoop = fromPath.includes('/sign-in') && toPath.includes('/dashboard') || fromPath.includes('/dashboard') && toPath.includes('/sign-in');
        return isAuthLoop && this.getRedirectCount() > 0;
    }
}
/* harmony default export */ const redirect_guard = (RedirectGuard);

// EXTERNAL MODULE: ./node_modules/@radix-ui/react-slot/dist/index.mjs
var react_slot_dist = __webpack_require__(8730);
// EXTERNAL MODULE: ./lib/utils.ts + 1 modules
var utils = __webpack_require__(57048);
// EXTERNAL MODULE: ./components/ui/label.tsx
var label = __webpack_require__(39390);
;// ./components/ui/form.tsx
/* __next_internal_client_entry_do_not_use__ useFormField,Form,FormItem,FormLabel,FormControl,FormDescription,FormMessage,FormField auto */ 





const Form = index_esm/* FormProvider */.Op;
const FormFieldContext = /*#__PURE__*/ react.createContext({});
const FormField = ({ ...props })=>{
    return /*#__PURE__*/ _jsx(FormFieldContext.Provider, {
        value: {
            name: props.name
        },
        children: /*#__PURE__*/ _jsx(Controller, {
            ...props
        })
    });
};
const useFormField = ()=>{
    const fieldContext = react.useContext(FormFieldContext);
    const itemContext = react.useContext(FormItemContext);
    const { getFieldState } = (0,index_esm/* useFormContext */.xW)();
    const formState = (0,index_esm/* useFormState */.lN)({
        name: fieldContext.name
    });
    const fieldState = getFieldState(fieldContext.name, formState);
    if (!fieldContext) {
        throw new Error("useFormField should be used within <FormField>");
    }
    const { id } = itemContext;
    return {
        id,
        name: fieldContext.name,
        formItemId: `${id}-form-item`,
        formDescriptionId: `${id}-form-item-description`,
        formMessageId: `${id}-form-item-message`,
        ...fieldState
    };
};
const FormItemContext = /*#__PURE__*/ react.createContext({});
function FormItem({ className, ...props }) {
    const id = react.useId();
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(FormItemContext.Provider, {
        value: {
            id
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
            "data-slot": "form-item",
            className: (0,utils.cn)("grid gap-2", className),
            ...props
        })
    });
}
function FormLabel({ className, ...props }) {
    const { error, formItemId } = useFormField();
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(label/* Label */.J, {
        "data-slot": "form-label",
        "data-error": !!error,
        className: (0,utils.cn)("data-[error=true]:text-destructive", className),
        htmlFor: formItemId,
        ...props
    });
}
function FormControl({ ...props }) {
    const { error, formItemId, formDescriptionId, formMessageId } = useFormField();
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(react_slot_dist/* Slot */.DX, {
        "data-slot": "form-control",
        id: formItemId,
        "aria-describedby": !error ? `${formDescriptionId}` : `${formDescriptionId} ${formMessageId}`,
        "aria-invalid": !!error,
        ...props
    });
}
function FormDescription({ className, ...props }) {
    const { formDescriptionId } = useFormField();
    return /*#__PURE__*/ _jsx("p", {
        "data-slot": "form-description",
        id: formDescriptionId,
        className: cn("text-muted-foreground text-sm", className),
        ...props
    });
}
function FormMessage({ className, ...props }) {
    const { error, formMessageId } = useFormField();
    const body = error ? String(error?.message ?? "") : props.children;
    if (!body) {
        return null;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)("p", {
        "data-slot": "form-message",
        id: formMessageId,
        className: (0,utils.cn)("text-destructive text-sm", className),
        ...props,
        children: body
    });
}


// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(24934);
// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(68988);
;// ./components/FormField.tsx




const FormField_FormField = ({ control, name, label, placeholder, type = "text", "data-testid": testId })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(index_esm/* Controller */.xI, {
        control: control,
        name: name,
        render: ({ field })=>/*#__PURE__*/ (0,react_jsx_runtime.jsxs)(FormItem, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(FormLabel, {
                        className: "label",
                        children: label
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(FormControl, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(input/* Input */.p, {
                            className: "input",
                            type: type,
                            placeholder: placeholder,
                            "data-testid": testId,
                            ...field
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)(FormMessage, {})
                ]
            })
    });
};
/* harmony default export */ const components_FormField = (FormField_FormField);

// EXTERNAL MODULE: ./lib/firebase/auth.js
var auth = __webpack_require__(87870);
;// ./components/GoogleAuthButton.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





function GoogleAuthButton({ mode }) {
    const router = (0,navigation.useRouter)();
    const [isLoading, setIsLoading] = (0,react.useState)(false);
    const [authSuccess, setAuthSuccess] = (0,react.useState)(false);
    // Note: Redirect is now handled by middleware after successful authentication
    // The middleware will detect the session cookie and redirect authenticated users from /sign-in to /dashboard
    const handleGoogleAuth = async ()=>{
        if (isLoading) return; // Prevent multiple clicks
        setIsLoading(true);
        console.log(`Starting Google ${mode === 'signup' ? 'Sign Up' : 'Sign In'}...`);
        // Use the Firebase auth helper for better error handling
        try {
            console.log('🔐 Starting Google authentication using Firebase helper...');
            const { user, idToken } = await (0,auth/* authenticateWithGoogle */.Xe)();
            console.log('🔐 Firebase authentication successful:', {
                uid: user.uid,
                email: user.email,
                displayName: user.displayName,
                emailVerified: user.emailVerified
            });
            // Validate the Firebase ID token
            if (!(0,auth/* validateFirebaseIdToken */.KG)(idToken)) {
                throw new Error('Invalid Firebase ID token received');
            }
            console.log('🔐 Firebase ID token validated successfully');
            console.log(`🔐 Attempting ${mode} with Firebase ID token...`);
            if (!user.email) {
                const error = new Error("No email provided by Google");
                console.error(error);
                throw error;
            }
            // Determine endpoint based on mode
            const endpoint = mode === 'signup' ? '/api/auth/signup' : '/api/auth/signin';
            try {
                const authResponse = await fetch(endpoint, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        idToken,
                        name: user.displayName || user.email?.split('@')[0] || 'User',
                        email: user.email
                    })
                });
                console.log(`🔐 ${mode} response status:`, authResponse.status);
                if (!authResponse.ok) {
                    const errorText = await authResponse.text();
                    console.error(`🔐 ${mode} failed with status ${authResponse.status}:`, errorText);
                }
                if (authResponse.ok) {
                    const responseData = await authResponse.json();
                    console.log(`🚀 GoogleAuthButton: ${mode} API call successful!`, {
                        status: authResponse.status,
                        hasToken: !!responseData.token,
                        hasUser: !!responseData.user,
                        responseKeys: Object.keys(responseData)
                    });
                    // Store token in localStorage if provided
                    if (responseData.token) {
                        localStorage.setItem('auth_token', responseData.token);
                        console.log('🚀 Token stored in localStorage');
                    }
                    console.log('🚀 About to show success toast and trigger redirect...');
                    dist/* toast */.o.success(mode === 'signup' ? 'Account created successfully!' : 'Signed in successfully!');
                    // Authentication successful! Let the middleware handle the redirect
                    console.log('🚀 Authentication successful! Cookie set, page will refresh to trigger middleware redirect...');
                    // Just refresh the current page - the middleware will see the session cookie 
                    // and redirect authenticated users from /sign-in to /dashboard
                    setTimeout(()=>{
                        console.log('🚀 Refreshing page to allow middleware to handle redirect...');
                        window.location.reload();
                    }, 500);
                    console.log('🚀 GoogleAuthButton: Returning from successful auth handler');
                    return;
                }
                // Handle specific error cases
                const errorData = await authResponse.json().catch(()=>({}));
                if (mode === 'signup' && authResponse.status === 409) {
                    // User already exists, try signing in instead
                    console.log('User already exists, attempting sign in...');
                    const signInResponse = await fetch('/api/auth/signin', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            idToken
                        })
                    });
                    if (signInResponse.ok) {
                        const signInData = await signInResponse.json();
                        if (signInData.token) {
                            localStorage.setItem('auth_token', signInData.token);
                        }
                        console.log('GoogleAuthButton: Sign in after signup conflict successful');
                        dist/* toast */.o.success('Welcome back! Signed in successfully!');
                        // Let middleware handle redirect after successful fallback sign-in
                        setTimeout(()=>{
                            console.log('🚀 Refreshing page to allow middleware redirect after signup conflict resolution...');
                            window.location.reload();
                        }, 500);
                        return;
                    }
                }
                if (mode === 'signin' && authResponse.status === 401) {
                    // For sign-in, if user doesn't exist, suggest sign-up
                    console.log('User not found, suggesting sign up...');
                    dist/* toast */.o.error('Account not found. Please sign up first or try with a different Google account.');
                    return;
                }
                // Generic error handling
                const error = new Error(`Failed to ${mode}: ${errorData.error || 'Unknown error'}`);
                console.error(error);
                throw error;
            } catch (error) {
                console.error(`${mode} error:`, error);
                throw error;
            }
        } catch (error) {
            console.error(`Google ${mode} Error:`, error);
            dist/* toast */.o.error(`Failed to ${mode === 'signup' ? 'sign up' : 'sign in'} with Google`);
        } finally{
            setIsLoading(false);
        }
    };
    const buttonText = 'Google';
    const loadingText = mode === 'signup' ? 'Creating account...' : 'Signing in...';
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
        variant: "outline",
        type: "button",
        className: "w-full flex items-center justify-center gap-3 !bg-dark-200 hover:!bg-dark-200/80 !text-light-100 !border-white/20 hover:!border-white/30 !rounded-full !min-h-12",
        onClick: handleGoogleAuth,
        disabled: isLoading,
        children: isLoading ? /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                    className: "animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-gray-400"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                    children: loadingText
                })
            ]
        }) : /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("svg", {
                    width: "20",
                    height: "20",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
                            d: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z",
                            fill: "#4285F4"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
                            d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.28-1.93-6.14-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",
                            fill: "#34A853"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
                            d: "M5.86 14.09c-.26-.77-.41-1.6-.41-2.45 0-.85.15-1.68.41-2.45V6.35H2.18C1.42 7.8 1 9.39 1 11s.42 3.2 1.18 4.65l3.68-2.84.01.01z",
                            fill: "#FBBC05"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
                            d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 6.35l3.68 2.84c.86-2.6 3.28-4.53 6.14-4.53z",
                            fill: "#EA4335"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("path", {
                            d: "M1 1h22v22H1z",
                            fill: "none"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                    children: buttonText
                })
            ]
        })
    });
}

;// ./components/AuthForm.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 














const authFormSchema = (type)=>{
    return lib.z.object({
        name: type === "sign-up" ? lib.z.string().min(3) : lib.z.string().optional(),
        email: lib.z.string().email(),
        password: lib.z.string().min(3)
    });
};
const AuthForm = ({ type })=>{
    const router = (0,navigation.useRouter)();
    const [signInSuccess, setSignInSuccess] = (0,react.useState)(false);
    const { trackFormSubmission, trackUserAction, trackError } = (0,TelemetryProvider/* useTelemetry */.J)();
    const formSchema = authFormSchema(type);
    const form = (0,index_esm/* useForm */.mN)({
        resolver: (0,zod/* zodResolver */.u)(formSchema),
        defaultValues: {
            name: "",
            email: "",
            password: ""
        }
    });
    const onSubmit = async (data)=>{
        const startTime = Date.now();
        let success = false;
        try {
            if (type === "sign-up") {
                const { name, email, password } = data;
                // Call unified auth signup endpoint
                const response = await fetch('/api/auth/signup', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        name,
                        email,
                        password
                    })
                });
                if (response.ok) {
                    success = true;
                    dist/* toast */.o.success("Account created successfully. You can now sign in.");
                    // Track successful sign up
                    await trackUserAction('signup', 'auth', {
                        method: 'email',
                        hasName: (!!name).toString()
                    });
                    router.push("/sign-in");
                } else {
                    const errorData = await response.json().catch(()=>({}));
                    const errorMessage = errorData.error || 'Failed to create account. Please try again.';
                    dist/* toast */.o.error(errorMessage);
                    // Track failed sign up
                    await trackFormSubmission('signup_form', false, {
                        errorMessage,
                        duration: (Date.now() - startTime).toString()
                    });
                    return;
                }
            } else {
                const { email, password } = data;
                // Call unified auth signin endpoint
                const response = await fetch('/api/auth/signin', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email,
                        password
                    })
                });
                if (response.ok) {
                    const result = await response.json();
                    // Store auth token if provided
                    if (result.token) {
                        localStorage.setItem('auth_token', result.token);
                    }
                    console.log('AuthForm: Sign in successful, redirecting to dashboard');
                    success = true;
                    dist/* toast */.o.success("Signed in successfully.");
                    // Track successful sign in
                    await trackUserAction('signin', 'auth', {
                        method: 'email'
                    });
                    setSignInSuccess(true);
                } else {
                    const errorData = await response.json().catch(()=>({}));
                    const errorMessage = errorData.error || 'Failed to sign in. Please check your credentials and try again.';
                    dist/* toast */.o.error(errorMessage);
                    // Track failed sign in
                    await trackFormSubmission('signin_form', false, {
                        errorMessage,
                        duration: (Date.now() - startTime).toString()
                    });
                }
            }
        } catch (error) {
            console.log(error);
            const errorMessage = `There was an error: ${error}`;
            dist/* toast */.o.error(errorMessage);
            // Track error
            await trackError(error instanceof Error ? error : new Error(errorMessage), {
                formType: type,
                action: type === 'sign-up' ? 'signup' : 'signin',
                duration: (Date.now() - startTime).toString()
            });
        } finally{
            // Track form submission if not already tracked
            if (success) {
                await trackFormSubmission(type === 'sign-up' ? 'signup_form' : 'signin_form', true, {
                    duration: (Date.now() - startTime).toString()
                });
            }
        }
    };
    // Handle redirect on successful sign-in
    (0,react.useEffect)(()=>{
        if (signInSuccess) {
            console.log('AuthForm: Successful sign-in, preparing redirect to /dashboard');
            const currentPath =  false ? 0 : '/sign-in';
            const targetPath = '/dashboard';
            // Check if redirect is allowed
            if (!redirect_guard.canRedirect(targetPath)) {
                console.error('AuthForm: Redirect blocked by RedirectGuard - potential loop detected');
                dist/* toast */.o.error('Authentication successful, but unable to redirect. Please navigate to dashboard manually.');
                return;
            }
            // Record the redirect attempt
            redirect_guard.recordRedirect(currentPath, targetPath);
            // Add a small delay to ensure cookie propagation
            const redirectTimer = setTimeout(()=>{
                console.log('AuthForm: Executing redirect to /dashboard');
                // Use window.location.href instead of router to ensure full page navigation
                // This prevents router-based issues and ensures fresh authentication state
                if (false) {}
            }, 500); // Increased delay for better cookie propagation
            // Cleanup timer if component unmounts
            return ()=>clearTimeout(redirectTimer);
        }
    }, [
        signInSuccess
    ]);
    const isSignIn = type === "sign-in";
    return /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
        className: "flex flex-col gap-6 bg-gray-900/60 backdrop-blur-md rounded-2xl min-h-full py-14 px-10 border border-white/20 lg:min-w-[566px] w-full",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                className: "flex flex-col items-center gap-4",
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                    className: "flex flex-row gap-2 justify-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(api_image["default"], {
                            src: "/logo.svg",
                            alt: "logo",
                            height: 32,
                            width: 38
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h2", {
                            className: "text-white",
                            children: "PrepBettr"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)("h3", {
                className: "text-center text-white",
                children: "Practice job interviews with AI"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(Form, {
                ...form,
                children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("form", {
                    onSubmit: form.handleSubmit(onSubmit),
                    className: "w-full space-y-6 mt-4 form",
                    children: [
                        !isSignIn && /*#__PURE__*/ (0,react_jsx_runtime.jsx)(components_FormField, {
                            control: form.control,
                            name: "name",
                            label: "Name",
                            placeholder: "Your Name",
                            type: "text"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(components_FormField, {
                            control: form.control,
                            name: "email",
                            label: "Email",
                            placeholder: "Your email address",
                            type: "email",
                            "data-testid": "email-input"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(components_FormField, {
                            control: form.control,
                            name: "password",
                            label: "Password",
                            placeholder: "Enter your password",
                            type: "password",
                            "data-testid": "password-input"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime.jsx)(ui_button/* Button */.$, {
                            className: "btn w-full",
                            type: "submit",
                            "data-testid": isSignIn ? "submit-login" : "submit-signup",
                            children: isSignIn ? "Sign In" : "Create an Account"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                        className: "absolute inset-0 flex items-center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                            className: "w-full border-t"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)("div", {
                        className: "relative flex justify-center text-xs uppercase",
                        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)("span", {
                            className: "bg-gray-900/80 px-2 text-white",
                            children: "Or continue with"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(GoogleAuthButton, {
                mode: isSignIn ? 'signin' : 'signup'
            }),
            /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("p", {
                className: "text-center",
                children: [
                    isSignIn ? "No account yet?" : "Have an account already?",
                    /*#__PURE__*/ (0,react_jsx_runtime.jsx)((link_default()), {
                        href: !isSignIn ? "/sign-in" : "/sign-up",
                        className: "font-bold text-user-primary ml-1",
                        children: !isSignIn ? "Sign In" : "Sign Up"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_AuthForm = (AuthForm);


/***/ }),

/***/ 24934:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ Button)
/* harmony export */ });
/* unused harmony export buttonVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8730);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24224);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);





const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__/* .cva */ .F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none", {
    variants: {
        variant: {
            default: "bg-primary-200 text-dark-100 shadow-xs hover:bg-primary-200/90 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            destructive: "bg-destructive-100 text-white shadow-xs hover:bg-destructive-200 focus-visible:ring-destructive-100/50 focus-visible:ring-[3px] disabled:bg-gray-700 disabled:text-gray-400",
            outline: "border border-gray-600 bg-gray-800 text-white shadow-xs hover:bg-gray-700 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800/50 disabled:text-gray-500 disabled:border-gray-700",
            secondary: "bg-gray-700 text-white shadow-xs hover:bg-gray-600 focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:bg-gray-800 disabled:text-gray-500",
            ghost: "text-white hover:bg-gray-800 hover:text-white focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500",
            link: "text-primary-200 underline-offset-4 hover:underline focus-visible:ring-primary-200/50 focus-visible:ring-[3px] disabled:text-gray-500"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_4__/* .Slot */ .DX : "button";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Comp, {
        "data-slot": "button",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    });
}



/***/ }),

/***/ 27470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37413);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const AuthLayout = ({ children })=>{
    // Authentication redirect is now handled by middleware
    // This layout just provides the structure for auth pages
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "min-h-screen relative",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "min-h-screen flex items-center justify-center p-4 relative z-10 overflow-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "w-full max-w-lg",
                children: children
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthLayout);


/***/ }),

/***/ 39390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ Label)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78148);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);
/* __next_internal_client_entry_do_not_use__ Label auto */ 



function Label({ className, ...props }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_3__/* .Root */ .b, {
        "data-slot": "label",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className),
        ...props
    });
}



/***/ }),

/***/ 46055:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(31658);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (props) => {
    const imageData = {"type":"image/x-icon","sizes":"256x256"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", await props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 64812:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12977));


/***/ }),

/***/ 68988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);



function Input({ className, type, ...props }) {
    const isDisabled = props.disabled;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
        type: type,
        "data-slot": "input",
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)(// Base styles for dark theme
        "bg-gray-800 text-white placeholder-gray-400 border-gray-600", "flex h-9 w-full min-w-0 rounded-md border px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none", "md:text-sm", // File input specific styles
        "file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-white", // Selection styles
        "selection:bg-primary-200 selection:text-dark-100", // Focus states with brand color (primary-200 from globals.css)
        "focus-visible:border-primary-200 focus-visible:ring-primary-200/50 focus-visible:ring-[3px]", // Disabled states with proper contrast
        isDisabled && "disabled:bg-gray-800/50 disabled:text-gray-500 disabled:placeholder-gray-500 disabled:cursor-not-allowed disabled:opacity-75", // Validation error states
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className),
        ...props
    });
}



/***/ }),

/***/ 70892:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 17989));


/***/ }),

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 82897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   db: () => (/* binding */ db),
/* harmony export */   hJ: () => (/* binding */ googleProvider),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(67989);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91042);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75535);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  false ? 0 : null;
    const windowProjectId =  false ? 0 : null;
    const windowAuthDomain =  false ? 0 : null;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || `${finalProjectId}.firebaseapp.com`;
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (true) {
        console.log('🔥 Firebase initialization skipped on server side');
        return;
    }
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = getApps();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = initializeApp(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = getAuth(app);
        db = getFirestore(app);
        // Initialize Google Auth Provider
        googleProvider = new GoogleAuthProvider();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (false) {}
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (false) {}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});


/***/ }),

/***/ 87870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   KG: () => (/* binding */ validateFirebaseIdToken),
/* harmony export */   Xe: () => (/* binding */ authenticateWithGoogle),
/* harmony export */   getCurrentUserIdToken: () => (/* binding */ getCurrentUserIdToken)
/* harmony export */ });
/* unused harmony export signOutFromFirebase */
/* harmony import */ var _firebase_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(82897);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91042);
/**
 * Firebase Authentication Helper
 * 
 * Provides proper Firebase Google authentication flow
 * Ensures Firebase ID tokens are generated correctly
 */ 

/**
 * Authenticate with Google using Firebase
 * Returns Firebase ID token (not Google OAuth token)
 */ async function authenticateWithGoogle() {
    if (!_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2 || !_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .googleProvider */ .hJ) {
        throw new Error('Firebase Auth not initialized');
    }
    try {
        console.log('🔐 Starting Firebase Google authentication...');
        // Sign in with Google using Firebase
        const result = await (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .signInWithPopup */ .df)(_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2, _firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .googleProvider */ .hJ);
        const user = result.user;
        if (!user) {
            throw new Error('No user returned from Google authentication');
        }
        console.log('🔐 Google authentication successful, getting Firebase ID token...');
        // Get Firebase ID token (this is crucial - not Google OAuth token)
        const idToken = await (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .getIdToken */ .p9)(user, true); // Force refresh to ensure fresh token
        console.log('🔐 Firebase ID token obtained successfully');
        console.log('🔐 Token preview:', idToken.substring(0, 50) + '...');
        // Validate token format (Firebase ID tokens are JWT)
        if (!idToken.includes('.')) {
            throw new Error('Invalid Firebase ID token format - not a JWT');
        }
        return {
            user: {
                uid: user.uid,
                email: user.email,
                displayName: user.displayName,
                photoURL: user.photoURL,
                emailVerified: user.emailVerified
            },
            idToken
        };
    } catch (error) {
        console.error('🔐 Firebase Google authentication failed:', error);
        throw error;
    }
}
/**
 * Sign out from Firebase
 */ async function signOutFromFirebase() {
    if (!auth) {
        throw new Error('Firebase Auth not initialized');
    }
    try {
        await auth.signOut();
        console.log('🔐 Firebase sign out successful');
    } catch (error) {
        console.error('🔐 Firebase sign out failed:', error);
        throw error;
    }
}
/**
 * Get current Firebase user's ID token
 */ async function getCurrentUserIdToken(forceRefresh = false) {
    if (!_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2?.currentUser) {
        throw new Error('No Firebase user signed in');
    }
    try {
        const idToken = await (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .getIdToken */ .p9)(_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2.currentUser, forceRefresh);
        console.log('🔐 Current user ID token obtained');
        return idToken;
    } catch (error) {
        console.error('🔐 Failed to get current user ID token:', error);
        throw error;
    }
}
/**
 * Validate Firebase ID token format
 */ function validateFirebaseIdToken(token) {
    if (!token || typeof token !== 'string') {
        return false;
    }
    // Firebase ID tokens are JWTs with 3 parts separated by dots
    const parts = token.split('.');
    if (parts.length !== 3) {
        return false;
    }
    try {
        // Try to decode the payload (second part)
        const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
        // Firebase ID tokens should have these claims
        return payload.iss && payload.aud && payload.exp && payload.iat && payload.sub && payload.iss.includes('securetoken.google.com');
    } catch  {
        return false;
    }
}


/***/ }),

/***/ 96487:
/***/ (() => {



/***/ })

};
;