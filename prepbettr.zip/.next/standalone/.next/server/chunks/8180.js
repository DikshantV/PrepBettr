"use strict";
exports.id = 8180;
exports.ids = [8180];
exports.modules = {

/***/ 53076:
/***/ ((__unused_webpack_module, exports) => {

var __webpack_unused_export__;

// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
__webpack_unused_export__ = ({ value: true });
exports.w = void 0;
/**
 * Holds the singleton operationRequestMap, to be shared across CJS and ESM imports.
 */
exports.w = {
    operationRequestMap: new WeakMap(),
};
//# sourceMappingURL=state-cjs.cjs.map

/***/ }),

/***/ 98180:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  KL: () => (/* reexport */ esm/* AzureKeyCredential */.KL),
  Pz: () => (/* reexport */ DocumentAnalysisClient)
});

// UNUSED EXPORTS: DocumentModelAdministrationClient, DocumentModelBuildMode, FormRecognizerFeature, KnownDocumentBarcodeKind, KnownDocumentBuildMode, KnownDocumentFieldType, KnownDocumentFormulaKind, KnownDocumentSignatureType, KnownDocumentTableCellKind, KnownFontStyle, KnownFontWeight, KnownFormRecognizerAudience, KnownLengthUnit, KnownOperationKind, KnownParagraphRole, KnownSelectionMarkState, StringIndexType, createModelFromSchema

// NAMESPACE OBJECT: ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/models/mappers.js
var mappers_namespaceObject = {};
__webpack_require__.r(mappers_namespaceObject);
__webpack_require__.d(mappers_namespaceObject, {
  AddressValue: () => (AddressValue),
  AnalyzeDocumentRequest: () => (AnalyzeDocumentRequest),
  AnalyzeResult: () => (AnalyzeResult),
  AnalyzeResultOperation: () => (AnalyzeResultOperation),
  AuthorizeCopyRequest: () => (AuthorizeCopyRequest),
  AzureBlobContentSource: () => (AzureBlobContentSource),
  AzureBlobFileListContentSource: () => (AzureBlobFileListContentSource),
  BoundingRegion: () => (BoundingRegion),
  BuildDocumentClassifierRequest: () => (BuildDocumentClassifierRequest),
  BuildDocumentModelRequest: () => (BuildDocumentModelRequest),
  ClassifierDocumentTypeDetails: () => (ClassifierDocumentTypeDetails),
  ClassifyDocumentRequest: () => (ClassifyDocumentRequest),
  ComponentDocumentModelDetails: () => (ComponentDocumentModelDetails),
  ComposeDocumentModelRequest: () => (ComposeDocumentModelRequest),
  CopyAuthorization: () => (CopyAuthorization),
  CurrencyValue: () => (CurrencyValue),
  CustomDocumentModelsDetails: () => (CustomDocumentModelsDetails),
  Document: () => (Document),
  DocumentBarcode: () => (DocumentBarcode),
  DocumentClassifierBuildOperationDetails: () => (DocumentClassifierBuildOperationDetails),
  DocumentClassifierDetails: () => (DocumentClassifierDetails),
  DocumentClassifiersBuildClassifierHeaders: () => (DocumentClassifiersBuildClassifierHeaders),
  DocumentClassifiersClassifyDocumentHeaders: () => (DocumentClassifiersClassifyDocumentHeaders),
  DocumentField: () => (DocumentField),
  DocumentFieldSchema: () => (DocumentFieldSchema),
  DocumentFormula: () => (DocumentFormula),
  DocumentKeyValueElement: () => (DocumentKeyValueElement),
  DocumentKeyValuePair: () => (DocumentKeyValuePair),
  DocumentLanguage: () => (DocumentLanguage),
  DocumentLine: () => (DocumentLine),
  DocumentModelBuildOperationDetails: () => (DocumentModelBuildOperationDetails),
  DocumentModelComposeOperationDetails: () => (DocumentModelComposeOperationDetails),
  DocumentModelCopyToOperationDetails: () => (DocumentModelCopyToOperationDetails),
  DocumentModelDetails: () => (DocumentModelDetails),
  DocumentModelSummary: () => (DocumentModelSummary),
  DocumentModelsAnalyzeDocumentHeaders: () => (DocumentModelsAnalyzeDocumentHeaders),
  DocumentModelsBuildModelHeaders: () => (DocumentModelsBuildModelHeaders),
  DocumentModelsComposeModelHeaders: () => (DocumentModelsComposeModelHeaders),
  DocumentModelsCopyModelToHeaders: () => (DocumentModelsCopyModelToHeaders),
  DocumentPage: () => (DocumentPage),
  DocumentParagraph: () => (DocumentParagraph),
  DocumentSelectionMark: () => (DocumentSelectionMark),
  DocumentSpan: () => (DocumentSpan),
  DocumentStyle: () => (DocumentStyle),
  DocumentTable: () => (DocumentTable),
  DocumentTableCell: () => (DocumentTableCell),
  DocumentTypeDetails: () => (DocumentTypeDetails),
  DocumentWord: () => (DocumentWord),
  ErrorModel: () => (ErrorModel),
  ErrorResponse: () => (ErrorResponse),
  GetDocumentClassifiersResponse: () => (GetDocumentClassifiersResponse),
  GetDocumentModelsResponse: () => (GetDocumentModelsResponse),
  GetOperationsResponse: () => (GetOperationsResponse),
  InnerError: () => (InnerError),
  OperationDetails: () => (OperationDetails),
  OperationSummary: () => (OperationSummary),
  QuotaDetails: () => (QuotaDetails),
  ResourceDetails: () => (ResourceDetails),
  discriminators: () => (discriminators)
});

// EXTERNAL MODULE: ./node_modules/@azure/core-auth/dist/esm/index.js + 5 modules
var esm = __webpack_require__(47837);
// EXTERNAL MODULE: ./node_modules/@azure/core-tracing/dist/esm/index.js + 4 modules
var dist_esm = __webpack_require__(61724);
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/constants.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Defines the known cloud audiences for Form Recognizer.
 *
 * To authenticate with Entra Id (using a `TokenCredential`) in a [Sovereign Cloud](https://learn.microsoft.com/entra/identity-platform/authentication-national-cloud)
 * environment, provide the appropriate value below as the `audience` option when creating a
 * `DocumentAnalysisClient` or `DocumentModelAdministrationClient`.
 *
 * The default value is suitable for Form Recognizer resources created in the Azure Public Cloud, so this value
 * is only required to use Form Recognizer in a different cloud environment.
 */
var KnownFormRecognizerAudience;
(function (KnownFormRecognizerAudience) {
    /** Azure China */
    KnownFormRecognizerAudience["AzureChina"] = "https://cognitiveservices.azure.cn";
    /** Azure Government */
    KnownFormRecognizerAudience["AzureGovernment"] = "https://cognitiveservices.azure.us";
    /** Azure Public Cloud */
    KnownFormRecognizerAudience["AzurePublicCloud"] = "https://cognitiveservices.azure.com";
})(KnownFormRecognizerAudience || (KnownFormRecognizerAudience = {}));
/**
 * The default Entra Id permissions scope for Cognitive Services.
 * @internal
 */
const DEFAULT_COGNITIVE_SCOPE = `${KnownFormRecognizerAudience.AzurePublicCloud}/.default`;
/**
 * @internal
 */
const constants_SDK_VERSION = "5.1.0";
const FORM_RECOGNIZER_API_VERSION = "2023-07-31";
//# sourceMappingURL=constants.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/models/mappers.js
/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 *
 * Code generated by Microsoft (R) AutoRest Code Generator.
 * Changes may cause incorrect behavior and will be lost if the code is regenerated.
 */
const AnalyzeDocumentRequest = {
    type: {
        name: "Composite",
        className: "AnalyzeDocumentRequest",
        modelProperties: {
            urlSource: {
                serializedName: "urlSource",
                type: {
                    name: "String"
                }
            },
            base64Source: {
                serializedName: "base64Source",
                type: {
                    name: "ByteArray"
                }
            }
        }
    }
};
const ErrorResponse = {
    type: {
        name: "Composite",
        className: "ErrorResponse",
        modelProperties: {
            error: {
                serializedName: "error",
                type: {
                    name: "Composite",
                    className: "ErrorModel"
                }
            }
        }
    }
};
const ErrorModel = {
    type: {
        name: "Composite",
        className: "ErrorModel",
        modelProperties: {
            code: {
                serializedName: "code",
                required: true,
                type: {
                    name: "String"
                }
            },
            message: {
                serializedName: "message",
                required: true,
                type: {
                    name: "String"
                }
            },
            target: {
                serializedName: "target",
                type: {
                    name: "String"
                }
            },
            details: {
                serializedName: "details",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "ErrorModel"
                        }
                    }
                }
            },
            innererror: {
                serializedName: "innererror",
                type: {
                    name: "Composite",
                    className: "InnerError"
                }
            }
        }
    }
};
const InnerError = {
    type: {
        name: "Composite",
        className: "InnerError",
        modelProperties: {
            code: {
                serializedName: "code",
                required: true,
                type: {
                    name: "String"
                }
            },
            message: {
                serializedName: "message",
                type: {
                    name: "String"
                }
            },
            innererror: {
                serializedName: "innererror",
                type: {
                    name: "Composite",
                    className: "InnerError"
                }
            }
        }
    }
};
const AnalyzeResultOperation = {
    type: {
        name: "Composite",
        className: "AnalyzeResultOperation",
        modelProperties: {
            status: {
                serializedName: "status",
                required: true,
                type: {
                    name: "Enum",
                    allowedValues: ["notStarted", "running", "failed", "succeeded"]
                }
            },
            createdOn: {
                serializedName: "createdDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            },
            lastUpdatedOn: {
                serializedName: "lastUpdatedDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            },
            error: {
                serializedName: "error",
                type: {
                    name: "Composite",
                    className: "ErrorModel"
                }
            },
            analyzeResult: {
                serializedName: "analyzeResult",
                type: {
                    name: "Composite",
                    className: "AnalyzeResult"
                }
            }
        }
    }
};
const AnalyzeResult = {
    type: {
        name: "Composite",
        className: "AnalyzeResult",
        modelProperties: {
            apiVersion: {
                serializedName: "apiVersion",
                required: true,
                type: {
                    name: "String"
                }
            },
            modelId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "modelId",
                required: true,
                type: {
                    name: "String"
                }
            },
            stringIndexType: {
                serializedName: "stringIndexType",
                required: true,
                type: {
                    name: "String"
                }
            },
            content: {
                serializedName: "content",
                required: true,
                type: {
                    name: "String"
                }
            },
            pages: {
                serializedName: "pages",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentPage"
                        }
                    }
                }
            },
            paragraphs: {
                serializedName: "paragraphs",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentParagraph"
                        }
                    }
                }
            },
            tables: {
                serializedName: "tables",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentTable"
                        }
                    }
                }
            },
            keyValuePairs: {
                serializedName: "keyValuePairs",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentKeyValuePair"
                        }
                    }
                }
            },
            styles: {
                serializedName: "styles",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentStyle"
                        }
                    }
                }
            },
            languages: {
                serializedName: "languages",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentLanguage"
                        }
                    }
                }
            },
            documents: {
                serializedName: "documents",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "Document"
                        }
                    }
                }
            }
        }
    }
};
const DocumentPage = {
    type: {
        name: "Composite",
        className: "DocumentPage",
        modelProperties: {
            pageNumber: {
                constraints: {
                    InclusiveMinimum: 1
                },
                serializedName: "pageNumber",
                required: true,
                type: {
                    name: "Number"
                }
            },
            angle: {
                constraints: {
                    InclusiveMaximum: 180,
                    ExclusiveMinimum: -180
                },
                serializedName: "angle",
                type: {
                    name: "Number"
                }
            },
            width: {
                constraints: {
                    InclusiveMinimum: 0
                },
                serializedName: "width",
                type: {
                    name: "Number"
                }
            },
            height: {
                constraints: {
                    InclusiveMinimum: 0
                },
                serializedName: "height",
                type: {
                    name: "Number"
                }
            },
            unit: {
                serializedName: "unit",
                type: {
                    name: "String"
                }
            },
            spans: {
                serializedName: "spans",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            },
            words: {
                serializedName: "words",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentWord"
                        }
                    }
                }
            },
            selectionMarks: {
                serializedName: "selectionMarks",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSelectionMark"
                        }
                    }
                }
            },
            lines: {
                serializedName: "lines",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentLine"
                        }
                    }
                }
            },
            barcodes: {
                serializedName: "barcodes",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentBarcode"
                        }
                    }
                }
            },
            formulas: {
                serializedName: "formulas",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentFormula"
                        }
                    }
                }
            }
        }
    }
};
const DocumentSpan = {
    type: {
        name: "Composite",
        className: "DocumentSpan",
        modelProperties: {
            offset: {
                constraints: {
                    InclusiveMinimum: 0
                },
                serializedName: "offset",
                required: true,
                type: {
                    name: "Number"
                }
            },
            length: {
                constraints: {
                    InclusiveMinimum: 0
                },
                serializedName: "length",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const DocumentWord = {
    type: {
        name: "Composite",
        className: "DocumentWord",
        modelProperties: {
            content: {
                serializedName: "content",
                required: true,
                type: {
                    name: "String"
                }
            },
            polygon: {
                serializedName: "polygon",
                type: {
                    name: "Sequence",
                    element: {
                        constraints: {
                            InclusiveMinimum: 0
                        },
                        type: {
                            name: "Number"
                        }
                    }
                }
            },
            span: {
                serializedName: "span",
                type: {
                    name: "Composite",
                    className: "DocumentSpan"
                }
            },
            confidence: {
                constraints: {
                    InclusiveMaximum: 1,
                    InclusiveMinimum: 0
                },
                serializedName: "confidence",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const DocumentSelectionMark = {
    type: {
        name: "Composite",
        className: "DocumentSelectionMark",
        modelProperties: {
            state: {
                serializedName: "state",
                required: true,
                type: {
                    name: "String"
                }
            },
            polygon: {
                serializedName: "polygon",
                type: {
                    name: "Sequence",
                    element: {
                        constraints: {
                            InclusiveMinimum: 0
                        },
                        type: {
                            name: "Number"
                        }
                    }
                }
            },
            span: {
                serializedName: "span",
                type: {
                    name: "Composite",
                    className: "DocumentSpan"
                }
            },
            confidence: {
                constraints: {
                    InclusiveMaximum: 1,
                    InclusiveMinimum: 0
                },
                serializedName: "confidence",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const DocumentLine = {
    type: {
        name: "Composite",
        className: "DocumentLine",
        modelProperties: {
            content: {
                serializedName: "content",
                required: true,
                type: {
                    name: "String"
                }
            },
            polygon: {
                serializedName: "polygon",
                type: {
                    name: "Sequence",
                    element: {
                        constraints: {
                            InclusiveMinimum: 0
                        },
                        type: {
                            name: "Number"
                        }
                    }
                }
            },
            spans: {
                serializedName: "spans",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            }
        }
    }
};
const DocumentBarcode = {
    type: {
        name: "Composite",
        className: "DocumentBarcode",
        modelProperties: {
            kind: {
                serializedName: "kind",
                required: true,
                type: {
                    name: "String"
                }
            },
            value: {
                serializedName: "value",
                required: true,
                type: {
                    name: "String"
                }
            },
            polygon: {
                serializedName: "polygon",
                type: {
                    name: "Sequence",
                    element: {
                        constraints: {
                            InclusiveMinimum: 0
                        },
                        type: {
                            name: "Number"
                        }
                    }
                }
            },
            span: {
                serializedName: "span",
                type: {
                    name: "Composite",
                    className: "DocumentSpan"
                }
            },
            confidence: {
                constraints: {
                    InclusiveMaximum: 1,
                    InclusiveMinimum: 0
                },
                serializedName: "confidence",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const DocumentFormula = {
    type: {
        name: "Composite",
        className: "DocumentFormula",
        modelProperties: {
            kind: {
                serializedName: "kind",
                required: true,
                type: {
                    name: "String"
                }
            },
            value: {
                serializedName: "value",
                required: true,
                type: {
                    name: "String"
                }
            },
            polygon: {
                serializedName: "polygon",
                type: {
                    name: "Sequence",
                    element: {
                        constraints: {
                            InclusiveMinimum: 0
                        },
                        type: {
                            name: "Number"
                        }
                    }
                }
            },
            span: {
                serializedName: "span",
                type: {
                    name: "Composite",
                    className: "DocumentSpan"
                }
            },
            confidence: {
                constraints: {
                    InclusiveMaximum: 1,
                    InclusiveMinimum: 0
                },
                serializedName: "confidence",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const DocumentParagraph = {
    type: {
        name: "Composite",
        className: "DocumentParagraph",
        modelProperties: {
            role: {
                serializedName: "role",
                type: {
                    name: "String"
                }
            },
            content: {
                serializedName: "content",
                required: true,
                type: {
                    name: "String"
                }
            },
            boundingRegions: {
                serializedName: "boundingRegions",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "BoundingRegion"
                        }
                    }
                }
            },
            spans: {
                serializedName: "spans",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            }
        }
    }
};
const BoundingRegion = {
    type: {
        name: "Composite",
        className: "BoundingRegion",
        modelProperties: {
            pageNumber: {
                constraints: {
                    InclusiveMinimum: 1
                },
                serializedName: "pageNumber",
                required: true,
                type: {
                    name: "Number"
                }
            },
            polygon: {
                serializedName: "polygon",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        constraints: {
                            InclusiveMinimum: 0
                        },
                        type: {
                            name: "Number"
                        }
                    }
                }
            }
        }
    }
};
const DocumentTable = {
    type: {
        name: "Composite",
        className: "DocumentTable",
        modelProperties: {
            rowCount: {
                constraints: {
                    InclusiveMinimum: 1
                },
                serializedName: "rowCount",
                required: true,
                type: {
                    name: "Number"
                }
            },
            columnCount: {
                constraints: {
                    InclusiveMinimum: 1
                },
                serializedName: "columnCount",
                required: true,
                type: {
                    name: "Number"
                }
            },
            cells: {
                serializedName: "cells",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentTableCell"
                        }
                    }
                }
            },
            boundingRegions: {
                serializedName: "boundingRegions",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "BoundingRegion"
                        }
                    }
                }
            },
            spans: {
                serializedName: "spans",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            }
        }
    }
};
const DocumentTableCell = {
    type: {
        name: "Composite",
        className: "DocumentTableCell",
        modelProperties: {
            kind: {
                defaultValue: "content",
                serializedName: "kind",
                type: {
                    name: "String"
                }
            },
            rowIndex: {
                serializedName: "rowIndex",
                required: true,
                type: {
                    name: "Number"
                }
            },
            columnIndex: {
                serializedName: "columnIndex",
                required: true,
                type: {
                    name: "Number"
                }
            },
            rowSpan: {
                defaultValue: 1,
                constraints: {
                    InclusiveMinimum: 1
                },
                serializedName: "rowSpan",
                type: {
                    name: "Number"
                }
            },
            columnSpan: {
                defaultValue: 1,
                constraints: {
                    InclusiveMinimum: 1
                },
                serializedName: "columnSpan",
                type: {
                    name: "Number"
                }
            },
            content: {
                serializedName: "content",
                required: true,
                type: {
                    name: "String"
                }
            },
            boundingRegions: {
                serializedName: "boundingRegions",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "BoundingRegion"
                        }
                    }
                }
            },
            spans: {
                serializedName: "spans",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            }
        }
    }
};
const DocumentKeyValuePair = {
    type: {
        name: "Composite",
        className: "DocumentKeyValuePair",
        modelProperties: {
            key: {
                serializedName: "key",
                type: {
                    name: "Composite",
                    className: "DocumentKeyValueElement"
                }
            },
            value: {
                serializedName: "value",
                type: {
                    name: "Composite",
                    className: "DocumentKeyValueElement"
                }
            },
            confidence: {
                constraints: {
                    InclusiveMaximum: 1,
                    InclusiveMinimum: 0
                },
                serializedName: "confidence",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const DocumentKeyValueElement = {
    type: {
        name: "Composite",
        className: "DocumentKeyValueElement",
        modelProperties: {
            content: {
                serializedName: "content",
                required: true,
                type: {
                    name: "String"
                }
            },
            boundingRegions: {
                serializedName: "boundingRegions",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "BoundingRegion"
                        }
                    }
                }
            },
            spans: {
                serializedName: "spans",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            }
        }
    }
};
const DocumentStyle = {
    type: {
        name: "Composite",
        className: "DocumentStyle",
        modelProperties: {
            isHandwritten: {
                serializedName: "isHandwritten",
                type: {
                    name: "Boolean"
                }
            },
            similarFontFamily: {
                serializedName: "similarFontFamily",
                type: {
                    name: "String"
                }
            },
            fontStyle: {
                serializedName: "fontStyle",
                type: {
                    name: "String"
                }
            },
            fontWeight: {
                serializedName: "fontWeight",
                type: {
                    name: "String"
                }
            },
            color: {
                constraints: {
                    Pattern: new RegExp("^#[0-9a-f]{6}$")
                },
                serializedName: "color",
                type: {
                    name: "String"
                }
            },
            backgroundColor: {
                constraints: {
                    Pattern: new RegExp("^#[0-9a-f]{6}$")
                },
                serializedName: "backgroundColor",
                type: {
                    name: "String"
                }
            },
            spans: {
                serializedName: "spans",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            },
            confidence: {
                constraints: {
                    InclusiveMaximum: 1,
                    InclusiveMinimum: 0
                },
                serializedName: "confidence",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const DocumentLanguage = {
    type: {
        name: "Composite",
        className: "DocumentLanguage",
        modelProperties: {
            locale: {
                serializedName: "locale",
                required: true,
                type: {
                    name: "String"
                }
            },
            spans: {
                serializedName: "spans",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            },
            confidence: {
                constraints: {
                    InclusiveMaximum: 1,
                    InclusiveMinimum: 0
                },
                serializedName: "confidence",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const Document = {
    type: {
        name: "Composite",
        className: "Document",
        modelProperties: {
            docType: {
                constraints: {
                    MaxLength: 64,
                    MinLength: 2
                },
                serializedName: "docType",
                required: true,
                type: {
                    name: "String"
                }
            },
            boundingRegions: {
                serializedName: "boundingRegions",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "BoundingRegion"
                        }
                    }
                }
            },
            spans: {
                serializedName: "spans",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            },
            fields: {
                serializedName: "fields",
                type: {
                    name: "Dictionary",
                    value: { type: { name: "Composite", className: "DocumentField" } }
                }
            },
            confidence: {
                constraints: {
                    InclusiveMaximum: 1,
                    InclusiveMinimum: 0
                },
                serializedName: "confidence",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const DocumentField = {
    type: {
        name: "Composite",
        className: "DocumentField",
        modelProperties: {
            type: {
                serializedName: "type",
                required: true,
                type: {
                    name: "String"
                }
            },
            valueString: {
                serializedName: "valueString",
                type: {
                    name: "String"
                }
            },
            valueDate: {
                serializedName: "valueDate",
                type: {
                    name: "Date"
                }
            },
            valueTime: {
                serializedName: "valueTime",
                type: {
                    name: "String"
                }
            },
            valuePhoneNumber: {
                serializedName: "valuePhoneNumber",
                type: {
                    name: "String"
                }
            },
            valueNumber: {
                serializedName: "valueNumber",
                type: {
                    name: "Number"
                }
            },
            valueInteger: {
                serializedName: "valueInteger",
                type: {
                    name: "Number"
                }
            },
            valueSelectionMark: {
                serializedName: "valueSelectionMark",
                type: {
                    name: "String"
                }
            },
            valueSignature: {
                serializedName: "valueSignature",
                type: {
                    name: "String"
                }
            },
            valueCountryRegion: {
                serializedName: "valueCountryRegion",
                type: {
                    name: "String"
                }
            },
            valueArray: {
                serializedName: "valueArray",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentField"
                        }
                    }
                }
            },
            valueObject: {
                serializedName: "valueObject",
                type: {
                    name: "Dictionary",
                    value: { type: { name: "Composite", className: "DocumentField" } }
                }
            },
            valueCurrency: {
                serializedName: "valueCurrency",
                type: {
                    name: "Composite",
                    className: "CurrencyValue"
                }
            },
            valueAddress: {
                serializedName: "valueAddress",
                type: {
                    name: "Composite",
                    className: "AddressValue"
                }
            },
            valueBoolean: {
                serializedName: "valueBoolean",
                type: {
                    name: "Boolean"
                }
            },
            content: {
                serializedName: "content",
                type: {
                    name: "String"
                }
            },
            boundingRegions: {
                serializedName: "boundingRegions",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "BoundingRegion"
                        }
                    }
                }
            },
            spans: {
                serializedName: "spans",
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentSpan"
                        }
                    }
                }
            },
            confidence: {
                constraints: {
                    InclusiveMaximum: 1,
                    InclusiveMinimum: 0
                },
                serializedName: "confidence",
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const CurrencyValue = {
    type: {
        name: "Composite",
        className: "CurrencyValue",
        modelProperties: {
            amount: {
                serializedName: "amount",
                required: true,
                type: {
                    name: "Number"
                }
            },
            currencySymbol: {
                serializedName: "currencySymbol",
                type: {
                    name: "String"
                }
            },
            currencyCode: {
                serializedName: "currencyCode",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const AddressValue = {
    type: {
        name: "Composite",
        className: "AddressValue",
        modelProperties: {
            houseNumber: {
                serializedName: "houseNumber",
                type: {
                    name: "String"
                }
            },
            poBox: {
                serializedName: "poBox",
                type: {
                    name: "String"
                }
            },
            road: {
                serializedName: "road",
                type: {
                    name: "String"
                }
            },
            city: {
                serializedName: "city",
                type: {
                    name: "String"
                }
            },
            state: {
                serializedName: "state",
                type: {
                    name: "String"
                }
            },
            postalCode: {
                serializedName: "postalCode",
                type: {
                    name: "String"
                }
            },
            countryRegion: {
                serializedName: "countryRegion",
                type: {
                    name: "String"
                }
            },
            streetAddress: {
                serializedName: "streetAddress",
                type: {
                    name: "String"
                }
            },
            unit: {
                serializedName: "unit",
                type: {
                    name: "String"
                }
            },
            cityDistrict: {
                serializedName: "cityDistrict",
                type: {
                    name: "String"
                }
            },
            stateDistrict: {
                serializedName: "stateDistrict",
                type: {
                    name: "String"
                }
            },
            suburb: {
                serializedName: "suburb",
                type: {
                    name: "String"
                }
            },
            house: {
                serializedName: "house",
                type: {
                    name: "String"
                }
            },
            level: {
                serializedName: "level",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const BuildDocumentModelRequest = {
    type: {
        name: "Composite",
        className: "BuildDocumentModelRequest",
        modelProperties: {
            modelId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "modelId",
                required: true,
                type: {
                    name: "String"
                }
            },
            description: {
                constraints: {
                    MaxLength: 4096
                },
                serializedName: "description",
                type: {
                    name: "String"
                }
            },
            buildMode: {
                serializedName: "buildMode",
                required: true,
                type: {
                    name: "String"
                }
            },
            azureBlobSource: {
                serializedName: "azureBlobSource",
                type: {
                    name: "Composite",
                    className: "AzureBlobContentSource"
                }
            },
            azureBlobFileListSource: {
                serializedName: "azureBlobFileListSource",
                type: {
                    name: "Composite",
                    className: "AzureBlobFileListContentSource"
                }
            },
            tags: {
                serializedName: "tags",
                type: {
                    name: "Dictionary",
                    value: { type: { name: "String" } }
                }
            }
        }
    }
};
const AzureBlobContentSource = {
    type: {
        name: "Composite",
        className: "AzureBlobContentSource",
        modelProperties: {
            containerUrl: {
                serializedName: "containerUrl",
                required: true,
                type: {
                    name: "String"
                }
            },
            prefix: {
                serializedName: "prefix",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const AzureBlobFileListContentSource = {
    type: {
        name: "Composite",
        className: "AzureBlobFileListContentSource",
        modelProperties: {
            containerUrl: {
                serializedName: "containerUrl",
                required: true,
                type: {
                    name: "String"
                }
            },
            fileList: {
                serializedName: "fileList",
                required: true,
                type: {
                    name: "String"
                }
            }
        }
    }
};
const ComposeDocumentModelRequest = {
    type: {
        name: "Composite",
        className: "ComposeDocumentModelRequest",
        modelProperties: {
            modelId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "modelId",
                required: true,
                type: {
                    name: "String"
                }
            },
            description: {
                constraints: {
                    MaxLength: 4096
                },
                serializedName: "description",
                type: {
                    name: "String"
                }
            },
            componentModels: {
                constraints: {
                    UniqueItems: true
                },
                serializedName: "componentModels",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "ComponentDocumentModelDetails"
                        }
                    }
                }
            },
            tags: {
                serializedName: "tags",
                type: {
                    name: "Dictionary",
                    value: { type: { name: "String" } }
                }
            }
        }
    }
};
const ComponentDocumentModelDetails = {
    type: {
        name: "Composite",
        className: "ComponentDocumentModelDetails",
        modelProperties: {
            modelId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "modelId",
                required: true,
                type: {
                    name: "String"
                }
            }
        }
    }
};
const AuthorizeCopyRequest = {
    type: {
        name: "Composite",
        className: "AuthorizeCopyRequest",
        modelProperties: {
            modelId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "modelId",
                required: true,
                type: {
                    name: "String"
                }
            },
            description: {
                constraints: {
                    MaxLength: 4096
                },
                serializedName: "description",
                type: {
                    name: "String"
                }
            },
            tags: {
                serializedName: "tags",
                type: {
                    name: "Dictionary",
                    value: { type: { name: "String" } }
                }
            }
        }
    }
};
const CopyAuthorization = {
    type: {
        name: "Composite",
        className: "CopyAuthorization",
        modelProperties: {
            targetResourceId: {
                serializedName: "targetResourceId",
                required: true,
                type: {
                    name: "String"
                }
            },
            targetResourceRegion: {
                serializedName: "targetResourceRegion",
                required: true,
                type: {
                    name: "String"
                }
            },
            targetModelId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "targetModelId",
                required: true,
                type: {
                    name: "String"
                }
            },
            targetModelLocation: {
                serializedName: "targetModelLocation",
                required: true,
                type: {
                    name: "String"
                }
            },
            accessToken: {
                serializedName: "accessToken",
                required: true,
                type: {
                    name: "String"
                }
            },
            expirationDateTime: {
                serializedName: "expirationDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            }
        }
    }
};
const GetOperationsResponse = {
    type: {
        name: "Composite",
        className: "GetOperationsResponse",
        modelProperties: {
            value: {
                serializedName: "value",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "OperationSummary"
                        }
                    }
                }
            },
            nextLink: {
                serializedName: "nextLink",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const OperationSummary = {
    type: {
        name: "Composite",
        className: "OperationSummary",
        modelProperties: {
            operationId: {
                serializedName: "operationId",
                required: true,
                type: {
                    name: "String"
                }
            },
            status: {
                serializedName: "status",
                required: true,
                type: {
                    name: "Enum",
                    allowedValues: [
                        "notStarted",
                        "running",
                        "failed",
                        "succeeded",
                        "canceled"
                    ]
                }
            },
            percentCompleted: {
                constraints: {
                    InclusiveMaximum: 100,
                    InclusiveMinimum: 0
                },
                serializedName: "percentCompleted",
                type: {
                    name: "Number"
                }
            },
            createdOn: {
                serializedName: "createdDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            },
            lastUpdatedOn: {
                serializedName: "lastUpdatedDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            },
            kind: {
                serializedName: "kind",
                required: true,
                type: {
                    name: "String"
                }
            },
            resourceLocation: {
                serializedName: "resourceLocation",
                required: true,
                type: {
                    name: "String"
                }
            },
            apiVersion: {
                serializedName: "apiVersion",
                type: {
                    name: "String"
                }
            },
            tags: {
                serializedName: "tags",
                type: {
                    name: "Dictionary",
                    value: { type: { name: "String" } }
                }
            }
        }
    }
};
const OperationDetails = {
    type: {
        name: "Composite",
        className: "OperationDetails",
        uberParent: "OperationDetails",
        polymorphicDiscriminator: {
            serializedName: "kind",
            clientName: "kind"
        },
        modelProperties: {
            operationId: {
                serializedName: "operationId",
                required: true,
                type: {
                    name: "String"
                }
            },
            status: {
                serializedName: "status",
                required: true,
                type: {
                    name: "Enum",
                    allowedValues: [
                        "notStarted",
                        "running",
                        "failed",
                        "succeeded",
                        "canceled"
                    ]
                }
            },
            percentCompleted: {
                constraints: {
                    InclusiveMaximum: 100,
                    InclusiveMinimum: 0
                },
                serializedName: "percentCompleted",
                type: {
                    name: "Number"
                }
            },
            createdOn: {
                serializedName: "createdDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            },
            lastUpdatedOn: {
                serializedName: "lastUpdatedDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            },
            kind: {
                serializedName: "kind",
                required: true,
                type: {
                    name: "String"
                }
            },
            resourceLocation: {
                serializedName: "resourceLocation",
                required: true,
                type: {
                    name: "String"
                }
            },
            apiVersion: {
                serializedName: "apiVersion",
                type: {
                    name: "String"
                }
            },
            tags: {
                serializedName: "tags",
                type: {
                    name: "Dictionary",
                    value: { type: { name: "String" } }
                }
            },
            error: {
                serializedName: "error",
                type: {
                    name: "Composite",
                    className: "ErrorModel"
                }
            }
        }
    }
};
const GetDocumentModelsResponse = {
    type: {
        name: "Composite",
        className: "GetDocumentModelsResponse",
        modelProperties: {
            value: {
                serializedName: "value",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentModelSummary"
                        }
                    }
                }
            },
            nextLink: {
                serializedName: "nextLink",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const DocumentModelSummary = {
    type: {
        name: "Composite",
        className: "DocumentModelSummary",
        modelProperties: {
            modelId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "modelId",
                required: true,
                type: {
                    name: "String"
                }
            },
            description: {
                constraints: {
                    MaxLength: 4096
                },
                serializedName: "description",
                type: {
                    name: "String"
                }
            },
            createdOn: {
                serializedName: "createdDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            },
            expiresOn: {
                serializedName: "expirationDateTime",
                type: {
                    name: "DateTime"
                }
            },
            apiVersion: {
                serializedName: "apiVersion",
                type: {
                    name: "String"
                }
            },
            tags: {
                serializedName: "tags",
                type: {
                    name: "Dictionary",
                    value: { type: { name: "String" } }
                }
            }
        }
    }
};
const DocumentModelDetails = {
    type: {
        name: "Composite",
        className: "DocumentModelDetails",
        modelProperties: {
            modelId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "modelId",
                required: true,
                type: {
                    name: "String"
                }
            },
            description: {
                constraints: {
                    MaxLength: 4096
                },
                serializedName: "description",
                type: {
                    name: "String"
                }
            },
            createdOn: {
                serializedName: "createdDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            },
            expiresOn: {
                serializedName: "expirationDateTime",
                type: {
                    name: "DateTime"
                }
            },
            apiVersion: {
                serializedName: "apiVersion",
                type: {
                    name: "String"
                }
            },
            tags: {
                serializedName: "tags",
                type: {
                    name: "Dictionary",
                    value: { type: { name: "String" } }
                }
            },
            docTypes: {
                serializedName: "docTypes",
                type: {
                    name: "Dictionary",
                    value: {
                        type: { name: "Composite", className: "DocumentTypeDetails" }
                    }
                }
            }
        }
    }
};
const DocumentTypeDetails = {
    type: {
        name: "Composite",
        className: "DocumentTypeDetails",
        modelProperties: {
            description: {
                constraints: {
                    MaxLength: 4096
                },
                serializedName: "description",
                type: {
                    name: "String"
                }
            },
            buildMode: {
                serializedName: "buildMode",
                type: {
                    name: "String"
                }
            },
            fieldSchema: {
                serializedName: "fieldSchema",
                required: true,
                type: {
                    name: "Dictionary",
                    value: {
                        type: { name: "Composite", className: "DocumentFieldSchema" }
                    }
                }
            },
            fieldConfidence: {
                serializedName: "fieldConfidence",
                type: {
                    name: "Dictionary",
                    value: {
                        type: { name: "Number" },
                        constraints: { InclusiveMaximum: 1, InclusiveMinimum: 0 }
                    }
                }
            }
        }
    }
};
const DocumentFieldSchema = {
    type: {
        name: "Composite",
        className: "DocumentFieldSchema",
        modelProperties: {
            type: {
                serializedName: "type",
                required: true,
                type: {
                    name: "String"
                }
            },
            description: {
                serializedName: "description",
                type: {
                    name: "String"
                }
            },
            example: {
                serializedName: "example",
                type: {
                    name: "String"
                }
            },
            items: {
                serializedName: "items",
                type: {
                    name: "Composite",
                    className: "DocumentFieldSchema"
                }
            },
            properties: {
                serializedName: "properties",
                type: {
                    name: "Dictionary",
                    value: {
                        type: { name: "Composite", className: "DocumentFieldSchema" }
                    }
                }
            }
        }
    }
};
const BuildDocumentClassifierRequest = {
    type: {
        name: "Composite",
        className: "BuildDocumentClassifierRequest",
        modelProperties: {
            classifierId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "classifierId",
                required: true,
                type: {
                    name: "String"
                }
            },
            description: {
                constraints: {
                    MaxLength: 4096
                },
                serializedName: "description",
                type: {
                    name: "String"
                }
            },
            docTypes: {
                serializedName: "docTypes",
                required: true,
                type: {
                    name: "Dictionary",
                    value: {
                        type: {
                            name: "Composite",
                            className: "ClassifierDocumentTypeDetails"
                        }
                    }
                }
            }
        }
    }
};
const ClassifierDocumentTypeDetails = {
    type: {
        name: "Composite",
        className: "ClassifierDocumentTypeDetails",
        modelProperties: {
            azureBlobSource: {
                serializedName: "azureBlobSource",
                type: {
                    name: "Composite",
                    className: "AzureBlobContentSource"
                }
            },
            azureBlobFileListSource: {
                serializedName: "azureBlobFileListSource",
                type: {
                    name: "Composite",
                    className: "AzureBlobFileListContentSource"
                }
            }
        }
    }
};
const GetDocumentClassifiersResponse = {
    type: {
        name: "Composite",
        className: "GetDocumentClassifiersResponse",
        modelProperties: {
            value: {
                serializedName: "value",
                required: true,
                type: {
                    name: "Sequence",
                    element: {
                        type: {
                            name: "Composite",
                            className: "DocumentClassifierDetails"
                        }
                    }
                }
            },
            nextLink: {
                serializedName: "nextLink",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const DocumentClassifierDetails = {
    type: {
        name: "Composite",
        className: "DocumentClassifierDetails",
        modelProperties: {
            classifierId: {
                constraints: {
                    Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$")
                },
                serializedName: "classifierId",
                required: true,
                type: {
                    name: "String"
                }
            },
            description: {
                constraints: {
                    MaxLength: 4096
                },
                serializedName: "description",
                type: {
                    name: "String"
                }
            },
            createdOn: {
                serializedName: "createdDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            },
            expiresOn: {
                serializedName: "expirationDateTime",
                type: {
                    name: "DateTime"
                }
            },
            apiVersion: {
                serializedName: "apiVersion",
                required: true,
                type: {
                    name: "String"
                }
            },
            docTypes: {
                serializedName: "docTypes",
                required: true,
                type: {
                    name: "Dictionary",
                    value: {
                        type: {
                            name: "Composite",
                            className: "ClassifierDocumentTypeDetails"
                        }
                    }
                }
            }
        }
    }
};
const ClassifyDocumentRequest = {
    type: {
        name: "Composite",
        className: "ClassifyDocumentRequest",
        modelProperties: {
            urlSource: {
                serializedName: "urlSource",
                type: {
                    name: "String"
                }
            },
            base64Source: {
                serializedName: "base64Source",
                type: {
                    name: "ByteArray"
                }
            }
        }
    }
};
const ResourceDetails = {
    type: {
        name: "Composite",
        className: "ResourceDetails",
        modelProperties: {
            customDocumentModels: {
                serializedName: "customDocumentModels",
                type: {
                    name: "Composite",
                    className: "CustomDocumentModelsDetails"
                }
            },
            customNeuralDocumentModelBuilds: {
                serializedName: "customNeuralDocumentModelBuilds",
                type: {
                    name: "Composite",
                    className: "QuotaDetails"
                }
            }
        }
    }
};
const CustomDocumentModelsDetails = {
    type: {
        name: "Composite",
        className: "CustomDocumentModelsDetails",
        modelProperties: {
            count: {
                serializedName: "count",
                required: true,
                type: {
                    name: "Number"
                }
            },
            limit: {
                serializedName: "limit",
                required: true,
                type: {
                    name: "Number"
                }
            }
        }
    }
};
const QuotaDetails = {
    type: {
        name: "Composite",
        className: "QuotaDetails",
        modelProperties: {
            used: {
                serializedName: "used",
                required: true,
                type: {
                    name: "Number"
                }
            },
            quota: {
                serializedName: "quota",
                required: true,
                type: {
                    name: "Number"
                }
            },
            quotaResetOn: {
                serializedName: "quotaResetDateTime",
                required: true,
                type: {
                    name: "DateTime"
                }
            }
        }
    }
};
const DocumentModelBuildOperationDetails = {
    serializedName: "documentModelBuild",
    type: {
        name: "Composite",
        className: "DocumentModelBuildOperationDetails",
        uberParent: "OperationDetails",
        polymorphicDiscriminator: OperationDetails.type.polymorphicDiscriminator,
        modelProperties: Object.assign(Object.assign({}, OperationDetails.type.modelProperties), { result: {
                serializedName: "result",
                type: {
                    name: "Composite",
                    className: "DocumentModelDetails"
                }
            } })
    }
};
const DocumentModelComposeOperationDetails = {
    serializedName: "documentModelCompose",
    type: {
        name: "Composite",
        className: "DocumentModelComposeOperationDetails",
        uberParent: "OperationDetails",
        polymorphicDiscriminator: OperationDetails.type.polymorphicDiscriminator,
        modelProperties: Object.assign(Object.assign({}, OperationDetails.type.modelProperties), { result: {
                serializedName: "result",
                type: {
                    name: "Composite",
                    className: "DocumentModelDetails"
                }
            } })
    }
};
const DocumentModelCopyToOperationDetails = {
    serializedName: "documentModelCopyTo",
    type: {
        name: "Composite",
        className: "DocumentModelCopyToOperationDetails",
        uberParent: "OperationDetails",
        polymorphicDiscriminator: OperationDetails.type.polymorphicDiscriminator,
        modelProperties: Object.assign(Object.assign({}, OperationDetails.type.modelProperties), { result: {
                serializedName: "result",
                type: {
                    name: "Composite",
                    className: "DocumentModelDetails"
                }
            } })
    }
};
const DocumentClassifierBuildOperationDetails = {
    serializedName: "documentClassifierBuild",
    type: {
        name: "Composite",
        className: "DocumentClassifierBuildOperationDetails",
        uberParent: "OperationDetails",
        polymorphicDiscriminator: OperationDetails.type.polymorphicDiscriminator,
        modelProperties: Object.assign(Object.assign({}, OperationDetails.type.modelProperties), { result: {
                serializedName: "result",
                type: {
                    name: "Composite",
                    className: "DocumentClassifierDetails"
                }
            } })
    }
};
const DocumentModelsAnalyzeDocumentHeaders = {
    type: {
        name: "Composite",
        className: "DocumentModelsAnalyzeDocumentHeaders",
        modelProperties: {
            operationLocation: {
                serializedName: "operation-location",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const DocumentModelsBuildModelHeaders = {
    type: {
        name: "Composite",
        className: "DocumentModelsBuildModelHeaders",
        modelProperties: {
            operationLocation: {
                serializedName: "operation-location",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const DocumentModelsComposeModelHeaders = {
    type: {
        name: "Composite",
        className: "DocumentModelsComposeModelHeaders",
        modelProperties: {
            operationLocation: {
                serializedName: "operation-location",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const DocumentModelsCopyModelToHeaders = {
    type: {
        name: "Composite",
        className: "DocumentModelsCopyModelToHeaders",
        modelProperties: {
            operationLocation: {
                serializedName: "operation-location",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const DocumentClassifiersBuildClassifierHeaders = {
    type: {
        name: "Composite",
        className: "DocumentClassifiersBuildClassifierHeaders",
        modelProperties: {
            operationLocation: {
                serializedName: "operation-location",
                type: {
                    name: "String"
                }
            }
        }
    }
};
const DocumentClassifiersClassifyDocumentHeaders = {
    type: {
        name: "Composite",
        className: "DocumentClassifiersClassifyDocumentHeaders",
        modelProperties: {
            operationLocation: {
                serializedName: "operation-location",
                type: {
                    name: "String"
                }
            }
        }
    }
};
let discriminators = {
    OperationDetails: OperationDetails,
    "OperationDetails.documentModelBuild": DocumentModelBuildOperationDetails,
    "OperationDetails.documentModelCompose": DocumentModelComposeOperationDetails,
    "OperationDetails.documentModelCopyTo": DocumentModelCopyToOperationDetails,
    "OperationDetails.documentClassifierBuild": DocumentClassifierBuildOperationDetails
};
//# sourceMappingURL=mappers.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/models/parameters.js
/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 *
 * Code generated by Microsoft (R) AutoRest Code Generator.
 * Changes may cause incorrect behavior and will be lost if the code is regenerated.
 */

const contentType = {
    parameterPath: "contentType",
    mapper: {
        serializedName: "Content-Type",
        required: true,
        type: {
            name: "Enum",
            allowedValues: [
                "application/octet-stream",
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "image/bmp",
                "image/heif",
                "image/jpeg",
                "image/png",
                "image/tiff"
            ]
        }
    }
};
const analyzeRequest = {
    parameterPath: ["options", "analyzeRequest"],
    mapper: {
        serializedName: "analyzeRequest",
        type: {
            name: "Stream"
        }
    }
};
const accept = {
    parameterPath: "accept",
    mapper: {
        defaultValue: "application/json",
        isConstant: true,
        serializedName: "Accept",
        type: {
            name: "String"
        }
    }
};
const contentType1 = {
    parameterPath: "contentType",
    mapper: {
        defaultValue: "text/html",
        isConstant: true,
        serializedName: "Content-Type",
        type: {
            name: "String"
        }
    }
};
const analyzeRequest1 = {
    parameterPath: ["options", "analyzeRequest"],
    mapper: {
        serializedName: "analyzeRequest",
        type: {
            name: "String"
        }
    }
};
const parameters_accept1 = {
    parameterPath: "accept",
    mapper: {
        defaultValue: "application/json",
        isConstant: true,
        serializedName: "Accept",
        type: {
            name: "String"
        }
    }
};
const contentType2 = {
    parameterPath: "contentType",
    mapper: {
        defaultValue: "application/json",
        isConstant: true,
        serializedName: "Content-Type",
        type: {
            name: "String"
        }
    }
};
const analyzeRequest2 = {
    parameterPath: ["options", "analyzeRequest"],
    mapper: AnalyzeDocumentRequest
};
const accept2 = {
    parameterPath: "accept",
    mapper: {
        defaultValue: "application/json",
        isConstant: true,
        serializedName: "Accept",
        type: {
            name: "String"
        }
    }
};
const endpoint = {
    parameterPath: "endpoint",
    mapper: {
        serializedName: "endpoint",
        required: true,
        type: {
            name: "String"
        }
    },
    skipEncoding: true
};
const modelId = {
    parameterPath: "modelId",
    mapper: {
        constraints: {
            Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$"),
            MaxLength: 64
        },
        serializedName: "modelId",
        required: true,
        type: {
            name: "String"
        }
    }
};
const pages = {
    parameterPath: ["options", "pages"],
    mapper: {
        constraints: {
            Pattern: new RegExp("^(\\d+(-\\d+)?)(,\\s*(\\d+(-\\d+)?))*$")
        },
        serializedName: "pages",
        type: {
            name: "String"
        }
    }
};
const locale = {
    parameterPath: ["options", "locale"],
    mapper: {
        serializedName: "locale",
        type: {
            name: "String"
        }
    }
};
const stringIndexType = {
    parameterPath: "stringIndexType",
    mapper: {
        serializedName: "stringIndexType",
        type: {
            name: "String"
        }
    }
};
const apiVersion = {
    parameterPath: "apiVersion",
    mapper: {
        defaultValue: "2023-07-31",
        isConstant: true,
        serializedName: "api-version",
        type: {
            name: "String"
        }
    }
};
const features = {
    parameterPath: ["options", "features"],
    mapper: {
        serializedName: "features",
        type: {
            name: "Sequence",
            element: {
                type: {
                    name: "String"
                }
            }
        }
    },
    collectionFormat: "CSV"
};
const resultId = {
    parameterPath: "resultId",
    mapper: {
        serializedName: "resultId",
        required: true,
        type: {
            name: "Uuid"
        }
    }
};
const contentType3 = {
    parameterPath: ["options", "contentType"],
    mapper: {
        defaultValue: "application/json",
        isConstant: true,
        serializedName: "Content-Type",
        type: {
            name: "String"
        }
    }
};
const buildRequest = {
    parameterPath: "buildRequest",
    mapper: BuildDocumentModelRequest
};
const composeRequest = {
    parameterPath: "composeRequest",
    mapper: ComposeDocumentModelRequest
};
const authorizeCopyRequest = {
    parameterPath: "authorizeCopyRequest",
    mapper: AuthorizeCopyRequest
};
const copyToRequest = {
    parameterPath: "copyToRequest",
    mapper: CopyAuthorization
};
const nextLink = {
    parameterPath: "nextLink",
    mapper: {
        serializedName: "nextLink",
        required: true,
        type: {
            name: "String"
        }
    },
    skipEncoding: true
};
const operationId = {
    parameterPath: "operationId",
    mapper: {
        constraints: {
            Pattern: new RegExp("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"),
            MaxLength: 36
        },
        serializedName: "operationId",
        required: true,
        type: {
            name: "String"
        }
    }
};
const buildRequest1 = {
    parameterPath: "buildRequest",
    mapper: BuildDocumentClassifierRequest
};
const classifierId = {
    parameterPath: "classifierId",
    mapper: {
        constraints: {
            Pattern: new RegExp("^[a-zA-Z0-9][a-zA-Z0-9._~-]{1,63}$"),
            MaxLength: 64
        },
        serializedName: "classifierId",
        required: true,
        type: {
            name: "String"
        }
    }
};
const classifyRequest = {
    parameterPath: ["options", "classifyRequest"],
    mapper: {
        serializedName: "classifyRequest",
        type: {
            name: "Stream"
        }
    }
};
const classifyRequest1 = {
    parameterPath: ["options", "classifyRequest"],
    mapper: {
        serializedName: "classifyRequest",
        type: {
            name: "String"
        }
    }
};
const classifyRequest2 = {
    parameterPath: ["options", "classifyRequest"],
    mapper: ClassifyDocumentRequest
};
//# sourceMappingURL=parameters.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/error.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Returns the innermost error that has a message field.
 *
 * @internal
 * @param error - the error to unwrap
 * @returns - the innermost populated error
 */
function unwrap(error) {
    if (error.innererror !== undefined && error.innererror.message !== undefined) {
        return unwrap(error.innererror);
    }
    return error;
}
/**
 * A class representing an Error from the Form Recognizer Service.
 *
 * For information about the error codes the service produces, refer to the service's error documentation:
 *
 * https://aka.ms/azsdk/formrecognizer/errors
 */
class error_FormRecognizerError extends Error {
    /**
     * Create a FormRecognizerError from a generated ErrorModel.
     * @internal
     * @hidden
     */
    constructor(formRecognizerError) {
        var _a;
        // TODO: We used to unwrap FR errors this way, but is it still necessary
        const e = unwrap(formRecognizerError);
        super(e.message);
        this.code = e.code;
        this.details = (_a = e.details) !== null && _a !== void 0 ? _a : [];
        this.target = e.target;
    }
}
//# sourceMappingURL=error.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/transforms/polygon.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
function toBoundingPolygon(original) {
    const points = [];
    if (!original)
        return;
    if (original.length % 2 !== 0) {
        throw new Error("Unexpected number of points in the response, unable to translate as 2D points");
    }
    for (let i = 0; i < original.length; i += 2) {
        points.push({ x: original[i], y: original[i + 1] });
    }
    return points;
}
function toBoundingRegions(original) {
    return original === null || original === void 0 ? void 0 : original.map((region) => (Object.assign(Object.assign({}, region), { polygon: toBoundingPolygon(region.polygon) })));
}
function toDocumentTableFromGenerated(table) {
    return Object.assign(Object.assign({}, table), { boundingRegions: toBoundingRegions(table.boundingRegions), cells: table.cells.map((cell) => (Object.assign(Object.assign({}, cell), { boundingRegions: toBoundingRegions(cell.boundingRegions) }))) });
}
function toKeyValuePairFromGenerated(pair) {
    var _a;
    return Object.assign(Object.assign({}, pair), { key: Object.assign(Object.assign({}, pair.key), { boundingRegions: toBoundingRegions(pair.key.boundingRegions) }), value: pair.value
            ? Object.assign(Object.assign({}, pair.value), { boundingRegions: toBoundingRegions((_a = pair.value) === null || _a === void 0 ? void 0 : _a.boundingRegions) }) : undefined });
}
//# sourceMappingURL=polygon.js.map
// EXTERNAL MODULE: ./node_modules/@azure/core-rest-pipeline/dist/esm/index.js + 36 modules
var core_rest_pipeline_dist_esm = __webpack_require__(97202);
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/azureKeyCredentialPolicy.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
const APIM_SUBSCRIPTION_KEY_HEADER = "Ocp-Apim-Subscription-Key";
/**
 * Create an HTTP pipeline policy to authenticate a request using an `AzureKeyCredential` for Azure Form Recognizer
 * @internal
 */
function createFormRecognizerAzureKeyCredentialPolicy(credential) {
    return {
        name: "cognitiveServicesApimSubscriptionKeyCredentialPolicy",
        sendRequest(request, next) {
            request.headers.set(APIM_SUBSCRIPTION_KEY_HEADER, credential.key);
            return next(request);
        },
    };
}
//# sourceMappingURL=azureKeyCredentialPolicy.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/models/index.js
/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 *
 * Code generated by Microsoft (R) AutoRest Code Generator.
 * Changes may cause incorrect behavior and will be lost if the code is regenerated.
 */
/** Known values of {@link StringIndexType} that the service accepts. */
var KnownStringIndexType;
(function (KnownStringIndexType) {
    /** User-perceived display character, or grapheme cluster, as defined by Unicode 8.0.0. */
    KnownStringIndexType["TextElements"] = "textElements";
    /** Character unit represented by a single unicode code point.  Used by Python 3. */
    KnownStringIndexType["UnicodeCodePoint"] = "unicodeCodePoint";
    /** Character unit represented by a 16-bit Unicode code unit.  Used by JavaScript, Java, and .NET. */
    KnownStringIndexType["Utf16CodeUnit"] = "utf16CodeUnit";
})(KnownStringIndexType || (KnownStringIndexType = {}));
/** Known values of {@link DocumentAnalysisFeature} that the service accepts. */
var KnownDocumentAnalysisFeature;
(function (KnownDocumentAnalysisFeature) {
    /** Perform OCR at a higher resolution to handle documents with fine print. */
    KnownDocumentAnalysisFeature["OcrHighResolution"] = "ocrHighResolution";
    /** Enable the detection of the text content language. */
    KnownDocumentAnalysisFeature["Languages"] = "languages";
    /** Enable the detection of barcodes in the document. */
    KnownDocumentAnalysisFeature["Barcodes"] = "barcodes";
    /** Enable the detection of mathematical expressions in the document. */
    KnownDocumentAnalysisFeature["Formulas"] = "formulas";
    /** Enable the detection of general key value pairs (form fields) in the document. */
    KnownDocumentAnalysisFeature["KeyValuePairs"] = "keyValuePairs";
    /** Enable the recognition of various font styles. */
    KnownDocumentAnalysisFeature["StyleFont"] = "styleFont";
})(KnownDocumentAnalysisFeature || (KnownDocumentAnalysisFeature = {}));
/** Known values of {@link LengthUnit} that the service accepts. */
var KnownLengthUnit;
(function (KnownLengthUnit) {
    /** Length unit for image files. */
    KnownLengthUnit["Pixel"] = "pixel";
    /** Length unit for PDF files. */
    KnownLengthUnit["Inch"] = "inch";
})(KnownLengthUnit || (KnownLengthUnit = {}));
/** Known values of {@link SelectionMarkState} that the service accepts. */
var KnownSelectionMarkState;
(function (KnownSelectionMarkState) {
    /** The selection mark is selected, often indicated by a check ✓ or cross X inside the selection mark. */
    KnownSelectionMarkState["Selected"] = "selected";
    /** The selection mark is not selected. */
    KnownSelectionMarkState["Unselected"] = "unselected";
})(KnownSelectionMarkState || (KnownSelectionMarkState = {}));
/** Known values of {@link DocumentBarcodeKind} that the service accepts. */
var KnownDocumentBarcodeKind;
(function (KnownDocumentBarcodeKind) {
    /** QR code, as defined in ISO/IEC 18004:2015. */
    KnownDocumentBarcodeKind["QRCode"] = "QRCode";
    /** PDF417, as defined in ISO 15438. */
    KnownDocumentBarcodeKind["PDF417"] = "PDF417";
    /** GS1 12-digit Universal Product Code. */
    KnownDocumentBarcodeKind["Upca"] = "UPCA";
    /** GS1 6-digit Universal Product Code. */
    KnownDocumentBarcodeKind["Upce"] = "UPCE";
    /** Code 39 barcode, as defined in ISO/IEC 16388:2007. */
    KnownDocumentBarcodeKind["Code39"] = "Code39";
    /** Code 128 barcode, as defined in ISO/IEC 15417:2007. */
    KnownDocumentBarcodeKind["Code128"] = "Code128";
    /** GS1 8-digit International Article Number (European Article Number). */
    KnownDocumentBarcodeKind["EAN8"] = "EAN8";
    /** GS1 13-digit International Article Number (European Article Number). */
    KnownDocumentBarcodeKind["EAN13"] = "EAN13";
    /** GS1 DataBar barcode. */
    KnownDocumentBarcodeKind["DataBar"] = "DataBar";
    /** Code 93 barcode, as defined in ANSI/AIM BC5-1995. */
    KnownDocumentBarcodeKind["Code93"] = "Code93";
    /** Codabar barcode, as defined in ANSI/AIM BC3-1995. */
    KnownDocumentBarcodeKind["Codabar"] = "Codabar";
    /** GS1 DataBar Expanded barcode. */
    KnownDocumentBarcodeKind["DataBarExpanded"] = "DataBarExpanded";
    /** Interleaved 2 of 5 barcode, as defined in ANSI/AIM BC2-1995. */
    KnownDocumentBarcodeKind["ITF"] = "ITF";
    /** Micro QR code, as defined in ISO/IEC 23941:2022. */
    KnownDocumentBarcodeKind["MicroQRCode"] = "MicroQRCode";
    /** Aztec code, as defined in ISO/IEC 24778:2008. */
    KnownDocumentBarcodeKind["Aztec"] = "Aztec";
    /** Data matrix code, as defined in ISO/IEC 16022:2006. */
    KnownDocumentBarcodeKind["DataMatrix"] = "DataMatrix";
    /** MaxiCode, as defined in ISO/IEC 16023:2000. */
    KnownDocumentBarcodeKind["MaxiCode"] = "MaxiCode";
})(KnownDocumentBarcodeKind || (KnownDocumentBarcodeKind = {}));
/** Known values of {@link DocumentFormulaKind} that the service accepts. */
var KnownDocumentFormulaKind;
(function (KnownDocumentFormulaKind) {
    /** A formula embedded within the content of a paragraph. */
    KnownDocumentFormulaKind["Inline"] = "inline";
    /** A formula in display mode that takes up an entire line. */
    KnownDocumentFormulaKind["Display"] = "display";
})(KnownDocumentFormulaKind || (KnownDocumentFormulaKind = {}));
/** Known values of {@link ParagraphRole} that the service accepts. */
var KnownParagraphRole;
(function (KnownParagraphRole) {
    /** Text near the top edge of the page. */
    KnownParagraphRole["PageHeader"] = "pageHeader";
    /** Text near the bottom edge of the page. */
    KnownParagraphRole["PageFooter"] = "pageFooter";
    /** Page number. */
    KnownParagraphRole["PageNumber"] = "pageNumber";
    /** Top-level title describing the entire document. */
    KnownParagraphRole["Title"] = "title";
    /** Sub heading describing a section of the document. */
    KnownParagraphRole["SectionHeading"] = "sectionHeading";
    /** A note usually placed after the main content on a page. */
    KnownParagraphRole["Footnote"] = "footnote";
    /** A block of formulas, often with shared alignment. */
    KnownParagraphRole["FormulaBlock"] = "formulaBlock";
})(KnownParagraphRole || (KnownParagraphRole = {}));
/** Known values of {@link DocumentTableCellKind} that the service accepts. */
var KnownDocumentTableCellKind;
(function (KnownDocumentTableCellKind) {
    /** Contains the main content/data. */
    KnownDocumentTableCellKind["Content"] = "content";
    /** Describes the content of the row. */
    KnownDocumentTableCellKind["RowHeader"] = "rowHeader";
    /** Describes the content of the column. */
    KnownDocumentTableCellKind["ColumnHeader"] = "columnHeader";
    /** Describes the row headers, usually located at the top left corner of a table. */
    KnownDocumentTableCellKind["StubHead"] = "stubHead";
    /** Describes the content in (parts of) the table. */
    KnownDocumentTableCellKind["Description"] = "description";
})(KnownDocumentTableCellKind || (KnownDocumentTableCellKind = {}));
/** Known values of {@link FontStyle} that the service accepts. */
var KnownFontStyle;
(function (KnownFontStyle) {
    /** Characters are represented normally. */
    KnownFontStyle["Normal"] = "normal";
    /** Characters are visually slanted to the right. */
    KnownFontStyle["Italic"] = "italic";
})(KnownFontStyle || (KnownFontStyle = {}));
/** Known values of {@link FontWeight} that the service accepts. */
var KnownFontWeight;
(function (KnownFontWeight) {
    /** Characters are represented normally. */
    KnownFontWeight["Normal"] = "normal";
    /** Characters are represented with thicker strokes. */
    KnownFontWeight["Bold"] = "bold";
})(KnownFontWeight || (KnownFontWeight = {}));
/** Known values of {@link DocumentFieldType} that the service accepts. */
var KnownDocumentFieldType;
(function (KnownDocumentFieldType) {
    /** Plain text. */
    KnownDocumentFieldType["String"] = "string";
    /** Date, normalized to ISO 8601 (YYYY-MM-DD) format. */
    KnownDocumentFieldType["Date"] = "date";
    /** Time, normalized to ISO 8601 (hh:mm:ss) format. */
    KnownDocumentFieldType["Time"] = "time";
    /** Phone number, normalized to E.164 (+{CountryCode}{SubscriberNumber}) format. */
    KnownDocumentFieldType["PhoneNumber"] = "phoneNumber";
    /** Floating point number, normalized to double precision floating point. */
    KnownDocumentFieldType["Number"] = "number";
    /** Integer number, normalized to 64-bit signed integer. */
    KnownDocumentFieldType["Integer"] = "integer";
    /** Is field selected? */
    KnownDocumentFieldType["SelectionMark"] = "selectionMark";
    /** Country/region, normalized to ISO 3166-1 alpha-3 format (ex. USA). */
    KnownDocumentFieldType["CountryRegion"] = "countryRegion";
    /** Is signature present? */
    KnownDocumentFieldType["Signature"] = "signature";
    /** List of subfields of the same type. */
    KnownDocumentFieldType["Array"] = "array";
    /** Named list of subfields of potentially different types. */
    KnownDocumentFieldType["Object"] = "object";
    /** Currency amount with optional currency symbol and unit. */
    KnownDocumentFieldType["Currency"] = "currency";
    /** Parsed address. */
    KnownDocumentFieldType["Address"] = "address";
    /** Boolean value, normalized to true or false. */
    KnownDocumentFieldType["Boolean"] = "boolean";
})(KnownDocumentFieldType || (KnownDocumentFieldType = {}));
/** Known values of {@link DocumentSignatureType} that the service accepts. */
var KnownDocumentSignatureType;
(function (KnownDocumentSignatureType) {
    /** A signature is detected. */
    KnownDocumentSignatureType["Signed"] = "signed";
    /** No signatures are detected. */
    KnownDocumentSignatureType["Unsigned"] = "unsigned";
})(KnownDocumentSignatureType || (KnownDocumentSignatureType = {}));
/** Known values of {@link DocumentBuildMode} that the service accepts. */
var KnownDocumentBuildMode;
(function (KnownDocumentBuildMode) {
    /** Target documents with similar visual templates. */
    KnownDocumentBuildMode["Template"] = "template";
    /** Support documents with diverse visual templates. */
    KnownDocumentBuildMode["Neural"] = "neural";
})(KnownDocumentBuildMode || (KnownDocumentBuildMode = {}));
/** Known values of {@link OperationKind} that the service accepts. */
var KnownOperationKind;
(function (KnownOperationKind) {
    /** Build a new custom document model. */
    KnownOperationKind["DocumentModelBuild"] = "documentModelBuild";
    /** Compose a new custom document model from existing models. */
    KnownOperationKind["DocumentModelCompose"] = "documentModelCompose";
    /** Copy an existing document model to potentially a different resource, region, or subscription. */
    KnownOperationKind["DocumentModelCopyTo"] = "documentModelCopyTo";
    /** Build a new custom classifier model. */
    KnownOperationKind["DocumentClassifierBuild"] = "documentClassifierBuild";
})(KnownOperationKind || (KnownOperationKind = {}));
//# sourceMappingURL=index.js.map
;// ./node_modules/@azure/core-client/dist/esm/base64.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Encodes a string in base64 format.
 * @param value - the string to encode
 * @internal
 */
function encodeString(value) {
    return Buffer.from(value).toString("base64");
}
/**
 * Encodes a byte array in base64 format.
 * @param value - the Uint8Aray to encode
 * @internal
 */
function encodeByteArray(value) {
    const bufferValue = value instanceof Buffer ? value : Buffer.from(value.buffer);
    return bufferValue.toString("base64");
}
/**
 * Decodes a base64 string into a byte array.
 * @param value - the base64 string to decode
 * @internal
 */
function decodeString(value) {
    return Buffer.from(value, "base64");
}
/**
 * Decodes a base64 string into a string.
 * @param value - the base64 string to decode
 * @internal
 */
function decodeStringToString(value) {
    return Buffer.from(value, "base64").toString();
}
//# sourceMappingURL=base64.js.map
;// ./node_modules/@azure/core-client/dist/esm/interfaces.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Default key used to access the XML attributes.
 */
const XML_ATTRKEY = "$";
/**
 * Default key used to access the XML value content.
 */
const XML_CHARKEY = "_";
//# sourceMappingURL=interfaces.js.map
;// ./node_modules/@azure/core-client/dist/esm/utils.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * A type guard for a primitive response body.
 * @param value - Value to test
 *
 * @internal
 */
function isPrimitiveBody(value, mapperTypeName) {
    return (mapperTypeName !== "Composite" &&
        mapperTypeName !== "Dictionary" &&
        (typeof value === "string" ||
            typeof value === "number" ||
            typeof value === "boolean" ||
            (mapperTypeName === null || mapperTypeName === void 0 ? void 0 : mapperTypeName.match(/^(Date|DateTime|DateTimeRfc1123|UnixTime|ByteArray|Base64Url)$/i)) !==
                null ||
            value === undefined ||
            value === null));
}
const validateISODuration = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/;
/**
 * Returns true if the given string is in ISO 8601 format.
 * @param value - The value to be validated for ISO 8601 duration format.
 * @internal
 */
function isDuration(value) {
    return validateISODuration.test(value);
}
const validUuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/i;
/**
 * Returns true if the provided uuid is valid.
 *
 * @param uuid - The uuid that needs to be validated.
 *
 * @internal
 */
function isValidUuid(uuid) {
    return validUuidRegex.test(uuid);
}
/**
 * Maps the response as follows:
 * - wraps the response body if needed (typically if its type is primitive).
 * - returns null if the combination of the headers and the body is empty.
 * - otherwise, returns the combination of the headers and the body.
 *
 * @param responseObject - a representation of the parsed response
 * @returns the response that will be returned to the user which can be null and/or wrapped
 *
 * @internal
 */
function handleNullableResponseAndWrappableBody(responseObject) {
    const combinedHeadersAndBody = Object.assign(Object.assign({}, responseObject.headers), responseObject.body);
    if (responseObject.hasNullableType &&
        Object.getOwnPropertyNames(combinedHeadersAndBody).length === 0) {
        return responseObject.shouldWrapBody ? { body: null } : null;
    }
    else {
        return responseObject.shouldWrapBody
            ? Object.assign(Object.assign({}, responseObject.headers), { body: responseObject.body }) : combinedHeadersAndBody;
    }
}
/**
 * Take a `FullOperationResponse` and turn it into a flat
 * response object to hand back to the consumer.
 * @param fullResponse - The processed response from the operation request
 * @param responseSpec - The response map from the OperationSpec
 *
 * @internal
 */
function flattenResponse(fullResponse, responseSpec) {
    var _a, _b;
    const parsedHeaders = fullResponse.parsedHeaders;
    // head methods never have a body, but we return a boolean set to body property
    // to indicate presence/absence of the resource
    if (fullResponse.request.method === "HEAD") {
        return Object.assign(Object.assign({}, parsedHeaders), { body: fullResponse.parsedBody });
    }
    const bodyMapper = responseSpec && responseSpec.bodyMapper;
    const isNullable = Boolean(bodyMapper === null || bodyMapper === void 0 ? void 0 : bodyMapper.nullable);
    const expectedBodyTypeName = bodyMapper === null || bodyMapper === void 0 ? void 0 : bodyMapper.type.name;
    /** If the body is asked for, we look at the expected body type to handle it */
    if (expectedBodyTypeName === "Stream") {
        return Object.assign(Object.assign({}, parsedHeaders), { blobBody: fullResponse.blobBody, readableStreamBody: fullResponse.readableStreamBody });
    }
    const modelProperties = (expectedBodyTypeName === "Composite" &&
        bodyMapper.type.modelProperties) ||
        {};
    const isPageableResponse = Object.keys(modelProperties).some((k) => modelProperties[k].serializedName === "");
    if (expectedBodyTypeName === "Sequence" || isPageableResponse) {
        const arrayResponse = (_a = fullResponse.parsedBody) !== null && _a !== void 0 ? _a : [];
        for (const key of Object.keys(modelProperties)) {
            if (modelProperties[key].serializedName) {
                arrayResponse[key] = (_b = fullResponse.parsedBody) === null || _b === void 0 ? void 0 : _b[key];
            }
        }
        if (parsedHeaders) {
            for (const key of Object.keys(parsedHeaders)) {
                arrayResponse[key] = parsedHeaders[key];
            }
        }
        return isNullable &&
            !fullResponse.parsedBody &&
            !parsedHeaders &&
            Object.getOwnPropertyNames(modelProperties).length === 0
            ? null
            : arrayResponse;
    }
    return handleNullableResponseAndWrappableBody({
        body: fullResponse.parsedBody,
        headers: parsedHeaders,
        hasNullableType: isNullable,
        shouldWrapBody: isPrimitiveBody(fullResponse.parsedBody, expectedBodyTypeName),
    });
}
//# sourceMappingURL=utils.js.map
;// ./node_modules/@azure/core-client/dist/esm/serializer.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.



class SerializerImpl {
    constructor(modelMappers = {}, isXML = false) {
        this.modelMappers = modelMappers;
        this.isXML = isXML;
    }
    /**
     * @deprecated Removing the constraints validation on client side.
     */
    validateConstraints(mapper, value, objectName) {
        const failValidation = (constraintName, constraintValue) => {
            throw new Error(`"${objectName}" with value "${value}" should satisfy the constraint "${constraintName}": ${constraintValue}.`);
        };
        if (mapper.constraints && value !== undefined && value !== null) {
            const { ExclusiveMaximum, ExclusiveMinimum, InclusiveMaximum, InclusiveMinimum, MaxItems, MaxLength, MinItems, MinLength, MultipleOf, Pattern, UniqueItems, } = mapper.constraints;
            if (ExclusiveMaximum !== undefined && value >= ExclusiveMaximum) {
                failValidation("ExclusiveMaximum", ExclusiveMaximum);
            }
            if (ExclusiveMinimum !== undefined && value <= ExclusiveMinimum) {
                failValidation("ExclusiveMinimum", ExclusiveMinimum);
            }
            if (InclusiveMaximum !== undefined && value > InclusiveMaximum) {
                failValidation("InclusiveMaximum", InclusiveMaximum);
            }
            if (InclusiveMinimum !== undefined && value < InclusiveMinimum) {
                failValidation("InclusiveMinimum", InclusiveMinimum);
            }
            if (MaxItems !== undefined && value.length > MaxItems) {
                failValidation("MaxItems", MaxItems);
            }
            if (MaxLength !== undefined && value.length > MaxLength) {
                failValidation("MaxLength", MaxLength);
            }
            if (MinItems !== undefined && value.length < MinItems) {
                failValidation("MinItems", MinItems);
            }
            if (MinLength !== undefined && value.length < MinLength) {
                failValidation("MinLength", MinLength);
            }
            if (MultipleOf !== undefined && value % MultipleOf !== 0) {
                failValidation("MultipleOf", MultipleOf);
            }
            if (Pattern) {
                const pattern = typeof Pattern === "string" ? new RegExp(Pattern) : Pattern;
                if (typeof value !== "string" || value.match(pattern) === null) {
                    failValidation("Pattern", Pattern);
                }
            }
            if (UniqueItems &&
                value.some((item, i, ar) => ar.indexOf(item) !== i)) {
                failValidation("UniqueItems", UniqueItems);
            }
        }
    }
    /**
     * Serialize the given object based on its metadata defined in the mapper
     *
     * @param mapper - The mapper which defines the metadata of the serializable object
     *
     * @param object - A valid Javascript object to be serialized
     *
     * @param objectName - Name of the serialized object
     *
     * @param options - additional options to serialization
     *
     * @returns A valid serialized Javascript object
     */
    serialize(mapper, object, objectName, options = { xml: {} }) {
        var _a, _b, _c;
        const updatedOptions = {
            xml: {
                rootName: (_a = options.xml.rootName) !== null && _a !== void 0 ? _a : "",
                includeRoot: (_b = options.xml.includeRoot) !== null && _b !== void 0 ? _b : false,
                xmlCharKey: (_c = options.xml.xmlCharKey) !== null && _c !== void 0 ? _c : XML_CHARKEY,
            },
        };
        let payload = {};
        const mapperType = mapper.type.name;
        if (!objectName) {
            objectName = mapper.serializedName;
        }
        if (mapperType.match(/^Sequence$/i) !== null) {
            payload = [];
        }
        if (mapper.isConstant) {
            object = mapper.defaultValue;
        }
        // This table of allowed values should help explain
        // the mapper.required and mapper.nullable properties.
        // X means "neither undefined or null are allowed".
        //           || required
        //           || true      | false
        //  nullable || ==========================
        //      true || null      | undefined/null
        //     false || X         | undefined
        // undefined || X         | undefined/null
        const { required, nullable } = mapper;
        if (required && nullable && object === undefined) {
            throw new Error(`${objectName} cannot be undefined.`);
        }
        if (required && !nullable && (object === undefined || object === null)) {
            throw new Error(`${objectName} cannot be null or undefined.`);
        }
        if (!required && nullable === false && object === null) {
            throw new Error(`${objectName} cannot be null.`);
        }
        if (object === undefined || object === null) {
            payload = object;
        }
        else {
            if (mapperType.match(/^any$/i) !== null) {
                payload = object;
            }
            else if (mapperType.match(/^(Number|String|Boolean|Object|Stream|Uuid)$/i) !== null) {
                payload = serializeBasicTypes(mapperType, objectName, object);
            }
            else if (mapperType.match(/^Enum$/i) !== null) {
                const enumMapper = mapper;
                payload = serializeEnumType(objectName, enumMapper.type.allowedValues, object);
            }
            else if (mapperType.match(/^(Date|DateTime|TimeSpan|DateTimeRfc1123|UnixTime)$/i) !== null) {
                payload = serializeDateTypes(mapperType, object, objectName);
            }
            else if (mapperType.match(/^ByteArray$/i) !== null) {
                payload = serializeByteArrayType(objectName, object);
            }
            else if (mapperType.match(/^Base64Url$/i) !== null) {
                payload = serializeBase64UrlType(objectName, object);
            }
            else if (mapperType.match(/^Sequence$/i) !== null) {
                payload = serializeSequenceType(this, mapper, object, objectName, Boolean(this.isXML), updatedOptions);
            }
            else if (mapperType.match(/^Dictionary$/i) !== null) {
                payload = serializeDictionaryType(this, mapper, object, objectName, Boolean(this.isXML), updatedOptions);
            }
            else if (mapperType.match(/^Composite$/i) !== null) {
                payload = serializeCompositeType(this, mapper, object, objectName, Boolean(this.isXML), updatedOptions);
            }
        }
        return payload;
    }
    /**
     * Deserialize the given object based on its metadata defined in the mapper
     *
     * @param mapper - The mapper which defines the metadata of the serializable object
     *
     * @param responseBody - A valid Javascript entity to be deserialized
     *
     * @param objectName - Name of the deserialized object
     *
     * @param options - Controls behavior of XML parser and builder.
     *
     * @returns A valid deserialized Javascript object
     */
    deserialize(mapper, responseBody, objectName, options = { xml: {} }) {
        var _a, _b, _c, _d;
        const updatedOptions = {
            xml: {
                rootName: (_a = options.xml.rootName) !== null && _a !== void 0 ? _a : "",
                includeRoot: (_b = options.xml.includeRoot) !== null && _b !== void 0 ? _b : false,
                xmlCharKey: (_c = options.xml.xmlCharKey) !== null && _c !== void 0 ? _c : XML_CHARKEY,
            },
            ignoreUnknownProperties: (_d = options.ignoreUnknownProperties) !== null && _d !== void 0 ? _d : false,
        };
        if (responseBody === undefined || responseBody === null) {
            if (this.isXML && mapper.type.name === "Sequence" && !mapper.xmlIsWrapped) {
                // Edge case for empty XML non-wrapped lists. xml2js can't distinguish
                // between the list being empty versus being missing,
                // so let's do the more user-friendly thing and return an empty list.
                responseBody = [];
            }
            // specifically check for undefined as default value can be a falsey value `0, "", false, null`
            if (mapper.defaultValue !== undefined) {
                responseBody = mapper.defaultValue;
            }
            return responseBody;
        }
        let payload;
        const mapperType = mapper.type.name;
        if (!objectName) {
            objectName = mapper.serializedName;
        }
        if (mapperType.match(/^Composite$/i) !== null) {
            payload = deserializeCompositeType(this, mapper, responseBody, objectName, updatedOptions);
        }
        else {
            if (this.isXML) {
                const xmlCharKey = updatedOptions.xml.xmlCharKey;
                /**
                 * If the mapper specifies this as a non-composite type value but the responseBody contains
                 * both header ("$" i.e., XML_ATTRKEY) and body ("#" i.e., XML_CHARKEY) properties,
                 * then just reduce the responseBody value to the body ("#" i.e., XML_CHARKEY) property.
                 */
                if (responseBody[XML_ATTRKEY] !== undefined && responseBody[xmlCharKey] !== undefined) {
                    responseBody = responseBody[xmlCharKey];
                }
            }
            if (mapperType.match(/^Number$/i) !== null) {
                payload = parseFloat(responseBody);
                if (isNaN(payload)) {
                    payload = responseBody;
                }
            }
            else if (mapperType.match(/^Boolean$/i) !== null) {
                if (responseBody === "true") {
                    payload = true;
                }
                else if (responseBody === "false") {
                    payload = false;
                }
                else {
                    payload = responseBody;
                }
            }
            else if (mapperType.match(/^(String|Enum|Object|Stream|Uuid|TimeSpan|any)$/i) !== null) {
                payload = responseBody;
            }
            else if (mapperType.match(/^(Date|DateTime|DateTimeRfc1123)$/i) !== null) {
                payload = new Date(responseBody);
            }
            else if (mapperType.match(/^UnixTime$/i) !== null) {
                payload = unixTimeToDate(responseBody);
            }
            else if (mapperType.match(/^ByteArray$/i) !== null) {
                payload = decodeString(responseBody);
            }
            else if (mapperType.match(/^Base64Url$/i) !== null) {
                payload = base64UrlToByteArray(responseBody);
            }
            else if (mapperType.match(/^Sequence$/i) !== null) {
                payload = deserializeSequenceType(this, mapper, responseBody, objectName, updatedOptions);
            }
            else if (mapperType.match(/^Dictionary$/i) !== null) {
                payload = deserializeDictionaryType(this, mapper, responseBody, objectName, updatedOptions);
            }
        }
        if (mapper.isConstant) {
            payload = mapper.defaultValue;
        }
        return payload;
    }
}
/**
 * Method that creates and returns a Serializer.
 * @param modelMappers - Known models to map
 * @param isXML - If XML should be supported
 */
function createSerializer(modelMappers = {}, isXML = false) {
    return new SerializerImpl(modelMappers, isXML);
}
function trimEnd(str, ch) {
    let len = str.length;
    while (len - 1 >= 0 && str[len - 1] === ch) {
        --len;
    }
    return str.substr(0, len);
}
function bufferToBase64Url(buffer) {
    if (!buffer) {
        return undefined;
    }
    if (!(buffer instanceof Uint8Array)) {
        throw new Error(`Please provide an input of type Uint8Array for converting to Base64Url.`);
    }
    // Uint8Array to Base64.
    const str = encodeByteArray(buffer);
    // Base64 to Base64Url.
    return trimEnd(str, "=").replace(/\+/g, "-").replace(/\//g, "_");
}
function base64UrlToByteArray(str) {
    if (!str) {
        return undefined;
    }
    if (str && typeof str.valueOf() !== "string") {
        throw new Error("Please provide an input of type string for converting to Uint8Array");
    }
    // Base64Url to Base64.
    str = str.replace(/-/g, "+").replace(/_/g, "/");
    // Base64 to Uint8Array.
    return decodeString(str);
}
function splitSerializeName(prop) {
    const classes = [];
    let partialclass = "";
    if (prop) {
        const subwords = prop.split(".");
        for (const item of subwords) {
            if (item.charAt(item.length - 1) === "\\") {
                partialclass += item.substr(0, item.length - 1) + ".";
            }
            else {
                partialclass += item;
                classes.push(partialclass);
                partialclass = "";
            }
        }
    }
    return classes;
}
function dateToUnixTime(d) {
    if (!d) {
        return undefined;
    }
    if (typeof d.valueOf() === "string") {
        d = new Date(d);
    }
    return Math.floor(d.getTime() / 1000);
}
function unixTimeToDate(n) {
    if (!n) {
        return undefined;
    }
    return new Date(n * 1000);
}
function serializeBasicTypes(typeName, objectName, value) {
    if (value !== null && value !== undefined) {
        if (typeName.match(/^Number$/i) !== null) {
            if (typeof value !== "number") {
                throw new Error(`${objectName} with value ${value} must be of type number.`);
            }
        }
        else if (typeName.match(/^String$/i) !== null) {
            if (typeof value.valueOf() !== "string") {
                throw new Error(`${objectName} with value "${value}" must be of type string.`);
            }
        }
        else if (typeName.match(/^Uuid$/i) !== null) {
            if (!(typeof value.valueOf() === "string" && isValidUuid(value))) {
                throw new Error(`${objectName} with value "${value}" must be of type string and a valid uuid.`);
            }
        }
        else if (typeName.match(/^Boolean$/i) !== null) {
            if (typeof value !== "boolean") {
                throw new Error(`${objectName} with value ${value} must be of type boolean.`);
            }
        }
        else if (typeName.match(/^Stream$/i) !== null) {
            const objectType = typeof value;
            if (objectType !== "string" &&
                typeof value.pipe !== "function" && // NodeJS.ReadableStream
                typeof value.tee !== "function" && // browser ReadableStream
                !(value instanceof ArrayBuffer) &&
                !ArrayBuffer.isView(value) &&
                // File objects count as a type of Blob, so we want to use instanceof explicitly
                !((typeof Blob === "function" || typeof Blob === "object") && value instanceof Blob) &&
                objectType !== "function") {
                throw new Error(`${objectName} must be a string, Blob, ArrayBuffer, ArrayBufferView, ReadableStream, or () => ReadableStream.`);
            }
        }
    }
    return value;
}
function serializeEnumType(objectName, allowedValues, value) {
    if (!allowedValues) {
        throw new Error(`Please provide a set of allowedValues to validate ${objectName} as an Enum Type.`);
    }
    const isPresent = allowedValues.some((item) => {
        if (typeof item.valueOf() === "string") {
            return item.toLowerCase() === value.toLowerCase();
        }
        return item === value;
    });
    if (!isPresent) {
        throw new Error(`${value} is not a valid value for ${objectName}. The valid values are: ${JSON.stringify(allowedValues)}.`);
    }
    return value;
}
function serializeByteArrayType(objectName, value) {
    if (value !== undefined && value !== null) {
        if (!(value instanceof Uint8Array)) {
            throw new Error(`${objectName} must be of type Uint8Array.`);
        }
        value = encodeByteArray(value);
    }
    return value;
}
function serializeBase64UrlType(objectName, value) {
    if (value !== undefined && value !== null) {
        if (!(value instanceof Uint8Array)) {
            throw new Error(`${objectName} must be of type Uint8Array.`);
        }
        value = bufferToBase64Url(value);
    }
    return value;
}
function serializeDateTypes(typeName, value, objectName) {
    if (value !== undefined && value !== null) {
        if (typeName.match(/^Date$/i) !== null) {
            if (!(value instanceof Date ||
                (typeof value.valueOf() === "string" && !isNaN(Date.parse(value))))) {
                throw new Error(`${objectName} must be an instanceof Date or a string in ISO8601 format.`);
            }
            value =
                value instanceof Date
                    ? value.toISOString().substring(0, 10)
                    : new Date(value).toISOString().substring(0, 10);
        }
        else if (typeName.match(/^DateTime$/i) !== null) {
            if (!(value instanceof Date ||
                (typeof value.valueOf() === "string" && !isNaN(Date.parse(value))))) {
                throw new Error(`${objectName} must be an instanceof Date or a string in ISO8601 format.`);
            }
            value = value instanceof Date ? value.toISOString() : new Date(value).toISOString();
        }
        else if (typeName.match(/^DateTimeRfc1123$/i) !== null) {
            if (!(value instanceof Date ||
                (typeof value.valueOf() === "string" && !isNaN(Date.parse(value))))) {
                throw new Error(`${objectName} must be an instanceof Date or a string in RFC-1123 format.`);
            }
            value = value instanceof Date ? value.toUTCString() : new Date(value).toUTCString();
        }
        else if (typeName.match(/^UnixTime$/i) !== null) {
            if (!(value instanceof Date ||
                (typeof value.valueOf() === "string" && !isNaN(Date.parse(value))))) {
                throw new Error(`${objectName} must be an instanceof Date or a string in RFC-1123/ISO8601 format ` +
                    `for it to be serialized in UnixTime/Epoch format.`);
            }
            value = dateToUnixTime(value);
        }
        else if (typeName.match(/^TimeSpan$/i) !== null) {
            if (!isDuration(value)) {
                throw new Error(`${objectName} must be a string in ISO 8601 format. Instead was "${value}".`);
            }
        }
    }
    return value;
}
function serializeSequenceType(serializer, mapper, object, objectName, isXml, options) {
    var _a;
    if (!Array.isArray(object)) {
        throw new Error(`${objectName} must be of type Array.`);
    }
    let elementType = mapper.type.element;
    if (!elementType || typeof elementType !== "object") {
        throw new Error(`element" metadata for an Array must be defined in the ` +
            `mapper and it must of type "object" in ${objectName}.`);
    }
    // Quirk: Composite mappers referenced by `element` might
    // not have *all* properties declared (like uberParent),
    // so let's try to look up the full definition by name.
    if (elementType.type.name === "Composite" && elementType.type.className) {
        elementType = (_a = serializer.modelMappers[elementType.type.className]) !== null && _a !== void 0 ? _a : elementType;
    }
    const tempArray = [];
    for (let i = 0; i < object.length; i++) {
        const serializedValue = serializer.serialize(elementType, object[i], objectName, options);
        if (isXml && elementType.xmlNamespace) {
            const xmlnsKey = elementType.xmlNamespacePrefix
                ? `xmlns:${elementType.xmlNamespacePrefix}`
                : "xmlns";
            if (elementType.type.name === "Composite") {
                tempArray[i] = Object.assign({}, serializedValue);
                tempArray[i][XML_ATTRKEY] = { [xmlnsKey]: elementType.xmlNamespace };
            }
            else {
                tempArray[i] = {};
                tempArray[i][options.xml.xmlCharKey] = serializedValue;
                tempArray[i][XML_ATTRKEY] = { [xmlnsKey]: elementType.xmlNamespace };
            }
        }
        else {
            tempArray[i] = serializedValue;
        }
    }
    return tempArray;
}
function serializeDictionaryType(serializer, mapper, object, objectName, isXml, options) {
    if (typeof object !== "object") {
        throw new Error(`${objectName} must be of type object.`);
    }
    const valueType = mapper.type.value;
    if (!valueType || typeof valueType !== "object") {
        throw new Error(`"value" metadata for a Dictionary must be defined in the ` +
            `mapper and it must of type "object" in ${objectName}.`);
    }
    const tempDictionary = {};
    for (const key of Object.keys(object)) {
        const serializedValue = serializer.serialize(valueType, object[key], objectName, options);
        // If the element needs an XML namespace we need to add it within the $ property
        tempDictionary[key] = getXmlObjectValue(valueType, serializedValue, isXml, options);
    }
    // Add the namespace to the root element if needed
    if (isXml && mapper.xmlNamespace) {
        const xmlnsKey = mapper.xmlNamespacePrefix ? `xmlns:${mapper.xmlNamespacePrefix}` : "xmlns";
        const result = tempDictionary;
        result[XML_ATTRKEY] = { [xmlnsKey]: mapper.xmlNamespace };
        return result;
    }
    return tempDictionary;
}
/**
 * Resolves the additionalProperties property from a referenced mapper
 * @param serializer - the serializer containing the entire set of mappers
 * @param mapper - the composite mapper to resolve
 * @param objectName - name of the object being serialized
 */
function resolveAdditionalProperties(serializer, mapper, objectName) {
    const additionalProperties = mapper.type.additionalProperties;
    if (!additionalProperties && mapper.type.className) {
        const modelMapper = resolveReferencedMapper(serializer, mapper, objectName);
        return modelMapper === null || modelMapper === void 0 ? void 0 : modelMapper.type.additionalProperties;
    }
    return additionalProperties;
}
/**
 * Finds the mapper referenced by className
 * @param serializer - the serializer containing the entire set of mappers
 * @param mapper - the composite mapper to resolve
 * @param objectName - name of the object being serialized
 */
function resolveReferencedMapper(serializer, mapper, objectName) {
    const className = mapper.type.className;
    if (!className) {
        throw new Error(`Class name for model "${objectName}" is not provided in the mapper "${JSON.stringify(mapper, undefined, 2)}".`);
    }
    return serializer.modelMappers[className];
}
/**
 * Resolves a composite mapper's modelProperties.
 * @param serializer - the serializer containing the entire set of mappers
 * @param mapper - the composite mapper to resolve
 */
function resolveModelProperties(serializer, mapper, objectName) {
    let modelProps = mapper.type.modelProperties;
    if (!modelProps) {
        const modelMapper = resolveReferencedMapper(serializer, mapper, objectName);
        if (!modelMapper) {
            throw new Error(`mapper() cannot be null or undefined for model "${mapper.type.className}".`);
        }
        modelProps = modelMapper === null || modelMapper === void 0 ? void 0 : modelMapper.type.modelProperties;
        if (!modelProps) {
            throw new Error(`modelProperties cannot be null or undefined in the ` +
                `mapper "${JSON.stringify(modelMapper)}" of type "${mapper.type.className}" for object "${objectName}".`);
        }
    }
    return modelProps;
}
function serializeCompositeType(serializer, mapper, object, objectName, isXml, options) {
    if (getPolymorphicDiscriminatorRecursively(serializer, mapper)) {
        mapper = getPolymorphicMapper(serializer, mapper, object, "clientName");
    }
    if (object !== undefined && object !== null) {
        const payload = {};
        const modelProps = resolveModelProperties(serializer, mapper, objectName);
        for (const key of Object.keys(modelProps)) {
            const propertyMapper = modelProps[key];
            if (propertyMapper.readOnly) {
                continue;
            }
            let propName;
            let parentObject = payload;
            if (serializer.isXML) {
                if (propertyMapper.xmlIsWrapped) {
                    propName = propertyMapper.xmlName;
                }
                else {
                    propName = propertyMapper.xmlElementName || propertyMapper.xmlName;
                }
            }
            else {
                const paths = splitSerializeName(propertyMapper.serializedName);
                propName = paths.pop();
                for (const pathName of paths) {
                    const childObject = parentObject[pathName];
                    if ((childObject === undefined || childObject === null) &&
                        ((object[key] !== undefined && object[key] !== null) ||
                            propertyMapper.defaultValue !== undefined)) {
                        parentObject[pathName] = {};
                    }
                    parentObject = parentObject[pathName];
                }
            }
            if (parentObject !== undefined && parentObject !== null) {
                if (isXml && mapper.xmlNamespace) {
                    const xmlnsKey = mapper.xmlNamespacePrefix
                        ? `xmlns:${mapper.xmlNamespacePrefix}`
                        : "xmlns";
                    parentObject[XML_ATTRKEY] = Object.assign(Object.assign({}, parentObject[XML_ATTRKEY]), { [xmlnsKey]: mapper.xmlNamespace });
                }
                const propertyObjectName = propertyMapper.serializedName !== ""
                    ? objectName + "." + propertyMapper.serializedName
                    : objectName;
                let toSerialize = object[key];
                const polymorphicDiscriminator = getPolymorphicDiscriminatorRecursively(serializer, mapper);
                if (polymorphicDiscriminator &&
                    polymorphicDiscriminator.clientName === key &&
                    (toSerialize === undefined || toSerialize === null)) {
                    toSerialize = mapper.serializedName;
                }
                const serializedValue = serializer.serialize(propertyMapper, toSerialize, propertyObjectName, options);
                if (serializedValue !== undefined && propName !== undefined && propName !== null) {
                    const value = getXmlObjectValue(propertyMapper, serializedValue, isXml, options);
                    if (isXml && propertyMapper.xmlIsAttribute) {
                        // XML_ATTRKEY, i.e., $ is the key attributes are kept under in xml2js.
                        // This keeps things simple while preventing name collision
                        // with names in user documents.
                        parentObject[XML_ATTRKEY] = parentObject[XML_ATTRKEY] || {};
                        parentObject[XML_ATTRKEY][propName] = serializedValue;
                    }
                    else if (isXml && propertyMapper.xmlIsWrapped) {
                        parentObject[propName] = { [propertyMapper.xmlElementName]: value };
                    }
                    else {
                        parentObject[propName] = value;
                    }
                }
            }
        }
        const additionalPropertiesMapper = resolveAdditionalProperties(serializer, mapper, objectName);
        if (additionalPropertiesMapper) {
            const propNames = Object.keys(modelProps);
            for (const clientPropName in object) {
                const isAdditionalProperty = propNames.every((pn) => pn !== clientPropName);
                if (isAdditionalProperty) {
                    payload[clientPropName] = serializer.serialize(additionalPropertiesMapper, object[clientPropName], objectName + '["' + clientPropName + '"]', options);
                }
            }
        }
        return payload;
    }
    return object;
}
function getXmlObjectValue(propertyMapper, serializedValue, isXml, options) {
    if (!isXml || !propertyMapper.xmlNamespace) {
        return serializedValue;
    }
    const xmlnsKey = propertyMapper.xmlNamespacePrefix
        ? `xmlns:${propertyMapper.xmlNamespacePrefix}`
        : "xmlns";
    const xmlNamespace = { [xmlnsKey]: propertyMapper.xmlNamespace };
    if (["Composite"].includes(propertyMapper.type.name)) {
        if (serializedValue[XML_ATTRKEY]) {
            return serializedValue;
        }
        else {
            const result = Object.assign({}, serializedValue);
            result[XML_ATTRKEY] = xmlNamespace;
            return result;
        }
    }
    const result = {};
    result[options.xml.xmlCharKey] = serializedValue;
    result[XML_ATTRKEY] = xmlNamespace;
    return result;
}
function isSpecialXmlProperty(propertyName, options) {
    return [XML_ATTRKEY, options.xml.xmlCharKey].includes(propertyName);
}
function deserializeCompositeType(serializer, mapper, responseBody, objectName, options) {
    var _a, _b;
    const xmlCharKey = (_a = options.xml.xmlCharKey) !== null && _a !== void 0 ? _a : XML_CHARKEY;
    if (getPolymorphicDiscriminatorRecursively(serializer, mapper)) {
        mapper = getPolymorphicMapper(serializer, mapper, responseBody, "serializedName");
    }
    const modelProps = resolveModelProperties(serializer, mapper, objectName);
    let instance = {};
    const handledPropertyNames = [];
    for (const key of Object.keys(modelProps)) {
        const propertyMapper = modelProps[key];
        const paths = splitSerializeName(modelProps[key].serializedName);
        handledPropertyNames.push(paths[0]);
        const { serializedName, xmlName, xmlElementName } = propertyMapper;
        let propertyObjectName = objectName;
        if (serializedName !== "" && serializedName !== undefined) {
            propertyObjectName = objectName + "." + serializedName;
        }
        const headerCollectionPrefix = propertyMapper.headerCollectionPrefix;
        if (headerCollectionPrefix) {
            const dictionary = {};
            for (const headerKey of Object.keys(responseBody)) {
                if (headerKey.startsWith(headerCollectionPrefix)) {
                    dictionary[headerKey.substring(headerCollectionPrefix.length)] = serializer.deserialize(propertyMapper.type.value, responseBody[headerKey], propertyObjectName, options);
                }
                handledPropertyNames.push(headerKey);
            }
            instance[key] = dictionary;
        }
        else if (serializer.isXML) {
            if (propertyMapper.xmlIsAttribute && responseBody[XML_ATTRKEY]) {
                instance[key] = serializer.deserialize(propertyMapper, responseBody[XML_ATTRKEY][xmlName], propertyObjectName, options);
            }
            else if (propertyMapper.xmlIsMsText) {
                if (responseBody[xmlCharKey] !== undefined) {
                    instance[key] = responseBody[xmlCharKey];
                }
                else if (typeof responseBody === "string") {
                    // The special case where xml parser parses "<Name>content</Name>" into JSON of
                    //   `{ name: "content"}` instead of `{ name: { "_": "content" }}`
                    instance[key] = responseBody;
                }
            }
            else {
                const propertyName = xmlElementName || xmlName || serializedName;
                if (propertyMapper.xmlIsWrapped) {
                    /* a list of <xmlElementName> wrapped by <xmlName>
                      For the xml example below
                        <Cors>
                          <CorsRule>...</CorsRule>
                          <CorsRule>...</CorsRule>
                        </Cors>
                      the responseBody has
                        {
                          Cors: {
                            CorsRule: [{...}, {...}]
                          }
                        }
                      xmlName is "Cors" and xmlElementName is"CorsRule".
                    */
                    const wrapped = responseBody[xmlName];
                    const elementList = (_b = wrapped === null || wrapped === void 0 ? void 0 : wrapped[xmlElementName]) !== null && _b !== void 0 ? _b : [];
                    instance[key] = serializer.deserialize(propertyMapper, elementList, propertyObjectName, options);
                    handledPropertyNames.push(xmlName);
                }
                else {
                    const property = responseBody[propertyName];
                    instance[key] = serializer.deserialize(propertyMapper, property, propertyObjectName, options);
                    handledPropertyNames.push(propertyName);
                }
            }
        }
        else {
            // deserialize the property if it is present in the provided responseBody instance
            let propertyInstance;
            let res = responseBody;
            // traversing the object step by step.
            let steps = 0;
            for (const item of paths) {
                if (!res)
                    break;
                steps++;
                res = res[item];
            }
            // only accept null when reaching the last position of object otherwise it would be undefined
            if (res === null && steps < paths.length) {
                res = undefined;
            }
            propertyInstance = res;
            const polymorphicDiscriminator = mapper.type.polymorphicDiscriminator;
            // checking that the model property name (key)(ex: "fishtype") and the
            // clientName of the polymorphicDiscriminator {metadata} (ex: "fishtype")
            // instead of the serializedName of the polymorphicDiscriminator (ex: "fish.type")
            // is a better approach. The generator is not consistent with escaping '\.' in the
            // serializedName of the property (ex: "fish\.type") that is marked as polymorphic discriminator
            // and the serializedName of the metadata polymorphicDiscriminator (ex: "fish.type"). However,
            // the clientName transformation of the polymorphicDiscriminator (ex: "fishtype") and
            // the transformation of model property name (ex: "fishtype") is done consistently.
            // Hence, it is a safer bet to rely on the clientName of the polymorphicDiscriminator.
            if (polymorphicDiscriminator &&
                key === polymorphicDiscriminator.clientName &&
                (propertyInstance === undefined || propertyInstance === null)) {
                propertyInstance = mapper.serializedName;
            }
            let serializedValue;
            // paging
            if (Array.isArray(responseBody[key]) && modelProps[key].serializedName === "") {
                propertyInstance = responseBody[key];
                const arrayInstance = serializer.deserialize(propertyMapper, propertyInstance, propertyObjectName, options);
                // Copy over any properties that have already been added into the instance, where they do
                // not exist on the newly de-serialized array
                for (const [k, v] of Object.entries(instance)) {
                    if (!Object.prototype.hasOwnProperty.call(arrayInstance, k)) {
                        arrayInstance[k] = v;
                    }
                }
                instance = arrayInstance;
            }
            else if (propertyInstance !== undefined || propertyMapper.defaultValue !== undefined) {
                serializedValue = serializer.deserialize(propertyMapper, propertyInstance, propertyObjectName, options);
                instance[key] = serializedValue;
            }
        }
    }
    const additionalPropertiesMapper = mapper.type.additionalProperties;
    if (additionalPropertiesMapper) {
        const isAdditionalProperty = (responsePropName) => {
            for (const clientPropName in modelProps) {
                const paths = splitSerializeName(modelProps[clientPropName].serializedName);
                if (paths[0] === responsePropName) {
                    return false;
                }
            }
            return true;
        };
        for (const responsePropName in responseBody) {
            if (isAdditionalProperty(responsePropName)) {
                instance[responsePropName] = serializer.deserialize(additionalPropertiesMapper, responseBody[responsePropName], objectName + '["' + responsePropName + '"]', options);
            }
        }
    }
    else if (responseBody && !options.ignoreUnknownProperties) {
        for (const key of Object.keys(responseBody)) {
            if (instance[key] === undefined &&
                !handledPropertyNames.includes(key) &&
                !isSpecialXmlProperty(key, options)) {
                instance[key] = responseBody[key];
            }
        }
    }
    return instance;
}
function deserializeDictionaryType(serializer, mapper, responseBody, objectName, options) {
    /* jshint validthis: true */
    const value = mapper.type.value;
    if (!value || typeof value !== "object") {
        throw new Error(`"value" metadata for a Dictionary must be defined in the ` +
            `mapper and it must of type "object" in ${objectName}`);
    }
    if (responseBody) {
        const tempDictionary = {};
        for (const key of Object.keys(responseBody)) {
            tempDictionary[key] = serializer.deserialize(value, responseBody[key], objectName, options);
        }
        return tempDictionary;
    }
    return responseBody;
}
function deserializeSequenceType(serializer, mapper, responseBody, objectName, options) {
    var _a;
    let element = mapper.type.element;
    if (!element || typeof element !== "object") {
        throw new Error(`element" metadata for an Array must be defined in the ` +
            `mapper and it must of type "object" in ${objectName}`);
    }
    if (responseBody) {
        if (!Array.isArray(responseBody)) {
            // xml2js will interpret a single element array as just the element, so force it to be an array
            responseBody = [responseBody];
        }
        // Quirk: Composite mappers referenced by `element` might
        // not have *all* properties declared (like uberParent),
        // so let's try to look up the full definition by name.
        if (element.type.name === "Composite" && element.type.className) {
            element = (_a = serializer.modelMappers[element.type.className]) !== null && _a !== void 0 ? _a : element;
        }
        const tempArray = [];
        for (let i = 0; i < responseBody.length; i++) {
            tempArray[i] = serializer.deserialize(element, responseBody[i], `${objectName}[${i}]`, options);
        }
        return tempArray;
    }
    return responseBody;
}
function getIndexDiscriminator(discriminators, discriminatorValue, typeName) {
    const typeNamesToCheck = [typeName];
    while (typeNamesToCheck.length) {
        const currentName = typeNamesToCheck.shift();
        const indexDiscriminator = discriminatorValue === currentName
            ? discriminatorValue
            : currentName + "." + discriminatorValue;
        if (Object.prototype.hasOwnProperty.call(discriminators, indexDiscriminator)) {
            return discriminators[indexDiscriminator];
        }
        else {
            for (const [name, mapper] of Object.entries(discriminators)) {
                if (name.startsWith(currentName + ".") &&
                    mapper.type.uberParent === currentName &&
                    mapper.type.className) {
                    typeNamesToCheck.push(mapper.type.className);
                }
            }
        }
    }
    return undefined;
}
function getPolymorphicMapper(serializer, mapper, object, polymorphicPropertyName) {
    var _a;
    const polymorphicDiscriminator = getPolymorphicDiscriminatorRecursively(serializer, mapper);
    if (polymorphicDiscriminator) {
        let discriminatorName = polymorphicDiscriminator[polymorphicPropertyName];
        if (discriminatorName) {
            // The serializedName might have \\, which we just want to ignore
            if (polymorphicPropertyName === "serializedName") {
                discriminatorName = discriminatorName.replace(/\\/gi, "");
            }
            const discriminatorValue = object[discriminatorName];
            const typeName = (_a = mapper.type.uberParent) !== null && _a !== void 0 ? _a : mapper.type.className;
            if (typeof discriminatorValue === "string" && typeName) {
                const polymorphicMapper = getIndexDiscriminator(serializer.modelMappers.discriminators, discriminatorValue, typeName);
                if (polymorphicMapper) {
                    mapper = polymorphicMapper;
                }
            }
        }
    }
    return mapper;
}
function getPolymorphicDiscriminatorRecursively(serializer, mapper) {
    return (mapper.type.polymorphicDiscriminator ||
        getPolymorphicDiscriminatorSafely(serializer, mapper.type.uberParent) ||
        getPolymorphicDiscriminatorSafely(serializer, mapper.type.className));
}
function getPolymorphicDiscriminatorSafely(serializer, typeName) {
    return (typeName &&
        serializer.modelMappers[typeName] &&
        serializer.modelMappers[typeName].type.polymorphicDiscriminator);
}
/**
 * Known types of Mappers
 */
const MapperTypeNames = {
    Base64Url: "Base64Url",
    Boolean: "Boolean",
    ByteArray: "ByteArray",
    Composite: "Composite",
    Date: "Date",
    DateTime: "DateTime",
    DateTimeRfc1123: "DateTimeRfc1123",
    Dictionary: "Dictionary",
    Enum: "Enum",
    Number: "Number",
    Object: "Object",
    Sequence: "Sequence",
    String: "String",
    Stream: "Stream",
    TimeSpan: "TimeSpan",
    UnixTime: "UnixTime",
};
//# sourceMappingURL=serializer.js.map
// EXTERNAL MODULE: ./node_modules/@azure/core-client/dist/commonjs/state.js
var state = __webpack_require__(53076);
;// ./node_modules/@azure/core-client/dist/esm/state.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
// @ts-expect-error The recommended approach to sharing module state between ESM and CJS.
// See https://github.com/isaacs/tshy/blob/main/README.md#module-local-state for additional information.

/**
 * Defines the shared state between CJS and ESM by re-exporting the CJS state.
 */
const state_state = state/* state */.w;
//# sourceMappingURL=state.js.map
;// ./node_modules/@azure/core-client/dist/esm/operationHelpers.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

/**
 * @internal
 * Retrieves the value to use for a given operation argument
 * @param operationArguments - The arguments passed from the generated client
 * @param parameter - The parameter description
 * @param fallbackObject - If something isn't found in the arguments bag, look here.
 *  Generally used to look at the service client properties.
 */
function getOperationArgumentValueFromParameter(operationArguments, parameter, fallbackObject) {
    let parameterPath = parameter.parameterPath;
    const parameterMapper = parameter.mapper;
    let value;
    if (typeof parameterPath === "string") {
        parameterPath = [parameterPath];
    }
    if (Array.isArray(parameterPath)) {
        if (parameterPath.length > 0) {
            if (parameterMapper.isConstant) {
                value = parameterMapper.defaultValue;
            }
            else {
                let propertySearchResult = getPropertyFromParameterPath(operationArguments, parameterPath);
                if (!propertySearchResult.propertyFound && fallbackObject) {
                    propertySearchResult = getPropertyFromParameterPath(fallbackObject, parameterPath);
                }
                let useDefaultValue = false;
                if (!propertySearchResult.propertyFound) {
                    useDefaultValue =
                        parameterMapper.required ||
                            (parameterPath[0] === "options" && parameterPath.length === 2);
                }
                value = useDefaultValue ? parameterMapper.defaultValue : propertySearchResult.propertyValue;
            }
        }
    }
    else {
        if (parameterMapper.required) {
            value = {};
        }
        for (const propertyName in parameterPath) {
            const propertyMapper = parameterMapper.type.modelProperties[propertyName];
            const propertyPath = parameterPath[propertyName];
            const propertyValue = getOperationArgumentValueFromParameter(operationArguments, {
                parameterPath: propertyPath,
                mapper: propertyMapper,
            }, fallbackObject);
            if (propertyValue !== undefined) {
                if (!value) {
                    value = {};
                }
                value[propertyName] = propertyValue;
            }
        }
    }
    return value;
}
function getPropertyFromParameterPath(parent, parameterPath) {
    const result = { propertyFound: false };
    let i = 0;
    for (; i < parameterPath.length; ++i) {
        const parameterPathPart = parameterPath[i];
        // Make sure to check inherited properties too, so don't use hasOwnProperty().
        if (parent && parameterPathPart in parent) {
            parent = parent[parameterPathPart];
        }
        else {
            break;
        }
    }
    if (i === parameterPath.length) {
        result.propertyValue = parent;
        result.propertyFound = true;
    }
    return result;
}
const originalRequestSymbol = Symbol.for("@azure/core-client original request");
function hasOriginalRequest(request) {
    return originalRequestSymbol in request;
}
function getOperationRequestInfo(request) {
    if (hasOriginalRequest(request)) {
        return getOperationRequestInfo(request[originalRequestSymbol]);
    }
    let info = state_state.operationRequestMap.get(request);
    if (!info) {
        info = {};
        state_state.operationRequestMap.set(request, info);
    }
    return info;
}
//# sourceMappingURL=operationHelpers.js.map
;// ./node_modules/@azure/core-client/dist/esm/deserializationPolicy.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.




const defaultJsonContentTypes = ["application/json", "text/json"];
const defaultXmlContentTypes = ["application/xml", "application/atom+xml"];
/**
 * The programmatic identifier of the deserializationPolicy.
 */
const deserializationPolicyName = "deserializationPolicy";
/**
 * This policy handles parsing out responses according to OperationSpecs on the request.
 */
function deserializationPolicy(options = {}) {
    var _a, _b, _c, _d, _e, _f, _g;
    const jsonContentTypes = (_b = (_a = options.expectedContentTypes) === null || _a === void 0 ? void 0 : _a.json) !== null && _b !== void 0 ? _b : defaultJsonContentTypes;
    const xmlContentTypes = (_d = (_c = options.expectedContentTypes) === null || _c === void 0 ? void 0 : _c.xml) !== null && _d !== void 0 ? _d : defaultXmlContentTypes;
    const parseXML = options.parseXML;
    const serializerOptions = options.serializerOptions;
    const updatedOptions = {
        xml: {
            rootName: (_e = serializerOptions === null || serializerOptions === void 0 ? void 0 : serializerOptions.xml.rootName) !== null && _e !== void 0 ? _e : "",
            includeRoot: (_f = serializerOptions === null || serializerOptions === void 0 ? void 0 : serializerOptions.xml.includeRoot) !== null && _f !== void 0 ? _f : false,
            xmlCharKey: (_g = serializerOptions === null || serializerOptions === void 0 ? void 0 : serializerOptions.xml.xmlCharKey) !== null && _g !== void 0 ? _g : XML_CHARKEY,
        },
    };
    return {
        name: deserializationPolicyName,
        async sendRequest(request, next) {
            const response = await next(request);
            return deserializeResponseBody(jsonContentTypes, xmlContentTypes, response, updatedOptions, parseXML);
        },
    };
}
function getOperationResponseMap(parsedResponse) {
    let result;
    const request = parsedResponse.request;
    const operationInfo = getOperationRequestInfo(request);
    const operationSpec = operationInfo === null || operationInfo === void 0 ? void 0 : operationInfo.operationSpec;
    if (operationSpec) {
        if (!(operationInfo === null || operationInfo === void 0 ? void 0 : operationInfo.operationResponseGetter)) {
            result = operationSpec.responses[parsedResponse.status];
        }
        else {
            result = operationInfo === null || operationInfo === void 0 ? void 0 : operationInfo.operationResponseGetter(operationSpec, parsedResponse);
        }
    }
    return result;
}
function shouldDeserializeResponse(parsedResponse) {
    const request = parsedResponse.request;
    const operationInfo = getOperationRequestInfo(request);
    const shouldDeserialize = operationInfo === null || operationInfo === void 0 ? void 0 : operationInfo.shouldDeserialize;
    let result;
    if (shouldDeserialize === undefined) {
        result = true;
    }
    else if (typeof shouldDeserialize === "boolean") {
        result = shouldDeserialize;
    }
    else {
        result = shouldDeserialize(parsedResponse);
    }
    return result;
}
async function deserializeResponseBody(jsonContentTypes, xmlContentTypes, response, options, parseXML) {
    const parsedResponse = await parse(jsonContentTypes, xmlContentTypes, response, options, parseXML);
    if (!shouldDeserializeResponse(parsedResponse)) {
        return parsedResponse;
    }
    const operationInfo = getOperationRequestInfo(parsedResponse.request);
    const operationSpec = operationInfo === null || operationInfo === void 0 ? void 0 : operationInfo.operationSpec;
    if (!operationSpec || !operationSpec.responses) {
        return parsedResponse;
    }
    const responseSpec = getOperationResponseMap(parsedResponse);
    const { error, shouldReturnResponse } = handleErrorResponse(parsedResponse, operationSpec, responseSpec, options);
    if (error) {
        throw error;
    }
    else if (shouldReturnResponse) {
        return parsedResponse;
    }
    // An operation response spec does exist for current status code, so
    // use it to deserialize the response.
    if (responseSpec) {
        if (responseSpec.bodyMapper) {
            let valueToDeserialize = parsedResponse.parsedBody;
            if (operationSpec.isXML && responseSpec.bodyMapper.type.name === MapperTypeNames.Sequence) {
                valueToDeserialize =
                    typeof valueToDeserialize === "object"
                        ? valueToDeserialize[responseSpec.bodyMapper.xmlElementName]
                        : [];
            }
            try {
                parsedResponse.parsedBody = operationSpec.serializer.deserialize(responseSpec.bodyMapper, valueToDeserialize, "operationRes.parsedBody", options);
            }
            catch (deserializeError) {
                const restError = new core_rest_pipeline_dist_esm/* RestError */.pj(`Error ${deserializeError} occurred in deserializing the responseBody - ${parsedResponse.bodyAsText}`, {
                    statusCode: parsedResponse.status,
                    request: parsedResponse.request,
                    response: parsedResponse,
                });
                throw restError;
            }
        }
        else if (operationSpec.httpMethod === "HEAD") {
            // head methods never have a body, but we return a boolean to indicate presence/absence of the resource
            parsedResponse.parsedBody = response.status >= 200 && response.status < 300;
        }
        if (responseSpec.headersMapper) {
            parsedResponse.parsedHeaders = operationSpec.serializer.deserialize(responseSpec.headersMapper, parsedResponse.headers.toJSON(), "operationRes.parsedHeaders", { xml: {}, ignoreUnknownProperties: true });
        }
    }
    return parsedResponse;
}
function isOperationSpecEmpty(operationSpec) {
    const expectedStatusCodes = Object.keys(operationSpec.responses);
    return (expectedStatusCodes.length === 0 ||
        (expectedStatusCodes.length === 1 && expectedStatusCodes[0] === "default"));
}
function handleErrorResponse(parsedResponse, operationSpec, responseSpec, options) {
    var _a, _b, _c, _d, _e;
    const isSuccessByStatus = 200 <= parsedResponse.status && parsedResponse.status < 300;
    const isExpectedStatusCode = isOperationSpecEmpty(operationSpec)
        ? isSuccessByStatus
        : !!responseSpec;
    if (isExpectedStatusCode) {
        if (responseSpec) {
            if (!responseSpec.isError) {
                return { error: null, shouldReturnResponse: false };
            }
        }
        else {
            return { error: null, shouldReturnResponse: false };
        }
    }
    const errorResponseSpec = responseSpec !== null && responseSpec !== void 0 ? responseSpec : operationSpec.responses.default;
    const initialErrorMessage = ((_a = parsedResponse.request.streamResponseStatusCodes) === null || _a === void 0 ? void 0 : _a.has(parsedResponse.status))
        ? `Unexpected status code: ${parsedResponse.status}`
        : parsedResponse.bodyAsText;
    const error = new core_rest_pipeline_dist_esm/* RestError */.pj(initialErrorMessage, {
        statusCode: parsedResponse.status,
        request: parsedResponse.request,
        response: parsedResponse,
    });
    // If the item failed but there's no error spec or default spec to deserialize the error,
    // and the parsed body doesn't look like an error object,
    // we should fail so we just throw the parsed response
    if (!errorResponseSpec &&
        !(((_c = (_b = parsedResponse.parsedBody) === null || _b === void 0 ? void 0 : _b.error) === null || _c === void 0 ? void 0 : _c.code) && ((_e = (_d = parsedResponse.parsedBody) === null || _d === void 0 ? void 0 : _d.error) === null || _e === void 0 ? void 0 : _e.message))) {
        throw error;
    }
    const defaultBodyMapper = errorResponseSpec === null || errorResponseSpec === void 0 ? void 0 : errorResponseSpec.bodyMapper;
    const defaultHeadersMapper = errorResponseSpec === null || errorResponseSpec === void 0 ? void 0 : errorResponseSpec.headersMapper;
    try {
        // If error response has a body, try to deserialize it using default body mapper.
        // Then try to extract error code & message from it
        if (parsedResponse.parsedBody) {
            const parsedBody = parsedResponse.parsedBody;
            let deserializedError;
            if (defaultBodyMapper) {
                let valueToDeserialize = parsedBody;
                if (operationSpec.isXML && defaultBodyMapper.type.name === MapperTypeNames.Sequence) {
                    valueToDeserialize = [];
                    const elementName = defaultBodyMapper.xmlElementName;
                    if (typeof parsedBody === "object" && elementName) {
                        valueToDeserialize = parsedBody[elementName];
                    }
                }
                deserializedError = operationSpec.serializer.deserialize(defaultBodyMapper, valueToDeserialize, "error.response.parsedBody", options);
            }
            const internalError = parsedBody.error || deserializedError || parsedBody;
            error.code = internalError.code;
            if (internalError.message) {
                error.message = internalError.message;
            }
            if (defaultBodyMapper) {
                error.response.parsedBody = deserializedError;
            }
        }
        // If error response has headers, try to deserialize it using default header mapper
        if (parsedResponse.headers && defaultHeadersMapper) {
            error.response.parsedHeaders =
                operationSpec.serializer.deserialize(defaultHeadersMapper, parsedResponse.headers.toJSON(), "operationRes.parsedHeaders");
        }
    }
    catch (defaultError) {
        error.message = `Error "${defaultError.message}" occurred in deserializing the responseBody - "${parsedResponse.bodyAsText}" for the default response.`;
    }
    return { error, shouldReturnResponse: false };
}
async function parse(jsonContentTypes, xmlContentTypes, operationResponse, opts, parseXML) {
    var _a;
    if (!((_a = operationResponse.request.streamResponseStatusCodes) === null || _a === void 0 ? void 0 : _a.has(operationResponse.status)) &&
        operationResponse.bodyAsText) {
        const text = operationResponse.bodyAsText;
        const contentType = operationResponse.headers.get("Content-Type") || "";
        const contentComponents = !contentType
            ? []
            : contentType.split(";").map((component) => component.toLowerCase());
        try {
            if (contentComponents.length === 0 ||
                contentComponents.some((component) => jsonContentTypes.indexOf(component) !== -1)) {
                operationResponse.parsedBody = JSON.parse(text);
                return operationResponse;
            }
            else if (contentComponents.some((component) => xmlContentTypes.indexOf(component) !== -1)) {
                if (!parseXML) {
                    throw new Error("Parsing XML not supported.");
                }
                const body = await parseXML(text, opts.xml);
                operationResponse.parsedBody = body;
                return operationResponse;
            }
        }
        catch (err) {
            const msg = `Error "${err}" occurred while parsing the response body - ${operationResponse.bodyAsText}.`;
            const errCode = err.code || core_rest_pipeline_dist_esm/* RestError */.pj.PARSE_ERROR;
            const e = new core_rest_pipeline_dist_esm/* RestError */.pj(msg, {
                code: errCode,
                statusCode: operationResponse.status,
                request: operationResponse.request,
                response: operationResponse,
            });
            throw e;
        }
    }
    return operationResponse;
}
//# sourceMappingURL=deserializationPolicy.js.map
;// ./node_modules/@azure/core-client/dist/esm/interfaceHelpers.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

/**
 * Gets the list of status codes for streaming responses.
 * @internal
 */
function getStreamingResponseStatusCodes(operationSpec) {
    const result = new Set();
    for (const statusCode in operationSpec.responses) {
        const operationResponse = operationSpec.responses[statusCode];
        if (operationResponse.bodyMapper &&
            operationResponse.bodyMapper.type.name === MapperTypeNames.Stream) {
            result.add(Number(statusCode));
        }
    }
    return result;
}
/**
 * Get the path to this parameter's value as a dotted string (a.b.c).
 * @param parameter - The parameter to get the path string for.
 * @returns The path to this parameter's value as a dotted string.
 * @internal
 */
function getPathStringFromParameter(parameter) {
    const { parameterPath, mapper } = parameter;
    let result;
    if (typeof parameterPath === "string") {
        result = parameterPath;
    }
    else if (Array.isArray(parameterPath)) {
        result = parameterPath.join(".");
    }
    else {
        result = mapper.serializedName;
    }
    return result;
}
//# sourceMappingURL=interfaceHelpers.js.map
;// ./node_modules/@azure/core-client/dist/esm/serializationPolicy.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.




/**
 * The programmatic identifier of the serializationPolicy.
 */
const serializationPolicyName = "serializationPolicy";
/**
 * This policy handles assembling the request body and headers using
 * an OperationSpec and OperationArguments on the request.
 */
function serializationPolicy(options = {}) {
    const stringifyXML = options.stringifyXML;
    return {
        name: serializationPolicyName,
        async sendRequest(request, next) {
            const operationInfo = getOperationRequestInfo(request);
            const operationSpec = operationInfo === null || operationInfo === void 0 ? void 0 : operationInfo.operationSpec;
            const operationArguments = operationInfo === null || operationInfo === void 0 ? void 0 : operationInfo.operationArguments;
            if (operationSpec && operationArguments) {
                serializeHeaders(request, operationArguments, operationSpec);
                serializeRequestBody(request, operationArguments, operationSpec, stringifyXML);
            }
            return next(request);
        },
    };
}
/**
 * @internal
 */
function serializeHeaders(request, operationArguments, operationSpec) {
    var _a, _b;
    if (operationSpec.headerParameters) {
        for (const headerParameter of operationSpec.headerParameters) {
            let headerValue = getOperationArgumentValueFromParameter(operationArguments, headerParameter);
            if ((headerValue !== null && headerValue !== undefined) || headerParameter.mapper.required) {
                headerValue = operationSpec.serializer.serialize(headerParameter.mapper, headerValue, getPathStringFromParameter(headerParameter));
                const headerCollectionPrefix = headerParameter.mapper
                    .headerCollectionPrefix;
                if (headerCollectionPrefix) {
                    for (const key of Object.keys(headerValue)) {
                        request.headers.set(headerCollectionPrefix + key, headerValue[key]);
                    }
                }
                else {
                    request.headers.set(headerParameter.mapper.serializedName || getPathStringFromParameter(headerParameter), headerValue);
                }
            }
        }
    }
    const customHeaders = (_b = (_a = operationArguments.options) === null || _a === void 0 ? void 0 : _a.requestOptions) === null || _b === void 0 ? void 0 : _b.customHeaders;
    if (customHeaders) {
        for (const customHeaderName of Object.keys(customHeaders)) {
            request.headers.set(customHeaderName, customHeaders[customHeaderName]);
        }
    }
}
/**
 * @internal
 */
function serializeRequestBody(request, operationArguments, operationSpec, stringifyXML = function () {
    throw new Error("XML serialization unsupported!");
}) {
    var _a, _b, _c, _d, _e;
    const serializerOptions = (_a = operationArguments.options) === null || _a === void 0 ? void 0 : _a.serializerOptions;
    const updatedOptions = {
        xml: {
            rootName: (_b = serializerOptions === null || serializerOptions === void 0 ? void 0 : serializerOptions.xml.rootName) !== null && _b !== void 0 ? _b : "",
            includeRoot: (_c = serializerOptions === null || serializerOptions === void 0 ? void 0 : serializerOptions.xml.includeRoot) !== null && _c !== void 0 ? _c : false,
            xmlCharKey: (_d = serializerOptions === null || serializerOptions === void 0 ? void 0 : serializerOptions.xml.xmlCharKey) !== null && _d !== void 0 ? _d : XML_CHARKEY,
        },
    };
    const xmlCharKey = updatedOptions.xml.xmlCharKey;
    if (operationSpec.requestBody && operationSpec.requestBody.mapper) {
        request.body = getOperationArgumentValueFromParameter(operationArguments, operationSpec.requestBody);
        const bodyMapper = operationSpec.requestBody.mapper;
        const { required, serializedName, xmlName, xmlElementName, xmlNamespace, xmlNamespacePrefix, nullable, } = bodyMapper;
        const typeName = bodyMapper.type.name;
        try {
            if ((request.body !== undefined && request.body !== null) ||
                (nullable && request.body === null) ||
                required) {
                const requestBodyParameterPathString = getPathStringFromParameter(operationSpec.requestBody);
                request.body = operationSpec.serializer.serialize(bodyMapper, request.body, requestBodyParameterPathString, updatedOptions);
                const isStream = typeName === MapperTypeNames.Stream;
                if (operationSpec.isXML) {
                    const xmlnsKey = xmlNamespacePrefix ? `xmlns:${xmlNamespacePrefix}` : "xmlns";
                    const value = getXmlValueWithNamespace(xmlNamespace, xmlnsKey, typeName, request.body, updatedOptions);
                    if (typeName === MapperTypeNames.Sequence) {
                        request.body = stringifyXML(prepareXMLRootList(value, xmlElementName || xmlName || serializedName, xmlnsKey, xmlNamespace), { rootName: xmlName || serializedName, xmlCharKey });
                    }
                    else if (!isStream) {
                        request.body = stringifyXML(value, {
                            rootName: xmlName || serializedName,
                            xmlCharKey,
                        });
                    }
                }
                else if (typeName === MapperTypeNames.String &&
                    (((_e = operationSpec.contentType) === null || _e === void 0 ? void 0 : _e.match("text/plain")) || operationSpec.mediaType === "text")) {
                    // the String serializer has validated that request body is a string
                    // so just send the string.
                    return;
                }
                else if (!isStream) {
                    request.body = JSON.stringify(request.body);
                }
            }
        }
        catch (error) {
            throw new Error(`Error "${error.message}" occurred in serializing the payload - ${JSON.stringify(serializedName, undefined, "  ")}.`);
        }
    }
    else if (operationSpec.formDataParameters && operationSpec.formDataParameters.length > 0) {
        request.formData = {};
        for (const formDataParameter of operationSpec.formDataParameters) {
            const formDataParameterValue = getOperationArgumentValueFromParameter(operationArguments, formDataParameter);
            if (formDataParameterValue !== undefined && formDataParameterValue !== null) {
                const formDataParameterPropertyName = formDataParameter.mapper.serializedName || getPathStringFromParameter(formDataParameter);
                request.formData[formDataParameterPropertyName] = operationSpec.serializer.serialize(formDataParameter.mapper, formDataParameterValue, getPathStringFromParameter(formDataParameter), updatedOptions);
            }
        }
    }
}
/**
 * Adds an xml namespace to the xml serialized object if needed, otherwise it just returns the value itself
 */
function getXmlValueWithNamespace(xmlNamespace, xmlnsKey, typeName, serializedValue, options) {
    // Composite and Sequence schemas already got their root namespace set during serialization
    // We just need to add xmlns to the other schema types
    if (xmlNamespace && !["Composite", "Sequence", "Dictionary"].includes(typeName)) {
        const result = {};
        result[options.xml.xmlCharKey] = serializedValue;
        result[XML_ATTRKEY] = { [xmlnsKey]: xmlNamespace };
        return result;
    }
    return serializedValue;
}
function prepareXMLRootList(obj, elementName, xmlNamespaceKey, xmlNamespace) {
    if (!Array.isArray(obj)) {
        obj = [obj];
    }
    if (!xmlNamespaceKey || !xmlNamespace) {
        return { [elementName]: obj };
    }
    const result = { [elementName]: obj };
    result[XML_ATTRKEY] = { [xmlNamespaceKey]: xmlNamespace };
    return result;
}
//# sourceMappingURL=serializationPolicy.js.map
;// ./node_modules/@azure/core-client/dist/esm/pipeline.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.



/**
 * Creates a new Pipeline for use with a Service Client.
 * Adds in deserializationPolicy by default.
 * Also adds in bearerTokenAuthenticationPolicy if passed a TokenCredential.
 * @param options - Options to customize the created pipeline.
 */
function createClientPipeline(options = {}) {
    const pipeline = (0,core_rest_pipeline_dist_esm/* createPipelineFromOptions */.Fp)(options !== null && options !== void 0 ? options : {});
    if (options.credentialOptions) {
        pipeline.addPolicy((0,core_rest_pipeline_dist_esm/* bearerTokenAuthenticationPolicy */.N$)({
            credential: options.credentialOptions.credential,
            scopes: options.credentialOptions.credentialScopes,
        }));
    }
    pipeline.addPolicy(serializationPolicy(options.serializationOptions), { phase: "Serialize" });
    pipeline.addPolicy(deserializationPolicy(options.deserializationOptions), {
        phase: "Deserialize",
    });
    return pipeline;
}
//# sourceMappingURL=pipeline.js.map
;// ./node_modules/@azure/core-client/dist/esm/httpClientCache.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

let cachedHttpClient;
function getCachedDefaultHttpClient() {
    if (!cachedHttpClient) {
        cachedHttpClient = (0,core_rest_pipeline_dist_esm/* createDefaultHttpClient */.fl)();
    }
    return cachedHttpClient;
}
//# sourceMappingURL=httpClientCache.js.map
;// ./node_modules/@azure/core-client/dist/esm/urlHelpers.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.


const CollectionFormatToDelimiterMap = {
    CSV: ",",
    SSV: " ",
    Multi: "Multi",
    TSV: "\t",
    Pipes: "|",
};
function getRequestUrl(baseUri, operationSpec, operationArguments, fallbackObject) {
    const urlReplacements = calculateUrlReplacements(operationSpec, operationArguments, fallbackObject);
    let isAbsolutePath = false;
    let requestUrl = replaceAll(baseUri, urlReplacements);
    if (operationSpec.path) {
        let path = replaceAll(operationSpec.path, urlReplacements);
        // QUIRK: sometimes we get a path component like /{nextLink}
        // which may be a fully formed URL with a leading /. In that case, we should
        // remove the leading /
        if (operationSpec.path === "/{nextLink}" && path.startsWith("/")) {
            path = path.substring(1);
        }
        // QUIRK: sometimes we get a path component like {nextLink}
        // which may be a fully formed URL. In that case, we should
        // ignore the baseUri.
        if (isAbsoluteUrl(path)) {
            requestUrl = path;
            isAbsolutePath = true;
        }
        else {
            requestUrl = appendPath(requestUrl, path);
        }
    }
    const { queryParams, sequenceParams } = calculateQueryParameters(operationSpec, operationArguments, fallbackObject);
    /**
     * Notice that this call sets the `noOverwrite` parameter to true if the `requestUrl`
     * is an absolute path. This ensures that existing query parameter values in `requestUrl`
     * do not get overwritten. On the other hand when `requestUrl` is not absolute path, it
     * is still being built so there is nothing to overwrite.
     */
    requestUrl = appendQueryParams(requestUrl, queryParams, sequenceParams, isAbsolutePath);
    return requestUrl;
}
function replaceAll(input, replacements) {
    let result = input;
    for (const [searchValue, replaceValue] of replacements) {
        result = result.split(searchValue).join(replaceValue);
    }
    return result;
}
function calculateUrlReplacements(operationSpec, operationArguments, fallbackObject) {
    var _a;
    const result = new Map();
    if ((_a = operationSpec.urlParameters) === null || _a === void 0 ? void 0 : _a.length) {
        for (const urlParameter of operationSpec.urlParameters) {
            let urlParameterValue = getOperationArgumentValueFromParameter(operationArguments, urlParameter, fallbackObject);
            const parameterPathString = getPathStringFromParameter(urlParameter);
            urlParameterValue = operationSpec.serializer.serialize(urlParameter.mapper, urlParameterValue, parameterPathString);
            if (!urlParameter.skipEncoding) {
                urlParameterValue = encodeURIComponent(urlParameterValue);
            }
            result.set(`{${urlParameter.mapper.serializedName || parameterPathString}}`, urlParameterValue);
        }
    }
    return result;
}
function isAbsoluteUrl(url) {
    return url.includes("://");
}
function appendPath(url, pathToAppend) {
    if (!pathToAppend) {
        return url;
    }
    const parsedUrl = new URL(url);
    let newPath = parsedUrl.pathname;
    if (!newPath.endsWith("/")) {
        newPath = `${newPath}/`;
    }
    if (pathToAppend.startsWith("/")) {
        pathToAppend = pathToAppend.substring(1);
    }
    const searchStart = pathToAppend.indexOf("?");
    if (searchStart !== -1) {
        const path = pathToAppend.substring(0, searchStart);
        const search = pathToAppend.substring(searchStart + 1);
        newPath = newPath + path;
        if (search) {
            parsedUrl.search = parsedUrl.search ? `${parsedUrl.search}&${search}` : search;
        }
    }
    else {
        newPath = newPath + pathToAppend;
    }
    parsedUrl.pathname = newPath;
    return parsedUrl.toString();
}
function calculateQueryParameters(operationSpec, operationArguments, fallbackObject) {
    var _a;
    const result = new Map();
    const sequenceParams = new Set();
    if ((_a = operationSpec.queryParameters) === null || _a === void 0 ? void 0 : _a.length) {
        for (const queryParameter of operationSpec.queryParameters) {
            if (queryParameter.mapper.type.name === "Sequence" && queryParameter.mapper.serializedName) {
                sequenceParams.add(queryParameter.mapper.serializedName);
            }
            let queryParameterValue = getOperationArgumentValueFromParameter(operationArguments, queryParameter, fallbackObject);
            if ((queryParameterValue !== undefined && queryParameterValue !== null) ||
                queryParameter.mapper.required) {
                queryParameterValue = operationSpec.serializer.serialize(queryParameter.mapper, queryParameterValue, getPathStringFromParameter(queryParameter));
                const delimiter = queryParameter.collectionFormat
                    ? CollectionFormatToDelimiterMap[queryParameter.collectionFormat]
                    : "";
                if (Array.isArray(queryParameterValue)) {
                    // replace null and undefined
                    queryParameterValue = queryParameterValue.map((item) => {
                        if (item === null || item === undefined) {
                            return "";
                        }
                        return item;
                    });
                }
                if (queryParameter.collectionFormat === "Multi" && queryParameterValue.length === 0) {
                    continue;
                }
                else if (Array.isArray(queryParameterValue) &&
                    (queryParameter.collectionFormat === "SSV" || queryParameter.collectionFormat === "TSV")) {
                    queryParameterValue = queryParameterValue.join(delimiter);
                }
                if (!queryParameter.skipEncoding) {
                    if (Array.isArray(queryParameterValue)) {
                        queryParameterValue = queryParameterValue.map((item) => {
                            return encodeURIComponent(item);
                        });
                    }
                    else {
                        queryParameterValue = encodeURIComponent(queryParameterValue);
                    }
                }
                // Join pipes and CSV *after* encoding, or the server will be upset.
                if (Array.isArray(queryParameterValue) &&
                    (queryParameter.collectionFormat === "CSV" || queryParameter.collectionFormat === "Pipes")) {
                    queryParameterValue = queryParameterValue.join(delimiter);
                }
                result.set(queryParameter.mapper.serializedName || getPathStringFromParameter(queryParameter), queryParameterValue);
            }
        }
    }
    return {
        queryParams: result,
        sequenceParams,
    };
}
function simpleParseQueryParams(queryString) {
    const result = new Map();
    if (!queryString || queryString[0] !== "?") {
        return result;
    }
    // remove the leading ?
    queryString = queryString.slice(1);
    const pairs = queryString.split("&");
    for (const pair of pairs) {
        const [name, value] = pair.split("=", 2);
        const existingValue = result.get(name);
        if (existingValue) {
            if (Array.isArray(existingValue)) {
                existingValue.push(value);
            }
            else {
                result.set(name, [existingValue, value]);
            }
        }
        else {
            result.set(name, value);
        }
    }
    return result;
}
/** @internal */
function appendQueryParams(url, queryParams, sequenceParams, noOverwrite = false) {
    if (queryParams.size === 0) {
        return url;
    }
    const parsedUrl = new URL(url);
    // QUIRK: parsedUrl.searchParams will have their name/value pairs decoded, which
    // can change their meaning to the server, such as in the case of a SAS signature.
    // To avoid accidentally un-encoding a query param, we parse the key/values ourselves
    const combinedParams = simpleParseQueryParams(parsedUrl.search);
    for (const [name, value] of queryParams) {
        const existingValue = combinedParams.get(name);
        if (Array.isArray(existingValue)) {
            if (Array.isArray(value)) {
                existingValue.push(...value);
                const valueSet = new Set(existingValue);
                combinedParams.set(name, Array.from(valueSet));
            }
            else {
                existingValue.push(value);
            }
        }
        else if (existingValue) {
            if (Array.isArray(value)) {
                value.unshift(existingValue);
            }
            else if (sequenceParams.has(name)) {
                combinedParams.set(name, [existingValue, value]);
            }
            if (!noOverwrite) {
                combinedParams.set(name, value);
            }
        }
        else {
            combinedParams.set(name, value);
        }
    }
    const searchPieces = [];
    for (const [name, value] of combinedParams) {
        if (typeof value === "string") {
            searchPieces.push(`${name}=${value}`);
        }
        else if (Array.isArray(value)) {
            // QUIRK: If we get an array of values, include multiple key/value pairs
            for (const subValue of value) {
                searchPieces.push(`${name}=${subValue}`);
            }
        }
        else {
            searchPieces.push(`${name}=${value}`);
        }
    }
    // QUIRK: we have to set search manually as searchParams will encode comma when it shouldn't.
    parsedUrl.search = searchPieces.length ? `?${searchPieces.join("&")}` : "";
    return parsedUrl.toString();
}
//# sourceMappingURL=urlHelpers.js.map
// EXTERNAL MODULE: ./node_modules/@azure/logger/dist/esm/index.js + 1 modules
var logger_dist_esm = __webpack_require__(83678);
;// ./node_modules/@azure/core-client/dist/esm/log.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

const log_logger = (0,logger_dist_esm/* createClientLogger */.KV)("core-client");
//# sourceMappingURL=log.js.map
;// ./node_modules/@azure/core-client/dist/esm/serviceClient.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.








/**
 * Initializes a new instance of the ServiceClient.
 */
class ServiceClient {
    /**
     * The ServiceClient constructor
     * @param options - The service client options that govern the behavior of the client.
     */
    constructor(options = {}) {
        var _a, _b;
        this._requestContentType = options.requestContentType;
        this._endpoint = (_a = options.endpoint) !== null && _a !== void 0 ? _a : options.baseUri;
        if (options.baseUri) {
            log_logger.warning("The baseUri option for SDK Clients has been deprecated, please use endpoint instead.");
        }
        this._allowInsecureConnection = options.allowInsecureConnection;
        this._httpClient = options.httpClient || getCachedDefaultHttpClient();
        this.pipeline = options.pipeline || createDefaultPipeline(options);
        if ((_b = options.additionalPolicies) === null || _b === void 0 ? void 0 : _b.length) {
            for (const { policy, position } of options.additionalPolicies) {
                // Sign happens after Retry and is commonly needed to occur
                // before policies that intercept post-retry.
                const afterPhase = position === "perRetry" ? "Sign" : undefined;
                this.pipeline.addPolicy(policy, {
                    afterPhase,
                });
            }
        }
    }
    /**
     * Send the provided httpRequest.
     */
    async sendRequest(request) {
        return this.pipeline.sendRequest(this._httpClient, request);
    }
    /**
     * Send an HTTP request that is populated using the provided OperationSpec.
     * @typeParam T - The typed result of the request, based on the OperationSpec.
     * @param operationArguments - The arguments that the HTTP request's templated values will be populated from.
     * @param operationSpec - The OperationSpec to use to populate the httpRequest.
     */
    async sendOperationRequest(operationArguments, operationSpec) {
        const endpoint = operationSpec.baseUrl || this._endpoint;
        if (!endpoint) {
            throw new Error("If operationSpec.baseUrl is not specified, then the ServiceClient must have a endpoint string property that contains the base URL to use.");
        }
        // Templatized URLs sometimes reference properties on the ServiceClient child class,
        // so we have to pass `this` below in order to search these properties if they're
        // not part of OperationArguments
        const url = getRequestUrl(endpoint, operationSpec, operationArguments, this);
        const request = (0,core_rest_pipeline_dist_esm/* createPipelineRequest */.G6)({
            url,
        });
        request.method = operationSpec.httpMethod;
        const operationInfo = getOperationRequestInfo(request);
        operationInfo.operationSpec = operationSpec;
        operationInfo.operationArguments = operationArguments;
        const contentType = operationSpec.contentType || this._requestContentType;
        if (contentType && operationSpec.requestBody) {
            request.headers.set("Content-Type", contentType);
        }
        const options = operationArguments.options;
        if (options) {
            const requestOptions = options.requestOptions;
            if (requestOptions) {
                if (requestOptions.timeout) {
                    request.timeout = requestOptions.timeout;
                }
                if (requestOptions.onUploadProgress) {
                    request.onUploadProgress = requestOptions.onUploadProgress;
                }
                if (requestOptions.onDownloadProgress) {
                    request.onDownloadProgress = requestOptions.onDownloadProgress;
                }
                if (requestOptions.shouldDeserialize !== undefined) {
                    operationInfo.shouldDeserialize = requestOptions.shouldDeserialize;
                }
                if (requestOptions.allowInsecureConnection) {
                    request.allowInsecureConnection = true;
                }
            }
            if (options.abortSignal) {
                request.abortSignal = options.abortSignal;
            }
            if (options.tracingOptions) {
                request.tracingOptions = options.tracingOptions;
            }
        }
        if (this._allowInsecureConnection) {
            request.allowInsecureConnection = true;
        }
        if (request.streamResponseStatusCodes === undefined) {
            request.streamResponseStatusCodes = getStreamingResponseStatusCodes(operationSpec);
        }
        try {
            const rawResponse = await this.sendRequest(request);
            const flatResponse = flattenResponse(rawResponse, operationSpec.responses[rawResponse.status]);
            if (options === null || options === void 0 ? void 0 : options.onResponse) {
                options.onResponse(rawResponse, flatResponse);
            }
            return flatResponse;
        }
        catch (error) {
            if (typeof error === "object" && (error === null || error === void 0 ? void 0 : error.response)) {
                const rawResponse = error.response;
                const flatResponse = flattenResponse(rawResponse, operationSpec.responses[error.statusCode] || operationSpec.responses["default"]);
                error.details = flatResponse;
                if (options === null || options === void 0 ? void 0 : options.onResponse) {
                    options.onResponse(rawResponse, flatResponse, error);
                }
            }
            throw error;
        }
    }
}
function createDefaultPipeline(options) {
    const credentialScopes = getCredentialScopes(options);
    const credentialOptions = options.credential && credentialScopes
        ? { credentialScopes, credential: options.credential }
        : undefined;
    return createClientPipeline(Object.assign(Object.assign({}, options), { credentialOptions }));
}
function getCredentialScopes(options) {
    if (options.credentialScopes) {
        return options.credentialScopes;
    }
    if (options.endpoint) {
        return `${options.endpoint}/.default`;
    }
    if (options.baseUri) {
        return `${options.baseUri}/.default`;
    }
    if (options.credential && !options.credentialScopes) {
        throw new Error(`When using credentials, the ServiceClientOptions must contain either a endpoint or a credentialScopes. Unable to create a bearerTokenAuthenticationPolicy`);
    }
    return undefined;
}
//# sourceMappingURL=serviceClient.js.map
;// ./node_modules/@azure/core-client/dist/esm/authorizeRequestOnClaimChallenge.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.


/**
 * Converts: `Bearer a="b", c="d", Bearer d="e", f="g"`.
 * Into: `[ { a: 'b', c: 'd' }, { d: 'e', f: 'g' } ]`.
 *
 * @internal
 */
function parseCAEChallenge(challenges) {
    const bearerChallenges = `, ${challenges.trim()}`.split(", Bearer ").filter((x) => x);
    return bearerChallenges.map((challenge) => {
        const challengeParts = `${challenge.trim()}, `.split('", ').filter((x) => x);
        const keyValuePairs = challengeParts.map((keyValue) => (([key, value]) => ({ [key]: value }))(keyValue.trim().split('="')));
        // Key-value pairs to plain object:
        return keyValuePairs.reduce((a, b) => (Object.assign(Object.assign({}, a), b)), {});
    });
}
/**
 * This function can be used as a callback for the `bearerTokenAuthenticationPolicy` of `@azure/core-rest-pipeline`, to support CAE challenges:
 * [Continuous Access Evaluation](https://learn.microsoft.com/azure/active-directory/conditional-access/concept-continuous-access-evaluation).
 *
 * Call the `bearerTokenAuthenticationPolicy` with the following options:
 *
 * ```ts snippet:AuthorizeRequestOnClaimChallenge
 * import { bearerTokenAuthenticationPolicy } from "@azure/core-rest-pipeline";
 * import { authorizeRequestOnClaimChallenge } from "@azure/core-client";
 *
 * const policy = bearerTokenAuthenticationPolicy({
 *   challengeCallbacks: {
 *     authorizeRequestOnChallenge: authorizeRequestOnClaimChallenge,
 *   },
 *   scopes: ["https://service/.default"],
 * });
 * ```
 *
 * Once provided, the `bearerTokenAuthenticationPolicy` policy will internally handle Continuous Access Evaluation (CAE) challenges.
 * When it can't complete a challenge it will return the 401 (unauthorized) response from ARM.
 *
 * Example challenge with claims:
 *
 * ```
 * Bearer authorization_uri="https://login.windows-ppe.net/", error="invalid_token",
 * error_description="User session has been revoked",
 * claims="eyJhY2Nlc3NfdG9rZW4iOnsibmJmIjp7ImVzc2VudGlhbCI6dHJ1ZSwgInZhbHVlIjoiMTYwMzc0MjgwMCJ9fX0="
 * ```
 */
async function authorizeRequestOnClaimChallenge(onChallengeOptions) {
    var _a;
    const { scopes, response } = onChallengeOptions;
    const logger = onChallengeOptions.logger || log_logger;
    const challenge = response.headers.get("WWW-Authenticate");
    if (!challenge) {
        logger.info(`The WWW-Authenticate header was missing. Failed to perform the Continuous Access Evaluation authentication flow.`);
        return false;
    }
    const challenges = parseCAEChallenge(challenge) || [];
    const parsedChallenge = challenges.find((x) => x.claims);
    if (!parsedChallenge) {
        logger.info(`The WWW-Authenticate header was missing the necessary "claims" to perform the Continuous Access Evaluation authentication flow.`);
        return false;
    }
    const accessToken = await onChallengeOptions.getAccessToken(parsedChallenge.scope ? [parsedChallenge.scope] : scopes, {
        claims: decodeStringToString(parsedChallenge.claims),
    });
    if (!accessToken) {
        return false;
    }
    onChallengeOptions.request.headers.set("Authorization", `${(_a = accessToken.tokenType) !== null && _a !== void 0 ? _a : "Bearer"} ${accessToken.token}`);
    return true;
}
//# sourceMappingURL=authorizeRequestOnClaimChallenge.js.map
;// ./node_modules/@azure/core-client/dist/esm/authorizeRequestOnTenantChallenge.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * A set of constants used internally when processing requests.
 */
const Constants = {
    DefaultScope: "/.default",
    /**
     * Defines constants for use with HTTP headers.
     */
    HeaderConstants: {
        /**
         * The Authorization header.
         */
        AUTHORIZATION: "authorization",
    },
};
function isUuid(text) {
    return /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/.test(text);
}
/**
 * Defines a callback to handle auth challenge for Storage APIs.
 * This implements the bearer challenge process described here: https://learn.microsoft.com/rest/api/storageservices/authorize-with-azure-active-directory#bearer-challenge
 * Handling has specific features for storage that departs to the general AAD challenge docs.
 **/
const authorizeRequestOnTenantChallenge = async (challengeOptions) => {
    var _a;
    const requestOptions = requestToOptions(challengeOptions.request);
    const challenge = getChallenge(challengeOptions.response);
    if (challenge) {
        const challengeInfo = parseChallenge(challenge);
        const challengeScopes = buildScopes(challengeOptions, challengeInfo);
        const tenantId = extractTenantId(challengeInfo);
        if (!tenantId) {
            return false;
        }
        const accessToken = await challengeOptions.getAccessToken(challengeScopes, Object.assign(Object.assign({}, requestOptions), { tenantId }));
        if (!accessToken) {
            return false;
        }
        challengeOptions.request.headers.set(Constants.HeaderConstants.AUTHORIZATION, `${(_a = accessToken.tokenType) !== null && _a !== void 0 ? _a : "Bearer"} ${accessToken.token}`);
        return true;
    }
    return false;
};
/**
 * Extracts the tenant id from the challenge information
 * The tenant id is contained in the authorization_uri as the first
 * path part.
 */
function extractTenantId(challengeInfo) {
    const parsedAuthUri = new URL(challengeInfo.authorization_uri);
    const pathSegments = parsedAuthUri.pathname.split("/");
    const tenantId = pathSegments[1];
    if (tenantId && isUuid(tenantId)) {
        return tenantId;
    }
    return undefined;
}
/**
 * Builds the authentication scopes based on the information that comes in the
 * challenge information. Scopes url is present in the resource_id, if it is empty
 * we keep using the original scopes.
 */
function buildScopes(challengeOptions, challengeInfo) {
    if (!challengeInfo.resource_id) {
        return challengeOptions.scopes;
    }
    const challengeScopes = new URL(challengeInfo.resource_id);
    challengeScopes.pathname = Constants.DefaultScope;
    let scope = challengeScopes.toString();
    if (scope === "https://disk.azure.com/.default") {
        // the extra slash is required by the service
        scope = "https://disk.azure.com//.default";
    }
    return [scope];
}
/**
 * We will retrieve the challenge only if the response status code was 401,
 * and if the response contained the header "WWW-Authenticate" with a non-empty value.
 */
function getChallenge(response) {
    const challenge = response.headers.get("WWW-Authenticate");
    if (response.status === 401 && challenge) {
        return challenge;
    }
    return;
}
/**
 * Converts: `Bearer a="b" c="d"`.
 * Into: `[ { a: 'b', c: 'd' }]`.
 *
 * @internal
 */
function parseChallenge(challenge) {
    const bearerChallenge = challenge.slice("Bearer ".length);
    const challengeParts = `${bearerChallenge.trim()} `.split(" ").filter((x) => x);
    const keyValuePairs = challengeParts.map((keyValue) => (([key, value]) => ({ [key]: value }))(keyValue.trim().split("=")));
    // Key-value pairs to plain object:
    return keyValuePairs.reduce((a, b) => (Object.assign(Object.assign({}, a), b)), {});
}
/**
 * Extracts the options form a Pipeline Request for later re-use
 */
function requestToOptions(request) {
    return {
        abortSignal: request.abortSignal,
        requestOptions: {
            timeout: request.timeout,
        },
        tracingOptions: request.tracingOptions,
    };
}
//# sourceMappingURL=authorizeRequestOnTenantChallenge.js.map
;// ./node_modules/@azure/core-client/dist/esm/index.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.








//# sourceMappingURL=index.js.map
// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.mjs
var tslib_es6 = __webpack_require__(74117);
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/operations/documentModels.js
/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 *
 * Code generated by Microsoft (R) AutoRest Code Generator.
 * Changes may cause incorrect behavior and will be lost if the code is regenerated.
 */




/// <reference lib="esnext.asynciterable" />
/** Class containing DocumentModels operations. */
class DocumentModelsImpl {
    /**
     * Initialize a new instance of the class DocumentModels class.
     * @param client Reference to the service client
     */
    constructor(client) {
        this.client = client;
    }
    /**
     * List all document models
     * @param options The options parameters.
     */
    listModels(options) {
        const iter = this.listModelsPagingAll(options);
        return {
            next() {
                return iter.next();
            },
            [Symbol.asyncIterator]() {
                return this;
            },
            byPage: () => {
                return this.listModelsPagingPage(options);
            }
        };
    }
    listModelsPagingPage(options) {
        return (0,tslib_es6/* __asyncGenerator */.AQ)(this, arguments, function* listModelsPagingPage_1() {
            let result = yield (0,tslib_es6/* __await */.N3)(this._listModels(options));
            yield yield (0,tslib_es6/* __await */.N3)(result.value || []);
            let continuationToken = result.nextLink;
            while (continuationToken) {
                result = yield (0,tslib_es6/* __await */.N3)(this._listModelsNext(continuationToken, options));
                continuationToken = result.nextLink;
                yield yield (0,tslib_es6/* __await */.N3)(result.value || []);
            }
        });
    }
    listModelsPagingAll(options) {
        return (0,tslib_es6/* __asyncGenerator */.AQ)(this, arguments, function* listModelsPagingAll_1() {
            var _a, e_1, _b, _c;
            try {
                for (var _d = true, _e = (0,tslib_es6/* __asyncValues */.xN)(this.listModelsPagingPage(options)), _f; _f = yield (0,tslib_es6/* __await */.N3)(_e.next()), _a = _f.done, !_a; _d = true) {
                    _c = _f.value;
                    _d = false;
                    const page = _c;
                    yield (0,tslib_es6/* __await */.N3)(yield* (0,tslib_es6/* __asyncDelegator */.Me)((0,tslib_es6/* __asyncValues */.xN)(page)));
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (!_d && !_a && (_b = _e.return)) yield (0,tslib_es6/* __await */.N3)(_b.call(_e));
                }
                finally { if (e_1) throw e_1.error; }
            }
        });
    }
    /**
     * Analyzes document with document model.
     * @param args Includes all the parameters for this operation.
     */
    analyzeDocument(...args) {
        let operationSpec;
        let operationArguments;
        let options;
        if (args[1] === "application/octet-stream" ||
            args[1] === "application/pdf" ||
            args[1] ===
                "application/vnd.openxmlformats-officedocument.presentationml.presentation" ||
            args[1] ===
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
            args[1] ===
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
            args[1] === "image/bmp" ||
            args[1] === "image/heif" ||
            args[1] === "image/jpeg" ||
            args[1] === "image/png" ||
            args[1] === "image/tiff") {
            operationSpec = analyzeDocument$binaryOperationSpec;
            operationArguments = {
                modelId: args[0],
                contentType: args[1],
                options: args[2]
            };
            options = args[2];
        }
        else if (args[1] === "text/html") {
            operationSpec = analyzeDocument$textOperationSpec;
            operationArguments = {
                modelId: args[0],
                contentType: args[1],
                options: args[2]
            };
            options = args[2];
        }
        else if (args[1] === "application/json") {
            operationSpec = analyzeDocument$jsonOperationSpec;
            operationArguments = {
                modelId: args[0],
                contentType: args[1],
                options: args[2]
            };
            options = args[2];
        }
        else {
            throw new TypeError(`"contentType" must be a valid value but instead was "${args[1]}".`);
        }
        operationArguments.options = options || {};
        return this.client.sendOperationRequest(operationArguments, operationSpec);
    }
    /**
     * Gets the result of document analysis.
     * @param modelId Unique document model name.
     * @param resultId Analyze operation result ID.
     * @param options The options parameters.
     */
    getAnalyzeResult(modelId, resultId, options) {
        return this.client.sendOperationRequest({ modelId, resultId, options }, getAnalyzeResultOperationSpec);
    }
    /**
     * Builds a custom document analysis model.
     * @param buildRequest Building request parameters.
     * @param options The options parameters.
     */
    buildModel(buildRequest, options) {
        return this.client.sendOperationRequest({ buildRequest, options }, buildModelOperationSpec);
    }
    /**
     * Creates a new document model from document types of existing document models.
     * @param composeRequest Compose request parameters.
     * @param options The options parameters.
     */
    composeModel(composeRequest, options) {
        return this.client.sendOperationRequest({ composeRequest, options }, composeModelOperationSpec);
    }
    /**
     * Generates authorization to copy a document model to this location with specified modelId and
     * optional description.
     * @param authorizeCopyRequest Authorize copy request parameters.
     * @param options The options parameters.
     */
    authorizeModelCopy(authorizeCopyRequest, options) {
        return this.client.sendOperationRequest({ authorizeCopyRequest, options }, authorizeModelCopyOperationSpec);
    }
    /**
     * Copies document model to the target resource, region, and modelId.
     * @param modelId Unique document model name.
     * @param copyToRequest Copy to request parameters.
     * @param options The options parameters.
     */
    copyModelTo(modelId, copyToRequest, options) {
        return this.client.sendOperationRequest({ modelId, copyToRequest, options }, copyModelToOperationSpec);
    }
    /**
     * List all document models
     * @param options The options parameters.
     */
    _listModels(options) {
        return this.client.sendOperationRequest({ options }, listModelsOperationSpec);
    }
    /**
     * Gets detailed document model information.
     * @param modelId Unique document model name.
     * @param options The options parameters.
     */
    getModel(modelId, options) {
        return this.client.sendOperationRequest({ modelId, options }, getModelOperationSpec);
    }
    /**
     * Deletes document model.
     * @param modelId Unique document model name.
     * @param options The options parameters.
     */
    deleteModel(modelId, options) {
        return this.client.sendOperationRequest({ modelId, options }, deleteModelOperationSpec);
    }
    /**
     * ListModelsNext
     * @param nextLink The nextLink from the previous successful call to the ListModels method.
     * @param options The options parameters.
     */
    _listModelsNext(nextLink, options) {
        return this.client.sendOperationRequest({ nextLink, options }, listModelsNextOperationSpec);
    }
}
// Operation Specifications
const serializer = createSerializer(mappers_namespaceObject, /* isXml */ false);
const analyzeDocument$binaryOperationSpec = {
    path: "/documentModels/{modelId}:analyze",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentModelsAnalyzeDocumentHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: analyzeRequest,
    queryParameters: [
        pages,
        locale,
        stringIndexType,
        apiVersion,
        features
    ],
    urlParameters: [endpoint, modelId],
    headerParameters: [contentType, accept],
    mediaType: "binary",
    serializer
};
const analyzeDocument$textOperationSpec = {
    path: "/documentModels/{modelId}:analyze",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentModelsAnalyzeDocumentHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: analyzeRequest1,
    queryParameters: [
        pages,
        locale,
        stringIndexType,
        apiVersion,
        features
    ],
    urlParameters: [endpoint, modelId],
    headerParameters: [contentType1, parameters_accept1],
    mediaType: "text",
    serializer
};
const analyzeDocument$jsonOperationSpec = {
    path: "/documentModels/{modelId}:analyze",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentModelsAnalyzeDocumentHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: analyzeRequest2,
    queryParameters: [
        pages,
        locale,
        stringIndexType,
        apiVersion,
        features
    ],
    urlParameters: [endpoint, modelId],
    headerParameters: [contentType2, accept2],
    mediaType: "json",
    serializer
};
const getAnalyzeResultOperationSpec = {
    path: "/documentModels/{modelId}/analyzeResults/{resultId}",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: AnalyzeResultOperation
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint, modelId, resultId],
    headerParameters: [accept2],
    serializer
};
const buildModelOperationSpec = {
    path: "/documentModels:build",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentModelsBuildModelHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: buildRequest,
    queryParameters: [apiVersion],
    urlParameters: [endpoint],
    headerParameters: [accept2, contentType3],
    mediaType: "json",
    serializer
};
const composeModelOperationSpec = {
    path: "/documentModels:compose",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentModelsComposeModelHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: composeRequest,
    queryParameters: [apiVersion],
    urlParameters: [endpoint],
    headerParameters: [accept2, contentType3],
    mediaType: "json",
    serializer
};
const authorizeModelCopyOperationSpec = {
    path: "/documentModels:authorizeCopy",
    httpMethod: "POST",
    responses: {
        200: {
            bodyMapper: CopyAuthorization
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: authorizeCopyRequest,
    queryParameters: [apiVersion],
    urlParameters: [endpoint],
    headerParameters: [accept2, contentType3],
    mediaType: "json",
    serializer
};
const copyModelToOperationSpec = {
    path: "/documentModels/{modelId}:copyTo",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentModelsCopyModelToHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: copyToRequest,
    queryParameters: [apiVersion],
    urlParameters: [endpoint, modelId],
    headerParameters: [accept2, contentType3],
    mediaType: "json",
    serializer
};
const listModelsOperationSpec = {
    path: "/documentModels",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: GetDocumentModelsResponse
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint],
    headerParameters: [accept2],
    serializer
};
const getModelOperationSpec = {
    path: "/documentModels/{modelId}",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: DocumentModelDetails
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint, modelId],
    headerParameters: [accept2],
    serializer
};
const deleteModelOperationSpec = {
    path: "/documentModels/{modelId}",
    httpMethod: "DELETE",
    responses: {
        204: {},
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint, modelId],
    headerParameters: [accept2],
    serializer
};
const listModelsNextOperationSpec = {
    path: "{nextLink}",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: GetDocumentModelsResponse
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint, nextLink],
    headerParameters: [accept2],
    serializer
};
//# sourceMappingURL=documentModels.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/operations/miscellaneous.js
/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 *
 * Code generated by Microsoft (R) AutoRest Code Generator.
 * Changes may cause incorrect behavior and will be lost if the code is regenerated.
 */




/// <reference lib="esnext.asynciterable" />
/** Class containing Miscellaneous operations. */
class MiscellaneousImpl {
    /**
     * Initialize a new instance of the class Miscellaneous class.
     * @param client Reference to the service client
     */
    constructor(client) {
        this.client = client;
    }
    /**
     * Lists all operations.
     * @param options The options parameters.
     */
    listOperations(options) {
        const iter = this.listOperationsPagingAll(options);
        return {
            next() {
                return iter.next();
            },
            [Symbol.asyncIterator]() {
                return this;
            },
            byPage: () => {
                return this.listOperationsPagingPage(options);
            }
        };
    }
    listOperationsPagingPage(options) {
        return (0,tslib_es6/* __asyncGenerator */.AQ)(this, arguments, function* listOperationsPagingPage_1() {
            let result = yield (0,tslib_es6/* __await */.N3)(this._listOperations(options));
            yield yield (0,tslib_es6/* __await */.N3)(result.value || []);
            let continuationToken = result.nextLink;
            while (continuationToken) {
                result = yield (0,tslib_es6/* __await */.N3)(this._listOperationsNext(continuationToken, options));
                continuationToken = result.nextLink;
                yield yield (0,tslib_es6/* __await */.N3)(result.value || []);
            }
        });
    }
    listOperationsPagingAll(options) {
        return (0,tslib_es6/* __asyncGenerator */.AQ)(this, arguments, function* listOperationsPagingAll_1() {
            var _a, e_1, _b, _c;
            try {
                for (var _d = true, _e = (0,tslib_es6/* __asyncValues */.xN)(this.listOperationsPagingPage(options)), _f; _f = yield (0,tslib_es6/* __await */.N3)(_e.next()), _a = _f.done, !_a; _d = true) {
                    _c = _f.value;
                    _d = false;
                    const page = _c;
                    yield (0,tslib_es6/* __await */.N3)(yield* (0,tslib_es6/* __asyncDelegator */.Me)((0,tslib_es6/* __asyncValues */.xN)(page)));
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (!_d && !_a && (_b = _e.return)) yield (0,tslib_es6/* __await */.N3)(_b.call(_e));
                }
                finally { if (e_1) throw e_1.error; }
            }
        });
    }
    /**
     * Lists all operations.
     * @param options The options parameters.
     */
    _listOperations(options) {
        return this.client.sendOperationRequest({ options }, listOperationsOperationSpec);
    }
    /**
     * Gets operation info.
     * @param operationId Unique operation ID.
     * @param options The options parameters.
     */
    getOperation(operationId, options) {
        return this.client.sendOperationRequest({ operationId, options }, getOperationOperationSpec);
    }
    /**
     * Return information about the current resource.
     * @param options The options parameters.
     */
    getResourceInfo(options) {
        return this.client.sendOperationRequest({ options }, getResourceInfoOperationSpec);
    }
    /**
     * ListOperationsNext
     * @param nextLink The nextLink from the previous successful call to the ListOperations method.
     * @param options The options parameters.
     */
    _listOperationsNext(nextLink, options) {
        return this.client.sendOperationRequest({ nextLink, options }, listOperationsNextOperationSpec);
    }
}
// Operation Specifications
const miscellaneous_serializer = createSerializer(mappers_namespaceObject, /* isXml */ false);
const listOperationsOperationSpec = {
    path: "/operations",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: GetOperationsResponse
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint],
    headerParameters: [accept2],
    serializer: miscellaneous_serializer
};
const getOperationOperationSpec = {
    path: "/operations/{operationId}",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: OperationDetails
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint, operationId],
    headerParameters: [accept2],
    serializer: miscellaneous_serializer
};
const getResourceInfoOperationSpec = {
    path: "/info",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: ResourceDetails
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint],
    headerParameters: [accept2],
    serializer: miscellaneous_serializer
};
const listOperationsNextOperationSpec = {
    path: "{nextLink}",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: GetOperationsResponse
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint, nextLink],
    headerParameters: [accept2],
    serializer: miscellaneous_serializer
};
//# sourceMappingURL=miscellaneous.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/operations/documentClassifiers.js
/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 *
 * Code generated by Microsoft (R) AutoRest Code Generator.
 * Changes may cause incorrect behavior and will be lost if the code is regenerated.
 */




/// <reference lib="esnext.asynciterable" />
/** Class containing DocumentClassifiers operations. */
class DocumentClassifiersImpl {
    /**
     * Initialize a new instance of the class DocumentClassifiers class.
     * @param client Reference to the service client
     */
    constructor(client) {
        this.client = client;
    }
    /**
     * List all document classifiers.
     * @param options The options parameters.
     */
    listClassifiers(options) {
        const iter = this.listClassifiersPagingAll(options);
        return {
            next() {
                return iter.next();
            },
            [Symbol.asyncIterator]() {
                return this;
            },
            byPage: () => {
                return this.listClassifiersPagingPage(options);
            }
        };
    }
    listClassifiersPagingPage(options) {
        return (0,tslib_es6/* __asyncGenerator */.AQ)(this, arguments, function* listClassifiersPagingPage_1() {
            let result = yield (0,tslib_es6/* __await */.N3)(this._listClassifiers(options));
            yield yield (0,tslib_es6/* __await */.N3)(result.value || []);
            let continuationToken = result.nextLink;
            while (continuationToken) {
                result = yield (0,tslib_es6/* __await */.N3)(this._listClassifiersNext(continuationToken, options));
                continuationToken = result.nextLink;
                yield yield (0,tslib_es6/* __await */.N3)(result.value || []);
            }
        });
    }
    listClassifiersPagingAll(options) {
        return (0,tslib_es6/* __asyncGenerator */.AQ)(this, arguments, function* listClassifiersPagingAll_1() {
            var _a, e_1, _b, _c;
            try {
                for (var _d = true, _e = (0,tslib_es6/* __asyncValues */.xN)(this.listClassifiersPagingPage(options)), _f; _f = yield (0,tslib_es6/* __await */.N3)(_e.next()), _a = _f.done, !_a; _d = true) {
                    _c = _f.value;
                    _d = false;
                    const page = _c;
                    yield (0,tslib_es6/* __await */.N3)(yield* (0,tslib_es6/* __asyncDelegator */.Me)((0,tslib_es6/* __asyncValues */.xN)(page)));
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (!_d && !_a && (_b = _e.return)) yield (0,tslib_es6/* __await */.N3)(_b.call(_e));
                }
                finally { if (e_1) throw e_1.error; }
            }
        });
    }
    /**
     * Builds a custom document classifier.
     * @param buildRequest Building request parameters.
     * @param options The options parameters.
     */
    buildClassifier(buildRequest, options) {
        return this.client.sendOperationRequest({ buildRequest, options }, buildClassifierOperationSpec);
    }
    /**
     * List all document classifiers.
     * @param options The options parameters.
     */
    _listClassifiers(options) {
        return this.client.sendOperationRequest({ options }, listClassifiersOperationSpec);
    }
    /**
     * Gets detailed document classifier information.
     * @param classifierId Unique document classifier name.
     * @param options The options parameters.
     */
    getClassifier(classifierId, options) {
        return this.client.sendOperationRequest({ classifierId, options }, getClassifierOperationSpec);
    }
    /**
     * Deletes document classifier.
     * @param classifierId Unique document classifier name.
     * @param options The options parameters.
     */
    deleteClassifier(classifierId, options) {
        return this.client.sendOperationRequest({ classifierId, options }, deleteClassifierOperationSpec);
    }
    /**
     * Classifies document with document classifier.
     * @param args Includes all the parameters for this operation.
     */
    classifyDocument(...args) {
        let operationSpec;
        let operationArguments;
        let options;
        if (args[1] === "application/octet-stream" ||
            args[1] === "application/pdf" ||
            args[1] ===
                "application/vnd.openxmlformats-officedocument.presentationml.presentation" ||
            args[1] ===
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
            args[1] ===
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
            args[1] === "image/bmp" ||
            args[1] === "image/heif" ||
            args[1] === "image/jpeg" ||
            args[1] === "image/png" ||
            args[1] === "image/tiff") {
            operationSpec = classifyDocument$binaryOperationSpec;
            operationArguments = {
                classifierId: args[0],
                contentType: args[1],
                options: args[2]
            };
            options = args[2];
        }
        else if (args[1] === "text/html") {
            operationSpec = classifyDocument$textOperationSpec;
            operationArguments = {
                classifierId: args[0],
                contentType: args[1],
                options: args[2]
            };
            options = args[2];
        }
        else if (args[1] === "application/json") {
            operationSpec = classifyDocument$jsonOperationSpec;
            operationArguments = {
                classifierId: args[0],
                contentType: args[1],
                options: args[2]
            };
            options = args[2];
        }
        else {
            throw new TypeError(`"contentType" must be a valid value but instead was "${args[1]}".`);
        }
        operationArguments.options = options || {};
        return this.client.sendOperationRequest(operationArguments, operationSpec);
    }
    /**
     * Gets the result of document classifier.
     * @param classifierId Unique document classifier name.
     * @param resultId Analyze operation result ID.
     * @param options The options parameters.
     */
    getClassifyResult(classifierId, resultId, options) {
        return this.client.sendOperationRequest({ classifierId, resultId, options }, getClassifyResultOperationSpec);
    }
    /**
     * ListClassifiersNext
     * @param nextLink The nextLink from the previous successful call to the ListClassifiers method.
     * @param options The options parameters.
     */
    _listClassifiersNext(nextLink, options) {
        return this.client.sendOperationRequest({ nextLink, options }, listClassifiersNextOperationSpec);
    }
}
// Operation Specifications
const documentClassifiers_serializer = createSerializer(mappers_namespaceObject, /* isXml */ false);
const buildClassifierOperationSpec = {
    path: "/documentClassifiers:build",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentClassifiersBuildClassifierHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: buildRequest1,
    queryParameters: [apiVersion],
    urlParameters: [endpoint],
    headerParameters: [accept2, contentType3],
    mediaType: "json",
    serializer: documentClassifiers_serializer
};
const listClassifiersOperationSpec = {
    path: "/documentClassifiers",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: GetDocumentClassifiersResponse
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint],
    headerParameters: [accept2],
    serializer: documentClassifiers_serializer
};
const getClassifierOperationSpec = {
    path: "/documentClassifiers/{classifierId}",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: DocumentClassifierDetails
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint, classifierId],
    headerParameters: [accept2],
    serializer: documentClassifiers_serializer
};
const deleteClassifierOperationSpec = {
    path: "/documentClassifiers/{classifierId}",
    httpMethod: "DELETE",
    responses: {
        204: {},
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint, classifierId],
    headerParameters: [accept2],
    serializer: documentClassifiers_serializer
};
const classifyDocument$binaryOperationSpec = {
    path: "/documentClassifiers/{classifierId}:analyze",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentClassifiersClassifyDocumentHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: classifyRequest,
    queryParameters: [stringIndexType, apiVersion],
    urlParameters: [endpoint, classifierId],
    headerParameters: [contentType, accept],
    mediaType: "binary",
    serializer: documentClassifiers_serializer
};
const classifyDocument$textOperationSpec = {
    path: "/documentClassifiers/{classifierId}:analyze",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentClassifiersClassifyDocumentHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: classifyRequest1,
    queryParameters: [stringIndexType, apiVersion],
    urlParameters: [endpoint, classifierId],
    headerParameters: [contentType1, parameters_accept1],
    mediaType: "text",
    serializer: documentClassifiers_serializer
};
const classifyDocument$jsonOperationSpec = {
    path: "/documentClassifiers/{classifierId}:analyze",
    httpMethod: "POST",
    responses: {
        202: {
            headersMapper: DocumentClassifiersClassifyDocumentHeaders
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    requestBody: classifyRequest2,
    queryParameters: [stringIndexType, apiVersion],
    urlParameters: [endpoint, classifierId],
    headerParameters: [contentType2, accept2],
    mediaType: "json",
    serializer: documentClassifiers_serializer
};
const getClassifyResultOperationSpec = {
    path: "/documentClassifiers/{classifierId}/analyzeResults/{resultId}",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: AnalyzeResultOperation
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [
        endpoint,
        resultId,
        classifierId
    ],
    headerParameters: [accept2],
    serializer: documentClassifiers_serializer
};
const listClassifiersNextOperationSpec = {
    path: "{nextLink}",
    httpMethod: "GET",
    responses: {
        200: {
            bodyMapper: GetDocumentClassifiersResponse
        },
        default: {
            bodyMapper: ErrorResponse
        }
    },
    queryParameters: [apiVersion],
    urlParameters: [endpoint, nextLink],
    headerParameters: [accept2],
    serializer: documentClassifiers_serializer
};
//# sourceMappingURL=documentClassifiers.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/operations/index.js
/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 *
 * Code generated by Microsoft (R) AutoRest Code Generator.
 * Changes may cause incorrect behavior and will be lost if the code is regenerated.
 */



//# sourceMappingURL=index.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/generatedClient.js
/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 *
 * Code generated by Microsoft (R) AutoRest Code Generator.
 * Changes may cause incorrect behavior and will be lost if the code is regenerated.
 */



class GeneratedClient extends ServiceClient {
    /**
     * Initializes a new instance of the GeneratedClient class.
     * @param endpoint Supported Cognitive Services endpoints (protocol and hostname, for
     *                 example: https://westus2.api.cognitive.microsoft.com).
     * @param options The parameter options
     */
    constructor(endpoint, options) {
        var _a, _b;
        if (endpoint === undefined) {
            throw new Error("'endpoint' cannot be null");
        }
        // Initializing default values for options
        if (!options) {
            options = {};
        }
        const defaults = {
            requestContentType: "application/json; charset=utf-8"
        };
        const packageDetails = `azsdk-js-ai-form-recognizer/5.1.0`;
        const userAgentPrefix = options.userAgentOptions && options.userAgentOptions.userAgentPrefix
            ? `${options.userAgentOptions.userAgentPrefix} ${packageDetails}`
            : `${packageDetails}`;
        const optionsWithDefaults = Object.assign(Object.assign(Object.assign({}, defaults), options), { userAgentOptions: {
                userAgentPrefix
            }, baseUri: (_b = (_a = options.endpoint) !== null && _a !== void 0 ? _a : options.baseUri) !== null && _b !== void 0 ? _b : "{endpoint}/formrecognizer" });
        super(optionsWithDefaults);
        if ((options === null || options === void 0 ? void 0 : options.pipeline) && options.pipeline.getOrderedPolicies().length > 0) {
            const pipelinePolicies = options.pipeline.getOrderedPolicies();
            const bearerTokenAuthenticationPolicyFound = pipelinePolicies.some((pipelinePolicy) => pipelinePolicy.name ===
                core_rest_pipeline_dist_esm/* bearerTokenAuthenticationPolicyName */.uQ);
            if (!bearerTokenAuthenticationPolicyFound) {
                this.pipeline.removePolicy({
                    name: core_rest_pipeline_dist_esm/* bearerTokenAuthenticationPolicyName */.uQ
                });
                this.pipeline.addPolicy(core_rest_pipeline_dist_esm/* bearerTokenAuthenticationPolicy */.N$({
                    scopes: `${optionsWithDefaults.baseUri}/.default`,
                    challengeCallbacks: {
                        authorizeRequestOnChallenge: authorizeRequestOnClaimChallenge
                    }
                }));
            }
        }
        // Parameter assignments
        this.endpoint = endpoint;
        // Assigning values to Constant parameters
        this.apiVersion = options.apiVersion || "2023-07-31";
        this.documentModels = new DocumentModelsImpl(this);
        this.miscellaneous = new MiscellaneousImpl(this);
        this.documentClassifiers = new DocumentClassifiersImpl(this);
        this.addCustomApiVersionPolicy(options.apiVersion);
    }
    /** A function that adds a policy that sets the api-version (or equivalent) to reflect the library version. */
    addCustomApiVersionPolicy(apiVersion) {
        if (!apiVersion) {
            return;
        }
        const apiVersionPolicy = {
            name: "CustomApiVersionPolicy",
            async sendRequest(request, next) {
                const param = request.url.split("?");
                if (param.length > 1) {
                    const newParams = param[1].split("&").map((item) => {
                        if (item.indexOf("api-version") > -1) {
                            return "api-version=" + apiVersion;
                        }
                        else {
                            return item;
                        }
                    });
                    request.url = param[0] + "?" + newParams.join("&");
                }
                return next(request);
            }
        };
        this.pipeline.addPolicy(apiVersionPolicy);
    }
}
//# sourceMappingURL=generatedClient.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/generated/index.js
/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT License.
 *
 * Code generated by Microsoft (R) AutoRest Code Generator.
 * Changes may cause incorrect behavior and will be lost if the code is regenerated.
 */
/// <reference lib="esnext.asynciterable" />



//# sourceMappingURL=index.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/options/FormRecognizerClientOptions.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Supported values of StringIndexType.
 */
// eslint-disable-next-line @typescript-eslint/no-redeclare
const StringIndexType = {
    /**
     * UTF-16 code units
     */
    Utf16CodeUnit: "utf16CodeUnit",
    /**
     * Unicode code points
     */
    UnicodeCodePoint: "unicodeCodePoint",
};
/**
 * Default settings for Form Recognizer clients.
 *
 * @internal
 */
const DEFAULT_GENERATED_CLIENT_OPTIONS = {
    stringIndexType: StringIndexType.Utf16CodeUnit,
};
//# sourceMappingURL=FormRecognizerClientOptions.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/util.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.









// This is used for URL request processing.
const util_SERIALIZER = createSerializer(mappers_namespaceObject, false);
/**
 * Type-strong uncapitalization.
 * @internal
 */
const util_uncapitalize = (s) => (s.substring(0, 1).toLowerCase() + s.substring(1));
/**
 * Type-strong capitalization
 * @internal
 */
const capitalize = (s) => (s.substring(0, 1).toUpperCase() + s.substring(1));
/**
 * Tests if a string looks like it begins with an acronym, i.e. it starts with two capital letters.
 * @internal
 */
const util_isAcronymic = (s) => {
    return /^[A-Z][A-Z]/.test(s);
};
/**
 * Map an optional value through a function
 * @internal
 */
const maybemap = (value, f) => value === undefined ? undefined : f(value);
/**
 * Create a GeneratedClient.
 * @internal
 */
function util_makeServiceClient(endpoint, credential, options) {
    var _a;
    const client = new GeneratedClient(endpoint === null || endpoint === void 0 ? void 0 : endpoint.replace(/\/$/, ""), Object.assign(Object.assign(Object.assign({}, DEFAULT_GENERATED_CLIENT_OPTIONS), options), { apiVersion: FORM_RECOGNIZER_API_VERSION }));
    const authPolicy = (0,esm/* isTokenCredential */.Zp)(credential)
        ? (0,core_rest_pipeline_dist_esm/* bearerTokenAuthenticationPolicy */.N$)({
            credential,
            scopes: [(_a = options.audience) !== null && _a !== void 0 ? _a : DEFAULT_COGNITIVE_SCOPE].map((scope) => {
                if (scope.endsWith("/.default"))
                    return scope;
                return `${scope}/.default`;
            }),
        })
        : createFormRecognizerAzureKeyCredentialPolicy(credential);
    client.pipeline.addPolicy(authPolicy);
    return client;
}
//# sourceMappingURL=util.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/models/fields.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.


/**
 * Convert a record of generated fields to a record of strongly-typed fields.
 * @internal
 * @param fields - a map of field names to generated field values
 * @returns - an object with the same keys, where all values have been mapped to DocumentFields
 */
function toAnalyzedDocumentFieldsFromGenerated(fields) {
    return Object.entries(fields !== null && fields !== void 0 ? fields : {}).reduce((transformedFields, [name, value]) => {
        transformedFields[name] = toDocumentField(value);
        return transformedFields;
    }, {});
}
/**
 * Convert a generated document field into a strong TypeScriptified document field.
 * @internal
 */
function toDocumentField(field) {
    const kind = field.type;
    const value = (() => {
        var _a, _b;
        switch (kind) {
            // Almost all value kinds are represented as simple elemental values
            case "string":
            case "date":
            case "time":
            case "phoneNumber":
            case "number":
            case "boolean":
            case "integer":
            case "selectionMark":
            case "countryRegion":
            case "signature":
            case "currency":
            case "address":
                return {
                    value: field[("value" + capitalize(kind))],
                };
            case "array":
                return { values: (_a = field.valueArray) === null || _a === void 0 ? void 0 : _a.map((v) => { var _a; return (_a = toDocumentField(v)) !== null && _a !== void 0 ? _a : []; }) };
            case "object":
                return { properties: toAnalyzedDocumentFieldsFromGenerated((_b = field.valueObject) !== null && _b !== void 0 ? _b : {}) };
            default:
                // Exhaustiveness check
                // eslint-disable-next-line no-case-declarations
                const __exhaust = kind;
                throw new Error(`Unrecognized DocumentField type: ${__exhaust}`);
        }
    })();
    return Object.assign(Object.assign({ kind }, value), { boundingRegions: toBoundingRegions(field.boundingRegions), content: field.content, spans: field.spans, confidence: field.confidence });
}
//# sourceMappingURL=fields.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/lro/analysis.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.



/**
 * Transform a REST-level Document response object into the more strongly-typed AnalyzedDocument.
 *
 * @internal
 * @param document - a REST-level document response object
 * @returns an AnalyzedDocument (which has had its fields mapped to stronger DocumentField types)
 */
function toAnalyzedDocumentFromGenerated(document) {
    var _a;
    return Object.assign(Object.assign({}, document), { boundingRegions: toBoundingRegions(document.boundingRegions), fields: toAnalyzedDocumentFieldsFromGenerated((_a = document.fields) !== null && _a !== void 0 ? _a : {}) });
}
/**
 * Tests if one span contains another, by testing that the outer span starts before or at the same character as the
 * inner span, and that the end position of the outer span is greater than or equal to the end position of the inner
 * span.
 *
 * @internal
 * @param outer - the outer (potentially containing) span
 * @param inner - the span to test if `outer` contains
 * @returns true if `inner` is contained inside of `outer`.
 */
function contains(outer, inner) {
    return outer.offset <= inner.offset && outer.offset + outer.length >= inner.offset + inner.length;
}
/**
 * Make an empty generator. This might seem silly, but it's useful for satisfying invariants.
 */
function* empty() {
    /* intentionally empty */
}
/**
 * Produces an iterator of the given items starting from the given index.
 *
 * @param items - the items to iterate over
 * @param idx - the index of the first item to begin iterating from
 */
function* iterFrom(items, idx) {
    let i = idx;
    while (i < items.length) {
        yield items[i++];
    }
}
function toDocumentLineFromGenerated(generated, page) {
    generated.words = () => {
        var _a, _b;
        return fastGetChildren(iterFrom(generated.spans, 0), (_b = (_a = page.words) === null || _a === void 0 ? void 0 : _a.map((word) => {
            return Object.assign(Object.assign({}, word), { polygon: toBoundingPolygon(word.polygon) });
        })) !== null && _b !== void 0 ? _b : []);
    };
    generated.polygon = toBoundingPolygon(generated.polygon);
    Object.defineProperty(generated, "words", {
        enumerable: false,
    });
    return generated;
}
function toDocumentPageFromGenerated(generated) {
    var _a, _b, _c, _d, _e;
    return Object.assign(Object.assign({}, generated), { lines: (_a = generated.lines) === null || _a === void 0 ? void 0 : _a.map((line) => toDocumentLineFromGenerated(line, generated)), selectionMarks: (_b = generated.selectionMarks) === null || _b === void 0 ? void 0 : _b.map((mark) => (Object.assign(Object.assign({}, mark), { polygon: toBoundingPolygon(mark.polygon) }))), words: (_c = generated.words) === null || _c === void 0 ? void 0 : _c.map((word) => (Object.assign(Object.assign({}, word), { polygon: toBoundingPolygon(word.polygon) }))), barcodes: (_d = generated.barcodes) === null || _d === void 0 ? void 0 : _d.map((barcode) => (Object.assign(Object.assign({}, barcode), { polygon: toBoundingPolygon(barcode.polygon) }))), formulas: (_e = generated.formulas) === null || _e === void 0 ? void 0 : _e.map((formula) => (Object.assign(Object.assign({}, formula), { polygon: toBoundingPolygon(formula.polygon) }))) });
}
/**
 * Binary search through an array of items to find the first item that could possibly be contained by the given span,
 * then return an iterator beginning from that item.
 *
 * This allows a program to quickly find the first relevant item in the array for consideration when testing for span
 * inclusion.
 *
 * @internal
 * @param span - the span to use when testing each individual item
 * @param items - an array of items to binary search through
 * @returns an iterator beginning from the item identified by the search
 */
function iteratorFromFirstMatchBinarySearch(span, items) {
    let idx = Math.floor(items.length / 2);
    let prevIdx = idx;
    let min = 0;
    let max = items.length;
    const found = () => { var _a, _b, _c; 
    // The item is found if it starts after the current span and the item before it does not. That means it is the first
    // item in the array that could be a child if the spans are sorted.
    return items[idx].span.offset >= span.offset && ((_c = (_b = (_a = items[idx - 1]) === null || _a === void 0 ? void 0 : _a.span) === null || _b === void 0 ? void 0 : _b.offset) !== null && _c !== void 0 ? _c : -1) < span.offset; };
    // Binary search to find the first element that could be a child
    do {
        if (found()) {
            return iterFrom(items, idx);
        }
        else if (span.offset > items[idx].span.offset) {
            min = prevIdx = idx;
            idx = Math.floor(idx + (max - idx) / 2);
        }
        else {
            max = prevIdx = idx;
            idx = Math.floor(idx - (idx - min) / 2);
        }
    } while (idx !== prevIdx);
    // This might seem weird, but it's a simple way to make the types a little more elegant.
    return empty();
}
/**
 * This fast algorithm tests the elements of `childArray` for inclusion in any of the given `spans`, assuming that both
 * the spans and child items are sorted.
 *
 * INVARIANT: the items in both the `spans` iterator and `childrenArray` MUST BE SORTED INCREASING by span _offset_.
 *
 * @internal
 * @param spans - the spans that contain the child elements
 * @param childrenArray - an array of child items (items that have spans) to test for inclusion in the spans
 * @returns - an IterableIterator of child items that are included in any span in the `spans` iterator
 */
function* fastGetChildren(spans, childrenArray) {
    let curSpan = spans.next();
    // Need to exit early if there are no spans.
    if (curSpan.done) {
        return;
    }
    const children = iteratorFromFirstMatchBinarySearch(curSpan.value, childrenArray);
    let curChild = children.next();
    while (!(curChild.done || curSpan.done)) {
        if (contains(curSpan.value, curChild.value.span)) {
            // The span is contained, so yield the current child and advance it.
            yield curChild.value;
            curChild = children.next();
        }
        else if (curSpan.value.offset + curSpan.value.length < curChild.value.span.offset) {
            // The current span ends before the next potential child starts, so advance the span
            curSpan = spans.next();
        }
        else {
            // The current child was not contained in the current span, so advance to the next child.
            curChild = children.next();
        }
    }
}
/**
 * Convert a generated AnalyzeResult into a convenience layer AnalyzeResult.
 * @internal
 */
function toAnalyzeResultFromGenerated(result) {
    var _a, _b, _c, _d;
    return {
        apiVersion: result.apiVersion,
        modelId: result.modelId,
        content: result.content,
        pages: result.pages.map((page) => toDocumentPageFromGenerated(page)),
        tables: (_a = result.tables) === null || _a === void 0 ? void 0 : _a.map((table) => toDocumentTableFromGenerated(table)),
        keyValuePairs: (_b = result.keyValuePairs) === null || _b === void 0 ? void 0 : _b.map((pair) => toKeyValuePairFromGenerated(pair)),
        languages: result.languages,
        styles: result.styles,
        paragraphs: (_c = result.paragraphs) === null || _c === void 0 ? void 0 : _c.map((para) => (Object.assign(Object.assign({}, para), { boundingRegions: toBoundingRegions(para.boundingRegions) }))),
        documents: (_d = result.documents) === null || _d === void 0 ? void 0 : _d.map(toAnalyzedDocumentFromGenerated),
    };
}
/**
 * Converts an AnalyzeResultOperation (LRO response) to a DocumentAnalysisPollOperationState
 * @internal
 */
function toDocumentAnalysisPollOperationState(definition, modelId, operationLocation, response) {
    return {
        status: response.status,
        modelId: modelId,
        lastUpdatedOn: response.lastUpdatedOn,
        createdOn: response.createdOn,
        operationLocation,
        result: response.analyzeResult && definition.transformResult(response.analyzeResult),
        error: response.error && new error_FormRecognizerError(response.error),
        isCancelled: false, // Not supported
        isStarted: response.status !== "notStarted",
        isCompleted: response.status === "succeeded",
    };
}
//# sourceMappingURL=analysis.js.map
// EXTERNAL MODULE: ./node_modules/@azure/abort-controller/dist/esm/index.js + 1 modules
var abort_controller_dist_esm = __webpack_require__(62417);
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/lro/util/delayMs.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.


/**
 * A promise that delays resolution until a certain amount of time (in milliseconds) has passed, with facilities for
 * robust cancellation.
 *
 * ### Example:
 *
 * ```ts snippet:ignore
 * let toCancel;
 *
 * // Wait 20 seconds, and optionally allow the function to be cancelled.
 * await delayMs(20000, (cancel) => { toCancel = cancel });
 *
 * // ... if `toCancel` is called before the 20 second timer expires, then the delayMs promise will reject.
 * ```
 *
 * @internal
 * @param ms - the number of milliseconds to wait before resolving
 * @param cb - a callback that can provide the caller with a cancellation function
 */
function delayMs(ms, abortSignal) {
    let aborted = false;
    let toReject;
    abortSignal === null || abortSignal === void 0 ? void 0 : abortSignal.addEventListener("abort", () => {
        aborted = true;
        toReject === null || toReject === void 0 ? void 0 : toReject(new abort_controller_dist_esm/* AbortError */.l("The operation was aborted."));
    });
    return Object.assign(new Promise((resolve, reject) => {
        let token;
        toReject = (e) => {
            maybemap(token, clearTimeout);
            reject(e);
        };
        // In the rare case that the operation is _already_ aborted, we will reject instantly. This could happen, for
        // example, if the user calls the cancellation function immediately without yielding execution.
        if (aborted) {
            toReject(new Error("The operation was cancelled prematurely."));
        }
        else {
            token = setTimeout(resolve, ms);
        }
    }), {
        cancel: () => {
            aborted = true;
            toReject === null || toReject === void 0 ? void 0 : toReject(new Error("The operation was cancelled."));
        },
    });
}
//# sourceMappingURL=delayMs.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/lro/util/poller.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.


const DEFAULT_POLLING_INTERVAL = 5000;
/**
 * Uniform poller implementation, creates a poller based on a PollerSpec.
 *
 * @internal
 */
async function poller_lro(spec, pollingInterval, initAbortSignal) {
    let serverDrivenDelay;
    const initContext = {
        abortSignal: initAbortSignal,
        updateDelay: (interval) => {
            serverDrivenDelay = interval;
        },
    };
    if (initAbortSignal === null || initAbortSignal === void 0 ? void 0 : initAbortSignal.aborted) {
        throw new abort_controller_dist_esm/* AbortError */.l("The operation was aborted.");
    }
    let state = await spec.init(initContext);
    // Job handling. If `job` is defined, then there is an active `pollUntilDone` call on this poller.
    // Call `cancelJob` to interrupt the polling loop (awaiters will throw).
    let job;
    let cancelJob;
    const handlers = new Map();
    const handleProgressEvents = async () => handlers.forEach((h) => h(state));
    const self = {
        onProgress: (callback) => {
            const s = Symbol();
            handlers.set(s, callback);
            return () => handlers.delete(s);
        },
        stopPolling: () => cancelJob === null || cancelJob === void 0 ? void 0 : cancelJob(),
        poll: async (options) => {
            state = await spec.poll({
                abortSignal: options === null || options === void 0 ? void 0 : options.abortSignal,
                updateDelay: (interval) => {
                    serverDrivenDelay = interval;
                },
            }, state);
            handleProgressEvents();
        },
        pollUntilDone: (options) => (job !== null && job !== void 0 ? job : (job = (async () => {
            // Technically, the poller could complete during initialization
            if (!self.isDone()) {
                // Poll once to get the ball rolling, this avoids a delay if the operation completes immediately
                await self.poll(options);
                while (!self.isDone()) {
                    const finalPollingInterval = Math.max(serverDrivenDelay !== null && serverDrivenDelay !== void 0 ? serverDrivenDelay : 0, pollingInterval !== null && pollingInterval !== void 0 ? pollingInterval : DEFAULT_POLLING_INTERVAL);
                    const delay = delayMs(finalPollingInterval, options === null || options === void 0 ? void 0 : options.abortSignal);
                    cancelJob = delay.cancel;
                    await delay.then(() => self.poll());
                }
            }
            const result = self.getResult();
            // The state says it's done, so we know we are in either a success case, an error case, or an _internal_ error.
            if (result !== undefined)
                return result;
            else if (state.error !== undefined)
                throw state.error;
            // Unreachable
            else {
                throw new Error(`Internal Client Error: analysis poller completed without success or error: ${state}`);
            }
        })().finally(() => {
            job = undefined;
        }))),
        // The poller is stopped if there is no job running
        isStopped: () => !!job,
        // The operation is complete if either a result or error is produced
        isDone: () => !!state.result || !!state.error,
        // In FR, all operations run to completion
        cancelOperation() {
            throw new Error("The Azure Form Recognizer service does not support operation cancellation.");
        },
        getOperationState: () => state,
        getResult: () => state.result,
        toString: () => spec.serialize(state),
    };
    return self;
}
//# sourceMappingURL=poller.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/documentAnalysisClient.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.






/**
 * A client for interacting with the Form Recognizer service's analysis features.
 *
 * ### Examples:
 *
 * The Form Recognizer service and clients support two means of authentication:
 *
 * #### Azure Active Directory
 *
 * ```ts snippet:ReadmeSampleCreateClient_TokenCredential
 * import { DefaultAzureCredential } from "@azure/identity";
 * import { DocumentAnalysisClient } from "@azure/ai-form-recognizer";
 *
 * const credential = new DefaultAzureCredential();
 * const client = new DocumentAnalysisClient(
 *   "https://<resource name>.cognitiveservices.azure.com",
 *   credential,
 * );
 * ```
 *
 * #### API Key (Subscription Key)
 *
 * ```ts snippet:ReadmeSampleCreateClient_KeyCredential
 * import { AzureKeyCredential, DocumentAnalysisClient } from "@azure/ai-form-recognizer";
 *
 * const credential = new AzureKeyCredential("<API key>");
 * const client = new DocumentAnalysisClient(
 *   "https://<resource name>.cognitiveservices.azure.com",
 *   credential,
 * );
 * ```
 */
class DocumentAnalysisClient {
    constructor(endpoint, credential, options = {}) {
        this._restClient = util_makeServiceClient(endpoint, credential, options);
        this._tracing = (0,dist_esm/* createTracingClient */.y)({
            packageName: "@azure/ai-form-recognizer",
            packageVersion: constants_SDK_VERSION,
            namespace: "Microsoft.CognitiveServices",
        });
    }
    async beginAnalyzeDocument(model, document, 
    // eslint-disable-next-line @azure/azure-sdk/ts-naming-options
    options = {}) {
        return this._tracing.withSpan("DocumentAnalysisClient.beginAnalyzeDocument", options, 
        // In the first version of the SDK, the document input was treated as a URL if it was a string, and we preserve
        // this behavior to avoid introducing a breaking change.
        this.analyze.bind(this, model, typeof document === "string" ? source("url", document) : source("body", document)));
    }
    async beginAnalyzeDocumentFromUrl(model, documentUrl, 
    // eslint-disable-next-line @azure/azure-sdk/ts-naming-options
    options = {}) {
        return this._tracing.withSpan("DocumentAnalysisClient.beginAnalyzeDocumentFromUrl", options, this.analyze.bind(this, model, source("url", documentUrl)));
    }
    /**
     * A helper method for running analysis polymorphically.
     *
     * @param model - the model ID or DocumentModel to use for analysis
     * @param input - the string URL or request body to use
     * @param options - analysis options
     * @returns - an analysis poller
     */
    analyze(model, input, options) {
        const { modelId: initialModelId, apiVersion: requestApiVersion, transformResult, } = typeof model === "string"
            ? { modelId: model, apiVersion: undefined, transformResult: (v) => v }
            : model;
        if (requestApiVersion && requestApiVersion !== FORM_RECOGNIZER_API_VERSION) {
            throw new Error([
                `API Version mismatch: the provided model wants version: ${requestApiVersion},`,
                `but the client is using ${FORM_RECOGNIZER_API_VERSION}.`,
                "The API version of the model must match the client's API version.",
            ].join(" "));
        }
        return this.createUnifiedPoller((abortSignal) => {
            const [contentType, analyzeRequest] = toAnalyzeRequest(input);
            if (contentType === "application/json") {
                return this._restClient.documentModels.analyzeDocument(initialModelId, contentType, Object.assign(Object.assign({}, options), { abortSignal,
                    analyzeRequest }));
            }
            else {
                return this._restClient.documentModels.analyzeDocument(initialModelId, contentType, Object.assign(Object.assign({}, options), { abortSignal,
                    analyzeRequest }));
            }
        }, {
            initialModelId,
            options,
            transformResult: (result) => transformResult(toAnalyzeResultFromGenerated(result)),
        });
    }
    /**
     * Classify a document using a custom classifier given by its ID.
     *
     * This method produces a long-running operation (poller) that will eventually produce an `AnalyzeResult`. This is the
     * same type as `beginAnalyzeDocument` and `beginAnalyzeDocumentFromUrl`, but the result will only contain a small
     * subset of its fields. Only the `documents` field and `pages` field will be populated, and only minimal page
     * information will be returned. The `documents` field will contain information about all the identified documents and
     * the `docType` that they were classified as.
     *
     * ### Example
     *
     * This method supports streamable request bodies ({@link FormRecognizerRequestBody}) such as Node.JS `ReadableStream`
     * objects, browser `Blob`s, and `ArrayBuffer`s. The contents of the body will be uploaded to the service for analysis.
     *
     * ```ts snippet:ReadmeSampleClassifyDocument_File
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentAnalysisClient } from "@azure/ai-form-recognizer";
     * import { createReadStream } from "node:fs";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentAnalysisClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * const path = "<path to a document>";
     * const readStream = createReadStream(path);
     *
     * const poller = await client.beginClassifyDocument("<classifier id>", readStream);
     *
     * const result = await poller.pollUntilDone();
     *
     * if (result?.documents?.length === 0) {
     *   throw new Error("Failed to extract any documents.");
     * }
     *
     * for (const document of result.documents) {
     *   console.log(
     *     `Extracted a document with type '${document.docType}' on page ${document.boundingRegions?.[0].pageNumber} (confidence: ${document.confidence})`,
     *   );
     * }
     * ```
     *
     * @param classifierId - the ID of the custom classifier to use for analysis
     * @param document - the document to classify
     * @param options - options for the classification operation
     * @returns a long-running operation (poller) that will eventually produce an `AnalyzeResult`
     */
    async beginClassifyDocument(classifierId, document, 
    // eslint-disable-next-line @azure/azure-sdk/ts-naming-options
    options = {}) {
        return this._tracing.withSpan("DocumentAnalysisClient.beginClassifyDocument", options, this.classify.bind(this, classifierId, source("body", document)));
    }
    /**
     * Classify a document from a URL using a custom classifier given by its ID.
     *
     * This method produces a long-running operation (poller) that will eventually produce an `AnalyzeResult`. This is the
     * same type as `beginAnalyzeDocument` and `beginAnalyzeDocumentFromUrl`, but the result will only contain a small
     * subset of its fields. Only the `documents` field and `pages` field will be populated, and only minimal page
     * information will be returned. The `documents` field will contain information about all the identified documents and
     * the `docType` that they were classified as.
     *
     * ### Example
     *
     * This method supports extracting data from a file at a given URL. The Form Recognizer service will attempt to
     * download a file using the submitted URL, so the URL must be accessible from the public internet. For example, a SAS
     * token can be used to grant read access to a blob in Azure Storage, and the service will use the SAS-encoded URL to
     * request the file.
     *
     * ```ts snippet:ReadmeSampleClassifyDocument
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentAnalysisClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentAnalysisClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * const documentUrl =
     *   "https://raw.githubusercontent.com/Azure/azure-sdk-for-js/main/sdk/formrecognizer/ai-form-recognizer/assets/invoice/Invoice_1.pdf";
     *
     * const poller = await client.beginClassifyDocumentFromUrl("<classifier id>", documentUrl);
     *
     * const result = await poller.pollUntilDone();
     *
     * if (result?.documents?.length === 0) {
     *   throw new Error("Failed to extract any documents.");
     * }
     *
     * for (const document of result.documents) {
     *   console.log(
     *     `Extracted a document with type '${document.docType}' on page ${document.boundingRegions?.[0].pageNumber} (confidence: ${document.confidence})`,
     *   );
     * }
     * ```
     * @param classifierId - the ID of the custom classifier to use for analysis
     * @param documentUrl - the URL of the document to classify
     * @param options -
     * @returns
     */
    async beginClassifyDocumentFromUrl(classifierId, documentUrl, 
    // eslint-disable-next-line @azure/azure-sdk/ts-naming-options
    options = {}) {
        return this._tracing.withSpan("DocumentAnalysisClient.beginClassifyDocumentFromUrl", options, this.classify.bind(this, classifierId, source("url", documentUrl)));
    }
    /**
     * A helper method for running classification polymorphically.
     * @param classifierId - the ID of the classifier to use
     * @param input - the string URL or request body to use
     * @param options - analysis options
     * @returns an analysis poller
     */
    classify(classifierId, input, options) {
        return this.createUnifiedPoller(async (abortSignal) => {
            const [contentType, classifyRequest] = toAnalyzeRequest(input);
            if (contentType === "application/json") {
                return this._restClient.documentClassifiers.classifyDocument(classifierId, contentType, Object.assign(Object.assign({}, options), { abortSignal,
                    classifyRequest }));
            }
            else {
                return this._restClient.documentClassifiers.classifyDocument(classifierId, contentType, Object.assign(Object.assign({}, options), { abortSignal,
                    classifyRequest }));
            }
        }, {
            initialModelId: classifierId,
            options,
            transformResult: toAnalyzeResultFromGenerated,
        });
    }
    /**
     * Create an LRO poller that handles analysis operations.
     *
     * This is the meat of all analysis polling operations.
     *
     * @param startOperation - function that starts the operation and returns the operation location
     * @param definition - operation definition (initial model ID, operation transforms, request options)
     * @returns - an analysis poller that produces the given return types according to the operation spec
     */
    async createUnifiedPoller(startOperation, definition) {
        const { resumeFrom } = definition.options;
        // TODO: what should we do if resumeFrom.modelId is different from initialModelId?
        // And what do we do with the redundant input??
        const getAnalyzeResult = (ctx, operationLocation) => this._tracing.withSpan("DocumentAnalysisClient.createAnalysisPoller-getAnalyzeResult", definition.options, (finalOptions) => this._restClient.sendOperationRequest({
            options: Object.assign(Object.assign({ onResponse: async (rawResponse, ...args) => {
                    var _a;
                    // Capture the `Retry-After` header if it was sent.
                    const retryAfterHeader = rawResponse.headers.get("retry-after");
                    // Convert the header value to milliseconds. If the header is not a valid number, then it is an HTTP
                    // date.
                    if (retryAfterHeader) {
                        const retryAfterMs = Number(retryAfterHeader) * 1000;
                        if (!Number.isNaN(retryAfterMs)) {
                            ctx.updateDelay(retryAfterMs);
                        }
                        else {
                            ctx.updateDelay(Date.parse(retryAfterHeader) - Date.now());
                        }
                    }
                    else {
                        ctx.updateDelay(undefined);
                    }
                    // Forward the `onResponse` callback if it was provided.
                    return (_a = finalOptions.onResponse) === null || _a === void 0 ? void 0 : _a.call(finalOptions, rawResponse, ...args);
                } }, finalOptions), { 
                // We need to pass the abort signal from the context rather than from the options, since the user could
                // poll the LRO with a different AbortSignal than it was instantiated with.
                abortSignal: ctx.abortSignal }),
        }, {
            path: operationLocation,
            httpMethod: "GET",
            responses: {
                200: {
                    bodyMapper: AnalyzeResultOperation,
                },
                default: {
                    bodyMapper: ErrorResponse,
                },
            },
            // URL is fully-formed, so we don't need any query parameters
            headerParameters: [parameters_accept1],
            serializer: util_SERIALIZER,
        }));
        const toInit = 
        // If the user gave us a stored token, we'll poll it again
        resumeFrom !== undefined
            ? async (ctx) => this._tracing.withSpan("DocumentAnalysisClient.createAnalysisPoller-resume", definition.options, async () => {
                const { clientVersion, operationLocation, modelId } = JSON.parse(resumeFrom);
                if (!clientVersion || clientVersion !== constants_SDK_VERSION) {
                    throw new Error([
                        "Cannot restore poller from a serialized state from a different version of the client",
                        `library (restoreFrom: '${clientVersion}', current: '${constants_SDK_VERSION}').`,
                    ].join(" "));
                }
                const result = await getAnalyzeResult(ctx, operationLocation);
                return toDocumentAnalysisPollOperationState(definition, modelId, operationLocation, result);
            })
            : // Otherwise, we'll start a new operation from the initialModelId
                async (ctx) => this._tracing.withSpan("DocumentAnalysisClient.createAnalysisPoller-start", definition.options, async () => {
                    const { operationLocation } = await startOperation(ctx.abortSignal);
                    if (operationLocation === undefined) {
                        throw new Error("Unable to start analysis operation: no Operation-Location received.");
                    }
                    const result = await getAnalyzeResult(ctx, operationLocation);
                    return toDocumentAnalysisPollOperationState(definition, definition.initialModelId, operationLocation, result);
                });
        const poller = await poller_lro({
            init: toInit,
            poll: async (ctx, { operationLocation, modelId }) => this._tracing.withSpan("DocumentAnalysisClient.createAnalysisPoller-poll", {}, async () => {
                const result = await getAnalyzeResult(ctx, operationLocation);
                return toDocumentAnalysisPollOperationState(definition, modelId, operationLocation, result);
            }),
            serialize: ({ operationLocation, modelId }) => JSON.stringify({ clientVersion: constants_SDK_VERSION, id: modelId, operationLocation }),
        }, definition.options.updateIntervalInMs, definition.options.abortSignal);
        if (definition.options.onProgress !== undefined) {
            poller.onProgress(definition.options.onProgress);
            definition.options.onProgress(poller.getOperationState());
        }
        return poller;
    }
}
/**
 * Produce an appropriate pair of content-type and analyzeRequest value for the analysis request.
 * @internal
 */
function toAnalyzeRequest(input) {
    switch (input.kind) {
        case "body":
            return ["application/octet-stream", input.body];
        case "url":
            return ["application/json", { urlSource: input.url }];
        case "base64":
            return ["application/json", { base64Source: input.base64 }];
        default: {
            const __exhaust = input;
            throw new Error(`Unreachable 'toAnalyzeRequest' case: ${__exhaust}`);
        }
    }
}
/**
 * The input to a document analysis operation.
 */
// type DocumentSource = DocumentBodySource | DocumentUrlSource | DocumentBase64Source;
function source(kind, value) {
    return {
        kind,
        [kind]: value,
    };
}
//# sourceMappingURL=documentAnalysisClient.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/lro/administration.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

/**
 * Convert an operation result into a training poller state.
 * @internal
 */
async function administration_toTrainingPollOperationState(response) {
    var _a;
    return {
        operationId: response.operationId,
        status: response.status,
        apiVersion: response.apiVersion,
        percentCompleted: (_a = response.percentCompleted) !== null && _a !== void 0 ? _a : 0,
        lastUpdatedOn: response.lastUpdatedOn,
        createdOn: response.createdOn,
        error: response.error && new FormRecognizerError(response.error),
        isCancelled: response.status === "canceled",
        isCompleted: response.status === "succeeded",
        isStarted: response.status !== "notStarted",
        tags: response.tags,
        // The following assertion is required. Technically the type of `response.result` is
        // `DocumentModelDetails | DocumentClassifierDetails | undefined`, which isn't assignable to the type of
        // either operation state's result. We would need some kind of dependent typing to express how the type of `result`
        // actually _determines_ the type of the resulting return value.
        result: response.result,
    };
}
//# sourceMappingURL=administration.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/documentModelAdministrationClient.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.






/**
 * A client for interacting with the Form Recognizer service's model management features, such as creating, reading,
 * listing, deleting, and copying models.
 *
 * ### Examples:
 *
 * #### Azure Active Directory
 *
 * ```ts snippet:ReadmeSampleAdministrationClient_TokenCredential
 * import { DefaultAzureCredential } from "@azure/identity";
 * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
 *
 * const credential = new DefaultAzureCredential();
 * const client = new DocumentModelAdministrationClient(
 *   "https://<resource name>.cognitiveservices.azure.com",
 *   credential,
 * );
 * ```
 *
 * #### API Key (Subscription Key)
 *
 * ```ts snippet:ReadmeSampleAdministrationClient_KeyCredential
 * import { AzureKeyCredential, DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
 *
 * const credential = new AzureKeyCredential("<API key>");
 * const client = new DocumentModelAdministrationClient(
 *   "https://<resource name>.cognitiveservices.azure.com",
 *   credential,
 * );
 * ```
 */
class DocumentModelAdministrationClient {
    constructor(endpoint, credential, options = {}) {
        this._restClient = makeServiceClient(endpoint, credential, options);
        this._tracing = createTracingClient({
            packageName: "@azure/ai-form-recognizer",
            packageVersion: SDK_VERSION,
            namespace: "Microsoft.CognitiveServices",
        });
    }
    async beginBuildDocumentModel(modelId, urlOrSource, buildMode, options = {}) {
        const sourceInfo = typeof urlOrSource === "string"
            ? {
                azureBlobSource: {
                    containerUrl: urlOrSource,
                },
            }
            : urlOrSource;
        return this._tracing.withSpan("DocumentModelAdministrationClient.beginBuildDocumentModel", options, (finalOptions) => this.createAdministrationPoller({
            options: finalOptions,
            start: (ctx) => this._restClient.documentModels.buildModel(Object.assign(Object.assign({ modelId, description: finalOptions.description }, sourceInfo), { buildMode }), Object.assign(Object.assign({}, finalOptions), { abortSignal: ctx.abortSignal })),
        }));
    }
    /**
     * Creates a single composed model from several pre-existing submodels.
     *
     * The resulting composed model combines the document types of its component models, and inserts a classification step
     * into the extraction pipeline to determine which of its component submodels is most appropriate for the given input.
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleComposeModel
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * const composeModelId = "aNewComposedModel";
     * const subModelIds = ["documentType1Model", "documentType2Model", "documentType3Model"];
     *
     * // The resulting composed model can classify and extract data from documents
     * // conforming to any of the above document types
     * const poller = await client.beginComposeDocumentModel(composeModelId, subModelIds, {
     *   description: "This is a composed model that can handle several document types.",
     * });
     * // Model composition, like all other model creation operations, returns a poller that eventually produces a
     * // ModelDetails object
     * const modelDetails = await poller.pollUntilDone();
     *
     * const {
     *   modelId, // identical to the modelId given when creating the model
     *   description, // identical to the description given when creating the model
     *   createdOn, // the Date (timestamp) that the model was created
     *   docTypes, // information about the document types of the composed submodels
     * } = modelDetails;
     * ```
     *
     * @param modelId - the unique ID of the model to create
     * @param componentModelIds - an Iterable of strings representing the unique model IDs of the models to compose
     * @param options - optional settings for model creation
     * @returns a long-running operation (poller) that will eventually produce the created model information or an error
     */
    async beginComposeDocumentModel(modelId, componentModelIds, options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.beginComposeDocumentModel", options, (finalOptions) => this.createAdministrationPoller({
            options: finalOptions,
            start: (ctx) => this._restClient.documentModels.composeModel({
                modelId,
                componentModels: [...componentModelIds].map((submodelId) => ({
                    modelId: submodelId,
                })),
                description: finalOptions.description,
                tags: finalOptions.tags,
            }, Object.assign(Object.assign({}, finalOptions), { abortSignal: ctx.abortSignal })),
        }));
    }
    /**
     * Creates an authorization to copy a model into the resource, used with the `beginCopyModelTo` method.
     *
     * The `CopyAuthorization` grants another cognitive service resource the right to create a model in this client's
     * resource with the model ID and optional description that are encoded into the authorization.
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleGetCopyAuthorization
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * // The copyAuthorization data structure stored below grants any cognitive services resource the right to copy a
     * // model into the client's resource with the given destination model ID.
     * const copyAuthorization = await client.getCopyAuthorization("<destination model ID>");
     * ```
     *
     * @param destinationModelId - the unique ID of the destination model (the ID to copy the model into)
     * @param options - optional settings for creating the copy authorization
     * @returns a copy authorization that encodes the given modelId and optional description
     */
    async getCopyAuthorization(destinationModelId, options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.getCopyAuthorization", options, (finalOptions) => this._restClient.documentModels.authorizeModelCopy({
            modelId: destinationModelId,
            description: finalOptions.description,
            tags: finalOptions.tags,
        }, finalOptions));
    }
    /**
     * Copies a model with the given ID into the resource and model ID encoded by a given copy authorization.
     *
     * See {@link CopyAuthorization} and {@link getCopyAuthorization}.
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleCopyModel
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient, AzureKeyCredential } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * // We create the copy authorization using a client authenticated with the destination resource. Note that these two
     * // resources can be the same (you can copy a model to a new ID in the same resource).
     * const copyAuthorization = await client.getCopyAuthorization("<destination model ID>");
     *
     * // Finally, use the _source_ client to copy the model and await the copy operation
     * // We need a client for the source model's resource
     * const sourceEndpoint = "https://<source resource name>.cognitiveservices.azure.com";
     * const sourceCredential = new AzureKeyCredential("<source api key>");
     * const sourceClient = new DocumentModelAdministrationClient(sourceEndpoint, sourceCredential);
     * const poller = await sourceClient.beginCopyModelTo("<source model ID>", copyAuthorization);
     *
     * // Model copying, like all other model creation operations, returns a poller that eventually produces a ModelDetails
     * // object
     * const modelDetails = await poller.pollUntilDone();
     *
     * const {
     *   modelId, // identical to the modelId given when creating the copy authorization
     *   description, // identical to the description given when creating the copy authorization
     *   createdOn, // the Date (timestamp) that the model was created
     *   docTypes, // information about the document types of the model (identical to the original, source model)
     * } = modelDetails;
     * ```
     *
     * @param sourceModelId - the unique ID of the source model that will be copied
     * @param authorization - an authorization to copy the model, created using the {@link getCopyAuthorization}
     * @param options - optional settings for
     * @returns a long-running operation (poller) that will eventually produce the copied model information or an error
     */
    async beginCopyModelTo(sourceModelId, authorization, 
    // eslint-disable-next-line @azure/azure-sdk/ts-naming-options
    options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.beginCopyModel", options, (finalOptions) => this.createAdministrationPoller({
            options: finalOptions,
            start: () => this._restClient.documentModels.copyModelTo(sourceModelId, authorization, finalOptions),
        }));
    }
    // #endregion
    // #region Document Classifiers
    /**
     * Build a new document classifier with the given classifier ID and document types.
     *
     * The classifier ID must be unique among classifiers within the resource.
     *
     * The document types are given as an object that maps the name of the document type to the training data set for that
     * document type. Two training data input methods are supported:
     *
     * - `azureBlobSource`, which trains a classifier using the data in the given Azure Blob Storage container.
     * - `azureBlobFileListSource`, which is similar to `azureBlobSource` but allows for more fine-grained control over
     *   the files that are included in the training data set by using a JSONL-formatted file list.
     *
     * The Form Recognizer service reads the training data set from an Azure Storage container, given as a URL to the
     * container with a SAS token that allows the service backend to communicate with the container. At a minimum, the
     * "read" and "list" permissions are required. In addition, the data in the given container must be organized
     * according to a particular convention, which is documented in [the service's documentation for building custom
     * document classifiers](https://aka.ms/azsdk/formrecognizer/buildclassifiermodel).
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleBuildClassifier
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * const newClassifiedId = "aNewClassifier";
     * const containerUrl1 = "<training data container SAS URL 1>";
     * const containerUrl2 = "<training data container SAS URL 2>";
     *
     * const poller = await client.beginBuildDocumentClassifier(
     *   newClassifiedId,
     *   {
     *     // The document types. Each entry in this object should map a document type name to a
     *     // `ClassifierDocumentTypeDetails` object
     *     formX: {
     *       azureBlobSource: {
     *         containerUrl: containerUrl1,
     *       },
     *     },
     *     formY: {
     *       azureBlobFileListSource: {
     *         containerUrl: containerUrl2,
     *         fileList: "path/to/fileList.jsonl",
     *       },
     *     },
     *   },
     *   {
     *     // Optionally, a text description may be attached to the classifier
     *     description: "This is an example classifier!",
     *   },
     * );
     *
     * // Classifier building, like model creation operations, returns a poller that eventually produces a
     * // DocumentClassifierDetails object
     * const classifierDetails = await poller.pollUntilDone();
     *
     * const {
     *   classifierId, // identical to the classifierId given when creating the classifier
     *   description, // identical to the description given when creating the classifier (if any)
     *   createdOn, // the Date (timestamp) that the classifier was created
     *   docTypes, // information about the document types in the classifier and their details
     * } = classifierDetails;
     * ```
     *
     * @param classifierId - the unique ID of the classifier to create
     * @param docTypeSources - the document types to include in the classifier and their sources (a map of document type
     *                         names to `ClassifierDocumentTypeDetails`)
     * @param options - optional settings for the classifier build operation
     * @returns a long-running operation (poller) that will eventually produce the created classifier details or an error
     */
    async beginBuildDocumentClassifier(classifierId, docTypeSources, options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.beginBuildDocumentClassifier", options, (finalOptions) => this.createAdministrationPoller({
            options: finalOptions,
            start: () => this._restClient.documentClassifiers.buildClassifier({
                classifierId,
                description: finalOptions.description,
                docTypes: docTypeSources,
            }, finalOptions),
        }));
    }
    // #endregion
    /**
     * Create an LRO poller that handles model creation operations.
     *
     * This is the meat of the above model creation operations.
     *
     * @param definition - operation definition (start operation method, request options)
     * @returns a model poller (produces a ModelDetails)
     */
    async createAdministrationPoller(definition) {
        const { resumeFrom } = definition.options;
        const toInit = resumeFrom === undefined
            ? (ctx) => this._tracing.withSpan("DocumentModelAdministrationClient.createDocumentModelPoller-start", definition.options, async (options) => {
                const { operationLocation } = await definition.start(ctx);
                if (operationLocation === undefined) {
                    throw new Error("Unable to start model creation operation: no Operation-Location received.");
                }
                return this._restClient.sendOperationRequest({
                    options: Object.assign(Object.assign({ onResponse: (rawResponse, ...args) => {
                            return captureRetryAfter(rawResponse, ctx, options, args);
                        } }, options), { abortSignal: ctx.abortSignal }),
                }, {
                    path: operationLocation,
                    httpMethod: "GET",
                    responses: {
                        200: {
                            bodyMapper: Mappers.OperationDetails,
                        },
                        default: {
                            bodyMapper: Mappers.ErrorResponse,
                        },
                    },
                    headerParameters: [accept1],
                    serializer: SERIALIZER,
                });
            })
            : (ctx) => this._tracing.withSpan("DocumentModelAdministrationClient.createDocumentModelPoller-resume", definition.options, (options) => {
                const { operationId } = JSON.parse(resumeFrom);
                return this._restClient.miscellaneous.getOperation(operationId, Object.assign({ onResponse: (rawResponse, ...args) => {
                        return captureRetryAfter(rawResponse, ctx, options, args);
                    } }, options));
            });
        const poller = await lro({
            init: async (ctx) => toTrainingPollOperationState(await toInit(ctx)),
            poll: async (ctx, { operationId }) => this._tracing.withSpan("DocumentModelAdminstrationClient.createDocumentModelPoller-poll", definition.options, async (options) => {
                const res = await this._restClient.miscellaneous.getOperation(operationId, Object.assign(Object.assign({ onResponse: (rawResponse, ...args) => {
                        // Capture the `Retry-After` header if it was sent.
                        return captureRetryAfter(rawResponse, ctx, options, args);
                    } }, options), { abortSignal: ctx.abortSignal }));
                return toTrainingPollOperationState(res);
            }),
            serialize: ({ operationId }) => JSON.stringify({ operationId }),
        }, definition.options.updateIntervalInMs, definition.options.abortSignal);
        if (definition.options.onProgress !== undefined) {
            poller.onProgress(definition.options.onProgress);
            definition.options.onProgress(poller.getOperationState());
        }
        // Need this assertion. The poller above is dynamic, and we can't infer the conditional return type of this method.
        return poller;
        /**
         * An inline helper for capturing the value of the `Retry-After` header if it was sent.
         * @param rawResponse - the raw response from the service
         * @param ctx - the operation context
         * @param options - the operation options
         * @param args - the arguments passed to the response handler
         * @returns
         */
        function captureRetryAfter(rawResponse, ctx, options, args) {
            var _a;
            const retryAfterHeader = rawResponse.headers.get("retry-after");
            // Convert the header value to milliseconds. If the header is not a valid number, then it is an HTTP
            // date.
            if (retryAfterHeader) {
                const retryAfterMs = Number(retryAfterHeader) * 1000;
                if (!Number.isNaN(retryAfterMs)) {
                    ctx.updateDelay(retryAfterMs);
                }
                else {
                    ctx.updateDelay(Date.parse(retryAfterHeader) - Date.now());
                }
            }
            else {
                ctx.updateDelay(undefined);
            }
            // Forward the `onResponse` callback if it was provided.
            return (_a = options.onResponse) === null || _a === void 0 ? void 0 : _a.call(options, rawResponse, ...args);
        }
    }
    // #region Model Management
    /**
     * Retrieve basic information about this client's resource.
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleGetResourceDetails
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * const {
     *   // Information about the custom models in the current resource
     *   customDocumentModels: {
     *     // The number of custom models in the current resource
     *     count,
     *     // The maximum number of models that the current resource can support
     *     limit,
     *   },
     * } = await client.getResourceDetails();
     * ```
     *
     * @param options - optional settings for the request
     * @returns basic information about this client's resource
     */
    getResourceDetails(options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.getResourceDetails", options, (finalOptions) => this._restClient.miscellaneous.getResourceInfo(finalOptions));
    }
    /**
     * Retrieves information about a model ({@link DocumentModelDetails}) by ID.
     *
     * This method can retrieve information about custom as well as prebuilt models.
     *
     * ### **Breaking Change**
     *
     * In previous versions of the Form Recognizer REST API and SDK, the `getModel` method could return any model, even
     * one that failed to create due to errors. In the new service versions, `getDocumentModel` and `listDocumentModels`
     * _only produce successfully created models_ (i.e. models that are "ready" for use). Failed models are now retrieved
     * through the "operations" APIs, see {@link getOperation} and {@link listOperations}.
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleGetModel
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * // The ID of the prebuilt business card model
     * const prebuiltModelId = "prebuilt-businessCard";
     *
     * const {
     *   modelId, // identical to the modelId given when calling `getDocumentModel`
     *   description, // a textual description of the model, if provided during model creation
     *   createdOn, // the Date (timestamp) that the model was created
     *   // information about the document types in the model and their field schemas
     *   docTypes: {
     *     // the document type of the prebuilt business card model
     *     "prebuilt:businesscard": {
     *       // an optional, textual description of this document type
     *       description: businessCardDescription,
     *       // the schema of the fields in this document type, see the FieldSchema type
     *       fieldSchema,
     *       // the service's confidences in the fields (an object with field names as properties and numeric confidence
     *       // values)
     *       fieldConfidence,
     *     },
     *   },
     * } = await client.getDocumentModel(prebuiltModelId);
     * ```
     *
     * @param modelId - the unique ID of the model to query
     * @param options - optional settings for the request
     * @returns information about the model with the given ID
     */
    getDocumentModel(modelId, 
    // eslint-disable-next-line @azure/azure-sdk/ts-naming-options
    options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.getDocumentModel", options, (finalOptions) => this._restClient.documentModels.getModel(modelId, finalOptions));
    }
    /**
     * List summaries of models in the resource. Custom as well as prebuilt models will be included. This operation
     * supports paging.
     *
     * The model summary ({@link DocumentModelSummary}) includes only the basic information about the model, and does not include
     * information about the document types in the model (such as the field schemas and confidence values).
     *
     * To access the full information about the model, use {@link getDocumentModel}.
     *
     * ### **Breaking Change**
     *
     * In previous versions of the Form Recognizer REST API and SDK, the `listModels` method would return all models, even
     * those that failed to create due to errors. In the new service versions, `listDocumentModels` and `getDocumentModel`
     * _only produce successfully created models_ (i.e. models that are "ready" for use). Failed models are now retrieved
     * through the "operations" APIs, see {@link getOperation} and {@link listOperations}.
     *
     * ### Examples
     *
     * #### Async Iteration
     *
     * ```ts snippet:ReadmeSampleListModels
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * // Iterate over all models in the current resource
     * for await (const summary of client.listDocumentModels()) {
     *   const {
     *     modelId, // The model's unique ID
     *     description, // a textual description of the model, if provided during model creation
     *   } = summary;
     *
     *   // You can get the full model info using `getDocumentModel`
     *   const model = await client.getDocumentModel(modelId);
     * }
     *
     * // The listDocumentModels method is paged, and you can iterate by page using the `byPage` method.
     * const pages = client.listDocumentModels().byPage();
     *
     * for await (const page of pages) {
     *   // Each page is an array of models and can be iterated synchronously
     *   for (const summary of page) {
     *     const {
     *       modelId, // The model's unique ID
     *       description, // a textual description of the model, if provided during model creation
     *     } = summary;
     *
     *     // You can get the full model info using `getDocumentModel`
     *     const model = await client.getDocumentModel(modelId);
     *   }
     * }
     * ```
     *
     * @param options - optional settings for the model requests
     * @returns an async iterable of model summaries that supports paging
     */
    listDocumentModels(
    // eslint-disable-next-line @azure/azure-sdk/ts-naming-options
    options = {}) {
        return this._restClient.documentModels.listModels(options);
    }
    /**
     * Deletes a model with the given ID from the client's resource, if it exists. This operation CANNOT be reverted.
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleDeleteModel
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * await client.deleteDocumentModel("<model ID to delete>");
     * ```
     *
     * @param modelId - the unique ID of the model to delete from the resource
     * @param options - optional settings for the request
     */
    deleteDocumentModel(modelId, options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.deleteDocumentModel", options, (finalOptions) => this._restClient.documentModels.deleteModel(modelId, finalOptions));
    }
    // #endregion
    // #region Classifier Management
    /**
     * Retrieves information about a classifier ({@link DocumentClassifierDetails}) by ID.
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleGetClassifier
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * const foundClassifier = "<classifier ID>";
     *
     * const {
     *   classifierId, // identical to the ID given when calling `getDocumentClassifier`
     *   description, // a textual description of the classifier, if provided during classifier creation
     *   createdOn, // the Date (timestamp) that the classifier was created
     *   // information about the document types in the classifier and their corresponding traning data
     *   docTypes,
     * } = await client.getDocumentClassifier(foundClassifier);
     *
     * // The `docTypes` property is a map of document type names to information about the training data
     * // for that document type.
     * for (const [docTypeName, classifierDocTypeDetails] of Object.entries(docTypes)) {
     *   console.log(`- '${docTypeName}': `, classifierDocTypeDetails);
     * }
     * ```
     *
     * @param classifierId - the unique ID of the classifier to query
     * @param options - optional settings for the request
     * @returns information about the classifier with the given ID
     */
    getDocumentClassifier(classifierId, options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.getDocumentClassifier", options, (finalOptions) => this._restClient.documentClassifiers.getClassifier(classifierId, finalOptions));
    }
    /**
     * List details about classifiers in the resource. This operation supports paging.
     *
     * ### Examples
     *
     * #### Async Iteration
     *
     * ```ts snippet:ReadmeSampleListClassifiers
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * for await (const details of client.listDocumentClassifiers()) {
     *   const {
     *     classifierId, // The classifier's unique ID
     *     description, // a textual description of the classifier, if provided during creation
     *     docTypes, // information about the document types in the classifier and their corresponding traning data
     *   } = details;
     * }
     *
     * // The listDocumentClassifiers method is paged, and you can iterate by page using the `byPage` method.
     * const pages = client.listDocumentClassifiers().byPage();
     *
     * for await (const page of pages) {
     *   // Each page is an array of classifiers and can be iterated synchronously
     *   for (const details of page) {
     *     const {
     *       classifierId, // The classifier's unique ID
     *       description, // a textual description of the classifier, if provided during creation
     *       docTypes, // information about the document types in the classifier and their corresponding traning data
     *     } = details;
     *   }
     * }
     * ```
     *
     * @param options - optional settings for the classifier requests
     * @returns an async iterable of classifier details that supports paging
     */
    listDocumentClassifiers(
    // eslint-disable-next-line @azure/azure-sdk/ts-naming-options
    options = {}) {
        return this._restClient.documentClassifiers.listClassifiers(options);
    }
    /**
     * Deletes a classifier with the given ID from the client's resource, if it exists. This operation CANNOT be reverted.
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleDeleteClassifier
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * await client.deleteDocumentClassifier("<classifier ID to delete>");
     * ```
     *
     * @param classifierId - the unique ID of the classifier to delete from the resource
     * @param options - optional settings for the request
     */
    deleteDocumentClassifier(classifierId, options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.deleteDocumentClassifier", options, (finalOptions) => this._restClient.documentClassifiers.deleteClassifier(classifierId, finalOptions));
    }
    // #endregion
    // #region Operations
    /**
     * Retrieves information about an operation (`OperationDetails`) by its ID.
     *
     * Operations represent non-analysis tasks, such as building, composing, or copying a model.
     *
     * @param operationId - the ID of the operation to query
     * @param options - optional settings for the request
     * @returns information about the operation with the given ID
     *
     * ### Example
     *
     * ```ts snippet:ReadmeSampleGetOperation
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * // The ID of the operation, which should be a GUID
     * const findOperationId = "<operation GUID>";
     *
     * const {
     *   operationId, // identical to the operationId given when calling `getOperation`
     *   kind, // the operation kind, one of "documentModelBuild", "documentModelCompose", or "documentModelCopyTo"
     *   status, // the status of the operation, one of "notStarted", "running", "failed", "succeeded", or "canceled"
     *   percentCompleted, // a number between 0 and 100 representing the progress of the operation
     *   createdOn, // a Date object that reflects the time when the operation was started
     *   lastUpdatedOn, // a Date object that reflects the time when the operation state was last modified
     * } = await client.getOperation(findOperationId);
     * ```
     */
    getOperation(operationId, options = {}) {
        return this._tracing.withSpan("DocumentModelAdministrationClient.getOperation", options, (finalOptions) => this._restClient.miscellaneous.getOperation(operationId, finalOptions));
    }
    /**
     * List model creation operations in the resource. This will produce all operations, including operations that failed
     * to create models successfully. This operation supports paging.
     *
     * ### Examples
     *
     * #### Async Iteration
     *
     * ```ts snippet:ReadmeSampleListOperations
     * import { DefaultAzureCredential } from "@azure/identity";
     * import { DocumentModelAdministrationClient } from "@azure/ai-form-recognizer";
     *
     * const credential = new DefaultAzureCredential();
     * const client = new DocumentModelAdministrationClient(
     *   "https://<resource name>.cognitiveservices.azure.com",
     *   credential,
     * );
     *
     * for await (const operation of client.listOperations()) {
     *   const {
     *     operationId, // the operation's GUID
     *     status, // the operation status, one of "notStarted", "running", "succeeded", "failed", or "canceled"
     *     percentCompleted, // the progress of the operation, from 0 to 100
     *   } = operation;
     * }
     *
     * // The listOperations method is paged, and you can iterate by page using the `byPage` method.
     * const pages = client.listOperations().byPage();
     *
     * for await (const page of pages) {
     *   // Each page is an array of operation info objects and can be iterated synchronously
     *   for (const operation of page) {
     *     const {
     *       operationId, // the operation's GUID
     *       status, // the operation status, one of "notStarted", "running", "succeeded", "failed", or "canceled"
     *       percentCompleted, // the progress of the operation, from 0 to 100
     *     } = operation;
     *   }
     * }
     * ```
     *
     * @param options - optional settings for the operation requests
     * @returns an async iterable of operation information objects that supports paging
     */
    listOperations(options = {}) {
        return this._restClient.miscellaneous.listOperations(options);
    }
}
//# sourceMappingURL=documentModelAdministrationClient.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/options/AnalyzeDocumentOptions.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Known feature flags supported by the Form Recognizer clients.
 */
// eslint-disable-next-line @typescript-eslint/no-redeclare
const FormRecognizerFeature = {
    /**
     * Enables extracting extra font information.
     */
    Fonts: "styleFont",
    /**
     * Enables high-resolution processing for documents with small text.
     */
    OcrHighResolution: "ocrHighResolution",
    /**
     * Enables the detection of mathematical expressions in the document..
     */
    Formulas: "formulas",
    /**
     * Enables the detection of the text content language.
     */
    Languages: "languages",
    /**
     *  Enables the detection of barcodes in the document.
     */
    Barcodes: "barcodes",
    /**
     *  Enables the detection of general key value pairs (form fields) in the document.
     */
    KeyValuePairs: "keyValuePairs",
};
//# sourceMappingURL=AnalyzeDocumentOptions.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/options/BuildModelOptions.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Supported values of `DocumentModelBuildMode`.
 */
// eslint-disable-next-line @typescript-eslint/no-redeclare
const DocumentModelBuildMode = {
    /**
     * A mode that builds a model assuming that documents all follow the same, fixed template layout (the same relative
     * positioning of fields between documents).
     */
    Template: "template",
    /**
     * A mode that uses a neural engine to extract fields, allowing for documents that have different visual appearances,
     * but that contain the same information.
     */
    Neural: "neural",
};
//# sourceMappingURL=BuildModelOptions.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/options/index.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.




//# sourceMappingURL=index.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/documentModel.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

/**
 * Checks a field value against a schema and converts it into a strong idiomatic DocumentField,
 * @internal
 * @param fieldName - the name of the field (used in diagnostics)
 * @param schema - the field's schema
 * @param field - the raw DocumentField value
 * @returns
 */
function extractField(fieldName, schema, field) {
    if (schema.type !== field.kind) {
        throw new Error(`Schema violation: ${fieldName} had type "${field.kind}", but expected "${schema.type}"`);
    }
    // Objects need to be handled specially, so that we can camelCase the field names.
    if (field.kind === "object") {
        const result = {};
        for (const [subFieldName, subFieldSchema] of Object.entries(schema.properties)) {
            if (field.properties[subFieldName] !== undefined && field.properties[subFieldName] !== null) {
                const trueFieldName = (isAcronymic(subFieldName) ? subFieldName : uncapitalize(subFieldName)).replace(/\s/g, "");
                result[trueFieldName] = extractField(fieldName + "." + subFieldName, subFieldSchema, field.properties[subFieldName]);
            }
        }
        return Object.assign(Object.assign({}, field), { properties: result });
    }
    else if (field.kind === "array") {
        return Object.assign(Object.assign({}, field), { values: field.values.map((val, idx) => extractField(fieldName + "[" + idx + "]", schema.items, val)) });
    }
    else
        return field;
}
/**
 * Create a DocumentModel that performs analysis using the given schema.
 *
 * The types of `documents` are created from the schema, so they are `unknown` unless they are asserted to be a
 * different type.
 *
 * @hidden
 * @param schema - model schema contents
 * @returns - a DocumentModel that encodes the schema
 */
function createModelFromSchema(schema) {
    return {
        modelId: schema.modelId,
        apiVersion: schema.apiVersion,
        transformResult(baseResult) {
            var _a, _b, _c;
            const hasDocuments = Object.entries((_a = schema.docTypes) !== null && _a !== void 0 ? _a : {}).length > 0;
            return Object.assign(Object.assign({}, baseResult), { documents: hasDocuments
                    ? (_b = baseResult.documents) === null || _b === void 0 ? void 0 : _b.map(toDocument)
                    : ((_c = baseResult.documents) !== null && _c !== void 0 ? _c : []) });
            function toDocument(document) {
                var _a;
                const result = {};
                const model = (_a = schema.docTypes) === null || _a === void 0 ? void 0 : _a[document.docType];
                if (model === undefined) {
                    throw new Error(`Unexpected document type "${document.docType}" in result using model "${schema.modelId}"`);
                }
                for (const [fieldName, fieldSchema] of Object.entries(model.fieldSchema)) {
                    if (document.fields &&
                        document.fields[fieldName] !== undefined &&
                        document.fields[fieldName] !== null) {
                        const trueFieldName = (isAcronymic(fieldName) ? fieldName : uncapitalize(fieldName)).replace(/\s/g, "");
                        result[trueFieldName] = extractField(fieldName, fieldSchema, document.fields[fieldName]);
                    }
                }
                return Object.assign(Object.assign({}, document), { fields: result });
            }
        },
    };
}
//# sourceMappingURL=documentModel.js.map
;// ./node_modules/@azure/ai-form-recognizer/dist/esm/index.js
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Azure Cognitive Services [Form Recognizer](https://azure.microsoft.com/services/cognitive-services/form-recognizer/)
 * uses cloud-based machine learning to extract structured data from form documents.
 *
 * @packageDocumentation
 */








//# sourceMappingURL=index.js.map

/***/ })

};
;