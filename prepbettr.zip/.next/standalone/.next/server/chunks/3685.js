"use strict";
exports.id = 3685;
exports.ids = [3685];
exports.modules = {

/***/ 3548:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   x: () => (/* binding */ AzureOpenAIAdapter)
/* harmony export */ });
/* harmony import */ var _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95965);
/* harmony import */ var _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34674);
/* harmony import */ var _lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__]);
([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure OpenAI Provider Adapter
 * 
 * This adapter wraps Azure OpenAI API to provide a consistent interface
 * for the AI service layer. Reuses the existing AzureOpenAIService for
 * consistent configuration and error handling.
 */ 


class AzureOpenAIAdapter {
    /**
   * Initialize the Azure OpenAI service
   */ async initialize() {
        try {
            // Try enhanced service first, fallback to standard service
            if (this.useEnhancedService) {
                this.isInitialized = await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.initialize();
                if (this.isInitialized) {
                    console.log('✅ Azure OpenAI adapter initialized with enhanced service');
                    return true;
                }
                console.warn('⚠️ Enhanced service failed, falling back to standard service');
                this.useEnhancedService = false;
            }
            // Fallback to standard service
            this.isInitialized = await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.initialize();
            if (this.isInitialized) {
                console.log('✅ Azure OpenAI adapter initialized with standard service');
            } else {
                console.warn('⚠️ Azure OpenAI adapter failed to initialize');
            }
            return this.isInitialized;
        } catch (error) {
            console.error('❌ Failed to initialize Azure OpenAI adapter:', error);
            return false;
        }
    }
    /**
   * Check if the adapter is ready
   */ isReady() {
        if (this.useEnhancedService) {
            return this.isInitialized && _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.isReady();
        }
        return this.isInitialized && _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.isReady();
    }
    /**
   * Generate a cover letter using Azure OpenAI with retry logic
   */ async generateCoverLetter(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service if available for optimal model selection
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateCoverLetter(resumeText, jobDescription);
            }
            // Fallback to custom implementation
            return await this.generateWithAzureOpenAI(this.getCoverLetterPrompt(resumeText, jobDescription));
        }, 'generate_cover_letter', userId, {
            maxRetries: 3,
            baseDelay: 2000,
            maxDelay: 60000 // 1 minute max delay
        });
    }
    /**
   * Calculate relevancy score between resume and job description with retry logic
   */ async calculateRelevancy(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service for efficient gpt-35-turbo scoring
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.calculateRelevancy(resumeText, jobDescription);
            }
            // Fallback implementation
            const prompt = this.getRelevancyPrompt(resumeText, jobDescription);
            const response = await this.generateWithAzureOpenAI(prompt, this.RELEVANCY_TEMPERATURE, this.RELEVANCY_MAX_TOKENS);
            // Extract number from response
            const scoreMatch = response.trim().match(/\d+/);
            if (!scoreMatch) {
                throw new Error('Could not extract relevancy score from response');
            }
            const score = parseInt(scoreMatch[0], 10);
            return Math.max(0, Math.min(100, score)); // Ensure score is between 0-100
        }, 'calculate_relevancy', userId, {
            maxRetries: 2,
            baseDelay: 1000,
            maxDelay: 30000
        });
    }
    /**
   * Tailor resume to match job description with retry logic
   */ async tailorResume(resumeText, jobDescription, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service for optimal gpt-4o quality
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.tailorResume(resumeText, jobDescription);
            }
            // Fallback to standard service
            return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.tailorResume(resumeText, jobDescription);
        }, 'tailor_resume', userId, {
            maxRetries: 3,
            baseDelay: 3000,
            maxDelay: 90000 // 1.5 minutes max delay
        });
    }
    /**
   * Generate interview questions based on resume information with retry logic
   */ async generateQuestions(resumeInfo, userId) {
        if (!this.isReady()) {
            throw new Error('Azure OpenAI adapter not initialized');
        }
        return await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_2__/* .retryWithExponentialBackoff */ .y)(async ()=>{
            // Use enhanced service for efficient gpt-35-turbo question generation
            if (this.useEnhancedService) {
                return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateQuestions(resumeInfo);
            }
            // Fallback to standard service
            return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.generateQuestions(resumeInfo);
        }, 'generate_questions', userId, {
            maxRetries: 2,
            baseDelay: 1500,
            maxDelay: 45000
        });
    }
    /**
   * Generate content using Azure OpenAI with retry logic
   * Uses optimized parameters for consistent high-quality responses
   */ async generateWithAzureOpenAI(prompt, temperature = this.DEFAULT_TEMPERATURE, maxTokens = this.DEFAULT_MAX_TOKENS) {
        const messages = [
            {
                role: 'user',
                content: prompt
            }
        ];
        try {
            const completion = await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.createCompletion(messages, {
                temperature,
                maxTokens,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1 // Encourage diverse content
            });
            const content = completion.choices[0]?.message?.content;
            if (!content) {
                throw new Error('Empty response from Azure OpenAI');
            }
            return content;
        } catch (error) {
            console.error('❌ Error generating content with Azure OpenAI:', error);
            throw error;
        }
    }
    /**
   * Get cover letter generation prompt with optimized structure
   */ getCoverLetterPrompt(resumeText, jobDescription) {
        return `You are an expert career coach and professional writer. Please generate a compelling cover letter based on the provided resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Please generate a cover letter that:
1. Is tailored to the specific job description
2. Highlights the most relevant skills and experiences from the resume
3. Has a professional and engaging tone
4. Is well-structured and easy to read
5. Is approximately 3-4 paragraphs long

Return ONLY the cover letter content with no additional commentary or explanations.`;
    }
    /**
   * Get relevancy analysis prompt with structured requirements
   */ getRelevancyPrompt(resumeText, jobDescription) {
        return `You are an expert ATS (Applicant Tracking System) analyzer. Please analyze the relevancy between this resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Analyze the match between the resume and job description considering:
1. Skills alignment (technical and soft skills)
2. Experience relevance (years and type of experience)
3. Education and certifications match
4. Industry experience
5. Role responsibilities alignment
6. Keywords and terminology match

Return ONLY a single number between 0 and 100 representing the percentage match/relevancy score. No explanations or additional text.`;
    }
    /**
   * Dispose of resources
   */ dispose() {
        // The underlying service manages its own resources
        this.isInitialized = false;
        this.useEnhancedService = true; // Reset for next initialization
        console.log('🧹 Azure OpenAI adapter disposed');
    }
    constructor(){
        this.name = 'Azure OpenAI (Enhanced)';
        this.isInitialized = false;
        this.useEnhancedService = true // Feature flag for enhanced multi-deployment service
        ;
        // Default parameters for optimal Azure OpenAI performance
        this.DEFAULT_TEMPERATURE = 0.7 // Balanced creativity
        ;
        this.DEFAULT_MAX_TOKENS = 1500 // Comprehensive responses
        ;
        this.RELEVANCY_TEMPERATURE = 0.1 // For precise scoring
        ;
        this.RELEVANCY_MAX_TOKENS = 50 // Short numeric response
        ;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 34593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   lL: () => (/* binding */ fetchAzureSecrets)
/* harmony export */ });
/* unused harmony exports getAzureConfig, isBrowser, clearCache */
// Browser-compatible Azure configuration
// This file only uses environment variables and doesn't import server-only Azure Identity libraries
let cachedSecrets = null;
/**
 * Fetch Azure secrets from environment variables (browser-safe version)
 * This function only uses NEXT_PUBLIC_ environment variables available in the browser
 */ async function fetchAzureSecrets() {
    // Return cached secrets if available
    if (cachedSecrets) {
        return cachedSecrets;
    }
    try {
        console.log('🔑 Loading Azure configuration from environment variables...');
        const secrets = {
            speechKey: process.env.NEXT_PUBLIC_SPEECH_KEY || '',
            speechEndpoint: process.env.NEXT_PUBLIC_SPEECH_ENDPOINT || '',
            azureOpenAIKey: process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY || '',
            azureOpenAIEndpoint: process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT || '',
            azureOpenAIDeployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT || 'gpt-4o',
            azureOpenAIGpt35Deployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            azureOpenAIGpt4oDeployment: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o',
            azureAppConfigConnectionString: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            azureAppConfigEndpoint: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        };
        // Validate that required secrets are available
        if (!secrets.speechKey || !secrets.speechEndpoint) {
            console.warn('⚠️ Azure Speech credentials not available in browser environment');
        }
        if (!secrets.azureOpenAIKey || !secrets.azureOpenAIEndpoint) {
            console.warn('⚠️ Azure OpenAI credentials not available in browser environment');
        }
        if (!secrets.azureAppConfigConnectionString && !secrets.azureAppConfigEndpoint) {
            console.warn('⚠️ Azure App Configuration credentials not available in browser environment');
        }
        cachedSecrets = secrets;
        console.log('✅ Azure configuration loaded from environment variables');
        return cachedSecrets;
    } catch (error) {
        console.error('❌ Failed to load Azure configuration:', error);
        // Return empty secrets as fallback
        const fallbackSecrets = {
            speechKey: '',
            speechEndpoint: '',
            azureOpenAIKey: '',
            azureOpenAIEndpoint: '',
            azureOpenAIDeployment: 'gpt-4o',
            azureOpenAIGpt35Deployment: 'gpt-4o',
            azureOpenAIGpt4oDeployment: 'gpt-4o',
            azureAppConfigConnectionString: undefined,
            azureAppConfigEndpoint: undefined
        };
        cachedSecrets = fallbackSecrets;
        return cachedSecrets;
    }
}
/**
 * Get current Azure configuration (for debugging)
 */ function getAzureConfig() {
    return {
        environment: 'browser',
        hasSecretsCache: !!cachedSecrets,
        configuration: {
            speechKey: !!process.env.NEXT_PUBLIC_SPEECH_KEY,
            speechEndpoint: !!process.env.NEXT_PUBLIC_SPEECH_ENDPOINT,
            azureOpenAIKey: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_API_KEY,
            azureOpenAIEndpoint: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT,
            azureOpenAIDeployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT,
            azureOpenAIGpt35Deployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT,
            azureOpenAIGpt4oDeployment: !!process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT,
            azureAppConfigConnectionString: !!process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            azureAppConfigEndpoint: !!process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        },
        deployments: {
            default: process.env.NEXT_PUBLIC_AZURE_OPENAI_DEPLOYMENT,
            gpt35Turbo: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT35_DEPLOYMENT || 'gpt-4o',
            gpt4o: process.env.NEXT_PUBLIC_AZURE_OPENAI_GPT4O_DEPLOYMENT || 'gpt-4o'
        },
        appConfiguration: {
            connectionString: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_CONNECTION_STRING,
            endpoint: process.env.NEXT_PUBLIC_AZURE_APP_CONFIG_ENDPOINT
        }
    };
}
/**
 * Check if we're running in a browser environment
 */ function isBrowser() {
    return "undefined" !== 'undefined';
}
/**
 * Clear cached secrets (useful for testing or re-initialization)
 */ function clearCache() {
    cachedSecrets = null;
    console.log('🧹 Azure configuration cache cleared');
}


/***/ }),

/***/ 34674:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   h: () => (/* binding */ enhancedAzureOpenAIService)
/* harmony export */ });
/* unused harmony export EnhancedAzureOpenAIService */
/* harmony import */ var _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(55506);
/* harmony import */ var _lib_azure_config_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34593);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__]);
_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Enhanced Azure OpenAI Service with Multi-Deployment Support
 * 
 * This service provides intelligent model selection based on task type:
 * - gpt-35-turbo: Fast, cost-effective for simple tasks (relevancy scoring, basic Q&A)
 * - gpt-4o: Advanced reasoning for complex tasks (cover letters, resume tailoring)
 */ 

class EnhancedAzureOpenAIService {
    /**
   * Initialize the service with multiple deployment clients
   */ async initialize() {
        try {
            this.secrets = await (0,_lib_azure_config_browser__WEBPACK_IMPORTED_MODULE_1__/* .fetchAzureSecrets */ .lL)();
            if (!this.secrets.azureOpenAIKey || !this.secrets.azureOpenAIEndpoint) {
                console.warn('⚠️ Azure OpenAI credentials not available');
                return false;
            }
            // Initialize clients for different deployments
            const deployments = [
                {
                    name: 'gpt-4o',
                    deployment: this.secrets.azureOpenAIGpt35Deployment || 'gpt-4o'
                },
                {
                    name: 'gpt-4o',
                    deployment: this.secrets.azureOpenAIGpt4oDeployment || 'gpt-4o'
                },
                {
                    name: 'default',
                    deployment: this.secrets.azureOpenAIDeployment
                }
            ];
            for (const { name, deployment } of deployments){
                if (deployment) {
                    const client = new _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__/* .MigrationOpenAIClient */ .Ag();
                    await client.init(); // Initialize the migration client
                    this.clients.set(name, client);
                    console.log(`✅ Azure OpenAI client initialized for ${name} (${deployment})`);
                }
            }
            this.isInitialized = this.clients.size > 0;
            if (this.isInitialized) {
                console.log(`✅ Enhanced Azure OpenAI Service initialized with ${this.clients.size} clients`);
            }
            return this.isInitialized;
        } catch (error) {
            console.error('❌ Failed to initialize Enhanced Azure OpenAI Service:', error);
            return false;
        }
    }
    /**
   * Generate content using the optimal model for the task
   */ async generateContent(prompt, taskType, customOptions) {
        if (!this.isInitialized) {
            throw new Error('Enhanced Azure OpenAI Service not initialized');
        }
        const config = {
            ...this.taskConfigurations[taskType],
            ...customOptions
        };
        const client = this.clients.get(config.deployment) || this.clients.get('default');
        if (!client) {
            throw new Error(`No client available for deployment: ${config.deployment}`);
        }
        console.log(`🎯 Using ${config.deployment} for ${taskType} task`);
        const messages = [
            {
                role: 'user',
                content: prompt
            }
        ];
        try {
            const completion = await this.retryWithBackoff(async ()=>{
                return await client.chat.completions.create({
                    model: config.deployment,
                    messages,
                    temperature: config.temperature,
                    max_tokens: config.maxTokens,
                    top_p: config.topP || 0.9,
                    frequency_penalty: config.frequencyPenalty || 0.1,
                    presence_penalty: config.presencePenalty || 0.1
                });
            });
            const content = completion.choices[0]?.message?.content;
            if (!content) {
                throw new Error(`Empty response from Azure OpenAI (${config.deployment})`);
            }
            return content;
        } catch (error) {
            console.error(`❌ Error generating content with ${config.deployment}:`, error);
            throw error;
        }
    }
    /**
   * Generate cover letter using gpt-4o for high quality
   */ async generateCoverLetter(resumeText, jobDescription) {
        const prompt = `You are an expert career coach and professional writer. Please generate a compelling cover letter based on the provided resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Please generate a cover letter that:
1. Is tailored to the specific job description
2. Highlights the most relevant skills and experiences from the resume
3. Has a professional and engaging tone
4. Is well-structured and easy to read
5. Is approximately 3-4 paragraphs long

Return ONLY the cover letter content with no additional commentary or explanations.`;
        return await this.generateContent(prompt, 'cover-letter');
    }
    /**
   * Calculate relevancy score using gpt-35-turbo for efficiency
   */ async calculateRelevancy(resumeText, jobDescription) {
        const prompt = `You are an expert ATS (Applicant Tracking System) analyzer. Please analyze the relevancy between this resume and job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Analyze the match between the resume and job description considering:
1. Skills alignment (technical and soft skills)
2. Experience relevance (years and type of experience)
3. Education and certifications match
4. Industry experience
5. Role responsibilities alignment
6. Keywords and terminology match

Return ONLY a single number between 0 and 100 representing the percentage match/relevancy score. No explanations or additional text.`;
        const response = await this.generateContent(prompt, 'relevancy');
        // Extract number from response
        const scoreMatch = response.trim().match(/\d+/);
        if (!scoreMatch) {
            throw new Error('Could not extract relevancy score from response');
        }
        const score = parseInt(scoreMatch[0], 10);
        return Math.max(0, Math.min(100, score)); // Ensure score is between 0-100
    }
    /**
   * Tailor resume using gpt-4o for quality
   */ async tailorResume(resumeText, jobDescription) {
        const prompt = `You are an expert resume writer and ATS optimization specialist. Please tailor this resume to better match the following job description for maximum ATS compatibility and relevance.

JOB DESCRIPTION:
${jobDescription}

CURRENT RESUME:
${resumeText}

Please provide a tailored version of the resume that:
1. Uses keywords and phrases directly from the job description
2. Highlights relevant skills and experiences that match the job requirements
3. Maintains professional formatting and ATS-friendly structure
4. Uses strong action verbs and quantifiable achievements
5. Keeps the same overall length and format structure
6. Optimizes for Applicant Tracking Systems (ATS)
7. Ensures keyword density without keyword stuffing

Return ONLY the tailored resume content with no additional commentary or explanations.`;
        return await this.generateContent(prompt, 'resume-tailor');
    }
    /**
   * Generate interview questions using gpt-35-turbo for efficiency
   */ async generateQuestions(resumeInfo) {
        const prompt = `You are an experienced interviewer. Based on the following resume information, generate 5 relevant interview questions that would help assess this candidate's qualifications and fit for their field.

RESUME INFORMATION:
Name: ${resumeInfo.name}
Experience: ${resumeInfo.experience}
Education: ${resumeInfo.education}
Skills: ${resumeInfo.skills}

Generate questions that:
1. Are specific to their experience level and field
2. Assess both technical and behavioral competencies
3. Are professional and engaging
4. Would help determine cultural fit
5. Allow the candidate to showcase their strengths

Format: Return exactly 5 questions, each on a new line, numbered 1-5. No additional text or explanations.`;
        const response = await this.generateContent(prompt, 'questions');
        // Parse questions from response
        const questions = response.split('\n').map((line)=>line.trim()).filter((line)=>line.length > 0).map((line)=>line.replace(/^\d+\.\s*/, '')) // Remove numbering
        .filter((line)=>line.length > 0).slice(0, 5); // Ensure max 5 questions
        if (questions.length === 0) {
            throw new Error('No questions could be parsed from response');
        }
        return questions;
    }
    /**
   * Retry mechanism with exponential backoff for rate limiting
   */ async retryWithBackoff(operation, maxRetries = 3, baseDelay = 1000) {
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                return await operation();
            } catch (error) {
                lastError = error;
                // Don't retry on non-retryable errors
                if (error.status && ![
                    429,
                    500,
                    502,
                    503,
                    504
                ].includes(error.status)) {
                    throw error;
                }
                if (attempt === maxRetries) {
                    throw error;
                }
                // Calculate delay with exponential backoff
                const delay = error.status === 429 ? parseInt(error.headers?.['retry-after'] || '10') * 1000 : baseDelay * Math.pow(2, attempt);
                console.log(`⏳ Retrying in ${delay}ms (attempt ${attempt + 1}/${maxRetries + 1})`);
                await new Promise((resolve)=>setTimeout(resolve, delay));
            }
        }
        throw lastError;
    }
    /**
   * Check if service is ready
   */ isReady() {
        return this.isInitialized && this.clients.size > 0;
    }
    /**
   * Get available deployments
   */ getAvailableDeployments() {
        return Array.from(this.clients.keys());
    }
    /**
   * Dispose of resources
   */ dispose() {
        this.clients.clear();
        this.isInitialized = false;
        console.log('🧹 Enhanced Azure OpenAI Service disposed');
    }
    constructor(){
        this.clients = new Map();
        this.isInitialized = false;
        this.secrets = null;
        // Task-specific configurations optimized for different models
        this.taskConfigurations = {
            // Fast tasks - use gpt-35-turbo for efficiency
            'relevancy': {
                deployment: 'gpt-4o',
                temperature: 0.1,
                maxTokens: 50,
                topP: 0.9,
                frequencyPenalty: 0.0,
                presencePenalty: 0.0
            },
            'questions': {
                deployment: 'gpt-4o',
                temperature: 0.5,
                maxTokens: 300,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            // Complex tasks - use gpt-4o for quality
            'cover-letter': {
                deployment: 'gpt-4o',
                temperature: 0.7,
                maxTokens: 1500,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            'resume-tailor': {
                deployment: 'gpt-4o',
                temperature: 0.3,
                maxTokens: 2000,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            },
            // Interview tasks - use gpt-4o for nuanced conversation
            'interview': {
                deployment: 'gpt-4o',
                temperature: 0.7,
                maxTokens: 200,
                topP: 0.9,
                frequencyPenalty: 0.1,
                presencePenalty: 0.1
            }
        };
    }
}
// Export singleton instance
const enhancedAzureOpenAIService = new EnhancedAzureOpenAIService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 42709:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OB: () => (/* binding */ azureAI)
/* harmony export */ });
/* harmony import */ var _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95965);
/* harmony import */ var _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34674);
/* harmony import */ var _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74798);
/* harmony import */ var _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(26765);
/* harmony import */ var _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82802);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75931);
/* harmony import */ var _lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(46502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__, _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__, _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__]);
([_lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__, _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__, _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__, _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Unified Azure AI Facade
 * 
 * Central entry point for all Azure AI services including OpenAI, Cognitive Services,
 * and Azure AI Foundry. Provides simplified access to Azure's AI capabilities
 * with intelligent routing and fallback mechanisms.
 */ 






/**
 * Azure AI Unified Service
 * Provides centralized access to all Azure AI capabilities
 */ class AzureAIService {
    /**
   * Initialize all Azure AI services
   */ async initialize() {
        if (this.initialized) {
            return;
        }
        console.log('🚀 Initializing Azure AI unified service...');
        const startTime = Date.now();
        try {
            // Initialize Azure OpenAI services
            const [openaiReady, enhancedReady, formRecognizerReady] = await Promise.allSettled([
                _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.initialize(),
                _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.initialize(),
                _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_2__/* .azureFormRecognizer */ .m.initialize()
            ]);
            this.availableServices.openai = openaiReady.status === 'fulfilled' && openaiReady.value;
            this.availableServices.enhanced = enhancedReady.status === 'fulfilled' && enhancedReady.value;
            this.availableServices.formRecognizer = formRecognizerReady.status === 'fulfilled' && formRecognizerReady.value;
            // Initialize Azure AI Foundry if feature flag is enabled
            try {
                const foundryEnabled = await _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__/* .unifiedConfigService */ .Um.get('features.foundryResumeProcessing', false);
                if (foundryEnabled) {
                    this.availableServices.foundry = await _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__/* .foundryDocumentIntelligenceService */ .P.initialize();
                }
            } catch (error) {
                console.warn('⚠️ Foundry initialization skipped:', error);
            }
            this.initialized = true;
            const initTime = Date.now() - startTime;
            console.log('✅ Azure AI unified service initialized', {
                duration: `${initTime}ms`,
                services: this.availableServices
            });
        } catch (error) {
            console.error('❌ Azure AI service initialization failed:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(error, {
                service: 'azure-ai-unified',
                action: 'initialize'
            });
            throw error;
        }
    }
    /**
   * Get service status information
   */ getStatus() {
        return {
            initialized: this.initialized,
            services: this.availableServices
        };
    }
    /**
   * Generate text completions using Azure OpenAI
   */ async generateCompletion(prompt, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            // Use enhanced service if available, fallback to standard
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const result = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateContent(prompt, 'general');
                } else {
                    // Fall back to basic service, but it doesn't have generateCompletion
                    throw new Error('Basic Azure OpenAI service does not support completion generation');
                }
            }, 'azure_ai_completion', options.userId, {
                maxRetries: 3,
                baseDelay: 1000
            });
            return {
                success: true,
                data: result,
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        } catch (error) {
            console.error('❌ Azure AI completion failed:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Completion failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Generate interview questions from resume data
   */ async generateQuestions(resumeData, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            // Use enhanced service if available
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const questions = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateQuestions(resumeData);
                } else {
                    return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.generateQuestions(resumeData);
                }
            }, 'azure_ai_questions', undefined, {
                maxRetries: 2,
                baseDelay: 1000
            });
            // Filter to max questions if specified
            const filteredQuestions = options.maxQuestions ? questions.slice(0, options.maxQuestions) : questions;
            return {
                success: true,
                data: filteredQuestions,
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        } catch (error) {
            console.error('❌ Azure AI question generation failed:', error);
            // Return default questions as fallback
            const defaultQuestions = [
                "Tell me about yourself and your professional background.",
                "What interests you most about this position?",
                "Describe a challenging project you've worked on.",
                "How do you stay updated with industry trends?",
                "Where do you see yourself in 5 years?",
                "What are your greatest strengths?",
                "Describe a time when you had to work under pressure.",
                "How do you handle feedback and criticism?"
            ];
            return {
                success: false,
                data: defaultQuestions.slice(0, options.maxQuestions || 8),
                error: error instanceof Error ? error.message : 'Question generation failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Extract data from resume documents
   */ async extractResumeData(fileBuffer, mimeType, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            // Use Azure AI Foundry if available and enabled
            if (this.availableServices.foundry && (options.forceFoundryProcessing || await _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_4__/* .unifiedConfigService */ .Um.get('features.foundryResumeProcessing', false))) {
                const extraction = await _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__/* .foundryDocumentIntelligenceService */ .P.analyzeResume(fileBuffer, mimeType, {
                    includeAtsAnalysis: options.includeAtsAnalysis,
                    modelType: 'resume-analysis'
                });
                return {
                    success: true,
                    data: extraction,
                    provider: 'azure-foundry',
                    processingTime: Date.now() - startTime,
                    confidence: extraction.metadata?.overallConfidence
                };
            }
            // Fallback to Azure Form Recognizer
            if (this.availableServices.formRecognizer) {
                const extraction = await _lib_services_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_2__/* .azureFormRecognizer */ .m.extractResumeData(fileBuffer, mimeType);
                return {
                    success: true,
                    data: extraction,
                    provider: 'azure-form-recognizer',
                    processingTime: Date.now() - startTime,
                    confidence: 0.85 // Default confidence for Form Recognizer
                };
            }
            throw new Error('No Azure document extraction services available');
        } catch (error) {
            console.error('❌ Azure resume extraction failed:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Extraction failed',
                provider: this.availableServices.foundry ? 'azure-foundry' : 'azure-form-recognizer',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Generate tailored resume content
   */ async tailorResume(resumeText, jobDescription, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const tailoredContent = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.tailorResume(resumeText, jobDescription);
                } else {
                    return await _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F.tailorResume(resumeText, jobDescription);
                }
            }, 'azure_ai_tailor', options.userId, {
                maxRetries: 3,
                baseDelay: 2000
            });
            return {
                success: true,
                data: tailoredContent,
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        } catch (error) {
            console.error('❌ Azure AI resume tailoring failed:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Resume tailoring failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Generate cover letters
   */ async generateCoverLetter(resumeText, jobDescription, options = {}) {
        await this.initialize();
        const startTime = Date.now();
        try {
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const coverLetter = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.generateCoverLetter(resumeText, jobDescription);
                } else {
                    throw new Error('Cover letter generation requires enhanced Azure OpenAI service');
                }
            }, 'azure_ai_cover_letter', options.userId, {
                maxRetries: 3,
                baseDelay: 2000
            });
            return {
                success: true,
                data: coverLetter,
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        } catch (error) {
            console.error('❌ Azure AI cover letter generation failed:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Cover letter generation failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    /**
   * Calculate relevancy score between resume and job description
   */ async calculateRelevancy(resumeText, jobDescription) {
        await this.initialize();
        const startTime = Date.now();
        try {
            const service = this.availableServices.enhanced ? _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h : _lib_services_azure_openai_service__WEBPACK_IMPORTED_MODULE_0__/* .azureOpenAIService */ .F;
            const score = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_6__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                if (this.availableServices.enhanced) {
                    return await _lib_services_azure_openai_enhanced__WEBPACK_IMPORTED_MODULE_1__/* .enhancedAzureOpenAIService */ .h.calculateRelevancy(resumeText, jobDescription);
                } else {
                    throw new Error('Relevancy calculation requires enhanced Azure OpenAI service');
                }
            }, 'azure_ai_relevancy', undefined, {
                maxRetries: 2,
                baseDelay: 1000
            });
            return {
                success: true,
                data: Math.max(0, Math.min(100, score)),
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime,
                confidence: 0.9
            };
        } catch (error) {
            console.error('❌ Azure AI relevancy calculation failed:', error);
            return {
                success: false,
                data: 50,
                error: error instanceof Error ? error.message : 'Relevancy calculation failed',
                provider: this.availableServices.enhanced ? 'azure-foundry' : 'azure-openai',
                processingTime: Date.now() - startTime
            };
        }
    }
    constructor(){
        this.initialized = false;
        this.availableServices = {
            openai: false,
            enhanced: false,
            formRecognizer: false,
            foundry: false
        };
    }
}
// Export singleton instance
const azureAI = new AzureAIService();
// For backward compatibility, export individual service references


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 53685:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   azureAI: () => (/* reexport safe */ _azure_ai__WEBPACK_IMPORTED_MODULE_1__.OB),
/* harmony export */   tailorResume: () => (/* binding */ tailorResume)
/* harmony export */ });
/* unused harmony exports generateCoverLetter, calculateRelevancy, generateQuestions, getProviderInfo, switchProvider, dispose */
/* harmony import */ var _azureOpenAI__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3548);
/* harmony import */ var _azure_ai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(42709);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azureOpenAI__WEBPACK_IMPORTED_MODULE_0__, _azure_ai__WEBPACK_IMPORTED_MODULE_1__]);
([_azureOpenAI__WEBPACK_IMPORTED_MODULE_0__, _azure_ai__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure-Centric AI Service Layer
 * 
 * This module provides a unified interface for AI operations backed
 * by Azure OpenAI services. Optimized for enterprise-grade AI functionality.
 * 
 * Updated to use the new unified Azure AI facade for improved service
 * management and intelligent routing between Azure services.
 */ 

/**
 * AI Service Manager - Azure OpenAI focused service manager
 */ class AIServiceManager {
    constructor(){
        this.currentProvider = null;
        this.providers = new Map();
        this.initialized = false;
        // Register Azure OpenAI as the primary provider
        this.providers.set('azure-openai', new _azureOpenAI__WEBPACK_IMPORTED_MODULE_0__/* .AzureOpenAIAdapter */ .x());
    }
    /**
   * Initialize the AI service with Azure OpenAI
   */ async initialize() {
        const providerName = 'azure-openai';
        console.log(`🚀 Initializing AI Service with provider: ${providerName}`);
        const provider = this.providers.get(providerName);
        if (!provider) {
            console.error(`❌ Azure OpenAI provider not found`);
            return false;
        }
        try {
            const success = await provider.initialize();
            if (success) {
                this.currentProvider = provider;
                this.initialized = true;
                console.log(`✅ AI Service initialized successfully with ${provider.name}`);
                return true;
            }
        } catch (error) {
            console.error(`❌ Failed to initialize Azure OpenAI provider:`, error);
        }
        console.error('❌ Azure OpenAI provider failed to initialize');
        return false;
    }
    /**
   * Get the current provider
   */ getCurrentProvider() {
        return this.currentProvider;
    }
    /**
   * Check if the service is ready
   */ isReady() {
        return this.initialized && this.currentProvider?.isReady() === true;
    }
    /**
   * Get current provider name
   */ getProviderName() {
        return this.currentProvider?.name || 'none';
    }
    /**
   * Switch to a different provider at runtime
   */ async switchProvider(providerName) {
        console.log(`🔄 Switching to provider: ${providerName}`);
        const provider = this.providers.get(providerName);
        if (!provider) {
            console.error(`❌ Provider '${providerName}' not found`);
            return false;
        }
        // Clean up current provider
        if (this.currentProvider) {
            this.currentProvider.dispose();
        }
        try {
            const success = await provider.initialize();
            if (success) {
                this.currentProvider = provider;
                console.log(`✅ Successfully switched to ${provider.name}`);
                return true;
            }
        } catch (error) {
            console.error(`❌ Failed to switch to provider '${providerName}':`, error);
        }
        return false;
    }
    /**
   * Dispose of all resources
   */ dispose() {
        if (this.currentProvider) {
            this.currentProvider.dispose();
        }
        this.currentProvider = null;
        this.initialized = false;
        console.log('🧹 AI Service Manager disposed');
    }
}
// Singleton instance
const aiServiceManager = new AIServiceManager();
/**
 * Ensure the AI service is initialized
 */ async function ensureInitialized() {
    if (!aiServiceManager.isReady()) {
        const success = await aiServiceManager.initialize();
        if (!success) {
            throw new Error('Failed to initialize AI service - no providers available');
        }
    }
}
/**
 * Generate a cover letter based on resume and job description
 */ async function generateCoverLetter(resumeText, jobDescription) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const coverLetter = await provider.generateCoverLetter(resumeText, jobDescription);
        return {
            success: true,
            data: coverLetter,
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error generating cover letter:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Calculate relevancy score between resume and job description (0-100)
 */ async function calculateRelevancy(resumeText, jobDescription) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const score = await provider.calculateRelevancy(resumeText, jobDescription);
        return {
            success: true,
            data: Math.max(0, Math.min(100, score)),
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error calculating relevancy:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Tailor resume to match job description
 */ async function tailorResume(resumeText, jobDescription) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const tailoredResume = await provider.tailorResume(resumeText, jobDescription);
        return {
            success: true,
            data: tailoredResume,
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error tailoring resume:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Generate interview questions based on resume information
 */ async function generateQuestions(resumeInfo) {
    try {
        await ensureInitialized();
        const provider = aiServiceManager.getCurrentProvider();
        if (!provider) {
            throw new Error('No AI provider available');
        }
        const questions = await provider.generateQuestions(resumeInfo);
        return {
            success: true,
            data: questions,
            provider: provider.name
        };
    } catch (error) {
        console.error('❌ Error generating questions:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Get current AI provider information
 */ function getProviderInfo() {
    return {
        name: aiServiceManager.getProviderName(),
        isReady: aiServiceManager.isReady()
    };
}
/**
 * Switch AI provider at runtime (for testing or hot-swapping)
 */ async function switchProvider(providerName) {
    try {
        const success = await aiServiceManager.switchProvider(providerName);
        return {
            success,
            data: success,
            provider: aiServiceManager.getProviderName()
        };
    } catch (error) {
        console.error('❌ Error switching provider:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            provider: aiServiceManager.getProviderName()
        };
    }
}
/**
 * Dispose of AI service resources
 */ function dispose() {
    aiServiceManager.dispose();
}
// Export the unified Azure AI service for modern usage

 // Alias for clarity
// Re-export individual services for direct access if needed


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 95965:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F: () => (/* binding */ azureOpenAIService)
/* harmony export */ });
/* unused harmony export AzureOpenAIService */
/* harmony import */ var _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(55506);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__]);
_lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// Client-side safety check
const isClient = "undefined" !== 'undefined';
// Only import server-side dependencies when running on server
let fetchAzureSecrets = null;
if (!isClient) {
    const azureConfig = __webpack_require__(85500);
    fetchAzureSecrets = azureConfig.fetchAzureSecrets;
}
class AzureOpenAIService {
    /**
   * Initialize the Azure OpenAI service
   */ async initialize() {
        if (isClient) {
            console.warn('[Azure OpenAI Service] Running on client side - service disabled');
            return false;
        }
        try {
            const secrets = await fetchAzureSecrets();
            if (!secrets.azureOpenAIKey || !secrets.azureOpenAIEndpoint) {
                console.warn('⚠️ Azure OpenAI credentials not available');
                return false;
            }
            this.deployment = secrets.azureOpenAIDeployment;
            this.client = new _lib_azure_ai_foundry_clients_migration_wrapper__WEBPACK_IMPORTED_MODULE_0__/* .MigrationOpenAIClient */ .Ag();
            await this.client.init(); // Initialize the migration client
            // Test the connection with a simple request
            try {
                console.log(`🔄 Testing Azure OpenAI connection with deployment: ${this.deployment}`);
                await this.client.chat.completions.create({
                    model: this.deployment,
                    messages: [
                        {
                            role: 'user',
                            content: 'Test'
                        }
                    ],
                    max_tokens: 5
                });
                this.isInitialized = true;
                console.log('✅ Azure OpenAI Service initialized and tested successfully');
                return true;
            } catch (testError) {
                console.error('❌ Azure OpenAI connection test failed:', testError.message);
                console.error('📋 Configuration details:', {
                    endpoint: secrets.azureOpenAIEndpoint,
                    deployment: this.deployment,
                    hasApiKey: !!secrets.azureOpenAIKey
                });
                if (testError.status === 401) {
                    console.error('🔐 Authentication Error (401):');
                    console.error('   • Your API key might be invalid or expired');
                    console.error('   • Check your Azure OpenAI resource for the correct key');
                } else if (testError.status === 404) {
                    console.error('📍 Resource Not Found (404):');
                    console.error('   • The deployment "' + this.deployment + '" does not exist');
                    console.error('   • Your endpoint URL might be incorrect');
                    console.error('   • No deployments might exist in your Azure OpenAI resource');
                    console.error('💡 To fix this:');
                    console.error('   1. Log into portal.azure.com');
                    console.error('   2. Navigate to your Azure OpenAI resource');
                    console.error('   3. Check the "Model deployments" or "Deployments" section');
                    console.error('   4. Create a deployment (e.g., gpt-35-turbo, gpt-4)');
                    console.error('   5. Update AZURE_OPENAI_DEPLOYMENT in your .env.local file');
                } else if (testError.status === 403) {
                    console.error('🚫 Access Forbidden (403):');
                    console.error('   • Your API key might not have the right permissions');
                    console.error('   • Your Azure OpenAI resource might not be properly configured');
                } else {
                    console.error(`❓ Unexpected error (${testError.status || 'Unknown'}):`);
                    console.error('   • Check your Azure OpenAI resource configuration');
                    console.error('   • Verify your subscription and resource status');
                }
                return false;
            }
        } catch (error) {
            console.error('❌ Failed to initialize Azure OpenAI Service:', error);
            return false;
        }
    }
    /**
   * Set interview context for conversation management
   */ setInterviewContext(context) {
        const previousState = {
            ...this.interviewContext
        };
        // Merge context while preserving defaults
        this.interviewContext = {
            ...this.interviewContext,
            ...context,
            // Ensure defaults are set if not provided
            preliminaryCollected: context.preliminaryCollected ?? this.interviewContext.preliminaryCollected ?? false,
            currentQuestionCount: context.currentQuestionCount ?? this.interviewContext.currentQuestionCount ?? 0,
            maxQuestions: context.maxQuestions ?? this.interviewContext.maxQuestions ?? 10
        };
        // Log state transition
        console.log('📋 Interview context updated:', this.interviewContext);
        console.debug('🔄 [STATE_TRANSITION] Interview context changed', {
            from: previousState,
            to: this.interviewContext,
            changes: {
                preliminaryCollected: previousState.preliminaryCollected !== this.interviewContext.preliminaryCollected,
                currentQuestionCount: previousState.currentQuestionCount !== this.interviewContext.currentQuestionCount,
                maxQuestions: previousState.maxQuestions !== this.interviewContext.maxQuestions
            },
            timestamp: new Date().toISOString()
        });
    }
    /**
   * Get system prompt based on interview context
   */ getSystemPrompt() {
        const { type, position, company, difficulty } = this.interviewContext;
        let basePrompt = `You are an experienced AI interviewer conducting a ${type} interview. Your goal is to create an engaging, realistic interview experience that helps candidates prepare effectively.

Core Interview Principles:
1. Ask relevant, progressively challenging questions
2. Provide thoughtful follow-ups based on candidate responses
3. Maintain a professional yet conversational tone
4. Show genuine interest in the candidate's experiences
5. Adapt question difficulty based on their expertise level
6. Give brief encouraging feedback when appropriate
7. Keep responses concise (50-80 words) and ask one question at a time

`;
        if (position) {
            basePrompt += `Target Position: ${position}\n`;
        }
        if (company) {
            basePrompt += `Company Context: ${company}\n`;
        }
        if (difficulty) {
            basePrompt += `Difficulty Level: ${difficulty}\n`;
        }
        switch(type){
            case 'technical':
                basePrompt += `\nTechnical Interview Focus:
- Start with foundational concepts, then progress to complex scenarios
- Ask about specific technologies, algorithms, and system design
- Explore problem-solving approaches and trade-offs
- Include practical coding scenarios and architecture discussions
- Ask "How would you optimize this?" or "What challenges might arise?"
- Focus on real-world application of technical knowledge`;
                break;
            case 'behavioral':
                basePrompt += `\nBehavioral Interview Focus:
- Use STAR method (Situation, Task, Action, Result) evaluation
- Ask about leadership, teamwork, conflict resolution, and growth
- Explore past experiences with specific examples
- Ask follow-ups like "What would you do differently?" or "What did you learn?"
- Focus on cultural fit, communication skills, and problem-solving approach
- Include questions about handling failures and difficult situations`;
                break;
            default:
                basePrompt += `\nGeneral Interview Focus:
- Balance background, experience, motivation, and role fit
- Ask about career goals, interests, and what excites them about the opportunity
- Explore their understanding of the role and company
- Include questions about learning style and professional development
- Ask about their greatest achievements and challenges`;
        }
        basePrompt += `\n\nInterview Style:
- Be conversational and show active listening
- Acknowledge good points: "That's a great approach" or "Interesting perspective"
- Ask natural follow-ups that build on their responses
- Create a comfortable environment that encourages detailed answers`;
        return basePrompt;
    }
    /**
   * Start a new interview conversation
   */ async startInterviewConversation() {
        console.log('🚀 [TRACE] startInterviewConversation called', {
            timestamp: new Date().toISOString(),
            interviewContext: this.interviewContext,
            isInitialized: this.isInitialized,
            callStack: new Error().stack?.split('\n').slice(0, 5).join('\n')
        });
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        // Reset conversation history
        this.conversationHistory = [
            {
                role: 'system',
                content: this.getSystemPrompt()
            }
        ];
        const openingMessage = this.getOpeningMessage();
        console.log('📢 [TRACE] Opening message generated', {
            message: openingMessage,
            interviewType: this.interviewContext.type,
            isPreliminaryQuestion: openingMessage.includes('tell me about your current role'),
            timestamp: new Date().toISOString()
        });
        this.conversationHistory.push({
            role: 'assistant',
            content: openingMessage
        });
        return {
            content: openingMessage,
            questionNumber: 1,
            isComplete: false
        };
    }
    /**
   * Get opening message based on interview type
   */ getOpeningMessage() {
        const { type, position, preliminaryCollected } = this.interviewContext;
        console.log('🎯 [TRACE] getOpeningMessage called', {
            type,
            position,
            preliminaryCollected,
            timestamp: new Date().toISOString(),
            callStack: new Error().stack?.split('\n').slice(0, 5).join('\n')
        });
        // Always greet user
        let greeting = "Hello! I'm excited to interview you today. ";
        if (position) {
            greeting += `We'll be discussing the ${position} position. `;
        }
        // Build opening message dynamically based on preliminaryCollected flag
        if (!preliminaryCollected) {
            // Append the single preliminary request
            return greeting + "Before we dive into the main interview, I'd like to get to know you better. Could you please tell me about your current role, your years of experience, and the main technologies or skills you work with?";
        } else {
            // Immediately ask first domain-specific question
            return greeting + this.generateFirstInterviewQuestion();
        }
    }
    /**
   * Generate the first interview question based on interview type
   */ generateFirstInterviewQuestion() {
        const { type, position, company, difficulty } = this.interviewContext;
        switch(type){
            case 'technical':
                if (difficulty === 'easy') {
                    return "Let's start with some fundamentals. Can you explain the difference between an array and a linked list, and when you would choose one over the other?";
                } else if (difficulty === 'hard') {
                    return "Let's dive into system design. How would you design a distributed caching system that can handle millions of requests per second with sub-millisecond latency?";
                } else {
                    return "To get started, can you walk me through a recent technical challenge you faced and how you approached solving it?";
                }
            case 'behavioral':
                if (company) {
                    return `Tell me about a time when you had to work with a difficult team member. How did you handle the situation and what was the outcome?`;
                } else {
                    return "Can you describe a situation where you had to lead a project or initiative? What was your approach and what did you learn from the experience?";
                }
            default:
                if (position) {
                    return `What specifically interests you about this ${position} role, and how does it align with your career goals?`;
                } else {
                    return "What motivated you to pursue this opportunity, and what unique value do you think you can bring to our team?";
                }
        }
    }
    /**
   * Process user response and generate next question or comment
   */ async processUserResponse(userResponse) {
        console.log('💬 [TRACE] processUserResponse called', {
            userResponse: userResponse.substring(0, 100) + '...',
            historyLength: this.conversationHistory.length,
            preliminaryCollected: this.interviewContext.preliminaryCollected,
            currentQuestionCount: this.interviewContext.currentQuestionCount,
            maxQuestions: this.interviewContext.maxQuestions,
            timestamp: new Date().toISOString(),
            callStack: new Error().stack?.split('\n').slice(0, 5).join('\n')
        });
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        // Check if we're still collecting preliminary information
        if (!this.interviewContext.preliminaryCollected) {
            console.debug('🎯 [PRELIMINARY] Processing preliminary response', {
                userResponseLength: userResponse.length,
                timestamp: new Date().toISOString()
            });
            // Process the preliminary response and set flag
            const previousPreliminaryState = this.interviewContext.preliminaryCollected;
            this.interviewContext.preliminaryCollected = true;
            console.debug('🔄 [STATE_TRANSITION] preliminaryCollected: false → true', {
                previousState: previousPreliminaryState,
                newState: true,
                timestamp: new Date().toISOString()
            });
            // Keep currentQuestionCount at 0 since we haven't asked real questions yet
            this.interviewContext.currentQuestionCount = 0;
            // Generate first real interview question
            const firstQuestion = this.generateFirstInterviewQuestion();
            this.conversationHistory.push({
                role: 'assistant',
                content: firstQuestion
            });
            // Increment to 1 for the first real question
            const previousQuestionCount = this.interviewContext.currentQuestionCount;
            this.interviewContext.currentQuestionCount = 1;
            console.debug('🔄 [STATE_TRANSITION] questionNumber: 0 → 1', {
                previousCount: previousQuestionCount,
                newCount: 1,
                isFirstRealQuestion: true,
                timestamp: new Date().toISOString()
            });
            return {
                content: `Thank you for that information! Now let's begin the interview.\n\n${firstQuestion}`,
                questionNumber: 1,
                isComplete: false,
                followUpSuggestions: this.generateFollowUpSuggestions()
            };
        }
        // Normal interview flow - add user response to conversation history
        this.conversationHistory.push({
            role: 'user',
            content: userResponse
        });
        console.log('📝 [TRACE] User response added to history', {
            historyLength: this.conversationHistory.length,
            timestamp: new Date().toISOString()
        });
        try {
            const completion = await this.retryWithBackoff(async ()=>{
                return await this.client.chat.completions.create({
                    model: this.deployment,
                    messages: this.conversationHistory,
                    temperature: 0.7,
                    max_tokens: 200,
                    top_p: 0.9,
                    frequency_penalty: 0.1,
                    presence_penalty: 0.1
                });
            });
            const assistantResponse = completion.choices[0]?.message?.content || 'I\'m sorry, I didn\'t catch that. Could you repeat your answer?';
            console.log('🤖 [TRACE] OpenAI response received', {
                response: assistantResponse.substring(0, 100) + '...',
                questionCount: this.interviewContext.currentQuestionCount,
                timestamp: new Date().toISOString()
            });
            // Add assistant response to conversation history
            this.conversationHistory.push({
                role: 'assistant',
                content: assistantResponse
            });
            const previousQuestionCount = this.interviewContext.currentQuestionCount || 0;
            const currentQuestionCount = previousQuestionCount + 1;
            const maxQuestions = this.interviewContext.maxQuestions || 10;
            console.log('📊 [TRACE] Question progression', {
                currentQuestionCount,
                maxQuestions,
                isComplete: currentQuestionCount >= maxQuestions,
                willContinue: currentQuestionCount < maxQuestions,
                timestamp: new Date().toISOString()
            });
            console.debug('🔄 [STATE_TRANSITION] questionNumber: %d → %d', previousQuestionCount, currentQuestionCount, {
                maxQuestions,
                progressPercentage: Math.round(currentQuestionCount / maxQuestions * 100),
                remainingQuestions: Math.max(0, maxQuestions - currentQuestionCount),
                timestamp: new Date().toISOString()
            });
            // Update question count
            this.interviewContext.currentQuestionCount = currentQuestionCount;
            return {
                content: assistantResponse,
                questionNumber: currentQuestionCount,
                isComplete: currentQuestionCount >= maxQuestions,
                followUpSuggestions: this.generateFollowUpSuggestions()
            };
        } catch (error) {
            console.error('❌ Error generating OpenAI response:', error);
            // Provide fallback response for common errors
            if (error.status === 429) {
                const fallbackResponse = this.getFallbackResponse(userResponse);
                this.conversationHistory.push({
                    role: 'assistant',
                    content: fallbackResponse
                });
                const currentQuestionCount = (this.interviewContext.currentQuestionCount || 0) + 1;
                this.interviewContext.currentQuestionCount = currentQuestionCount;
                return {
                    content: fallbackResponse,
                    questionNumber: currentQuestionCount,
                    isComplete: false,
                    followUpSuggestions: this.generateFollowUpSuggestions()
                };
            }
            throw new Error('Failed to generate response');
        }
    }
    /**
   * Retry mechanism with exponential backoff for rate limiting
   */ async retryWithBackoff(operation, maxRetries = 3, baseDelay = 1000) {
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                return await operation();
            } catch (error) {
                lastError = error;
                // Don't retry on non-retryable errors
                if (error.status && ![
                    429,
                    500,
                    502,
                    503,
                    504
                ].includes(error.status)) {
                    throw error;
                }
                if (attempt === maxRetries) {
                    throw error;
                }
                // Calculate delay with exponential backoff
                const delay = error.status === 429 ? parseInt(error.headers?.['retry-after'] || '10') * 1000 : baseDelay * Math.pow(2, attempt);
                console.log(`⏳ Retrying in ${delay}ms (attempt ${attempt + 1}/${maxRetries + 1})`);
                await new Promise((resolve)=>setTimeout(resolve, delay));
            }
        }
        throw lastError;
    }
    /**
   * Generate fallback response when AI service is unavailable
   */ getFallbackResponse(userResponse) {
        const { type } = this.interviewContext;
        const fallbackResponses = {
            technical: [
                "That's an interesting approach. Can you tell me more about the challenges you faced?",
                "I see. How would you optimize this solution for better performance?",
                "Good point. What alternative approaches did you consider?"
            ],
            behavioral: [
                "Thank you for sharing that experience. What was the outcome?",
                "That sounds challenging. What did you learn from that situation?",
                "Interesting. How would you handle a similar situation now?"
            ],
            general: [
                "That's great to hear. Can you elaborate on that?",
                "Interesting background. What motivates you in your work?",
                "I appreciate you sharing that. What are you most proud of?"
            ]
        };
        const responses = fallbackResponses[type] || fallbackResponses.general;
        return responses[Math.floor(Math.random() * responses.length)];
    }
    /**
   * Generate follow-up suggestions based on conversation
   */ generateFollowUpSuggestions() {
        const { type } = this.interviewContext;
        switch(type){
            case 'technical':
                return [
                    "Can you explain your thought process?",
                    "What would you do differently?",
                    "How would this scale?"
                ];
            case 'behavioral':
                return [
                    "What was the outcome?",
                    "What did you learn?",
                    "How would you handle it now?"
                ];
            default:
                return [
                    "Can you elaborate on that?",
                    "What was your biggest challenge?",
                    "What motivates you?"
                ];
        }
    }
    /**
   * Generate interview summary and feedback
   */ async generateInterviewSummary() {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        const summaryPrompt = {
            role: 'system',
            content: `Based on the interview conversation, provide a brief summary of the candidate's performance, highlighting:\n1. Key strengths demonstrated\n2. Areas for improvement\n3. Overall assessment\n4. Recommendation\n\nKeep it concise and constructive (under 200 words).`
        };
        try {
            const completion = await this.client.chat.completions.create({
                model: this.deployment,
                messages: [
                    ...this.conversationHistory,
                    summaryPrompt
                ],
                temperature: 0.3,
                max_tokens: 300
            });
            return completion.choices[0]?.message?.content || 'Unable to generate summary.';
        } catch (error) {
            console.error('❌ Error generating interview summary:', error);
            throw new Error('Failed to generate summary');
        }
    }
    /**
   * Get conversation history
   */ getConversationHistory() {
        return this.conversationHistory.filter((msg)=>msg.role !== 'system');
    }
    /**
   * Clear conversation history
   */ clearConversation() {
        const previousState = {
            historyLength: this.conversationHistory.length,
            questionCount: this.interviewContext.currentQuestionCount,
            preliminaryCollected: this.interviewContext.preliminaryCollected
        };
        this.conversationHistory = [];
        this.interviewContext.currentQuestionCount = 0;
        this.interviewContext.preliminaryCollected = false;
        console.log('🧹 Conversation history cleared');
        console.debug('🔄 [STATE_RESET] Conversation state reset', {
            previousState,
            newState: {
                historyLength: 0,
                questionCount: 0,
                preliminaryCollected: false
            },
            timestamp: new Date().toISOString()
        });
    }
    /**
   * Generate questions based on resume information
   */ async generateQuestions(resumeInfo) {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        const prompt = `Given the following resume information, generate 5 relevant interview questions. Format each question on a new line. Only return the questions, no additional text.

Name: ${resumeInfo.name}
Experience: ${resumeInfo.experience}
Education: ${resumeInfo.education}
Skills: ${resumeInfo.skills}`;
        try {
            const completion = await this.client.chat.completions.create({
                model: this.deployment,
                messages: [
                    {
                        role: 'system',
                        content: prompt
                    }
                ],
                temperature: 0.5,
                max_tokens: 150
            });
            const response = completion.choices[0]?.message?.content || '';
            return response.split('\n').map((q)=>q.trim()).filter((q)=>q.length > 0).slice(0, 5);
        } catch (error) {
            console.error('❌ Error generating questions:', error);
            throw new Error('Failed to generate questions');
        }
    }
    /**
   * Tailor resume based on job description using Azure OpenAI
   */ async tailorResume(resumeText, jobDescription) {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        const prompt = `You are an expert resume writer and ATS optimization specialist. Please tailor this resume to better match the following job description for maximum ATS compatibility and relevance.

JOB DESCRIPTION:
${jobDescription}

CURRENT RESUME:
${resumeText}

Please provide a tailored version of the resume that:
1. Uses keywords and phrases directly from the job description
2. Highlights relevant skills and experiences that match the job requirements
3. Maintains professional formatting and ATS-friendly structure
4. Uses strong action verbs and quantifiable achievements
5. Keeps the same overall length and format structure
6. Optimizes for Applicant Tracking Systems (ATS)
7. Ensures keyword density without keyword stuffing

Return ONLY the tailored resume content with no additional commentary or explanations.`;
        try {
            const completion = await this.retryWithBackoff(async ()=>{
                return await this.client.chat.completions.create({
                    model: this.deployment,
                    messages: [
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    temperature: 0.3,
                    max_tokens: 2000,
                    top_p: 0.9,
                    frequency_penalty: 0.1,
                    presence_penalty: 0.1
                });
            });
            const tailoredResume = completion.choices[0]?.message?.content;
            if (!tailoredResume) {
                throw new Error('No response generated');
            }
            return tailoredResume;
        } catch (error) {
            console.error('❌ Error tailoring resume:', error);
            throw error;
        }
    }
    /**
   * Check if service is ready
   */ isReady() {
        return this.isInitialized && this.client !== null;
    }
    /**
   * Generate a completion for a given prompt
   */ async generateCompletion(prompt) {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        try {
            const completion = await this.createCompletion([
                {
                    role: 'user',
                    content: prompt
                }
            ], {
                temperature: 0.7,
                maxTokens: 1000
            });
            return completion.choices[0]?.message?.content || 'Unable to generate completion.';
        } catch (error) {
            console.error('❌ Error generating completion:', error);
            throw new Error('Failed to generate completion');
        }
    }
    /**
   * Create a chat completion with custom parameters
   * Public method for use by adapters
   */ async createCompletion(messages, options = {}) {
        if (!this.isInitialized || !this.client) {
            throw new Error('Azure OpenAI Service not initialized');
        }
        const { temperature = 0.7, maxTokens = 1500, topP = 0.9, frequencyPenalty = 0.1, presencePenalty = 0.1 // Encourage diverse content
         } = options;
        return await this.retryWithBackoff(async ()=>{
            return await this.client.chat.completions.create({
                model: this.deployment,
                messages,
                temperature,
                max_tokens: maxTokens,
                top_p: topP,
                frequency_penalty: frequencyPenalty,
                presence_penalty: presencePenalty
            });
        });
    }
    /**
   * Dispose of resources
   */ dispose() {
        this.client = null;
        this.isInitialized = false;
        this.conversationHistory = [];
        console.log('🧹 Azure OpenAI Service disposed');
    }
    constructor(){
        this.client = null;
        this.isInitialized = false;
        this.deployment = '';
        this.conversationHistory = [];
        this.interviewContext = {
            type: 'general',
            preliminaryCollected: false,
            currentQuestionCount: 0,
            maxQuestions: 10
        };
    }
}
// Export singleton instance
const azureOpenAIService = new AzureOpenAIService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;