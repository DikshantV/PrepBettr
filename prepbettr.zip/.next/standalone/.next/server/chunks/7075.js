"use strict";
exports.id = 7075;
exports.ids = [7075];
exports.modules = {

/***/ 7075:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: () => (/* binding */ enhancedResumeProcessingService)
/* harmony export */ });
/* harmony import */ var firebase_admin_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7879);
/* harmony import */ var _lib_firebase_admin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63969);
/* harmony import */ var _lib_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25712);
/* harmony import */ var _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(26765);
/* harmony import */ var _azure_form_recognizer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(74798);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75931);
/* harmony import */ var _unified_config_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(82802);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_admin_firestore__WEBPACK_IMPORTED_MODULE_0__, _lib_storage__WEBPACK_IMPORTED_MODULE_2__, _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__, _unified_config_service__WEBPACK_IMPORTED_MODULE_6__]);
([firebase_admin_firestore__WEBPACK_IMPORTED_MODULE_0__, _lib_storage__WEBPACK_IMPORTED_MODULE_2__, _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__, _unified_config_service__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Enhanced Resume Processing Service
 * 
 * Integrates Azure AI Foundry Document Intelligence with the existing resume processing pipeline.
 * Provides advanced document analysis, ATS optimization, and job matching capabilities.
 * Features backward compatibility and graceful fallback to existing services.
 */ 






/**
 * Enhanced Resume Processing Service with Azure AI Foundry integration
 */ class EnhancedResumeProcessingService {
    /**
   * Initialize the enhanced resume processing service
   */ async initialize() {
        if (this.initialized) {
            return;
        }
        const startTime = Date.now();
        console.log('🔧 Initializing Enhanced Resume Processing Service...');
        try {
            // Check if Foundry Document Intelligence is enabled via feature flag
            this.foundryEnabled = await this.checkFoundryEnabled();
            if (this.foundryEnabled) {
                // Initialize Azure AI Foundry Document Intelligence
                const foundryReady = await _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__/* .foundryDocumentIntelligenceService */ .P.initialize();
                if (foundryReady) {
                    console.log('✅ Azure AI Foundry Document Intelligence initialized');
                } else {
                    console.warn('⚠️ Foundry Document Intelligence failed to initialize, using fallback');
                    this.foundryEnabled = false;
                }
            }
            // Always initialize fallback services
            await _azure_form_recognizer__WEBPACK_IMPORTED_MODULE_4__/* .azureFormRecognizer */ .m.initialize();
            this.initialized = true;
            const initTime = Date.now() - startTime;
            console.log(`✅ Enhanced Resume Processing Service initialized in ${initTime}ms (Foundry: ${this.foundryEnabled})`);
        } catch (error) {
            console.error('❌ Failed to initialize Enhanced Resume Processing Service:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(error, {
                service: 'enhanced-resume-processing',
                action: 'initialize'
            });
            // Don't throw - we can still operate with fallbacks
            this.initialized = true;
        }
    }
    /**
   * Check if Foundry processing is enabled via feature flag
   */ async checkFoundryEnabled() {
        try {
            const enabled = await _unified_config_service__WEBPACK_IMPORTED_MODULE_6__/* .unifiedConfigService */ .Um.get('features.foundryResumeProcessing', false);
            console.log(`🎛️ Foundry resume processing feature flag: ${enabled}`);
            return enabled;
        } catch (error) {
            console.warn('⚠️ Could not check Foundry feature flag, defaulting to false:', error);
            return false;
        }
    }
    /**
   * Process resume with enhanced capabilities
   */ async processResume(userId, fileBuffer, fileName, mimeType, fileSize, options = {}) {
        const startTime = Date.now();
        try {
            await this.initialize();
            console.log(`🔄 Processing resume for user ${userId}: ${fileName}`);
            console.log(`📋 Options:`, {
                generateQuestions: options.generateQuestions !== false,
                includeAtsAnalysis: options.includeAtsAnalysis || false,
                includeJobMatching: options.includeJobMatching && !!options.jobDescription,
                forceFoundryProcessing: options.forceFoundryProcessing || false
            });
            // Step 1: Delete existing resume if it exists
            await this.deleteExistingResume(userId);
            // Step 2: Upload to storage first (for backup and sharing)
            const storageResult = await _lib_storage__WEBPACK_IMPORTED_MODULE_2__/* .resumeStorageService */ .G5.uploadResume(userId, fileBuffer, fileName, mimeType);
            // Step 3: Extract data using the best available method
            const extractionResult = await this.extractResumeDataEnhanced(fileBuffer, mimeType, options);
            // Step 4: Generate interview questions if requested
            let interviewQuestions = [];
            if (options.generateQuestions !== false) {
                interviewQuestions = await this.generateQuestionsEnhanced(extractionResult.extractedData, options.maxQuestions);
            }
            // Step 5: Perform job matching if job description provided
            let jobMatchAnalysis;
            if (options.includeJobMatching && options.jobDescription && this.isFoundryExtraction(extractionResult.extractedData)) {
                try {
                    jobMatchAnalysis = await _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__/* .foundryDocumentIntelligenceService */ .P.compareWithJobDescription(extractionResult.extractedData, options.jobDescription);
                } catch (error) {
                    console.warn('⚠️ Job matching failed:', error);
                }
            }
            // Step 6: Save to Firestore with enhanced data
            const resumeId = await this.saveToFirestoreEnhanced(userId, {
                fileName,
                fileUrl: storageResult.fileUrl,
                filePath: storageResult.filePath,
                sasUrl: storageResult.sasUrl,
                extractedData: extractionResult.extractedData,
                interviewQuestions,
                jobDescription: options.jobDescription,
                jobMatchAnalysis,
                metadata: {
                    fileSize,
                    uploadDate: new Date(),
                    lastModified: new Date(),
                    mimeType,
                    storageProvider: storageResult.provider,
                    processingMethod: extractionResult.processingMethod,
                    processingTime: extractionResult.processingTime,
                    confidence: extractionResult.confidence
                }
            });
            const totalProcessingTime = Date.now() - startTime;
            console.log(`✅ Enhanced resume processing completed in ${totalProcessingTime}ms`);
            // Extract enhanced scores for response
            const atsScore = this.isFoundryExtraction(extractionResult.extractedData) ? extractionResult.extractedData.atsAnalysis?.score : undefined;
            const jobMatchScore = jobMatchAnalysis?.overallScore;
            const missingKeywords = jobMatchAnalysis?.skillsMatch.missingSkills;
            return {
                success: true,
                data: {
                    resumeId,
                    fileUrl: storageResult.fileUrl,
                    sasUrl: storageResult.sasUrl,
                    extractedData: extractionResult.extractedData,
                    interviewQuestions,
                    storageProvider: storageResult.provider,
                    atsScore,
                    jobMatchScore,
                    missingKeywords,
                    processingMethod: extractionResult.processingMethod,
                    processingTime: totalProcessingTime,
                    confidence: extractionResult.confidence
                }
            };
        } catch (error) {
            const processingTime = Date.now() - startTime;
            console.error(`❌ Enhanced resume processing failed for user ${userId}:`, error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_5__/* .logServerError */ .wh)(error, {
                service: 'enhanced-resume-processing',
                action: 'process',
                userId
            }, {
                fileName: fileName.substring(0, 50),
                processingTime,
                foundryEnabled: this.foundryEnabled
            });
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Failed to process resume'
            };
        }
    }
    /**
   * Extract resume data using enhanced processing with intelligent fallback
   */ async extractResumeDataEnhanced(fileBuffer, mimeType, options) {
        // Try Azure AI Foundry Document Intelligence first (if enabled)
        if ((this.foundryEnabled || options.forceFoundryProcessing) && _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__/* .foundryDocumentIntelligenceService */ .P.isReady()) {
            try {
                console.log('🚀 Using Azure AI Foundry Document Intelligence...');
                const startTime = Date.now();
                const extraction = await _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__/* .foundryDocumentIntelligenceService */ .P.analyzeResume(fileBuffer, mimeType, {
                    includeAtsAnalysis: options.includeAtsAnalysis,
                    modelType: 'resume-analysis'
                });
                const processingTime = Date.now() - startTime;
                return {
                    extractedData: extraction,
                    processingMethod: 'foundry-document-intelligence',
                    processingTime,
                    confidence: extraction.metadata.overallConfidence
                };
            } catch (error) {
                console.warn('⚠️ Foundry Document Intelligence failed, falling back:', error);
            // Continue to fallback
            }
        }
        // Fallback to Azure Form Recognizer
        if (_azure_form_recognizer__WEBPACK_IMPORTED_MODULE_4__/* .azureFormRecognizer */ .m.isReady()) {
            try {
                console.log('🔍 Using Azure Form Recognizer fallback...');
                const startTime = Date.now();
                const extraction = await _azure_form_recognizer__WEBPACK_IMPORTED_MODULE_4__/* .azureFormRecognizer */ .m.extractResumeData(fileBuffer, mimeType);
                const processingTime = Date.now() - startTime;
                return {
                    extractedData: extraction,
                    processingMethod: 'azure-form-recognizer',
                    processingTime,
                    confidence: 0.8 // Default confidence for Form Recognizer
                };
            } catch (error) {
                console.warn('⚠️ Azure Form Recognizer failed, falling back to OpenAI:', error);
            // Continue to final fallback
            }
        }
        // Final fallback to OpenAI extraction
        console.log('🤖 Using OpenAI extraction fallback...');
        const startTime = Date.now();
        const extraction = await this.extractWithOpenAIFallback(fileBuffer, mimeType);
        const processingTime = Date.now() - startTime;
        return {
            extractedData: extraction,
            processingMethod: 'openai-fallback',
            processingTime,
            confidence: 0.7 // Lower confidence for text-only extraction
        };
    }
    /**
   * Enhanced question generation with intelligent routing
   */ async generateQuestionsEnhanced(extractedData, maxQuestions = 10) {
        try {
            console.log('🤔 Generating interview questions...');
            // Use the unified Azure AI service for question generation
            const { azureAI } = await Promise.all(/* import() */[__webpack_require__.e(8833), __webpack_require__.e(5506), __webpack_require__.e(3685)]).then(__webpack_require__.bind(__webpack_require__, 53685));
            // Convert data to the format expected by azureAI
            const resumeData = this.convertToResumeInfo(extractedData);
            const result = await azureAI.generateQuestions(resumeData, {
                maxQuestions,
                interviewType: 'mixed'
            });
            if (result.success && result.data) {
                console.log(`✅ Generated ${result.data.length} interview questions via ${result.provider}`);
                return result.data;
            }
            // Return default questions if generation fails
            console.warn('⚠️ Question generation failed, using defaults:', result.error);
            return result.data || this.getDefaultQuestions();
        } catch (error) {
            console.warn('⚠️ Question generation failed:', error);
            return this.getDefaultQuestions();
        }
    }
    /**
   * Save enhanced data to Firestore
   */ async saveToFirestoreEnhanced(userId, resumeData) {
        try {
            const db = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_1__.getAdminFirestore)();
            const docRef = db.collection('profiles').doc(userId);
            // Extract ATS and job matching scores for top-level fields
            const atsScore = this.isFoundryExtraction(resumeData.extractedData) ? resumeData.extractedData.atsAnalysis?.score : undefined;
            const jobMatchScore = resumeData.jobMatchAnalysis?.overallScore;
            const missingKeywords = resumeData.jobMatchAnalysis?.skillsMatch.missingSkills || [];
            await docRef.set({
                userId,
                ...resumeData,
                // Enhanced fields for easy querying
                atsScore,
                jobMatchScore,
                missingKeywords,
                processorVersion: this.isFoundryExtraction(resumeData.extractedData) ? 'foundry-v1' : 'legacy-v1',
                metadata: {
                    ...resumeData.metadata,
                    uploadDate: firebase_admin_firestore__WEBPACK_IMPORTED_MODULE_0__.FieldValue.serverTimestamp(),
                    lastModified: firebase_admin_firestore__WEBPACK_IMPORTED_MODULE_0__.FieldValue.serverTimestamp()
                }
            });
            console.log(`✅ Enhanced resume data saved to Firestore for user: ${userId}`);
            return userId;
        } catch (error) {
            console.error('❌ Failed to save enhanced resume data to Firestore:', error);
            throw new Error('Failed to save resume data');
        }
    }
    /**
   * Delete existing resume data
   */ async deleteExistingResume(userId) {
        try {
            const db = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_1__.getAdminFirestore)();
            const profileDoc = await db.collection('profiles').doc(userId).get();
            if (profileDoc.exists) {
                const profileData = profileDoc.data();
                // Delete from storage
                if (profileData?.filePath) {
                    await _lib_storage__WEBPACK_IMPORTED_MODULE_2__/* .resumeStorageService */ .G5.deleteResume(profileData.filePath);
                } else if (profileData?.blobName) {
                    await _lib_storage__WEBPACK_IMPORTED_MODULE_2__/* .resumeStorageService */ .G5.deleteResume(profileData.blobName);
                }
            }
            console.log(`🗑️ Existing resume cleaned up for user: ${userId}`);
        } catch (error) {
            console.warn('⚠️ Failed to delete existing resume:', error);
        // Don't throw - we still want to proceed with new upload
        }
    }
    /**
   * OpenAI fallback extraction (legacy method)
   */ async extractWithOpenAIFallback(fileBuffer, mimeType) {
        // For PDFs, extract text first
        let text = '';
        if (mimeType === 'application/pdf') {
            const pdfParse = await __webpack_require__.e(/* import() */ 6188).then(__webpack_require__.t.bind(__webpack_require__, 36188, 23));
            const pdfData = await pdfParse.default(fileBuffer);
            text = pdfData.text;
        } else if (mimeType.includes('text')) {
            text = fileBuffer.toString('utf-8');
        } else {
            throw new Error(`Unsupported file type for OpenAI extraction: ${mimeType}`);
        }
        // Use unified Azure AI service for structured extraction
        const prompt = this.getExtractionPrompt(text);
        const { azureAI } = await Promise.all(/* import() */[__webpack_require__.e(8833), __webpack_require__.e(5506), __webpack_require__.e(3685)]).then(__webpack_require__.bind(__webpack_require__, 53685));
        const result = await azureAI.generateCompletion(prompt, {
            temperature: 0.1,
            maxTokens: 4000
        });
        if (result.success && result.data) {
            try {
                const parsedData = typeof result.data === 'string' ? JSON.parse(result.data) : result.data;
                return {
                    personalInfo: parsedData.personalInfo || {},
                    summary: parsedData.summary,
                    skills: parsedData.skills || [],
                    experience: parsedData.experience || [],
                    education: parsedData.education || [],
                    projects: parsedData.projects || [],
                    certifications: parsedData.certifications || [],
                    languages: parsedData.languages || [],
                    rawExtraction: {
                        text,
                        aiResponse: result.data
                    }
                };
            } catch (parseError) {
                console.warn('⚠️ Failed to parse OpenAI extraction result');
                throw new Error('Failed to parse extracted resume data');
            }
        }
        throw new Error('Failed to extract resume data with OpenAI');
    }
    /**
   * Type guard to check if extraction is from Foundry
   */ isFoundryExtraction(data) {
        return 'metadata' in data && data.metadata && 'processingTime' in data.metadata;
    }
    /**
   * Convert extracted data to ResumeInfo format for question generation
   */ convertToResumeInfo(data) {
        if (this.isFoundryExtraction(data)) {
            // Enhanced Foundry extraction
            return {
                name: data.personalInfo?.name?.content || 'Unknown',
                skills: data.skills.map((s)=>s.skill).join(', '),
                experience: data.experience.map((exp)=>`${exp.position.content} at ${exp.company.content} (${exp.startDate?.content || 'Unknown'} - ${exp.endDate?.content || 'Present'}): ${exp.description.content}`).join('. '),
                education: data.education.map((edu)=>`${edu.degree.content} in ${edu.field.content} from ${edu.institution.content} (${edu.startDate?.content || 'Unknown'} - ${edu.endDate?.content || 'Unknown'})`).join(', ')
            };
        } else {
            // Legacy extraction
            return {
                name: data.personalInfo?.name || 'Unknown',
                skills: data.skills.join(', '),
                experience: data.experience.map((exp)=>`${exp.position} at ${exp.company} (${exp.startDate || 'Unknown'} - ${exp.endDate || 'Present'}): ${exp.description}`).join('. '),
                education: data.education.map((edu)=>`${edu.degree} in ${edu.field} from ${edu.institution} (${edu.startDate || 'Unknown'} - ${edu.endDate || 'Unknown'})`).join(', ')
            };
        }
    }
    /**
   * Get extraction prompt for OpenAI fallback
   */ getExtractionPrompt(text) {
        return `Extract the following information from this resume text and return as JSON:

    {
      "personalInfo": {
        "name": "Full name",
        "email": "Email address", 
        "phone": "Phone number",
        "address": "Address",
        "linkedin": "LinkedIn URL",
        "github": "GitHub URL",
        "website": "Personal website URL"
      },
      "summary": "Professional summary",
      "skills": ["skill1", "skill2", ...],
      "experience": [
        {
          "company": "Company name",
          "position": "Job title", 
          "startDate": "Start date",
          "endDate": "End date or 'Present'",
          "isCurrent": true/false,
          "description": "Job description",
          "achievements": ["achievement1", ...],
          "technologies": ["tech1", "tech2", ...],
          "location": "Location"
        }
      ],
      "education": [
        {
          "institution": "School name",
          "degree": "Degree type",
          "field": "Field of study", 
          "startDate": "Start date",
          "endDate": "End date",
          "gpa": 3.5,
          "location": "Location"
        }
      ],
      "projects": [...],
      "certifications": [...],
      "languages": [...]
    }
    
    Resume text:
    ${text}`;
    }
    /**
   * Get default interview questions
   */ getDefaultQuestions() {
        return [
            "Tell me about yourself and your professional background.",
            "What interests you most about this position?",
            "Describe a challenging project you've worked on.",
            "How do you stay updated with industry trends?",
            "Where do you see yourself in 5 years?",
            "What are your greatest strengths?",
            "Describe a time when you had to work under pressure.",
            "How do you handle feedback and criticism?"
        ];
    }
    /**
   * Get user's resume data from Firestore
   */ async getUserResumeData(userId) {
        try {
            const db = await (0,_lib_firebase_admin__WEBPACK_IMPORTED_MODULE_1__.getAdminFirestore)();
            const profileDoc = await db.collection('profiles').doc(userId).get();
            if (profileDoc.exists) {
                return profileDoc.data();
            }
            return null;
        } catch (error) {
            console.error('❌ Failed to get user resume data:', error);
            throw error;
        }
    }
    /**
   * Generate new secure URL for file access
   */ async generateNewSecureUrl(userId, expiryHours = 24) {
        try {
            const resumeData = await this.getUserResumeData(userId);
            const filePath = resumeData?.filePath || resumeData?.blobName;
            if (filePath) {
                return await _lib_storage__WEBPACK_IMPORTED_MODULE_2__/* .resumeStorageService */ .G5.getResumeUrl(filePath, expiryHours);
            }
            return null;
        } catch (error) {
            console.error('❌ Failed to generate new secure URL:', error);
            return null;
        }
    }
    /**
   * Check service status
   */ getServiceStatus() {
        return {
            initialized: this.initialized,
            foundryEnabled: this.foundryEnabled,
            foundryReady: _lib_azure_ai_foundry_documents_document_client__WEBPACK_IMPORTED_MODULE_3__/* .foundryDocumentIntelligenceService */ .P.isReady(),
            formRecognizerReady: _azure_form_recognizer__WEBPACK_IMPORTED_MODULE_4__/* .azureFormRecognizer */ .m.isReady()
        };
    }
    constructor(){
        this.initialized = false;
        this.foundryEnabled = false;
    }
}
// Export singleton instance
const enhancedResumeProcessingService = new EnhancedResumeProcessingService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 25712:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G5: () => (/* binding */ resumeStorageService)
/* harmony export */ });
/* unused harmony exports getStorageService, resetStorageService, ResumeStorageService */
/* harmony import */ var _IStorageService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59291);
/* harmony import */ var _providers_AzureBlobStorageService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39909);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_providers_AzureBlobStorageService__WEBPACK_IMPORTED_MODULE_1__]);
_providers_AzureBlobStorageService__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// Client-side safety check
const isClient = "undefined" !== 'undefined';
// Only import server-side dependencies when running on server
let getConfiguration = null;
if (!isClient) {
    const azureConfig = __webpack_require__(85500);
    getConfiguration = azureConfig.getConfiguration;
}
// Singleton storage service instance
let storageServiceInstance = null;
/**
 * Gets the Azure Blob Storage service instance.
 * All storage operations now use Azure exclusively.
 */ async function getStorageService() {
    if (isClient) {
        throw new Error('Storage service not available on client side');
    }
    if (storageServiceInstance) {
        return storageServiceInstance;
    }
    storageServiceInstance = await createAzureStorageService();
    return storageServiceInstance;
}
/**
 * Creates an Azure Blob Storage service instance with proper configuration.
 */ async function createAzureStorageService() {
    if (isClient) {
        throw new Error('Storage service not available on client side');
    }
    try {
        const config = await getConfiguration();
        const storageAccountName = config['AZURE_STORAGE_ACCOUNT'] || process.env.AZURE_STORAGE_ACCOUNT || 'prepbettrstorage684';
        const containerName = config['AZURE_STORAGE_CONTAINER'] || process.env.AZURE_STORAGE_CONTAINER || 'resumes';
        return new _providers_AzureBlobStorageService__WEBPACK_IMPORTED_MODULE_1__/* .AzureBlobStorageService */ .$(storageAccountName, containerName);
    } catch (error) {
        console.error('Failed to create Azure storage service:', error);
        throw error;
    }
}
/**
 * Resets the singleton storage service instance.
 * Useful for testing or configuration changes.
 */ function resetStorageService() {
    storageServiceInstance = null;
}
/**
 * Resume-specific utilities for backward compatibility
 */ class ResumeStorageService {
    async getService() {
        if (!this.storageService) {
            this.storageService = await getStorageService();
        }
        return this.storageService;
    }
    /**
   * Upload a resume file with proper path organization
   */ async uploadResume(userId, fileBuffer, fileName, mimeType) {
        const service = await this.getService();
        const filePath = `resumes/${userId}/${fileName}`;
        const result = await service.upload(fileBuffer, filePath, mimeType);
        return {
            fileUrl: result.url,
            filePath: result.path,
            sasUrl: result.sasUrl,
            provider: _IStorageService__WEBPACK_IMPORTED_MODULE_0__/* .StorageProvider */ .L.Azure
        };
    }
    /**
   * Delete a resume file
   */ async deleteResume(filePath) {
        const service = await this.getService();
        await service.delete(filePath);
    }
    /**
   * Generate a secure URL for resume access
   */ async getResumeUrl(filePath, expiresInHours = 24) {
        const service = await this.getService();
        return await service.getPublicUrl(filePath, {
            expiresIn: expiresInHours * 3600,
            accessType: 'read'
        });
    }
    constructor(){
        this.storageService = null;
    }
}
// Export singleton instance for resume operations
const resumeStorageService = new ResumeStorageService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 39909:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ AzureBlobStorageService)
/* harmony export */ });
/* harmony import */ var _azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(14737);
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10756);
/* harmony import */ var _opentelemetry_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(76895);
/* harmony import */ var _IStorageService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59291);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__, _azure_identity__WEBPACK_IMPORTED_MODULE_1__]);
([_azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__, _azure_identity__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const TRACER_NAME = 'AzureBlobStorageService';
class AzureBlobStorageService {
    constructor(storageAccountName, containerName){
        this.containerName = containerName;
        this.isInitialized = false;
        this.storageAccountName = storageAccountName;
        const blobServiceUrl = `https://${this.storageAccountName}.blob.core.windows.net`;
        // Use DefaultAzureCredential in production, fallback to connection string for local dev
        const credential = process.env.AZURE_STORAGE_CONNECTION_STRING ? new _azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__.StorageSharedKeyCredential(this.storageAccountName, process.env.AZURE_STORAGE_ACCOUNT_KEY) : new _azure_identity__WEBPACK_IMPORTED_MODULE_1__.DefaultAzureCredential();
        const blobServiceClient = new _azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__.BlobServiceClient(blobServiceUrl, credential);
        this.containerClient = blobServiceClient.getContainerClient(this.containerName);
    }
    async initialize() {
        if (this.isInitialized) return;
        const tracer = _opentelemetry_api__WEBPACK_IMPORTED_MODULE_3__/* .trace */ .u.getTracer(TRACER_NAME);
        const span = tracer.startSpan('initialize');
        try {
            await this.containerClient.createIfNotExists(); // Private access by default
            this.isInitialized = true;
            span.setStatus({
                code: 1
            }); // OK
        } catch (error) {
            span.recordException(error);
            span.setStatus({
                code: 2,
                message: error.message
            }); // ERROR
            throw new _IStorageService__WEBPACK_IMPORTED_MODULE_2__/* .StorageError */ .a('Failed to initialize Azure Blob Storage container', _IStorageService__WEBPACK_IMPORTED_MODULE_2__/* .StorageProvider */ .L.Azure, error);
        } finally{
            span.end();
        }
    }
    async upload(file, path, mimeType) {
        await this.initialize();
        const blockBlobClient = this.containerClient.getBlockBlobClient(path);
        const tracer = _opentelemetry_api__WEBPACK_IMPORTED_MODULE_3__/* .trace */ .u.getTracer(TRACER_NAME);
        const span = tracer.startSpan('upload');
        span.setAttributes({
            path,
            mimeType,
            size: file.length
        });
        try {
            await blockBlobClient.upload(file, file.length, {
                blobHTTPHeaders: {
                    blobContentType: mimeType
                }
            });
            const fileMeta = {
                provider: _IStorageService__WEBPACK_IMPORTED_MODULE_2__/* .StorageProvider */ .L.Azure,
                url: blockBlobClient.url,
                path,
                size: file.length,
                mimeType: mimeType || 'application/octet-stream',
                createdAt: new Date()
            };
            span.setStatus({
                code: 1
            });
            return fileMeta;
        } catch (error) {
            span.recordException(error);
            span.setStatus({
                code: 2,
                message: error.message
            });
            throw new _IStorageService__WEBPACK_IMPORTED_MODULE_2__/* .StorageError */ .a(`Failed to upload to Azure Blob Storage: ${path}`, _IStorageService__WEBPACK_IMPORTED_MODULE_2__/* .StorageProvider */ .L.Azure, error);
        } finally{
            span.end();
        }
    }
    async download(path) {
        await this.initialize();
        const blockBlobClient = this.containerClient.getBlockBlobClient(path);
        const tracer = _opentelemetry_api__WEBPACK_IMPORTED_MODULE_3__/* .trace */ .u.getTracer(TRACER_NAME);
        const span = tracer.startSpan('download');
        span.setAttribute('path', path);
        try {
            const buffer = await blockBlobClient.downloadToBuffer();
            span.setStatus({
                code: 1
            });
            return buffer;
        } catch (error) {
            span.recordException(error);
            span.setStatus({
                code: 2,
                message: error.message
            });
            throw new _IStorageService__WEBPACK_IMPORTED_MODULE_2__/* .StorageError */ .a(`Failed to download from Azure Blob Storage: ${path}`, _IStorageService__WEBPACK_IMPORTED_MODULE_2__/* .StorageProvider */ .L.Azure, error);
        } finally{
            span.end();
        }
    }
    async delete(path) {
        await this.initialize();
        const blockBlobClient = this.containerClient.getBlockBlobClient(path);
        const tracer = _opentelemetry_api__WEBPACK_IMPORTED_MODULE_3__/* .trace */ .u.getTracer(TRACER_NAME);
        const span = tracer.startSpan('delete');
        span.setAttribute('path', path);
        try {
            await blockBlobClient.delete();
            span.setStatus({
                code: 1
            });
        } catch (error) {
            span.recordException(error);
            span.setStatus({
                code: 2,
                message: error.message
            });
            throw new _IStorageService__WEBPACK_IMPORTED_MODULE_2__/* .StorageError */ .a(`Failed to delete from Azure Blob Storage: ${path}`, _IStorageService__WEBPACK_IMPORTED_MODULE_2__/* .StorageProvider */ .L.Azure, error);
        } finally{
            span.end();
        }
    }
    async getPublicUrl(path, options) {
        await this.initialize();
        const blockBlobClient = this.containerClient.getBlockBlobClient(path);
        const permissions = new _azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__.BlobSASPermissions();
        permissions.read = options?.accessType === 'read' || !options?.accessType;
        permissions.write = options?.accessType === 'write';
        const expiryDate = new Date();
        expiryDate.setSeconds(expiryDate.getSeconds() + (options?.expiresIn || 3600)); // Default to 1 hour
        const sasQueryParameters = (0,_azure_storage_blob__WEBPACK_IMPORTED_MODULE_0__.generateBlobSASQueryParameters)({
            containerName: this.containerName,
            blobName: path,
            permissions,
            startsOn: new Date(),
            expiresOn: expiryDate
        }, this.containerClient.credential);
        return `${blockBlobClient.url}?${sasQueryParameters.toString()}`;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 59291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L: () => (/* binding */ StorageProvider),
/* harmony export */   a: () => (/* binding */ StorageError)
/* harmony export */ });
/**
 * @file Defines the universal interface for storage services.
 * This abstraction allows for a seamless switch between different storage providers (e.g., Azure, Firebase).
 */ /**
 * Enumeration for the storage providers.
 */ var StorageProvider = /*#__PURE__*/ function(StorageProvider) {
    StorageProvider["Azure"] = "azure";
    StorageProvider["Firebase"] = "firebase";
    StorageProvider["Dual"] = "dual";
    return StorageProvider;
}({});
/**
 * Custom error class for storage operations.
 */ class StorageError extends Error {
    constructor(message, provider, originalError){
        super(message), this.provider = provider, this.originalError = originalError;
        this.name = 'StorageError';
    }
}


/***/ }),

/***/ 74798:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   m: () => (/* binding */ azureFormRecognizer)
/* harmony export */ });
/* harmony import */ var _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(98180);
/* harmony import */ var _azure_lib_azure_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65868);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75931);



class AzureFormRecognizerService {
    /**
   * Initialize the Azure Form Recognizer service
   */ async initialize() {
        try {
            const secrets = await (0,_azure_lib_azure_config__WEBPACK_IMPORTED_MODULE_1__/* .fetchAzureSecrets */ .lL)();
            const endpoint = process.env.AZURE_FORM_RECOGNIZER_ENDPOINT || secrets.azureFormRecognizerEndpoint;
            const apiKey = process.env.AZURE_FORM_RECOGNIZER_KEY || secrets.azureFormRecognizerKey;
            if (!endpoint || !apiKey) {
                console.warn('⚠️ Azure Form Recognizer credentials not found, will use OpenAI fallback');
                return false;
            }
            this.client = new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_0__/* .DocumentAnalysisClient */ .Pz(endpoint, new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_0__/* .AzureKeyCredential */ .KL(apiKey));
            console.log('✅ Azure Form Recognizer service initialized');
            return true;
        } catch (error) {
            console.error('❌ Failed to initialize Azure Form Recognizer:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
                service: 'azure-form-recognizer',
                action: 'initialize'
            });
            return false;
        }
    }
    /**
   * Check if service is ready
   */ isReady() {
        return this.client !== null;
    }
    /**
   * Extract resume data from buffer using Azure Form Recognizer
   */ async extractResumeData(fileBuffer, mimeType) {
        if (!this.isReady()) {
            throw new Error('Azure Form Recognizer service not initialized');
        }
        try {
            console.log('🔍 Extracting resume data with Azure Form Recognizer...');
            // Analyze the document
            const poller = await this.client.beginAnalyzeDocument(this.modelId, fileBuffer);
            const result = await poller.pollUntilDone();
            // Extract text content from the document
            const fullText = result.content || '';
            // Store raw extraction for GDPR export
            const rawExtraction = {
                content: result.content,
                pages: result.pages,
                tables: result.tables,
                keyValuePairs: result.keyValuePairs,
                styles: result.styles
            };
            // Parse the extracted text to structure data
            const extractedData = await this.parseResumeContent(fullText);
            // Include raw extraction
            extractedData.rawExtraction = rawExtraction;
            console.log('✅ Resume data extracted successfully with Azure Form Recognizer');
            return extractedData;
        } catch (error) {
            console.error('Failed to extract resume data with Azure Form Recognizer:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
                service: 'azure-form-recognizer',
                action: 'extract'
            }, {
                mimeType
            });
            throw error;
        }
    }
    /**
   * Parse resume content using AI to extract structured data
   * This method uses OpenAI as a processing layer on top of Form Recognizer
   */ async parseResumeContent(text) {
        // We'll use tailorResume function as it's the main AI processing function available
        // Use OpenAI function calling to structure the extracted text
        const prompt = `
    Extract the following information from this resume text and return as JSON:
    
    {
      "personalInfo": {
        "name": "Full name",
        "email": "Email address",
        "phone": "Phone number",
        "address": "Address",
        "linkedin": "LinkedIn URL",
        "github": "GitHub URL",
        "website": "Personal website URL"
      },
      "summary": "Professional summary or objective",
      "skills": ["skill1", "skill2", ...],
      "experience": [
        {
          "company": "Company name",
          "position": "Job title",
          "startDate": "Start date",
          "endDate": "End date or 'Present'",
          "isCurrent": true/false,
          "description": "Job description",
          "achievements": ["achievement1", ...],
          "technologies": ["tech1", "tech2", ...],
          "location": "Location"
        }
      ],
      "education": [
        {
          "institution": "School name",
          "degree": "Degree type",
          "field": "Field of study",
          "startDate": "Start date",
          "endDate": "End date",
          "gpa": 3.5,
          "description": "Additional details",
          "location": "Location"
        }
      ],
      "projects": [
        {
          "name": "Project name",
          "description": "Project description",
          "technologies": ["tech1", "tech2", ...],
          "url": "Project URL",
          "github": "GitHub URL",
          "startDate": "Start date",
          "endDate": "End date"
        }
      ],
      "certifications": [
        {
          "name": "Certification name",
          "issuer": "Issuing organization",
          "date": "Issue date",
          "expiryDate": "Expiry date",
          "credentialId": "Credential ID",
          "url": "Verification URL"
        }
      ],
      "languages": [
        {
          "name": "Language name",
          "proficiency": "Proficiency level"
        }
      ]
    }
    
    Resume text:
    ${text}
    `;
        try {
            // Use the AI service to process the text
            const { tailorResume } = await Promise.all(/* import() */[__webpack_require__.e(8833), __webpack_require__.e(5506), __webpack_require__.e(6955), __webpack_require__.e(3685)]).then(__webpack_require__.bind(__webpack_require__, 53685));
            // Create a structured extraction prompt
            const extractionResult = await tailorResume(text, prompt);
            if (extractionResult.success && extractionResult.data) {
                try {
                    // Parse the JSON response
                    const parsedData = typeof extractionResult.data === 'string' ? JSON.parse(extractionResult.data) : extractionResult.data;
                    return {
                        personalInfo: parsedData.personalInfo || {},
                        summary: parsedData.summary,
                        skills: parsedData.skills || [],
                        experience: parsedData.experience || [],
                        education: parsedData.education || [],
                        projects: parsedData.projects || [],
                        certifications: parsedData.certifications || [],
                        languages: parsedData.languages || []
                    };
                } catch (parseError) {
                    console.warn('Failed to parse AI extraction result, using fallback parsing');
                    return this.fallbackTextParsing(text);
                }
            }
            // Fallback to simple text parsing if AI fails
            return this.fallbackTextParsing(text);
        } catch (error) {
            console.warn('AI parsing failed, using fallback text parsing:', error);
            return this.fallbackTextParsing(text);
        }
    }
    /**
   * Fallback text parsing method
   */ fallbackTextParsing(text) {
        const lines = text.split('\n').map((line)=>line.trim()).filter((line)=>line);
        // Simple regex patterns for basic extraction
        const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
        const phoneRegex = /(\+?1?[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}/g;
        const linkedinRegex = /linkedin\.com\/in\/[\w-]+/gi;
        const githubRegex = /github\.com\/[\w-]+/gi;
        const emails = text.match(emailRegex) || [];
        const phones = text.match(phoneRegex) || [];
        const linkedinUrls = text.match(linkedinRegex) || [];
        const githubUrls = text.match(githubRegex) || [];
        // Extract skills (simple keyword matching)
        const skillKeywords = [
            'javascript',
            'typescript',
            'python',
            'java',
            'react',
            'node',
            'express',
            'mongodb',
            'sql',
            'postgresql',
            'mysql',
            'docker',
            'kubernetes',
            'aws',
            'azure',
            'gcp',
            'git',
            'html',
            'css',
            'angular',
            'vue',
            'spring',
            'django',
            'flask',
            'ruby',
            'php',
            'go',
            'rust',
            'c++',
            'c#',
            'swift',
            'kotlin',
            'flutter',
            'dart',
            'tensorflow',
            'pytorch',
            'machine learning',
            'data science',
            'artificial intelligence',
            'blockchain',
            'devops'
        ];
        const detectedSkills = skillKeywords.filter((skill)=>text.toLowerCase().includes(skill.toLowerCase()));
        return {
            personalInfo: {
                email: emails[0],
                phone: phones[0],
                linkedin: linkedinUrls[0] ? `https://${linkedinUrls[0]}` : undefined,
                github: githubUrls[0] ? `https://${githubUrls[0]}` : undefined
            },
            skills: detectedSkills,
            experience: [],
            education: [],
            projects: [],
            certifications: [],
            languages: []
        };
    }
    constructor(){
        this.client = null;
        this.modelId = 'prebuilt-document' // Use prebuilt document model
        ;
    }
}
// Export singleton instance
const azureFormRecognizer = new AzureFormRecognizerService();


/***/ }),

/***/ 75931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   wh: () => (/* binding */ logServerError)
/* harmony export */ });
/* unused harmony exports createErrorResponse, createApiErrorResponse, isRetryableError, mapErrorToResponse, NETWORK_FAILURE_MESSAGE, getUserFriendlyErrorMessage */
// lib/errors.ts
/**
 * Creates a standardized error response
 */ function createErrorResponse(error, status) {
    return {
        error,
        status
    };
}
/**
 * Creates a NextResponse error for API routes
 */ function createApiErrorResponse(error, status) {
    // Import NextResponse dynamically to avoid module issues
    const { NextResponse } = __webpack_require__(32190);
    return NextResponse.json({
        error
    }, {
        status
    });
}
/**
 * Logs server errors with context but never exposes sensitive information
 */ function logServerError(error, context, additionalContext) {
    const errorMessage = error instanceof Error ? error.message : error;
    const errorStack = error instanceof Error ? error.stack : undefined;
    // Create safe logging context (no sensitive data)
    const safeContext = {
        timestamp: context.timestamp || new Date().toISOString(),
        url: context.url,
        method: context.method,
        userId: context.userId ? `user_${context.userId.slice(-8)}` : 'anonymous',
        userAgent: context.userAgent ? context.userAgent.slice(0, 100) : undefined,
        ip: context.ip ? context.ip.replace(/\d+$/, 'xxx') : undefined,
        ...additionalContext
    };
    console.error('Server Error:', {
        message: errorMessage,
        context: safeContext,
        stack: errorStack
    });
    // In production, you might want to send this to a logging service
    // like DataDog, Sentry, etc.
    if (true) {
    // Example: Send to external logging service
    // logger.error(errorMessage, safeContext);
    }
}
/**
 * Determines if an error should be retried
 */ function isRetryableError(status) {
    // Retry for 5xx errors and specific 4xx errors
    return status >= 500 || status === 408 || status === 429;
}
/**
 * Maps common error types to standard error responses
 */ function mapErrorToResponse(error) {
    // Network/Connection errors
    if (error.name === 'AbortError' || error.code === 'ECONNABORTED') {
        return createErrorResponse('Request timeout. Please try again.', 408);
    }
    if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
        return createErrorResponse('Network error. Please check your connection.', 503);
    }
    // Azure OpenAI specific errors
    if (error.status) {
        switch(error.status){
            case 401:
                return createErrorResponse('Service authentication failed. Please try again later.', 500);
            case 429:
                return createErrorResponse('Service temporarily unavailable due to high demand. Please try again later.', 429);
            case 400:
                return createErrorResponse('Invalid request format. Please check your input.', 400);
            default:
                if (error.status >= 500) {
                    return createErrorResponse('Service temporarily unavailable. Please try again later.', 500);
                }
        }
    }
    // Generic API errors
    if (error.message) {
        if (error.message.includes('API key') || error.message.includes('credentials')) {
            return createErrorResponse('Service configuration error. Please contact support.', 500);
        }
        if (error.message.includes('quota') || error.message.includes('limit') || error.message.includes('rate')) {
            return createErrorResponse('Service temporarily unavailable due to usage limits. Please try again later.', 429);
        }
        if (error.message.includes('not initialized')) {
            return createErrorResponse('Service is not properly configured. Please contact support.', 500);
        }
    }
    // Default error response
    return createErrorResponse('An unexpected error occurred. Please try again.', 500);
}
/**
 * Standard fallback message for network failures
 */ const NETWORK_FAILURE_MESSAGE = "Could not fetch job description from the provided URL.";
/**
 * Gets user-friendly error message for frontend display
 */ function getUserFriendlyErrorMessage(error, context) {
    if (error?.error) {
        return error.error;
    }
    if (context === 'url_extraction') {
        return NETWORK_FAILURE_MESSAGE;
    }
    if (error?.message) {
        // Don't expose internal error messages to users
        if (error.message.includes('API key') || error.message.includes('credentials') || error.message.includes('internal') || error.message.includes('database')) {
            return 'Service temporarily unavailable. Please try again later.';
        }
        return error.message;
    }
    return 'An unexpected error occurred. Please try again.';
}


/***/ })

};
;