"use strict";
exports.id = 7186;
exports.ids = [7186];
exports.modules = {

/***/ 73905:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   clearAzureSecretsCache: () => (/* binding */ clearAzureSecretsCache),
/* harmony export */   fetchAzureSecrets: () => (/* binding */ fetchAzureSecrets),
/* harmony export */   getAzureConfig: () => (/* binding */ getAzureConfig),
/* harmony export */   getConfiguration: () => (/* binding */ getConfiguration),
/* harmony export */   initializeAzureEnvironment: () => (/* binding */ initializeAzureEnvironment)
/* harmony export */ });
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10756);
/* harmony import */ var _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36695);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__]);
([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// Client-side safety check - provide empty implementations when running on client
const isClient = "undefined" !== 'undefined';
if (isClient) {
    console.warn('[Azure Config] Running on client side - using fallback implementations');
}
// Azure Key Vault configuration
const AZURE_KEY_VAULT_URI = process.env.AZURE_KEY_VAULT_URI || 'https://prepbettr-keyvault-083.vault.azure.net/';
let cachedSecrets = null;
/**
 * Initialize Azure Key Vault client
 */ function createKeyVaultClient() {
    if (!AZURE_KEY_VAULT_URI) {
        throw new Error('AZURE_KEY_VAULT_URI environment variable is required');
    }
    const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_0__.DefaultAzureCredential();
    return new _azure_keyvault_secrets__WEBPACK_IMPORTED_MODULE_1__.SecretClient(AZURE_KEY_VAULT_URI, credential);
}
/**
 * Clear cached secrets (useful when Azure keys are renewed)
 */ function clearAzureSecretsCache() {
    if (isClient) return;
    console.log('🔄 Clearing Azure secrets cache...');
    cachedSecrets = null;
}
/**
 * Fetch secrets from Azure Key Vault
 */ async function fetchAzureSecrets(forceRefresh = false) {
    if (isClient) {
        return {
            speechKey: '',
            speechEndpoint: '',
            azureOpenAIKey: '',
            azureOpenAIEndpoint: '',
            azureOpenAIDeployment: '',
            firebaseProjectId: '',
            firebaseClientEmail: '',
            firebasePrivateKey: ''
        };
    }
    // Clear cache if force refresh is requested
    if (forceRefresh) {
        clearAzureSecretsCache();
    }
    // Return cached secrets if available
    if (cachedSecrets) {
        return cachedSecrets;
    }
    try {
        console.log('🔑 Fetching secrets from Azure Key Vault...');
        const client = createKeyVaultClient();
        // Helper function to suppress expected 404 errors for optional secrets
        const getOptionalSecret = (name)=>client.getSecret(name).catch((err)=>{
                if (err.statusCode !== 404) {
                    console.warn(`⚠️ Unexpected error fetching optional secret '${name}':`, err.message);
                }
                return null;
            });
        // Fetch all secrets (some are optional)
        const [speechKey, speechEndpoint, azureOpenAIKey, azureOpenAIEndpoint, azureOpenAIDeployment, firebaseProjectId, firebaseClientEmail, firebasePrivateKey, firebaseClientKey, azureFormRecognizerKey, azureFormRecognizerEndpoint, azureStorageAccount, azureStorageAccountKey, azureStorageConnectionString, azureStorageContainer, storageProvider] = await Promise.all([
            client.getSecret('speech-key'),
            client.getSecret('speech-endpoint'),
            client.getSecret('azure-openai-key'),
            client.getSecret('azure-openai-endpoint'),
            client.getSecret('azure-openai-deployment'),
            getOptionalSecret('firebase-project-id'),
            getOptionalSecret('firebase-client-email'),
            getOptionalSecret('firebase-private-key'),
            getOptionalSecret('NEXT-PUBLIC-FIREBASE-CLIENT-KEY'),
            getOptionalSecret('azure-form-recognizer-key'),
            getOptionalSecret('azure-form-recognizer-endpoint'),
            getOptionalSecret('azure-storage-account'),
            getOptionalSecret('azure-storage-account-key'),
            getOptionalSecret('azure-storage-connection-string'),
            getOptionalSecret('azure-storage-container'),
            getOptionalSecret('storage-provider')
        ]);
        // Validate only Azure-related secrets (Firebase can come from env vars)
        const requiredAzureSecrets = {
            speechKey: speechKey?.value,
            speechEndpoint: speechEndpoint?.value,
            azureOpenAIKey: azureOpenAIKey?.value,
            azureOpenAIEndpoint: azureOpenAIEndpoint?.value,
            azureOpenAIDeployment: azureOpenAIDeployment?.value
        };
        const missingAzureSecrets = Object.entries(requiredAzureSecrets).filter(([_, value])=>!value).map(([key, _])=>key);
        if (missingAzureSecrets.length > 0) {
            throw new Error(`Required Azure secrets missing from Key Vault: ${missingAzureSecrets.join(', ')}`);
        }
        cachedSecrets = {
            speechKey: speechKey.value,
            speechEndpoint: speechEndpoint.value,
            azureOpenAIKey: azureOpenAIKey.value,
            azureOpenAIEndpoint: azureOpenAIEndpoint.value,
            azureOpenAIDeployment: azureOpenAIDeployment.value,
            firebaseProjectId: firebaseProjectId?.value || process.env.FIREBASE_PROJECT_ID || '',
            firebaseClientEmail: firebaseClientEmail?.value || process.env.FIREBASE_CLIENT_EMAIL || '',
            firebasePrivateKey: firebasePrivateKey?.value || process.env.FIREBASE_PRIVATE_KEY || '',
            firebaseClientKey: firebaseClientKey?.value || '',
            azureFormRecognizerKey: azureFormRecognizerKey?.value,
            azureFormRecognizerEndpoint: azureFormRecognizerEndpoint?.value,
            azureStorageAccount: azureStorageAccount?.value,
            azureStorageAccountKey: azureStorageAccountKey?.value,
            azureStorageConnectionString: azureStorageConnectionString?.value,
            azureStorageContainer: azureStorageContainer?.value,
            storageProvider: storageProvider?.value
        };
        console.log('✅ Azure secrets loaded successfully');
        return cachedSecrets;
    } catch (error) {
        console.error('❌ Failed to fetch Azure secrets:', error);
        // Fallback to environment variables if Key Vault fails
        console.log('🔄 Falling back to environment variables...');
        const fallbackSecrets = {
            speechKey: process.env.AZURE_SPEECH_KEY || process.env.SPEECH_KEY || '',
            speechEndpoint: process.env.SPEECH_ENDPOINT || 'https://eastus2.api.cognitive.microsoft.com/',
            azureOpenAIKey: process.env.AZURE_OPENAI_API_KEY || process.env.AZURE_OPENAI_KEY || '',
            azureOpenAIEndpoint: process.env.AZURE_OPENAI_ENDPOINT || '',
            azureOpenAIDeployment: process.env.AZURE_OPENAI_DEPLOYMENT || '',
            // Firebase fallbacks
            firebaseProjectId: process.env.FIREBASE_PROJECT_ID || '',
            firebaseClientEmail: process.env.FIREBASE_CLIENT_EMAIL || '',
            firebasePrivateKey: process.env.FIREBASE_PRIVATE_KEY || '',
            firebaseClientKey: '',
            // Optional fallbacks
            azureFormRecognizerKey: process.env.AZURE_FORM_RECOGNIZER_KEY,
            azureFormRecognizerEndpoint: process.env.AZURE_FORM_RECOGNIZER_ENDPOINT,
            azureStorageAccount: process.env.AZURE_STORAGE_ACCOUNT_NAME,
            azureStorageAccountKey: process.env.AZURE_STORAGE_ACCOUNT_KEY
        };
        // Only warn about critical missing secrets
        const missingCritical = [];
        if (!fallbackSecrets.speechKey) missingCritical.push('SPEECH_KEY');
        if (!fallbackSecrets.azureOpenAIKey) missingCritical.push('AZURE_OPENAI_KEY');
        // Only warn about missing optional secrets if not available from environment
        const missingOptional = [];
        if (!fallbackSecrets.firebaseProjectId && !process.env.FIREBASE_PROJECT_ID) missingOptional.push('FIREBASE_PROJECT_ID');
        if (missingCritical.length > 0) {
            console.error(`❌ Critical secrets missing: ${missingCritical.join(', ')}`);
        }
        if (missingOptional.length > 0) {
            console.warn(`⚠️ Optional secrets missing: ${missingOptional.join(', ')}`);
        }
        cachedSecrets = fallbackSecrets;
        return cachedSecrets;
    }
}
/**
 * Initialize environment variables from Azure Key Vault
 * This should be called at application startup
 */ async function initializeAzureEnvironment() {
    if (isClient) return;
    try {
        const secrets = await fetchAzureSecrets();
        // Set Azure service environment variables
        process.env.SPEECH_KEY = secrets.speechKey;
        process.env.SPEECH_ENDPOINT = secrets.speechEndpoint;
        // Set Azure OpenAI environment variables
        process.env.AZURE_OPENAI_KEY = secrets.azureOpenAIKey;
        process.env.AZURE_OPENAI_ENDPOINT = secrets.azureOpenAIEndpoint;
        process.env.AZURE_OPENAI_DEPLOYMENT = secrets.azureOpenAIDeployment;
        // Set Firebase environment variables
        process.env.FIREBASE_PROJECT_ID = secrets.firebaseProjectId;
        process.env.FIREBASE_CLIENT_EMAIL = secrets.firebaseClientEmail;
        process.env.FIREBASE_PRIVATE_KEY = secrets.firebasePrivateKey;
        // Set client-side environment variables using string concatenation to avoid Next.js inlining
        const nextPublicPrefix = 'NEXT_PUBLIC_';
        process.env[nextPublicPrefix + 'SPEECH_KEY'] = secrets.speechKey;
        process.env[nextPublicPrefix + 'SPEECH_ENDPOINT'] = secrets.speechEndpoint;
        process.env[nextPublicPrefix + 'AZURE_OPENAI_API_KEY'] = secrets.azureOpenAIKey;
        process.env[nextPublicPrefix + 'AZURE_OPENAI_ENDPOINT'] = secrets.azureOpenAIEndpoint;
        process.env[nextPublicPrefix + 'AZURE_OPENAI_DEPLOYMENT'] = secrets.azureOpenAIDeployment;
        process.env[nextPublicPrefix + 'FIREBASE_PROJECT_ID'] = secrets.firebaseProjectId;
        // Set the Firebase client key from secrets or environment
        if (secrets.firebaseClientKey) {
            process.env[nextPublicPrefix + 'FIREBASE_CLIENT_KEY'] = secrets.firebaseClientKey;
            console.log('🔑 Firebase client key set from Azure Key Vault');
        } else {
            console.warn('⚠️ Firebase client key not found in Azure Key Vault');
        }
        // Set optional Azure services if available
        if (secrets.azureFormRecognizerKey) {
            process.env.AZURE_FORM_RECOGNIZER_KEY = secrets.azureFormRecognizerKey;
        }
        if (secrets.azureFormRecognizerEndpoint) {
            process.env.AZURE_FORM_RECOGNIZER_ENDPOINT = secrets.azureFormRecognizerEndpoint;
        }
        // Set storage configuration
        if (secrets.azureStorageAccount) {
            process.env.AZURE_STORAGE_ACCOUNT = secrets.azureStorageAccount;
        }
        if (secrets.azureStorageAccountKey) {
            process.env.AZURE_STORAGE_ACCOUNT_KEY = secrets.azureStorageAccountKey;
        }
        if (secrets.azureStorageConnectionString) {
            process.env.AZURE_STORAGE_CONNECTION_STRING = secrets.azureStorageConnectionString;
        }
        if (secrets.azureStorageContainer) {
            process.env.AZURE_STORAGE_CONTAINER = secrets.azureStorageContainer;
        }
        if (secrets.storageProvider) {
            process.env.STORAGE_PROVIDER = secrets.storageProvider;
        }
        console.log('🌟 Azure environment initialized successfully');
    } catch (error) {
        console.error('❌ Failed to initialize Azure environment:', error);
        throw error;
    }
}
/**
 * Get generic configuration values (used by storage abstraction and other services)
 */ async function getConfiguration() {
    try {
        const secrets = await fetchAzureSecrets();
        return {
            // Azure Storage configuration
            'AZURE_STORAGE_ACCOUNT': secrets.azureStorageAccount || process.env.AZURE_STORAGE_ACCOUNT || 'prepbettrstorage684',
            'AZURE_STORAGE_ACCOUNT_KEY': secrets.azureStorageAccountKey || process.env.AZURE_STORAGE_ACCOUNT_KEY || '',
            'AZURE_STORAGE_CONNECTION_STRING': secrets.azureStorageConnectionString || process.env.AZURE_STORAGE_CONNECTION_STRING || '',
            'AZURE_STORAGE_CONTAINER': secrets.azureStorageContainer || process.env.AZURE_STORAGE_CONTAINER || 'resumes',
            'STORAGE_PROVIDER': secrets.storageProvider || process.env.STORAGE_PROVIDER || 'firebase',
            // Azure AI services
            'AZURE_OPENAI_KEY': secrets.azureOpenAIKey,
            'AZURE_OPENAI_ENDPOINT': secrets.azureOpenAIEndpoint,
            'AZURE_OPENAI_DEPLOYMENT': secrets.azureOpenAIDeployment,
            'AZURE_SPEECH_KEY': secrets.speechKey,
            'AZURE_SPEECH_ENDPOINT': secrets.speechEndpoint,
            'AZURE_FORM_RECOGNIZER_KEY': secrets.azureFormRecognizerKey || '',
            'AZURE_FORM_RECOGNIZER_ENDPOINT': secrets.azureFormRecognizerEndpoint || '',
            // Firebase configuration
            'FIREBASE_PROJECT_ID': secrets.firebaseProjectId,
            'FIREBASE_CLIENT_EMAIL': secrets.firebaseClientEmail,
            'FIREBASE_PRIVATE_KEY': secrets.firebasePrivateKey,
            'FIREBASE_CLIENT_KEY': secrets.firebaseClientKey || ''
        };
    } catch (error) {
        console.warn('Failed to get configuration from Azure, using environment variables:', error);
        // Fallback to environment variables only
        return {
            'AZURE_STORAGE_ACCOUNT': process.env.AZURE_STORAGE_ACCOUNT || 'prepbettrstorage684',
            'AZURE_STORAGE_ACCOUNT_KEY': process.env.AZURE_STORAGE_ACCOUNT_KEY || '',
            'AZURE_STORAGE_CONNECTION_STRING': process.env.AZURE_STORAGE_CONNECTION_STRING || '',
            'AZURE_STORAGE_CONTAINER': process.env.AZURE_STORAGE_CONTAINER || 'resumes',
            'STORAGE_PROVIDER': process.env.STORAGE_PROVIDER || 'firebase',
            'AZURE_OPENAI_KEY': process.env.AZURE_OPENAI_KEY || '',
            'AZURE_OPENAI_ENDPOINT': process.env.AZURE_OPENAI_ENDPOINT || '',
            'AZURE_OPENAI_DEPLOYMENT': process.env.AZURE_OPENAI_DEPLOYMENT || '',
            'AZURE_SPEECH_KEY': process.env.AZURE_SPEECH_KEY || process.env.SPEECH_KEY || '',
            'AZURE_SPEECH_ENDPOINT': process.env.SPEECH_ENDPOINT || '',
            'AZURE_FORM_RECOGNIZER_KEY': process.env.AZURE_FORM_RECOGNIZER_KEY || '',
            'AZURE_FORM_RECOGNIZER_ENDPOINT': process.env.AZURE_FORM_RECOGNIZER_ENDPOINT || '',
            'FIREBASE_PROJECT_ID': process.env.FIREBASE_PROJECT_ID || '',
            'FIREBASE_CLIENT_EMAIL': process.env.FIREBASE_CLIENT_EMAIL || '',
            'FIREBASE_PRIVATE_KEY': process.env.FIREBASE_PRIVATE_KEY || '',
            // Use string concatenation to avoid Next.js inlining
            'FIREBASE_CLIENT_KEY': process.env['NEXT_PUBLIC_' + 'FIREBASE_CLIENT_KEY'] || ''
        };
    }
}
/**
 * Get current Azure configuration (for debugging)
 */ function getAzureConfig() {
    const nextPublicPrefix = 'NEXT_PUBLIC_';
    return {
        keyVaultUri: AZURE_KEY_VAULT_URI,
        hasSecretsCache: !!cachedSecrets,
        environment: {
            speechKey: !!process.env[nextPublicPrefix + 'SPEECH_KEY'],
            speechEndpoint: !!process.env[nextPublicPrefix + 'SPEECH_ENDPOINT'],
            azureOpenAIKey: !!process.env.AZURE_OPENAI_KEY,
            azureOpenAIEndpoint: !!process.env.AZURE_OPENAI_ENDPOINT,
            azureOpenAIDeployment: !!process.env.AZURE_OPENAI_DEPLOYMENT
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 97186:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VZ: () => (/* binding */ getAdminFirestore),
/* harmony export */   Y0: () => (/* binding */ verifyIdToken)
/* harmony export */ });
/* unused harmony exports getAdminAuth, getAdminRemoteConfig, getDBService */
/**
 * Firebase Admin SDK Configuration
 * 
 * Real Firebase Admin SDK implementation with Azure Key Vault integration
 */ // Client-side safety check
const isClient = "undefined" !== 'undefined';
if (isClient) {
    console.warn('[Firebase Admin] Running on client side - using fallback implementations');
}
// Only import server-side dependencies when running on server
let admin = null;
let getConfiguration = null;
if (!isClient) {
    admin = __webpack_require__(46675);
    try {
        const azureConfig = __webpack_require__(73905);
        getConfiguration = azureConfig.getConfiguration;
    } catch (error) {
        console.warn('🔥 Failed to import azure-config, getConfiguration will be undefined:', error);
        getConfiguration = null;
    }
}
// Global Firebase Admin app instance
let adminApp = null;
let adminAuth = null;
/**
 * Initialize Firebase Admin SDK
 */ async function initializeFirebaseAdmin() {
    if (isClient) {
        throw new Error('Firebase Admin SDK not available on client side');
    }
    if (adminApp) {
        return adminApp;
    }
    try {
        console.log('🔥 Starting Firebase Admin SDK initialization...');
        // Check if Firebase Admin is already initialized
        const existingApps = admin.apps;
        if (existingApps.length > 0) {
            console.log('🔥 Found existing Firebase Admin app, reusing...');
            adminApp = existingApps[0];
            return adminApp;
        }
        // Get Firebase configuration from Azure Key Vault or environment variables
        let config = {};
        try {
            if (getConfiguration && typeof getConfiguration === 'function') {
                config = await getConfiguration();
            } else {
                console.warn('🔥 getConfiguration not available, using environment variables directly');
            }
        } catch (configError) {
            console.warn('🔥 Failed to get config from Azure, using environment variables:', configError);
            config = {};
        }
        const firebaseConfig = {
            projectId: config['FIREBASE_PROJECT_ID'] || process.env.FIREBASE_PROJECT_ID || "prepbettr" || 0,
            clientEmail: config['FIREBASE_CLIENT_EMAIL'] || process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: config['FIREBASE_PRIVATE_KEY'] || process.env.FIREBASE_PRIVATE_KEY
        };
        console.log('🔥 Firebase config loaded:', {
            projectId: firebaseConfig.projectId,
            hasClientEmail: !!firebaseConfig.clientEmail,
            hasPrivateKey: !!firebaseConfig.privateKey && firebaseConfig.privateKey.length > 0
        });
        // Validate project ID
        if (!firebaseConfig.projectId || firebaseConfig.projectId === 'prepbettr') {
            console.warn('🔥 Using default project ID - this may cause authentication issues');
        }
        // Initialize Firebase Admin SDK
        if (firebaseConfig.clientEmail && firebaseConfig.privateKey) {
            console.log('🔥 Initializing with service account credentials...');
            // Clean up private key format (handle escaped newlines)
            let cleanPrivateKey = firebaseConfig.privateKey;
            if (cleanPrivateKey.includes('\\n')) {
                cleanPrivateKey = cleanPrivateKey.replace(/\\n/g, '\n');
            }
            // Validate private key format
            if (!cleanPrivateKey.includes('-----BEGIN PRIVATE KEY-----')) {
                throw new Error('Invalid private key format - missing BEGIN marker');
            }
            if (!cleanPrivateKey.includes('-----END PRIVATE KEY-----')) {
                throw new Error('Invalid private key format - missing END marker');
            }
            adminApp = admin.initializeApp({
                credential: admin.credential.cert({
                    projectId: firebaseConfig.projectId,
                    clientEmail: firebaseConfig.clientEmail,
                    privateKey: cleanPrivateKey
                }),
                projectId: firebaseConfig.projectId
            });
        } else {
            console.warn('🔥 Missing service account credentials, initializing with project ID only');
            adminApp = admin.initializeApp({
                projectId: firebaseConfig.projectId
            });
        }
        console.log('🔥 Firebase Admin SDK initialized successfully');
        return adminApp;
    } catch (error) {
        console.error('🔥 Failed to initialize Firebase Admin SDK:', error);
        // Create a minimal fallback for development
        console.warn('🔥 Creating minimal fallback Firebase Admin instance');
        try {
            // Use the default project ID as fallback
            const fallbackProjectId = "prepbettr" || 0 || 0;
            adminApp = admin.initializeApp({
                projectId: fallbackProjectId
            });
            console.log('🔥 Fallback Firebase Admin instance created');
            return adminApp;
        } catch (fallbackError) {
            console.error('🔥 Failed to create fallback Firebase Admin instance:', fallbackError);
            throw new Error(`Firebase Admin SDK initialization completely failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
}
/**
 * Get Firebase Admin Auth instance
 */ async function getAdminAuth() {
    if (isClient) {
        throw new Error('Firebase Admin SDK not available on client side');
    }
    if (adminAuth) {
        return adminAuth;
    }
    const app = await initializeFirebaseAdmin();
    adminAuth = admin.auth(app);
    return adminAuth;
}
async function getAdminFirestore() {
    if (isClient) {
        throw new Error('Firebase Admin SDK not available on client side');
    }
    // Get or initialize the Firebase Admin app
    const app = await initializeFirebaseAdmin();
    // Return the real Firestore instance
    return admin.firestore(app);
}
async function getAdminRemoteConfig() {
    if (isClient) {
        throw new Error('Firebase Admin SDK not available on client side');
    }
    return {
        getTemplate: async ()=>({
                parameters: {}
            }),
        publishTemplate: async ()=>{},
        getParameter: async ()=>({
                defaultValue: null
            }),
        setParameter: async ()=>{}
    };
}
async function verifyIdToken(token) {
    if (isClient) {
        throw new Error('Firebase Admin SDK not available on client side');
    }
    console.warn('Firebase Admin verifyIdToken deprecated - use unified auth system');
    return {
        uid: 'mock-user-id',
        email: 'mock@example.com'
    };
}
async function getDBService() {
    return getAdminFirestore();
}


/***/ })

};
;