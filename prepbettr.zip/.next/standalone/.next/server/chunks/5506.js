"use strict";
exports.id = 5506;
exports.ids = [5506];
exports.modules = {

/***/ 7839:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   e: () => (/* binding */ FoundryModelManager)
/* harmony export */ });
/* harmony import */ var _config_foundry_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(22082);
/* harmony import */ var _clients_foundry_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20809);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_foundry_config__WEBPACK_IMPORTED_MODULE_0__, _clients_foundry_client__WEBPACK_IMPORTED_MODULE_1__]);
([_config_foundry_config__WEBPACK_IMPORTED_MODULE_0__, _clients_foundry_client__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure AI Foundry Model Manager
 * 
 * Handles model configurations, deployments, cost tracking, and model selection logic.
 * Provides utilities for managing multiple models and their configurations.
 */ 

/**
 * FoundryModelManager class for managing model configurations and usage
 */ class FoundryModelManager extends _clients_foundry_client__WEBPACK_IMPORTED_MODULE_1__/* .FoundryClientBase */ .K {
    constructor(){
        super(), this.usageHistory = [], this.deployments = new Map();
    }
    /**
   * Get all available model configurations
   */ getAvailableModels() {
        return this.config?.models || {};
    }
    /**
   * Get model configuration by name with fallback
   */ getModel(modelName) {
        return (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_0__/* .getModelConfig */ .Ac)(modelName);
    }
    /**
   * Get the default model configuration
   */ getDefaultModelConfig() {
        return (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_0__/* .getDefaultModel */ .fZ)();
    }
    /**
   * Select best model based on criteria
   */ selectModel(criteria = {}) {
        const models = this.getAvailableModels();
        const modelList = Object.values(models);
        // Start with preferred model if specified
        if (criteria.preferredModel && models[criteria.preferredModel]) {
            const preferred = models[criteria.preferredModel];
            if (this.modelMeetsCriteria(preferred, criteria)) {
                return preferred;
            }
        }
        // Try fallback models
        if (criteria.fallbackModels) {
            for (const fallbackName of criteria.fallbackModels){
                const fallback = models[fallbackName];
                if (fallback && this.modelMeetsCriteria(fallback, criteria)) {
                    return fallback;
                }
            }
        }
        // Filter models by criteria
        let candidates = modelList.filter((model)=>this.modelMeetsCriteria(model, criteria));
        // Sort by cost (ascending) and capabilities (descending)
        candidates = candidates.sort((a, b)=>{
            // Primary sort: cost
            const costDiff = a.costPerToken - b.costPerToken;
            if (Math.abs(costDiff) > 0.001) return costDiff;
            // Secondary sort: capabilities (more is better)
            return b.capabilities.length - a.capabilities.length;
        });
        // Return best candidate or default model
        return candidates[0] || this.getDefaultModelConfig();
    }
    /**
   * Check if model meets selection criteria
   */ modelMeetsCriteria(model, criteria) {
        // Check cost constraint
        if (criteria.maxCost !== undefined && model.costPerToken > criteria.maxCost) {
            return false;
        }
        // Check capabilities
        if (criteria.requiredCapabilities) {
            const hasAllCapabilities = criteria.requiredCapabilities.every((capability)=>model.capabilities.includes(capability));
            if (!hasAllCapabilities) {
                return false;
            }
        }
        // Note: maxLatency check would require historical performance data
        // This could be implemented by tracking actual response times
        return true;
    }
    /**
   * Track usage for a model request
   */ trackUsage({ modelName, tokenUsage, latency, success, errorCode }) {
        const model = this.getModel(modelName);
        if (!model) {
            console.warn(`[ModelManager] Unknown model for usage tracking: ${modelName}`);
            return;
        }
        const cost = tokenUsage.total_tokens / 1000 * model.costPerToken;
        const entry = {
            modelName,
            timestamp: new Date().toISOString(),
            promptTokens: tokenUsage.prompt_tokens,
            completionTokens: tokenUsage.completion_tokens,
            totalTokens: tokenUsage.total_tokens,
            cost,
            latency,
            success,
            errorCode
        };
        this.usageHistory.push(entry);
        // Keep only last 1000 entries to prevent memory bloat
        if (this.usageHistory.length > 1000) {
            this.usageHistory = this.usageHistory.slice(-1000);
        }
    }
    /**
   * Get performance metrics for a specific model
   */ getModelMetrics(modelName, timeRangeHours = 24) {
        const cutoff = Date.now() - timeRangeHours * 60 * 60 * 1000;
        const entries = this.usageHistory.filter((entry)=>entry.modelName === modelName && new Date(entry.timestamp).getTime() >= cutoff);
        if (entries.length === 0) {
            return {
                averageLatency: 0,
                successRate: 0,
                totalCost: 0,
                totalTokens: 0,
                requestCount: 0,
                costPerToken: 0,
                tokensPerSecond: 0
            };
        }
        const totalLatency = entries.reduce((sum, e)=>sum + e.latency, 0);
        const successCount = entries.filter((e)=>e.success).length;
        const totalCost = entries.reduce((sum, e)=>sum + e.cost, 0);
        const totalTokens = entries.reduce((sum, e)=>sum + e.totalTokens, 0);
        const totalTime = totalLatency / 1000; // convert to seconds
        return {
            averageLatency: totalLatency / entries.length,
            successRate: successCount / entries.length,
            totalCost,
            totalTokens,
            requestCount: entries.length,
            costPerToken: totalTokens > 0 ? totalCost / totalTokens * 1000 : 0,
            tokensPerSecond: totalTime > 0 ? totalTokens / totalTime : 0
        };
    }
    /**
   * Get usage statistics for all models
   */ getUsageStatistics(timeRangeHours = 24) {
        const cutoff = Date.now() - timeRangeHours * 60 * 60 * 1000;
        const entries = this.usageHistory.filter((entry)=>new Date(entry.timestamp).getTime() >= cutoff);
        const breakdown = {};
        const modelStats = new Map();
        entries.forEach((entry)=>{
            const stats = modelStats.get(entry.modelName) || {
                requests: 0,
                tokens: 0,
                errors: 0,
                latency: 0
            };
            stats.requests += 1;
            stats.tokens += entry.totalTokens;
            stats.errors += entry.success ? 0 : 1;
            stats.latency += entry.latency;
            modelStats.set(entry.modelName, stats);
        });
        modelStats.forEach((stats, modelName)=>{
            breakdown[modelName] = {
                requests: stats.requests,
                tokens: stats.tokens,
                errors: stats.errors
            };
        });
        const totalRequests = entries.length;
        const totalTokens = entries.reduce((sum, e)=>sum + e.totalTokens, 0);
        const totalErrors = entries.filter((e)=>!e.success).length;
        const totalLatency = entries.reduce((sum, e)=>sum + e.latency, 0);
        return {
            totalRequests,
            totalTokens,
            averageLatency: totalRequests > 0 ? totalLatency / totalRequests : 0,
            errorRate: totalRequests > 0 ? totalErrors / totalRequests : 0,
            timeRange: {
                start: new Date(cutoff).toISOString(),
                end: new Date().toISOString()
            },
            breakdown
        };
    }
    /**
   * Get cost estimate for a request
   */ estimateCost(modelName, estimatedTokens) {
        const model = this.getModel(modelName);
        if (!model) {
            console.warn(`[ModelManager] Unknown model for cost estimation: ${modelName}`);
            return 0;
        }
        return estimatedTokens / 1000 * model.costPerToken;
    }
    /**
   * List models sorted by cost efficiency
   */ getModelsByCostEfficiency() {
        const models = Object.values(this.getAvailableModels());
        return models.sort((a, b)=>a.costPerToken - b.costPerToken);
    }
    /**
   * Get models by capability
   */ getModelsByCapability(capability) {
        const models = Object.values(this.getAvailableModels());
        return models.filter((model)=>model.capabilities.includes(capability));
    }
    /**
   * Clear usage history (for testing or privacy)
   */ clearUsageHistory() {
        this.usageHistory = [];
        console.log('[ModelManager] Usage history cleared');
    }
    /**
   * Export usage history for external analysis
   */ exportUsageHistory() {
        return [
            ...this.usageHistory
        ]; // Return copy
    }
    /**
   * Get recommended model for specific use case
   */ getRecommendedModel(useCase) {
        const useCaseMap = {
            interview: {
                requiredCapabilities: [
                    'text-generation',
                    'reasoning'
                ],
                maxCost: 0.01,
                preferredModel: 'gpt-4o'
            },
            'code-generation': {
                requiredCapabilities: [
                    'code-generation',
                    'reasoning'
                ],
                preferredModel: 'gpt-4-turbo'
            },
            reasoning: {
                requiredCapabilities: [
                    'reasoning'
                ],
                preferredModel: 'gpt-4o'
            },
            lightweight: {
                maxCost: 0.002,
                preferredModel: 'phi-4',
                fallbackModels: [
                    'gpt-4o'
                ]
            }
        };
        const criteria = useCaseMap[useCase] || {};
        return this.selectModel(criteria);
    }
    /**
   * Health check for model availability
   */ async checkModelHealth(modelName) {
        const model = this.getModel(modelName);
        if (!model) {
            return {
                available: false,
                error: 'Model not found in configuration'
            };
        }
        try {
            const start = Date.now();
            // Simple health check with minimal prompt
            await this.request('/models/health-check', {
                method: 'POST',
                body: {
                    model: model.deploymentName,
                    prompt: 'test',
                    max_tokens: 1
                }
            });
            const latency = Date.now() - start;
            return {
                available: true,
                latency
            };
        } catch (error) {
            return {
                available: false,
                error: error.message || 'Health check failed'
            };
        }
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 20809:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   K: () => (/* binding */ FoundryClientBase)
/* harmony export */ });
/* harmony import */ var node_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(97294);
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10756);
/* harmony import */ var _azure_ai_projects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60746);
/* harmony import */ var _azure_ai_agents__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(11969);
/* harmony import */ var _config_foundry_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22082);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_identity__WEBPACK_IMPORTED_MODULE_1__, _azure_ai_projects__WEBPACK_IMPORTED_MODULE_2__, _config_foundry_config__WEBPACK_IMPORTED_MODULE_4__]);
([_azure_identity__WEBPACK_IMPORTED_MODULE_1__, _azure_ai_projects__WEBPACK_IMPORTED_MODULE_2__, _config_foundry_config__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// Client-side safety check
const isClient = "undefined" !== 'undefined';
if (isClient) {
    console.warn('[Azure AI Foundry Client] Running on client side - clients will not be initialized');
}
/**
 * Unified Azure AI Foundry Client
 * 
 * Combines HTTP request functionality with Azure SDK client factories.
 * Provides both low-level request() method and high-level SDK helpers.
 */ class FoundryClientBase {
    constructor(){
        this.projectsClientInstance = null;
        this.agentsClientInstance = null;
        this.currentSdkConfig = null;
    }
    /**
   * Initialize configuration
   */ async init(forceRefresh = false) {
        this.config = await (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_4__/* .getFoundryConfig */ .at)(forceRefresh);
        const { isValid, errors } = (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_4__/* .validateFoundryConfig */ .I6)(this.config);
        if (!isValid) {
            throw new Error(`Invalid Foundry configuration: ${errors.join(', ')}`);
        }
    }
    /**
   * Build default headers with API key
   */ buildHeaders(extra) {
        return {
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': this.config.apiKey,
            'User-Agent': 'PrepBettr/FoundryClient',
            ...extra || {}
        };
    }
    /**
   * Core request helper with retry logic based on connection settings
   */ async request(path, options = {}) {
        const baseUrl = this.config.endpoint.replace(/\/$/, '');
        const url = `${baseUrl}${path.startsWith('/') ? '' : '/'}${path}`;
        const { connection } = this.config;
        const method = options.method || 'GET';
        const headers = this.buildHeaders(options.headers);
        const body = options.body ? JSON.stringify(options.body) : undefined;
        let attempt = 0;
        const max = connection.retryPolicy.maxRetries;
        const start = Date.now();
        while(true){
            try {
                const controller = new AbortController();
                const timeout = setTimeout(()=>controller.abort(), connection.timeout);
                const res = await (0,node_fetch__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Ay)(url, {
                    method,
                    headers,
                    body,
                    // @ts-ignore node-fetch v2 compatibility
                    signal: controller.signal
                });
                clearTimeout(timeout);
                const raw = await res.text();
                let data = null;
                try {
                    data = raw ? JSON.parse(raw) : null;
                } catch  {
                // non-JSON response
                }
                if (!res.ok && this.shouldRetry(res.status) && attempt < max) {
                    attempt++;
                    await this.delay(this.backoff(attempt, connection));
                    continue;
                }
                return {
                    status: res.status,
                    data,
                    raw
                };
            } catch (err) {
                // AbortError / network errors
                if (attempt < max) {
                    attempt++;
                    await this.delay(this.backoff(attempt, connection));
                    continue;
                }
                throw new Error(`Foundry request failed after ${attempt} retries: ${err?.message || err}`);
            } finally{
                // Optional: log slow requests
                const elapsed = Date.now() - start;
                if (elapsed > Math.max(2000, this.config.connection.timeout)) {
                    // eslint-disable-next-line no-console
                    console.warn(`[FoundryClient] Slow request ${method} ${url} took ${elapsed}ms`);
                }
            }
        }
    }
    /**
   * Basic retry policy on transient status codes
   */ shouldRetry(status) {
        return [
            408,
            409,
            429,
            500,
            502,
            503,
            504
        ].includes(status);
    }
    /**
   * Exponential backoff with optional jitter
   */ backoff(attempt, conn) {
        const { baseDelay, maxDelay, exponentialBase, jitter } = conn.retryPolicy;
        const delay = Math.min(maxDelay, baseDelay * Math.pow(exponentialBase, attempt - 1));
        return jitter ? Math.floor(Math.random() * delay) : delay;
    }
    delay(ms) {
        return new Promise((resolve)=>setTimeout(resolve, ms));
    }
    /**
   * Validate connectivity to Foundry endpoint
   */ async validateConnection() {
        if (!this.config) await this.init();
        try {
            const res = await this.request('/', {
                method: 'GET'
            });
            // Root might be 404 but still proves connectivity
            const ok = res.status < 500;
            return {
                ok,
                status: res.status
            };
        } catch (err) {
            return {
                ok: false,
                error: err?.message || String(err)
            };
        }
    }
    /**
   * Placeholder for text completion call via model inference.
   * Implement with specific Foundry Inference API once finalized.
   */ // eslint-disable-next-line @typescript-eslint/no-unused-vars
    async completeText(_prompt, _modelKey = 'gpt-4o') {
        throw new Error('completeText not implemented yet for Foundry Inference API');
    }
    /**
   * Azure SDK Client Methods
   */ /**
   * Create Azure AI Projects client with proper authentication
   */ createProjectsClient(config) {
        if (isClient) {
            throw new Error('Projects client cannot be initialized on client side');
        }
        try {
            const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_1__.DefaultAzureCredential();
            console.log(`🔧 Creating Azure AI Projects client for endpoint: ${config.endpoint}`);
            const client = new _azure_ai_projects__WEBPACK_IMPORTED_MODULE_2__/* .AIProjectClient */ .b(config.endpoint, credential, {
                additionalPolicies: [
                    {
                        policy: {
                            name: 'PrepBettrUserAgent',
                            sendRequest: async (request, next)=>{
                                const existingUserAgent = request.headers.get('User-Agent') || '';
                                request.headers.set('User-Agent', `PrepBettr/1.0 ${existingUserAgent}`);
                                return next(request);
                            }
                        },
                        position: 'perCall'
                    }
                ],
                retryOptions: {
                    maxRetries: 3,
                    retryDelayInMs: 1000
                }
            });
            console.log('✅ Azure AI Projects client created successfully');
            return client;
        } catch (error) {
            console.error('❌ Failed to create Azure AI Projects client:', error);
            throw error;
        }
    }
    /**
   * Create Azure AI Agents client with proper authentication
   */ createAgentsClient(config) {
        if (isClient) {
            throw new Error('Agents client cannot be initialized on client side');
        }
        try {
            const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_1__.DefaultAzureCredential();
            console.log(`🤖 Creating Azure AI Agents client for project: ${config.projectId}`);
            const client = new _azure_ai_agents__WEBPACK_IMPORTED_MODULE_3__/* .AgentsClient */ .Iv(config.endpoint, credential, {
                additionalPolicies: [
                    {
                        policy: {
                            name: 'PrepBettrAgentUserAgent',
                            sendRequest: async (request, next)=>{
                                const existingUserAgent = request.headers.get('User-Agent') || '';
                                request.headers.set('User-Agent', `PrepBettr-Agent/1.0 ${existingUserAgent}`);
                                if (config.projectId) {
                                    request.headers.set('X-Project-Id', config.projectId);
                                }
                                return next(request);
                            }
                        },
                        position: 'perCall'
                    }
                ],
                retryOptions: {
                    maxRetries: 3,
                    retryDelayInMs: 1000
                }
            });
            console.log('✅ Azure AI Agents client created successfully');
            return client;
        } catch (error) {
            console.error('❌ Failed to create Azure AI Agents client:', error);
            throw error;
        }
    }
    /**
   * Get or create Azure AI Projects client (singleton pattern)
   */ async getProjectsClient(forceRefresh = false) {
        if (isClient) {
            throw new Error('Projects client is not available on client side');
        }
        const config = await (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_4__/* .getFoundryConfig */ .at)(forceRefresh);
        if (forceRefresh || !this.projectsClientInstance || !this.currentSdkConfig || this.currentSdkConfig.endpoint !== config.endpoint || this.currentSdkConfig.apiKey !== config.apiKey) {
            console.log('🔄 Creating new Azure AI Projects client instance...');
            this.projectsClientInstance = this.createProjectsClient(config);
            this.currentSdkConfig = {
                ...config
            };
        }
        return this.projectsClientInstance;
    }
    /**
   * Get or create Azure AI Agents client (singleton pattern)
   */ async getAgentsClient(forceRefresh = false) {
        if (isClient) {
            throw new Error('Agents client is not available on client side');
        }
        const config = await (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_4__/* .getFoundryConfig */ .at)(forceRefresh);
        if (forceRefresh || !this.agentsClientInstance || !this.currentSdkConfig || this.currentSdkConfig.endpoint !== config.endpoint || this.currentSdkConfig.apiKey !== config.apiKey) {
            console.log('🔄 Creating new Azure AI Agents client instance...');
            this.agentsClientInstance = this.createAgentsClient(config);
            this.currentSdkConfig = {
                ...config
            };
        }
        return this.agentsClientInstance;
    }
    /**
   * Test connection to Azure AI Foundry services
   */ async testFoundryConnection() {
        if (isClient) {
            console.warn('⚠️ Cannot test foundry connection on client side');
            return false;
        }
        try {
            console.log('🔍 Testing Azure AI Foundry connection...');
            const client = await this.getProjectsClient();
            // TODO: Add actual connection test based on Azure AI Projects SDK
            console.log('✅ Azure AI Foundry connection test successful');
            return true;
        } catch (error) {
            console.error('❌ Azure AI Foundry connection test failed:', error);
            return false;
        }
    }
    /**
   * Clear SDK client instances (useful for testing or configuration updates)
   */ clearFoundryClients() {
        if (isClient) return;
        console.log('🔄 Clearing Azure AI Foundry client instances...');
        this.projectsClientInstance = null;
        this.agentsClientInstance = null;
        this.currentSdkConfig = null;
    }
    /**
   * Get current foundry configuration (for debugging)
   */ async getCurrentFoundryConfig() {
        if (isClient) {
            console.warn('⚠️ Cannot access foundry config on client side');
            return null;
        }
        try {
            return await (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_4__/* .getFoundryConfig */ .at)();
        } catch (error) {
            console.error('❌ Failed to get current foundry configuration:', error);
            return null;
        }
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 55506:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ag: () => (/* binding */ MigrationOpenAIClient)
/* harmony export */ });
/* unused harmony exports migrationOpenAIClient, OpenAI, OpenAIClient */
/* harmony import */ var _foundry_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20809);
/* harmony import */ var _managers_model_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7839);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_foundry_client__WEBPACK_IMPORTED_MODULE_0__, _managers_model_manager__WEBPACK_IMPORTED_MODULE_1__]);
([_foundry_client__WEBPACK_IMPORTED_MODULE_0__, _managers_model_manager__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure AI Foundry Migration Wrapper
 * 
 * Drop-in replacement for Azure OpenAI SDK that routes requests through
 * Azure AI Foundry while maintaining full API compatibility.
 * 
 * This allows for seamless migration from legacy OpenAI/Azure OpenAI clients
 * to the new Azure AI Foundry infrastructure without changing existing code.
 */ 

/**
 * Migration OpenAI Client
 * 
 * Provides full compatibility with OpenAI SDK while using Azure AI Foundry backend.
 * Includes cost tracking, usage monitoring, and intelligent model selection.
 */ class MigrationOpenAIClient extends _foundry_client__WEBPACK_IMPORTED_MODULE_0__/* .FoundryClientBase */ .K {
    constructor(){
        super(), this.isInitialized = false; // Call parent constructor
        this.modelManager = new _managers_model_manager__WEBPACK_IMPORTED_MODULE_1__/* .FoundryModelManager */ .e();
        // Create nested API structure to match OpenAI SDK exactly
        this.chat = {
            completions: {
                create: this.createChatCompletion.bind(this)
            }
        };
        this.completions = {
            create: this.createCompletion.bind(this)
        };
    }
    /**
   * Initialize the migration client
   */ async init() {
        if (this.isInitialized) return;
        await super.init(); // Call parent init
        await this.modelManager.init();
        this.isInitialized = true;
        console.log('✅ MigrationOpenAIClient initialized with Azure AI Foundry backend');
    }
    /**
   * Create chat completion (main method used by existing code)
   */ async createChatCompletion(params) {
        await this.ensureInitialized();
        const startTime = Date.now();
        const mappedModel = this.mapModel(params.model);
        const modelConfig = this.modelManager.getModel(mappedModel) || this.modelManager.getDefaultModelConfig();
        // Log cost estimation before the request
        const estimatedTokens = this.estimateTokens(params);
        const estimatedCost = estimatedTokens / 1000 * modelConfig.costPerToken;
        console.info(`[Cost] Estimated cost for ${mappedModel}: $${estimatedCost.toFixed(4)} (~${estimatedTokens} tokens)`);
        try {
            // Convert OpenAI request to Foundry request format
            const foundryRequest = {
                messages: params.messages,
                model: mappedModel,
                temperature: params.temperature ?? modelConfig.temperature,
                max_tokens: params.max_tokens ?? modelConfig.maxTokens,
                top_p: params.top_p ?? modelConfig.topP,
                frequency_penalty: params.frequency_penalty ?? modelConfig.frequencyPenalty,
                presence_penalty: params.presence_penalty ?? modelConfig.presencePenalty,
                stream: false,
                stop: params.stop,
                n: params.n ?? 1
            };
            // Make request through Foundry client (inherited method)
            const foundryResponse = await this.request(`/chat/completions`, {
                method: 'POST',
                body: foundryRequest
            });
            if (foundryResponse.status !== 200) {
                throw new Error(`Foundry API returned status ${foundryResponse.status}: ${foundryResponse.raw}`);
            }
            // Convert Foundry response to OpenAI format
            const openAIResponse = {
                id: foundryResponse.data?.id || `chatcmpl-${Date.now()}`,
                object: 'chat.completion',
                created: Math.floor(Date.now() / 1000),
                model: mappedModel,
                choices: foundryResponse.data?.choices?.map((choice, index)=>({
                        index,
                        message: {
                            role: choice.message?.role || 'assistant',
                            content: choice.message?.content || '',
                            function_call: choice.message?.function_call
                        },
                        finish_reason: choice.finish_reason || 'stop'
                    })) || [
                    {
                        index: 0,
                        message: {
                            role: 'assistant',
                            content: foundryResponse.data?.content || foundryResponse.raw
                        },
                        finish_reason: 'stop'
                    }
                ],
                usage: foundryResponse.data?.usage ? {
                    prompt_tokens: foundryResponse.data.usage.prompt_tokens || 0,
                    completion_tokens: foundryResponse.data.usage.completion_tokens || 0,
                    total_tokens: foundryResponse.data.usage.total_tokens || 0
                } : undefined
            };
            // Track usage metrics
            const latency = Date.now() - startTime;
            const actualUsage = openAIResponse.usage || {
                prompt_tokens: estimatedTokens * 0.7,
                completion_tokens: estimatedTokens * 0.3,
                total_tokens: estimatedTokens
            };
            this.modelManager.trackUsage({
                modelName: mappedModel,
                tokenUsage: actualUsage,
                latency,
                success: true
            });
            // Log actual cost
            const actualCost = actualUsage.total_tokens / 1000 * modelConfig.costPerToken;
            console.info(`[Cost] Actual cost for ${mappedModel}: $${actualCost.toFixed(4)} (${actualUsage.total_tokens} tokens, ${latency}ms)`);
            return openAIResponse;
        } catch (error) {
            // Track failed usage
            const latency = Date.now() - startTime;
            this.modelManager.trackUsage({
                modelName: mappedModel,
                tokenUsage: {
                    prompt_tokens: 0,
                    completion_tokens: 0,
                    total_tokens: 0
                },
                latency,
                success: false,
                errorCode: error.status?.toString() || 'UNKNOWN_ERROR'
            });
            console.error(`[Cost] Failed request for ${mappedModel} after ${latency}ms:`, error.message);
            throw error;
        }
    }
    /**
   * Create text completion (legacy method, less common but still used)
   */ async createCompletion(params) {
        await this.ensureInitialized();
        const startTime = Date.now();
        const mappedModel = this.mapModel(params.model);
        const modelConfig = this.modelManager.getModel(mappedModel) || this.modelManager.getDefaultModelConfig();
        // Estimate cost
        const estimatedTokens = params.prompt.length / 4; // Rough token estimation
        const estimatedCost = estimatedTokens / 1000 * modelConfig.costPerToken;
        console.info(`[Cost] Estimated cost for ${mappedModel} completion: $${estimatedCost.toFixed(4)}`);
        try {
            // Convert to chat completion format for Foundry
            const chatParams = {
                model: mappedModel,
                messages: [
                    {
                        role: 'user',
                        content: params.prompt
                    }
                ],
                temperature: params.temperature,
                max_tokens: params.max_tokens,
                top_p: params.top_p,
                frequency_penalty: params.frequency_penalty,
                presence_penalty: params.presence_penalty,
                stop: params.stop,
                n: params.n
            };
            const chatResponse = await this.createChatCompletion(chatParams);
            // Convert chat response to completion format
            const completionResponse = {
                id: chatResponse.id,
                object: 'text_completion',
                created: chatResponse.created,
                model: mappedModel,
                choices: chatResponse.choices.map((choice)=>({
                        text: choice.message.content,
                        index: choice.index,
                        finish_reason: choice.finish_reason
                    })),
                usage: chatResponse.usage
            };
            return completionResponse;
        } catch (error) {
            const latency = Date.now() - startTime;
            console.error(`[Cost] Failed completion request for ${mappedModel} after ${latency}ms:`, error.message);
            throw error;
        }
    }
    /**
   * List available models
   */ async listModels() {
        await this.ensureInitialized();
        const availableModels = this.modelManager.getAvailableModels();
        const modelList = Object.entries(availableModels).map(([name, config])=>({
                id: name,
                object: 'model',
                created: Math.floor(Date.now() / 1000),
                owned_by: 'azure-ai-foundry'
            }));
        return {
            object: 'list',
            data: modelList
        };
    }
    /**
   * Map legacy model names to Azure AI Foundry model names
   * 
   * @param legacyModelName - Original model name from legacy code
   * @returns Mapped model name for Azure AI Foundry
   */ mapModel(legacyModelName) {
        // Define model mapping based on your specifications
        const modelMapping = {
            // GPT-4 variants → gpt-4.5 (though we'll use gpt-4o as it's available)
            'gpt-4': 'gpt-4o',
            'gpt-4-turbo': 'gpt-4-turbo',
            'gpt-4o': 'gpt-4o',
            // GPT-3.5 variants → gpt-4o (upgrade path)
            'gpt-3.5': 'gpt-4o',
            'gpt-3.5-turbo': 'gpt-4o',
            'gpt-35-turbo': 'gpt-4o',
            // Phi models (if they exist in your foundry config)
            'phi-4': 'phi-4',
            // Default fallback
            'default': 'gpt-4o'
        };
        const mapped = modelMapping[legacyModelName] || modelMapping['default'];
        if (legacyModelName !== mapped) {
            console.log(`[ModelMapping] ${legacyModelName} → ${mapped}`);
        }
        return mapped;
    }
    /**
   * Estimate token count for cost calculation
   */ estimateTokens(params) {
        const messageContent = params.messages.map((m)=>m.content).join(' ');
        // Rough estimation: 1 token ≈ 4 characters for English text
        const inputTokens = Math.ceil(messageContent.length / 4);
        const outputTokens = Math.min(params.max_tokens || 150, 500); // Conservative estimate
        return inputTokens + outputTokens;
    }
    /**
   * Ensure client is initialized before use
   */ async ensureInitialized() {
        if (!this.isInitialized) {
            await this.init();
        }
    }
    /**
   * Get usage statistics
   */ getUsageStats() {
        // Delegate to model manager for usage statistics
        return {
            availableModels: Object.keys(this.modelManager.getAvailableModels()),
            initialized: this.isInitialized
        };
    }
    /**
   * Clean up resources
   */ dispose() {
        this.isInitialized = false;
        console.log('🧹 MigrationOpenAIClient disposed');
    }
}
// Export singleton instance for drop-in replacement
const migrationOpenAIClient = new MigrationOpenAIClient();
// Export class for custom instantiation


// Default export for CommonJS compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (MigrationOpenAIClient)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;