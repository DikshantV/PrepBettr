"use strict";
exports.id = 8703;
exports.ids = [8703];
exports.modules = {

/***/ 8703:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  fd: () => (/* reexport */ core_getUnifiedAuth),
  nr: () => (/* reexport */ verifyToken)
});

// UNUSED EXPORTS: AuthErrorCode, AuthPerformanceMonitor, TokenUtils, UnifiedAuth, UnifiedAuthError, authSystemHealthCheck, azureAdminMiddleware, azureAuthMiddleware, azureRoleMiddleware, benchmarkAzureAuth, benchmarkExpressAuth, benchmarkNextAuth, createAdminAzureFunction, createAuthError, createAuthenticatedAzureFunction, createAzureHealthResponse, createNextHealthResponse, createRoleBasedAzureFunction, expressAdminMiddleware, expressAuthErrorHandler, expressAuthMiddleware, expressOptionalAuth, expressRoleMiddleware, extractUserFromAzureRequest, extractUserFromExpressRequest, extractUserFromRequest, getAuthMetrics, getGlobalAuth, getUserFromSessionCookie, getUserRoles, hasAnyRole, hasRole, initializeFirebaseForAzure, initializeUnifiedAuth, isAuthError, isAuthenticatedUser, isExpressRequestAuthenticated, isTokenInfo, legacyAzureAuthMiddleware, nextAdminMiddleware, nextAuthMiddleware, nextOptionalAuth, nextRoleMiddleware, protectExpressAdminRoutes, protectExpressRouteWithRoles, protectExpressRouter, quickAuthCheck, resetAuthMetrics, resetGlobalAuth, shouldMigrateAuth, validateMigrationReadiness, verifyAuthHeader, verifyRoles, withNextAdminAuth, withNextAuth, withNextRoleAuth

;// ./lib/shared/auth/types.ts
/**
 * Unified Authentication Types
 * 
 * Common type definitions for all authentication implementations
 */ // ===== USER TYPES =====
// ===== ERROR TYPES =====
var types_AuthErrorCode = /*#__PURE__*/ function(AuthErrorCode) {
    AuthErrorCode["MISSING_TOKEN"] = "MISSING_TOKEN";
    AuthErrorCode["INVALID_TOKEN"] = "INVALID_TOKEN";
    AuthErrorCode["EXPIRED_TOKEN"] = "EXPIRED_TOKEN";
    AuthErrorCode["MALFORMED_TOKEN"] = "MALFORMED_TOKEN";
    AuthErrorCode["INSUFFICIENT_PERMISSIONS"] = "INSUFFICIENT_PERMISSIONS";
    AuthErrorCode["SERVICE_UNAVAILABLE"] = "SERVICE_UNAVAILABLE";
    AuthErrorCode["FIREBASE_ERROR"] = "FIREBASE_ERROR";
    AuthErrorCode["AZURE_ERROR"] = "AZURE_ERROR";
    AuthErrorCode["NETWORK_ERROR"] = "NETWORK_ERROR";
    AuthErrorCode["UNKNOWN_ERROR"] = "UNKNOWN_ERROR";
    return AuthErrorCode;
}({});
// ===== TYPE GUARDS =====
function isAuthenticatedUser(obj) {
    return obj && typeof obj === 'object' && typeof obj.uid === 'string';
}
function isAuthError(error) {
    return error instanceof Error && 'code' in error && Object.values(types_AuthErrorCode).includes(error.code);
}
function isTokenInfo(obj) {
    return obj && typeof obj === 'object' && typeof obj.provider === 'string' && typeof obj.value === 'string';
}

;// ./lib/shared/auth/core.ts
/**
 * Unified Authentication Core Library
 * 
 * Consolidates all authentication logic into a single, reusable library
 * that eliminates the 87% code duplication across platforms
 */ 
class core_UnifiedAuthError extends Error {
    constructor(code, message, details, statusCode){
        super(message), this.code = code, this.details = details, this.statusCode = statusCode;
        this.name = 'UnifiedAuthError';
    }
    static missingToken() {
        return new core_UnifiedAuthError(types_AuthErrorCode.MISSING_TOKEN, 'Missing or invalid Authorization header', {}, 401);
    }
    static invalidToken(details) {
        return new core_UnifiedAuthError(types_AuthErrorCode.INVALID_TOKEN, 'Invalid or malformed token', {
            details
        }, 401);
    }
    static expiredToken() {
        return new core_UnifiedAuthError(types_AuthErrorCode.EXPIRED_TOKEN, 'Token has expired', {}, 401);
    }
    static insufficientPermissions(requiredRoles) {
        return new core_UnifiedAuthError(types_AuthErrorCode.INSUFFICIENT_PERMISSIONS, 'Insufficient permissions', {
            requiredRoles
        }, 403);
    }
    static serviceUnavailable(service) {
        return new core_UnifiedAuthError(types_AuthErrorCode.SERVICE_UNAVAILABLE, `Authentication service unavailable: ${service}`, {
            service
        }, 503);
    }
}
// ===== CORE AUTHENTICATION CLASS =====
class UnifiedAuth {
    constructor(config = {}){
        this.initialized = false;
        this.config = {
            security: {
                enableTokenRefresh: true,
                tokenExpiryMinutes: 60,
                maxRetryAttempts: 3,
                retryDelayMs: 1000,
                ...config.security
            },
            logging: {
                enabled: true,
                level: 'debug',
                includeTokenDetails: false,
                ...config.logging
            },
            ...config
        };
        this.metrics = {
            totalRequests: 0,
            successfulAuth: 0,
            failedAuth: 0,
            averageVerificationTime: 0,
            errorsByCode: {}
        };
    }
    static getInstance(config) {
        if (!UnifiedAuth.instance) {
            UnifiedAuth.instance = new UnifiedAuth(config);
        }
        return UnifiedAuth.instance;
    }
    /**
   * Initialize authentication providers
   */ async initialize() {
        if (this.initialized) return;
        try {
            // Always initialize Firebase Auth (it's the primary provider)
            console.log('🔥 UnifiedAuth: Starting initialization...');
            await this.initializeFirebase();
            // Initialize Azure Auth (if needed)
            if (this.config.azure) {
                await this.initializeAzure();
            }
            this.initialized = true;
            console.log('🔥 UnifiedAuth: Initialization completed successfully');
            this.log('info', 'UnifiedAuth initialized successfully');
        } catch (error) {
            console.error('🔥 UnifiedAuth: Initialization failed:', error);
            this.log('error', 'Failed to initialize UnifiedAuth', {
                error
            });
            throw error;
        }
    }
    /**
   * Initialize Firebase Auth
   */ async initializeFirebase() {
        try {
            console.log('🔥 UnifiedAuth: Initializing Firebase Admin SDK...');
            // Use existing Firebase admin initialization
            const { getAdminAuth } = await __webpack_require__.e(/* import() */ 3969).then(__webpack_require__.bind(__webpack_require__, 63969));
            this.firebaseAuth = await getAdminAuth();
            // Test the connection
            try {
                // Try to get a non-existent user to test connectivity
                await this.firebaseAuth.getUser('test-connection-' + Date.now());
            } catch (testError) {
                if (testError.code === 'auth/user-not-found') {
                    console.log('🔥 UnifiedAuth: Firebase Admin SDK connection test successful');
                } else {
                    console.warn('🔥 UnifiedAuth: Firebase Admin SDK connection test warning:', testError.message);
                }
            }
            console.log('🔥 UnifiedAuth: Firebase Auth initialized successfully');
            this.log('info', 'Firebase Auth initialized');
        } catch (error) {
            console.error('🔥 UnifiedAuth: Firebase Auth initialization failed:', error);
            throw new core_UnifiedAuthError(types_AuthErrorCode.FIREBASE_ERROR, 'Failed to initialize Firebase Auth', {
                error: error instanceof Error ? error.message : 'Unknown error'
            });
        }
    }
    /**
   * Initialize Azure Auth (placeholder for future Azure AD integration)
   */ async initializeAzure() {
        try {
            // Placeholder for Azure AD initialization
            this.log('info', 'Azure Auth initialization skipped (not implemented)');
        } catch (error) {
            throw new core_UnifiedAuthError(types_AuthErrorCode.AZURE_ERROR, 'Failed to initialize Azure Auth', {
                error: error instanceof Error ? error.message : 'Unknown error'
            });
        }
    }
    /**
   * Extract Bearer token from Authorization header
   */ extractBearerToken(authHeader) {
        if (!authHeader) {
            return null;
        }
        const parts = authHeader.trim().split(' ');
        if (parts.length !== 2 || parts[0] !== 'Bearer') {
            return null;
        }
        return parts[1];
    }
    /**
   * Verify any token (Firebase, Azure, etc.)
   */ async verifyToken(token) {
        if (!this.initialized) {
            await this.initialize();
        }
        const startTime = Date.now();
        this.metrics.totalRequests++;
        try {
            // Try Firebase token verification first
            if (this.firebaseAuth) {
                const result = await this.verifyFirebaseToken(token);
                if (result.valid) {
                    this.updateMetrics(true, Date.now() - startTime);
                    return result;
                }
            }
            // Try Azure token verification (if configured)
            if (this.azureAuth) {
                const result = await this.verifyAzureToken(token);
                if (result.valid) {
                    this.updateMetrics(true, Date.now() - startTime);
                    return result;
                }
            }
            // No valid token found
            this.updateMetrics(false, Date.now() - startTime, types_AuthErrorCode.INVALID_TOKEN);
            return {
                valid: false,
                error: 'Token verification failed across all providers',
                errorCode: types_AuthErrorCode.INVALID_TOKEN
            };
        } catch (error) {
            this.updateMetrics(false, Date.now() - startTime, types_AuthErrorCode.UNKNOWN_ERROR);
            this.log('error', 'Token verification error', {
                error
            });
            return {
                valid: false,
                error: error instanceof Error ? error.message : 'Unknown verification error',
                errorCode: types_AuthErrorCode.UNKNOWN_ERROR
            };
        }
    }
    /**
   * Verify Firebase ID token
   */ async verifyFirebaseToken(idToken) {
        try {
            // Handle mock tokens for development
            if (idToken.startsWith('mock-token-')) {
                this.log('debug', 'Verifying mock token');
                return this.verifyMockToken(idToken);
            }
            if (!this.firebaseAuth) {
                console.error('🔥 UnifiedAuth: Firebase Auth not initialized in verifyFirebaseToken');
                throw new core_UnifiedAuthError(types_AuthErrorCode.SERVICE_UNAVAILABLE, 'Firebase Auth not initialized');
            }
            this.log('debug', 'Verifying Firebase ID token', {
                tokenPrefix: idToken.substring(0, 20) + '...'
            });
            console.log('🔥 UnifiedAuth: About to call firebaseAuth.verifyIdToken...');
            // Add additional validation options
            const decodedToken = await this.firebaseAuth.verifyIdToken(idToken, true);
            console.log('🔥 UnifiedAuth: Firebase verifyIdToken successful');
            this.log('debug', 'Firebase token verification successful', {
                uid: decodedToken.uid,
                email: decodedToken.email,
                exp: decodedToken.exp
            });
            const user = {
                uid: decodedToken.uid,
                email: decodedToken.email,
                name: decodedToken.name || decodedToken.display_name || decodedToken.email?.split('@')[0],
                picture: decodedToken.picture,
                email_verified: decodedToken.email_verified || false,
                firebase: decodedToken.firebase,
                custom_claims: decodedToken.custom_claims || {},
                provider: 'firebase'
            };
            return {
                valid: true,
                user,
                expiresAt: new Date(decodedToken.exp * 1000)
            };
        } catch (error) {
            this.log('error', 'Firebase token verification failed', {
                error: error.message,
                code: error.code,
                tokenPrefix: idToken.substring(0, 20) + '...'
            });
            // Handle specific Firebase Auth errors
            if (error.code === 'auth/id-token-expired') {
                return {
                    valid: false,
                    error: 'Token has expired',
                    errorCode: types_AuthErrorCode.EXPIRED_TOKEN
                };
            }
            if (error.code === 'auth/id-token-revoked') {
                return {
                    valid: false,
                    error: 'Token has been revoked',
                    errorCode: types_AuthErrorCode.INVALID_TOKEN
                };
            }
            if (error.code === 'auth/invalid-id-token') {
                return {
                    valid: false,
                    error: 'Invalid ID token format',
                    errorCode: types_AuthErrorCode.INVALID_TOKEN
                };
            }
            if (error.code === 'auth/project-not-found') {
                return {
                    valid: false,
                    error: 'Firebase project not found',
                    errorCode: types_AuthErrorCode.SERVICE_UNAVAILABLE
                };
            }
            // Handle the specific "kid" claim error (expired token)
            if (error.code === 'auth/argument-error' && error.message.includes('kid')) {
                return {
                    valid: false,
                    error: 'Token has expired or is invalid. Please refresh your authentication.',
                    errorCode: types_AuthErrorCode.EXPIRED_TOKEN
                };
            }
            return {
                valid: false,
                error: error.message || 'Firebase token verification failed',
                errorCode: types_AuthErrorCode.FIREBASE_ERROR
            };
        }
    }
    /**
   * Verify mock token for development
   */ verifyMockToken(token) {
        try {
            // Parse mock token: mock-token-{uid}-{timestamp}
            const parts = token.split('-');
            if (parts.length < 4) {
                return {
                    valid: false,
                    error: 'Invalid mock token format',
                    errorCode: types_AuthErrorCode.INVALID_TOKEN
                };
            }
            const uid = parts[2];
            const timestamp = parseInt(parts[3]);
            // Check if token is not too old (24 hours)
            const tokenAge = Date.now() - timestamp;
            if (tokenAge > 24 * 60 * 60 * 1000) {
                return {
                    valid: false,
                    error: 'Mock token has expired',
                    errorCode: types_AuthErrorCode.EXPIRED_TOKEN
                };
            }
            const user = {
                uid: uid,
                email: uid.includes('@') ? uid : `${uid}@mock.com`,
                name: uid.replace(/[^a-zA-Z0-9]/g, ' ').replace(/\s+/g, ' ').trim() || 'Mock User',
                email_verified: true,
                provider: 'custom'
            };
            this.log('debug', 'Mock token verified successfully', {
                uid
            });
            return {
                valid: true,
                user,
                expiresAt: new Date(timestamp + 24 * 60 * 60 * 1000) // 24 hours from creation
            };
        } catch (error) {
            return {
                valid: false,
                error: error instanceof Error ? error.message : 'Mock token verification failed',
                errorCode: types_AuthErrorCode.INVALID_TOKEN
            };
        }
    }
    /**
   * Verify Azure AD token (placeholder)
   */ async verifyAzureToken(token) {
        try {
            // Placeholder for Azure AD token verification
            this.log('debug', 'Azure token verification not implemented');
            return {
                valid: false,
                error: 'Azure token verification not implemented',
                errorCode: types_AuthErrorCode.SERVICE_UNAVAILABLE
            };
        } catch (error) {
            return {
                valid: false,
                error: error instanceof Error ? error.message : 'Azure token verification failed',
                errorCode: types_AuthErrorCode.AZURE_ERROR
            };
        }
    }
    /**
   * Verify session cookie (primarily for Firebase)
   */ async verifySessionCookie(sessionCookie) {
        try {
            if (!this.firebaseAuth) {
                await this.initialize();
            }
            const decodedClaims = await this.firebaseAuth.verifySessionCookie(sessionCookie, true);
            const user = {
                uid: decodedClaims.uid,
                email: decodedClaims.email,
                name: decodedClaims.name || decodedClaims.email?.split('@')[0],
                picture: decodedClaims.picture,
                email_verified: decodedClaims.email_verified || false,
                firebase: decodedClaims.firebase,
                custom_claims: decodedClaims.custom_claims || {},
                provider: 'firebase'
            };
            return {
                valid: true,
                user,
                expiresAt: new Date(decodedClaims.exp * 1000)
            };
        } catch (error) {
            this.log('debug', 'Session cookie verification failed', {
                error: error.message
            });
            return {
                valid: false,
                error: error.message || 'Session cookie verification failed',
                errorCode: types_AuthErrorCode.INVALID_TOKEN
            };
        }
    }
    /**
   * Check if user has required roles
   */ hasRequiredRoles(user, requiredRoles) {
        if (!requiredRoles.length) return true;
        const userRoles = user.custom_claims?.roles || [];
        return requiredRoles.some((role)=>userRoles.includes(role));
    }
    /**
   * Create standardized auth result
   */ createAuthResult(user, error) {
        return {
            success: !!user && !error,
            user,
            error: error?.message,
            errorCode: error?.code
        };
    }
    /**
   * Get authentication metrics
   */ getMetrics() {
        return {
            ...this.metrics
        };
    }
    /**
   * Reset metrics
   */ resetMetrics() {
        this.metrics = {
            totalRequests: 0,
            successfulAuth: 0,
            failedAuth: 0,
            averageVerificationTime: 0,
            errorsByCode: {}
        };
    }
    /**
   * Health check
   */ async healthCheck() {
        const details = {
            initialized: this.initialized,
            firebase: !!this.firebaseAuth,
            azure: !!this.azureAuth,
            metrics: this.metrics
        };
        let healthy = this.initialized;
        // Test Firebase connectivity
        if (this.firebaseAuth) {
            try {
                // Simple connectivity test
                await this.firebaseAuth.getUser('test-user-id').catch(()=>{
                // Expected to fail, just testing connectivity
                });
                details.firebaseConnectivity = 'ok';
            } catch (error) {
                details.firebaseConnectivity = 'error';
                details.firebaseError = error instanceof Error ? error.message : 'Unknown error';
                healthy = false;
            }
        }
        return {
            healthy,
            details
        };
    }
    /**
   * Update performance metrics
   */ updateMetrics(success, responseTime, errorCode) {
        if (success) {
            this.metrics.successfulAuth++;
        } else {
            this.metrics.failedAuth++;
            if (errorCode) {
                this.metrics.errorsByCode[errorCode] = (this.metrics.errorsByCode[errorCode] || 0) + 1;
            }
        }
        // Update average response time
        const totalAuth = this.metrics.successfulAuth + this.metrics.failedAuth;
        this.metrics.averageVerificationTime = (this.metrics.averageVerificationTime * (totalAuth - 1) + responseTime) / totalAuth;
    }
    /**
   * Unified logging
   */ log(level, message, details) {
        if (!this.config.logging?.enabled) return;
        const logLevel = this.config.logging?.level || 'info';
        const levels = {
            debug: 0,
            info: 1,
            warn: 2,
            error: 3
        };
        if (levels[level] >= levels[logLevel]) {
            const logMessage = `[UnifiedAuth] ${message}`;
            const logDetails = this.config.logging?.includeTokenDetails ? details : details ? {
                ...details,
                token: '[REDACTED]'
            } : undefined;
            switch(level){
                case 'debug':
                    console.debug(logMessage, logDetails);
                    break;
                case 'info':
                    console.info(logMessage, logDetails);
                    break;
                case 'warn':
                    console.warn(logMessage, logDetails);
                    break;
                case 'error':
                    console.error(logMessage, logDetails);
                    break;
            }
        }
    }
}
// ===== UTILITY FUNCTIONS =====
/**
 * Get the singleton UnifiedAuth instance
 */ function core_getUnifiedAuth(config) {
    return UnifiedAuth.getInstance(config);
}
/**
 * Quick token verification function
 */ async function verifyToken(token) {
    const auth = core_getUnifiedAuth();
    return auth.verifyToken(token);
}
/**
 * Extract and verify token from authorization header
 */ async function core_verifyAuthHeader(authHeader) {
    const auth = core_getUnifiedAuth();
    try {
        const token = auth.extractBearerToken(authHeader);
        if (!token) {
            throw core_UnifiedAuthError.missingToken();
        }
        const result = await auth.verifyToken(token);
        if (!result.valid) {
            throw new core_UnifiedAuthError(result.errorCode || AuthErrorCode.INVALID_TOKEN, result.error || 'Token verification failed');
        }
        return auth.createAuthResult(result.user || null);
    } catch (error) {
        if (error instanceof core_UnifiedAuthError) {
            return auth.createAuthResult(null, error);
        }
        return auth.createAuthResult(null, new core_UnifiedAuthError(AuthErrorCode.UNKNOWN_ERROR, error instanceof Error ? error.message : 'Unknown authentication error'));
    }
}
/**
 * Verify user has required roles
 */ function verifyRoles(user, requiredRoles) {
    const auth = core_getUnifiedAuth();
    return auth.hasRequiredRoles(user, requiredRoles);
}
/**
 * Create a custom authentication error
 */ function createAuthError(code, message, details, statusCode) {
    return new core_UnifiedAuthError(code, message, details, statusCode);
}
// ===== TOKEN UTILITIES =====
class TokenUtils {
    /**
   * Parse token to extract basic information without verification
   */ static parseTokenInfo(token) {
        try {
            // For JWT tokens, decode the payload (without verification)
            if (token.includes('.')) {
                const parts = token.split('.');
                if (parts.length === 3) {
                    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
                    return {
                        provider: 'firebase',
                        value: token,
                        expiresAt: payload.exp ? new Date(payload.exp * 1000) : undefined,
                        userId: payload.uid || payload.sub,
                        claims: payload
                    };
                }
            }
            return {
                provider: 'custom',
                value: token
            };
        } catch (error) {
            return null;
        }
    }
    /**
   * Check if token is expired (without verification)
   */ static isTokenExpired(token) {
        const tokenInfo = TokenUtils.parseTokenInfo(token);
        if (!tokenInfo?.expiresAt) return false;
        return tokenInfo.expiresAt < new Date();
    }
    /**
   * Get token expiry time
   */ static getTokenExpiry(token) {
        const tokenInfo = TokenUtils.parseTokenInfo(token);
        return tokenInfo?.expiresAt || null;
    }
}
// ===== PERFORMANCE MONITORING =====
class core_AuthPerformanceMonitor {
    static getInstance() {
        if (!core_AuthPerformanceMonitor.instance) {
            core_AuthPerformanceMonitor.instance = new core_AuthPerformanceMonitor();
        }
        return core_AuthPerformanceMonitor.instance;
    }
    /**
   * Start timing an operation
   */ startTiming(operation) {
        const startTime = performance.now();
        return ()=>{
            const duration = performance.now() - startTime;
            this.recordTiming(operation, duration);
            return duration;
        };
    }
    /**
   * Record timing for an operation
   */ recordTiming(operation, duration) {
        if (!this.timings.has(operation)) {
            this.timings.set(operation, []);
        }
        const timings = this.timings.get(operation);
        timings.push(duration);
        // Keep only last 100 measurements
        if (timings.length > 100) {
            timings.shift();
        }
    }
    /**
   * Get performance statistics
   */ getStats(operation) {
        if (operation) {
            const timings = this.timings.get(operation) || [];
            return this.calculateStats(operation, timings);
        }
        const stats = {};
        for (const [op, timings] of this.timings.entries()){
            stats[op] = this.calculateStats(op, timings);
        }
        return stats;
    }
    calculateStats(operation, timings) {
        if (timings.length === 0) {
            return {
                operation,
                count: 0
            };
        }
        const sorted = [
            ...timings
        ].sort((a, b)=>a - b);
        const sum = timings.reduce((a, b)=>a + b, 0);
        return {
            operation,
            count: timings.length,
            average: sum / timings.length,
            median: sorted[Math.floor(sorted.length / 2)],
            p95: sorted[Math.floor(sorted.length * 0.95)],
            p99: sorted[Math.floor(sorted.length * 0.99)],
            min: sorted[0],
            max: sorted[sorted.length - 1]
        };
    }
    /**
   * Reset all performance data
   */ reset() {
        this.timings.clear();
    }
    constructor(){
        this.timings = new Map();
    }
}
// ===== GLOBAL INSTANCES =====
let globalAuth = null;
function getGlobalAuth() {
    if (!globalAuth) {
        globalAuth = UnifiedAuth.getInstance();
    }
    return globalAuth;
}
function resetGlobalAuth() {
    globalAuth = null;
}

// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
;// ./lib/shared/auth/adapters/next-auth.ts
/**
 * Next.js Authentication Middleware Adapter
 * 
 * Provides Next.js-specific authentication middleware using the unified auth library
 */ 


// ===== NEXT.JS MIDDLEWARE FUNCTIONS =====
/**
 * Core authentication middleware for Next.js API routes
 */ async function nextAuthMiddleware(request, options = {}) {
    const monitor = AuthPerformanceMonitor.getInstance();
    const endTiming = monitor.startTiming('next-auth-middleware');
    try {
        const authHeader = request.headers.get('authorization');
        const authResult = await verifyAuthHeader(authHeader);
        if (!authResult.success || !authResult.user) {
            const error = new UnifiedAuthError(authResult.errorCode || AuthErrorCode.INVALID_TOKEN, authResult.error || 'Authentication failed');
            return {
                success: false,
                user: null,
                response: createErrorResponse(error),
                error: error.message,
                errorCode: error.code
            };
        }
        // Check roles if required
        if (options.requiredRoles?.length) {
            const auth = getUnifiedAuth();
            if (!auth.hasRequiredRoles(authResult.user, options.requiredRoles)) {
                const error = UnifiedAuthError.insufficientPermissions(options.requiredRoles);
                return {
                    success: false,
                    user: null,
                    response: createErrorResponse(error),
                    error: error.message,
                    errorCode: error.code
                };
            }
        }
        // Custom validation
        if (options.customValidator) {
            const isValid = await options.customValidator(authResult.user);
            if (!isValid) {
                const error = new UnifiedAuthError(AuthErrorCode.INSUFFICIENT_PERMISSIONS, 'Custom validation failed');
                return {
                    success: false,
                    user: null,
                    response: createErrorResponse(error),
                    error: error.message,
                    errorCode: error.code
                };
            }
        }
        endTiming();
        return {
            success: true,
            user: authResult.user
        };
    } catch (error) {
        endTiming();
        console.error('Next.js auth middleware error:', error);
        const authError = error instanceof UnifiedAuthError ? error : new UnifiedAuthError(AuthErrorCode.UNKNOWN_ERROR, 'Authentication system error');
        return {
            success: false,
            user: null,
            response: createErrorResponse(authError),
            error: authError.message,
            errorCode: authError.code
        };
    }
}
/**
 * Optional authentication middleware (allows anonymous users)
 */ async function nextOptionalAuth(request) {
    try {
        const authHeader = request.headers.get('authorization');
        const authResult = await verifyAuthHeader(authHeader);
        return {
            user: authResult.user,
            isAuthenticated: authResult.success
        };
    } catch (error) {
        return {
            user: null,
            isAuthenticated: false
        };
    }
}
/**
 * Role-based authentication middleware
 */ async function nextRoleMiddleware(request, requiredRoles) {
    return nextAuthMiddleware(request, {
        requiredRoles
    });
}
/**
 * Admin-only middleware
 */ async function nextAdminMiddleware(request) {
    return nextAuthMiddleware(request, {
        requiredRoles: [
            'admin'
        ]
    });
}
// ===== HIGHER-ORDER FUNCTIONS =====
/**
 * Higher-order function to create authenticated API handlers
 */ function withNextAuth(handler, options = {}) {
    return async (request, ...args)=>{
        if (options.skipAuth) {
            return await handler(request, null, ...args);
        }
        const authResult = await nextAuthMiddleware(request, options);
        if (!authResult.success || !authResult.user) {
            return authResult.response;
        }
        // Call the actual handler with the authenticated user
        return await handler(request, authResult.user, ...args);
    };
}
/**
 * Admin-only handler wrapper
 */ function withNextAdminAuth(handler) {
    return withNextAuth(handler, {
        requiredRoles: [
            'admin'
        ]
    });
}
/**
 * Role-based handler wrapper
 */ function withNextRoleAuth(handler, requiredRoles) {
    return withNextAuth(handler, {
        requiredRoles
    });
}
// ===== UTILITY FUNCTIONS =====
/**
 * Create standardized error response for Next.js
 */ function createErrorResponse(error) {
    return NextResponse.json({
        error: error.message,
        code: error.code,
        details: error.details
    }, {
        status: error.statusCode || 500,
        headers: {
            'Content-Type': 'application/json'
        }
    });
}
/**
 * Create health check response
 */ function createNextHealthResponse() {
    return NextResponse.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        service: 'Next.js Unified Auth Middleware'
    }, {
        status: 200
    });
}
/**
 * Get user from session cookie (for server components)
 */ async function getUserFromSessionCookie(sessionCookie) {
    try {
        const auth = getUnifiedAuth();
        const result = await auth.verifySessionCookie(sessionCookie);
        return result.valid ? result.user || null : null;
    } catch (error) {
        console.error('Session cookie verification failed:', error);
        return null;
    }
}
/**
 * Extract user from Next.js request context
 */ async function extractUserFromRequest(request) {
    try {
        // Try Authorization header first
        const authHeader = request.headers.get('authorization');
        if (authHeader) {
            const authResult = await verifyAuthHeader(authHeader);
            if (authResult.success && authResult.user) {
                return authResult.user;
            }
        }
        // Try session cookie as fallback
        const sessionCookie = request.cookies.get('session')?.value;
        if (sessionCookie) {
            return await getUserFromSessionCookie(sessionCookie);
        }
        return null;
    } catch (error) {
        console.error('Failed to extract user from request:', error);
        return null;
    }
}
// ===== PERFORMANCE HELPERS =====
/**
 * Benchmark authentication performance
 */ async function benchmarkNextAuth(request, iterations = 100) {
    const monitor = AuthPerformanceMonitor.getInstance();
    const results = [];
    for(let i = 0; i < iterations; i++){
        const endTiming = monitor.startTiming('benchmark');
        await nextAuthMiddleware(request);
        const duration = endTiming();
        results.push(duration);
    }
    const sorted = results.sort((a, b)=>a - b);
    const sum = results.reduce((a, b)=>a + b, 0);
    return {
        iterations,
        average: sum / iterations,
        median: sorted[Math.floor(sorted.length / 2)],
        p95: sorted[Math.floor(sorted.length * 0.95)],
        p99: sorted[Math.floor(sorted.length * 0.99)],
        min: sorted[0],
        max: sorted[sorted.length - 1]
    };
}

;// ./lib/shared/auth/adapters/azure-auth.ts
/**
 * Azure Functions Authentication Middleware Adapter
 * 
 * Provides Azure Functions-specific authentication middleware using the unified auth library
 */ 

// ===== AZURE FUNCTIONS MIDDLEWARE =====
/**
 * Core authentication middleware for Azure Functions
 */ async function azureAuthMiddleware(context, req, options = {}) {
    const monitor = AuthPerformanceMonitor.getInstance();
    const endTiming = monitor.startTiming('azure-auth-middleware');
    try {
        const authHeader = req.headers.authorization || req.headers.Authorization;
        const authResult = await verifyAuthHeader(authHeader);
        if (!authResult.success || !authResult.user) {
            const error = new UnifiedAuthError(authResult.errorCode || AuthErrorCode.INVALID_TOKEN, authResult.error || 'Authentication failed');
            return {
                success: false,
                user: null,
                response: createAzureErrorResponse(error),
                error: error.message,
                errorCode: error.code
            };
        }
        // Check roles if required
        if (options.requiredRoles?.length) {
            const auth = getUnifiedAuth();
            if (!auth.hasRequiredRoles(authResult.user, options.requiredRoles)) {
                const error = UnifiedAuthError.insufficientPermissions(options.requiredRoles);
                return {
                    success: false,
                    user: null,
                    response: createAzureErrorResponse(error),
                    error: error.message,
                    errorCode: error.code
                };
            }
        }
        // Custom validation
        if (options.customValidator) {
            const isValid = await options.customValidator(authResult.user);
            if (!isValid) {
                const error = new UnifiedAuthError(AuthErrorCode.INSUFFICIENT_PERMISSIONS, 'Custom validation failed');
                return {
                    success: false,
                    user: null,
                    response: createAzureErrorResponse(error),
                    error: error.message,
                    errorCode: error.code
                };
            }
        }
        // Log successful authentication
        context.log.info(`Authenticated user: ${authResult.user.uid} (${authResult.user.email})`);
        endTiming();
        return {
            success: true,
            user: authResult.user
        };
    } catch (error) {
        endTiming();
        context.log.error(`Azure Functions auth middleware error: ${error}`);
        const authError = error instanceof UnifiedAuthError ? error : new UnifiedAuthError(AuthErrorCode.UNKNOWN_ERROR, 'Authentication system error');
        return {
            success: false,
            user: null,
            response: createAzureErrorResponse(authError),
            error: authError.message,
            errorCode: authError.code
        };
    }
}
/**
 * Role-based authentication middleware for Azure Functions
 */ async function azureRoleMiddleware(context, req, requiredRoles) {
    return azureAuthMiddleware(context, req, {
        requiredRoles
    });
}
/**
 * Admin-only middleware for Azure Functions
 */ async function azureAdminMiddleware(context, req) {
    return azureAuthMiddleware(context, req, {
        requiredRoles: [
            'admin'
        ]
    });
}
// ===== HIGHER-ORDER FUNCTIONS =====
/**
 * Create authenticated Azure Function wrapper
 */ function createAuthenticatedAzureFunction(handlerFunction, options = {}) {
    return async function(context, req) {
        if (options.skipAuth) {
            return await handlerFunction(context, req, null);
        }
        const authResult = await azureAuthMiddleware(context, req, options);
        if (!authResult.success || !authResult.user) {
            context.res = authResult.response;
            return;
        }
        // Call the actual handler with the authenticated user
        return await handlerFunction(context, req, authResult.user);
    };
}
/**
 * Create admin-only Azure Function wrapper
 */ function createAdminAzureFunction(handlerFunction) {
    return createAuthenticatedAzureFunction(handlerFunction, {
        requiredRoles: [
            'admin'
        ]
    });
}
/**
 * Create role-based Azure Function wrapper
 */ function createRoleBasedAzureFunction(handlerFunction, requiredRoles) {
    return createAuthenticatedAzureFunction(handlerFunction, {
        requiredRoles
    });
}
// ===== UTILITY FUNCTIONS =====
/**
 * Create standardized error response for Azure Functions
 */ function createAzureErrorResponse(error) {
    return {
        status: error.statusCode || 500,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            error: error.message,
            code: error.code,
            details: error.details
        })
    };
}
/**
 * Create health check response for Azure Functions
 */ function createAzureHealthResponse() {
    return {
        status: 200,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            status: 'healthy',
            timestamp: new Date().toISOString(),
            service: 'Azure Functions Unified Auth Middleware'
        })
    };
}
/**
 * Extract user from Azure Functions request
 */ async function extractUserFromAzureRequest(context, req) {
    try {
        const authHeader = req.headers.authorization || req.headers.Authorization;
        const authResult = await verifyAuthHeader(authHeader);
        return authResult.success ? authResult.user : null;
    } catch (error) {
        context.log.error(`Failed to extract user from Azure request: ${error}`);
        return null;
    }
}
// ===== LEGACY COMPATIBILITY =====
/**
 * Legacy Azure Functions middleware format (for backward compatibility)
 */ async function legacyAzureAuthMiddleware(context, req) {
    const authResult = await azureAuthMiddleware(context, req);
    // Return in the old format for backward compatibility
    return {
        success: authResult.success,
        user: authResult.user,
        response: authResult.response
    };
}
/**
 * Initialize Firebase for Azure Functions (backward compatibility)
 */ async function initializeFirebaseForAzure() {
    const auth = getUnifiedAuth();
    await auth.initialize();
    return auth;
}
// ===== PERFORMANCE HELPERS =====
/**
 * Benchmark Azure Functions authentication performance
 */ async function benchmarkAzureAuth(context, req, iterations = 100) {
    const monitor = AuthPerformanceMonitor.getInstance();
    const results = [];
    for(let i = 0; i < iterations; i++){
        const endTiming = monitor.startTiming('benchmark');
        await azureAuthMiddleware(context, req);
        const duration = endTiming();
        results.push(duration);
    }
    const sorted = results.sort((a, b)=>a - b);
    const sum = results.reduce((a, b)=>a + b, 0);
    const stats = {
        iterations,
        average: sum / iterations,
        median: sorted[Math.floor(sorted.length / 2)],
        p95: sorted[Math.floor(sorted.length * 0.95)],
        p99: sorted[Math.floor(sorted.length * 0.99)],
        min: sorted[0],
        max: sorted[sorted.length - 1]
    };
    context.log.info(`Azure auth performance benchmark: ${JSON.stringify(stats)}`);
    return stats;
}

;// ./lib/shared/auth/adapters/express-auth.ts
/**
 * Express.js Authentication Middleware Adapter
 * 
 * Provides Express.js-specific authentication middleware using the unified auth library
 */ 

// ===== EXPRESS.JS MIDDLEWARE =====
/**
 * Core authentication middleware for Express.js
 */ function expressAuthMiddleware(options = {}) {
    return async (req, res, next)=>{
        const monitor = AuthPerformanceMonitor.getInstance();
        const endTiming = monitor.startTiming('express-auth-middleware');
        try {
            if (options.skipAuth) {
                req.user = null;
                next();
                return;
            }
            const authHeader = req.headers.authorization || req.headers.Authorization;
            const authResult = await verifyAuthHeader(authHeader);
            if (!authResult.success || !authResult.user) {
                const error = new UnifiedAuthError(authResult.errorCode || AuthErrorCode.INVALID_TOKEN, authResult.error || 'Authentication failed');
                endTiming();
                res.status(error.statusCode || 401).json({
                    error: error.message,
                    code: error.code,
                    details: error.details
                });
                return;
            }
            // Check roles if required
            if (options.requiredRoles?.length) {
                const auth = getUnifiedAuth();
                if (!auth.hasRequiredRoles(authResult.user, options.requiredRoles)) {
                    const error = UnifiedAuthError.insufficientPermissions(options.requiredRoles);
                    endTiming();
                    res.status(error.statusCode || 403).json({
                        error: error.message,
                        code: error.code,
                        details: error.details
                    });
                    return;
                }
            }
            // Custom validation
            if (options.customValidator) {
                const isValid = await options.customValidator(authResult.user);
                if (!isValid) {
                    const error = new UnifiedAuthError(AuthErrorCode.INSUFFICIENT_PERMISSIONS, 'Custom validation failed');
                    endTiming();
                    res.status(error.statusCode || 403).json({
                        error: error.message,
                        code: error.code,
                        details: error.details
                    });
                    return;
                }
            }
            // Attach user to request
            req.user = authResult.user;
            endTiming();
            next();
        } catch (error) {
            endTiming();
            console.error('Express auth middleware error:', error);
            const authError = error instanceof UnifiedAuthError ? error : new UnifiedAuthError(AuthErrorCode.UNKNOWN_ERROR, 'Authentication system error');
            res.status(authError.statusCode || 500).json({
                error: authError.message,
                code: authError.code,
                details: authError.details
            });
        }
    };
}
/**
 * Optional authentication middleware (allows anonymous users)
 */ function expressOptionalAuth() {
    return async (req, res, next)=>{
        try {
            const authHeader = req.headers.authorization || req.headers.Authorization;
            const authResult = await verifyAuthHeader(authHeader);
            req.user = authResult.success ? authResult.user || undefined : undefined;
            next();
        } catch (error) {
            req.user = undefined;
            next();
        }
    };
}
/**
 * Role-based authentication middleware
 */ function expressRoleMiddleware(requiredRoles) {
    return expressAuthMiddleware({
        requiredRoles
    });
}
/**
 * Admin-only middleware
 */ function expressAdminMiddleware() {
    return expressAuthMiddleware({
        requiredRoles: [
            'admin'
        ]
    });
}
// ===== UTILITY FUNCTIONS =====
/**
 * Extract user from Express request
 */ async function extractUserFromExpressRequest(req) {
    try {
        // Check if user is already attached (from middleware)
        if (req.user) {
            return req.user;
        }
        // Try to extract from authorization header
        const authHeader = req.headers.authorization || req.headers.Authorization;
        const authResult = await verifyAuthHeader(authHeader);
        return authResult.success ? authResult.user : null;
    } catch (error) {
        console.error('Failed to extract user from Express request:', error);
        return null;
    }
}
/**
 * Check if Express request is authenticated
 */ function isExpressRequestAuthenticated(req) {
    return !!req.user;
}
/**
 * Get user roles from Express request
 */ function getUserRoles(req) {
    return req.user?.custom_claims?.roles || [];
}
/**
 * Check if Express request user has role
 */ function hasRole(req, role) {
    const roles = getUserRoles(req);
    return roles.includes(role);
}
/**
 * Check if Express request user has any of the required roles
 */ function hasAnyRole(req, requiredRoles) {
    const userRoles = getUserRoles(req);
    return requiredRoles.some((role)=>userRoles.includes(role));
}
// ===== ERROR HANDLERS =====
/**
 * Express error handler for authentication errors
 */ function expressAuthErrorHandler() {
    return (error, req, res, next)=>{
        if (error instanceof UnifiedAuthError) {
            res.status(error.statusCode || 500).json({
                error: error.message,
                code: error.code,
                details: error.details
            });
            return;
        }
        // Pass non-auth errors to next handler
        next(error);
    };
}
// ===== PERFORMANCE HELPERS =====
/**
 * Benchmark Express authentication performance
 */ async function benchmarkExpressAuth(req, iterations = 100) {
    const monitor = AuthPerformanceMonitor.getInstance();
    const results = [];
    for(let i = 0; i < iterations; i++){
        const endTiming = monitor.startTiming('benchmark');
        // Simulate middleware execution
        const mockRes = {
            status: ()=>mockRes,
            json: ()=>mockRes
        };
        const mockNext = ()=>{};
        await new Promise((resolve)=>{
            expressAuthMiddleware()(req, mockRes, ()=>{
                const duration = endTiming();
                results.push(duration);
                resolve();
            });
        });
    }
    const sorted = results.sort((a, b)=>a - b);
    const sum = results.reduce((a, b)=>a + b, 0);
    return {
        iterations,
        average: sum / iterations,
        median: sorted[Math.floor(sorted.length / 2)],
        p95: sorted[Math.floor(sorted.length * 0.95)],
        p99: sorted[Math.floor(sorted.length * 0.99)],
        min: sorted[0],
        max: sorted[sorted.length - 1]
    };
}
// ===== ROUTE PROTECTION HELPERS =====
/**
 * Protect all routes in an Express router with authentication
 */ function protectExpressRouter(options = {}) {
    return expressAuthMiddleware(options);
}
/**
 * Protect specific Express routes with role-based access
 */ function protectExpressRouteWithRoles(requiredRoles) {
    return expressRoleMiddleware(requiredRoles);
}
/**
 * Protect Express routes for admin-only access
 */ function protectExpressAdminRoutes() {
    return expressAdminMiddleware();
}

;// ./lib/shared/auth/index.ts
/**
 * Unified Authentication Library
 * 
 * Single source of truth for all authentication logic across platforms
 * Eliminates 87% code duplication in authentication middleware
 */ // ===== CORE EXPORTS =====

// Also import for local use


// ===== PLATFORM ADAPTER EXPORTS =====
// Next.js adapters

// Azure Functions adapters

// Express.js adapters

// ===== CONVENIENCE FUNCTIONS =====
/**
 * Initialize unified authentication with default configuration
 */ async function initializeUnifiedAuth(config) {
    const auth = getUnifiedAuth(config);
    await auth.initialize();
    return auth;
}
/**
 * Quick authentication check for any platform
 */ async function quickAuthCheck(authHeader) {
    try {
        const result = await verifyAuthHeader(authHeader);
        return {
            authenticated: result.success,
            user: result.user,
            error: result.error
        };
    } catch (error) {
        return {
            authenticated: false,
            user: null,
            error: error instanceof Error ? error.message : 'Unknown error'
        };
    }
}
/**
 * Get comprehensive authentication metrics across all platforms
 */ function getAuthMetrics() {
    const auth = getUnifiedAuth();
    const monitor = AuthPerformanceMonitor.getInstance();
    return {
        core: auth.getMetrics(),
        performance: monitor.getStats()
    };
}
/**
 * Reset all authentication metrics and performance data
 */ function resetAuthMetrics() {
    const auth = getUnifiedAuth();
    const monitor = AuthPerformanceMonitor.getInstance();
    auth.resetMetrics();
    monitor.reset();
}
/**
 * Health check for the entire authentication system
 */ async function authSystemHealthCheck() {
    const auth = getUnifiedAuth();
    const coreHealth = await auth.healthCheck();
    const metrics = getAuthMetrics();
    return {
        healthy: coreHealth.healthy,
        core: coreHealth,
        metrics
    };
}
// ===== MIGRATION HELPERS =====
/**
 * Check if current authentication implementation needs migration
 */ function shouldMigrateAuth() {
    // Check if old middleware files exist
    const fs = __webpack_require__(29021);
    const path = __webpack_require__(33873);
    const oldFiles = [
        'lib/middleware/authMiddleware.ts',
        'azure/shared/authMiddleware.js',
        'lib/auth.ts'
    ];
    return oldFiles.some((file)=>{
        try {
            return fs.existsSync(path.resolve(process.cwd(), file));
        } catch  {
            return false;
        }
    });
}
/**
 * Validate migration readiness
 */ async function validateMigrationReadiness() {
    const issues = [];
    const suggestions = [];
    try {
        // Test unified auth initialization
        const auth = getUnifiedAuth();
        await auth.initialize();
        // Test health check
        const health = await auth.healthCheck();
        if (!health.healthy) {
            issues.push('Authentication system health check failed');
            suggestions.push('Check Firebase configuration and connectivity');
        }
        // Check for old middleware usage
        if (shouldMigrateAuth()) {
            suggestions.push('Old authentication middleware files detected - consider migration');
        }
    } catch (error) {
        issues.push(`Initialization failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        suggestions.push('Check environment variables and Firebase admin configuration');
    }
    return {
        ready: issues.length === 0,
        issues,
        suggestions
    };
}


/***/ })

};
;