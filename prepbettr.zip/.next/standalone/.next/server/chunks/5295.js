exports.id = 5295;
exports.ids = [5295];
exports.modules = {

/***/ 78335:
/***/ (() => {



/***/ }),

/***/ 96487:
/***/ (() => {



/***/ }),

/***/ 96559:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

if (false) {} else {
    if (false) {} else {
        if (false) {} else {
            if (false) {} else {
                module.exports = __webpack_require__(44870);
            }
        }
    }
}

//# sourceMappingURL=module.compiled.js.map

/***/ }),

/***/ 97853:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  X: () => (/* binding */ InterviewWorkflow)
});

;// ./lib/azure-ai-foundry/agents/base-agent.ts
/**
 * Base Agent Class and Core Interfaces for Azure AI Foundry Agent System
 * 
 * This module provides the foundational classes and interfaces for implementing
 * specialized interview agents (technical, behavioral, industry expert).
 */ // ===== BASE AGENT CLASS =====
class BaseAgent {
    constructor(foundryClient, config){
        this.foundryClient = foundryClient;
        this.config = config;
    }
    /**
   * Generate interview questions based on context
   */ async generateQuestions(context) {
        try {
            console.log(`🤖 ${this.metadata.name} generating questions for ${context.candidateProfile.targetRole}`);
            const prompt = this.buildQuestionsPrompt(context);
            const response = await this.foundryClient.request(`/chat/completions`, {
                method: 'POST',
                body: {
                    model: this.modelName,
                    messages: [
                        {
                            role: 'system',
                            content: this.instructions
                        },
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    temperature: 0.7,
                    max_tokens: 2000
                }
            });
            const questionsText = response.data?.choices?.[0]?.message?.content || response.raw || '';
            const questions = this.parseQuestionsFromResponse(questionsText, context);
            // Log usage for monitoring
            this.logUsage(context, response.data);
            return questions;
        } catch (error) {
            console.error(`❌ Error generating questions for ${this.metadata.name}:`, error);
            return this.getFallbackQuestions(context);
        }
    }
    /**
   * Process candidate response and return follow-up or acknowledgment
   */ async processResponse(response, context) {
        try {
            // For now, just return a simple acknowledgment
            // In a full implementation, this would analyze the response and provide feedback
            console.log(`📝 ${this.metadata.name} processed response: ${response.substring(0, 50)}...`);
            // Return acknowledgment or follow-up question
            return "Thank you for your response. That's a good approach to the problem.";
        } catch (error) {
            console.error(`❌ Error processing response for ${this.metadata.name}:`, error);
            return "Thank you for your response. Let's continue with the next question.";
        }
    }
    /**
   * Check if agent has completed its interview phase
   */ isComplete(context) {
        const agentQuestions = context.previousQuestions.filter((q)=>q.category === this.getQuestionCategory());
        const responses = context.responses?.filter((r)=>agentQuestions.some((q)=>q.id === r.questionId)) || [];
        // Complete if we have responses to at least 3 questions or reached max questions
        return responses.length >= Math.min(3, this.metadata.maxQuestions || 5);
    }
    // ===== PROTECTED HELPER METHODS =====
    buildQuestionsPrompt(context) {
        return `
Generate ${this.getQuestionCount(context)} interview questions for:

**Candidate Profile:**
- Target Role: ${context.candidateProfile.targetRole}
- Experience: ${context.candidateProfile.experience}
- Skills: ${context.candidateProfile.skills.join(', ')}
- Industry: ${context.candidateProfile.industry}

**Interview Requirements:**
- Difficulty: ${context.interviewConfig.difficulty}
- Focus Areas: ${context.interviewConfig.focusAreas.join(', ')}
|- Duration per question: ~${Math.floor(context.interviewConfig.duration / (this.metadata.maxQuestions || 5))} minutes

**Previously Asked Questions:**
${context.previousQuestions.map((q)=>`- ${q.text}`).join('\n') || 'None'}

Return questions in JSON format:
[
  {
    "id": "unique-id",
    "text": "Question text here",
    "category": "${this.getQuestionCategory()}",
    "difficulty": "easy|medium|hard",
    "expectedDuration": 180,
    "followUpQuestions": ["follow-up if needed"],
    "tags": ["relevant", "tags"],
    "metadata": {
      "skill": "specific skill",
      "topic": "topic area"
    }
  }
]
    `.trim();
    }
    parseQuestionsFromResponse(responseText, context) {
        try {
            // Try to extract JSON from the response
            const jsonMatch = responseText.match(/\[[\s\S]*\]/);
            if (!jsonMatch) {
                console.warn(`⚠️ Could not find JSON in ${this.metadata.name} response, using fallback`);
                return this.getFallbackQuestions(context);
            }
            const questions = JSON.parse(jsonMatch[0]);
            // Validate and clean questions
            return questions.filter((q)=>q.text && q.id).map((q)=>({
                    ...q,
                    category: this.getQuestionCategory(),
                    id: q.id || `${this.metadata.name.toLowerCase()}-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`
                })).slice(0, this.metadata.maxQuestions || 5);
        } catch (error) {
            console.error(`❌ Error parsing questions from ${this.metadata.name}:`, error);
            return this.getFallbackQuestions(context);
        }
    }
    getFallbackQuestions(context) {
        return [
            {
                id: `${this.metadata.name.toLowerCase()}-fallback-${Date.now()}`,
                text: this.getDefaultQuestion(context),
                type: this.getQuestionCategory() || 'general',
                category: this.getQuestionCategory() || 'general',
                difficulty: 'medium',
                expectedDuration: 180,
                tags: [
                    'fallback',
                    this.metadata.specialty || 'general'
                ],
                metadata: {
                    topic: 'general'
                }
            }
        ];
    }
    getQuestionCount(context) {
        const remainingTime = context.interviewConfig.duration;
        const avgTimePerQuestion = this.metadata.averageDuration || 5;
        const maxQuestions = Math.min(this.metadata.maxQuestions || 5, Math.floor(remainingTime / avgTimePerQuestion));
        return Math.max(1, maxQuestions);
    }
    /**
   * Log usage metrics for monitoring and cost tracking
   */ logUsage(context, responseData) {
        try {
            const usage = responseData?.usage;
            if (usage) {
                console.log(`📊 ${this.metadata.name} usage - Tokens: ${usage.total_tokens} (${usage.prompt_tokens}+${usage.completion_tokens})`);
            // TODO: Integrate with Application Insights or monitoring service
            // trackEvent('agent_usage', {
            //   agent: this.metadata.name,
            //   sessionId: context.sessionId,
            //   tokens: usage.total_tokens,
            //   model: this.modelName
            // });
            }
        } catch (error) {
            console.warn(`⚠️ Failed to log usage for ${this.metadata.name}:`, error);
        }
    }
    /**
   * Handle errors with context-aware logging
   */ handleError(error, context, operation) {
        console.error(`❌ ${this.metadata.name} error in ${operation}:`, {
            error: error.message,
            sessionId: context.sessionId,
            agent: this.metadata.name,
            operation,
            timestamp: new Date().toISOString()
        });
    // TODO: Integrate with error tracking service
    // reportError(error, {
    //   context: `agent_${operation}`,
    //   metadata: {
    //     agent: this.metadata.name,
    //     sessionId: context.sessionId
    //   }
    // });
    }
}
// ===== UTILITY FUNCTIONS =====
function generateQuestionId(agentName, category) {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substr(2, 5);
    return `${agentName.toLowerCase()}-${category}-${timestamp}-${random}`;
}
function calculateInterviewProgress(context) {
    const totalExpectedQuestions = 9; // 3 per agent type
    const completedQuestions = context.responses?.length || 0;
    return Math.min(100, Math.round(completedQuestions / totalExpectedQuestions * 100));
}
function getEstimatedRemainingTime(context, currentAgent) {
    const completedQuestions = context.responses?.length || 0;
    const avgTimePerQuestion = currentAgent.metadata.averageDuration || 5;
    const remainingQuestions = Math.max(0, (currentAgent.metadata.maxQuestions || 5) - completedQuestions);
    return remainingQuestions * avgTimePerQuestion;
}

;// ./lib/azure-ai-foundry/agents/technical-interviewer.ts
/**
 * Technical Interviewer Agent
 * 
 * Specialized agent for conducting technical interviews focusing on
 * coding skills, system design, algorithms, and technical knowledge.
 */ 
class TechnicalInterviewer extends BaseAgent {
    constructor(foundryClient, config){
        super(foundryClient, config), // Required BaseAgent interface properties
        this.id = 'technical-interviewer', this.name = 'Technical Interviewer', this.type = 'technical', this.modelName = 'gpt-4.5' // Use GPT-4.5 for technical interviews
        , this.instructions = `You are a Senior Technical Interviewer with 10+ years of experience conducting technical interviews for software engineering roles. Your goal is to assess the candidate's technical competency through thoughtful, practical questions.

## Your Responsibilities:
1. Generate technical questions appropriate for the candidate's experience level
2. Focus on problem-solving approach over perfect solutions
3. Include a mix of coding, system design, and conceptual questions
4. Provide questions that reveal thinking process and technical depth
5. Consider the target role and required technical skills

## Question Categories:
- **Coding Problems**: Algorithm implementation, data structures, optimization
- **System Design**: Scalability, architecture, trade-offs, design patterns
- **Technical Concepts**: Language-specific features, frameworks, best practices
- **Debugging**: Code analysis, troubleshooting, performance issues
- **Experience-Based**: Real-world scenarios, past project challenges

## Guidelines:
- Tailor difficulty to candidate's experience level (entry/mid/senior/expert)
- Ask open-ended questions that allow for discussion
- Include practical, real-world scenarios when possible
- Focus on understanding reasoning and approach
- Keep questions relevant to the target role and industry

## Response Format:
Always respond with valid JSON array containing question objects with all required fields.
Ensure questions are clear, specific, and actionable.`, this.metadata = {
            id: 'technical-interviewer',
            name: 'Technical Interviewer',
            description: 'Specializes in technical questions for software engineering roles',
            version: '1.0.0',
            supportedPhases: [
                'technical',
                'coding'
            ],
            capabilities: [
                'question-generation',
                'code-review',
                'algorithm-assessment'
            ],
            modelRequirements: {
                minimumTokens: 4000,
                preferredModels: [
                    'gpt-4',
                    'gpt-4.5'
                ]
            },
            tags: [
                'technical',
                'coding',
                'algorithms',
                'system-design'
            ],
            // Legacy compatibility
            specialty: 'Technical Skills Assessment',
            modelPreference: 'gpt-4.5',
            maxQuestions: 5,
            averageDuration: 8 // 8 minutes per technical question on average
        };
    }
    getQuestionCategory() {
        return 'technical';
    }
    getDefaultQuestion(context) {
        const { targetRole, experience, skills } = context.candidateProfile;
        const { difficulty } = context.interviewConfig;
        // Generate role-specific default questions based on context
        if (targetRole.toLowerCase().includes('frontend') || skills.includes('React')) {
            return `Describe how you would implement a reusable component in React that handles user input validation. What patterns would you use and why?`;
        }
        if (targetRole.toLowerCase().includes('backend') || skills.includes('Node.js')) {
            return `Design a RESTful API for a ${context.candidateProfile.industry} application. What endpoints would you create and how would you handle authentication and error cases?`;
        }
        if (targetRole.toLowerCase().includes('fullstack')) {
            return `Walk me through how you would architect a real-time chat application. Consider both frontend and backend components, data flow, and scalability.`;
        }
        // General technical question based on experience level
        switch(difficulty){
            case 'entry':
                return `Explain the difference between let, const, and var in JavaScript. When would you use each one and why?`;
            case 'mid':
                return `Describe a challenging technical problem you've solved recently. What was your approach and what trade-offs did you consider?`;
            case 'senior':
                return `How would you design a system to handle 1 million concurrent users? Walk me through your architecture decisions and scaling strategies.`;
            case 'expert':
                return `Discuss a time when you had to optimize performance in a critical system. What was your methodology for identifying bottlenecks and implementing solutions?`;
            default:
                return `Tell me about a technical decision you made recently and explain your reasoning process.`;
        }
    }
    /**
   * Enhanced completion check for technical interviews
   */ isComplete(context) {
        const technicalQuestions = context.previousQuestions.filter((q)=>q.category === 'technical');
        const technicalResponses = context.responses?.filter((r)=>technicalQuestions.some((q)=>q.id === r.questionId)) || [];
        // Technical interview complete if:
        // - At least 3 questions answered, OR
        // - Reached max questions for this agent, OR
        // - Spent more than 30 minutes on technical questions
        const minQuestionsAnswered = technicalResponses.length >= 3;
        const reachedMaxQuestions = technicalQuestions.length >= (this.metadata.maxQuestions || 5);
        return minQuestionsAnswered || reachedMaxQuestions;
    }
}

;// ./lib/azure-ai-foundry/agents/behavioral-interviewer.ts

/**
 * BehavioralInterviewer agent specializing in behavioral and situational questions
 * Uses GPT-4o model for human-focused behavioral assessment
 */ class BehavioralInterviewer extends BaseAgent {
    constructor(foundryClient, config){
        super(foundryClient, config), // Required BaseAgent interface properties
        this.id = 'behavioral-interviewer', this.name = 'Behavioral Interviewer', this.type = 'behavioral', this.modelName = 'gpt-4o', this.instructions = `You are a behavioral interview specialist focused on assessing soft skills, leadership potential, and cultural fit.

ROLE GUIDELINES:
- Ask questions about past experiences, challenging situations, and interpersonal skills
- Focus on STAR method responses (Situation, Task, Action, Result)
- Assess communication skills, problem-solving approach, and emotional intelligence
- Adapt questions based on the candidate's seniority level and role requirements

QUESTION TYPES TO FOCUS ON:
- Leadership and teamwork experiences
- Conflict resolution and difficult conversations
- Adaptability and learning from failure
- Decision-making under pressure
- Career motivation and goal alignment

INTERVIEW STYLE:
- Be empathetic and encouraging
- Ask follow-up questions to understand context and impact
- Help candidates structure their responses using the STAR method
- Focus on specific examples rather than hypothetical scenarios

Always tailor questions to the candidate's background and the specific role requirements.`, this.metadata = {
            id: 'behavioral-interviewer',
            name: 'Behavioral Interviewer',
            description: 'Specializes in behavioral and soft skills assessment',
            version: '1.0.0',
            supportedPhases: [
                'behavioral',
                'cultural-fit'
            ],
            capabilities: [
                'behavioral-assessment',
                'soft-skills-evaluation',
                'cultural-fit-analysis'
            ],
            modelRequirements: {
                minimumTokens: 2000,
                preferredModels: [
                    'gpt-4o',
                    'gpt-4'
                ]
            },
            tags: [
                'behavioral',
                'soft-skills',
                'teamwork',
                'leadership'
            ],
            // Legacy compatibility
            maxQuestions: 5,
            averageDuration: 6
        };
    }
    /**
   * Build behavioral-specific prompt based on context
   */ buildPrompt(context) {
        const { candidateProfile, jobRole, companyInfo, sessionHistory } = context;
        let prompt = `Generate 5-7 behavioral interview questions for a candidate interviewing for: ${jobRole}`;
        if (companyInfo?.name) {
            prompt += ` at ${companyInfo.name}`;
        }
        prompt += '\n\nCandidate Background:\n';
        if (candidateProfile?.experience) {
            prompt += `- Experience Level: ${candidateProfile.experience}\n`;
        }
        if (candidateProfile?.skills?.length) {
            prompt += `- Key Skills: ${candidateProfile.skills.join(', ')}\n`;
        }
        // Remove references to undefined properties
        if (candidateProfile?.industry) {
            prompt += `- Industry: ${candidateProfile.industry}\n`;
        }
        if (sessionHistory?.previousQuestions?.length) {
            prompt += `\nPreviously Asked Questions:\n${sessionHistory.previousQuestions.map((q)=>`- ${q.text}`).join('\n')}\n\nAvoid repeating these topics and build upon previous responses.\n`;
        }
        prompt += `\nFOCUS AREAS:
- Past experiences demonstrating relevant skills
- Leadership and teamwork scenarios
- Problem-solving and decision-making situations
- Adaptability and learning from challenges
- Communication and interpersonal skills
- Career motivation and cultural fit

FORMAT: Return each question as a JSON object with:
- "text": the question text
- "category": behavioral category (leadership, teamwork, problem-solving, etc.)
- "followUps": 1-2 potential follow-up questions
- "difficulty": beginner/intermediate/advanced based on role seniority

Ensure questions encourage STAR method responses and are appropriate for the candidate's experience level.`;
        return prompt;
    }
    /**
   * Get fallback behavioral questions when AI generation fails
   */ getFallbackBehavioralQuestions(context) {
        const experienceLevel = context.candidateProfile?.experience?.toLowerCase() || 'intermediate';
        const fallbackQuestions = [
            {
                id: 'behavioral-1',
                text: 'Tell me about a time when you had to work with a difficult team member. How did you handle the situation?',
                type: 'behavioral',
                category: 'behavioral',
                difficulty: 'medium',
                expectedDuration: 300,
                tags: [
                    'teamwork',
                    'conflict-resolution'
                ],
                metadata: {
                    topic: 'teamwork'
                }
            },
            {
                id: 'behavioral-2',
                text: 'Describe a situation where you had to learn something new quickly to complete a project.',
                type: 'behavioral',
                category: 'behavioral',
                difficulty: 'easy',
                expectedDuration: 240,
                tags: [
                    'adaptability',
                    'learning'
                ],
                metadata: {
                    topic: 'adaptability'
                }
            },
            {
                id: 'behavioral-3',
                text: 'Give me an example of a time when you had to make a decision without having all the information you needed.',
                type: 'behavioral',
                category: 'behavioral',
                difficulty: 'medium',
                expectedDuration: 360,
                tags: [
                    'decision-making',
                    'problem-solving'
                ],
                metadata: {
                    topic: 'decision-making'
                }
            },
            {
                id: 'behavioral-4',
                text: 'Tell me about a time when you received constructive criticism. How did you respond?',
                type: 'behavioral',
                category: 'behavioral',
                difficulty: 'easy',
                expectedDuration: 240,
                tags: [
                    'growth-mindset',
                    'feedback'
                ],
                metadata: {
                    topic: 'growth-mindset'
                }
            }
        ];
        // Add senior-level questions if appropriate
        if (experienceLevel.includes('senior') || experienceLevel.includes('lead') || experienceLevel.includes('principal')) {
            fallbackQuestions.push({
                id: 'behavioral-5',
                text: 'Describe a time when you had to influence others without having direct authority over them.',
                type: 'behavioral',
                category: 'behavioral',
                difficulty: 'hard',
                expectedDuration: 420,
                tags: [
                    'leadership',
                    'influence'
                ],
                metadata: {
                    topic: 'leadership'
                }
            });
        }
        return fallbackQuestions;
    }
    // Required BaseAgent abstract methods
    getQuestionCategory() {
        return 'behavioral';
    }
    getDefaultQuestion(context) {
        return 'Tell me about a time when you had to work with a difficult team member. How did you handle the situation?';
    }
}

;// ./lib/azure-ai-foundry/agents/industry-expert.ts

/**
 * IndustryExpert agent specializing in industry-specific knowledge and trends
 * Uses specialized models for domain expertise and industry insights
 */ class IndustryExpert extends BaseAgent {
    constructor(foundryClient, config){
        super(foundryClient, config), // Required BaseAgent interface properties
        this.id = 'industry-expert', this.name = 'Industry Expert', this.type = 'industry', this.modelName = 'llama-4', this.instructions = `You are an industry expert with deep knowledge across various sectors and business domains.

EXPERTISE AREAS:
- Technology trends and emerging technologies
- Business strategy and market dynamics
- Industry-specific regulations and compliance
- Competitive landscape analysis
- Best practices and industry standards
- Innovation and future outlook

ROLE GUIDELINES:
- Ask questions that assess industry knowledge and awareness
- Focus on current trends, challenges, and opportunities in the candidate's field
- Evaluate strategic thinking and business acumen
- Assess understanding of industry regulations and standards
- Test knowledge of competitive landscape and market positioning

QUESTION TYPES TO FOCUS ON:
- Industry trends and future predictions
- Regulatory changes and compliance requirements
- Competitive analysis and market positioning
- Technology adoption and innovation
- Business model evolution and disruption
- Ethical considerations and sustainability

INTERVIEW STYLE:
- Be knowledgeable and analytical
- Ask thought-provoking questions about industry direction
- Encourage strategic thinking and business reasoning
- Focus on practical application of industry knowledge
- Assess both current knowledge and learning agility

Tailor questions to the specific industry and role level of the candidate.`, this.metadata = {
            id: 'industry-expert',
            name: 'Industry Expert',
            description: 'Specializes in industry-specific knowledge and market insights',
            version: '1.0.0',
            supportedPhases: [
                'industry',
                'market-analysis'
            ],
            capabilities: [
                'industry-analysis',
                'market-knowledge',
                'trend-assessment'
            ],
            modelRequirements: {
                minimumTokens: 2500,
                preferredModels: [
                    'llama-4',
                    'gpt-4'
                ]
            },
            tags: [
                'industry',
                'market',
                'trends',
                'business'
            ],
            // Legacy compatibility
            maxQuestions: 4,
            averageDuration: 7
        };
    }
    /**
   * Generate industry-specific interview questions based on context
   */ async generateQuestions(context) {
        try {
            const prompt = this.buildPrompt(context);
            const response = await this.foundryClient.request('/chat/completions', {
                method: 'POST',
                body: {
                    model: 'llama-4',
                    messages: [
                        {
                            role: 'system',
                            content: this.getSystemInstructions()
                        },
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    temperature: 0.6,
                    max_tokens: 2500
                }
            });
            const questionsText = response.data?.choices?.[0]?.message?.content || response.raw || '';
            const questions = this.parseQuestionsFromResponse(questionsText, context);
            return questions.length > 0 ? questions : this.getFallbackQuestions(context);
        } catch (error) {
            console.error('Error generating industry questions:', error);
            return this.getFallbackQuestions(context);
        }
    }
    getSystemInstructions() {
        return `You are an industry expert with deep knowledge across various sectors and business domains.

EXPERTISE AREAS:
- Technology trends and emerging technologies
- Business strategy and market dynamics
- Industry-specific regulations and compliance
- Competitive landscape analysis
- Best practices and industry standards
- Innovation and future outlook

ROLE GUIDELINES:
- Ask questions that assess industry knowledge and awareness
- Focus on current trends, challenges, and opportunities in the candidate's field
- Evaluate strategic thinking and business acumen
- Assess understanding of industry regulations and standards
- Test knowledge of competitive landscape and market positioning

QUESTION TYPES TO FOCUS ON:
- Industry trends and future predictions
- Regulatory changes and compliance requirements
- Competitive analysis and market positioning
- Technology adoption and innovation
- Business model evolution and disruption
- Ethical considerations and sustainability

INTERVIEW STYLE:
- Be knowledgeable and analytical
- Ask thought-provoking questions about industry direction
- Encourage strategic thinking and business reasoning
- Focus on practical application of industry knowledge
- Assess both current knowledge and learning agility

Tailor questions to the specific industry and role level of the candidate.`;
    }
    /**
   * Build industry-specific prompt based on context
   */ buildPrompt(context) {
        const { candidateProfile, jobRole, companyInfo, sessionHistory } = context;
        // Extract industry from company or job role
        const industry = this.extractIndustry(companyInfo, jobRole);
        let prompt = `Generate 5-7 industry-specific interview questions for a candidate interviewing for: ${jobRole}`;
        if (companyInfo?.name) {
            prompt += ` at ${companyInfo.name}`;
        }
        if (industry) {
            prompt += ` in the ${industry} industry`;
        }
        prompt += '\n\nCandidate Background:\n';
        if (candidateProfile?.experience) {
            prompt += `- Experience Level: ${candidateProfile.experience}\n`;
        }
        if (candidateProfile?.skills?.length) {
            prompt += `- Technical Skills: ${candidateProfile.skills.join(', ')}\n`;
        }
        if (candidateProfile?.industry) {
            prompt += `- Industry Background: ${candidateProfile.industry}\n`;
        }
        if (companyInfo?.industry) {
            prompt += `\nTarget Industry: ${companyInfo.industry}\n`;
        }
        if (companyInfo?.size) {
            prompt += `Company Size: ${companyInfo.size}\n`;
        }
        if (sessionHistory?.previousQuestions?.length) {
            prompt += `\nPreviously Asked Questions:\n${sessionHistory.previousQuestions.map((q)=>`- ${q.text}`).join('\n')}\n\nBuild upon previous responses and avoid repetition.\n`;
        }
        prompt += `\nFOCUS AREAS FOR ${industry?.toUpperCase() || 'THIS'} INDUSTRY:
- Current market trends and disruptions
- Regulatory environment and compliance challenges  
- Competitive landscape and positioning
- Technology adoption and digital transformation
- Business model innovation and evolution
- Sustainability and ethical considerations
- Future outlook and growth opportunities

FORMAT: Return each question as a JSON object with:
- "text": the question text focusing on industry knowledge
- "category": industry category (trends, regulation, competition, technology, etc.)
- "followUps": 1-2 follow-up questions to drill deeper
- "difficulty": beginner/intermediate/advanced based on role seniority
- "industryContext": brief context about why this knowledge is important

Ensure questions test both current industry knowledge and strategic thinking abilities.`;
        return prompt;
    }
    /**
   * Extract industry from company info and job role
   */ extractIndustry(companyInfo, jobRole) {
        // Check explicit industry field first
        if (companyInfo?.industry) {
            return companyInfo.industry;
        }
        // Infer from company name or job role
        const combinedText = `${companyInfo?.name || ''} ${jobRole || ''}`.toLowerCase();
        const industryKeywords = {
            'technology': [
                'tech',
                'software',
                'saas',
                'ai',
                'data',
                'cloud',
                'developer',
                'engineer'
            ],
            'finance': [
                'bank',
                'fintech',
                'financial',
                'investment',
                'trading',
                'credit',
                'payment'
            ],
            'healthcare': [
                'health',
                'medical',
                'pharma',
                'biotech',
                'hospital',
                'clinical'
            ],
            'retail': [
                'retail',
                'ecommerce',
                'commerce',
                'shopping',
                'store',
                'marketplace'
            ],
            'manufacturing': [
                'manufacturing',
                'automotive',
                'industrial',
                'factory',
                'production'
            ],
            'consulting': [
                'consulting',
                'advisory',
                'strategy',
                'management',
                'professional services'
            ],
            'education': [
                'education',
                'learning',
                'school',
                'university',
                'training',
                'academic'
            ]
        };
        for (const [industry, keywords] of Object.entries(industryKeywords)){
            if (keywords.some((keyword)=>combinedText.includes(keyword))) {
                return industry;
            }
        }
        return null;
    }
    /**
   * Get fallback industry questions when AI generation fails
   */ getFallbackQuestions(context) {
        const industry = this.extractIndustry(context.companyInfo, context.jobRole) || 'technology';
        const fallbackQuestions = [
            {
                id: 'industry-1',
                text: `What do you see as the biggest trend currently shaping the ${industry} industry?`,
                type: 'industry',
                category: 'industry',
                difficulty: 'medium',
                expectedDuration: 360,
                tags: [
                    'trends',
                    'market-analysis'
                ],
                metadata: {
                    topic: 'trends'
                }
            },
            {
                id: 'industry-2',
                text: 'How do you stay updated with industry developments and emerging technologies?',
                type: 'industry',
                category: 'industry',
                difficulty: 'easy',
                expectedDuration: 240,
                tags: [
                    'learning',
                    'industry-knowledge'
                ],
                metadata: {
                    topic: 'learning'
                }
            },
            {
                id: 'industry-3',
                text: `What regulatory or compliance challenges do you think companies in ${industry} face today?`,
                type: 'industry',
                category: 'industry',
                difficulty: 'medium',
                expectedDuration: 420,
                tags: [
                    'regulation',
                    'compliance'
                ],
                metadata: {
                    topic: 'regulation'
                }
            },
            {
                id: 'industry-4',
                text: 'How do you think artificial intelligence and automation will impact this industry?',
                type: 'industry',
                category: 'industry',
                difficulty: 'medium',
                expectedDuration: 480,
                tags: [
                    'technology',
                    'future-trends'
                ],
                metadata: {
                    topic: 'technology'
                }
            }
        ];
        // Add industry-specific questions based on detected industry
        const industrySpecific = this.getIndustrySpecificQuestions(industry);
        fallbackQuestions.push(...industrySpecific);
        return fallbackQuestions;
    }
    /**
   * Get industry-specific fallback questions
   */ getIndustrySpecificQuestions(industry) {
        const specificQuestions = {
            'technology': [
                {
                    id: 'tech-specific-1',
                    text: 'How do you approach evaluating new technologies for adoption in a business context?',
                    type: 'industry',
                    category: 'industry',
                    difficulty: 'hard',
                    expectedDuration: 540,
                    tags: [
                        'technology-evaluation',
                        'strategic-thinking'
                    ],
                    metadata: {
                        topic: 'technology-evaluation'
                    }
                }
            ],
            'finance': [
                {
                    id: 'finance-specific-1',
                    text: 'How do you see fintech disrupting traditional financial services?',
                    type: 'industry',
                    category: 'industry',
                    difficulty: 'hard',
                    expectedDuration: 480,
                    tags: [
                        'fintech',
                        'disruption'
                    ],
                    metadata: {
                        topic: 'disruption'
                    }
                }
            ],
            'healthcare': [
                {
                    id: 'health-specific-1',
                    text: 'What role do you think digital health technologies play in improving patient outcomes?',
                    type: 'industry',
                    category: 'industry',
                    difficulty: 'medium',
                    expectedDuration: 420,
                    tags: [
                        'digital-health',
                        'patient-outcomes'
                    ],
                    metadata: {
                        topic: 'digital-health'
                    }
                }
            ]
        };
        return specificQuestions[industry] || [];
    }
    // Required BaseAgent abstract methods
    getQuestionCategory() {
        return 'industry';
    }
    getDefaultQuestion(context) {
        const industry = this.extractIndustry(context.companyInfo, context.jobRole) || context.candidateProfile?.industry || 'technology';
        return `What do you see as the biggest trend currently shaping the ${industry} industry?`;
    }
}

;// ./lib/azure-ai-foundry/agents/agent-factory.ts



/**
 * Factory class for creating and managing interview agents
 * 
 * Implements the Factory pattern to provide a centralized way to create
 * different types of interview agents with optional configuration overrides.
 */ class AgentFactory {
    constructor(foundryClient, config){
        this.agentInstances = new Map();
        this.foundryClient = foundryClient;
        this.config = config;
    }
    /**
   * Get singleton instance of AgentFactory
   */ static getInstance(foundryClient, config) {
        if (!AgentFactory.instance) {
            if (!foundryClient || !config) {
                throw new Error('AgentFactory must be initialized with foundryClient and config on first call');
            }
            AgentFactory.instance = new AgentFactory(foundryClient, config);
        }
        return AgentFactory.instance;
    }
    /**
   * Create an agent instance of the specified type
   * 
   * @param type - The type of agent to create
   * @param config - Optional configuration overrides
   * @returns The created agent instance
   */ createAgent(type, config) {
        const cacheKey = `${type}-${this.getConfigHash(config)}`;
        // Return cached instance if available
        if (this.agentInstances.has(cacheKey)) {
            return this.agentInstances.get(cacheKey);
        }
        let agent;
        // Create agent based on type
        switch(type){
            case 'technical':
                agent = new TechnicalInterviewer(this.foundryClient, this.config);
                break;
            case 'behavioral':
                agent = new BehavioralInterviewer(this.foundryClient, this.config);
                break;
            case 'industry':
                agent = new IndustryExpert(this.foundryClient, this.config);
                break;
            default:
                throw new Error(`Unknown agent type: ${type}`);
        }
        // Apply configuration overrides if provided
        if (config) {
            agent = this.applyConfigOverrides(agent, config);
        }
        // Cache the instance
        this.agentInstances.set(cacheKey, agent);
        return agent;
    }
    /**
   * Create multiple agents at once
   * 
   * @param specs - Array of agent specifications with type and optional config
   * @returns Array of created agent instances
   */ createAgents(specs) {
        return specs.map((spec)=>this.createAgent(spec.type, spec.config));
    }
    /**
   * Get all available agent types
   */ getAvailableTypes() {
        return [
            'technical',
            'behavioral',
            'industry'
        ];
    }
    /**
   * Create a default interview agent set (one of each type)
   * 
   * @param globalConfig - Global configuration to apply to all agents
   * @returns Object containing all three agent types
   */ createDefaultSet(globalConfig) {
        return {
            technical: this.createAgent('technical', globalConfig),
            behavioral: this.createAgent('behavioral', globalConfig),
            industry: this.createAgent('industry', globalConfig)
        };
    }
    /**
   * Create agents based on interview requirements
   * 
   * @param requirements - Interview requirements specification
   * @returns Array of appropriate agents for the requirements
   */ createAgentsForRequirements(requirements) {
        const agents = [];
        // Always include technical for technical roles
        if (requirements.includeTechnical !== false) {
            const techConfig = {};
            // Adjust technical difficulty based on experience level
            if (requirements.experienceLevel === 'entry') {
                techConfig.temperature = 0.3; // More predictable, foundational questions
            } else if (requirements.experienceLevel === 'senior' || requirements.experienceLevel === 'executive') {
                techConfig.temperature = 0.7; // More complex, system design focused
            }
            agents.push(this.createAgent('technical', techConfig));
        }
        // Include behavioral for management and senior roles
        if (requirements.includeBehavioral !== false) {
            const behavioralConfig = {};
            // Adjust behavioral focus based on role type
            if (requirements.roleType === 'management' || requirements.roleType === 'leadership') {
                behavioralConfig.customInstructions = '\n\nFOCUS ON LEADERSHIP: Emphasize leadership scenarios, team management, strategic decision-making, and organizational impact.';
                behavioralConfig.instructionsMode = 'append';
            }
            agents.push(this.createAgent('behavioral', behavioralConfig));
        }
        // Include industry expert for senior roles and specific industries
        if (requirements.includeIndustry !== false && (requirements.experienceLevel === 'senior' || requirements.experienceLevel === 'executive' || requirements.industry)) {
            const industryConfig = {};
            if (requirements.industry) {
                industryConfig.customInstructions = `\n\nINDUSTRY FOCUS: Prioritize questions specific to the ${requirements.industry} industry, including sector-specific regulations, competitive dynamics, and emerging trends.`;
                industryConfig.instructionsMode = 'append';
            }
            agents.push(this.createAgent('industry', industryConfig));
        }
        return agents;
    }
    /**
   * Clear cached agent instances (useful for testing or configuration changes)
   */ clearCache() {
        this.agentInstances.clear();
    }
    /**
   * Get information about a specific agent type
   */ getAgentInfo(type) {
        const agentInfo = {
            technical: {
                type: 'technical',
                name: 'Technical Interviewer',
                description: 'Specializes in coding challenges, system design, and technical problem-solving assessment',
                defaultModel: 'gpt-4.5',
                capabilities: [
                    'Coding problems and algorithms',
                    'System design and architecture',
                    'Technology stack assessment',
                    'Problem-solving methodology',
                    'Code review and best practices'
                ]
            },
            behavioral: {
                type: 'behavioral',
                name: 'Behavioral Interviewer',
                description: 'Focuses on soft skills, leadership potential, and cultural fit assessment',
                defaultModel: 'gpt-4o',
                capabilities: [
                    'STAR method behavioral questions',
                    'Leadership and teamwork assessment',
                    'Conflict resolution scenarios',
                    'Communication skills evaluation',
                    'Cultural fit and motivation'
                ]
            },
            industry: {
                type: 'industry',
                name: 'Industry Expert',
                description: 'Evaluates industry knowledge, market awareness, and strategic thinking',
                defaultModel: 'llama-4',
                capabilities: [
                    'Industry trends and insights',
                    'Regulatory and compliance knowledge',
                    'Competitive landscape analysis',
                    'Business strategy evaluation',
                    'Market dynamics understanding'
                ]
            }
        };
        return agentInfo[type];
    }
    /**
   * Apply configuration overrides to an agent
   * Note: This is a simplified implementation. In a real scenario, you might
   * need to create a new instance with the overrides applied at construction time.
   */ applyConfigOverrides(agent, config) {
        // For now, we return the agent as-is since our BaseAgent doesn't support
        // runtime configuration changes. In a full implementation, you would either:
        // 1. Make agent configurations mutable
        // 2. Create a wrapper/decorator pattern
        // 3. Recreate the agent with new config
        // This is a placeholder for the concept
        console.log(`Applied config overrides to agent:`, config);
        return agent;
    }
    /**
   * Generate a hash for configuration to use in caching
   */ getConfigHash(config) {
        if (!config) return 'default';
        return JSON.stringify(config);
    }
}

;// ./lib/azure-ai-foundry/agents/agent-orchestrator.ts

/**
 * AgentOrchestrator manages multi-agent interview sessions
 * 
 * Coordinates the execution of different interview phases using specialized agents,
 * manages session state, tracks progress, and provides comprehensive reporting.
 */ class AgentOrchestrator {
    constructor(){
        this.activeSessions = new Map();
        this.agentFactory = AgentFactory.getInstance();
    }
    /**
   * Start a new interview session
   * 
   * @param config - Session configuration
   * @returns Promise resolving to session result
   */ async startSession(config) {
        const startTime = Date.now();
        console.log(`Starting interview session: ${config.sessionId}`);
        // Initialize session state
        const sessionState = {
            sessionId: config.sessionId,
            currentPhase: 0,
            totalPhases: config.phases.length,
            completedQuestions: 0,
            allQuestions: [],
            agentResponses: [],
            startTime,
            lastUpdateTime: startTime,
            metadata: config.metadata || {}
        };
        this.activeSessions.set(config.sessionId, sessionState);
        const phaseResults = [];
        let totalCost = 0;
        let totalTokensUsed = 0;
        let phasesCompleted = 0;
        let phasesSkipped = 0;
        // Execute each phase
        for(let i = 0; i < config.phases.length; i++){
            const phase = config.phases[i];
            const phaseStartTime = Date.now();
            try {
                // Check if phase should be executed
                if (phase.optional && !this.shouldExecutePhase(phase, config.context)) {
                    console.log(`Skipping optional phase: ${phase.name}`);
                    phasesSkipped++;
                    continue;
                }
                console.log(`Executing phase ${i + 1}/${config.phases.length}: ${phase.name}`);
                // Create agent for this phase
                const agent = this.agentFactory.createAgent(phase.agentType, phase.agentConfig);
                // Update context with session history
                const phaseContext = {
                    ...config.context,
                    sessionHistory: {
                        previousQuestions: sessionState.allQuestions
                    }
                };
                // Generate questions for this phase
                const questions = await agent.generateQuestions(phaseContext);
                // Limit questions to requested count
                const limitedQuestions = questions.slice(0, phase.questionCount);
                // Update session state
                sessionState.currentPhase = i + 1;
                sessionState.allQuestions.push(...limitedQuestions);
                sessionState.completedQuestions += limitedQuestions.length;
                sessionState.lastUpdateTime = Date.now();
                const executionTime = Date.now() - phaseStartTime;
                // Track phase result
                phaseResults.push({
                    phase,
                    questions: limitedQuestions,
                    agent,
                    executionTime,
                    success: true
                });
                phasesCompleted++;
                // Update cost and token tracking (placeholder - would integrate with actual usage tracking)
                totalCost += this.estimatePhaseCost(limitedQuestions.length, phase.agentType);
                totalTokensUsed += this.estimatePhaseTokens(limitedQuestions.length, phase.agentType);
                console.log(`Phase ${phase.name} completed: ${limitedQuestions.length} questions generated in ${executionTime}ms`);
            } catch (error) {
                console.error(`Error executing phase ${phase.name}:`, error);
                const executionTime = Date.now() - phaseStartTime;
                phaseResults.push({
                    phase,
                    questions: [],
                    agent: this.agentFactory.createAgent(phase.agentType),
                    executionTime,
                    success: false,
                    error: error instanceof Error ? error.message : 'Unknown error'
                });
                // Continue with next phase rather than failing entire session
                if (!phase.optional) {
                    console.warn(`Required phase ${phase.name} failed, but continuing session`);
                }
            }
        }
        const totalExecutionTime = Date.now() - startTime;
        // Calculate final metrics
        const successfulPhases = phaseResults.filter((r)=>r.success).length;
        const successRate = config.phases.length > 0 ? successfulPhases / config.phases.length : 0;
        const result = {
            sessionId: config.sessionId,
            allQuestions: sessionState.allQuestions,
            phaseResults,
            metrics: {
                totalExecutionTime,
                totalCost,
                totalTokensUsed,
                phasesCompleted,
                phasesSkipped,
                successRate
            },
            finalState: sessionState
        };
        // Clean up session from active sessions
        this.activeSessions.delete(config.sessionId);
        console.log(`Interview session ${config.sessionId} completed:`, {
            totalQuestions: result.allQuestions.length,
            phases: phasesCompleted,
            duration: `${totalExecutionTime}ms`,
            successRate: `${(successRate * 100).toFixed(1)}%`
        });
        return result;
    }
    /**
   * Create a standard interview session configuration
   * 
   * @param params - Basic interview parameters
   * @returns Complete session configuration
   */ createStandardSession(params) {
        const phases = [];
        // Technical phase (default: included)
        if (params.includePhases?.technical !== false) {
            phases.push({
                id: 'technical',
                name: 'Technical Assessment',
                agentType: 'technical',
                questionCount: params.experienceLevel === 'entry' ? 4 : 6,
                agentConfig: {
                    temperature: params.experienceLevel === 'entry' ? 0.3 : 0.5
                }
            });
        }
        // Behavioral phase (default: included)
        if (params.includePhases?.behavioral !== false) {
            phases.push({
                id: 'behavioral',
                name: 'Behavioral Interview',
                agentType: 'behavioral',
                questionCount: 5,
                agentConfig: {
                    temperature: 0.7
                }
            });
        }
        // Industry phase (optional for senior+ or specific industries)
        if (params.includePhases?.industry !== false) {
            phases.push({
                id: 'industry',
                name: 'Industry Knowledge',
                agentType: 'industry',
                questionCount: 4,
                optional: true,
                conditions: {
                    minExperienceLevel: 'mid'
                },
                agentConfig: {
                    temperature: 0.6
                }
            });
        }
        return {
            sessionId: params.sessionId,
            phases,
            context: {
                sessionId: params.sessionId,
                candidateName: params.candidateProfile.name || 'Candidate',
                role: params.jobRole,
                experienceLevel: params.experienceLevel || 'mid',
                industry: params.candidateProfile.industry,
                resumeContent: params.candidateProfile.resumeContent,
                candidateProfile: params.candidateProfile,
                jobRole: params.jobRole,
                companyInfo: params.companyInfo,
                interviewConfig: {
                    duration: 60,
                    focusAreas: [
                        'technical',
                        'behavioral'
                    ],
                    difficulty: params.experienceLevel === 'executive' ? 'expert' : params.experienceLevel || 'mid',
                    includeFollowUps: true
                },
                previousQuestions: [],
                previousAnswers: [],
                currentPhase: 'technical',
                metadata: {
                    sessionType: 'standard',
                    createdAt: new Date().toISOString()
                }
            },
            maxDurationMinutes: 60,
            allowSkipOptional: true,
            metadata: {
                experienceLevel: params.experienceLevel,
                createdAt: new Date().toISOString()
            }
        };
    }
    /**
   * Get active session state
   */ getSessionState(sessionId) {
        return this.activeSessions.get(sessionId);
    }
    /**
   * Get all active session IDs
   */ getActiveSessions() {
        return Array.from(this.activeSessions.keys());
    }
    /**
   * Cancel an active session
   */ cancelSession(sessionId) {
        return this.activeSessions.delete(sessionId);
    }
    /**
   * Determine if a phase should be executed based on conditions
   */ shouldExecutePhase(phase, context) {
        if (!phase.conditions) return true;
        const { conditions } = phase;
        // Check experience level requirement
        if (conditions.minExperienceLevel) {
            const experienceLevels = [
                'entry',
                'mid',
                'senior',
                'executive'
            ];
            const candidateLevel = context.candidateProfile?.experience?.toLowerCase() || 'mid';
            const candidateIndex = experienceLevels.indexOf(candidateLevel);
            const requiredIndex = experienceLevels.indexOf(conditions.minExperienceLevel);
            if (candidateIndex < requiredIndex) {
                return false;
            }
        }
        // Check industry requirement
        if (conditions.requiredIndustry) {
            const candidateIndustry = context.companyInfo?.industry?.toLowerCase();
            const hasRequiredIndustry = conditions.requiredIndustry.some((industry)=>candidateIndustry?.includes(industry.toLowerCase()));
            if (!hasRequiredIndustry) {
                return false;
            }
        }
        return true;
    }
    /**
   * Estimate cost for a phase (placeholder implementation)
   */ estimatePhaseCost(questionCount, agentType) {
        const costPerQuestion = {
            'technical': 0.05,
            'behavioral': 0.03,
            'industry': 0.04
        };
        return questionCount * (costPerQuestion[agentType] || 0.03);
    }
    /**
   * Estimate token usage for a phase (placeholder implementation)
   */ estimatePhaseTokens(questionCount, agentType) {
        const tokensPerQuestion = {
            'technical': 150,
            'behavioral': 100,
            'industry': 120
        };
        return questionCount * (tokensPerQuestion[agentType] || 100);
    }
}

;// ./lib/azure-ai-foundry/workflows/interview-workflow.ts


/**
 * In-memory session store for simplicity. Replace with Redis/Firestore in production.
 */ const sessionStore = new Map();
/**
 * Default stage durations (minutes)
 */ const DEFAULT_STAGE_DURATIONS = {
    technical: 15,
    behavioral: 10,
    industry: 10,
    'wrap-up': 5
};
/**
 * Default questions per stage
 */ const DEFAULT_QUESTIONS_PER_STAGE = {
    technical: 6,
    behavioral: 5,
    industry: 4,
    'wrap-up': 0
};
/**
 * Map experience level to agent parameter adjustments
 */ function getExperienceAdjustments(level) {
    switch(level){
        case 'entry':
            return {
                temperature: 0.3,
                maxTokens: 1200
            };
        case 'senior':
            return {
                temperature: 0.6,
                maxTokens: 1800
            };
        case 'executive':
            return {
                temperature: 0.7,
                maxTokens: 2000
            };
        case 'mid':
        default:
            return {
                temperature: 0.5,
                maxTokens: 1500
            };
    }
}
/**
 * Build interview phases based on configuration
 */ function buildPhases(config) {
    const stages = config.customization?.enabledStages ?? [
        'technical',
        'behavioral',
        'industry',
        'wrap-up'
    ];
    const durations = {
        ...DEFAULT_STAGE_DURATIONS,
        ...config.customization?.stageDurations || {}
    };
    const questionCounts = {
        ...DEFAULT_QUESTIONS_PER_STAGE,
        ...config.customization?.questionsPerStage || {}
    };
    const base = [
        {
            id: 'technical',
            name: 'Technical Assessment',
            agentType: 'technical',
            duration: durations.technical,
            questionCount: questionCounts.technical,
            required: true,
            conditions: {
                minExperienceLevel: 'entry'
            },
            instructions: `Focus on ${config.role} fundamentals and practical problem solving.`
        },
        {
            id: 'behavioral',
            name: 'Behavioral Evaluation',
            agentType: 'behavioral',
            duration: durations.behavioral,
            questionCount: questionCounts.behavioral,
            required: true,
            instructions: 'Assess teamwork, leadership potential, and communication.'
        },
        {
            id: 'industry',
            name: 'Industry Knowledge Check',
            agentType: 'industry',
            duration: durations.industry,
            questionCount: questionCounts.industry,
            required: false,
            conditions: {
                minExperienceLevel: 'mid'
            },
            instructions: `Tailor to ${config.industry || config.companyInfo?.industry || 'the target'} industry.`
        },
        {
            id: 'wrap-up',
            name: 'Wrap-up and Feedback',
            agentType: 'behavioral',
            duration: durations['wrap-up'],
            questionCount: questionCounts['wrap-up'],
            required: true,
            instructions: 'Summarize key insights and provide feedback.'
        }
    ];
    return base.filter((s)=>stages.includes(s.id));
}
/**
 * InterviewWorkflow orchestrates a multi-agent interview using AgentOrchestrator
 */ class InterviewWorkflow {
    /**
   * Start a multi-agent interview and return a session ID
   */ async startMultiAgentInterview(config) {
        // Build phases and select agents
        const phases = buildPhases(config);
        // Adjust agent configs by experience level and apply any overrides
        const adjustments = getExperienceAdjustments(config.experienceLevel);
        // Transform candidateProfile to match CandidateProfile interface
        const transformedCandidateProfile = {
            name: config.candidateProfile.name,
            experience: `${config.experienceLevel} level`,
            skills: config.candidateProfile.skills,
            targetRole: config.role,
            industry: config.industry || config.companyInfo?.industry || 'Technology',
            previousRoles: config.candidateProfile.previousRoles,
            yearsExperience: config.candidateProfile.yearsExperience,
            education: config.candidateProfile.education,
            certifications: config.candidateProfile.certifications
        };
        // Build orchestrator session config
        const orchestratorConfig = this.orchestrator.createStandardSession({
            sessionId: config.sessionId,
            candidateProfile: transformedCandidateProfile,
            jobRole: config.role,
            companyInfo: config.companyInfo,
            experienceLevel: config.experienceLevel,
            includePhases: {
                technical: !!phases.find((p)=>p.id === 'technical'),
                behavioral: !!phases.find((p)=>p.id === 'behavioral'),
                industry: !!phases.find((p)=>p.id === 'industry')
            }
        });
        // Override default phase question counts and temps where applicable
        orchestratorConfig.phases = orchestratorConfig.phases.map((phase)=>{
            const def = phases.find((p)=>p.id === phase.id);
            if (!def) return phase;
            return {
                ...phase,
                questionCount: def.questionCount,
                agentConfig: {
                    ...phase.agentConfig || {},
                    temperature: config.customization?.agentOverrides?.[def.agentType]?.temperature ?? adjustments.temperature,
                    maxTokens: config.customization?.agentOverrides?.[def.agentType]?.maxTokens ?? adjustments.maxTokens
                }
            };
        });
        // Compose InterviewContext with focus areas and metadata
        const interviewContext = {
            candidateProfile: transformedCandidateProfile,
            jobRole: config.role,
            companyInfo: config.companyInfo,
            sessionHistory: undefined,
            focusAreas: config.customization?.focusAreas
        };
        // Initialize session state
        const startTime = Date.now();
        const totalEstimatedMinutes = phases.reduce((sum, p)=>sum + p.duration, 0);
        const state = {
            config,
            interviewContext,
            allQuestions: [],
            stageHistory: [],
            notes: [],
            persistence: {
                createdAt: startTime,
                updatedAt: startTime,
                version: '1.0.0',
                checkpoints: []
            },
            status: {
                sessionId: config.sessionId,
                state: 'initializing',
                currentStageIndex: 0,
                totalStages: phases.length,
                stages: phases.map((p)=>({
                        stage: p,
                        status: 'pending',
                        questionsGenerated: 0,
                        questionsAnswered: 0
                    })),
                progressPercentage: 0,
                timing: {
                    startTime,
                    currentTime: startTime,
                    elapsedMinutes: 0,
                    estimatedRemainingMinutes: totalEstimatedMinutes,
                    totalEstimatedMinutes
                },
                activeAgents: [],
                pendingAgents: phases.map((p)=>p.agentType),
                metrics: {
                    totalQuestionsGenerated: 0,
                    totalQuestionsAnswered: 0,
                    averageResponseTime: 0,
                    stageSwitches: 0,
                    agentHandoffs: 0
                }
            }
        };
        sessionStore.set(config.sessionId, state);
        // Start first phase immediately (no parallelism yet)
        await this.advanceStage(config.sessionId, orchestratorConfig);
        return config.sessionId;
    }
    /**
   * Get current workflow status
   */ async getStatus(sessionId) {
        const state = sessionStore.get(sessionId);
        if (!state) throw this.makeError('SESSION_NOT_FOUND', sessionId, 'Session not found', false);
        // Update timing
        const now = Date.now();
        const elapsedMinutes = Math.floor((now - state.status.timing.startTime) / 60000);
        const completedDurations = state.status.stages.filter((s)=>s.status === 'completed' || s.status === 'skipped').reduce((sum, s)=>sum + s.stage.duration, 0);
        const remaining = Math.max(state.status.timing.totalEstimatedMinutes - completedDurations, 0);
        state.status.timing.currentTime = now;
        state.status.timing.elapsedMinutes = elapsedMinutes;
        state.status.timing.estimatedRemainingMinutes = remaining;
        return state.status;
    }
    /**
   * Complete interview and return result
   */ async completeInterview(sessionId) {
        const state = sessionStore.get(sessionId);
        if (!state) throw this.makeError('SESSION_NOT_FOUND', sessionId, 'Session not found', false);
        // If not all stages are completed, mark remaining as skipped
        const remainingStages = state.status.stages.filter((s)=>s.status === 'pending' || s.status === 'in-progress');
        remainingStages.forEach((s)=>s.status = 'skipped');
        state.status.state = 'completed';
        // Build simple result (can be enhanced with AI-generated feedback later)
        const totalDuration = Math.floor((state.status.timing.currentTime - state.status.timing.startTime) / 60000);
        const stageResults = state.status.stages.map((s)=>({
                stage: s.stage,
                agent: s.stage.agentType,
                status: s.status,
                duration: s.stage.duration,
                questionsAsked: state.allQuestions.filter((q)=>q.stageId === s.stage.id),
                questionsAnswered: 0,
                keyInsights: [],
                recommendations: [],
                strengths: [],
                concerns: []
            }));
        const result = {
            sessionId,
            outcome: 'completed',
            summary: {
                totalDurationMinutes: totalDuration,
                stagesCompleted: state.status.stages.filter((s)=>s.status === 'completed').length,
                totalStages: state.status.totalStages,
                questionsAsked: state.allQuestions.length,
                questionsAnswered: 0
            },
            stageResults,
            feedback: {
                overallAssessment: 'Interview completed. AI-generated detailed assessment pending integration.',
                strengths: [],
                improvementAreas: [],
                roleFitAssessment: {
                    technicalFit: 0,
                    behavioralFit: 0,
                    industryKnowledge: 0,
                    overallFit: 0,
                    reasoning: 'Scoring to be computed by analysis pipeline.'
                },
                recommendations: {
                    hiring: 'maybe',
                    reasoning: 'Requires further analysis.',
                    nextSteps: [
                        'Review responses',
                        'Schedule follow-up if needed'
                    ]
                }
            },
            analytics: {
                metrics: {
                    averageResponseTime: 0,
                    questionDifficulty: 'medium',
                    knowledgeAreas: {},
                    confidenceLevel: 0,
                    communicationClarity: 0
                },
                patterns: {
                    responseLength: 'detailed',
                    questioningStyle: 'deep-diving',
                    confidenceIndicators: [],
                    stressIndicators: []
                }
            },
            exports: {
                reportAvailable: false
            },
            metadata: {
                generatedAt: Date.now(),
                generationDuration: 0,
                aiModelsUsed: Array.from(new Set(state.status.stages.map((s)=>s.stage.agentType))),
                totalCost: 0,
                totalTokensUsed: 0,
                qualityScore: 80
            }
        };
        return result;
    }
    /**
   * Advance to the next stage or execute current one if pending
   */ async advanceStage(sessionId, orchestratorConfig) {
        const state = sessionStore.get(sessionId);
        if (!state) throw this.makeError('SESSION_NOT_FOUND', sessionId, 'Session not found', false);
        const s = state.status;
        const currentIdx = s.currentStageIndex;
        const current = s.stages[currentIdx];
        // If all stages complete, update status
        if (currentIdx >= s.totalStages) {
            s.state = 'completed';
            return;
        }
        if (current.status === 'pending') {
            console.log(`[InterviewWorkflow] Starting stage: ${current.stage.name}`);
            current.status = 'in-progress';
            current.startTime = Date.now();
            s.state = 'in-progress';
            s.currentStage = current.stage.id;
            s.activeAgents = [
                current.stage.agentType
            ];
            s.pendingAgents = s.stages.slice(currentIdx + 1).map((x)=>x.stage.agentType);
            // Execute via orchestrator
            const runConfig = orchestratorConfig ?? this.orchestrator.createStandardSession({
                sessionId,
                candidateProfile: state.interviewContext.candidateProfile,
                jobRole: state.interviewContext.jobRole,
                companyInfo: state.interviewContext.companyInfo,
                experienceLevel: state.config.experienceLevel,
                includePhases: {
                    technical: current.stage.id === 'technical',
                    behavioral: current.stage.id === 'behavioral' || current.stage.id === 'wrap-up',
                    industry: current.stage.id === 'industry'
                }
            });
            const result = await this.orchestrator.startSession(runConfig);
            // Track generated questions
            const stageQuestions = result.allQuestions.map((q)=>({
                    ...q,
                    stageId: current.stage.id
                }));
            state.allQuestions.push(...stageQuestions);
            current.questionsGenerated += stageQuestions.length;
            s.metrics.totalQuestionsGenerated += stageQuestions.length;
            // Mark complete
            current.status = 'completed';
            current.endTime = Date.now();
            s.metrics.stageSwitches += 1;
            // Progress
            s.currentStageIndex += 1;
            s.progressPercentage = Math.round(s.currentStageIndex / s.totalStages * 100);
            // Move to next stage if exists
            if (s.currentStageIndex < s.totalStages) {
                const next = s.stages[s.currentStageIndex];
                s.currentStage = next.stage.id;
                s.activeAgents = [
                    next.stage.agentType
                ];
                s.pendingAgents = s.stages.slice(s.currentStageIndex + 1).map((x)=>x.stage.agentType);
            } else {
                s.currentStage = undefined;
                s.activeAgents = [];
                s.pendingAgents = [];
                s.state = 'completed';
            }
            state.persistence.updatedAt = Date.now();
        }
    }
    /** Utility to build standardized errors */ makeError(code, sessionId, message, recoverable) {
        const err = new Error(message);
        err.code = code;
        err.sessionId = sessionId;
        err.recoverable = recoverable;
        return err;
    }
    constructor(){
        this.factory = AgentFactory.getInstance();
        this.orchestrator = new AgentOrchestrator();
    }
}


/***/ })

};
;