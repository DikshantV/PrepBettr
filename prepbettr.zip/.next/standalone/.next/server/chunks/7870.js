"use strict";
exports.id = 7870;
exports.ids = [7870];
exports.modules = {

/***/ 82897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   db: () => (/* binding */ db),
/* harmony export */   hJ: () => (/* binding */ googleProvider),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony export app */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(67989);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91042);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75535);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  false ? 0 : null;
    const windowProjectId =  false ? 0 : null;
    const windowAuthDomain =  false ? 0 : null;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || `${finalProjectId}.firebaseapp.com`;
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (true) {
        console.log('🔥 Firebase initialization skipped on server side');
        return;
    }
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = getApps();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = initializeApp(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = getAuth(app);
        db = getFirestore(app);
        // Initialize Google Auth Provider
        googleProvider = new GoogleAuthProvider();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (false) {}
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (false) {}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});


/***/ }),

/***/ 87870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   KG: () => (/* binding */ validateFirebaseIdToken),
/* harmony export */   Xe: () => (/* binding */ authenticateWithGoogle),
/* harmony export */   getCurrentUserIdToken: () => (/* binding */ getCurrentUserIdToken)
/* harmony export */ });
/* unused harmony export signOutFromFirebase */
/* harmony import */ var _firebase_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(82897);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91042);
/**
 * Firebase Authentication Helper
 * 
 * Provides proper Firebase Google authentication flow
 * Ensures Firebase ID tokens are generated correctly
 */ 

/**
 * Authenticate with Google using Firebase
 * Returns Firebase ID token (not Google OAuth token)
 */ async function authenticateWithGoogle() {
    if (!_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2 || !_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .googleProvider */ .hJ) {
        throw new Error('Firebase Auth not initialized');
    }
    try {
        console.log('🔐 Starting Firebase Google authentication...');
        // Sign in with Google using Firebase
        const result = await (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .signInWithPopup */ .df)(_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2, _firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .googleProvider */ .hJ);
        const user = result.user;
        if (!user) {
            throw new Error('No user returned from Google authentication');
        }
        console.log('🔐 Google authentication successful, getting Firebase ID token...');
        // Get Firebase ID token (this is crucial - not Google OAuth token)
        const idToken = await (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .getIdToken */ .p9)(user, true); // Force refresh to ensure fresh token
        console.log('🔐 Firebase ID token obtained successfully');
        console.log('🔐 Token preview:', idToken.substring(0, 50) + '...');
        // Validate token format (Firebase ID tokens are JWT)
        if (!idToken.includes('.')) {
            throw new Error('Invalid Firebase ID token format - not a JWT');
        }
        return {
            user: {
                uid: user.uid,
                email: user.email,
                displayName: user.displayName,
                photoURL: user.photoURL,
                emailVerified: user.emailVerified
            },
            idToken
        };
    } catch (error) {
        console.error('🔐 Firebase Google authentication failed:', error);
        throw error;
    }
}
/**
 * Sign out from Firebase
 */ async function signOutFromFirebase() {
    if (!auth) {
        throw new Error('Firebase Auth not initialized');
    }
    try {
        await auth.signOut();
        console.log('🔐 Firebase sign out successful');
    } catch (error) {
        console.error('🔐 Firebase sign out failed:', error);
        throw error;
    }
}
/**
 * Get current Firebase user's ID token
 */ async function getCurrentUserIdToken(forceRefresh = false) {
    if (!_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2?.currentUser) {
        throw new Error('No Firebase user signed in');
    }
    try {
        const idToken = await (0,firebase_auth__WEBPACK_IMPORTED_MODULE_1__/* .getIdToken */ .p9)(_firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2.currentUser, forceRefresh);
        console.log('🔐 Current user ID token obtained');
        return idToken;
    } catch (error) {
        console.error('🔐 Failed to get current user ID token:', error);
        throw error;
    }
}
/**
 * Validate Firebase ID token format
 */ function validateFirebaseIdToken(token) {
    if (!token || typeof token !== 'string') {
        return false;
    }
    // Firebase ID tokens are JWTs with 3 parts separated by dots
    const parts = token.split('.');
    if (parts.length !== 3) {
        return false;
    }
    try {
        // Try to decode the payload (second part)
        const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
        // Firebase ID tokens should have these claims
        return payload.iss && payload.aud && payload.exp && payload.iat && payload.sub && payload.iss.includes('securetoken.google.com');
    } catch  {
        return false;
    }
}


/***/ })

};
;