exports.id = 9757;
exports.ids = [6502,9757];
exports.modules = {

/***/ 486:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ TestHelperInitializer)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/**
 * Test Helper Initializer for E2E Testing
 * 
 * This component exposes test helper functions to the browser window object
 * during E2E tests, allowing Playwright tests to simulate various scenarios
 * like voice transcripts, agent failures, network issues, and session state.
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 
function TestHelperInitializer() {
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // Only initialize test helpers in test environment
        if ( true && !process.env.PLAYWRIGHT_TEST) {
            return;
        }
        // Store interview session state
        let currentSession = null;
        let currentResults = null;
        // Voice transcript simulation
        window.simulateVoiceTranscript = (transcript)=>{
            console.log('🎤 Test Helper: Simulating voice transcript:', transcript);
            // Trigger voice transcript event
            const event = new CustomEvent('voiceTranscript', {
                detail: {
                    transcript,
                    confidence: 0.95,
                    isFinal: true,
                    timestamp: Date.now()
                }
            });
            document.dispatchEvent(event);
            // Also dispatch to any voice components that might be listening
            const voiceEvents = [
                'speechResult',
                'transcriptionResult'
            ];
            voiceEvents.forEach((eventType)=>{
                const voiceEvent = new CustomEvent(eventType, {
                    detail: {
                        transcript,
                        confidence: 0.95,
                        isFinal: true
                    }
                });
                document.dispatchEvent(voiceEvent);
            });
        };
        // Agent failure simulation
        window.simulateAgentFailure = (agentType)=>{
            console.log('❌ Test Helper: Simulating agent failure for:', agentType);
            const event = new CustomEvent('agentFailure', {
                detail: {
                    agentType,
                    error: `Simulated ${agentType} agent failure`,
                    timestamp: Date.now(),
                    recoverable: true
                }
            });
            document.dispatchEvent(event);
        };
        // Network interruption simulation
        window.simulateNetworkInterruption = (duration = 5000)=>{
            console.log('🌐 Test Helper: Simulating network interruption for', duration, 'ms');
            // Simulate connection lost
            const disconnectEvent = new CustomEvent('connectionLost', {
                detail: {
                    timestamp: Date.now(),
                    duration
                }
            });
            document.dispatchEvent(disconnectEvent);
            // Simulate connection restored after duration
            setTimeout(()=>{
                const reconnectEvent = new CustomEvent('connectionRestored', {
                    detail: {
                        timestamp: Date.now()
                    }
                });
                document.dispatchEvent(reconnectEvent);
                // Add visual indicator for tests
                const indicator = document.createElement('div');
                indicator.setAttribute('data-testid', 'connection-restored');
                indicator.style.display = 'none';
                document.body.appendChild(indicator);
            }, duration);
        };
        // Session timeout simulation
        window.simulateSessionTimeout = ()=>{
            console.log('⏰ Test Helper: Simulating session timeout');
            const event = new CustomEvent('sessionTimeout', {
                detail: {
                    timestamp: Date.now()
                }
            });
            document.dispatchEvent(event);
        };
        // Test helper utilities
        window.testHelpers = {
            setInterviewSession: (session)=>{
                console.log('📝 Test Helper: Setting interview session', session);
                currentSession = session;
                window.interviewSession = session;
                // Add session indicators for tests
                const sessionIndicator = document.createElement('div');
                sessionIndicator.setAttribute('data-testid', 'interview-session-active');
                sessionIndicator.style.display = 'none';
                document.body.appendChild(sessionIndicator);
                const sessionIdIndicator = document.createElement('div');
                sessionIdIndicator.setAttribute('data-testid', 'session-id');
                sessionIdIndicator.setAttribute('data-session-id', session.id || session.config?.sessionId || 'test-session');
                sessionIdIndicator.style.display = 'none';
                document.body.appendChild(sessionIdIndicator);
            },
            setInterviewResults: (results)=>{
                console.log('📊 Test Helper: Setting interview results', results);
                currentResults = results;
                window.interviewResults = results;
                // Add results indicator for tests
                const resultsIndicator = document.createElement('div');
                resultsIndicator.setAttribute('data-testid', 'results-ready');
                resultsIndicator.style.display = 'none';
                document.body.appendChild(resultsIndicator);
            },
            triggerError: (errorType, details)=>{
                console.log('💥 Test Helper: Triggering error:', errorType, details);
                const event = new CustomEvent('testError', {
                    detail: {
                        errorType,
                        details,
                        timestamp: Date.now()
                    }
                });
                document.dispatchEvent(event);
            }
        };
        // Add global test indicators
        const addTestIndicator = (testId, condition = true)=>{
            if (condition && !document.querySelector(`[data-testid="${testId}"]`)) {
                const indicator = document.createElement('div');
                indicator.setAttribute('data-testid', testId);
                indicator.style.display = 'none';
                document.body.appendChild(indicator);
            }
        };
        // Add common test indicators
        addTestIndicator('voice-ready-indicator');
        addTestIndicator('voice-active-indicator');
        addTestIndicator('agent-handoff-pending');
        addTestIndicator('agent-handoff-complete');
        addTestIndicator('backup-agent-active');
        addTestIndicator('system-recovered');
        addTestIndicator('interview-resumed');
        addTestIndicator('response-processed');
        // Mock current agent indicator
        const currentAgentIndicator = document.createElement('div');
        currentAgentIndicator.setAttribute('data-testid', 'current-agent');
        currentAgentIndicator.textContent = 'TechnicalInterviewer';
        currentAgentIndicator.style.display = 'none';
        document.body.appendChild(currentAgentIndicator);
        // Mock current phase indicator
        const currentPhaseIndicator = document.createElement('div');
        currentPhaseIndicator.setAttribute('data-testid', 'current-phase');
        currentPhaseIndicator.textContent = 'technical';
        currentPhaseIndicator.style.display = 'none';
        document.body.appendChild(currentPhaseIndicator);
        // Mock questions answered counter
        const questionsAnsweredIndicator = document.createElement('div');
        questionsAnsweredIndicator.setAttribute('data-testid', 'questions-answered-count');
        questionsAnsweredIndicator.textContent = '0';
        questionsAnsweredIndicator.style.display = 'none';
        document.body.appendChild(questionsAnsweredIndicator);
        console.log('✅ Test helpers initialized for E2E testing');
        // Cleanup function
        return ()=>{
            // Remove test helpers from window
            delete window.simulateVoiceTranscript;
            delete window.simulateAgentFailure;
            delete window.simulateNetworkInterruption;
            delete window.simulateSessionTimeout;
            delete window.testHelpers;
            delete window.interviewSession;
            delete window.interviewResults;
        };
    }, []);
    // This component renders nothing - it's just for side effects
    return null;
}


/***/ }),

/***/ 605:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94515));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52631));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5779));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 10796));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19760));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 486));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51108));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43410));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52581));


/***/ }),

/***/ 5779:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ NetworkLoggerInit)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
;// ./lib/utils/network-logger.ts
/* __next_internal_client_entry_do_not_use__ initNetworkLogger,getNetworkCalls,getAuthCalls,getCallsToEndpoint,analyzeLoops,clearNetworkHistory,displayNetworkStats,getNetworkStats auto */ const networkCalls = (/* unused pure expression or super */ null && ([]));
const originalFetch =  false ? 0 : null;
/**
 * Initialize network logging
 */ function initNetworkLogger() {
    if (true) {
        return;
    }
    console.log('🔍 Network logger initialized - tracing all fetch calls');
    // Monkey patch window.fetch
    window.fetch = function(...args) {
        const [input, init] = args;
        const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url;
        const method = init?.method || 'GET';
        // Create error to capture stack trace
        const error = new Error();
        const stack = error.stack || '';
        // Extract caller information from stack trace
        const stackLines = stack.split('\n');
        const caller = stackLines[2]?.trim() || 'unknown';
        const networkCall = {
            url,
            method,
            timestamp: Date.now(),
            stack,
            caller
        };
        networkCalls.push(networkCall);
        // Log auth-related calls immediately
        if (url.includes('/api/auth/')) {
            console.group(`🔍 AUTH API CALL: ${method} ${url}`);
            console.log('Timestamp:', new Date(networkCall.timestamp).toISOString());
            console.log('Caller:', caller);
            console.log('Full stack:', stack);
            console.groupEnd();
        }
        // Log dashboard-related calls immediately
        if (url.includes('/api/dashboard/') || url.includes('/dashboard')) {
            console.group(`📊 DASHBOARD API CALL: ${method} ${url}`);
            console.log('Timestamp:', new Date(networkCall.timestamp).toISOString());
            console.log('Caller:', caller);
            console.log('Full stack:', stack);
            console.groupEnd();
        }
        // Log sync-firebase calls (potential polling source)
        if (url.includes('/api/auth/sync-firebase')) {
            console.group(`🔄 SYNC-FIREBASE CALL: ${method} ${url}`);
            console.log('Timestamp:', new Date(networkCall.timestamp).toISOString());
            console.log('Caller:', caller);
            console.warn('⚠️  This may be part of a polling loop!');
            console.log('Full stack:', stack);
            console.groupEnd();
        }
        // Call original fetch
        return originalFetch.apply(this, args);
    };
}
/**
 * Get all network calls
 */ function getNetworkCalls() {
    return [
        ...networkCalls
    ];
}
/**
 * Get auth-related network calls
 */ function getAuthCalls() {
    return networkCalls.filter((call)=>call.url.includes('/api/auth/'));
}
/**
 * Get calls to specific endpoint
 */ function getCallsToEndpoint(endpoint) {
    return networkCalls.filter((call)=>call.url.includes(endpoint));
}
/**
 * Analyze call frequency for potential loops
 */ function analyzeLoops(windowMs = 5000) {
    const now = Date.now();
    const recentCalls = networkCalls.filter((call)=>now - call.timestamp <= windowMs);
    const endpointCounts = recentCalls.reduce((acc, call)=>{
        acc[call.url] = (acc[call.url] || 0) + 1;
        return acc;
    }, {});
    return Object.entries(endpointCounts).map(([endpoint, count])=>({
            endpoint,
            count,
            frequency: count / (windowMs / 1000),
            isLoop: count > 3 // More than 3 calls in window indicates a potential loop
        }));
}
/**
 * Clear network call history
 */ function clearNetworkHistory() {
    networkCalls.length = 0;
    console.log('🗑️ Network call history cleared');
}
/**
 * Display current network statistics
 */ function displayNetworkStats() {
    if (true) return;
    const authCalls = getAuthCalls();
    const loops = analyzeLoops();
    console.group('📊 Network Statistics');
    console.log(`Total calls: ${networkCalls.length}`);
    console.log(`Auth calls: ${authCalls.length}`);
    if (loops.length > 0) {
        console.group('🔄 Potential loops detected:');
        loops.filter((l)=>l.isLoop).forEach((loop)=>{
            console.warn(`${loop.endpoint}: ${loop.count} calls (${loop.frequency.toFixed(1)}/s)`);
        });
        console.groupEnd();
    }
    if (authCalls.length > 0) {
        console.group('🔐 Recent auth calls:');
        authCalls.slice(-5).forEach((call)=>{
            console.log(`${call.method} ${call.url} - ${call.caller}`);
        });
        console.groupEnd();
    }
    console.groupEnd();
}
/**
 * Export network statistics for testing
 */ function getNetworkStats() {
    return {
        totalCalls: networkCalls.length,
        authCalls: getAuthCalls().length,
        loops: analyzeLoops(),
        recentAuthCalls: getAuthCalls().slice(-10)
    };
}
// Auto-display stats every 10 seconds in development (DISABLED to prevent polling)
// if (typeof window !== 'undefined' && process.env.NODE_ENV === 'development') {
//   setInterval(displayNetworkStats, 10000);
// }
// Instead, provide manual trigger for debugging:
if (false) {}

;// ./components/NetworkLoggerInit.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

function NetworkLoggerInit() {
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        // Only initialize network logger if explicitly enabled in development
        if (false) {}
    }, []);
    return null;
}


/***/ }),

/***/ 10796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  TelemetryProvider: () => (/* binding */ TelemetryProvider),
  J: () => (/* binding */ useTelemetry)
});

// UNUSED EXPORTS: default

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js
var react_jsx_runtime = __webpack_require__(60687);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js
var react = __webpack_require__(43210);
// EXTERNAL MODULE: ./node_modules/next/dist/api/navigation.js
var navigation = __webpack_require__(16189);
// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(51108);
;// ./lib/utils/telemetry-stub.ts
// lib/utils/telemetry-stub.ts
// Temporary telemetry stub to allow testing without server-only dependencies
class TelemetryStubService {
    async initialize() {
        if (this.isInitialized) return;
        console.log('📊 Telemetry stub initialized (no actual telemetry)');
        this.isInitialized = true;
    }
    async trackPageView(pageView) {
        console.log(`📊 [STUB] Page view: ${pageView.name}`, pageView);
    }
    async trackEvent(event) {
        console.log(`📊 [STUB] Event: ${event.name}`, event);
    }
    async trackUserAction(action) {
        console.log(`📊 [STUB] User action: ${action.action} on ${action.feature}`, action);
    }
    async trackFeatureUsage(featureName, userId, properties) {
        console.log(`📊 [STUB] Feature usage: ${featureName}`, {
            userId,
            properties
        });
    }
    async trackMetric(metric) {
        console.log(`📈 [STUB] Metric: ${metric.name} = ${metric.value}`, metric);
    }
    async trackBusinessMetric(metricName, value, userId, properties) {
        console.log(`💼 [STUB] Business metric: ${metricName} = ${value}`, {
            userId,
            properties
        });
    }
    async trackInterviewCompletion(userId, interviewId, questionCount, duration, score) {
        console.log(`🎯 [STUB] Interview completed:`, {
            userId,
            interviewId,
            questionCount,
            duration,
            score
        });
    }
    async trackResumeUpload(userId, fileSize, mimeType, processingTime) {
        console.log(`📄 [STUB] Resume uploaded:`, {
            userId,
            fileSize,
            mimeType,
            processingTime
        });
    }
    async trackFormSubmission(formName, userId, success, properties) {
        console.log(`📝 [STUB] Form submitted: ${formName}`, {
            userId,
            success,
            properties
        });
    }
    async trackButtonClick(buttonName, location, userId, properties) {
        console.log(`🔘 [STUB] Button clicked: ${buttonName} at ${location}`, {
            userId,
            properties
        });
    }
    async trackSubscription(userId, action, plan, revenue) {
        console.log(`💳 [STUB] Subscription ${action}: ${plan}`, {
            userId,
            revenue
        });
    }
    async trackError(errorInfo) {
        console.log(`🚨 [STUB] Error tracked: ${errorInfo.error.message}`, errorInfo);
    }
    async setUser(userId, email, properties) {
        console.log(`👤 [STUB] User context set: ${userId}`, {
            email,
            properties
        });
    }
    async clearUser() {
        console.log('👤 [STUB] User context cleared');
    }
    async trackABTest(testName, variant, userId) {
        console.log(`🧪 [STUB] A/B test: ${testName} = ${variant}`, {
            userId
        });
    }
    async trackConversion(conversionType, value, userId, properties) {
        console.log(`🎯 [STUB] Conversion: ${conversionType}`, {
            value,
            userId,
            properties
        });
    }
    async flush() {
        console.log('🚿 [STUB] Telemetry flushed');
    }
    getReactPlugin() {
        return null;
    }
    getAppInsights() {
        return null;
    }
    constructor(){
        this.isInitialized = false;
        this.isClient = "undefined" !== 'undefined';
    }
}
// Export singleton instance
const telemetry = new TelemetryStubService();
/* harmony default export */ const telemetry_stub = ((/* unused pure expression or super */ null && (telemetry)));

;// ./components/providers/TelemetryProvider.tsx
/* __next_internal_client_entry_do_not_use__ TelemetryProvider,useTelemetry,default auto */ 




const TelemetryContext = /*#__PURE__*/ (0,react.createContext)(null);
function TelemetryProvider({ children }) {
    const [isInitialized, setIsInitialized] = (0,react.useState)(false);
    const router = (0,navigation.useRouter)();
    const { user } = (0,AuthContext/* useAuth */.A)();
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        const initTelemetry = async ()=>{
            try {
                await telemetry.initialize();
                setIsInitialized(true);
                // Track initial page view
                await telemetry.trackPageView({
                    name: document.title,
                    uri: window.location.pathname + window.location.search,
                    userId: user?.uid,
                    isLoggedIn: !!user
                });
            } catch (error) {
                console.error('Failed to initialize telemetry:', error);
            }
        };
        initTelemetry();
    }, [
        user
    ]);
    // Set user context when user changes
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        const updateUserContext = async ()=>{
            if (!isInitialized) return;
            if (user) {
                await telemetry.setUser(user.uid, user.email || undefined, {
                    isEmailVerified: user.email_verified?.toString() || 'false',
                    creationTime: 'unknown' // metadata not available in AuthenticatedUser type
                });
            } else {
                await telemetry.clearUser();
            }
        };
        updateUserContext();
    }, [
        user,
        isInitialized
    ]);
    // Track route changes
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react.useEffect)(()=>{
        if (!isInitialized) return;
        const handleRouteChange = async (url)=>{
            await telemetry.trackPageView({
                name: document.title,
                uri: url,
                userId: user?.uid,
                isLoggedIn: !!user
            });
        };
        // For Next.js app router, we need to listen for navigation events differently
        // This is a simplified version - you might need to adjust based on your routing setup
        const originalPushState = window.history.pushState;
        const originalReplaceState = window.history.replaceState;
        window.history.pushState = function(...args) {
            originalPushState.apply(this, args);
            handleRouteChange(window.location.pathname + window.location.search);
        };
        window.history.replaceState = function(...args) {
            originalReplaceState.apply(this, args);
            handleRouteChange(window.location.pathname + window.location.search);
        };
        window.addEventListener('popstate', ()=>{
            handleRouteChange(window.location.pathname + window.location.search);
        });
        return ()=>{
            window.history.pushState = originalPushState;
            window.history.replaceState = originalReplaceState;
            window.removeEventListener('popstate', ()=>{});
        };
    }, [
        isInitialized,
        user
    ]);
    const contextValue = {
        trackPageView: async (name, properties)=>{
            await telemetry.trackPageView({
                name,
                uri: window.location.pathname + window.location.search,
                userId: user?.uid,
                isLoggedIn: !!user,
                properties
            });
        },
        trackEvent: async (name, properties, measurements)=>{
            await telemetry.trackEvent({
                name,
                properties: {
                    userId: user?.uid || 'anonymous',
                    ...properties
                },
                measurements
            });
        },
        trackUserAction: async (action, feature, properties)=>{
            await telemetry.trackUserAction({
                action,
                feature,
                userId: user?.uid,
                properties
            });
        },
        trackFeatureUsage: async (featureName, properties)=>{
            await telemetry.trackFeatureUsage(featureName, user?.uid, properties);
        },
        trackButtonClick: async (buttonName, properties)=>{
            await telemetry.trackButtonClick(buttonName, window.location.pathname, user?.uid, properties);
        },
        trackFormSubmission: async (formName, success, properties)=>{
            await telemetry.trackFormSubmission(formName, user?.uid, success, properties);
        },
        trackInterviewCompletion: async (interviewId, questionCount, duration, score)=>{
            if (!user?.uid) return;
            await telemetry.trackInterviewCompletion(user.uid, interviewId, questionCount, duration, score);
        },
        trackResumeUpload: async (fileSize, mimeType, processingTime)=>{
            if (!user?.uid) return;
            await telemetry.trackResumeUpload(user.uid, fileSize, mimeType, processingTime);
        },
        trackError: async (error, context)=>{
            await telemetry.trackError({
                error,
                userId: user?.uid,
                context
            });
        },
        isInitialized
    };
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(TelemetryContext.Provider, {
        value: contextValue,
        children: children
    });
}
function useTelemetry() {
    const context = (0,react.useContext)(TelemetryContext);
    if (!context) {
        throw new Error('useTelemetry must be used within a TelemetryProvider');
    }
    return context;
}
/* harmony default export */ const providers_TelemetryProvider = ((/* unused pure expression or super */ null && (TelemetryProvider)));


/***/ }),

/***/ 19760:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RouterLoadingHandler: () => (/* binding */ RouterLoadingHandler)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_LoadingContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43410);
/* __next_internal_client_entry_do_not_use__ RouterLoadingHandler auto */ 

const RouterLoadingHandler = ()=>{
    const { showLoader, hideLoader } = (0,_contexts_LoadingContext__WEBPACK_IMPORTED_MODULE_1__/* .useLoading */ .M)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        let navigationTimer = null;
        // Listen for browser navigation (back/forward buttons)
        const handlePopState = ()=>{
            showLoader('', 500);
            // Auto-hide after a maximum time to prevent infinite loading
            navigationTimer = setTimeout(()=>{
                hideLoader(true); // Force hide
            }, 3000); // 3 seconds max
        };
        // Listen for page load completion
        const handleLoad = ()=>{
            if (navigationTimer) {
                clearTimeout(navigationTimer);
            }
            hideLoader();
        };
        // Listen for DOM content loaded (faster than full load)
        const handleDOMContentLoaded = ()=>{
            if (navigationTimer) {
                clearTimeout(navigationTimer);
            }
            hideLoader();
        };
        // Only listen to popstate for browser navigation
        window.addEventListener('popstate', handlePopState);
        window.addEventListener('load', handleLoad);
        window.addEventListener('DOMContentLoaded', handleDOMContentLoaded);
        // Clean up on unmount
        return ()=>{
            if (navigationTimer) {
                clearTimeout(navigationTimer);
            }
            window.removeEventListener('popstate', handlePopState);
            window.removeEventListener('load', handleLoad);
            window.removeEventListener('DOMContentLoaded', handleDOMContentLoaded);
        };
    }, [
        showLoader,
        hideLoader
    ]);
    return null;
};


/***/ }),

/***/ 24824:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 16444, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 16042, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 88170, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 49477, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 29345, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 12089, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 46577, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 31307, 23));


/***/ }),

/***/ 29296:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LoadingProvider: () => (/* binding */ LoadingProvider)
/* harmony export */ });
/* unused harmony export useLoading */
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

const LoadingProvider = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call LoadingProvider() from the server but LoadingProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/contexts/LoadingContext.tsx",
"LoadingProvider",
);const useLoading = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call useLoading() from the server but useLoading is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/contexts/LoadingContext.tsx",
"useLoading",
);

/***/ }),

/***/ 30461:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78972));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 59953));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 59337));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72076));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54310));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 58792));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94442));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 29296));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6931));


/***/ }),

/***/ 34552:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 86346, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 27924, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 35656, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 40099, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 38243, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 28827, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 62763, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 97173, 23));


/***/ }),

/***/ 36371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(47237);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57048);




const Loader = ({ overlay = false, text, backgroundOpacity = 80, blur = true, className, ariaLabel = 'Loading...' })=>{
    const loaderContent = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledWrapper, {
        className: className,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "banter-loader",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "banter-loader__box"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "banter-loader__box"
                    })
                ]
            }),
            overlay && text && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                className: "text-white text-center mt-4 font-medium",
                "aria-live": "polite",
                children: text
            })
        ]
    });
    if (overlay) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("fixed inset-0 z-50 flex items-center justify-center flex-col", blur && "backdrop-blur-md", "transition-all duration-300"),
            style: {
                backgroundColor: `rgba(0, 0, 0, ${backgroundOpacity / 100})`,
                backdropFilter: blur ? 'blur(8px)' : 'none',
                WebkitBackdropFilter: blur ? 'blur(8px)' : 'none'
            },
            role: "dialog",
            "aria-modal": "true",
            "aria-label": ariaLabel,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "relative",
                children: loaderContent
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        role: "status",
        "aria-label": ariaLabel,
        children: loaderContent
    });
};
const StyledWrapper = styled_components__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Ay.div`
  .banter-loader {
    position: relative;
    width: 72px;
    height: 72px;
    margin: 0 auto;
  }

  .banter-loader__box {
    float: left;
    position: relative;
    width: 20px;
    height: 20px;
    margin-right: 6px;
  }

  .banter-loader__box:before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: #fff;
  }

  .banter-loader__box:nth-child(3n) {
    margin-right: 0;
    margin-bottom: 6px;
  }

  .banter-loader__box:nth-child(1):before, .banter-loader__box:nth-child(4):before {
    margin-left: 26px;
  }

  .banter-loader__box:nth-child(3):before {
    margin-top: 52px;
  }

  .banter-loader__box:last-child {
    margin-bottom: 0;
  }

  @keyframes moveBox-1 {
    9.0909090909% {
      transform: translate(-26px, 0);
    }

    18.1818181818% {
      transform: translate(0px, 0);
    }

    27.2727272727% {
      transform: translate(0px, 0);
    }

    36.3636363636% {
      transform: translate(26px, 0);
    }

    45.4545454545% {
      transform: translate(26px, 26px);
    }

    54.5454545455% {
      transform: translate(26px, 26px);
    }

    63.6363636364% {
      transform: translate(26px, 26px);
    }

    72.7272727273% {
      transform: translate(26px, 0px);
    }

    81.8181818182% {
      transform: translate(0px, 0px);
    }

    90.9090909091% {
      transform: translate(-26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(1) {
    animation: moveBox-1 4s infinite;
  }

  @keyframes moveBox-2 {
    9.0909090909% {
      transform: translate(0, 0);
    }

    18.1818181818% {
      transform: translate(26px, 0);
    }

    27.2727272727% {
      transform: translate(0px, 0);
    }

    36.3636363636% {
      transform: translate(26px, 0);
    }

    45.4545454545% {
      transform: translate(26px, 26px);
    }

    54.5454545455% {
      transform: translate(26px, 26px);
    }

    63.6363636364% {
      transform: translate(26px, 26px);
    }

    72.7272727273% {
      transform: translate(26px, 26px);
    }

    81.8181818182% {
      transform: translate(0px, 26px);
    }

    90.9090909091% {
      transform: translate(0px, 26px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(2) {
    animation: moveBox-2 4s infinite;
  }

  @keyframes moveBox-3 {
    9.0909090909% {
      transform: translate(-26px, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(0px, 0);
    }

    36.3636363636% {
      transform: translate(-26px, 0);
    }

    45.4545454545% {
      transform: translate(-26px, 0);
    }

    54.5454545455% {
      transform: translate(-26px, 0);
    }

    63.6363636364% {
      transform: translate(-26px, 0);
    }

    72.7272727273% {
      transform: translate(-26px, 0);
    }

    81.8181818182% {
      transform: translate(-26px, -26px);
    }

    90.9090909091% {
      transform: translate(0px, -26px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(3) {
    animation: moveBox-3 4s infinite;
  }

  @keyframes moveBox-4 {
    9.0909090909% {
      transform: translate(-26px, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(-26px, -26px);
    }

    36.3636363636% {
      transform: translate(0px, -26px);
    }

    45.4545454545% {
      transform: translate(0px, 0px);
    }

    54.5454545455% {
      transform: translate(0px, -26px);
    }

    63.6363636364% {
      transform: translate(0px, -26px);
    }

    72.7272727273% {
      transform: translate(0px, -26px);
    }

    81.8181818182% {
      transform: translate(-26px, -26px);
    }

    90.9090909091% {
      transform: translate(-26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(4) {
    animation: moveBox-4 4s infinite;
  }

  @keyframes moveBox-5 {
    9.0909090909% {
      transform: translate(0, 0);
    }

    18.1818181818% {
      transform: translate(0, 0);
    }

    27.2727272727% {
      transform: translate(0, 0);
    }

    36.3636363636% {
      transform: translate(26px, 0);
    }

    45.4545454545% {
      transform: translate(26px, 0);
    }

    54.5454545455% {
      transform: translate(26px, 0);
    }

    63.6363636364% {
      transform: translate(26px, 0);
    }

    72.7272727273% {
      transform: translate(26px, 0);
    }

    81.8181818182% {
      transform: translate(26px, -26px);
    }

    90.9090909091% {
      transform: translate(0px, -26px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(5) {
    animation: moveBox-5 4s infinite;
  }

  @keyframes moveBox-6 {
    9.0909090909% {
      transform: translate(0, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(-26px, 0);
    }

    36.3636363636% {
      transform: translate(0px, 0);
    }

    45.4545454545% {
      transform: translate(0px, 0);
    }

    54.5454545455% {
      transform: translate(0px, 0);
    }

    63.6363636364% {
      transform: translate(0px, 0);
    }

    72.7272727273% {
      transform: translate(0px, 26px);
    }

    81.8181818182% {
      transform: translate(-26px, 26px);
    }

    90.9090909091% {
      transform: translate(-26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(6) {
    animation: moveBox-6 4s infinite;
  }

  @keyframes moveBox-7 {
    9.0909090909% {
      transform: translate(26px, 0);
    }

    18.1818181818% {
      transform: translate(26px, 0);
    }

    27.2727272727% {
      transform: translate(26px, 0);
    }

    36.3636363636% {
      transform: translate(0px, 0);
    }

    45.4545454545% {
      transform: translate(0px, -26px);
    }

    54.5454545455% {
      transform: translate(26px, -26px);
    }

    63.6363636364% {
      transform: translate(0px, -26px);
    }

    72.7272727273% {
      transform: translate(0px, -26px);
    }

    81.8181818182% {
      transform: translate(0px, 0px);
    }

    90.9090909091% {
      transform: translate(26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(7) {
    animation: moveBox-7 4s infinite;
  }

  @keyframes moveBox-8 {
    9.0909090909% {
      transform: translate(0, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(-26px, -26px);
    }

    36.3636363636% {
      transform: translate(0px, -26px);
    }

    45.4545454545% {
      transform: translate(0px, -26px);
    }

    54.5454545455% {
      transform: translate(0px, -26px);
    }

    63.6363636364% {
      transform: translate(0px, -26px);
    }

    72.7272727273% {
      transform: translate(0px, -26px);
    }

    81.8181818182% {
      transform: translate(26px, -26px);
    }

    90.9090909091% {
      transform: translate(26px, 0px);
    }

    100% {
      transform: translate(0px, 0px);
    }
  }

  .banter-loader__box:nth-child(8) {
    animation: moveBox-8 4s infinite;
  }

  @keyframes moveBox-9 {
    9.0909090909% {
      transform: translate(-26px, 0);
    }

    18.1818181818% {
      transform: translate(-26px, 0);
    }

    27.2727272727% {
      transform: translate(0px, 0);
    }

    36.3636363636% {
      transform: translate(-26px, 0);
    }

    45.4545454545% {
      transform: translate(0px, 0);
    }

    54.5454545455% {
      transform: translate(0px, 0);
    }

    63.6363636364% {
      transform: translate(-26px, 0);
    }

    72.7272727273% {
      transform: translate(-26px, 0);
    }

    81.8181818182% {
      transform: translate(-52px, 0);
    }

    90.9090909091% {
      transform: translate(-26px, 0);
    }

    100% {
      transform: translate(0px, 0);
    }
  }

  .banter-loader__box:nth-child(9) {
    animation: moveBox-9 4s infinite;
  }
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ }),

/***/ 43410:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LoadingProvider: () => (/* binding */ LoadingProvider),
/* harmony export */   M: () => (/* binding */ useLoading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_BanterLoader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36371);
/* __next_internal_client_entry_do_not_use__ LoadingProvider,useLoading auto */ 


const LoadingContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(undefined);
const LoadingProvider = ({ children })=>{
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [loadingText, setLoadingText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('Loading...');
    const [minimumDuration, setMinimumDuration] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(500); // Minimum 500ms loading time
    const timeoutRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const startTimeRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const safetyTimeoutRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const showLoader = (text = 'Loading...', minDuration)=>{
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
        if (safetyTimeoutRef.current) {
            clearTimeout(safetyTimeoutRef.current);
        }
        setLoadingText(text);
        setIsLoading(true);
        startTimeRef.current = Date.now();
        if (minDuration !== undefined) {
            setMinimumDuration(minDuration);
        }
        // Safety timeout: force hide after 5 seconds to prevent infinite loading
        safetyTimeoutRef.current = setTimeout(()=>{
            console.warn('Loading timeout reached, force hiding loader');
            setIsLoading(false);
            startTimeRef.current = null;
        }, 5000);
    };
    const hideLoader = (force = false)=>{
        // Clear safety timeout
        if (safetyTimeoutRef.current) {
            clearTimeout(safetyTimeoutRef.current);
        }
        if (force) {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
            setIsLoading(false);
            startTimeRef.current = null;
            return;
        }
        const elapsedTime = startTimeRef.current ? Date.now() - startTimeRef.current : 0;
        const remainingTime = Math.max(0, minimumDuration - elapsedTime);
        if (remainingTime > 0) {
            timeoutRef.current = setTimeout(()=>{
                setIsLoading(false);
                startTimeRef.current = null;
            }, remainingTime);
        } else {
            setIsLoading(false);
            startTimeRef.current = null;
        }
    };
    const value = {
        isLoading,
        loadingText,
        showLoader,
        hideLoader,
        setMinimumDuration: (duration)=>setMinimumDuration(duration)
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(LoadingContext.Provider, {
        value: value,
        children: [
            children,
            isLoading && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_ui_BanterLoader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A, {
                overlay: true,
                text: loadingText
            })
        ]
    });
};
const useLoading = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(LoadingContext);
    if (!context) {
        throw new Error('useLoading must be used within a LoadingProvider');
    }
    return context;
};


/***/ }),

/***/ 46502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   j: () => (/* binding */ RetryWithBackoff),
/* harmony export */   y: () => (/* binding */ retryWithExponentialBackoff)
/* harmony export */ });

class RetryWithBackoff {
    static initialize(instrumentationKey) {
        if (instrumentationKey && "undefined" !== 'undefined') {}
    }
    /**
   * Execute a function with exponential backoff retry logic
   */ static async execute(fn, options = {}) {
        const { maxRetries = 3, baseDelay = 1000, maxDelay = 30000, jitter = true, retryCondition = this.defaultRetryCondition, onRetry, userId, action = 'unknown' } = options;
        const startTime = Date.now();
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                const result = await fn();
                // Log success metrics
                if (attempt > 0) {
                    this.logRetrySuccess({
                        attempt: attempt + 1,
                        totalAttempts: attempt + 1,
                        delay: 0,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                }
                return result;
            } catch (error) {
                lastError = error;
                // Check if we should retry
                if (attempt === maxRetries || !retryCondition(error)) {
                    // Log final failure
                    this.logRetryFailure({
                        attempt: attempt + 1,
                        totalAttempts: maxRetries + 1,
                        delay: 0,
                        error,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                    throw error;
                }
                // Calculate delay for next attempt
                const exponentialDelay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
                const delay = jitter ? exponentialDelay + Math.random() * exponentialDelay * 0.1 // Add 10% jitter
                 : exponentialDelay;
                // Log retry attempt
                this.logRetryAttempt({
                    attempt: attempt + 1,
                    totalAttempts: maxRetries + 1,
                    delay,
                    error,
                    userId,
                    action,
                    startTime
                });
                // Execute retry callback if provided
                if (onRetry) {
                    onRetry(error, attempt + 1);
                }
                // Wait before next attempt
                await this.sleep(delay);
            }
        }
        throw lastError;
    }
    /**
   * Default retry condition - retry on network errors, rate limits, and server errors
   */ static defaultRetryCondition(error) {
        // Network errors
        if (error.code === 'ECONNRESET' || error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
            return true;
        }
        // HTTP status codes that should be retried
        if (error.response?.status) {
            const status = error.response.status;
            return status === 429 || // Rate limit
            status === 502 || // Bad Gateway
            status === 503 || // Service Unavailable
            status === 504; // Gateway Timeout
        }
        // Azure OpenAI specific errors
        if (error.message?.includes('rate limit') || error.message?.includes('throttled') || error.message?.includes('quota exceeded')) {
            return true;
        }
        return false;
    }
    /**
   * Sleep for specified milliseconds
   */ static sleep(ms) {
        return new Promise((resolve)=>setTimeout(resolve, ms));
    }
    /**
   * Log retry attempt
   */ static logRetryAttempt(metrics) {
        const logData = {
            level: 'warn',
            message: `Retry attempt ${metrics.attempt}/${metrics.totalAttempts} for ${metrics.action}`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                delay: metrics.delay,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name
                },
                timestamp: new Date().toISOString()
            }
        };
        console.warn('RETRY_ATTEMPT', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 2,
                properties: logData.properties
            });
        }
    }
    /**
   * Log retry success
   */ static logRetrySuccess(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'info',
            message: `Retry succeeded for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                timestamp: new Date().toISOString()
            }
        };
        console.log('RETRY_SUCCESS', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 1,
                properties: logData.properties
            });
            // Track custom metric for retry success
            this.appInsights.trackMetric({
                name: 'RetrySuccess',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
    /**
   * Log retry failure
   */ static logRetryFailure(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'error',
            message: `Retry failed for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name,
                    stack: metrics.error?.stack
                },
                timestamp: new Date().toISOString()
            }
        };
        console.error('RETRY_FAILURE', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackException({
                exception: metrics.error,
                properties: logData.properties,
                severityLevel: 3 // Error
            });
            // Track custom metric for retry failure
            this.appInsights.trackMetric({
                name: 'RetryFailure',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
}
/**
 * Convenience function for common retry scenarios
 */ async function retryWithExponentialBackoff(fn, action, userId, options) {
    return RetryWithBackoff.execute(fn, {
        action,
        userId,
        ...options
    });
}


/***/ }),

/***/ 51108:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ useAuth),
/* harmony export */   AuthProvider: () => (/* binding */ AuthProvider)
/* harmony export */ });
/* unused harmony export AuthContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60687);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ AuthProvider,useAuth,AuthContext auto */ 

/**
 * Refresh the current Firebase auth token
 */ async function refreshAuthToken() {
    try {
        // Import Firebase auth dynamically to avoid SSR issues
        const { getCurrentUserIdToken } = await Promise.all(/* import() */[__webpack_require__.e(1012), __webpack_require__.e(7870)]).then(__webpack_require__.bind(__webpack_require__, 87870));
        console.log('🔄 Attempting to refresh Firebase ID token...');
        // Force refresh the Firebase ID token
        const freshToken = await getCurrentUserIdToken(true);
        if (freshToken) {
            // Update localStorage with the new token
            localStorage.setItem('auth_token', freshToken);
            console.log('✅ Firebase ID token refreshed successfully');
            return freshToken;
        } else {
            console.warn('⚠️ No fresh token returned from Firebase');
            return null;
        }
    } catch (error) {
        console.error('❌ Token refresh failed:', error);
        // If Firebase auth is not available or user is not signed in,
        // clear the auth state completely
        if (error instanceof Error && error.message.includes('No Firebase user signed in')) {
            localStorage.removeItem('auth_token');
            // Clear all caches
            Object.keys(localStorage).forEach((key)=>{
                if (key.startsWith('auth_verification_')) {
                    localStorage.removeItem(key);
                }
            });
        }
        return null;
    }
}
// Create the context with default values
const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    user: null,
    loading: true,
    isAuthenticated: false,
    signOut: async ()=>{}
});
// AuthProvider component that manages unified auth state
function AuthProvider({ children, initialUser }) {
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialUser || null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!initialUser);
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Only check auth state once on mount
        let mounted = true;
        const checkAuthState = async ()=>{
            // Skip auth checks on authentication pages to prevent API loops
            const isAuthPage =  false && 0;
            if (isAuthPage) {
                console.log('🚫 Auth check skipped: on authentication page');
                if (mounted) {
                    setUser(null);
                    setLoading(false);
                }
                return;
            }
            try {
                // First check for session cookie to avoid unnecessary API call
                const cookies = document.cookie.split(';').reduce((acc, cookie)=>{
                    const [name, value] = cookie.trim().split('=');
                    acc[name] = value;
                    return acc;
                }, {});
                const sessionCookie = cookies.session;
                const token = localStorage.getItem('auth_token');
                // If no session cookie and no token, user is not authenticated
                if (!sessionCookie && !token) {
                    if (mounted) {
                        setUser(null);
                        setLoading(false);
                    }
                    return;
                }
                // Only verify token if we have one
                if (token) {
                    // Check for cached verification result (15 min cache)
                    const cacheKey = `auth_verification_${token.substring(0, 10)}`;
                    const cachedVerification = localStorage.getItem(cacheKey);
                    if (cachedVerification) {
                        try {
                            const cached = JSON.parse(cachedVerification);
                            const cacheAge = Date.now() - cached.timestamp;
                            // Use cached result if less than 15 minutes old
                            if (cacheAge < 15 * 60 * 1000) {
                                console.log('🚀 Using cached auth verification');
                                if (mounted && cached.verified && cached.user) {
                                    setUser(cached.user);
                                }
                                if (mounted) {
                                    setLoading(false);
                                }
                                return;
                            } else {
                                // Remove expired cache
                                localStorage.removeItem(cacheKey);
                            }
                        } catch (error) {
                            // Invalid cache, remove it
                            localStorage.removeItem(cacheKey);
                        }
                    }
                    console.log('🔍 Verifying auth token via API');
                    const response = await fetch('/api/auth/verify', {
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    });
                    if (response.ok) {
                        const userData = await response.json();
                        // Cache successful verification
                        const cacheData = {
                            verified: true,
                            user: userData.user,
                            timestamp: Date.now()
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        if (mounted) {
                            setUser(userData.user);
                        }
                    } else if (response.status === 401) {
                        // Token is invalid/expired, check if server suggests refresh
                        const errorData = await response.json().catch(()=>({}));
                        const shouldRefresh = errorData.shouldRefresh !== false; // Default to true
                        console.log('🔄 Token expired/invalid:', errorData.error || 'Unknown error');
                        if (shouldRefresh) {
                            console.log('🔄 Attempting token refresh...');
                            try {
                                const refreshed = await refreshAuthToken();
                                if (refreshed && mounted) {
                                    // Retry verification with new token
                                    const retryResponse = await fetch('/api/auth/verify', {
                                        headers: {
                                            'Authorization': `Bearer ${refreshed}`
                                        }
                                    });
                                    if (retryResponse.ok) {
                                        const userData = await retryResponse.json();
                                        // Cache successful verification with new token
                                        const newCacheKey = `auth_verification_${refreshed.substring(0, 10)}`;
                                        const cacheData = {
                                            verified: true,
                                            user: userData.user,
                                            timestamp: Date.now()
                                        };
                                        localStorage.setItem(newCacheKey, JSON.stringify(cacheData));
                                        if (mounted) {
                                            setUser(userData.user);
                                        }
                                        return;
                                    }
                                }
                            } catch (refreshError) {
                                console.error('🔄 Token refresh failed:', refreshError);
                            }
                        }
                        // If refresh failed or not recommended, clear auth state
                        localStorage.removeItem('auth_token');
                        // Clear all verification caches
                        Object.keys(localStorage).forEach((key)=>{
                            if (key.startsWith('auth_verification_')) {
                                localStorage.removeItem(key);
                            }
                        });
                        if (mounted) {
                            setUser(null);
                        }
                    } else {
                        // Other error, cache failed verification temporarily (1 min)
                        const cacheData = {
                            verified: false,
                            user: null,
                            timestamp: Date.now() - 14 * 60 * 1000 // Expire quickly for failed attempts
                        };
                        localStorage.setItem(cacheKey, JSON.stringify(cacheData));
                        localStorage.removeItem('auth_token');
                        if (mounted) {
                            setUser(null);
                        }
                    }
                } else if (sessionCookie) {
                    // If we have session cookie but no token, consider user logged in
                    // but with minimal user data
                    if (mounted) {
                        setUser({
                            uid: 'session-user',
                            email: 'unknown@session.com',
                            email_verified: false
                        });
                    }
                }
            } catch (error) {
                console.error('Auth state check failed:', error);
                if (mounted) {
                    setUser(null);
                }
            } finally{
                if (mounted) {
                    setLoading(false);
                }
            }
        };
        if (!initialUser) {
            checkAuthState();
        } else {
            setLoading(false);
        }
        return ()=>{
            mounted = false;
        };
    }, [
        initialUser
    ]);
    const signOut = async ()=>{
        try {
            await fetch('/api/auth/signout', {
                method: 'POST'
            });
            localStorage.removeItem('auth_token');
            setUser(null);
        } catch (error) {
            console.error('Sign out error:', error);
        }
    };
    const contextValue = {
        user,
        loading,
        isAuthenticated: !!user,
        signOut
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(AuthContext.Provider, {
        value: contextValue,
        children: children
    });
}
// Custom hook to use the auth context
function useAuth() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthContext);
    if (context === undefined) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
}
// Export the context for advanced use cases



/***/ }),

/***/ 52631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FirebaseClientInit)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(43210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* __next_internal_client_entry_do_not_use__ default auto */ 
/**
 * Firebase Client Initialization Component
 * 
 * This component ensures Firebase client environment variables are properly
 * set from Azure Key Vault before Firebase services are used
 */ function FirebaseClientInit() {
    process.env.__NEXT_PRIVATE_MINIMIZE_MACRO_FALSE && (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const initializeFirebaseConfig = async ()=>{
            try {
                // Check if Firebase config is already available
                const hasFirebaseConfig = !!("AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0 || 0);
                if (hasFirebaseConfig) {
                    console.log('🔥 Firebase client config already available');
                    return;
                }
                console.log('🔥 Firebase client config not found, checking Azure Key Vault...');
                // Try to fetch from server-side Azure configuration
                const response = await fetch('/api/config/firebase', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                if (response.ok) {
                    const config = await response.json();
                    // Set client-side environment variables
                    if (config.apiKey) {
                        window.__NEXT_FIREBASE_API_KEY__ = config.apiKey;
                    }
                    if (config.projectId) {
                        window.__NEXT_FIREBASE_PROJECT_ID__ = config.projectId;
                    }
                    if (config.authDomain) {
                        window.__NEXT_FIREBASE_AUTH_DOMAIN__ = config.authDomain;
                    }
                    console.log('🔥 Firebase client config loaded from server:', {
                        hasApiKey: !!config.apiKey,
                        projectId: config.projectId,
                        authDomain: config.authDomain
                    });
                } else {
                    console.warn('🔥 Failed to fetch Firebase config from server, using fallback');
                }
            } catch (error) {
                console.error('🔥 Error initializing Firebase client config:', error);
            }
        };
        // Initialize Firebase config on client side only
        if (false) {}
    }, []);
    // This component doesn't render anything
    return null;
}


/***/ }),

/***/ 54310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RouterLoadingHandler: () => (/* binding */ RouterLoadingHandler)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

const RouterLoadingHandler = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call RouterLoadingHandler() from the server but RouterLoadingHandler is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/RouterLoadingHandler.tsx",
"RouterLoadingHandler",
);

/***/ }),

/***/ 57048:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  cn: () => (/* binding */ cn),
  L8: () => (/* binding */ getCompanyLogoForInterview),
  o8: () => (/* binding */ getRandomInterviewCover),
  iE: () => (/* binding */ normalizeTechstack)
});

// UNUSED EXPORTS: getTechIcons

// EXTERNAL MODULE: ./node_modules/zod/lib/index.mjs
var lib = __webpack_require__(45880);
;// ./constants/index.ts

const mappings = {
    "react.js": "react",
    reactjs: "react",
    react: "react",
    "next.js": "nextjs",
    nextjs: "nextjs",
    next: "nextjs",
    "vue.js": "vuejs",
    vuejs: "vuejs",
    vue: "vuejs",
    "express.js": "express",
    expressjs: "express",
    express: "express",
    "node.js": "nodejs",
    nodejs: "nodejs",
    node: "nodejs",
    mongodb: "mongodb",
    mongo: "mongodb",
    mongoose: "mongoose",
    mysql: "mysql",
    postgresql: "postgresql",
    sqlite: "sqlite",
    firebase: "firebase",
    docker: "docker",
    kubernetes: "kubernetes",
    aws: "aws",
    azure: "azure",
    gcp: "gcp",
    digitalocean: "digitalocean",
    heroku: "heroku",
    photoshop: "photoshop",
    "adobe photoshop": "photoshop",
    html5: "html5",
    html: "html5",
    css3: "css3",
    css: "css3",
    sass: "sass",
    scss: "sass",
    less: "less",
    tailwindcss: "tailwindcss",
    tailwind: "tailwindcss",
    bootstrap: "bootstrap",
    jquery: "jquery",
    typescript: "typescript",
    ts: "typescript",
    javascript: "javascript",
    js: "javascript",
    "angular.js": "angular",
    angularjs: "angular",
    angular: "angular",
    "ember.js": "ember",
    emberjs: "ember",
    ember: "ember",
    "backbone.js": "backbone",
    backbonejs: "backbone",
    backbone: "backbone",
    nestjs: "nestjs",
    graphql: "graphql",
    "graph ql": "graphql",
    apollo: "apollo",
    webpack: "webpack",
    babel: "babel",
    "rollup.js": "rollup",
    rollupjs: "rollup",
    rollup: "rollup",
    "parcel.js": "parcel",
    parceljs: "parcel",
    npm: "npm",
    yarn: "yarn",
    git: "git",
    github: "github",
    gitlab: "gitlab",
    bitbucket: "bitbucket",
    figma: "figma",
    prisma: "prisma",
    redux: "redux",
    flux: "flux",
    redis: "redis",
    selenium: "selenium",
    cypress: "cypress",
    jest: "jest",
    mocha: "mocha",
    chai: "chai",
    karma: "karma",
    vuex: "vuex",
    "nuxt.js": "nuxt",
    nuxtjs: "nuxt",
    nuxt: "nuxt",
    strapi: "strapi",
    wordpress: "wordpress",
    contentful: "contentful",
    netlify: "netlify",
    "aws amplify": "amplify"
};
// Azure-based interviewer configuration
const azureInterviewer = {
    name: "PrepBettr AI Interviewer",
    first_message: "Hello {{candidateName}}! Thank you for taking the time to speak with me today. I'm excited to learn more about you and your experience.",
    system_prompt: `You are a professional job interviewer conducting a real-time voice interview with a candidate. Your goal is to assess their qualifications, motivation, and fit for the role.

Interview Guidelines:
Follow the structured question flow:
{{questions}}

Engage naturally & react appropriately:
Listen actively to responses and acknowledge them before moving forward.
Ask brief follow-up questions if a response is vague or requires more detail.
Keep the conversation flowing smoothly while maintaining control.
Be professional, yet warm and welcoming:

Use official yet friendly language.
Keep responses concise and to the point (like in a real voice interview).
Avoid robotic phrasing—sound natural and conversational.
Answer the candidate's questions professionally:

If asked about the role, company, or expectations, provide a clear and relevant answer.
If unsure, redirect the candidate to HR for more details.

Conclude the interview properly:
Thank the candidate for their time.
Inform them that the company will reach out soon with feedback.
End the conversation on a polite and positive note.

- Be sure to be professional and polite.
- Keep all your responses short and simple. Use official language, but be kind and welcoming.
- This is a voice conversation, so keep your responses short, like in a real conversation. Don't ramble for too long.`,
    speech: {
        region: "eastus",
        voice_name: "en-US-JennyNeural",
        speaking_rate: 0.9,
        pitch: "+0Hz"
    },
    openai: {
        model: "gpt-4",
        temperature: 0.7,
        max_tokens: 200
    }
};
const feedbackSchema = lib.z.object({
    totalScore: lib.z.number(),
    categoryScores: lib.z.tuple([
        lib.z.object({
            name: lib.z.literal("Communication Skills"),
            score: lib.z.number(),
            comment: lib.z.string()
        }),
        lib.z.object({
            name: lib.z.literal("Technical Knowledge"),
            score: lib.z.number(),
            comment: lib.z.string()
        }),
        lib.z.object({
            name: lib.z.literal("Problem Solving"),
            score: lib.z.number(),
            comment: lib.z.string()
        }),
        lib.z.object({
            name: lib.z.literal("Cultural Fit"),
            score: lib.z.number(),
            comment: lib.z.string()
        }),
        lib.z.object({
            name: lib.z.literal("Confidence and Clarity"),
            score: lib.z.number(),
            comment: lib.z.string()
        })
    ]),
    strengths: lib.z.array(lib.z.string()),
    areasForImprovement: lib.z.array(lib.z.string()),
    finalAssessment: lib.z.string()
});
// Company logos for interviews
const companyLogos = [
    {
        name: "Apple",
        logo: "/apple.svg"
    },
    {
        name: "Microsoft",
        logo: "/microsoft.svg"
    },
    {
        name: "Google",
        logo: "/google.svg"
    },
    {
        name: "OpenAI",
        logo: "/openai.svg"
    },
    {
        name: "Instagram",
        logo: "/instagram.svg"
    },
    {
        name: "IBM",
        logo: "/ibm.svg"
    },
    {
        name: "LinkedIn",
        logo: "/linkedin.png"
    },
    {
        name: "Tesla",
        logo: "/tesla.png"
    },
    {
        name: "Netflix",
        logo: "/netflix.svg"
    },
    {
        name: "Amazon",
        logo: "/amazon.png"
    },
    {
        name: "Meta",
        logo: "/meta.png"
    },
    {
        name: "Adobe",
        logo: "/adobe.png"
    },
    {
        name: "Spotify",
        logo: "/spotify.png"
    },
    {
        name: "Airbnb",
        logo: "/airbnb.svg"
    },
    {
        name: "Uber",
        logo: "/uber.svg"
    },
    {
        name: "Reddit",
        logo: "/reddit.png"
    },
    {
        name: "Pinterest",
        logo: "/pinterest.png"
    },
    {
        name: "Quora",
        logo: "/quora.png"
    },
    {
        name: "Skype",
        logo: "/skype.png"
    },
    {
        name: "TikTok",
        logo: "/tiktok.png"
    },
    {
        name: "Yahoo",
        logo: "/yahoo.png"
    },
    {
        name: "Telegram",
        logo: "/telegram.png"
    },
    {
        name: "Facebook",
        logo: "/facebook.png"
    },
    {
        name: "Hostinger",
        logo: "/hostinger.png"
    }
];
// Legacy array for backward compatibility
const interviewCovers = companyLogos.map((c)=>c.logo);
const dummyInterviews = [
    {
        id: "1",
        userId: "user1",
        jobTitle: "Frontend Developer",
        company: "TechCorp",
        jobDescription: "Frontend developer position working with React and TypeScript",
        questions: [
            {
                question: "What is React?",
                category: "technical",
                difficulty: "medium"
            },
            {
                question: "Explain TypeScript benefits",
                category: "technical",
                difficulty: "medium"
            }
        ],
        finalized: false,
        feedbackGenerated: false,
        createdAt: "2024-03-15T10:00:00Z",
        updatedAt: "2024-03-15T10:00:00Z",
        // Legacy properties for backward compatibility
        role: "Frontend Developer",
        type: "Technical",
        techstack: [
            "React",
            "TypeScript",
            "Next.js",
            "Tailwind CSS"
        ],
        level: "Junior"
    },
    {
        id: "2",
        userId: "user1",
        jobTitle: "Full Stack Developer",
        company: "StartupXYZ",
        jobDescription: "Full stack developer position using Node.js and React",
        questions: [
            {
                question: "What is Node.js?",
                category: "technical",
                difficulty: "medium"
            },
            {
                question: "Explain RESTful APIs",
                category: "technical",
                difficulty: "medium"
            }
        ],
        finalized: false,
        feedbackGenerated: false,
        createdAt: "2024-03-14T15:30:00Z",
        updatedAt: "2024-03-14T15:30:00Z",
        // Legacy properties for backward compatibility
        role: "Full Stack Developer",
        type: "Mixed",
        techstack: [
            "Node.js",
            "Express",
            "MongoDB",
            "React"
        ],
        level: "Senior"
    }
];

// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(49384);
// EXTERNAL MODULE: ./node_modules/tailwind-merge/dist/bundle-mjs.mjs
var bundle_mjs = __webpack_require__(82348);
;// ./lib/utils.ts



function cn(...inputs) {
    return (0,bundle_mjs/* twMerge */.QP)((0,clsx/* clsx */.$)(inputs));
}
/**
 * Normalizes techstack data to always return a string array
 * Handles cases where techstack might be null, undefined, string, or already an array
 */ function normalizeTechstack(techstack) {
    if (!techstack) return [];
    if (typeof techstack === 'string') {
        return techstack.split(',').map((tech)=>tech.trim()).filter(Boolean);
    }
    if (Array.isArray(techstack)) {
        return techstack.filter((tech)=>typeof tech === 'string' && tech.trim());
    }
    return [];
}
// Tech icon configuration using React Icons (primary) and DevIcons (fallback)
const techIconsMap = {
    // Frontend
    'react': {
        type: 'react-icon',
        icon: 'FaReact'
    },
    'nextjs': {
        type: 'react-icon',
        icon: 'SiNextdotjs'
    },
    'next': {
        type: 'react-icon',
        icon: 'SiNextdotjs'
    },
    'next.js': {
        type: 'react-icon',
        icon: 'SiNextdotjs'
    },
    'vue': {
        type: 'react-icon',
        icon: 'FaVuejs'
    },
    'angular': {
        type: 'react-icon',
        icon: 'FaAngular'
    },
    'svelte': {
        type: 'react-icon',
        icon: 'SiSvelte'
    },
    'typescript': {
        type: 'react-icon',
        icon: 'SiTypescript'
    },
    'javascript': {
        type: 'react-icon',
        icon: 'SiJavascript'
    },
    'html': {
        type: 'react-icon',
        icon: 'FaHtml5'
    },
    'css': {
        type: 'react-icon',
        icon: 'FaCss3Alt'
    },
    'sass': {
        type: 'react-icon',
        icon: 'FaSass'
    },
    'tailwind': {
        type: 'react-icon',
        icon: 'SiTailwindcss'
    },
    'tailwindcss': {
        type: 'react-icon',
        icon: 'SiTailwindcss'
    },
    'bootstrap': {
        type: 'react-icon',
        icon: 'FaBootstrap'
    },
    'materialui': {
        type: 'react-icon',
        icon: 'SiMui'
    },
    'mui': {
        type: 'react-icon',
        icon: 'SiMui'
    },
    // Backend
    'nodejs': {
        type: 'react-icon',
        icon: 'FaNodeJs'
    },
    'node': {
        type: 'react-icon',
        icon: 'FaNodeJs'
    },
    'node.js': {
        type: 'react-icon',
        icon: 'FaNodeJs'
    },
    'express': {
        type: 'react-icon',
        icon: 'SiExpress'
    },
    'python': {
        type: 'react-icon',
        icon: 'FaPython'
    },
    'django': {
        type: 'react-icon',
        icon: 'SiDjango'
    },
    'flask': {
        type: 'react-icon',
        icon: 'SiFlask'
    },
    'java': {
        type: 'react-icon',
        icon: 'FaJava'
    },
    'spring': {
        type: 'react-icon',
        icon: 'SiSpring'
    },
    'php': {
        type: 'react-icon',
        icon: 'FaPhp'
    },
    'ruby': {
        type: 'react-icon',
        icon: 'SiRuby'
    },
    'rails': {
        type: 'react-icon',
        icon: 'SiRubyonrails'
    },
    'go': {
        type: 'react-icon',
        icon: 'SiGo'
    },
    'golang': {
        type: 'react-icon',
        icon: 'SiGo'
    },
    'rust': {
        type: 'react-icon',
        icon: 'SiRust'
    },
    'csharp': {
        type: 'devicon',
        icon: '',
        fallbackUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg'
    },
    'c#': {
        type: 'devicon',
        icon: '',
        fallbackUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg'
    },
    'dotnet': {
        type: 'react-icon',
        icon: 'SiDotnet'
    },
    '.net': {
        type: 'react-icon',
        icon: 'SiDotnet'
    },
    // Databases
    'mongodb': {
        type: 'react-icon',
        icon: 'SiMongodb'
    },
    'mysql': {
        type: 'react-icon',
        icon: 'SiMysql'
    },
    'postgresql': {
        type: 'react-icon',
        icon: 'SiPostgresql'
    },
    'postgres': {
        type: 'react-icon',
        icon: 'SiPostgresql'
    },
    'redis': {
        type: 'react-icon',
        icon: 'SiRedis'
    },
    'sqlite': {
        type: 'react-icon',
        icon: 'SiSqlite'
    },
    'oracle': {
        type: 'react-icon',
        icon: 'SiOracle'
    },
    'elasticsearch': {
        type: 'react-icon',
        icon: 'SiElasticsearch'
    },
    // Mobile
    'reactnative': {
        type: 'react-icon',
        icon: 'FaReact'
    },
    'flutter': {
        type: 'react-icon',
        icon: 'SiFlutter'
    },
    'swift': {
        type: 'react-icon',
        icon: 'SiSwift'
    },
    'kotlin': {
        type: 'react-icon',
        icon: 'SiKotlin'
    },
    'android': {
        type: 'react-icon',
        icon: 'FaAndroid'
    },
    'ios': {
        type: 'react-icon',
        icon: 'FaApple'
    },
    // Cloud & DevOps
    'docker': {
        type: 'react-icon',
        icon: 'FaDocker'
    },
    'kubernetes': {
        type: 'react-icon',
        icon: 'SiKubernetes'
    },
    'aws': {
        type: 'react-icon',
        icon: 'FaAws'
    },
    'azure': {
        type: 'devicon',
        icon: '',
        fallbackUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/azure/azure-original.svg'
    },
    'gcp': {
        type: 'react-icon',
        icon: 'SiGooglecloud'
    },
    'googlecloud': {
        type: 'react-icon',
        icon: 'SiGooglecloud'
    },
    'firebase': {
        type: 'react-icon',
        icon: 'SiFirebase'
    },
    'netlify': {
        type: 'react-icon',
        icon: 'SiNetlify'
    },
    // Version Control
    'git': {
        type: 'react-icon',
        icon: 'FaGitAlt'
    },
    'github': {
        type: 'react-icon',
        icon: 'FaGithub'
    },
    'gitlab': {
        type: 'react-icon',
        icon: 'FaGitlab'
    },
    'bitbucket': {
        type: 'react-icon',
        icon: 'FaBitbucket'
    },
    // Build Tools & Bundlers
    'webpack': {
        type: 'react-icon',
        icon: 'SiWebpack'
    },
    'vite': {
        type: 'react-icon',
        icon: 'SiVite'
    },
    'rollup': {
        type: 'react-icon',
        icon: 'SiRollupdotjs'
    },
    'babel': {
        type: 'react-icon',
        icon: 'SiBabel'
    },
    'eslint': {
        type: 'react-icon',
        icon: 'SiEslint'
    },
    'prettier': {
        type: 'react-icon',
        icon: 'SiPrettier'
    },
    // Testing
    'jest': {
        type: 'react-icon',
        icon: 'SiJest'
    },
    'cypress': {
        type: 'react-icon',
        icon: 'SiCypress'
    },
    'mocha': {
        type: 'devicon',
        icon: '',
        fallbackUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mocha/mocha-plain.svg'
    },
    // State Management
    'redux': {
        type: 'react-icon',
        icon: 'SiRedux'
    },
    'mobx': {
        type: 'react-icon',
        icon: 'SiMobx'
    },
    // API Technologies
    'graphql': {
        type: 'react-icon',
        icon: 'SiGraphql'
    },
    'apollo': {
        type: 'react-icon',
        icon: 'SiApollographql'
    },
    'restapi': {
        type: 'react-icon',
        icon: 'SiPostman'
    },
    'rest': {
        type: 'react-icon',
        icon: 'SiPostman'
    },
    // CI/CD
    'jenkins': {
        type: 'react-icon',
        icon: 'SiJenkins'
    },
    'githubactions': {
        type: 'react-icon',
        icon: 'SiGithubactions'
    },
    'circleci': {
        type: 'react-icon',
        icon: 'SiCircleci'
    },
    'travis': {
        type: 'react-icon',
        icon: 'SiTravisci'
    },
    // Additional Popular Technologies
    'laravel': {
        type: 'react-icon',
        icon: 'SiLaravel'
    },
    'symfony': {
        type: 'react-icon',
        icon: 'SiSymfony'
    },
    'codeigniter': {
        type: 'react-icon',
        icon: 'SiCodeigniter'
    },
    'wordpress': {
        type: 'react-icon',
        icon: 'FaWordpress'
    },
    'drupal': {
        type: 'react-icon',
        icon: 'FaDrupal'
    },
    'joomla': {
        type: 'react-icon',
        icon: 'FaJoomla'
    },
    'shopify': {
        type: 'react-icon',
        icon: 'SiShopify'
    },
    'strapi': {
        type: 'react-icon',
        icon: 'SiStrapi'
    },
    'contentful': {
        type: 'react-icon',
        icon: 'SiContentful'
    },
    'sanity': {
        type: 'react-icon',
        icon: 'SiSanity'
    },
    // Additional Frameworks & Libraries (20+ new entries)
    'nuxt': {
        type: 'react-icon',
        icon: 'SiNuxtdotjs'
    },
    'nuxtjs': {
        type: 'react-icon',
        icon: 'SiNuxtdotjs'
    },
    'gatsby': {
        type: 'react-icon',
        icon: 'SiGatsby'
    },
    'ember': {
        type: 'react-icon',
        icon: 'SiEmber'
    },
    'backbone': {
        type: 'react-icon',
        icon: 'SiBackbonedotjs'
    },
    'polymer': {
        type: 'react-icon',
        icon: 'SiPolymer'
    },
    'astro': {
        type: 'react-icon',
        icon: 'SiAstro'
    },
    // Backend Frameworks
    'fastapi': {
        type: 'react-icon',
        icon: 'SiFastapi'
    },
    'nestjs': {
        type: 'react-icon',
        icon: 'SiNestjs'
    },
    'koa': {
        type: 'react-icon',
        icon: 'SiKoa'
    },
    'hapi': {
        type: 'react-icon',
        icon: 'SiHapi'
    },
    'deno': {
        type: 'react-icon',
        icon: 'SiDeno'
    },
    // Cloud & Database
    'supabase': {
        type: 'react-icon',
        icon: 'SiSupabase'
    },
    'prisma': {
        type: 'react-icon',
        icon: 'SiPrisma'
    },
    'sequelize': {
        type: 'react-icon',
        icon: 'SiSequelize'
    },
    'mariadb': {
        type: 'react-icon',
        icon: 'SiMariadb'
    },
    'cassandra': {
        type: 'react-icon',
        icon: 'SiCassandra'
    },
    'couchdb': {
        type: 'react-icon',
        icon: 'SiCouchdb'
    },
    'neo4j': {
        type: 'react-icon',
        icon: 'SiNeo4j'
    },
    'influxdb': {
        type: 'react-icon',
        icon: 'SiInfluxdb'
    },
    // DevOps & Monitoring
    'grafana': {
        type: 'react-icon',
        icon: 'SiGrafana'
    },
    'prometheus': {
        type: 'react-icon',
        icon: 'SiPrometheus'
    },
    'terraform': {
        type: 'react-icon',
        icon: 'SiTerraform'
    },
    'ansible': {
        type: 'react-icon',
        icon: 'SiAnsible'
    },
    'puppet': {
        type: 'react-icon',
        icon: 'SiPuppet'
    },
    'helm': {
        type: 'react-icon',
        icon: 'SiHelm'
    },
    'argo': {
        type: 'react-icon',
        icon: 'SiArgo'
    },
    'rancher': {
        type: 'react-icon',
        icon: 'SiRancher'
    },
    'datadog': {
        type: 'react-icon',
        icon: 'SiDatadog'
    },
    'newrelic': {
        type: 'react-icon',
        icon: 'SiNewrelic'
    },
    'sentry': {
        type: 'react-icon',
        icon: 'SiSentry'
    },
    // Data Processing & Analytics
    'elastic': {
        type: 'react-icon',
        icon: 'SiElastic'
    },
    'logstash': {
        type: 'react-icon',
        icon: 'SiLogstash'
    },
    'kibana': {
        type: 'react-icon',
        icon: 'SiKibana'
    },
    'kafka': {
        type: 'react-icon',
        icon: 'SiApachekafka'
    },
    'rabbitmq': {
        type: 'react-icon',
        icon: 'SiRabbitmq'
    },
    'spark': {
        type: 'react-icon',
        icon: 'SiApachespark'
    },
    'hadoop': {
        type: 'react-icon',
        icon: 'SiHadoop'
    },
    'databricks': {
        type: 'react-icon',
        icon: 'SiDatabricks'
    },
    'snowflake': {
        type: 'react-icon',
        icon: 'SiSnowflake'
    },
    'tableau': {
        type: 'react-icon',
        icon: 'SiTableau'
    },
    'powerbi': {
        type: 'react-icon',
        icon: 'SiPowerbi'
    },
    'qlik': {
        type: 'react-icon',
        icon: 'SiQlik'
    },
    // Data Visualization
    'd3': {
        type: 'react-icon',
        icon: 'SiD3Dotjs'
    },
    'd3js': {
        type: 'react-icon',
        icon: 'SiD3Dotjs'
    },
    'chartjs': {
        type: 'react-icon',
        icon: 'SiChartdotjs'
    },
    'plotly': {
        type: 'react-icon',
        icon: 'SiPlotly'
    },
    'leaflet': {
        type: 'react-icon',
        icon: 'SiLeaflet'
    },
    'mapbox': {
        type: 'react-icon',
        icon: 'SiMapbox'
    },
    'threejs': {
        type: 'react-icon',
        icon: 'SiThreejs'
    },
    // Testing Frameworks
    'playwright': {
        type: 'react-icon',
        icon: 'SiPlaywright'
    },
    'selenium': {
        type: 'react-icon',
        icon: 'SiSelenium'
    },
    'testinglibrary': {
        type: 'react-icon',
        icon: 'SiTestinglibrary'
    },
    'vitest': {
        type: 'react-icon',
        icon: 'SiVitest'
    },
    'storybook': {
        type: 'react-icon',
        icon: 'SiStorybook'
    },
    'chromatic': {
        type: 'react-icon',
        icon: 'SiChromatic'
    },
    // Validation & Design
    'zod': {
        type: 'react-icon',
        icon: 'SiZod'
    },
    'yup': {
        type: 'react-icon',
        icon: 'SiYup'
    },
    'figma': {
        type: 'react-icon',
        icon: 'SiFigma'
    },
    'sketch': {
        type: 'react-icon',
        icon: 'SiSketch'
    },
    'adobexd': {
        type: 'react-icon',
        icon: 'SiAdobexd'
    },
    'framer': {
        type: 'react-icon',
        icon: 'SiFramer'
    },
    // Web3 & Blockchain
    'solidity': {
        type: 'react-icon',
        icon: 'SiSolidity'
    },
    'ethereum': {
        type: 'react-icon',
        icon: 'SiEthereum'
    },
    'web3': {
        type: 'react-icon',
        icon: 'SiWeb3Dotjs'
    },
    'web3js': {
        type: 'react-icon',
        icon: 'SiWeb3Dotjs'
    },
    'ipfs': {
        type: 'react-icon',
        icon: 'SiIpfs'
    },
    'chainlink': {
        type: 'react-icon',
        icon: 'SiChainlink'
    },
    'alchemy': {
        type: 'react-icon',
        icon: 'SiAlchemy'
    },
    // Payment Processing
    'stripe': {
        type: 'react-icon',
        icon: 'SiStripe'
    }
};
// DevIcon fallback URLs for technologies not available in React Icons
const devIconFallbacks = {
    'rails': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/rails/rails-original-wordmark.svg',
    'mocha': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mocha/mocha-plain.svg',
    'materialui': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/materialui/materialui-original.svg',
    'oracle': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/oracle/oracle-original.svg'
};
const normalizeTechName = (tech)=>{
    if (!tech) return '';
    // First normalize common tech names
    const normalized = tech.toLowerCase().replace(/\.js$/, '').replace(/\s+/g, '').replace(/[^a-z0-9]/g, '');
    // Special handling for common tech names
    if ([
        'node',
        'nodejs'
    ].includes(normalized)) return 'nodejs';
    if ([
        'next',
        'nextjs'
    ].includes(normalized)) return 'nextjs';
    return normalized;
};
/**
 * Get available tech icons configuration for a given array of technologies
 * Only returns technologies that have corresponding icons available
 * @param techArray - Array of technology names
 * @param maxIcons - Maximum number of icons to return (default: 6)
 * @returns Array of tech icon configurations
 */ const getTechIcons = (techArray = [], maxIcons = 6)=>{
    if (!techArray || techArray.length === 0) return [];
    // Filter and map technologies to their icon configurations
    const availableIcons = techArray.map((tech)=>{
        const normalized = normalizeTechName(tech);
        const iconConfig = techIconsMap[normalized];
        // Only include technologies that have icon configurations
        if (iconConfig) {
            return {
                tech: tech.trim(),
                normalized,
                ...iconConfig
            };
        }
        return null;
    }).filter((icon)=>icon !== null) // Remove null values with proper typing
    .slice(0, maxIcons); // Limit number of icons
    return availableIcons;
};
/**
 * Get company logo deterministically based on interview ID
 * Returns both logo path and company name
 */ const getCompanyLogoForInterview = (id)=>{
    // Use deterministic selection based on ID to ensure consistency
    if (id) {
        const hash = id.split('').reduce((acc, char)=>acc + char.charCodeAt(0), 0);
        const index = hash % companyLogos.length;
        const company = companyLogos[index];
        const path = `/covers${company.logo}`;
        console.log('Generated company logo:', path, 'Company:', company.name, 'for ID:', id);
        return {
            logo: path,
            company: company.name
        };
    }
    // Fallback to first company if no ID provided
    const fallback = companyLogos[0];
    const path = `/covers${fallback.logo}`;
    console.log('Fallback company logo:', path, 'Company:', fallback.name);
    return {
        logo: path,
        company: fallback.name
    };
};
// Legacy function for backward compatibility
const getRandomInterviewCover = (id)=>{
    return getCompanyLogoForInterview(id).logo;
};


/***/ }),

/***/ 58792:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/components/test/TestHelperInitializer.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/test/TestHelperInitializer.tsx",
"default",
));


/***/ }),

/***/ 59337:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/components/NetworkLoggerInit.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/NetworkLoggerInit.tsx",
"default",
));


/***/ }),

/***/ 59953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/components/FirebaseClientInit.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/FirebaseClientInit.tsx",
"default",
));


/***/ }),

/***/ 72076:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TelemetryProvider: () => (/* binding */ TelemetryProvider)
/* harmony export */ });
/* unused harmony export useTelemetry */
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

const TelemetryProvider = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call TelemetryProvider() from the server but TelemetryProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/providers/TelemetryProvider.tsx",
"TelemetryProvider",
);const useTelemetry = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call useTelemetry() from the server but useTelemetry is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/providers/TelemetryProvider.tsx",
"useTelemetry",
);/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/components/providers/TelemetryProvider.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/components/providers/TelemetryProvider.tsx",
"default",
));


/***/ }),

/***/ 76295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-runtime.js
var react_jsx_runtime = __webpack_require__(37413);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(6931);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app/layout.tsx","import":"Mona_Sans","arguments":[{"variable":"--font-mona-sans","subsets":["latin"]}],"variableName":"monaSans"}
var layout_tsx_import_Mona_Sans_arguments_variable_font_mona_sans_subsets_latin_variableName_monaSans_ = __webpack_require__(87664);
var layout_tsx_import_Mona_Sans_arguments_variable_font_mona_sans_subsets_latin_variableName_monaSans_default = /*#__PURE__*/__webpack_require__.n(layout_tsx_import_Mona_Sans_arguments_variable_font_mona_sans_subsets_latin_variableName_monaSans_);
// EXTERNAL MODULE: ./contexts/AuthContext.tsx
var AuthContext = __webpack_require__(94442);
// EXTERNAL MODULE: ./contexts/LoadingContext.tsx
var LoadingContext = __webpack_require__(29296);
// EXTERNAL MODULE: ./components/RouterLoadingHandler.tsx
var RouterLoadingHandler = __webpack_require__(54310);
// EXTERNAL MODULE: ./components/providers/TelemetryProvider.tsx
var TelemetryProvider = __webpack_require__(72076);
// EXTERNAL MODULE: ./components/FirebaseClientInit.tsx
var FirebaseClientInit = __webpack_require__(59953);
// EXTERNAL MODULE: ./app/providers.tsx
var providers = __webpack_require__(78972);
// EXTERNAL MODULE: ./lib/utils/retry-with-backoff.ts
var retry_with_backoff = __webpack_require__(46502);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(32190);
;// ./lib/middleware/error-handler.ts


class ErrorHandler {
    static initialize(instrumentationKey) {
        if (instrumentationKey && "undefined" !== 'undefined') {}
    }
    /**
   * Global error handler middleware for Next.js API routes
   */ static withErrorHandler(handler) {
        return async (req)=>{
            try {
                return await handler(req);
            } catch (error) {
                return this.handleError(error, req);
            }
        };
    }
    /**
   * Handle and log errors with structured logging
   */ static handleError(error, req) {
        const apiError = this.normalizeError(error);
        const errorDetails = this.extractErrorDetails(apiError, req);
        // Log the error
        this.logError(apiError, errorDetails);
        // Return appropriate response
        return this.createErrorResponse(apiError, errorDetails);
    }
    /**
   * Normalize different error types to ApiError
   */ static normalizeError(error) {
        // Already an ApiError
        if (error.statusCode && error.isOperational !== undefined) {
            return error;
        }
        // Network/HTTP errors
        if (error.code === 'ECONNRESET' || error.code === 'ENOTFOUND') {
            return {
                name: 'NetworkError',
                message: 'Network connection failed',
                statusCode: 503,
                code: error.code,
                isOperational: true,
                stack: error.stack
            };
        }
        // Validation errors
        if (error.name === 'ValidationError' || error.name === 'ZodError') {
            return {
                name: 'ValidationError',
                message: error.message || 'Validation failed',
                statusCode: 400,
                code: 'VALIDATION_ERROR',
                isOperational: true,
                stack: error.stack
            };
        }
        // Authentication errors
        if (error.message?.includes('unauthorized') || error.message?.includes('token')) {
            return {
                name: 'AuthenticationError',
                message: 'Authentication failed',
                statusCode: 401,
                code: 'AUTH_ERROR',
                isOperational: true,
                stack: error.stack
            };
        }
        // Rate limiting errors
        if (error.message?.includes('rate limit') || error.message?.includes('throttled')) {
            return {
                name: 'RateLimitError',
                message: 'Rate limit exceeded',
                statusCode: 429,
                code: 'RATE_LIMIT_ERROR',
                isOperational: true,
                stack: error.stack
            };
        }
        // External service errors (Azure OpenAI, etc.)
        if (error.message?.includes('Azure OpenAI') || error.message?.includes('OpenAI')) {
            return {
                name: 'ExternalServiceError',
                message: 'External AI service error',
                statusCode: 502,
                code: 'AI_SERVICE_ERROR',
                isOperational: true,
                stack: error.stack
            };
        }
        // Default to internal server error
        return {
            name: error.name || 'InternalError',
            message: error.message || 'An internal server error occurred',
            statusCode: 500,
            code: 'INTERNAL_ERROR',
            isOperational: false,
            stack: error.stack
        };
    }
    /**
   * Extract error details from request and error
   */ static extractErrorDetails(error, req) {
        const url = req?.url ? new URL(req.url) : undefined;
        const headers = req?.headers;
        return {
            userId: this.extractUserId(req),
            jobId: this.extractJobId(req),
            action: url?.pathname || 'unknown',
            requestId: headers?.get('x-request-id') || undefined,
            userAgent: headers?.get('user-agent') || undefined,
            path: url?.pathname || undefined,
            method: req?.method || undefined,
            statusCode: error.statusCode || 500,
            stack: error.stack,
            timestamp: new Date().toISOString()
        };
    }
    /**
   * Extract user ID from request (cookies, headers, or body)
   */ static extractUserId(req) {
        if (!req) return undefined;
        // Try to get from cookies first
        const sessionCookie = req.cookies.get('session')?.value;
        if (sessionCookie) {
            try {
                // In a real implementation, you'd decode the session token
                // For now, we'll just note that there's a session
                return 'user_from_session';
            } catch  {
            // Failed to decode session
            }
        }
        // Try to get from headers
        const userIdHeader = req.headers.get('x-user-id');
        if (userIdHeader) {
            return userIdHeader;
        }
        return undefined;
    }
    /**
   * Extract job ID from request path or body
   */ static extractJobId(req) {
        if (!req) return undefined;
        const url = req.url ? new URL(req.url) : undefined;
        // Try to extract from path
        const pathMatch = url?.pathname.match(/\/jobs\/([^\/]+)/);
        if (pathMatch) {
            return pathMatch[1];
        }
        // Try to extract from query parameters
        const jobId = url?.searchParams.get('jobId');
        if (jobId) {
            return jobId;
        }
        return undefined;
    }
    /**
   * Log error with structured logging
   */ static logError(error, details) {
        const logData = {
            level: 'error',
            message: `API Error: ${error.message}`,
            properties: {
                errorName: error.name,
                errorCode: error.code,
                statusCode: error.statusCode,
                isOperational: error.isOperational,
                userId: details.userId,
                jobId: details.jobId,
                action: details.action,
                requestId: details.requestId,
                userAgent: details.userAgent,
                path: details.path,
                method: details.method,
                timestamp: details.timestamp
            },
            exception: {
                message: error.message,
                stack: error.stack,
                name: error.name
            }
        };
        // Log to console with structured format
        console.error('API_ERROR', JSON.stringify(logData));
        // Send to Application Insights if available
        if (this.appInsights) {
            this.appInsights.trackException({
                exception: error,
                properties: logData.properties,
                severityLevel: error.isOperational ? 2 : 3 // Warning for operational, Error for programming errors
            });
            // Track custom metric for error rates
            this.appInsights.trackMetric({
                name: 'ApiError',
                average: 1,
                sampleCount: 1,
                properties: {
                    errorCode: error.code || 'unknown',
                    statusCode: error.statusCode?.toString() || '500',
                    action: details.action || 'unknown'
                }
            });
        }
    }
    /**
   * Create appropriate error response
   */ static createErrorResponse(error, details) {
        const response = {
            error: {
                message: error.isOperational ? error.message : 'An internal server error occurred',
                code: error.code || 'INTERNAL_ERROR',
                timestamp: details.timestamp,
                requestId: details.requestId
            }
        };
        // Don't expose internal error details in production
        if (false) {}
        return server.NextResponse.json(response, {
            status: error.statusCode || 500,
            headers: {
                'Content-Type': 'application/json',
                'X-Request-ID': details.requestId || 'unknown'
            }
        });
    }
    /**
   * Create an operational error (expected errors)
   */ static createOperationalError(message, statusCode = 400, code) {
        return {
            name: 'OperationalError',
            message,
            statusCode,
            code: code || 'OPERATIONAL_ERROR',
            isOperational: true
        };
    }
    /**
   * Create a programming error (unexpected errors)
   */ static createProgrammingError(message, originalError) {
        return {
            name: 'ProgrammingError',
            message,
            statusCode: 500,
            code: 'PROGRAMMING_ERROR',
            isOperational: false,
            stack: originalError?.stack
        };
    }
}
// Convenience function for wrapping API handlers
function withErrorHandler(handler) {
    return ErrorHandler.withErrorHandler(handler);
}
// Convenience functions for creating errors
const createOperationalError = ErrorHandler.createOperationalError;
const createProgrammingError = ErrorHandler.createProgrammingError;

// EXTERNAL MODULE: ./components/NetworkLoggerInit.tsx
var NetworkLoggerInit = __webpack_require__(59337);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(82704);
// EXTERNAL MODULE: ./components/test/TestHelperInitializer.tsx
var TestHelperInitializer = __webpack_require__(58792);
;// ./app/layout.tsx














// Initialize Azure services on server-side
// initializeAzureServices(); // Temporarily disabled for testing
// Initialize retry logic and error handler with Application Insights
const instrumentationKey = "9ae93338-ec14-4020-9a1c-79098b102a7d";
if (instrumentationKey) {
    retry_with_backoff/* RetryWithBackoff */.j.initialize(instrumentationKey);
    ErrorHandler.initialize(instrumentationKey);
}
const metadata = {
    title: "PrepBettr",
    description: "An AI-powered platform for preparing for mock interviews",
    icons: {
        icon: [
            {
                url: '/icon',
                sizes: '512x512',
                type: 'image/png'
            }
        ],
        apple: [
            {
                url: '/apple-icon',
                sizes: '1024x1024',
                type: 'image/png'
            }
        ],
        other: [
            {
                rel: 'icon',
                url: '/favicon.ico',
                sizes: '256x256'
            }
        ]
    }
};
function RootLayout({ children }) {
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)("html", {
        lang: "en",
        className: "dark",
        children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)("body", {
            className: `${(layout_tsx_import_Mona_Sans_arguments_variable_font_mona_sans_subsets_latin_variableName_monaSans_default()).className} antialiased`,
            style: {
                backgroundColor: "#0a0a0a",
                backgroundImage: "url('/pattern.png')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                backgroundRepeat: "no-repeat",
                backgroundAttachment: "fixed",
                "--color-background": "transparent",
                "--background": "transparent"
            },
            suppressHydrationWarning: true,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(providers["default"], {
                    children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(LoadingContext.LoadingProvider, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(NetworkLoggerInit["default"], {}),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(FirebaseClientInit["default"], {}),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(RouterLoadingHandler.RouterLoadingHandler, {}),
                            /*#__PURE__*/ (0,react_jsx_runtime.jsx)(AuthContext.AuthProvider, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime.jsxs)(TelemetryProvider.TelemetryProvider, {
                                    children: [
                                        ( false || process.env.NEXT_PUBLIC_TESTING === 'true') && /*#__PURE__*/ (0,react_jsx_runtime.jsx)(TestHelperInitializer["default"], {}),
                                        children
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime.jsx)(dist.Toaster, {})
            ]
        })
    });
}


/***/ }),

/***/ 78972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call the default export of \"/Users/dikshantvashistha/PrepBettr/app/providers.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/app/providers.tsx",
"default",
));


/***/ }),

/***/ 82704:
/***/ (() => {



/***/ }),

/***/ 94442:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthProvider: () => (/* binding */ AuthProvider)
/* harmony export */ });
/* unused harmony exports useAuth, AuthContext */
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12907);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__);

const AuthProvider = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call AuthProvider() from the server but AuthProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/contexts/AuthContext.tsx",
"AuthProvider",
);const useAuth = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call useAuth() from the server but useAuth is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/contexts/AuthContext.tsx",
"useAuth",
);const AuthContext = (0,react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_0__.registerClientReference)(
function() { throw new Error("Attempted to call AuthContext() from the server but AuthContext is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component."); },
"/Users/dikshantvashistha/PrepBettr/contexts/AuthContext.tsx",
"AuthContext",
);

/***/ }),

/***/ 94515:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Providers)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js
var react_jsx_runtime = __webpack_require__(60687);
// EXTERNAL MODULE: ./node_modules/@mantine/core/esm/core/MantineProvider/MantineProvider.mjs + 16 modules
var MantineProvider = __webpack_require__(60458);
// EXTERNAL MODULE: ./node_modules/swr/dist/index/index.mjs + 5 modules
var index = __webpack_require__(25995);
// EXTERNAL MODULE: ./node_modules/sonner/dist/index.mjs
var dist = __webpack_require__(52581);
;// ./contexts/SWRProvider.tsx
/* __next_internal_client_entry_do_not_use__ SWRProvider,createOptimisticUpdate,cacheKeys auto */ 


// Global SWR configuration
const swrConfig = {
    // Cache data for 5 minutes by default
    dedupingInterval: 5 * 60 * 1000,
    // Revalidate on focus after 30 seconds
    focusThrottleInterval: 30 * 1000,
    // Revalidate on reconnect
    revalidateOnReconnect: true,
    // Don't revalidate on focus for real-time data (we have listeners)
    revalidateOnFocus: false,
    // Retry failed requests up to 3 times
    errorRetryCount: 3,
    // Exponential backoff for retries
    errorRetryInterval: 1000,
    // Show loading states quickly
    loadingTimeout: 3000,
    // Global error handler
    onError: (error, key)=>{
        console.error('SWR Error:', {
            error,
            key
        });
        // Don't show toast errors for auth-related issues or expected errors
        if (error?.code === 'permission-denied' || error?.message?.includes('auth')) {
            return;
        }
        // Show user-friendly error messages
        if (error?.message) {
            dist/* toast */.o.error('Something went wrong', {
                description: 'Please try again in a moment.'
            });
        }
    },
    // Global success handler for mutations
    onSuccess: (data, key)=>{
    // You can add global success handling here if needed
    // For now, we'll handle success per component
    },
    // Fallback data while loading
    fallback: {},
    // Keep data fresh in background
    revalidateIfStale: true,
    // Keep previous data while revalidating
    keepPreviousData: true,
    // Use suspense for better loading states
    suspense: false
};
function SWRProvider({ children }) {
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(index/* SWRConfig */.BE, {
        value: swrConfig,
        children: children
    });
}
// Utility function to create optimistic updates
function createOptimisticUpdate(currentData, newItem, getId, action) {
    const id = getId(newItem);
    switch(action){
        case 'add':
            return [
                newItem,
                ...currentData
            ];
        case 'update':
            return currentData.map((item)=>getId(item) === id ? {
                    ...item,
                    ...newItem
                } : item);
        case 'delete':
            return currentData.filter((item)=>getId(item) !== id);
        default:
            return currentData;
    }
}
// Utility function for cache invalidation patterns
const cacheKeys = {
    userInterviews: (userId)=>`user-interviews/${userId}`,
    publicInterviews: (userId)=>`public-interviews/${userId}`,
    interview: (interviewId)=>`interviews/${interviewId}`,
    feedback: (interviewId, userId)=>`feedback/${interviewId}/${userId}`,
    userProfile: (userId)=>`users/${userId}`,
    applicationStatus: (applicationId)=>`applicationStatuses/${applicationId}`
};

;// ./app/providers.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


function Providers({ children }) {
    return /*#__PURE__*/ (0,react_jsx_runtime.jsx)(SWRProvider, {
        children: /*#__PURE__*/ (0,react_jsx_runtime.jsx)(MantineProvider/* MantineProvider */.y, {
            theme: {
                fontFamily: 'inherit',
                primaryColor: 'blue'
            },
            children: children
        })
    });
}


/***/ })

};
;