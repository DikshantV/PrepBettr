"use strict";
exports.id = 6955;
exports.ids = [6955];
exports.modules = {

/***/ 26765:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ foundryDocumentIntelligenceService)
/* harmony export */ });
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10756);
/* harmony import */ var _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(98180);
/* harmony import */ var _config_foundry_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(22082);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75931);
/* harmony import */ var _lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(46502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _config_foundry_config__WEBPACK_IMPORTED_MODULE_2__]);
([_azure_identity__WEBPACK_IMPORTED_MODULE_0__, _config_foundry_config__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Azure AI Foundry Document Intelligence Client
 * 
 * Enhanced document analysis using Azure AI Foundry's Document Intelligence service.
 * Provides advanced OCR, layout analysis, and structured extraction capabilities.
 * Replaces and enhances the existing Azure Form Recognizer implementation.
 */ 




// Client-side safety check
const isClient = "undefined" !== 'undefined';
if (isClient) {
    console.warn('[Document Intelligence Client] Running on client side - clients will not be initialized');
}
/**
 * Azure AI Foundry Document Intelligence Service
 */ class FoundryDocumentIntelligenceService {
    /**
   * Initialize the Azure AI Foundry Document Intelligence service
   */ async initialize() {
        if (isClient) {
            console.warn('⚠️ Document Intelligence client cannot be initialized on client side');
            return false;
        }
        if (this.isInitialized) {
            return true;
        }
        try {
            const config = await (0,_config_foundry_config__WEBPACK_IMPORTED_MODULE_2__/* .getFoundryConfig */ .at)();
            // Check if Document Intelligence is configured in Foundry config
            const docIntEndpoint = process.env.AZURE_FOUNDRY_DOCINT_ENDPOINT || config.docIntelligence?.endpoint;
            const docIntApiKey = process.env.AZURE_FOUNDRY_DOCINT_API_KEY || config.docIntelligence?.apiKey;
            if (!docIntEndpoint || !docIntApiKey) {
                console.warn('⚠️ Azure AI Foundry Document Intelligence credentials not found');
                console.log('💡 Configure AZURE_FOUNDRY_DOCINT_ENDPOINT and AZURE_FOUNDRY_DOCINT_API_KEY');
                return false;
            }
            console.log('🔧 Initializing Azure AI Foundry Document Intelligence client...');
            // Create client with either API key or managed identity
            const credential = docIntApiKey.startsWith('https://') ? new _azure_identity__WEBPACK_IMPORTED_MODULE_0__.DefaultAzureCredential() : new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_1__/* .AzureKeyCredential */ .KL(docIntApiKey);
            this.client = new _azure_ai_form_recognizer__WEBPACK_IMPORTED_MODULE_1__/* .DocumentAnalysisClient */ .Pz(docIntEndpoint, credential, {
                additionalPolicies: [
                    {
                        policy: {
                            name: 'PrepBettrDocumentIntelligence',
                            sendRequest: async (request, next)=>{
                                // Add custom headers for tracking
                                request.headers.set('X-Client-Name', 'PrepBettr');
                                request.headers.set('X-Client-Version', '2.0');
                                return next(request);
                            }
                        },
                        position: 'perCall'
                    }
                ],
                retryOptions: {
                    maxRetries: config.connection.retryPolicy.maxRetries,
                    retryDelayInMs: config.connection.retryPolicy.baseDelay
                }
            });
            this.isInitialized = true;
            console.log('✅ Azure AI Foundry Document Intelligence service initialized');
            return true;
        } catch (error) {
            console.error('❌ Failed to initialize Document Intelligence service:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_3__/* .logServerError */ .wh)(error, {
                service: 'foundry-document-intelligence',
                action: 'initialize'
            });
            return false;
        }
    }
    /**
   * Check if service is ready
   */ isReady() {
        return !isClient && this.isInitialized && this.client !== null;
    }
    /**
   * Analyze resume document with enhanced extraction
   */ async analyzeResume(documentBuffer, mimeType, options) {
        if (!this.isReady()) {
            throw new Error('Document Intelligence service not initialized');
        }
        const startTime = Date.now();
        const modelType = options?.modelType || 'resume-analysis';
        const modelConfig = this.modelConfigs[modelType];
        try {
            console.log(`🔍 Analyzing resume with model: ${modelConfig.modelId}`);
            const result = await (0,_lib_utils_retry_with_backoff__WEBPACK_IMPORTED_MODULE_4__/* .retryWithExponentialBackoff */ .y)(async ()=>{
                const poller = await this.client.beginAnalyzeDocument(modelConfig.modelId, documentBuffer, {
                    locale: modelConfig.locale
                });
                return await poller.pollUntilDone();
            }, 'document-intelligence-analyze', undefined, {
                maxRetries: 3,
                baseDelay: 2000,
                maxDelay: 30000
            });
            const processingTime = Date.now() - startTime;
            // Extract structured data from the analysis result
            const extraction = await this.extractStructuredData(result, processingTime);
            // Add ATS analysis if requested
            if (options?.includeAtsAnalysis) {
                extraction.atsAnalysis = await this.performAtsAnalysis(extraction);
            }
            console.log(`✅ Resume analysis completed in ${processingTime}ms`);
            return extraction;
        } catch (error) {
            console.error('❌ Failed to analyze resume with Document Intelligence:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_3__/* .logServerError */ .wh)(error, {
                service: 'foundry-document-intelligence',
                action: 'analyze-resume'
            }, {
                mimeType,
                modelType,
                processingTime: Date.now() - startTime
            });
            throw error;
        }
    }
    /**
   * Compare resume against job description for matching analysis
   */ async compareWithJobDescription(resumeExtraction, jobDescription) {
        try {
            console.log('🎯 Performing job match analysis...');
            // Extract job requirements from description
            const jobRequirements = await this.extractJobRequirements(jobDescription);
            // Perform multi-dimensional matching
            const skillsMatch = this.analyzeSkillsMatch(resumeExtraction.skills, jobRequirements.skills);
            const experienceMatch = this.analyzeExperienceMatch(resumeExtraction.experience, jobRequirements);
            const educationMatch = this.analyzeEducationMatch(resumeExtraction.education, jobRequirements);
            const keywordAnalysis = this.analyzeKeywords(resumeExtraction, jobDescription);
            // Calculate overall score
            const overallScore = this.calculateOverallMatchScore({
                skillsMatch,
                experienceMatch,
                educationMatch,
                keywordAnalysis
            });
            // Generate recommendations
            const recommendations = this.generateMatchRecommendations({
                skillsMatch,
                experienceMatch,
                educationMatch,
                keywordAnalysis
            });
            return {
                overallScore,
                skillsMatch,
                experienceMatch,
                educationMatch,
                keywordAnalysis,
                recommendations
            };
        } catch (error) {
            console.error('❌ Failed to perform job match analysis:', error);
            throw error;
        }
    }
    /**
   * Extract structured data from Document Intelligence result
   */ async extractStructuredData(result, processingTime) {
        const pages = result.pages || [];
        const keyValuePairs = result.keyValuePairs || [];
        const entities = result.entities || [];
        const content = result.content || '';
        // Extract personal information using key-value pairs and patterns
        const personalInfo = this.extractPersonalInfo(keyValuePairs, content, entities);
        // Extract skills with proficiency assessment
        const skills = this.extractEnhancedSkills(content, entities);
        // Extract work experience with quantifiable results
        const experience = this.extractWorkExperience(content, entities);
        // Extract education with validation
        const education = this.extractEducation(content, entities);
        // Extract projects with impact assessment
        const projects = this.extractProjects(content, entities);
        // Extract certifications
        const certifications = this.extractCertifications(content, entities);
        // Extract languages
        const languages = this.extractLanguages(content, entities);
        // Analyze document structure
        const documentStructure = this.analyzeDocumentStructure(result);
        return {
            personalInfo,
            skills,
            experience,
            education,
            projects,
            certifications,
            languages,
            metadata: {
                processingTime,
                pageCount: pages.length,
                modelUsed: 'azure-foundry-document-intelligence',
                overallConfidence: this.calculateOverallConfidence(result),
                languageDetected: result.languages?.[0]?.locale,
                documentStructure
            },
            rawExtraction: result // Store for debugging/export
        };
    }
    /**
   * Extract personal information with confidence scores
   */ extractPersonalInfo(keyValuePairs, content, entities) {
        const personalInfo = {};
        // Extract from key-value pairs first (highest confidence)
        keyValuePairs.forEach((pair)=>{
            const key = pair.key?.content?.toLowerCase() || '';
            const value = pair.value;
            if (key.includes('name') && !personalInfo.name) {
                personalInfo.name = {
                    content: value.content,
                    confidence: value.confidence || 0.9
                };
            } else if (key.includes('email') && !personalInfo.email) {
                personalInfo.email = {
                    content: value.content,
                    confidence: value.confidence || 0.95
                };
            } else if (key.includes('phone') && !personalInfo.phone) {
                personalInfo.phone = {
                    content: value.content,
                    confidence: value.confidence || 0.9
                };
            }
        });
        // Extract from entities if not found in key-value pairs
        entities.forEach((entity)=>{
            if (entity.category === 'Person' && !personalInfo.name) {
                personalInfo.name = {
                    content: entity.content,
                    confidence: entity.confidence
                };
            } else if (entity.category === 'Email' && !personalInfo.email) {
                personalInfo.email = {
                    content: entity.content,
                    confidence: entity.confidence
                };
            } else if (entity.category === 'PhoneNumber' && !personalInfo.phone) {
                personalInfo.phone = {
                    content: entity.content,
                    confidence: entity.confidence
                };
            }
        });
        // Fallback to regex patterns with lower confidence
        if (!personalInfo.email) {
            const emailMatch = content.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/);
            if (emailMatch) {
                personalInfo.email = {
                    content: emailMatch[0],
                    confidence: 0.8
                };
            }
        }
        if (!personalInfo.phone) {
            const phoneMatch = content.match(/(\+?1?[-. \s]?)?\(?[0-9]{3}\)?[-. \s]?[0-9]{3}[-. \s]?[0-9]{4}/);
            if (phoneMatch) {
                personalInfo.phone = {
                    content: phoneMatch[0],
                    confidence: 0.75
                };
            }
        }
        // Extract LinkedIn and GitHub URLs
        const linkedinMatch = content.match(/linkedin\.com\/in\/[\w-]+/i);
        if (linkedinMatch) {
            personalInfo.linkedin = {
                content: `https://${linkedinMatch[0]}`,
                confidence: 0.9
            };
        }
        const githubMatch = content.match(/github\.com\/[\w-]+/i);
        if (githubMatch) {
            personalInfo.github = {
                content: `https://${githubMatch[0]}`,
                confidence: 0.9
            };
        }
        return personalInfo;
    }
    /**
   * Extract skills with proficiency levels and categorization
   */ extractEnhancedSkills(content, entities) {
        const skills = [];
        // Technical skills database for categorization
        const technicalSkills = [
            'javascript',
            'typescript',
            'python',
            'java',
            'react',
            'node',
            'angular',
            'vue',
            'sql',
            'mongodb',
            'postgresql',
            'mysql',
            'docker',
            'kubernetes',
            'aws',
            'azure',
            'tensorflow',
            'pytorch',
            'machine learning',
            'data science',
            'blockchain'
        ];
        const softSkills = [
            'leadership',
            'teamwork',
            'communication',
            'problem solving',
            'critical thinking',
            'project management',
            'agile',
            'scrum'
        ];
        // Extract from content with pattern matching
        const skillsSection = content.match(/(?:skills?|technologies|competencies)[:\s]*([^]*?)(?=\n\s*[A-Z][^:]*:|$)/i);
        if (skillsSection) {
            const skillsText = skillsSection[1];
            // Split by common delimiters
            const detectedSkills = skillsText.replace(/[•\\-\\*]/g, ',').split(/[,\\n]/).map((skill)=>skill.trim()).filter((skill)=>skill.length > 0 && skill.length < 50);
            detectedSkills.forEach((skill)=>{
                const lowerSkill = skill.toLowerCase();
                let category = 'tool';
                let proficiency;
                // Categorize skill
                if (technicalSkills.some((tech)=>lowerSkill.includes(tech))) {
                    category = 'technical';
                } else if (softSkills.some((soft)=>lowerSkill.includes(soft))) {
                    category = 'soft';
                }
                // Detect proficiency indicators
                if (skill.match(/expert|advanced|senior|lead/i)) {
                    proficiency = 'expert';
                } else if (skill.match(/intermediate|mid|experienced/i)) {
                    proficiency = 'intermediate';
                } else if (skill.match(/beginner|basic|junior/i)) {
                    proficiency = 'beginner';
                } else if (skill.match(/proficient|skilled/i)) {
                    proficiency = 'advanced';
                }
                skills.push({
                    skill: skill,
                    proficiency,
                    category,
                    confidence: 0.8,
                    yearsOfExperience: this.extractYearsOfExperience(skill, content)
                });
            });
        }
        return skills;
    }
    /**
   * Extract work experience with quantifiable results and management scope
   */ extractWorkExperience(content, entities) {
        const experience = [];
        // Pattern to match experience sections
        const expSection = content.match(/(?:experience|employment|work history)[:\s]*([^]*?)(?=\n\s*(?:education|skills?|projects?)[:\s]|$)/i);
        if (!expSection) return experience;
        const expText = expSection[1];
        // Split into individual job entries (basic pattern)
        const jobEntries = expText.split(/\n(?=[A-Z].*(?:Inc\.|Corp\.|LLC|Ltd\.|Company|\d{4}))/);
        jobEntries.forEach((entry)=>{
            if (entry.trim().length < 50) return; // Skip short entries
            const job = this.parseJobEntry(entry.trim());
            if (job.company.content && job.position.content) {
                experience.push(job);
            }
        });
        return experience;
    }
    /**
   * Parse individual job entry
   */ parseJobEntry(entry) {
        const lines = entry.split('\n').map((line)=>line.trim());
        // Extract company and position (usually first few lines)
        const companyMatch = lines[0].match(/^(.+?)(?:\s+[-–—]\s+(.+))?$/);
        const company = companyMatch ? companyMatch[1] : lines[0];
        const position = companyMatch ? companyMatch[2] || lines[1] : lines[1];
        // Extract dates
        const datePattern = /(\d{1,2}\/\d{4}|\w+\s+\d{4}|\d{4})\s*[-–—]\s*(\d{1,2}\/\d{4}|\w+\s+\d{4}|\d{4}|present)/i;
        const dateMatch = entry.match(datePattern);
        // Extract achievements and quantifiable results
        const achievements = lines.filter((line)=>line.match(/^[•\\-\\*]/) || line.includes('achieved') || line.includes('%') || line.includes('$')).map((line)=>({
                content: line.replace(/^[•\\-\\*]\s*/, ''),
                confidence: 0.8
            }));
        // Extract quantifiable results
        const quantifiableResults = this.extractQuantifiableResults(entry);
        // Extract management scope
        const managementScope = this.extractManagementScope(entry);
        return {
            company: {
                content: company,
                confidence: 0.9
            },
            position: {
                content: position,
                confidence: 0.9
            },
            startDate: dateMatch ? {
                content: dateMatch[1],
                confidence: 0.8
            } : undefined,
            endDate: dateMatch ? {
                content: dateMatch[2],
                confidence: 0.8
            } : undefined,
            isCurrent: dateMatch ? dateMatch[2].toLowerCase().includes('present') : false,
            description: {
                content: lines.slice(2).join(' '),
                confidence: 0.7
            },
            achievements,
            technologies: this.extractTechnologies(entry),
            managementScope,
            quantifiableResults,
            confidence: 0.8
        };
    }
    /**
   * Extract quantifiable results from job description
   */ extractQuantifiableResults(text) {
        const results = [];
        // Pattern for percentages
        const percentMatches = text.match(/(\w+[^.]*?)(\d+)%/g);
        percentMatches?.forEach((match)=>{
            const parts = match.match(/(\w+[^.]*?)(\d+)%/);
            if (parts) {
                results.push({
                    metric: parts[1].trim(),
                    value: parseInt(parts[2]),
                    unit: 'percentage',
                    impact: match
                });
            }
        });
        // Pattern for monetary values
        const moneyMatches = text.match(/\$[\d,]+(?:\.\d{2})?[KMB]?/g);
        moneyMatches?.forEach((match)=>{
            const value = match.replace(/[\$,]/g, '');
            results.push({
                metric: 'revenue/savings',
                value: parseFloat(value),
                unit: 'currency',
                impact: match
            });
        });
        return results;
    }
    /**
   * Extract management scope information
   */ extractManagementScope(text) {
        const teamSizeMatch = text.match(/(?:managed|led|supervised).*?(\d+).*?(?:people|team|members|employees)/i);
        const budgetMatch = text.match(/budget.*?\$[\d,]+(?:\.\d{2})?[KMB]?/i);
        if (teamSizeMatch || budgetMatch) {
            return {
                teamSize: teamSizeMatch ? parseInt(teamSizeMatch[1]) : undefined,
                budget: budgetMatch ? budgetMatch[0] : undefined,
                responsibilities: text.match(/(?:managed|led|supervised|oversaw)[^.]+/gi) || []
            };
        }
        return undefined;
    }
    /**
   * Extract technologies from text
   */ extractTechnologies(text) {
        const techKeywords = [
            'javascript',
            'typescript',
            'python',
            'java',
            'react',
            'angular',
            'vue',
            'node',
            'sql',
            'mongodb',
            'postgresql',
            'docker',
            'kubernetes',
            'aws',
            'azure',
            'git'
        ];
        return techKeywords.filter((tech)=>text.toLowerCase().includes(tech.toLowerCase()));
    }
    /**
   * Extract years of experience for a skill from context
   */ extractYearsOfExperience(skill, content) {
        const skillPattern = new RegExp(`${skill}.*?(\\d+)\\s*years?`, 'i');
        const match = content.match(skillPattern);
        return match ? parseInt(match[1]) : undefined;
    }
    /**
   * Extract education information
   */ extractEducation(content, entities) {
        const education = [];
        const eduSection = content.match(/(?:education|academic)[:\s]*([^]*?)(?=\n\s*(?:experience|skills?|projects?)[:\s]|$)/i);
        if (!eduSection) return education;
        const eduText = eduSection[1];
        const lines = eduText.split('\n').filter((line)=>line.trim());
        let currentEdu = {};
        lines.forEach((line)=>{
            line = line.trim();
            if (!line) return;
            // Check if this looks like a new education entry
            if (line.match(/university|college|institute|school/i)) {
                if (currentEdu.institution) {
                    education.push(currentEdu);
                }
                currentEdu = {
                    institution: {
                        content: line,
                        confidence: 0.9
                    },
                    confidence: 0.8
                };
            } else if (line.match(/bachelor|master|phd|doctorate|degree/i)) {
                currentEdu.degree = {
                    content: line,
                    confidence: 0.9
                };
            } else if (line.match(/\d{4}/)) {
                const dateMatch = line.match(/(\d{4})\s*[-–—]\s*(\d{4})/);
                if (dateMatch) {
                    currentEdu.startDate = {
                        content: dateMatch[1],
                        confidence: 0.8
                    };
                    currentEdu.endDate = {
                        content: dateMatch[2],
                        confidence: 0.8
                    };
                }
            }
        });
        if (currentEdu.institution) {
            education.push(currentEdu);
        }
        return education;
    }
    /**
   * Extract projects information
   */ extractProjects(content, entities) {
        const projects = [];
        const projSection = content.match(/(?:projects?)[:\s]*([^]*?)(?=\n\s*(?:experience|education|skills?)[:\s]|$)/i);
        if (!projSection) return projects;
        const projText = projSection[1];
        const projectEntries = projText.split(/\n(?=[A-Z][^:\n]+)/);
        projectEntries.forEach((entry)=>{
            if (entry.trim().length < 20) return;
            const lines = entry.split('\n').map((line)=>line.trim());
            const projectName = lines[0];
            const description = lines.slice(1).join(' ');
            projects.push({
                name: {
                    content: projectName,
                    confidence: 0.8
                },
                description: {
                    content: description,
                    confidence: 0.7
                },
                technologies: this.extractTechnologies(entry),
                confidence: 0.7
            });
        });
        return projects;
    }
    /**
   * Extract certifications
   */ extractCertifications(content, entities) {
        const certifications = [];
        const certSection = content.match(/(?:certifications?|certificates)[:\s]*([^]*?)(?=\n\s*(?:experience|education|skills?|projects?)[:\s]|$)/i);
        if (!certSection) return certifications;
        const certText = certSection[1];
        const lines = certText.split('\n').filter((line)=>line.trim());
        lines.forEach((line)=>{
            line = line.trim();
            if (line.length < 10) return;
            const parts = line.split(/[-–—,]/);
            const name = parts[0]?.trim();
            const issuer = parts[1]?.trim();
            if (name) {
                certifications.push({
                    name: {
                        content: name,
                        confidence: 0.8
                    },
                    issuer: {
                        content: issuer || 'Unknown',
                        confidence: issuer ? 0.7 : 0.3
                    },
                    status: 'unknown',
                    confidence: 0.7
                });
            }
        });
        return certifications;
    }
    /**
   * Extract languages
   */ extractLanguages(content, entities) {
        const languages = [];
        const langSection = content.match(/(?:languages?)[:\s]*([^]*?)(?=\n\s*[A-Z][^:]*:|$)/i);
        if (!langSection) return languages;
        const langText = langSection[1];
        const langEntries = langText.split(/[,\n]/).filter((entry)=>entry.trim());
        langEntries.forEach((entry)=>{
            entry = entry.trim();
            const parts = entry.split(/[-–—:]/);
            const name = parts[0]?.trim();
            const proficiencyText = parts[1]?.trim().toLowerCase();
            let proficiency = 'conversational';
            if (proficiencyText) {
                if (proficiencyText.includes('native') || proficiencyText.includes('mother tongue')) {
                    proficiency = 'native';
                } else if (proficiencyText.includes('fluent') || proficiencyText.includes('advanced')) {
                    proficiency = 'fluent';
                } else if (proficiencyText.includes('basic') || proficiencyText.includes('beginner')) {
                    proficiency = 'basic';
                }
            }
            if (name && name.length > 2) {
                languages.push({
                    name: name,
                    proficiency,
                    confidence: 0.7
                });
            }
        });
        return languages;
    }
    /**
   * Analyze document structure
   */ analyzeDocumentStructure(result) {
        const content = result.content || '';
        return {
            hasHeaders: /^[A-Z][^a-z]*$/m.test(content),
            hasBulletPoints: /[•\\-\\*]/.test(content),
            hasTables: result.tables && result.tables.length > 0,
            columnLayout: content.includes('\t') || content.match(/\s{4,}/) !== null
        };
    }
    /**
   * Calculate overall confidence score
   */ calculateOverallConfidence(result) {
        const pages = result.pages || [];
        if (pages.length === 0) return 0;
        let totalConfidence = 0;
        let totalElements = 0;
        pages.forEach((page)=>{
            const lines = page.lines || [];
            lines.forEach((line)=>{
                totalConfidence += line.confidence || 0;
                totalElements++;
            });
        });
        return totalElements > 0 ? totalConfidence / totalElements : 0;
    }
    /**
   * Perform ATS optimization analysis
   */ async performAtsAnalysis(extraction) {
        // Simplified ATS analysis - can be enhanced with more sophisticated algorithms
        const recommendations = [];
        const formatIssues = [];
        const structuralOptimizations = [];
        // Check for common ATS issues
        if (!extraction.personalInfo.email) {
            formatIssues.push('Missing email address');
        }
        if (!extraction.personalInfo.phone) {
            formatIssues.push('Missing phone number');
        }
        if (extraction.skills.length < 5) {
            recommendations.push('Add more relevant skills to improve keyword matching');
        }
        if (extraction.experience.length === 0) {
            structuralOptimizations.push('Add work experience section');
        }
        // Calculate keyword density
        const keywordDensity = {};
        const allText = JSON.stringify(extraction).toLowerCase();
        // Common job keywords
        const jobKeywords = [
            'experience',
            'skills',
            'manage',
            'develop',
            'lead',
            'project',
            'team'
        ];
        jobKeywords.forEach((keyword)=>{
            const matches = (allText.match(new RegExp(keyword, 'g')) || []).length;
            keywordDensity[keyword] = matches;
        });
        // Calculate ATS score (simplified)
        let score = 70; // Base score
        if (extraction.personalInfo.email) score += 5;
        if (extraction.personalInfo.phone) score += 5;
        if (extraction.skills.length >= 10) score += 10;
        if (extraction.experience.length >= 2) score += 10;
        score -= formatIssues.length * 5;
        return {
            score: Math.max(0, Math.min(100, score)),
            recommendations,
            keywordDensity,
            formatIssues,
            structuralOptimizations
        };
    }
    // Placeholder methods for job matching (to be implemented)
    async extractJobRequirements(jobDescription) {
        // TODO: Implement job requirements extraction
        return {
            skills: [],
            experience: [],
            education: []
        };
    }
    analyzeSkillsMatch(resumeSkills, jobSkills) {
        // TODO: Implement skills matching algorithm
        return {
            matchedSkills: [],
            missingSkills: [],
            skillGapScore: 0
        };
    }
    analyzeExperienceMatch(experience, jobRequirements) {
        // TODO: Implement experience matching
        return {
            yearsMatch: false,
            industryMatch: false,
            roleMatch: false,
            seniorityMatch: false
        };
    }
    analyzeEducationMatch(education, jobRequirements) {
        // TODO: Implement education matching
        return {
            degreeMatch: false,
            fieldMatch: false
        };
    }
    analyzeKeywords(extraction, jobDescription) {
        // TODO: Implement keyword analysis
        return {
            totalKeywords: 0,
            matchedKeywords: 0,
            missedKeywords: [],
            keywordDensity: 0
        };
    }
    calculateOverallMatchScore(analysis) {
        // TODO: Implement overall score calculation
        return 0;
    }
    generateMatchRecommendations(analysis) {
        // TODO: Implement recommendation generation
        return [];
    }
    /**
   * Dispose of resources
   */ dispose() {
        this.client = null;
        this.isInitialized = false;
        console.log('🧹 Document Intelligence service disposed');
    }
    constructor(){
        this.client = null;
        this.isInitialized = false;
        // Model configurations for different document types
        this.modelConfigs = {
            'resume-analysis': {
                modelId: 'prebuilt-layout'
            },
            'resume-structured': {
                modelId: 'prebuilt-document'
            },
            'general-document': {
                modelId: 'prebuilt-read'
            }
        };
    }
}
// Export singleton instance
const foundryDocumentIntelligenceService = new FoundryDocumentIntelligenceService();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 46502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   j: () => (/* binding */ RetryWithBackoff),
/* harmony export */   y: () => (/* binding */ retryWithExponentialBackoff)
/* harmony export */ });

class RetryWithBackoff {
    static initialize(instrumentationKey) {
        if (instrumentationKey && "undefined" !== 'undefined') {}
    }
    /**
   * Execute a function with exponential backoff retry logic
   */ static async execute(fn, options = {}) {
        const { maxRetries = 3, baseDelay = 1000, maxDelay = 30000, jitter = true, retryCondition = this.defaultRetryCondition, onRetry, userId, action = 'unknown' } = options;
        const startTime = Date.now();
        let lastError;
        for(let attempt = 0; attempt <= maxRetries; attempt++){
            try {
                const result = await fn();
                // Log success metrics
                if (attempt > 0) {
                    this.logRetrySuccess({
                        attempt: attempt + 1,
                        totalAttempts: attempt + 1,
                        delay: 0,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                }
                return result;
            } catch (error) {
                lastError = error;
                // Check if we should retry
                if (attempt === maxRetries || !retryCondition(error)) {
                    // Log final failure
                    this.logRetryFailure({
                        attempt: attempt + 1,
                        totalAttempts: maxRetries + 1,
                        delay: 0,
                        error,
                        userId,
                        action,
                        startTime,
                        endTime: Date.now()
                    });
                    throw error;
                }
                // Calculate delay for next attempt
                const exponentialDelay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
                const delay = jitter ? exponentialDelay + Math.random() * exponentialDelay * 0.1 // Add 10% jitter
                 : exponentialDelay;
                // Log retry attempt
                this.logRetryAttempt({
                    attempt: attempt + 1,
                    totalAttempts: maxRetries + 1,
                    delay,
                    error,
                    userId,
                    action,
                    startTime
                });
                // Execute retry callback if provided
                if (onRetry) {
                    onRetry(error, attempt + 1);
                }
                // Wait before next attempt
                await this.sleep(delay);
            }
        }
        throw lastError;
    }
    /**
   * Default retry condition - retry on network errors, rate limits, and server errors
   */ static defaultRetryCondition(error) {
        // Network errors
        if (error.code === 'ECONNRESET' || error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
            return true;
        }
        // HTTP status codes that should be retried
        if (error.response?.status) {
            const status = error.response.status;
            return status === 429 || // Rate limit
            status === 502 || // Bad Gateway
            status === 503 || // Service Unavailable
            status === 504; // Gateway Timeout
        }
        // Azure OpenAI specific errors
        if (error.message?.includes('rate limit') || error.message?.includes('throttled') || error.message?.includes('quota exceeded')) {
            return true;
        }
        return false;
    }
    /**
   * Sleep for specified milliseconds
   */ static sleep(ms) {
        return new Promise((resolve)=>setTimeout(resolve, ms));
    }
    /**
   * Log retry attempt
   */ static logRetryAttempt(metrics) {
        const logData = {
            level: 'warn',
            message: `Retry attempt ${metrics.attempt}/${metrics.totalAttempts} for ${metrics.action}`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                delay: metrics.delay,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name
                },
                timestamp: new Date().toISOString()
            }
        };
        console.warn('RETRY_ATTEMPT', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 2,
                properties: logData.properties
            });
        }
    }
    /**
   * Log retry success
   */ static logRetrySuccess(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'info',
            message: `Retry succeeded for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                timestamp: new Date().toISOString()
            }
        };
        console.log('RETRY_SUCCESS', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackTrace({
                message: logData.message,
                severityLevel: 1,
                properties: logData.properties
            });
            // Track custom metric for retry success
            this.appInsights.trackMetric({
                name: 'RetrySuccess',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
    /**
   * Log retry failure
   */ static logRetryFailure(metrics) {
        const duration = (metrics.endTime || Date.now()) - metrics.startTime;
        const logData = {
            level: 'error',
            message: `Retry failed for ${metrics.action} after ${metrics.attempt} attempts`,
            properties: {
                userId: metrics.userId,
                action: metrics.action,
                attempt: metrics.attempt,
                totalAttempts: metrics.totalAttempts,
                duration,
                error: {
                    message: metrics.error?.message,
                    code: metrics.error?.code,
                    status: metrics.error?.response?.status,
                    name: metrics.error?.name,
                    stack: metrics.error?.stack
                },
                timestamp: new Date().toISOString()
            }
        };
        console.error('RETRY_FAILURE', JSON.stringify(logData));
        // Send to Application Insights
        if (this.appInsights) {
            this.appInsights.trackException({
                exception: metrics.error,
                properties: logData.properties,
                severityLevel: 3 // Error
            });
            // Track custom metric for retry failure
            this.appInsights.trackMetric({
                name: 'RetryFailure',
                average: metrics.attempt,
                sampleCount: 1,
                properties: {
                    action: metrics.action,
                    userId: metrics.userId || 'unknown'
                }
            });
        }
    }
}
/**
 * Convenience function for common retry scenarios
 */ async function retryWithExponentialBackoff(fn, action, userId, options) {
    return RetryWithBackoff.execute(fn, {
        action,
        userId,
        ...options
    });
}


/***/ }),

/***/ 70114:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Nv: () => (/* binding */ getCosmosDbConfig)
/* harmony export */ });
/* unused harmony exports environmentLoader, loadEnvironmentConfig, isCosmosDbEnabled, getEnvironmentName */
/* harmony import */ var _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(82802);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(75931);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_0__]);
_lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Environment Configuration Loader
 * 
 * Provides centralized environment variable management with hierarchical loading:
 * 1. Azure App Configuration (primary)
 * 2. Azure Key Vault (sensitive secrets)
 * 3. Environment variables (fallback for local dev)
 * 
 * Special handling for Cosmos DB connection strings and other sensitive data.
 */ 

// ===== CONFIGURATION LOADER =====
class EnvironmentConfigurationLoader {
    /**
   * Load environment configuration with hierarchy
   */ async load() {
        if (this.config && this.initialized) {
            return this.config;
        }
        try {
            console.log('🔧 Loading environment configuration...');
            // Load base environment settings
            const environment = this.getEnvironment();
            // Load Cosmos DB configuration
            const cosmosDb = await this.loadCosmosDbConfig();
            // Load Azure service configuration
            const azure = await this.loadAzureConfig();
            // Load Firebase configuration
            const firebase = await this.loadFirebaseConfig();
            // Load feature flags
            const features = await this.loadFeatureConfig();
            this.config = {
                environment,
                cosmosDb,
                azure,
                firebase,
                features
            };
            this.initialized = true;
            console.log(`✅ Environment configuration loaded for ${environment}`);
            return this.config;
        } catch (error) {
            console.error('❌ Failed to load environment configuration:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_1__/* .logServerError */ .wh)(error, {
                service: 'environment-loader',
                action: 'load'
            });
            // Return minimal fallback configuration
            return this.getFallbackConfig();
        }
    }
    /**
   * Load Cosmos DB configuration with hierarchy
   */ async loadCosmosDbConfig() {
        try {
            // Try unified config service first
            const [connectionString, maxRUPerSecond, batchSize, connectionTimeout, retryAttempts] = await Promise.all([
                this.getConfigValue('data.cosmos.connectionString', process.env.COSMOS_CONNECTION_STRING),
                this.getConfigValue('data.cosmos.maxRUPerSecond', 4000),
                this.getConfigValue('data.cosmos.batchSize', 100),
                this.getConfigValue('data.cosmos.connectionTimeout', 10000),
                this.getConfigValue('data.cosmos.retryAttempts', 3)
            ]);
            if (!connectionString) {
                throw new Error('Cosmos DB connection string is required');
            }
            return {
                connectionString,
                database: process.env.COSMOS_DATABASE || 'prepbettr',
                maxRUPerSecond: Number(maxRUPerSecond),
                batchSize: Number(batchSize),
                connectionTimeout: Number(connectionTimeout),
                retryAttempts: Number(retryAttempts)
            };
        } catch (error) {
            console.warn('⚠️ Failed to load Cosmos DB config from unified service, using environment fallback');
            return {
                connectionString: process.env.COSMOS_CONNECTION_STRING || '',
                database: process.env.COSMOS_DATABASE || 'prepbettr',
                maxRUPerSecond: Number(process.env.COSMOS_MAX_RU_PER_SECOND || 4000),
                batchSize: Number(process.env.COSMOS_BATCH_SIZE || 100),
                connectionTimeout: Number(process.env.COSMOS_CONNECTION_TIMEOUT || 10000),
                retryAttempts: Number(process.env.COSMOS_RETRY_ATTEMPTS || 3)
            };
        }
    }
    /**
   * Load Azure service configuration
   */ async loadAzureConfig() {
        return {
            appConfigConnectionString: process.env.AZURE_APP_CONFIG_CONNECTION_STRING,
            appConfigEndpoint: process.env.AZURE_APP_CONFIG_ENDPOINT,
            keyVaultUrl: process.env.AZURE_KEY_VAULT_URL
        };
    }
    /**
   * Load Firebase configuration
   */ async loadFirebaseConfig() {
        try {
            const [clientKey, adminKey] = await Promise.all([
                this.getConfigValue('auth.firebase.clientKey', "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8"),
                this.getConfigValue('auth.firebase.adminKey', process.env.FIREBASE_ADMIN_KEY)
            ]);
            return {
                clientKey,
                adminKey
            };
        } catch (error) {
            console.warn('⚠️ Failed to load Firebase config from unified service, using environment fallback');
            return {
                clientKey: "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8",
                adminKey: process.env.FIREBASE_ADMIN_KEY
            };
        }
    }
    /**
   * Load feature configuration
   */ async loadFeatureConfig() {
        try {
            const [enableCosmosDb, enableUnifiedConfig, enableKeyVault] = await Promise.all([
                this.getConfigValue('features.enableCosmosDb', true),
                this.getConfigValue('features.enableUnifiedConfig', true),
                this.getConfigValue('features.enableKeyVault', false)
            ]);
            return {
                enableCosmosDb: Boolean(enableCosmosDb),
                enableUnifiedConfig: Boolean(enableUnifiedConfig),
                enableKeyVault: Boolean(enableKeyVault)
            };
        } catch (error) {
            console.warn('⚠️ Failed to load feature config from unified service, using defaults');
            return {
                enableCosmosDb: "production" === 'production',
                enableUnifiedConfig: true,
                enableKeyVault: false
            };
        }
    }
    /**
   * Get configuration value with fallback hierarchy
   */ async getConfigValue(key, fallback) {
        try {
            // Try unified config service first
            const value = await _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.get(key, fallback);
            return value;
        } catch (error) {
            // Fall back to provided fallback value
            console.warn(`⚠️ Failed to get config ${key} from unified service:`, error);
            return fallback;
        }
    }
    /**
   * Determine current environment
   */ getEnvironment() {
        const env = "production" || 0;
        const vercelEnv = process.env.VERCEL_ENV;
        if (env === 'production') {
            return 'production';
        } else if (vercelEnv === 'preview' || process.env.APP_ENV === 'staging') {
            return 'staging';
        } else {
            return 'development';
        }
    }
    /**
   * Get fallback configuration when loading fails
   */ getFallbackConfig() {
        console.warn('⚠️ Using fallback environment configuration');
        return {
            environment: this.getEnvironment(),
            cosmosDb: {
                connectionString: process.env.COSMOS_CONNECTION_STRING || '',
                database: process.env.COSMOS_DATABASE || 'prepbettr',
                maxRUPerSecond: 4000,
                batchSize: 100,
                connectionTimeout: 10000,
                retryAttempts: 3
            },
            azure: {
                appConfigConnectionString: process.env.AZURE_APP_CONFIG_CONNECTION_STRING,
                appConfigEndpoint: process.env.AZURE_APP_CONFIG_ENDPOINT,
                keyVaultUrl: process.env.AZURE_KEY_VAULT_URL
            },
            firebase: {
                clientKey: "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8",
                adminKey: process.env.FIREBASE_ADMIN_KEY
            },
            features: {
                enableCosmosDb: "production" === 'production',
                enableUnifiedConfig: false,
                enableKeyVault: false
            }
        };
    }
    /**
   * Refresh configuration (useful for hot reloading in development)
   */ async refresh() {
        this.config = null;
        this.initialized = false;
        return await this.load();
    }
    /**
   * Get current configuration (throws if not loaded)
   */ getCurrentConfig() {
        if (!this.config) {
            throw new Error('Environment configuration not loaded. Call load() first.');
        }
        return this.config;
    }
    /**
   * Check if configuration is loaded
   */ isLoaded() {
        return this.initialized && this.config !== null;
    }
    /**
   * Export configuration for deployment scripts
   */ exportForDeployment() {
        const config = this.getCurrentConfig();
        return {
            NODE_ENV: config.environment,
            COSMOS_DATABASE: config.cosmosDb.database,
            COSMOS_MAX_RU_PER_SECOND: config.cosmosDb.maxRUPerSecond.toString(),
            COSMOS_BATCH_SIZE: config.cosmosDb.batchSize.toString(),
            COSMOS_CONNECTION_TIMEOUT: config.cosmosDb.connectionTimeout.toString(),
            COSMOS_RETRY_ATTEMPTS: config.cosmosDb.retryAttempts.toString(),
            // NOTE: Don't export connection strings or sensitive keys for security
            AZURE_APP_CONFIG_ENDPOINT: config.azure.appConfigEndpoint || '',
            AZURE_KEY_VAULT_URL: config.azure.keyVaultUrl || ''
        };
    }
    constructor(){
        this.config = null;
        this.initialized = false;
    }
}
// ===== SINGLETON INSTANCE =====
const environmentLoader = new EnvironmentConfigurationLoader();
// ===== CONVENIENCE FUNCTIONS =====
/**
 * Load environment configuration (idempotent)
 */ async function loadEnvironmentConfig() {
    return await environmentLoader.load();
}
/**
 * Get Cosmos DB configuration
 */ async function getCosmosDbConfig() {
    const config = await loadEnvironmentConfig();
    return config.cosmosDb;
}
/**
 * Check if Cosmos DB is enabled
 */ async function isCosmosDbEnabled() {
    try {
        const config = await loadEnvironmentConfig();
        return config.features.enableCosmosDb && !!config.cosmosDb.connectionString;
    } catch (error) {
        console.warn('Failed to check Cosmos DB status:', error);
        return false;
    }
}
/**
 * Get environment name
 */ async function getEnvironmentName() {
    const config = await loadEnvironmentConfig();
    return config.environment;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (environmentLoader)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 81599:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   h: () => (/* binding */ azureCosmosService)
/* harmony export */ });
/* harmony import */ var _azure_cosmos__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(46602);
/* harmony import */ var _lib_config_environment_loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(70114);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_cosmos__WEBPACK_IMPORTED_MODULE_0__, _lib_config_environment_loader__WEBPACK_IMPORTED_MODULE_1__]);
([_azure_cosmos__WEBPACK_IMPORTED_MODULE_0__, _lib_config_environment_loader__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


class AzureCosmosService {
    constructor(){
        this.client = null;
        this.database = null;
        this.containers = new Map();
        this.initialized = false;
    // Client initialization is now deferred to initialize() method
    // to use the unified environment loader
    }
    async initialize() {
        if (this.initialized) return;
        try {
            // Load Cosmos DB configuration from unified environment loader
            const cosmosConfig = await (0,_lib_config_environment_loader__WEBPACK_IMPORTED_MODULE_1__/* .getCosmosDbConfig */ .Nv)();
            if (!cosmosConfig.connectionString) {
                throw new Error('Cosmos DB connection string not available in configuration');
            }
            // Initialize Cosmos client with configuration
            this.client = new _azure_cosmos__WEBPACK_IMPORTED_MODULE_0__.CosmosClient(cosmosConfig.connectionString);
            // Create or get database
            const { database } = await this.client.databases.createIfNotExists({
                id: cosmosConfig.database
            });
            this.database = database;
            // Define containers with their partition keys
            const containerDefinitions = [
                {
                    id: 'users',
                    partitionKey: '/userId'
                },
                {
                    id: 'interviews',
                    partitionKey: '/userId'
                },
                {
                    id: 'feedback',
                    partitionKey: '/userId'
                },
                {
                    id: 'resumes',
                    partitionKey: '/userId'
                },
                {
                    id: 'usage',
                    partitionKey: '/userId'
                },
                {
                    id: 'jobListings',
                    partitionKey: '/id'
                },
                {
                    id: 'applications',
                    partitionKey: '/userId'
                },
                {
                    id: 'autoApplySettings',
                    partitionKey: '/userId'
                },
                {
                    id: 'automationLogs',
                    partitionKey: '/userId'
                },
                {
                    id: 'subscriptionEvents',
                    partitionKey: '/id'
                },
                {
                    id: 'dataDeletionRequests',
                    partitionKey: '/userId'
                },
                {
                    id: 'dataProtectionAuditLog',
                    partitionKey: '/userId'
                },
                {
                    id: 'notificationEvents',
                    partitionKey: '/userId'
                },
                {
                    id: 'featureErrors',
                    partitionKey: '/featureName'
                },
                {
                    id: 'errorBudgets',
                    partitionKey: '/featureName'
                },
                {
                    id: 'emailVerifications',
                    partitionKey: '/userId'
                },
                {
                    id: 'profiles',
                    partitionKey: '/userId'
                }
            ];
            // Create containers
            if (!this.database) {
                throw new Error('Database initialization failed');
            }
            for (const containerDef of containerDefinitions){
                const { container } = await this.database.containers.createIfNotExists({
                    id: containerDef.id,
                    partitionKey: containerDef.partitionKey
                });
                this.containers.set(containerDef.id, container);
            }
            this.initialized = true;
            console.log('✅ Azure Cosmos DB service initialized');
        } catch (error) {
            console.error('❌ Failed to initialize Azure Cosmos DB:', error);
            throw error;
        }
    }
    getContainer(containerName) {
        const container = this.containers.get(containerName);
        if (!container) {
            throw new Error(`Container ${containerName} not found. Make sure initialize() was called.`);
        }
        return container;
    }
    // Users operations
    async createUser(userData) {
        await this.initialize();
        const container = this.getContainer('users');
        const document = {
            id: userData.userId,
            ...userData,
            _partitionKey: userData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getUser(userId) {
        await this.initialize();
        const container = this.getContainer('users');
        try {
            const { resource } = await container.item(userId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async updateUser(userId, updates) {
        await this.initialize();
        const container = this.getContainer('users');
        const { resource: existing } = await container.item(userId, userId).read();
        if (!existing) throw new Error('User not found');
        const updated = {
            ...existing,
            ...updates,
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.item(userId, userId).replace(updated);
    }
    // Interviews operations
    async createInterview(interviewData) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const id = `interview_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...interviewData,
            _partitionKey: interviewData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getInterview(interviewId, userId) {
        await this.initialize();
        const container = this.getContainer('interviews');
        try {
            const { resource } = await container.item(interviewId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async getUserInterviews(userId) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId ORDER BY c.createdAt DESC',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    async getPublicInterviews(userId, limit = 20) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId AND c.finalized = true ORDER BY c.createdAt DESC OFFSET 0 LIMIT @limit',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                },
                {
                    name: '@limit',
                    value: limit
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    async getPublicInterviewsExcludingUser(excludeUserId, limit = 20) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.finalized = true AND c.userId != @excludeUserId ORDER BY c.createdAt DESC OFFSET 0 LIMIT @limit',
            parameters: [
                {
                    name: '@excludeUserId',
                    value: excludeUserId
                },
                {
                    name: '@limit',
                    value: limit
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    async updateInterview(interviewId, userId, updates) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const { resource: existing } = await container.item(interviewId, userId).read();
        if (!existing) throw new Error('Interview not found');
        const updated = {
            ...existing,
            ...updates,
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.item(interviewId, userId).replace(updated);
    }
    async deleteInterview(interviewId, userId) {
        await this.initialize();
        const container = this.getContainer('interviews');
        await container.item(interviewId, userId).delete();
    }
    // Feedback operations
    async createFeedback(feedbackData) {
        await this.initialize();
        const container = this.getContainer('feedback');
        const id = `feedback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...feedbackData,
            _partitionKey: feedbackData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getFeedbackByInterview(interviewId, userId) {
        await this.initialize();
        const container = this.getContainer('feedback');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.interviewId = @interviewId AND c.userId = @userId',
            parameters: [
                {
                    name: '@interviewId',
                    value: interviewId
                },
                {
                    name: '@userId',
                    value: userId
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources[0] || null;
    }
    // Resume operations
    async saveResume(resumeData) {
        await this.initialize();
        const container = this.getContainer('resumes');
        const document = {
            ...resumeData,
            _partitionKey: resumeData.userId
        };
        const { resource } = await container.items.upsert(document);
        return resource.id;
    }
    async getUserResume(userId) {
        await this.initialize();
        const container = this.getContainer('resumes');
        try {
            const { resource } = await container.item(userId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async deleteUserResume(userId) {
        await this.initialize();
        const container = this.getContainer('resumes');
        try {
            await container.item(userId, userId).delete();
        } catch (error) {
            if (error.code === 404) return; // Already deleted
            throw error;
        }
    }
    // Usage operations
    async getUserUsage(userId) {
        await this.initialize();
        const container = this.getContainer('usage');
        try {
            const { resource } = await container.item(userId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async initializeUserUsage(userId) {
        await this.initialize();
        const container = this.getContainer('usage');
        const usageData = {
            id: userId,
            userId,
            interviews: {
                count: 0,
                limit: 3
            },
            resumes: {
                count: 0,
                limit: 2
            },
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.items.upsert(usageData);
    }
    async incrementUsage(userId, type) {
        await this.initialize();
        const container = this.getContainer('usage');
        const { resource: existing } = await container.item(userId, userId).read();
        if (!existing) {
            await this.initializeUserUsage(userId);
            return this.incrementUsage(userId, type);
        }
        const updated = {
            ...existing,
            [type]: {
                ...existing[type],
                count: existing[type].count + 1
            },
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.item(userId, userId).replace(updated);
    }
    async checkUsageLimit(userId, type) {
        const usage = await this.getUserUsage(userId);
        if (!usage) {
            await this.initializeUserUsage(userId);
            return true;
        }
        return usage[type].count < usage[type].limit;
    }
    // Job-related operations
    async createJobListing(jobData) {
        await this.initialize();
        const container = this.getContainer('jobListings');
        const id = `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...jobData,
            _partitionKey: id
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getActiveJobListings(userId) {
        await this.initialize();
        const container = this.getContainer('jobListings');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.isActive = true AND (ARRAY_CONTAINS(c.discoveredBy, @userId) OR ARRAY_LENGTH(c.discoveredBy) = 0) ORDER BY c.postedDate DESC',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    // Applications operations
    async createApplication(applicationData) {
        await this.initialize();
        const container = this.getContainer('applications');
        const id = `app_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...applicationData,
            _partitionKey: applicationData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getUserApplications(userId) {
        await this.initialize();
        const container = this.getContainer('applications');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId ORDER BY c.appliedAt DESC',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    // GDPR operations
    async createDataDeletionRequest(requestData) {
        await this.initialize();
        const container = this.getContainer('dataDeletionRequests');
        const id = `del_req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...requestData,
            _partitionKey: requestData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async deleteAllUserData(userId) {
        await this.initialize();
        const deletedCollections = [];
        const collections = [
            'users',
            'interviews',
            'feedback',
            'resumes',
            'usage',
            'applications',
            'autoApplySettings',
            'automationLogs',
            'dataDeletionRequests'
        ];
        for (const collectionName of collections){
            try {
                const container = this.getContainer(collectionName);
                if (collectionName === 'users' || collectionName === 'resumes' || collectionName === 'usage') {
                    // These use userId as document ID
                    try {
                        await container.item(userId, userId).delete();
                        deletedCollections.push(collectionName);
                    } catch (error) {
                        if (error.code !== 404) throw error;
                    }
                } else {
                    // Query and delete all documents for this user
                    const querySpec = {
                        query: 'SELECT c.id FROM c WHERE c.userId = @userId',
                        parameters: [
                            {
                                name: '@userId',
                                value: userId
                            }
                        ]
                    };
                    const { resources } = await container.items.query(querySpec).fetchAll();
                    if (resources.length > 0) {
                        for (const item of resources){
                            await container.item(item.id, userId).delete();
                        }
                        deletedCollections.push(collectionName);
                    }
                }
            } catch (error) {
                console.error(`Error deleting from ${collectionName}:`, error);
            }
        }
        return deletedCollections;
    }
    // Notification Events operations
    async createNotificationEvent(eventData) {
        await this.initialize();
        const container = this.getContainer('notificationEvents');
        const id = `notify_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...eventData,
            _partitionKey: eventData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async updateNotificationEvent(eventId, userId, updates) {
        await this.initialize();
        const container = this.getContainer('notificationEvents');
        const { resource: existing } = await container.item(eventId, userId).read();
        if (!existing) throw new Error('Notification event not found');
        const updated = {
            ...existing,
            ...updates,
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.item(eventId, userId).replace(updated);
    }
    async getUserNotificationEvents(userId, limit = 50) {
        await this.initialize();
        const container = this.getContainer('notificationEvents');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId ORDER BY c.createdAt DESC OFFSET 0 LIMIT @limit',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                },
                {
                    name: '@limit',
                    value: limit
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    // Error Events operations for monitoring
    async createErrorEvent(errorData) {
        await this.initialize();
        const container = this.getContainer('featureErrors');
        const id = `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...errorData,
            _partitionKey: errorData.featureName
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getErrorEvents(featureName, timeWindowMinutes, limit = 100) {
        await this.initialize();
        const container = this.getContainer('featureErrors');
        const cutoffTime = new Date(Date.now() - timeWindowMinutes * 60 * 1000);
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.featureName = @featureName AND c.timestamp >= @cutoffTime ORDER BY c.timestamp DESC OFFSET 0 LIMIT @limit',
            parameters: [
                {
                    name: '@featureName',
                    value: featureName
                },
                {
                    name: '@cutoffTime',
                    value: cutoffTime
                },
                {
                    name: '@limit',
                    value: limit
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    async getErrorEventCount(featureName, timeWindowMinutes) {
        await this.initialize();
        const container = this.getContainer('featureErrors');
        const cutoffTime = new Date(Date.now() - timeWindowMinutes * 60 * 1000);
        const querySpec = {
            query: 'SELECT VALUE COUNT(1) FROM c WHERE c.featureName = @featureName AND c.timestamp >= @cutoffTime',
            parameters: [
                {
                    name: '@featureName',
                    value: featureName
                },
                {
                    name: '@cutoffTime',
                    value: cutoffTime
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources[0] || 0;
    }
    // Error Budget operations
    async createErrorBudget(budgetData) {
        await this.initialize();
        const container = this.getContainer('errorBudgets');
        const id = `budget_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...budgetData,
            _partitionKey: budgetData.featureName
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    // Email Verification operations
    async createEmailVerification(verificationData) {
        await this.initialize();
        const container = this.getContainer('emailVerifications');
        const id = `verify_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...verificationData,
            _partitionKey: verificationData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getEmailVerification(userId, email, type) {
        await this.initialize();
        const container = this.getContainer('emailVerifications');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId AND c.email = @email AND c.type = @type AND c.verified = false ORDER BY c.createdAt DESC',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                },
                {
                    name: '@email',
                    value: email
                },
                {
                    name: '@type',
                    value: type
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources[0] || null;
    }
    async updateEmailVerification(verificationId, userId, updates) {
        await this.initialize();
        const container = this.getContainer('emailVerifications');
        const { resource: existing } = await container.item(verificationId, userId).read();
        if (!existing) throw new Error('Email verification not found');
        const updated = {
            ...existing,
            ...updates,
            _partitionKey: userId
        };
        await container.item(verificationId, userId).replace(updated);
    }
    // Profile operations (for Firestore profiles collection)
    async saveProfile(profileData) {
        await this.initialize();
        const container = this.getContainer('profiles');
        const document = {
            ...profileData,
            _partitionKey: profileData.userId
        };
        const { resource } = await container.items.upsert(document);
        return resource.id;
    }
    async getProfile(userId) {
        await this.initialize();
        const container = this.getContainer('profiles');
        try {
            const { resource } = await container.item(userId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async updateProfile(userId, updates) {
        await this.initialize();
        const container = this.getContainer('profiles');
        const { resource: existing } = await container.item(userId, userId).read();
        if (!existing) {
            // Create new profile if doesn't exist
            const newProfile = {
                id: userId,
                userId,
                ...updates,
                updatedAt: new Date(),
                _partitionKey: userId
            };
            await container.items.create(newProfile);
        } else {
            const updated = {
                ...existing,
                ...updates,
                updatedAt: new Date(),
                _partitionKey: userId
            };
            await container.item(userId, userId).replace(updated);
        }
    }
    // Generic query operations for complex Firestore-like queries
    async queryDocuments(containerName, query, parameters, partitionKey) {
        await this.initialize();
        const container = this.getContainer(containerName);
        const querySpec = {
            query,
            parameters
        };
        const queryOptions = partitionKey ? {
            partitionKey
        } : {};
        const { resources } = await container.items.query(querySpec, queryOptions).fetchAll();
        return resources;
    }
    // Generic document operations
    async createDocument(containerName, document) {
        await this.initialize();
        const container = this.getContainer(containerName);
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getDocument(containerName, documentId, partitionKey) {
        await this.initialize();
        const container = this.getContainer(containerName);
        try {
            const { resource } = await container.item(documentId, partitionKey).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async updateDocument(containerName, documentId, partitionKey, updates) {
        await this.initialize();
        const container = this.getContainer(containerName);
        const { resource: existing } = await container.item(documentId, partitionKey).read();
        if (!existing) throw new Error('Document not found');
        const updated = {
            ...existing,
            ...updates
        };
        await container.item(documentId, partitionKey).replace(updated);
    }
    async deleteDocument(containerName, documentId, partitionKey) {
        await this.initialize();
        const container = this.getContainer(containerName);
        try {
            await container.item(documentId, partitionKey).delete();
        } catch (error) {
            if (error.code !== 404) throw error;
        // Document already deleted, ignore 404
        }
    }
    // Batch operations for efficiency
    async batchCreate(containerName, documents) {
        await this.initialize();
        const container = this.getContainer(containerName);
        // Process in smaller batches to avoid limits
        const batchSize = 25;
        for(let i = 0; i < documents.length; i += batchSize){
            const batch = documents.slice(i, i + batchSize);
            await Promise.all(batch.map((doc)=>container.items.create(doc)));
        }
    }
    async batchDelete(containerName, documentIds) {
        await this.initialize();
        const container = this.getContainer(containerName);
        // Process in smaller batches
        const batchSize = 25;
        for(let i = 0; i < documentIds.length; i += batchSize){
            const batch = documentIds.slice(i, i + batchSize);
            await Promise.all(batch.map(({ id, partitionKey })=>container.item(id, partitionKey).delete().catch((err)=>{
                    if (err.code !== 404) throw err;
                // Ignore 404s for already deleted documents
                })));
        }
    }
    // Health check
    async healthCheck() {
        try {
            await this.initialize();
            const container = this.getContainer('users');
            // Simple read operation to test connectivity
            const querySpec = {
                query: 'SELECT VALUE COUNT(1) FROM c',
                parameters: []
            };
            await container.items.query(querySpec).fetchAll();
            return {
                status: 'healthy',
                timestamp: new Date()
            };
        } catch (error) {
            console.error('Azure Cosmos DB health check failed:', error);
            return {
                status: 'unhealthy',
                timestamp: new Date()
            };
        }
    }
}
// Export singleton instance
const azureCosmosService = new AzureCosmosService();
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (azureCosmosService)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 82802:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Um: () => (/* binding */ unifiedConfigService)
/* harmony export */ });
/* unused harmony exports CONFIG_SCHEMA, CONFIG_DEFAULTS, useUnifiedConfig */
/* harmony import */ var _azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16446);
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10756);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75931);
/* harmony import */ var _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(81599);
/* harmony import */ var _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89098);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__, _azure_identity__WEBPACK_IMPORTED_MODULE_1__, _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__, _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__]);
([_azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__, _azure_identity__WEBPACK_IMPORTED_MODULE_1__, _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__, _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Unified Configuration Service
 * 
 * Eliminates configuration drift by providing a single source of truth
 * with Azure App Configuration as primary and Firebase Remote Config
 * for client-side distribution.
 * 
 * Key features:
 * - Single API for all configuration needs
 * - Automatic Azure → Firebase synchronization
 * - Two-layer caching with drift detection
 * - Version control and rollback capabilities
 * - Edge-runtime compatible for Next.js middleware
 */ 




// ===== CONFIGURATION SCHEMA =====
const CONFIG_SCHEMA = {
    // Core application settings
    'core.app.environment': {
        required: true,
        type: 'string',
        enum: [
            'development',
            'staging',
            'production'
        ]
    },
    'core.app.version': {
        required: true,
        type: 'string'
    },
    'core.app.debug': {
        required: false,
        type: 'boolean'
    },
    'core.app.maintenanceMode': {
        required: false,
        type: 'boolean'
    },
    // Feature flags (synced to Firebase for client access)
    'features.autoApplyAzure': {
        required: false,
        type: 'boolean'
    },
    'features.portalIntegration': {
        required: false,
        type: 'boolean'
    },
    'features.voiceInterview': {
        required: false,
        type: 'boolean'
    },
    'features.voiceInterviewV2': {
        required: false,
        type: 'boolean'
    },
    'features.premiumFeatures': {
        required: false,
        type: 'boolean'
    },
    'features.newUI': {
        required: false,
        type: 'boolean'
    },
    // Cosmos DB configuration
    'data.cosmos.maxRUPerSecond': {
        required: false,
        type: 'number',
        min: 400,
        max: 100000
    },
    'data.cosmos.batchSize': {
        required: false,
        type: 'number',
        min: 10,
        max: 1000
    },
    'data.cosmos.connectionTimeout': {
        required: false,
        type: 'number',
        min: 1000,
        max: 30000
    },
    'data.cosmos.retryAttempts': {
        required: false,
        type: 'number',
        min: 1,
        max: 10
    },
    // Usage limits and quotas
    'quotas.freeInterviews': {
        required: false,
        type: 'number',
        min: 0,
        max: 100
    },
    'quotas.freeResumes': {
        required: false,
        type: 'number',
        min: 0,
        max: 50
    },
    'quotas.premiumInterviews': {
        required: false,
        type: 'number',
        min: 0,
        max: 10000
    },
    'quotas.premiumResumes': {
        required: false,
        type: 'number',
        min: 0,
        max: 1000
    },
    // Authentication settings (Firebase client-side)
    'auth.firebase.sessionTimeout': {
        required: false,
        type: 'number',
        min: 300,
        max: 86400
    },
    'auth.firebase.maxAttempts': {
        required: false,
        type: 'number',
        min: 3,
        max: 10
    },
    'auth.firebase.lockoutDuration': {
        required: false,
        type: 'number',
        min: 300,
        max: 3600
    },
    // Performance and monitoring
    'perf.cacheTimeout': {
        required: false,
        type: 'number',
        min: 30,
        max: 3600
    },
    'perf.maxCacheSize': {
        required: false,
        type: 'number',
        min: 100,
        max: 10000
    },
    'perf.enableMetrics': {
        required: false,
        type: 'boolean'
    }
};
// Default values with metadata
const CONFIG_DEFAULTS = {
    'core.app.environment': {
        value: 'development',
        type: 'string',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: ''
        }
    },
    'core.app.debug': {
        value: false,
        type: 'boolean',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: ''
        }
    },
    'features.autoApplyAzure': {
        value: false,
        type: 'boolean',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: '',
            syncToFirebase: true
        }
    },
    'features.voiceInterview': {
        value: true,
        type: 'boolean',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: '',
            syncToFirebase: true
        }
    },
    'features.voiceInterviewV2': {
        value: true,
        type: 'boolean',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: '',
            syncToFirebase: true
        }
    },
    'quotas.freeInterviews': {
        value: 3,
        type: 'number',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: ''
        }
    },
    'quotas.freeResumes': {
        value: 2,
        type: 'number',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: ''
        }
    }
};
// ===== UNIFIED CONFIGURATION SERVICE =====
class UnifiedConfigService {
    constructor(){
        this.azureClient = null;
        this.cache = new Map();
        this.initialized = false;
        this.driftCache = new Map();
        this.CACHE_TTL = 5 * 60 * 1000 // 5 minutes
        ;
        this.DRIFT_CHECK_INTERVAL = 10 * 60 * 1000 // 10 minutes
        ;
        this.setupDriftDetection();
    }
    // ===== INITIALIZATION =====
    async initialize() {
        if (this.initialized) return;
        try {
            const connectionString = process.env.AZURE_APP_CONFIG_CONNECTION_STRING;
            const endpoint = process.env.AZURE_APP_CONFIG_ENDPOINT;
            if (connectionString) {
                this.azureClient = new _azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__.AppConfigurationClient(connectionString);
            } else if (endpoint) {
                const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_1__.DefaultAzureCredential();
                this.azureClient = new _azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__.AppConfigurationClient(endpoint, credential);
            } else {
                console.warn('⚠️ Azure App Configuration not configured - using defaults only');
                this.initialized = true;
                return;
            }
            // Test connection
            const iterator = this.azureClient.listConfigurationSettings();
            await iterator.next(); // Just get the first result to test connection
            this.initialized = true;
            console.log('✅ Unified Configuration Service initialized');
        } catch (error) {
            console.error('❌ Failed to initialize Unified Config Service:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
                service: 'unified-config',
                action: 'initialize'
            });
            // Continue with defaults only
            this.initialized = true;
        }
    }
    // ===== CORE CONFIGURATION METHODS =====
    /**
   * Get configuration value with intelligent fallback
   */ async get(key, defaultValue) {
        const startTime = Date.now();
        let success = true;
        await this.initialize();
        try {
            // Check cache first
            const cached = this.getCachedValue(key);
            if (cached) {
                _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackCacheHit(true, key);
                const latency = Date.now() - startTime;
                _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, true);
                return cached.value;
            }
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackCacheHit(false, key);
            // Try Azure App Configuration first
            const azureValue = await this.getFromAzure(key);
            if (azureValue !== null) {
                const latency = Date.now() - startTime;
                _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, true);
                return azureValue;
            }
            // Check if it's a client-only config that should come from Firebase
            const schema = CONFIG_SCHEMA[key];
            const defaultConfig = CONFIG_DEFAULTS[key];
            if (defaultConfig?.metadata?.clientOnly) {
                const firebaseValue = await this.getFromFirebase(key);
                if (firebaseValue !== null) {
                    const latency = Date.now() - startTime;
                    _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, true);
                    return firebaseValue;
                }
            }
            // Return default value or schema default
            const result = defaultValue !== undefined ? defaultValue : defaultConfig ? defaultConfig.value : undefined;
            const latency = Date.now() - startTime;
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, true);
            return result;
        } catch (error) {
            success = false;
            console.error(`Error getting config ${key}:`, error);
            const latency = Date.now() - startTime;
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, false);
            return defaultValue;
        }
    }
    /**
   * Set configuration value with validation and audit
   */ async set(key, value, options) {
        const startTime = Date.now();
        let success = true;
        await this.initialize();
        const { environment = 'default', syncToFirebase = false, version = '1.0.0', changedBy = 'system' } = options || {};
        try {
            // Validate against schema
            this.validateConfigValue(key, value);
            // Get previous value for audit
            const previousValue = await this.get(key);
            // Create config value with metadata
            const configValue = {
                value,
                type: this.inferType(value),
                metadata: {
                    source: 'azure',
                    version,
                    lastModified: new Date(),
                    hash: this.calculateHash(value),
                    syncToFirebase
                }
            };
            // Store in Azure App Configuration
            if (this.azureClient) {
                await this.setInAzure(key, configValue, environment);
            }
            // Sync to Firebase if requested
            if (syncToFirebase) {
                await this.syncToFirebase(key, configValue);
            }
            // Clear cache
            this.cache.delete(key);
            // Record audit entry
            await this.recordAuditEntry({
                id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                key,
                oldValue: previousValue,
                newValue: value,
                version,
                source: 'unified',
                changedBy,
                timestamp: new Date(),
                rollbackable: true,
                metadata: {
                    environment,
                    syncToFirebase
                }
            });
            // Track configuration change
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigChange(key, previousValue, value, changedBy, environment);
            const latency = Date.now() - startTime;
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'set', latency, true);
            console.log(`✅ Config updated: ${key} = ${JSON.stringify(value)}`);
        } catch (error) {
            success = false;
            const latency = Date.now() - startTime;
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'set', latency, false);
            console.error(`❌ Failed to set config ${key}:`, error);
            throw error;
        }
    }
    /**
   * Get all configuration values with optional prefix filter
   */ async getAll(prefix) {
        await this.initialize();
        const result = {};
        try {
            // Get from Azure App Configuration
            if (this.azureClient) {
                const settings = this.azureClient.listConfigurationSettings({
                    keyFilter: prefix ? `${prefix}*` : undefined
                });
                for await (const setting of settings){
                    if (setting.key && setting.value !== undefined) {
                        const parsedValue = this.parseConfigurationSetting(setting);
                        result[setting.key] = parsedValue.value;
                        // Cache the value
                        this.setCachedValue(setting.key, parsedValue, setting.etag);
                    }
                }
            }
            // Add defaults for missing keys
            Object.entries(CONFIG_DEFAULTS).forEach(([key, defaultConfig])=>{
                if (!prefix || key.startsWith(prefix)) {
                    if (result[key] === undefined) {
                        result[key] = defaultConfig.value;
                    }
                }
            });
            return result;
        } catch (error) {
            console.error('Error getting all configs:', error);
            // Return defaults only on error
            const defaults = {};
            Object.entries(CONFIG_DEFAULTS).forEach(([key, defaultConfig])=>{
                if (!prefix || key.startsWith(prefix)) {
                    defaults[key] = defaultConfig.value;
                }
            });
            return defaults;
        }
    }
    /**
   * Refresh cache and check for drift
   */ async refresh() {
        this.cache.clear();
        this.driftCache.clear();
        await this.checkForDrift();
    }
    /**
   * Subscribe to configuration changes (polling-based)
   */ subscribe(key, callback) {
        let lastValue = undefined;
        let isActive = true;
        const poll = async ()=>{
            if (!isActive) return;
            try {
                const currentValue = await this.get(key);
                if (JSON.stringify(currentValue) !== JSON.stringify(lastValue)) {
                    lastValue = currentValue;
                    callback(currentValue);
                }
            } catch (error) {
                console.error(`Config subscription error for ${key}:`, error);
            }
        };
        // Poll every 30 seconds
        const interval = setInterval(poll, 30000);
        // Initial call
        poll();
        return ()=>{
            isActive = false;
            clearInterval(interval);
        };
    }
    // ===== DRIFT DETECTION =====
    async checkForDrift() {
        const driftResults = [];
        try {
            // Get all configs that should sync to Firebase
            const allConfigs = await this.getAll();
            const syncableKeys = Object.keys(allConfigs).filter((key)=>{
                const defaultConfig = CONFIG_DEFAULTS[key];
                return defaultConfig?.metadata?.syncToFirebase;
            });
            for (const key of syncableKeys){
                const drift = await this.checkKeyForDrift(key);
                if (drift) {
                    driftResults.push(drift);
                    this.driftCache.set(key, drift);
                }
            }
            // Track drift detection metrics
            const driftedKeys = driftResults.filter((d)=>d.drifted).map((d)=>d.key);
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackDriftDetection(driftedKeys, syncableKeys.length);
            if (driftResults.length > 0) {
                console.warn(`⚠️ Configuration drift detected in ${driftResults.length} keys`);
                // Record drift event for monitoring
                await this.recordDriftEvent(driftResults);
            }
            return driftResults;
        } catch (error) {
            console.error('Error checking for drift:', error);
            return [];
        }
    }
    async checkKeyForDrift(key) {
        try {
            const [azureValue, firebaseValue] = await Promise.all([
                this.getFromAzure(key),
                this.getFromFirebase(key)
            ]);
            if (azureValue === null && firebaseValue === null) {
                return null; // Both missing, no drift
            }
            const azureHash = this.calculateHash(azureValue);
            const firebaseHash = this.calculateHash(firebaseValue);
            const drifted = azureHash !== firebaseHash;
            return {
                key,
                azureValue,
                firebaseValue,
                azureHash,
                firebaseHash,
                drifted,
                lastChecked: new Date()
            };
        } catch (error) {
            console.error(`Error checking drift for ${key}:`, error);
            return null;
        }
    }
    // ===== ROLLBACK FUNCTIONALITY =====
    async revert(versionId) {
        try {
            // Get audit entry
            const auditEntry = await this.getAuditEntry(versionId);
            if (!auditEntry || !auditEntry.rollbackable) {
                throw new Error(`Version ${versionId} not found or not rollbackable`);
            }
            // Restore previous value
            await this.set(auditEntry.key, auditEntry.oldValue, {
                version: `rollback_${versionId}`,
                changedBy: 'rollback-system',
                syncToFirebase: auditEntry.metadata?.syncToFirebase
            });
            console.log(`✅ Successfully reverted ${auditEntry.key} to version ${versionId}`);
        } catch (error) {
            console.error(`❌ Failed to revert to version ${versionId}:`, error);
            throw error;
        }
    }
    // ===== PRIVATE HELPER METHODS =====
    async getFromAzure(key) {
        if (!this.azureClient) return null;
        try {
            const setting = await this.azureClient.getConfigurationSetting({
                key
            });
            if (!setting || setting.value === undefined) {
                return null;
            }
            const parsedValue = this.parseConfigurationSetting(setting);
            this.setCachedValue(key, parsedValue, setting.etag);
            return parsedValue.value;
        } catch (error) {
            if (error.statusCode === 404) {
                return null;
            }
            throw error;
        }
    }
    async getFromFirebase(key) {
        try {
            // Import Firebase Remote Config dynamically
            const { getRemoteConfig, getValue } = await Promise.all(/* import() */[__webpack_require__.e(1039), __webpack_require__.e(2308)]).then(__webpack_require__.bind(__webpack_require__, 99927));
            const { app } = await Promise.all(/* import() */[__webpack_require__.e(1039), __webpack_require__.e(8074)]).then(__webpack_require__.bind(__webpack_require__, 68074));
            if (!app) {
                console.warn('Firebase app not available');
                return null;
            }
            const remoteConfig = getRemoteConfig(app);
            const value = getValue(remoteConfig, key);
            return value.asString();
        } catch (error) {
            console.warn(`Failed to get Firebase Remote Config for ${key}:`, error);
            return null;
        }
    }
    async setInAzure(key, configValue, environment) {
        if (!this.azureClient) return;
        const setting = {
            key: environment === 'default' ? key : `${key}__${environment}`,
            value: this.serializeValue(configValue.value),
            contentType: this.getContentType(configValue.value),
            isReadOnly: false,
            tags: {
                environment,
                version: configValue.metadata?.version || '1.0.0',
                source: 'unified-service',
                lastModified: new Date().toISOString(),
                hash: configValue.metadata?.hash || '',
                syncToFirebase: configValue.metadata?.syncToFirebase ? 'true' : 'false'
            }
        };
        await this.azureClient.setConfigurationSetting(setting);
    }
    async syncToFirebase(key, configValue) {
        // This will be implemented by the config-sync Azure Function
        // For now, we'll queue the sync request
        console.log(`🔄 Queuing Firebase sync for ${key}`);
    // Could implement immediate sync here if needed
    // For production, better to use the dedicated sync function
    }
    parseConfigurationSetting(setting) {
        const value = this.parseValue(setting.value || '', setting.contentType);
        return {
            value,
            type: this.inferType(value),
            metadata: {
                source: 'azure',
                version: setting.tags?.version || '1.0.0',
                lastModified: new Date(setting.tags?.lastModified || new Date()),
                hash: setting.tags?.hash || this.calculateHash(value),
                syncToFirebase: setting.tags?.syncToFirebase === 'true'
            }
        };
    }
    parseValue(value, contentType) {
        if (!contentType) {
            // Try to infer type
            if (value === 'true' || value === 'false') {
                return value === 'true';
            }
            const numberValue = Number(value);
            if (!isNaN(numberValue)) {
                return numberValue;
            }
            try {
                return JSON.parse(value);
            } catch  {
                return value;
            }
        }
        switch(contentType){
            case 'application/json':
                return JSON.parse(value);
            case 'text/plain':
            default:
                return value;
        }
    }
    serializeValue(value) {
        if (typeof value === 'string') {
            return value;
        }
        if (typeof value === 'number' || typeof value === 'boolean') {
            return value.toString();
        }
        return JSON.stringify(value);
    }
    getContentType(value) {
        if (typeof value === 'object') {
            return 'application/json';
        }
        return 'text/plain';
    }
    inferType(value) {
        if (Array.isArray(value)) return 'array';
        if (typeof value === 'object') return 'object';
        if (typeof value === 'boolean') return 'boolean';
        if (typeof value === 'number') return 'number';
        return 'string';
    }
    validateConfigValue(key, value) {
        const rule = CONFIG_SCHEMA[key];
        if (!rule) return; // No validation rule, allow any value
        // Type validation
        const actualType = this.inferType(value);
        if (rule.type !== actualType) {
            throw new Error(`Config ${key}: expected type ${rule.type}, got ${actualType}`);
        }
        // Enum validation
        if (rule.enum && !rule.enum.includes(value)) {
            throw new Error(`Config ${key}: value must be one of ${rule.enum.join(', ')}`);
        }
        // Range validation for numbers
        if (rule.type === 'number') {
            if (rule.min !== undefined && value < rule.min) {
                throw new Error(`Config ${key}: value ${value} is below minimum ${rule.min}`);
            }
            if (rule.max !== undefined && value > rule.max) {
                throw new Error(`Config ${key}: value ${value} is above maximum ${rule.max}`);
            }
        }
        // Pattern validation for strings
        if (rule.type === 'string' && rule.pattern && !rule.pattern.test(value)) {
            throw new Error(`Config ${key}: value does not match required pattern`);
        }
    }
    calculateHash(value) {
        const crypto = __webpack_require__(55511);
        const normalized = JSON.stringify(value, Object.keys(value || {}).sort());
        return crypto.createHash('sha256').update(normalized).digest('hex').substring(0, 16);
    }
    getCachedValue(key) {
        const cached = this.cache.get(key);
        if (!cached) return null;
        const isExpired = Date.now() - cached.timestamp > this.CACHE_TTL;
        if (isExpired) {
            this.cache.delete(key);
            return null;
        }
        return cached.value;
    }
    setCachedValue(key, value, etag) {
        this.cache.set(key, {
            value,
            timestamp: Date.now(),
            etag
        });
    }
    setupDriftDetection() {
        // Check for drift every 10 minutes
        setInterval(async ()=>{
            await this.checkForDrift();
        }, this.DRIFT_CHECK_INTERVAL);
    }
    async recordAuditEntry(entry) {
        try {
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.initialize();
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.createDocument('configAudit', {
                ...entry,
                _partitionKey: entry.key
            });
        } catch (error) {
            console.error('Failed to record config audit entry:', error);
        }
    }
    async getAuditEntry(versionId) {
        try {
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.initialize();
            const result = await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.queryDocuments('configAudit', 'SELECT * FROM c WHERE c.version = @versionId', [
                {
                    name: '@versionId',
                    value: versionId
                }
            ]);
            return result[0] || null;
        } catch (error) {
            console.error('Failed to get audit entry:', error);
            return null;
        }
    }
    async recordDriftEvent(driftResults) {
        try {
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.initialize();
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.createDocument('configDrift', {
                id: `drift_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                timestamp: new Date(),
                driftCount: driftResults.length,
                keys: driftResults.map((d)=>d.key),
                details: driftResults,
                _partitionKey: 'drift-detection'
            });
        } catch (error) {
            console.error('Failed to record drift event:', error);
        }
    }
    // ===== HEALTH CHECK =====
    async healthCheck() {
        try {
            await this.initialize();
            if (!this.azureClient) {
                return {
                    healthy: false,
                    message: 'Azure App Configuration not available - using defaults only'
                };
            }
            // Test connectivity
            const testIterator = this.azureClient.listConfigurationSettings();
            await testIterator.next(); // Just test the connection
            const driftCount = Array.from(this.driftCache.values()).filter((d)=>d.drifted).length;
            // Get comprehensive health check from monitoring service
            const monitoringHealth = await _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.healthCheck();
            return {
                healthy: monitoringHealth.status === 'healthy',
                message: monitoringHealth.status !== 'healthy' ? `Service status: ${monitoringHealth.status}` : undefined,
                details: {
                    cacheSize: this.cache.size,
                    driftDetected: driftCount,
                    lastRefresh: new Date(),
                    monitoring: monitoringHealth
                }
            };
        } catch (error) {
            return {
                healthy: false,
                message: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
}
// ===== SINGLETON INSTANCE =====
const unifiedConfigService = new UnifiedConfigService();
// ===== REACT HOOK =====
// Note: This hook should be used in client-side components only
// The actual implementation will be moved to a separate file to avoid
// bundling React in server-side code
function useUnifiedConfig(key, defaultValue) {
    // This is a placeholder implementation that will be overridden
    // in client-side usage. See /lib/hooks/useUnifiedConfig.ts
    console.warn('useUnifiedConfig called from server context. Use the client-side hook instead.');
    return {
        value: defaultValue,
        loading: false,
        error: null
    };
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (unifiedConfigService)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 89098:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G: () => (/* binding */ configMonitoringService)
/* harmony export */ });
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75931);
/* harmony import */ var _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(81599);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__]);
_azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Configuration Monitoring Service
 * 
 * Provides comprehensive monitoring, metrics, and alerting for the
 * unified configuration system with Application Insights integration.
 */ 

// ===== MONITORING SERVICE =====
class ConfigMonitoringService {
    constructor(){
        this.telemetryClient = null;
        this.metrics = {
            requestCount: 0,
            cacheHits: 0,
            cacheMisses: 0,
            avgLatency: 0,
            errorCount: 0,
            driftDetected: 0,
            syncFailures: 0
        };
        this.latencyBuffer = [];
        this.LATENCY_BUFFER_SIZE = 100;
        this.ALERT_THRESHOLDS = {
            HIGH_LATENCY_MS: 1000,
            ERROR_RATE_THRESHOLD: 0.05,
            CACHE_HIT_RATIO_MIN: 0.8,
            MAX_DRIFT_COUNT: 5
        };
        this.initializeTelemetry();
    }
    // ===== INITIALIZATION =====
    initializeTelemetry() {
        try {
            const appInsightsKey = process.env.APPLICATIONINSIGHTS_CONNECTION_STRING;
            if (appInsightsKey) {
                // Application Insights is typically initialized globally
                // This service uses the global instance if available
                const appInsights = __webpack_require__(26231);
                if (appInsights.defaultClient) {
                    this.telemetryClient = appInsights.defaultClient;
                    console.log('✅ Config monitoring connected to Application Insights');
                } else {
                    appInsights.setup(appInsightsKey).setAutoCollectRequests(true).setAutoCollectPerformance(true).setAutoCollectExceptions(true).setAutoCollectDependencies(true).setAutoCollectConsole(true, true).setUseDiskRetryCaching(true).start();
                    this.telemetryClient = appInsights.defaultClient;
                    console.log('✅ Config monitoring initialized Application Insights');
                }
            } else {
                console.warn('⚠️ Application Insights connection string not found - monitoring disabled');
            }
        } catch (error) {
            console.error('❌ Failed to initialize Application Insights:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_0__/* .logServerError */ .wh)(error, {
                service: 'config-monitoring',
                action: 'initialize'
            });
        }
    }
    // ===== METRICS TRACKING =====
    /**
   * Track configuration request with timing
   */ trackConfigRequest(key, operation, latency, success) {
        this.metrics.requestCount++;
        // Update latency metrics
        this.latencyBuffer.push(latency);
        if (this.latencyBuffer.length > this.LATENCY_BUFFER_SIZE) {
            this.latencyBuffer.shift();
        }
        this.metrics.avgLatency = this.latencyBuffer.reduce((a, b)=>a + b, 0) / this.latencyBuffer.length;
        // Track errors
        if (!success) {
            this.metrics.errorCount++;
        }
        // Send to Application Insights
        if (this.telemetryClient) {
            this.telemetryClient.trackRequest({
                name: `Config-${operation}`,
                url: `config://${key}`,
                duration: latency,
                resultCode: success ? '200' : '500',
                success,
                properties: {
                    configKey: key,
                    operation,
                    service: 'unified-config'
                },
                measurements: {
                    latency,
                    cacheHitRatio: this.getCacheHitRatio(),
                    requestCount: this.metrics.requestCount
                }
            });
            // Track custom metric
            this.telemetryClient.trackMetric({
                name: 'Config.Request.Latency',
                value: latency,
                properties: {
                    operation,
                    key: key.split('.')[0] // Track by namespace
                }
            });
        }
        // Check for alerts
        this.checkLatencyAlert(latency);
        this.checkErrorRateAlert();
    }
    /**
   * Track cache hit/miss
   */ trackCacheHit(hit, key) {
        if (hit) {
            this.metrics.cacheHits++;
        } else {
            this.metrics.cacheMisses++;
        }
        if (this.telemetryClient) {
            this.telemetryClient.trackEvent({
                name: 'Config.Cache.Access',
                properties: {
                    hit: hit.toString(),
                    key: key.split('.')[0],
                    service: 'unified-config'
                },
                measurements: {
                    hitRatio: this.getCacheHitRatio(),
                    totalCacheAccess: this.metrics.cacheHits + this.metrics.cacheMisses
                }
            });
        }
        // Check cache performance alert
        this.checkCachePerformanceAlert();
    }
    /**
   * Track configuration drift detection
   */ trackDriftDetection(driftedKeys, totalChecked) {
        this.metrics.driftDetected = driftedKeys.length;
        if (this.telemetryClient) {
            this.telemetryClient.trackEvent({
                name: 'Config.Drift.Detection',
                properties: {
                    driftedKeys: driftedKeys.join(','),
                    service: 'unified-config'
                },
                measurements: {
                    driftCount: driftedKeys.length,
                    totalChecked,
                    driftRatio: driftedKeys.length / totalChecked
                }
            });
        }
        // Alert if drift detected
        if (driftedKeys.length > 0) {
            this.createAlert('drift', 'high', `Configuration drift detected in ${driftedKeys.length} keys: ${driftedKeys.join(', ')}`, {
                driftedKeys,
                totalChecked
            });
        }
    }
    /**
   * Track Firebase sync operations
   */ trackSyncOperation(success, keysSync, duration, error) {
        if (!success) {
            this.metrics.syncFailures++;
        }
        if (this.telemetryClient) {
            this.telemetryClient.trackDependency({
                dependencyTypeName: 'Firebase',
                name: 'Config.Sync',
                data: `Sync ${keysSync} keys`,
                duration,
                success,
                properties: {
                    keysSync: keysSync.toString(),
                    service: 'config-sync',
                    error: error || ''
                }
            });
            this.telemetryClient.trackMetric({
                name: 'Config.Sync.KeyCount',
                value: keysSync,
                properties: {
                    success: success.toString()
                }
            });
        }
        // Alert on sync failures
        if (!success) {
            this.createAlert('sync_failure', 'medium', `Firebase sync failed: ${error || 'Unknown error'}`, {
                keysSync,
                duration,
                error
            });
        }
    }
    /**
   * Track configuration changes
   */ trackConfigChange(key, oldValue, newValue, changedBy, environment) {
        if (this.telemetryClient) {
            this.telemetryClient.trackEvent({
                name: 'Config.Change',
                properties: {
                    key,
                    changedBy,
                    environment,
                    service: 'unified-config',
                    hasOldValue: (oldValue !== null && oldValue !== undefined).toString(),
                    valueType: typeof newValue
                },
                measurements: {
                    changeTimestamp: Date.now()
                }
            });
        }
    }
    // ===== ALERTING =====
    /**
   * Create and process alerts
   */ async createAlert(type, severity, message, metadata) {
        const alert = {
            id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            type,
            severity,
            message,
            metadata,
            timestamp: new Date(),
            resolved: false,
            environment: "production" || 0
        };
        // Store alert in Cosmos DB
        try {
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__/* .azureCosmosService */ .h.createDocument('configAlerts', {
                ...alert,
                _partitionKey: alert.type
            });
        } catch (error) {
            console.error('Failed to store alert:', error);
        }
        // Send to Application Insights as exception for high/critical severity
        if (this.telemetryClient && (severity === 'high' || severity === 'critical')) {
            this.telemetryClient.trackException({
                exception: new Error(`Config Alert [${severity.toUpperCase()}]: ${message}`),
                properties: {
                    alertId: alert.id,
                    alertType: type,
                    severity,
                    environment: alert.environment,
                    service: 'unified-config'
                },
                measurements: metadata
            });
        }
        // Send to notification channels
        await this.sendAlertNotification(alert);
        console.warn(`🚨 Config Alert [${severity.toUpperCase()}]: ${message}`);
    }
    /**
   * Check for latency alerts
   */ checkLatencyAlert(latency) {
        if (latency > this.ALERT_THRESHOLDS.HIGH_LATENCY_MS) {
            this.createAlert('high_latency', 'medium', `High configuration latency detected: ${latency}ms`, {
                latency,
                threshold: this.ALERT_THRESHOLDS.HIGH_LATENCY_MS
            });
        }
    }
    /**
   * Check for error rate alerts
   */ checkErrorRateAlert() {
        const errorRate = this.metrics.requestCount > 0 ? this.metrics.errorCount / this.metrics.requestCount : 0;
        if (errorRate > this.ALERT_THRESHOLDS.ERROR_RATE_THRESHOLD && this.metrics.requestCount > 10) {
            this.createAlert('error_rate', 'high', `High configuration error rate: ${(errorRate * 100).toFixed(2)}%`, {
                errorRate,
                errorCount: this.metrics.errorCount,
                requestCount: this.metrics.requestCount
            });
        }
    }
    /**
   * Check for cache performance alerts
   */ checkCachePerformanceAlert() {
        const hitRatio = this.getCacheHitRatio();
        const totalRequests = this.metrics.cacheHits + this.metrics.cacheMisses;
        if (hitRatio < this.ALERT_THRESHOLDS.CACHE_HIT_RATIO_MIN && totalRequests > 50) {
            this.createAlert('cache_performance', 'medium', `Low cache hit ratio: ${(hitRatio * 100).toFixed(2)}%`, {
                hitRatio,
                cacheHits: this.metrics.cacheHits,
                cacheMisses: this.metrics.cacheMisses
            });
        }
    }
    // ===== NOTIFICATIONS =====
    /**
   * Send alert notifications to configured channels
   */ async sendAlertNotification(alert) {
        try {
            // Slack webhook notification
            const slackWebhook = process.env.SLACK_WEBHOOK_URL;
            if (slackWebhook && (alert.severity === 'high' || alert.severity === 'critical')) {
                await this.sendSlackNotification(alert, slackWebhook);
            }
        // Email notification (could be implemented)
        // await this.sendEmailNotification(alert);
        // Microsoft Teams notification (could be implemented)
        // await this.sendTeamsNotification(alert);
        } catch (error) {
            console.error('Failed to send alert notification:', error);
        }
    }
    /**
   * Send Slack notification
   */ async sendSlackNotification(alert, webhookUrl) {
        const payload = {
            text: `🚨 Configuration Alert: ${alert.message}`,
            attachments: [
                {
                    color: this.getAlertColor(alert.severity),
                    fields: [
                        {
                            title: 'Alert Type',
                            value: alert.type,
                            short: true
                        },
                        {
                            title: 'Severity',
                            value: alert.severity.toUpperCase(),
                            short: true
                        },
                        {
                            title: 'Environment',
                            value: alert.environment,
                            short: true
                        },
                        {
                            title: 'Timestamp',
                            value: alert.timestamp.toISOString(),
                            short: true
                        }
                    ],
                    footer: 'PrepBettr Config Monitoring'
                }
            ]
        };
        const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });
        if (!response.ok) {
            throw new Error(`Slack notification failed: ${response.statusText}`);
        }
    }
    /**
   * Get alert color for Slack
   */ getAlertColor(severity) {
        switch(severity){
            case 'critical':
                return 'danger';
            case 'high':
                return 'warning';
            case 'medium':
                return 'warning';
            case 'low':
                return 'good';
            default:
                return 'good';
        }
    }
    // ===== HEALTH CHECK =====
    /**
   * Perform comprehensive health check
   */ async healthCheck() {
        const alerts = await this.getActiveAlerts();
        const status = this.calculateHealthStatus(alerts);
        return {
            service: 'unified-config',
            status,
            timestamp: new Date(),
            metrics: {
                ...this.metrics
            },
            alerts,
            details: {
                cacheHitRatio: this.getCacheHitRatio(),
                avgLatency: this.metrics.avgLatency,
                errorRate: this.metrics.requestCount > 0 ? this.metrics.errorCount / this.metrics.requestCount : 0,
                uptime: process.uptime()
            }
        };
    }
    /**
   * Get active alerts
   */ async getActiveAlerts() {
        try {
            const alerts = await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__/* .azureCosmosService */ .h.queryDocuments('configAlerts', 'SELECT * FROM c WHERE c.resolved = false AND c.timestamp >= @cutoff ORDER BY c.timestamp DESC', [
                {
                    name: '@cutoff',
                    value: new Date(Date.now() - 24 * 60 * 60 * 1000)
                }
            ] // Last 24 hours
            );
            return alerts.slice(0, 10); // Limit to 10 most recent
        } catch (error) {
            console.error('Failed to get active alerts:', error);
            return [];
        }
    }
    /**
   * Calculate overall health status
   */ calculateHealthStatus(alerts) {
        const criticalAlerts = alerts.filter((a)=>a.severity === 'critical');
        const highAlerts = alerts.filter((a)=>a.severity === 'high');
        if (criticalAlerts.length > 0) return 'unhealthy';
        if (highAlerts.length > 2) return 'unhealthy';
        if (alerts.length > 5) return 'degraded';
        // Check metrics
        const errorRate = this.metrics.requestCount > 0 ? this.metrics.errorCount / this.metrics.requestCount : 0;
        const cacheHitRatio = this.getCacheHitRatio();
        if (errorRate > 0.1 || cacheHitRatio < 0.5 || this.metrics.avgLatency > 2000) {
            return 'degraded';
        }
        return 'healthy';
    }
    // ===== UTILITY METHODS =====
    /**
   * Get current cache hit ratio
   */ getCacheHitRatio() {
        const total = this.metrics.cacheHits + this.metrics.cacheMisses;
        return total > 0 ? this.metrics.cacheHits / total : 0;
    }
    /**
   * Get current metrics
   */ getMetrics() {
        return {
            ...this.metrics
        };
    }
    /**
   * Reset metrics (for testing or periodic reset)
   */ resetMetrics() {
        this.metrics = {
            requestCount: 0,
            cacheHits: 0,
            cacheMisses: 0,
            avgLatency: 0,
            errorCount: 0,
            driftDetected: 0,
            syncFailures: 0
        };
        this.latencyBuffer = [];
    }
    /**
   * Flush telemetry data
   */ flush() {
        return new Promise((resolve)=>{
            if (this.telemetryClient) {
                this.telemetryClient.flush();
                // Flush is synchronous, so we can resolve immediately
                resolve();
            } else {
                resolve();
            }
        });
    }
}
// ===== SINGLETON INSTANCE =====
const configMonitoringService = new ConfigMonitoringService();
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (configMonitoringService)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;