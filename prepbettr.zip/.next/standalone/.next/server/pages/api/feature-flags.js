"use strict";
(() => {
var exports = {};
exports.id = 1505;
exports.ids = [1505,5060];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 7028:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ featureFlagsService)
/* harmony export */ });
/* harmony import */ var _unified_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(67327);
/* harmony import */ var _user_targeting__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13179);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_unified_config_service__WEBPACK_IMPORTED_MODULE_0__, _user_targeting__WEBPACK_IMPORTED_MODULE_1__]);
([_unified_config_service__WEBPACK_IMPORTED_MODULE_0__, _user_targeting__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


class FeatureFlagsService {
    static getInstance() {
        if (!FeatureFlagsService.instance) {
            FeatureFlagsService.instance = new FeatureFlagsService();
        }
        return FeatureFlagsService.instance;
    }
    /**
   * Get feature flag value considering both remote config and user targeting
   */ async getFeatureFlag(flagName) {
        try {
            // Get feature flag from unified config service
            const configKey = `features.${flagName}`;
            const globalValue = await _unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.get(configKey, false);
            if (!globalValue) {
                // If disabled globally, return false
                return false;
            }
            // If enabled globally, check if user is in the rollout
            const rolloutConfig = _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .UserTargetingService */ .o.ROLLOUT_CONFIGS[flagName];
            if (!rolloutConfig) {
                // If no rollout config, default to global setting
                return globalValue;
            }
            return _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .userTargetingService */ .A.isCurrentUserInRollout(rolloutConfig);
        } catch (error) {
            console.error(`Error getting feature flag ${flagName}:`, error);
            return false; // Default to disabled on error
        }
    }
    /**
   * Get all feature flags with rollout status
   */ async getAllFeatureFlags() {
        try {
            // Get all feature flags from unified config service
            const allConfigs = await _unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.getAll('features.');
            // Extract flags from config keys
            const globalFlags = {
                autoApplyAzure: allConfigs['features.autoApplyAzure'] || false,
                portalIntegration: allConfigs['features.portalIntegration'] || false,
                voiceInterview: allConfigs['features.voiceInterview'] || false,
                voiceInterviewV2: allConfigs['features.voiceInterviewV2'] || false,
                premiumFeatures: allConfigs['features.premiumFeatures'] || false,
                newUI: allConfigs['features.newUI'] || false
            };
            // Get rollout status for current user
            const rolloutStatus = _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .userTargetingService */ .A.getCurrentUserRolloutStatus();
            // Combine both: feature must be enabled globally AND user must be in rollout
            const enhancedFlags = {
                autoApplyAzure: globalFlags.autoApplyAzure && rolloutStatus.autoApplyAzure,
                portalIntegration: globalFlags.portalIntegration && rolloutStatus.portalIntegration,
                voiceInterview: globalFlags.voiceInterview && rolloutStatus.voiceInterview,
                voiceInterviewV2: globalFlags.voiceInterviewV2 && rolloutStatus.voiceInterviewV2,
                premiumFeatures: globalFlags.premiumFeatures && rolloutStatus.premiumFeatures,
                newUI: globalFlags.newUI && rolloutStatus.newUI,
                rolloutStatus: {
                    autoApplyAzure: rolloutStatus.autoApplyAzure || false,
                    portalIntegration: rolloutStatus.portalIntegration || false,
                    voiceInterview: rolloutStatus.voiceInterview || false,
                    voiceInterviewV2: rolloutStatus.voiceInterviewV2 || false,
                    premiumFeatures: rolloutStatus.premiumFeatures || false,
                    newUI: rolloutStatus.newUI || false
                }
            };
            return enhancedFlags;
        } catch (error) {
            console.error('Error getting all feature flags:', error);
            return {
                autoApplyAzure: false,
                portalIntegration: false,
                voiceInterview: false,
                voiceInterviewV2: false,
                premiumFeatures: false,
                newUI: false,
                rolloutStatus: {
                    autoApplyAzure: false,
                    portalIntegration: false,
                    voiceInterview: false,
                    voiceInterviewV2: false,
                    premiumFeatures: false,
                    newUI: false
                }
            };
        }
    }
    /**
   * Check if a specific feature is enabled for the current user
   */ async isFeatureEnabled(featureName) {
        return this.getFeatureFlag(featureName);
    }
    /**
   * Convenience methods for specific features
   */ async isAutoApplyAzureEnabled() {
        return this.getFeatureFlag('autoApplyAzure');
    }
    async isPortalIntegrationEnabled() {
        return this.getFeatureFlag('portalIntegration');
    }
    /**
   * Get debug information about feature flags
   */ async getDebugInfo() {
        const unifiedConfig = await _unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.getAll('features.');
        const rolloutStatus = _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .userTargetingService */ .A.getCurrentUserRolloutStatus();
        const finalFlags = await this.getAllFeatureFlags();
        const userId = _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .userTargetingService */ .A.getCurrentUserId();
        return {
            unifiedConfig,
            rolloutStatus,
            finalFlags: {
                autoApplyAzure: finalFlags.autoApplyAzure,
                portalIntegration: finalFlags.portalIntegration,
                voiceInterview: finalFlags.voiceInterview,
                voiceInterviewV2: finalFlags.voiceInterviewV2,
                premiumFeatures: finalFlags.premiumFeatures,
                newUI: finalFlags.newUI
            },
            userId,
            rolloutConfigs: _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .UserTargetingService */ .o.ROLLOUT_CONFIGS
        };
    }
    /**
   * Force refresh all feature flags
   */ async refreshFeatureFlags() {
        await _unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.refresh();
        return this.getAllFeatureFlags();
    }
}
// Export singleton instance
const featureFlagsService = FeatureFlagsService.getInstance();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 10756:
/***/ ((module) => {

module.exports = import("@azure/identity");;

/***/ }),

/***/ 13179:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ userTargetingService),
/* harmony export */   o: () => (/* binding */ UserTargetingService)
/* harmony export */ });
/* harmony import */ var _firebase_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65060);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_firebase_client__WEBPACK_IMPORTED_MODULE_0__]);
_firebase_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

class UserTargetingService {
    static getInstance() {
        if (!UserTargetingService.instance) {
            UserTargetingService.instance = new UserTargetingService();
        }
        return UserTargetingService.instance;
    }
    /**
   * Simple hash function to create a consistent hash from user ID
   */ hashUserId(userId) {
        let hash = 0;
        for(let i = 0; i < userId.length; i++){
            const char = userId.charCodeAt(i);
            hash = (hash << 5) - hash + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return Math.abs(hash);
    }
    /**
   * Determines if a user should be included in a feature rollout
   * Uses consistent hashing to ensure the same user always gets the same result
   */ isUserInRollout(userId, rolloutConfig) {
        if (rolloutConfig.percentage <= 0) return false;
        if (rolloutConfig.percentage >= 100) return true;
        // Create a feature-specific hash by combining userId and feature name
        const combinedString = `${userId}-${rolloutConfig.featureName}`;
        const hash = this.hashUserId(combinedString);
        // Use modulo to get a consistent percentage (0-99)
        const userBucket = hash % 100;
        return userBucket < rolloutConfig.percentage;
    }
    /**
   * Get the current user's ID
   */ getCurrentUserId() {
        return _firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2?.currentUser?.uid || null;
    }
    /**
   * Check if current user is in a specific feature rollout
   */ isCurrentUserInRollout(rolloutConfig) {
        const userId = this.getCurrentUserId();
        if (!userId) {
            // For anonymous users, use a fallback (could be device ID, session ID, etc.)
            const fallbackId = this.getAnonymousUserFallback();
            return this.isUserInRollout(fallbackId, rolloutConfig);
        }
        return this.isUserInRollout(userId, rolloutConfig);
    }
    /**
   * Generate a fallback ID for anonymous users
   * This could be based on device fingerprinting, localStorage, etc.
   */ getAnonymousUserFallback() {
        // Try to get or create a persistent anonymous ID
        let anonymousId = localStorage.getItem('prep_anonymous_id');
        if (!anonymousId) {
            // Generate a new anonymous ID
            anonymousId = `anon_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            localStorage.setItem('prep_anonymous_id', anonymousId);
        }
        return anonymousId;
    }
    static{
        /**
   * Predefined rollout configurations
   */ this.ROLLOUT_CONFIGS = {
            autoApplyAzure: {
                percentage: 5,
                featureName: 'autoApplyAzure'
            },
            portalIntegration: {
                percentage: 5,
                featureName: 'portalIntegration'
            },
            voiceInterview: {
                percentage: 10,
                featureName: 'voiceInterview'
            },
            voiceInterviewV2: {
                percentage: 100,
                featureName: 'voiceInterviewV2'
            },
            premiumFeatures: {
                percentage: 15,
                featureName: 'premiumFeatures'
            },
            newUI: {
                percentage: 20,
                featureName: 'newUI'
            }
        };
    }
    /**
   * Get all rollout statuses for the current user
   */ getCurrentUserRolloutStatus() {
        return {
            autoApplyAzure: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.autoApplyAzure),
            portalIntegration: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.portalIntegration),
            voiceInterview: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.voiceInterview),
            voiceInterviewV2: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.voiceInterviewV2),
            premiumFeatures: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.premiumFeatures),
            newUI: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.newUI)
        };
    }
    /**
   * Update rollout percentage for a feature (for admin/testing purposes)
   */ static updateRolloutPercentage(featureName, percentage) {
        if (percentage < 0 || percentage > 100) {
            throw new Error('Rollout percentage must be between 0 and 100');
        }
        UserTargetingService.ROLLOUT_CONFIGS[featureName].percentage = percentage;
        console.log(`Updated ${featureName} rollout to ${percentage}%`);
    }
}
// Export singleton instance
const userTargetingService = UserTargetingService.getInstance();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 16446:
/***/ ((module) => {

module.exports = import("@azure/app-configuration");;

/***/ }),

/***/ 26231:
/***/ ((module) => {

module.exports = require("applicationinsights");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 34000:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routeModule: () => (/* binding */ routeModule)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(33480);
/* harmony import */ var next_dist_server_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8667);
/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(86435);
/* harmony import */ var private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(81031);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__]);
private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// Import the userland code.

// Re-export the handler (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .M)(private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__, 'default'));
// Re-export config.
const config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .M)(private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__, 'config');
// Create and export the route module that will be consumed.
const routeModule = new next_dist_server_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .A.PAGES_API,
        page: "/api/feature-flags",
        pathname: "/api/feature-flags",
        // The following aren't used in production.
        bundlePath: '',
        filename: ''
    },
    userland: private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__
});

//# sourceMappingURL=pages-api.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 44337:
/***/ ((module) => {

module.exports = import("firebase/firestore");;

/***/ }),

/***/ 46602:
/***/ ((module) => {

module.exports = import("@azure/cosmos");;

/***/ }),

/***/ 55511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 65044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   wh: () => (/* binding */ logServerError)
/* harmony export */ });
/* unused harmony exports createErrorResponse, createApiErrorResponse, isRetryableError, mapErrorToResponse, NETWORK_FAILURE_MESSAGE, getUserFriendlyErrorMessage */
// lib/errors.ts
/**
 * Creates a standardized error response
 */ function createErrorResponse(error, status) {
    return {
        error,
        status
    };
}
/**
 * Creates a NextResponse error for API routes
 */ function createApiErrorResponse(error, status) {
    // Import NextResponse dynamically to avoid module issues
    const { NextResponse } = __webpack_require__(80645);
    return NextResponse.json({
        error
    }, {
        status
    });
}
/**
 * Logs server errors with context but never exposes sensitive information
 */ function logServerError(error, context, additionalContext) {
    const errorMessage = error instanceof Error ? error.message : error;
    const errorStack = error instanceof Error ? error.stack : undefined;
    // Create safe logging context (no sensitive data)
    const safeContext = {
        timestamp: context.timestamp || new Date().toISOString(),
        url: context.url,
        method: context.method,
        userId: context.userId ? `user_${context.userId.slice(-8)}` : 'anonymous',
        userAgent: context.userAgent ? context.userAgent.slice(0, 100) : undefined,
        ip: context.ip ? context.ip.replace(/\d+$/, 'xxx') : undefined,
        ...additionalContext
    };
    console.error('Server Error:', {
        message: errorMessage,
        context: safeContext,
        stack: errorStack
    });
    // In production, you might want to send this to a logging service
    // like DataDog, Sentry, etc.
    if (true) {
    // Example: Send to external logging service
    // logger.error(errorMessage, safeContext);
    }
}
/**
 * Determines if an error should be retried
 */ function isRetryableError(status) {
    // Retry for 5xx errors and specific 4xx errors
    return status >= 500 || status === 408 || status === 429;
}
/**
 * Maps common error types to standard error responses
 */ function mapErrorToResponse(error) {
    // Network/Connection errors
    if (error.name === 'AbortError' || error.code === 'ECONNABORTED') {
        return createErrorResponse('Request timeout. Please try again.', 408);
    }
    if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
        return createErrorResponse('Network error. Please check your connection.', 503);
    }
    // Azure OpenAI specific errors
    if (error.status) {
        switch(error.status){
            case 401:
                return createErrorResponse('Service authentication failed. Please try again later.', 500);
            case 429:
                return createErrorResponse('Service temporarily unavailable due to high demand. Please try again later.', 429);
            case 400:
                return createErrorResponse('Invalid request format. Please check your input.', 400);
            default:
                if (error.status >= 500) {
                    return createErrorResponse('Service temporarily unavailable. Please try again later.', 500);
                }
        }
    }
    // Generic API errors
    if (error.message) {
        if (error.message.includes('API key') || error.message.includes('credentials')) {
            return createErrorResponse('Service configuration error. Please contact support.', 500);
        }
        if (error.message.includes('quota') || error.message.includes('limit') || error.message.includes('rate')) {
            return createErrorResponse('Service temporarily unavailable due to usage limits. Please try again later.', 429);
        }
        if (error.message.includes('not initialized')) {
            return createErrorResponse('Service is not properly configured. Please contact support.', 500);
        }
    }
    // Default error response
    return createErrorResponse('An unexpected error occurred. Please try again.', 500);
}
/**
 * Standard fallback message for network failures
 */ const NETWORK_FAILURE_MESSAGE = "Could not fetch job description from the provided URL.";
/**
 * Gets user-friendly error message for frontend display
 */ function getUserFriendlyErrorMessage(error, context) {
    if (error?.error) {
        return error.error;
    }
    if (context === 'url_extraction') {
        return NETWORK_FAILURE_MESSAGE;
    }
    if (error?.message) {
        // Don't expose internal error messages to users
        if (error.message.includes('API key') || error.message.includes('credentials') || error.message.includes('internal') || error.message.includes('database')) {
            return 'Service temporarily unavailable. Please try again later.';
        }
        return error.message;
    }
    return 'An unexpected error occurred. Please try again.';
}


/***/ }),

/***/ 65060:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   app: () => (/* binding */ app),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony exports db, googleProvider */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66551);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86958);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(44337);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  false ? 0 : null;
    const windowProjectId =  false ? 0 : null;
    const windowAuthDomain =  false ? 0 : null;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || `${finalProjectId}.firebaseapp.com`;
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (true) {
        console.log('🔥 Firebase initialization skipped on server side');
        return;
    }
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = getApps();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = initializeApp(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = getAuth(app);
        db = getFirestore(app);
        // Initialize Google Auth Provider
        googleProvider = new GoogleAuthProvider();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (false) {}
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (false) {}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 66551:
/***/ ((module) => {

module.exports = import("firebase/app");;

/***/ }),

/***/ 75600:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.prod.js");

/***/ }),

/***/ 81031:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7028);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__]);
_lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/**
 * API endpoint for feature flags - provides client-safe access to feature flags
 * without bundling server-only modules for the client
 */ async function handler(req, res) {
    if (req.method !== 'GET') {
        return res.status(405).json({
            error: 'Method not allowed'
        });
    }
    try {
        // Optional: Verify authentication if needed
        // const authResult = await verifyAuthHeader(req.headers.authorization);
        // if (!authResult.success) {
        //   return res.status(401).json({ error: 'Unauthorized' });
        // }
        const refreshFlags = req.query.refresh === 'true';
        // Get feature flags from the service
        const flags = refreshFlags ? await _lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__/* .featureFlagsService */ .$.refreshFeatureFlags() : await _lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__/* .featureFlagsService */ .$.getAllFeatureFlags();
        return res.status(200).json(flags);
    } catch (error) {
        console.error('Error fetching feature flags:', error);
        // Return default flags on error
        return res.status(200).json({
            autoApplyAzure: false,
            portalIntegration: false,
            voiceInterview: false,
            premiumFeatures: false,
            newUI: false,
            rolloutStatus: {
                autoApplyAzure: false,
                portalIntegration: false,
                voiceInterview: false,
                premiumFeatures: false,
                newUI: false
            }
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 82015:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 86958:
/***/ ((module) => {

module.exports = import("firebase/auth");;

/***/ }),

/***/ 97747:
/***/ ((module) => {

module.exports = import("firebase/remote-config");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7866,2096], () => (__webpack_exec__(34000)));
module.exports = __webpack_exports__;

})();