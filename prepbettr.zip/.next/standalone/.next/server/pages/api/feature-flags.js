"use strict";
(() => {
var exports = {};
exports.id = 1505;
exports.ids = [1505];
exports.modules = {

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 7028:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ featureFlagsService)
/* harmony export */ });
/* harmony import */ var _unified_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(67327);
/* harmony import */ var _user_targeting__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13179);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_unified_config_service__WEBPACK_IMPORTED_MODULE_0__, _user_targeting__WEBPACK_IMPORTED_MODULE_1__]);
([_unified_config_service__WEBPACK_IMPORTED_MODULE_0__, _user_targeting__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


class FeatureFlagsService {
    static getInstance() {
        if (!FeatureFlagsService.instance) {
            FeatureFlagsService.instance = new FeatureFlagsService();
        }
        return FeatureFlagsService.instance;
    }
    /**
   * Get feature flag value considering both remote config and user targeting
   */ async getFeatureFlag(flagName) {
        try {
            // Get feature flag from unified config service
            const configKey = `features.${flagName}`;
            const globalValue = await _unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.get(configKey, false);
            if (!globalValue) {
                // If disabled globally, return false
                return false;
            }
            // If enabled globally, check if user is in the rollout
            const rolloutConfig = _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .UserTargetingService */ .o.ROLLOUT_CONFIGS[flagName];
            if (!rolloutConfig) {
                // If no rollout config, default to global setting
                return globalValue;
            }
            return _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .userTargetingService */ .A.isCurrentUserInRollout(rolloutConfig);
        } catch (error) {
            console.error(`Error getting feature flag ${flagName}:`, error);
            return false; // Default to disabled on error
        }
    }
    /**
   * Get all feature flags with rollout status
   */ async getAllFeatureFlags() {
        try {
            // Get all feature flags from unified config service
            const allConfigs = await _unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.getAll('features.');
            // Extract flags from config keys
            const globalFlags = {
                autoApplyAzure: allConfigs['features.autoApplyAzure'] || false,
                portalIntegration: allConfigs['features.portalIntegration'] || false,
                voiceInterview: allConfigs['features.voiceInterview'] || false,
                premiumFeatures: allConfigs['features.premiumFeatures'] || false,
                newUI: allConfigs['features.newUI'] || false
            };
            // Get rollout status for current user
            const rolloutStatus = _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .userTargetingService */ .A.getCurrentUserRolloutStatus();
            // Combine both: feature must be enabled globally AND user must be in rollout
            const enhancedFlags = {
                autoApplyAzure: globalFlags.autoApplyAzure && rolloutStatus.autoApplyAzure,
                portalIntegration: globalFlags.portalIntegration && rolloutStatus.portalIntegration,
                voiceInterview: globalFlags.voiceInterview && rolloutStatus.voiceInterview,
                premiumFeatures: globalFlags.premiumFeatures && rolloutStatus.premiumFeatures,
                newUI: globalFlags.newUI && rolloutStatus.newUI,
                rolloutStatus: {
                    autoApplyAzure: rolloutStatus.autoApplyAzure || false,
                    portalIntegration: rolloutStatus.portalIntegration || false,
                    voiceInterview: rolloutStatus.voiceInterview || false,
                    premiumFeatures: rolloutStatus.premiumFeatures || false,
                    newUI: rolloutStatus.newUI || false
                }
            };
            return enhancedFlags;
        } catch (error) {
            console.error('Error getting all feature flags:', error);
            return {
                autoApplyAzure: false,
                portalIntegration: false,
                voiceInterview: false,
                premiumFeatures: false,
                newUI: false,
                rolloutStatus: {
                    autoApplyAzure: false,
                    portalIntegration: false,
                    voiceInterview: false,
                    premiumFeatures: false,
                    newUI: false
                }
            };
        }
    }
    /**
   * Check if a specific feature is enabled for the current user
   */ async isFeatureEnabled(featureName) {
        return this.getFeatureFlag(featureName);
    }
    /**
   * Convenience methods for specific features
   */ async isAutoApplyAzureEnabled() {
        return this.getFeatureFlag('autoApplyAzure');
    }
    async isPortalIntegrationEnabled() {
        return this.getFeatureFlag('portalIntegration');
    }
    /**
   * Get debug information about feature flags
   */ async getDebugInfo() {
        const unifiedConfig = await _unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.getAll('features.');
        const rolloutStatus = _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .userTargetingService */ .A.getCurrentUserRolloutStatus();
        const finalFlags = await this.getAllFeatureFlags();
        const userId = _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .userTargetingService */ .A.getCurrentUserId();
        return {
            unifiedConfig,
            rolloutStatus,
            finalFlags: {
                autoApplyAzure: finalFlags.autoApplyAzure,
                portalIntegration: finalFlags.portalIntegration,
                voiceInterview: finalFlags.voiceInterview,
                premiumFeatures: finalFlags.premiumFeatures,
                newUI: finalFlags.newUI
            },
            userId,
            rolloutConfigs: _user_targeting__WEBPACK_IMPORTED_MODULE_1__/* .UserTargetingService */ .o.ROLLOUT_CONFIGS
        };
    }
    /**
   * Force refresh all feature flags
   */ async refreshFeatureFlags() {
        await _unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.refresh();
        return this.getAllFeatureFlags();
    }
}
// Export singleton instance
const featureFlagsService = FeatureFlagsService.getInstance();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 10756:
/***/ ((module) => {

module.exports = import("@azure/identity");;

/***/ }),

/***/ 13179:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ userTargetingService),
/* harmony export */   o: () => (/* binding */ UserTargetingService)
/* harmony export */ });
/* harmony import */ var _firebase_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65060);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_firebase_client__WEBPACK_IMPORTED_MODULE_0__]);
_firebase_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

class UserTargetingService {
    static getInstance() {
        if (!UserTargetingService.instance) {
            UserTargetingService.instance = new UserTargetingService();
        }
        return UserTargetingService.instance;
    }
    /**
   * Simple hash function to create a consistent hash from user ID
   */ hashUserId(userId) {
        let hash = 0;
        for(let i = 0; i < userId.length; i++){
            const char = userId.charCodeAt(i);
            hash = (hash << 5) - hash + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return Math.abs(hash);
    }
    /**
   * Determines if a user should be included in a feature rollout
   * Uses consistent hashing to ensure the same user always gets the same result
   */ isUserInRollout(userId, rolloutConfig) {
        if (rolloutConfig.percentage <= 0) return false;
        if (rolloutConfig.percentage >= 100) return true;
        // Create a feature-specific hash by combining userId and feature name
        const combinedString = `${userId}-${rolloutConfig.featureName}`;
        const hash = this.hashUserId(combinedString);
        // Use modulo to get a consistent percentage (0-99)
        const userBucket = hash % 100;
        return userBucket < rolloutConfig.percentage;
    }
    /**
   * Get the current user's ID
   */ getCurrentUserId() {
        return _firebase_client__WEBPACK_IMPORTED_MODULE_0__/* .auth */ .j2?.currentUser?.uid || null;
    }
    /**
   * Check if current user is in a specific feature rollout
   */ isCurrentUserInRollout(rolloutConfig) {
        const userId = this.getCurrentUserId();
        if (!userId) {
            // For anonymous users, use a fallback (could be device ID, session ID, etc.)
            const fallbackId = this.getAnonymousUserFallback();
            return this.isUserInRollout(fallbackId, rolloutConfig);
        }
        return this.isUserInRollout(userId, rolloutConfig);
    }
    /**
   * Generate a fallback ID for anonymous users
   * This could be based on device fingerprinting, localStorage, etc.
   */ getAnonymousUserFallback() {
        // Try to get or create a persistent anonymous ID
        let anonymousId = localStorage.getItem('prep_anonymous_id');
        if (!anonymousId) {
            // Generate a new anonymous ID
            anonymousId = `anon_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            localStorage.setItem('prep_anonymous_id', anonymousId);
        }
        return anonymousId;
    }
    static{
        /**
   * Predefined rollout configurations
   */ this.ROLLOUT_CONFIGS = {
            autoApplyAzure: {
                percentage: 5,
                featureName: 'autoApplyAzure'
            },
            portalIntegration: {
                percentage: 5,
                featureName: 'portalIntegration'
            },
            voiceInterview: {
                percentage: 10,
                featureName: 'voiceInterview'
            },
            premiumFeatures: {
                percentage: 15,
                featureName: 'premiumFeatures'
            },
            newUI: {
                percentage: 20,
                featureName: 'newUI'
            }
        };
    }
    /**
   * Get all rollout statuses for the current user
   */ getCurrentUserRolloutStatus() {
        return {
            autoApplyAzure: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.autoApplyAzure),
            portalIntegration: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.portalIntegration),
            voiceInterview: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.voiceInterview),
            premiumFeatures: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.premiumFeatures),
            newUI: this.isCurrentUserInRollout(UserTargetingService.ROLLOUT_CONFIGS.newUI)
        };
    }
    /**
   * Update rollout percentage for a feature (for admin/testing purposes)
   */ static updateRolloutPercentage(featureName, percentage) {
        if (percentage < 0 || percentage > 100) {
            throw new Error('Rollout percentage must be between 0 and 100');
        }
        UserTargetingService.ROLLOUT_CONFIGS[featureName].percentage = percentage;
        console.log(`Updated ${featureName} rollout to ${percentage}%`);
    }
}
// Export singleton instance
const userTargetingService = UserTargetingService.getInstance();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 14655:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G: () => (/* binding */ configMonitoringService)
/* harmony export */ });
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65044);
/* harmony import */ var _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(32096);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__]);
_azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Configuration Monitoring Service
 * 
 * Provides comprehensive monitoring, metrics, and alerting for the
 * unified configuration system with Application Insights integration.
 */ 

// ===== MONITORING SERVICE =====
class ConfigMonitoringService {
    constructor(){
        this.telemetryClient = null;
        this.metrics = {
            requestCount: 0,
            cacheHits: 0,
            cacheMisses: 0,
            avgLatency: 0,
            errorCount: 0,
            driftDetected: 0,
            syncFailures: 0
        };
        this.latencyBuffer = [];
        this.LATENCY_BUFFER_SIZE = 100;
        this.ALERT_THRESHOLDS = {
            HIGH_LATENCY_MS: 1000,
            ERROR_RATE_THRESHOLD: 0.05,
            CACHE_HIT_RATIO_MIN: 0.8,
            MAX_DRIFT_COUNT: 5
        };
        this.initializeTelemetry();
    }
    // ===== INITIALIZATION =====
    initializeTelemetry() {
        try {
            const appInsightsKey = process.env.APPLICATIONINSIGHTS_CONNECTION_STRING;
            if (appInsightsKey) {
                // Application Insights is typically initialized globally
                // This service uses the global instance if available
                const appInsights = __webpack_require__(26231);
                if (appInsights.defaultClient) {
                    this.telemetryClient = appInsights.defaultClient;
                    console.log('✅ Config monitoring connected to Application Insights');
                } else {
                    appInsights.setup(appInsightsKey).setAutoCollectRequests(true).setAutoCollectPerformance(true).setAutoCollectExceptions(true).setAutoCollectDependencies(true).setAutoCollectConsole(true, true).setUseDiskRetryCaching(true).start();
                    this.telemetryClient = appInsights.defaultClient;
                    console.log('✅ Config monitoring initialized Application Insights');
                }
            } else {
                console.warn('⚠️ Application Insights connection string not found - monitoring disabled');
            }
        } catch (error) {
            console.error('❌ Failed to initialize Application Insights:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_0__/* .logServerError */ .wh)(error, {
                service: 'config-monitoring',
                action: 'initialize'
            });
        }
    }
    // ===== METRICS TRACKING =====
    /**
   * Track configuration request with timing
   */ trackConfigRequest(key, operation, latency, success) {
        this.metrics.requestCount++;
        // Update latency metrics
        this.latencyBuffer.push(latency);
        if (this.latencyBuffer.length > this.LATENCY_BUFFER_SIZE) {
            this.latencyBuffer.shift();
        }
        this.metrics.avgLatency = this.latencyBuffer.reduce((a, b)=>a + b, 0) / this.latencyBuffer.length;
        // Track errors
        if (!success) {
            this.metrics.errorCount++;
        }
        // Send to Application Insights
        if (this.telemetryClient) {
            this.telemetryClient.trackRequest({
                name: `Config-${operation}`,
                url: `config://${key}`,
                duration: latency,
                resultCode: success ? '200' : '500',
                success,
                properties: {
                    configKey: key,
                    operation,
                    service: 'unified-config'
                },
                measurements: {
                    latency,
                    cacheHitRatio: this.getCacheHitRatio(),
                    requestCount: this.metrics.requestCount
                }
            });
            // Track custom metric
            this.telemetryClient.trackMetric({
                name: 'Config.Request.Latency',
                value: latency,
                properties: {
                    operation,
                    key: key.split('.')[0] // Track by namespace
                }
            });
        }
        // Check for alerts
        this.checkLatencyAlert(latency);
        this.checkErrorRateAlert();
    }
    /**
   * Track cache hit/miss
   */ trackCacheHit(hit, key) {
        if (hit) {
            this.metrics.cacheHits++;
        } else {
            this.metrics.cacheMisses++;
        }
        if (this.telemetryClient) {
            this.telemetryClient.trackEvent({
                name: 'Config.Cache.Access',
                properties: {
                    hit: hit.toString(),
                    key: key.split('.')[0],
                    service: 'unified-config'
                },
                measurements: {
                    hitRatio: this.getCacheHitRatio(),
                    totalCacheAccess: this.metrics.cacheHits + this.metrics.cacheMisses
                }
            });
        }
        // Check cache performance alert
        this.checkCachePerformanceAlert();
    }
    /**
   * Track configuration drift detection
   */ trackDriftDetection(driftedKeys, totalChecked) {
        this.metrics.driftDetected = driftedKeys.length;
        if (this.telemetryClient) {
            this.telemetryClient.trackEvent({
                name: 'Config.Drift.Detection',
                properties: {
                    driftedKeys: driftedKeys.join(','),
                    service: 'unified-config'
                },
                measurements: {
                    driftCount: driftedKeys.length,
                    totalChecked,
                    driftRatio: driftedKeys.length / totalChecked
                }
            });
        }
        // Alert if drift detected
        if (driftedKeys.length > 0) {
            this.createAlert('drift', 'high', `Configuration drift detected in ${driftedKeys.length} keys: ${driftedKeys.join(', ')}`, {
                driftedKeys,
                totalChecked
            });
        }
    }
    /**
   * Track Firebase sync operations
   */ trackSyncOperation(success, keysSync, duration, error) {
        if (!success) {
            this.metrics.syncFailures++;
        }
        if (this.telemetryClient) {
            this.telemetryClient.trackDependency({
                dependencyTypeName: 'Firebase',
                name: 'Config.Sync',
                data: `Sync ${keysSync} keys`,
                duration,
                success,
                properties: {
                    keysSync: keysSync.toString(),
                    service: 'config-sync',
                    error: error || ''
                }
            });
            this.telemetryClient.trackMetric({
                name: 'Config.Sync.KeyCount',
                value: keysSync,
                properties: {
                    success: success.toString()
                }
            });
        }
        // Alert on sync failures
        if (!success) {
            this.createAlert('sync_failure', 'medium', `Firebase sync failed: ${error || 'Unknown error'}`, {
                keysSync,
                duration,
                error
            });
        }
    }
    /**
   * Track configuration changes
   */ trackConfigChange(key, oldValue, newValue, changedBy, environment) {
        if (this.telemetryClient) {
            this.telemetryClient.trackEvent({
                name: 'Config.Change',
                properties: {
                    key,
                    changedBy,
                    environment,
                    service: 'unified-config',
                    hasOldValue: (oldValue !== null && oldValue !== undefined).toString(),
                    valueType: typeof newValue
                },
                measurements: {
                    changeTimestamp: Date.now()
                }
            });
        }
    }
    // ===== ALERTING =====
    /**
   * Create and process alerts
   */ async createAlert(type, severity, message, metadata) {
        const alert = {
            id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            type,
            severity,
            message,
            metadata,
            timestamp: new Date(),
            resolved: false,
            environment: "production" || 0
        };
        // Store alert in Cosmos DB
        try {
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__/* .azureCosmosService */ .h.createDocument('configAlerts', {
                ...alert,
                _partitionKey: alert.type
            });
        } catch (error) {
            console.error('Failed to store alert:', error);
        }
        // Send to Application Insights as exception for high/critical severity
        if (this.telemetryClient && (severity === 'high' || severity === 'critical')) {
            this.telemetryClient.trackException({
                exception: new Error(`Config Alert [${severity.toUpperCase()}]: ${message}`),
                properties: {
                    alertId: alert.id,
                    alertType: type,
                    severity,
                    environment: alert.environment,
                    service: 'unified-config'
                },
                measurements: metadata
            });
        }
        // Send to notification channels
        await this.sendAlertNotification(alert);
        console.warn(`🚨 Config Alert [${severity.toUpperCase()}]: ${message}`);
    }
    /**
   * Check for latency alerts
   */ checkLatencyAlert(latency) {
        if (latency > this.ALERT_THRESHOLDS.HIGH_LATENCY_MS) {
            this.createAlert('high_latency', 'medium', `High configuration latency detected: ${latency}ms`, {
                latency,
                threshold: this.ALERT_THRESHOLDS.HIGH_LATENCY_MS
            });
        }
    }
    /**
   * Check for error rate alerts
   */ checkErrorRateAlert() {
        const errorRate = this.metrics.requestCount > 0 ? this.metrics.errorCount / this.metrics.requestCount : 0;
        if (errorRate > this.ALERT_THRESHOLDS.ERROR_RATE_THRESHOLD && this.metrics.requestCount > 10) {
            this.createAlert('error_rate', 'high', `High configuration error rate: ${(errorRate * 100).toFixed(2)}%`, {
                errorRate,
                errorCount: this.metrics.errorCount,
                requestCount: this.metrics.requestCount
            });
        }
    }
    /**
   * Check for cache performance alerts
   */ checkCachePerformanceAlert() {
        const hitRatio = this.getCacheHitRatio();
        const totalRequests = this.metrics.cacheHits + this.metrics.cacheMisses;
        if (hitRatio < this.ALERT_THRESHOLDS.CACHE_HIT_RATIO_MIN && totalRequests > 50) {
            this.createAlert('cache_performance', 'medium', `Low cache hit ratio: ${(hitRatio * 100).toFixed(2)}%`, {
                hitRatio,
                cacheHits: this.metrics.cacheHits,
                cacheMisses: this.metrics.cacheMisses
            });
        }
    }
    // ===== NOTIFICATIONS =====
    /**
   * Send alert notifications to configured channels
   */ async sendAlertNotification(alert) {
        try {
            // Slack webhook notification
            const slackWebhook = process.env.SLACK_WEBHOOK_URL;
            if (slackWebhook && (alert.severity === 'high' || alert.severity === 'critical')) {
                await this.sendSlackNotification(alert, slackWebhook);
            }
        // Email notification (could be implemented)
        // await this.sendEmailNotification(alert);
        // Microsoft Teams notification (could be implemented)
        // await this.sendTeamsNotification(alert);
        } catch (error) {
            console.error('Failed to send alert notification:', error);
        }
    }
    /**
   * Send Slack notification
   */ async sendSlackNotification(alert, webhookUrl) {
        const payload = {
            text: `🚨 Configuration Alert: ${alert.message}`,
            attachments: [
                {
                    color: this.getAlertColor(alert.severity),
                    fields: [
                        {
                            title: 'Alert Type',
                            value: alert.type,
                            short: true
                        },
                        {
                            title: 'Severity',
                            value: alert.severity.toUpperCase(),
                            short: true
                        },
                        {
                            title: 'Environment',
                            value: alert.environment,
                            short: true
                        },
                        {
                            title: 'Timestamp',
                            value: alert.timestamp.toISOString(),
                            short: true
                        }
                    ],
                    footer: 'PrepBettr Config Monitoring'
                }
            ]
        };
        const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });
        if (!response.ok) {
            throw new Error(`Slack notification failed: ${response.statusText}`);
        }
    }
    /**
   * Get alert color for Slack
   */ getAlertColor(severity) {
        switch(severity){
            case 'critical':
                return 'danger';
            case 'high':
                return 'warning';
            case 'medium':
                return 'warning';
            case 'low':
                return 'good';
            default:
                return 'good';
        }
    }
    // ===== HEALTH CHECK =====
    /**
   * Perform comprehensive health check
   */ async healthCheck() {
        const alerts = await this.getActiveAlerts();
        const status = this.calculateHealthStatus(alerts);
        return {
            service: 'unified-config',
            status,
            timestamp: new Date(),
            metrics: {
                ...this.metrics
            },
            alerts,
            details: {
                cacheHitRatio: this.getCacheHitRatio(),
                avgLatency: this.metrics.avgLatency,
                errorRate: this.metrics.requestCount > 0 ? this.metrics.errorCount / this.metrics.requestCount : 0,
                uptime: process.uptime()
            }
        };
    }
    /**
   * Get active alerts
   */ async getActiveAlerts() {
        try {
            const alerts = await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_1__/* .azureCosmosService */ .h.queryDocuments('configAlerts', 'SELECT * FROM c WHERE c.resolved = false AND c.timestamp >= @cutoff ORDER BY c.timestamp DESC', [
                {
                    name: '@cutoff',
                    value: new Date(Date.now() - 24 * 60 * 60 * 1000)
                }
            ] // Last 24 hours
            );
            return alerts.slice(0, 10); // Limit to 10 most recent
        } catch (error) {
            console.error('Failed to get active alerts:', error);
            return [];
        }
    }
    /**
   * Calculate overall health status
   */ calculateHealthStatus(alerts) {
        const criticalAlerts = alerts.filter((a)=>a.severity === 'critical');
        const highAlerts = alerts.filter((a)=>a.severity === 'high');
        if (criticalAlerts.length > 0) return 'unhealthy';
        if (highAlerts.length > 2) return 'unhealthy';
        if (alerts.length > 5) return 'degraded';
        // Check metrics
        const errorRate = this.metrics.requestCount > 0 ? this.metrics.errorCount / this.metrics.requestCount : 0;
        const cacheHitRatio = this.getCacheHitRatio();
        if (errorRate > 0.1 || cacheHitRatio < 0.5 || this.metrics.avgLatency > 2000) {
            return 'degraded';
        }
        return 'healthy';
    }
    // ===== UTILITY METHODS =====
    /**
   * Get current cache hit ratio
   */ getCacheHitRatio() {
        const total = this.metrics.cacheHits + this.metrics.cacheMisses;
        return total > 0 ? this.metrics.cacheHits / total : 0;
    }
    /**
   * Get current metrics
   */ getMetrics() {
        return {
            ...this.metrics
        };
    }
    /**
   * Reset metrics (for testing or periodic reset)
   */ resetMetrics() {
        this.metrics = {
            requestCount: 0,
            cacheHits: 0,
            cacheMisses: 0,
            avgLatency: 0,
            errorCount: 0,
            driftDetected: 0,
            syncFailures: 0
        };
        this.latencyBuffer = [];
    }
    /**
   * Flush telemetry data
   */ flush() {
        return new Promise((resolve)=>{
            if (this.telemetryClient) {
                this.telemetryClient.flush();
                // Flush is synchronous, so we can resolve immediately
                resolve();
            } else {
                resolve();
            }
        });
    }
}
// ===== SINGLETON INSTANCE =====
const configMonitoringService = new ConfigMonitoringService();
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (configMonitoringService)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 16446:
/***/ ((module) => {

module.exports = import("@azure/app-configuration");;

/***/ }),

/***/ 26231:
/***/ ((module) => {

module.exports = require("applicationinsights");

/***/ }),

/***/ 29294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 32096:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   h: () => (/* binding */ azureCosmosService)
/* harmony export */ });
/* harmony import */ var _azure_cosmos__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(46602);
/* harmony import */ var _lib_config_environment_loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52359);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_cosmos__WEBPACK_IMPORTED_MODULE_0__, _lib_config_environment_loader__WEBPACK_IMPORTED_MODULE_1__]);
([_azure_cosmos__WEBPACK_IMPORTED_MODULE_0__, _lib_config_environment_loader__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


class AzureCosmosService {
    constructor(){
        this.client = null;
        this.database = null;
        this.containers = new Map();
        this.initialized = false;
    // Client initialization is now deferred to initialize() method
    // to use the unified environment loader
    }
    async initialize() {
        if (this.initialized) return;
        try {
            // Load Cosmos DB configuration from unified environment loader
            const cosmosConfig = await (0,_lib_config_environment_loader__WEBPACK_IMPORTED_MODULE_1__/* .getCosmosDbConfig */ .Nv)();
            if (!cosmosConfig.connectionString) {
                throw new Error('Cosmos DB connection string not available in configuration');
            }
            // Initialize Cosmos client with configuration
            this.client = new _azure_cosmos__WEBPACK_IMPORTED_MODULE_0__.CosmosClient(cosmosConfig.connectionString);
            // Create or get database
            const { database } = await this.client.databases.createIfNotExists({
                id: cosmosConfig.database
            });
            this.database = database;
            // Define containers with their partition keys
            const containerDefinitions = [
                {
                    id: 'users',
                    partitionKey: '/userId'
                },
                {
                    id: 'interviews',
                    partitionKey: '/userId'
                },
                {
                    id: 'feedback',
                    partitionKey: '/userId'
                },
                {
                    id: 'resumes',
                    partitionKey: '/userId'
                },
                {
                    id: 'usage',
                    partitionKey: '/userId'
                },
                {
                    id: 'jobListings',
                    partitionKey: '/id'
                },
                {
                    id: 'applications',
                    partitionKey: '/userId'
                },
                {
                    id: 'autoApplySettings',
                    partitionKey: '/userId'
                },
                {
                    id: 'automationLogs',
                    partitionKey: '/userId'
                },
                {
                    id: 'subscriptionEvents',
                    partitionKey: '/id'
                },
                {
                    id: 'dataDeletionRequests',
                    partitionKey: '/userId'
                },
                {
                    id: 'dataProtectionAuditLog',
                    partitionKey: '/userId'
                },
                {
                    id: 'notificationEvents',
                    partitionKey: '/userId'
                },
                {
                    id: 'featureErrors',
                    partitionKey: '/featureName'
                },
                {
                    id: 'errorBudgets',
                    partitionKey: '/featureName'
                },
                {
                    id: 'emailVerifications',
                    partitionKey: '/userId'
                },
                {
                    id: 'profiles',
                    partitionKey: '/userId'
                }
            ];
            // Create containers
            if (!this.database) {
                throw new Error('Database initialization failed');
            }
            for (const containerDef of containerDefinitions){
                const { container } = await this.database.containers.createIfNotExists({
                    id: containerDef.id,
                    partitionKey: containerDef.partitionKey
                });
                this.containers.set(containerDef.id, container);
            }
            this.initialized = true;
            console.log('✅ Azure Cosmos DB service initialized');
        } catch (error) {
            console.error('❌ Failed to initialize Azure Cosmos DB:', error);
            throw error;
        }
    }
    getContainer(containerName) {
        const container = this.containers.get(containerName);
        if (!container) {
            throw new Error(`Container ${containerName} not found. Make sure initialize() was called.`);
        }
        return container;
    }
    // Users operations
    async createUser(userData) {
        await this.initialize();
        const container = this.getContainer('users');
        const document = {
            id: userData.userId,
            ...userData,
            _partitionKey: userData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getUser(userId) {
        await this.initialize();
        const container = this.getContainer('users');
        try {
            const { resource } = await container.item(userId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async updateUser(userId, updates) {
        await this.initialize();
        const container = this.getContainer('users');
        const { resource: existing } = await container.item(userId, userId).read();
        if (!existing) throw new Error('User not found');
        const updated = {
            ...existing,
            ...updates,
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.item(userId, userId).replace(updated);
    }
    // Interviews operations
    async createInterview(interviewData) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const id = `interview_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...interviewData,
            _partitionKey: interviewData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getInterview(interviewId, userId) {
        await this.initialize();
        const container = this.getContainer('interviews');
        try {
            const { resource } = await container.item(interviewId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async getUserInterviews(userId) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId ORDER BY c.createdAt DESC',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    async getPublicInterviews(userId, limit = 20) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId AND c.finalized = true ORDER BY c.createdAt DESC OFFSET 0 LIMIT @limit',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                },
                {
                    name: '@limit',
                    value: limit
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    async getPublicInterviewsExcludingUser(excludeUserId, limit = 20) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.finalized = true AND c.userId != @excludeUserId ORDER BY c.createdAt DESC OFFSET 0 LIMIT @limit',
            parameters: [
                {
                    name: '@excludeUserId',
                    value: excludeUserId
                },
                {
                    name: '@limit',
                    value: limit
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    async updateInterview(interviewId, userId, updates) {
        await this.initialize();
        const container = this.getContainer('interviews');
        const { resource: existing } = await container.item(interviewId, userId).read();
        if (!existing) throw new Error('Interview not found');
        const updated = {
            ...existing,
            ...updates,
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.item(interviewId, userId).replace(updated);
    }
    async deleteInterview(interviewId, userId) {
        await this.initialize();
        const container = this.getContainer('interviews');
        await container.item(interviewId, userId).delete();
    }
    // Feedback operations
    async createFeedback(feedbackData) {
        await this.initialize();
        const container = this.getContainer('feedback');
        const id = `feedback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...feedbackData,
            _partitionKey: feedbackData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getFeedbackByInterview(interviewId, userId) {
        await this.initialize();
        const container = this.getContainer('feedback');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.interviewId = @interviewId AND c.userId = @userId',
            parameters: [
                {
                    name: '@interviewId',
                    value: interviewId
                },
                {
                    name: '@userId',
                    value: userId
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources[0] || null;
    }
    // Resume operations
    async saveResume(resumeData) {
        await this.initialize();
        const container = this.getContainer('resumes');
        const document = {
            ...resumeData,
            _partitionKey: resumeData.userId
        };
        const { resource } = await container.items.upsert(document);
        return resource.id;
    }
    async getUserResume(userId) {
        await this.initialize();
        const container = this.getContainer('resumes');
        try {
            const { resource } = await container.item(userId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async deleteUserResume(userId) {
        await this.initialize();
        const container = this.getContainer('resumes');
        try {
            await container.item(userId, userId).delete();
        } catch (error) {
            if (error.code === 404) return; // Already deleted
            throw error;
        }
    }
    // Usage operations
    async getUserUsage(userId) {
        await this.initialize();
        const container = this.getContainer('usage');
        try {
            const { resource } = await container.item(userId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async initializeUserUsage(userId) {
        await this.initialize();
        const container = this.getContainer('usage');
        const usageData = {
            id: userId,
            userId,
            interviews: {
                count: 0,
                limit: 3
            },
            resumes: {
                count: 0,
                limit: 2
            },
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.items.upsert(usageData);
    }
    async incrementUsage(userId, type) {
        await this.initialize();
        const container = this.getContainer('usage');
        const { resource: existing } = await container.item(userId, userId).read();
        if (!existing) {
            await this.initializeUserUsage(userId);
            return this.incrementUsage(userId, type);
        }
        const updated = {
            ...existing,
            [type]: {
                ...existing[type],
                count: existing[type].count + 1
            },
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.item(userId, userId).replace(updated);
    }
    async checkUsageLimit(userId, type) {
        const usage = await this.getUserUsage(userId);
        if (!usage) {
            await this.initializeUserUsage(userId);
            return true;
        }
        return usage[type].count < usage[type].limit;
    }
    // Job-related operations
    async createJobListing(jobData) {
        await this.initialize();
        const container = this.getContainer('jobListings');
        const id = `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...jobData,
            _partitionKey: id
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getActiveJobListings(userId) {
        await this.initialize();
        const container = this.getContainer('jobListings');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.isActive = true AND (ARRAY_CONTAINS(c.discoveredBy, @userId) OR ARRAY_LENGTH(c.discoveredBy) = 0) ORDER BY c.postedDate DESC',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    // Applications operations
    async createApplication(applicationData) {
        await this.initialize();
        const container = this.getContainer('applications');
        const id = `app_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...applicationData,
            _partitionKey: applicationData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getUserApplications(userId) {
        await this.initialize();
        const container = this.getContainer('applications');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId ORDER BY c.appliedAt DESC',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    // GDPR operations
    async createDataDeletionRequest(requestData) {
        await this.initialize();
        const container = this.getContainer('dataDeletionRequests');
        const id = `del_req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...requestData,
            _partitionKey: requestData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async deleteAllUserData(userId) {
        await this.initialize();
        const deletedCollections = [];
        const collections = [
            'users',
            'interviews',
            'feedback',
            'resumes',
            'usage',
            'applications',
            'autoApplySettings',
            'automationLogs',
            'dataDeletionRequests'
        ];
        for (const collectionName of collections){
            try {
                const container = this.getContainer(collectionName);
                if (collectionName === 'users' || collectionName === 'resumes' || collectionName === 'usage') {
                    // These use userId as document ID
                    try {
                        await container.item(userId, userId).delete();
                        deletedCollections.push(collectionName);
                    } catch (error) {
                        if (error.code !== 404) throw error;
                    }
                } else {
                    // Query and delete all documents for this user
                    const querySpec = {
                        query: 'SELECT c.id FROM c WHERE c.userId = @userId',
                        parameters: [
                            {
                                name: '@userId',
                                value: userId
                            }
                        ]
                    };
                    const { resources } = await container.items.query(querySpec).fetchAll();
                    if (resources.length > 0) {
                        for (const item of resources){
                            await container.item(item.id, userId).delete();
                        }
                        deletedCollections.push(collectionName);
                    }
                }
            } catch (error) {
                console.error(`Error deleting from ${collectionName}:`, error);
            }
        }
        return deletedCollections;
    }
    // Notification Events operations
    async createNotificationEvent(eventData) {
        await this.initialize();
        const container = this.getContainer('notificationEvents');
        const id = `notify_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...eventData,
            _partitionKey: eventData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async updateNotificationEvent(eventId, userId, updates) {
        await this.initialize();
        const container = this.getContainer('notificationEvents');
        const { resource: existing } = await container.item(eventId, userId).read();
        if (!existing) throw new Error('Notification event not found');
        const updated = {
            ...existing,
            ...updates,
            updatedAt: new Date(),
            _partitionKey: userId
        };
        await container.item(eventId, userId).replace(updated);
    }
    async getUserNotificationEvents(userId, limit = 50) {
        await this.initialize();
        const container = this.getContainer('notificationEvents');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId ORDER BY c.createdAt DESC OFFSET 0 LIMIT @limit',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                },
                {
                    name: '@limit',
                    value: limit
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    // Error Events operations for monitoring
    async createErrorEvent(errorData) {
        await this.initialize();
        const container = this.getContainer('featureErrors');
        const id = `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...errorData,
            _partitionKey: errorData.featureName
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getErrorEvents(featureName, timeWindowMinutes, limit = 100) {
        await this.initialize();
        const container = this.getContainer('featureErrors');
        const cutoffTime = new Date(Date.now() - timeWindowMinutes * 60 * 1000);
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.featureName = @featureName AND c.timestamp >= @cutoffTime ORDER BY c.timestamp DESC OFFSET 0 LIMIT @limit',
            parameters: [
                {
                    name: '@featureName',
                    value: featureName
                },
                {
                    name: '@cutoffTime',
                    value: cutoffTime
                },
                {
                    name: '@limit',
                    value: limit
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources;
    }
    async getErrorEventCount(featureName, timeWindowMinutes) {
        await this.initialize();
        const container = this.getContainer('featureErrors');
        const cutoffTime = new Date(Date.now() - timeWindowMinutes * 60 * 1000);
        const querySpec = {
            query: 'SELECT VALUE COUNT(1) FROM c WHERE c.featureName = @featureName AND c.timestamp >= @cutoffTime',
            parameters: [
                {
                    name: '@featureName',
                    value: featureName
                },
                {
                    name: '@cutoffTime',
                    value: cutoffTime
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources[0] || 0;
    }
    // Error Budget operations
    async createErrorBudget(budgetData) {
        await this.initialize();
        const container = this.getContainer('errorBudgets');
        const id = `budget_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...budgetData,
            _partitionKey: budgetData.featureName
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    // Email Verification operations
    async createEmailVerification(verificationData) {
        await this.initialize();
        const container = this.getContainer('emailVerifications');
        const id = `verify_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const document = {
            id,
            ...verificationData,
            _partitionKey: verificationData.userId
        };
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getEmailVerification(userId, email, type) {
        await this.initialize();
        const container = this.getContainer('emailVerifications');
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.userId = @userId AND c.email = @email AND c.type = @type AND c.verified = false ORDER BY c.createdAt DESC',
            parameters: [
                {
                    name: '@userId',
                    value: userId
                },
                {
                    name: '@email',
                    value: email
                },
                {
                    name: '@type',
                    value: type
                }
            ]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        return resources[0] || null;
    }
    async updateEmailVerification(verificationId, userId, updates) {
        await this.initialize();
        const container = this.getContainer('emailVerifications');
        const { resource: existing } = await container.item(verificationId, userId).read();
        if (!existing) throw new Error('Email verification not found');
        const updated = {
            ...existing,
            ...updates,
            _partitionKey: userId
        };
        await container.item(verificationId, userId).replace(updated);
    }
    // Profile operations (for Firestore profiles collection)
    async saveProfile(profileData) {
        await this.initialize();
        const container = this.getContainer('profiles');
        const document = {
            ...profileData,
            _partitionKey: profileData.userId
        };
        const { resource } = await container.items.upsert(document);
        return resource.id;
    }
    async getProfile(userId) {
        await this.initialize();
        const container = this.getContainer('profiles');
        try {
            const { resource } = await container.item(userId, userId).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async updateProfile(userId, updates) {
        await this.initialize();
        const container = this.getContainer('profiles');
        const { resource: existing } = await container.item(userId, userId).read();
        if (!existing) {
            // Create new profile if doesn't exist
            const newProfile = {
                id: userId,
                userId,
                ...updates,
                updatedAt: new Date(),
                _partitionKey: userId
            };
            await container.items.create(newProfile);
        } else {
            const updated = {
                ...existing,
                ...updates,
                updatedAt: new Date(),
                _partitionKey: userId
            };
            await container.item(userId, userId).replace(updated);
        }
    }
    // Generic query operations for complex Firestore-like queries
    async queryDocuments(containerName, query, parameters, partitionKey) {
        await this.initialize();
        const container = this.getContainer(containerName);
        const querySpec = {
            query,
            parameters
        };
        const queryOptions = partitionKey ? {
            partitionKey
        } : {};
        const { resources } = await container.items.query(querySpec, queryOptions).fetchAll();
        return resources;
    }
    // Generic document operations
    async createDocument(containerName, document) {
        await this.initialize();
        const container = this.getContainer(containerName);
        const { resource } = await container.items.create(document);
        return resource.id;
    }
    async getDocument(containerName, documentId, partitionKey) {
        await this.initialize();
        const container = this.getContainer(containerName);
        try {
            const { resource } = await container.item(documentId, partitionKey).read();
            return resource || null;
        } catch (error) {
            if (error.code === 404) return null;
            throw error;
        }
    }
    async updateDocument(containerName, documentId, partitionKey, updates) {
        await this.initialize();
        const container = this.getContainer(containerName);
        const { resource: existing } = await container.item(documentId, partitionKey).read();
        if (!existing) throw new Error('Document not found');
        const updated = {
            ...existing,
            ...updates
        };
        await container.item(documentId, partitionKey).replace(updated);
    }
    async deleteDocument(containerName, documentId, partitionKey) {
        await this.initialize();
        const container = this.getContainer(containerName);
        try {
            await container.item(documentId, partitionKey).delete();
        } catch (error) {
            if (error.code !== 404) throw error;
        // Document already deleted, ignore 404
        }
    }
    // Batch operations for efficiency
    async batchCreate(containerName, documents) {
        await this.initialize();
        const container = this.getContainer(containerName);
        // Process in smaller batches to avoid limits
        const batchSize = 25;
        for(let i = 0; i < documents.length; i += batchSize){
            const batch = documents.slice(i, i + batchSize);
            await Promise.all(batch.map((doc)=>container.items.create(doc)));
        }
    }
    async batchDelete(containerName, documentIds) {
        await this.initialize();
        const container = this.getContainer(containerName);
        // Process in smaller batches
        const batchSize = 25;
        for(let i = 0; i < documentIds.length; i += batchSize){
            const batch = documentIds.slice(i, i + batchSize);
            await Promise.all(batch.map(({ id, partitionKey })=>container.item(id, partitionKey).delete().catch((err)=>{
                    if (err.code !== 404) throw err;
                // Ignore 404s for already deleted documents
                })));
        }
    }
    // Health check
    async healthCheck() {
        try {
            await this.initialize();
            const container = this.getContainer('users');
            // Simple read operation to test connectivity
            const querySpec = {
                query: 'SELECT VALUE COUNT(1) FROM c',
                parameters: []
            };
            await container.items.query(querySpec).fetchAll();
            return {
                status: 'healthy',
                timestamp: new Date()
            };
        } catch (error) {
            console.error('Azure Cosmos DB health check failed:', error);
            return {
                status: 'unhealthy',
                timestamp: new Date()
            };
        }
    }
}
// Export singleton instance
const azureCosmosService = new AzureCosmosService();
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (azureCosmosService)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 34000:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routeModule: () => (/* binding */ routeModule)
/* harmony export */ });
/* harmony import */ var next_dist_server_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(33480);
/* harmony import */ var next_dist_server_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8667);
/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(86435);
/* harmony import */ var private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(81031);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__]);
private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// Import the userland code.

// Re-export the handler (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .M)(private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__, 'default'));
// Re-export config.
const config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .M)(private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__, 'config');
// Create and export the route module that will be consumed.
const routeModule = new next_dist_server_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule({
    definition: {
        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .A.PAGES_API,
        page: "/api/feature-flags",
        pathname: "/api/feature-flags",
        // The following aren't used in production.
        bundlePath: '',
        filename: ''
    },
    userland: private_next_pages_api_feature_flags_ts__WEBPACK_IMPORTED_MODULE_3__
});

//# sourceMappingURL=pages-api.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 44337:
/***/ ((module) => {

module.exports = import("firebase/firestore");;

/***/ }),

/***/ 46602:
/***/ ((module) => {

module.exports = import("@azure/cosmos");;

/***/ }),

/***/ 52359:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Nv: () => (/* binding */ getCosmosDbConfig)
/* harmony export */ });
/* unused harmony exports environmentLoader, loadEnvironmentConfig, isCosmosDbEnabled, getEnvironmentName */
/* harmony import */ var _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(67327);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65044);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_0__]);
_lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/**
 * Environment Configuration Loader
 * 
 * Provides centralized environment variable management with hierarchical loading:
 * 1. Azure App Configuration (primary)
 * 2. Azure Key Vault (sensitive secrets)
 * 3. Environment variables (fallback for local dev)
 * 
 * Special handling for Cosmos DB connection strings and other sensitive data.
 */ 

// ===== CONFIGURATION LOADER =====
class EnvironmentConfigurationLoader {
    /**
   * Load environment configuration with hierarchy
   */ async load() {
        if (this.config && this.initialized) {
            return this.config;
        }
        try {
            console.log('🔧 Loading environment configuration...');
            // Load base environment settings
            const environment = this.getEnvironment();
            // Load Cosmos DB configuration
            const cosmosDb = await this.loadCosmosDbConfig();
            // Load Azure service configuration
            const azure = await this.loadAzureConfig();
            // Load Firebase configuration
            const firebase = await this.loadFirebaseConfig();
            // Load feature flags
            const features = await this.loadFeatureConfig();
            this.config = {
                environment,
                cosmosDb,
                azure,
                firebase,
                features
            };
            this.initialized = true;
            console.log(`✅ Environment configuration loaded for ${environment}`);
            return this.config;
        } catch (error) {
            console.error('❌ Failed to load environment configuration:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_1__/* .logServerError */ .wh)(error, {
                service: 'environment-loader',
                action: 'load'
            });
            // Return minimal fallback configuration
            return this.getFallbackConfig();
        }
    }
    /**
   * Load Cosmos DB configuration with hierarchy
   */ async loadCosmosDbConfig() {
        try {
            // Try unified config service first
            const [connectionString, maxRUPerSecond, batchSize, connectionTimeout, retryAttempts] = await Promise.all([
                this.getConfigValue('data.cosmos.connectionString', process.env.COSMOS_CONNECTION_STRING),
                this.getConfigValue('data.cosmos.maxRUPerSecond', 4000),
                this.getConfigValue('data.cosmos.batchSize', 100),
                this.getConfigValue('data.cosmos.connectionTimeout', 10000),
                this.getConfigValue('data.cosmos.retryAttempts', 3)
            ]);
            if (!connectionString) {
                throw new Error('Cosmos DB connection string is required');
            }
            return {
                connectionString,
                database: process.env.COSMOS_DATABASE || 'prepbettr',
                maxRUPerSecond: Number(maxRUPerSecond),
                batchSize: Number(batchSize),
                connectionTimeout: Number(connectionTimeout),
                retryAttempts: Number(retryAttempts)
            };
        } catch (error) {
            console.warn('⚠️ Failed to load Cosmos DB config from unified service, using environment fallback');
            return {
                connectionString: process.env.COSMOS_CONNECTION_STRING || '',
                database: process.env.COSMOS_DATABASE || 'prepbettr',
                maxRUPerSecond: Number(process.env.COSMOS_MAX_RU_PER_SECOND || 4000),
                batchSize: Number(process.env.COSMOS_BATCH_SIZE || 100),
                connectionTimeout: Number(process.env.COSMOS_CONNECTION_TIMEOUT || 10000),
                retryAttempts: Number(process.env.COSMOS_RETRY_ATTEMPTS || 3)
            };
        }
    }
    /**
   * Load Azure service configuration
   */ async loadAzureConfig() {
        return {
            appConfigConnectionString: process.env.AZURE_APP_CONFIG_CONNECTION_STRING,
            appConfigEndpoint: process.env.AZURE_APP_CONFIG_ENDPOINT,
            keyVaultUrl: process.env.AZURE_KEY_VAULT_URL
        };
    }
    /**
   * Load Firebase configuration
   */ async loadFirebaseConfig() {
        try {
            const [clientKey, adminKey] = await Promise.all([
                this.getConfigValue('auth.firebase.clientKey', "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8"),
                this.getConfigValue('auth.firebase.adminKey', process.env.FIREBASE_ADMIN_KEY)
            ]);
            return {
                clientKey,
                adminKey
            };
        } catch (error) {
            console.warn('⚠️ Failed to load Firebase config from unified service, using environment fallback');
            return {
                clientKey: "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8",
                adminKey: process.env.FIREBASE_ADMIN_KEY
            };
        }
    }
    /**
   * Load feature configuration
   */ async loadFeatureConfig() {
        try {
            const [enableCosmosDb, enableUnifiedConfig, enableKeyVault] = await Promise.all([
                this.getConfigValue('features.enableCosmosDb', true),
                this.getConfigValue('features.enableUnifiedConfig', true),
                this.getConfigValue('features.enableKeyVault', false)
            ]);
            return {
                enableCosmosDb: Boolean(enableCosmosDb),
                enableUnifiedConfig: Boolean(enableUnifiedConfig),
                enableKeyVault: Boolean(enableKeyVault)
            };
        } catch (error) {
            console.warn('⚠️ Failed to load feature config from unified service, using defaults');
            return {
                enableCosmosDb: "production" === 'production',
                enableUnifiedConfig: true,
                enableKeyVault: false
            };
        }
    }
    /**
   * Get configuration value with fallback hierarchy
   */ async getConfigValue(key, fallback) {
        try {
            // Try unified config service first
            const value = await _lib_services_unified_config_service__WEBPACK_IMPORTED_MODULE_0__/* .unifiedConfigService */ .Um.get(key, fallback);
            return value;
        } catch (error) {
            // Fall back to provided fallback value
            console.warn(`⚠️ Failed to get config ${key} from unified service:`, error);
            return fallback;
        }
    }
    /**
   * Determine current environment
   */ getEnvironment() {
        const env = "production" || 0;
        const vercelEnv = process.env.VERCEL_ENV;
        if (env === 'production') {
            return 'production';
        } else if (vercelEnv === 'preview' || process.env.APP_ENV === 'staging') {
            return 'staging';
        } else {
            return 'development';
        }
    }
    /**
   * Get fallback configuration when loading fails
   */ getFallbackConfig() {
        console.warn('⚠️ Using fallback environment configuration');
        return {
            environment: this.getEnvironment(),
            cosmosDb: {
                connectionString: process.env.COSMOS_CONNECTION_STRING || '',
                database: process.env.COSMOS_DATABASE || 'prepbettr',
                maxRUPerSecond: 4000,
                batchSize: 100,
                connectionTimeout: 10000,
                retryAttempts: 3
            },
            azure: {
                appConfigConnectionString: process.env.AZURE_APP_CONFIG_CONNECTION_STRING,
                appConfigEndpoint: process.env.AZURE_APP_CONFIG_ENDPOINT,
                keyVaultUrl: process.env.AZURE_KEY_VAULT_URL
            },
            firebase: {
                clientKey: "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8",
                adminKey: process.env.FIREBASE_ADMIN_KEY
            },
            features: {
                enableCosmosDb: "production" === 'production',
                enableUnifiedConfig: false,
                enableKeyVault: false
            }
        };
    }
    /**
   * Refresh configuration (useful for hot reloading in development)
   */ async refresh() {
        this.config = null;
        this.initialized = false;
        return await this.load();
    }
    /**
   * Get current configuration (throws if not loaded)
   */ getCurrentConfig() {
        if (!this.config) {
            throw new Error('Environment configuration not loaded. Call load() first.');
        }
        return this.config;
    }
    /**
   * Check if configuration is loaded
   */ isLoaded() {
        return this.initialized && this.config !== null;
    }
    /**
   * Export configuration for deployment scripts
   */ exportForDeployment() {
        const config = this.getCurrentConfig();
        return {
            NODE_ENV: config.environment,
            COSMOS_DATABASE: config.cosmosDb.database,
            COSMOS_MAX_RU_PER_SECOND: config.cosmosDb.maxRUPerSecond.toString(),
            COSMOS_BATCH_SIZE: config.cosmosDb.batchSize.toString(),
            COSMOS_CONNECTION_TIMEOUT: config.cosmosDb.connectionTimeout.toString(),
            COSMOS_RETRY_ATTEMPTS: config.cosmosDb.retryAttempts.toString(),
            // NOTE: Don't export connection strings or sensitive keys for security
            AZURE_APP_CONFIG_ENDPOINT: config.azure.appConfigEndpoint || '',
            AZURE_KEY_VAULT_URL: config.azure.keyVaultUrl || ''
        };
    }
    constructor(){
        this.config = null;
        this.initialized = false;
    }
}
// ===== SINGLETON INSTANCE =====
const environmentLoader = new EnvironmentConfigurationLoader();
// ===== CONVENIENCE FUNCTIONS =====
/**
 * Load environment configuration (idempotent)
 */ async function loadEnvironmentConfig() {
    return await environmentLoader.load();
}
/**
 * Get Cosmos DB configuration
 */ async function getCosmosDbConfig() {
    const config = await loadEnvironmentConfig();
    return config.cosmosDb;
}
/**
 * Check if Cosmos DB is enabled
 */ async function isCosmosDbEnabled() {
    try {
        const config = await loadEnvironmentConfig();
        return config.features.enableCosmosDb && !!config.cosmosDb.connectionString;
    } catch (error) {
        console.warn('Failed to check Cosmos DB status:', error);
        return false;
    }
}
/**
 * Get environment name
 */ async function getEnvironmentName() {
    const config = await loadEnvironmentConfig();
    return config.environment;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (environmentLoader)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 55511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 63033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 65044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   wh: () => (/* binding */ logServerError)
/* harmony export */ });
/* unused harmony exports createErrorResponse, createApiErrorResponse, isRetryableError, mapErrorToResponse, NETWORK_FAILURE_MESSAGE, getUserFriendlyErrorMessage */
// lib/errors.ts
/**
 * Creates a standardized error response
 */ function createErrorResponse(error, status) {
    return {
        error,
        status
    };
}
/**
 * Creates a NextResponse error for API routes
 */ function createApiErrorResponse(error, status) {
    // Import NextResponse dynamically to avoid module issues
    const { NextResponse } = __webpack_require__(80645);
    return NextResponse.json({
        error
    }, {
        status
    });
}
/**
 * Logs server errors with context but never exposes sensitive information
 */ function logServerError(error, context, additionalContext) {
    const errorMessage = error instanceof Error ? error.message : error;
    const errorStack = error instanceof Error ? error.stack : undefined;
    // Create safe logging context (no sensitive data)
    const safeContext = {
        timestamp: context.timestamp || new Date().toISOString(),
        url: context.url,
        method: context.method,
        userId: context.userId ? `user_${context.userId.slice(-8)}` : 'anonymous',
        userAgent: context.userAgent ? context.userAgent.slice(0, 100) : undefined,
        ip: context.ip ? context.ip.replace(/\d+$/, 'xxx') : undefined,
        ...additionalContext
    };
    console.error('Server Error:', {
        message: errorMessage,
        context: safeContext,
        stack: errorStack
    });
    // In production, you might want to send this to a logging service
    // like DataDog, Sentry, etc.
    if (true) {
    // Example: Send to external logging service
    // logger.error(errorMessage, safeContext);
    }
}
/**
 * Determines if an error should be retried
 */ function isRetryableError(status) {
    // Retry for 5xx errors and specific 4xx errors
    return status >= 500 || status === 408 || status === 429;
}
/**
 * Maps common error types to standard error responses
 */ function mapErrorToResponse(error) {
    // Network/Connection errors
    if (error.name === 'AbortError' || error.code === 'ECONNABORTED') {
        return createErrorResponse('Request timeout. Please try again.', 408);
    }
    if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
        return createErrorResponse('Network error. Please check your connection.', 503);
    }
    // Azure OpenAI specific errors
    if (error.status) {
        switch(error.status){
            case 401:
                return createErrorResponse('Service authentication failed. Please try again later.', 500);
            case 429:
                return createErrorResponse('Service temporarily unavailable due to high demand. Please try again later.', 429);
            case 400:
                return createErrorResponse('Invalid request format. Please check your input.', 400);
            default:
                if (error.status >= 500) {
                    return createErrorResponse('Service temporarily unavailable. Please try again later.', 500);
                }
        }
    }
    // Generic API errors
    if (error.message) {
        if (error.message.includes('API key') || error.message.includes('credentials')) {
            return createErrorResponse('Service configuration error. Please contact support.', 500);
        }
        if (error.message.includes('quota') || error.message.includes('limit') || error.message.includes('rate')) {
            return createErrorResponse('Service temporarily unavailable due to usage limits. Please try again later.', 429);
        }
        if (error.message.includes('not initialized')) {
            return createErrorResponse('Service is not properly configured. Please contact support.', 500);
        }
    }
    // Default error response
    return createErrorResponse('An unexpected error occurred. Please try again.', 500);
}
/**
 * Standard fallback message for network failures
 */ const NETWORK_FAILURE_MESSAGE = "Could not fetch job description from the provided URL.";
/**
 * Gets user-friendly error message for frontend display
 */ function getUserFriendlyErrorMessage(error, context) {
    if (error?.error) {
        return error.error;
    }
    if (context === 'url_extraction') {
        return NETWORK_FAILURE_MESSAGE;
    }
    if (error?.message) {
        // Don't expose internal error messages to users
        if (error.message.includes('API key') || error.message.includes('credentials') || error.message.includes('internal') || error.message.includes('database')) {
            return 'Service temporarily unavailable. Please try again later.';
        }
        return error.message;
    }
    return 'An unexpected error occurred. Please try again.';
}


/***/ }),

/***/ 65060:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   app: () => (/* binding */ app),
/* harmony export */   j2: () => (/* binding */ auth)
/* harmony export */ });
/* unused harmony exports db, googleProvider */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66551);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86958);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(44337);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Firebase Client Configuration
 * 
 * Real Firebase client implementation with configuration from Azure Key Vault
 */ 


// Get Firebase configuration from various sources
function getFirebaseConfig() {
    // Try to get from client-side environment variables first
    const clientApiKey = "AIzaSyAsTYUzEURUz1LaQWSwreqc7fnoN-WS0S8" || 0;
    const projectId = "prepbettr" || 0;
    // Try to get from window globals (set by server-side fetch)
    const windowApiKey =  false ? 0 : null;
    const windowProjectId =  false ? 0 : null;
    const windowAuthDomain =  false ? 0 : null;
    // Determine final values
    const finalApiKey = clientApiKey || windowApiKey || '';
    const finalProjectId = projectId || windowProjectId || 'prepbettr';
    const finalAuthDomain = windowAuthDomain || `${finalProjectId}.firebaseapp.com`;
    const config = {
        apiKey: finalApiKey,
        authDomain: finalAuthDomain,
        projectId: finalProjectId,
        storageBucket: "prepbettr.firebasestorage.app" || 0,
        messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
    };
    // Validate that we have the minimum required config
    if (!config.projectId) {
        console.error('Firebase configuration missing: projectId is required');
        return null;
    }
    console.log('🔥 Firebase config loaded:', {
        projectId: config.projectId,
        authDomain: config.authDomain,
        hasApiKey: !!config.apiKey,
        storageBucket: config.storageBucket,
        source: {
            apiKey: clientApiKey ? 'env' : windowApiKey ? 'server' : 'none',
            projectId: projectId ? 'env' : windowProjectId ? 'server' : 'fallback'
        }
    });
    return config;
}
// Initialize Firebase app
let app = null;
let auth = null;
let db = null;
let googleProvider = null;
function initializeFirebase() {
    // Only initialize on client side
    if (true) {
        console.log('🔥 Firebase initialization skipped on server side');
        return;
    }
    // Don't initialize if already done
    if (app) {
        return;
    }
    try {
        const firebaseConfig = getFirebaseConfig();
        if (!firebaseConfig) {
            console.error('🔥 Firebase initialization failed: missing configuration');
            return;
        }
        // Check if Firebase app is already initialized
        const existingApps = getApps();
        if (existingApps.length > 0) {
            app = existingApps[0];
            console.log('🔥 Using existing Firebase app');
        } else {
            // Initialize Firebase app
            app = initializeApp(firebaseConfig);
            console.log('🔥 Firebase app initialized successfully');
        }
        // Initialize Firebase services
        auth = getAuth(app);
        db = getFirestore(app);
        // Initialize Google Auth Provider
        googleProvider = new GoogleAuthProvider();
        googleProvider.setCustomParameters({
            prompt: 'select_account'
        });
        googleProvider.addScope('profile');
        googleProvider.addScope('email');
        console.log('🔥 Firebase services initialized:', {
            auth: !!auth,
            firestore: !!db,
            googleProvider: !!googleProvider
        });
    } catch (error) {
        console.error('🔥 Firebase initialization error:', error);
        // Create fallback mock objects to prevent errors
        auth = {
            currentUser: null,
            signOut: async ()=>{
                if (false) {}
            },
            onAuthStateChanged: (callback)=>{
                callback(null);
                return ()=>{};
            }
        };
        googleProvider = {
            setCustomParameters: ()=>{},
            addScope: ()=>{}
        };
    }
}
// Initialize Firebase when this module is loaded (client-side only)
if (false) {}
// Export Firebase services with null checks

// Export default for backward compatibility
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    auth,
    db,
    googleProvider,
    app
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 66551:
/***/ ((module) => {

module.exports = import("firebase/app");;

/***/ }),

/***/ 67327:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Um: () => (/* binding */ unifiedConfigService)
/* harmony export */ });
/* unused harmony exports CONFIG_SCHEMA, CONFIG_DEFAULTS, useUnifiedConfig */
/* harmony import */ var _azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16446);
/* harmony import */ var _azure_identity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10756);
/* harmony import */ var _lib_errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65044);
/* harmony import */ var _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(32096);
/* harmony import */ var _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14655);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__, _azure_identity__WEBPACK_IMPORTED_MODULE_1__, _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__, _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__]);
([_azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__, _azure_identity__WEBPACK_IMPORTED_MODULE_1__, _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__, _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * Unified Configuration Service
 * 
 * Eliminates configuration drift by providing a single source of truth
 * with Azure App Configuration as primary and Firebase Remote Config
 * for client-side distribution.
 * 
 * Key features:
 * - Single API for all configuration needs
 * - Automatic Azure → Firebase synchronization
 * - Two-layer caching with drift detection
 * - Version control and rollback capabilities
 * - Edge-runtime compatible for Next.js middleware
 */ 




// ===== CONFIGURATION SCHEMA =====
const CONFIG_SCHEMA = {
    // Core application settings
    'core.app.environment': {
        required: true,
        type: 'string',
        enum: [
            'development',
            'staging',
            'production'
        ]
    },
    'core.app.version': {
        required: true,
        type: 'string'
    },
    'core.app.debug': {
        required: false,
        type: 'boolean'
    },
    'core.app.maintenanceMode': {
        required: false,
        type: 'boolean'
    },
    // Feature flags (synced to Firebase for client access)
    'features.autoApplyAzure': {
        required: false,
        type: 'boolean'
    },
    'features.portalIntegration': {
        required: false,
        type: 'boolean'
    },
    'features.voiceInterview': {
        required: false,
        type: 'boolean'
    },
    'features.premiumFeatures': {
        required: false,
        type: 'boolean'
    },
    'features.newUI': {
        required: false,
        type: 'boolean'
    },
    // Cosmos DB configuration
    'data.cosmos.maxRUPerSecond': {
        required: false,
        type: 'number',
        min: 400,
        max: 100000
    },
    'data.cosmos.batchSize': {
        required: false,
        type: 'number',
        min: 10,
        max: 1000
    },
    'data.cosmos.connectionTimeout': {
        required: false,
        type: 'number',
        min: 1000,
        max: 30000
    },
    'data.cosmos.retryAttempts': {
        required: false,
        type: 'number',
        min: 1,
        max: 10
    },
    // Usage limits and quotas
    'quotas.freeInterviews': {
        required: false,
        type: 'number',
        min: 0,
        max: 100
    },
    'quotas.freeResumes': {
        required: false,
        type: 'number',
        min: 0,
        max: 50
    },
    'quotas.premiumInterviews': {
        required: false,
        type: 'number',
        min: 0,
        max: 10000
    },
    'quotas.premiumResumes': {
        required: false,
        type: 'number',
        min: 0,
        max: 1000
    },
    // Authentication settings (Firebase client-side)
    'auth.firebase.sessionTimeout': {
        required: false,
        type: 'number',
        min: 300,
        max: 86400
    },
    'auth.firebase.maxAttempts': {
        required: false,
        type: 'number',
        min: 3,
        max: 10
    },
    'auth.firebase.lockoutDuration': {
        required: false,
        type: 'number',
        min: 300,
        max: 3600
    },
    // Performance and monitoring
    'perf.cacheTimeout': {
        required: false,
        type: 'number',
        min: 30,
        max: 3600
    },
    'perf.maxCacheSize': {
        required: false,
        type: 'number',
        min: 100,
        max: 10000
    },
    'perf.enableMetrics': {
        required: false,
        type: 'boolean'
    }
};
// Default values with metadata
const CONFIG_DEFAULTS = {
    'core.app.environment': {
        value: 'development',
        type: 'string',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: ''
        }
    },
    'core.app.debug': {
        value: false,
        type: 'boolean',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: ''
        }
    },
    'features.autoApplyAzure': {
        value: false,
        type: 'boolean',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: '',
            syncToFirebase: true
        }
    },
    'features.voiceInterview': {
        value: true,
        type: 'boolean',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: '',
            syncToFirebase: true
        }
    },
    'quotas.freeInterviews': {
        value: 3,
        type: 'number',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: ''
        }
    },
    'quotas.freeResumes': {
        value: 2,
        type: 'number',
        metadata: {
            source: 'azure',
            version: '1.0.0',
            lastModified: new Date(),
            hash: ''
        }
    }
};
// ===== UNIFIED CONFIGURATION SERVICE =====
class UnifiedConfigService {
    constructor(){
        this.azureClient = null;
        this.cache = new Map();
        this.initialized = false;
        this.driftCache = new Map();
        this.CACHE_TTL = 5 * 60 * 1000 // 5 minutes
        ;
        this.DRIFT_CHECK_INTERVAL = 10 * 60 * 1000 // 10 minutes
        ;
        this.setupDriftDetection();
    }
    // ===== INITIALIZATION =====
    async initialize() {
        if (this.initialized) return;
        try {
            const connectionString = process.env.AZURE_APP_CONFIG_CONNECTION_STRING;
            const endpoint = process.env.AZURE_APP_CONFIG_ENDPOINT;
            if (connectionString) {
                this.azureClient = new _azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__.AppConfigurationClient(connectionString);
            } else if (endpoint) {
                const credential = new _azure_identity__WEBPACK_IMPORTED_MODULE_1__.DefaultAzureCredential();
                this.azureClient = new _azure_app_configuration__WEBPACK_IMPORTED_MODULE_0__.AppConfigurationClient(endpoint, credential);
            } else {
                console.warn('⚠️ Azure App Configuration not configured - using defaults only');
                this.initialized = true;
                return;
            }
            // Test connection
            const iterator = this.azureClient.listConfigurationSettings();
            await iterator.next(); // Just get the first result to test connection
            this.initialized = true;
            console.log('✅ Unified Configuration Service initialized');
        } catch (error) {
            console.error('❌ Failed to initialize Unified Config Service:', error);
            (0,_lib_errors__WEBPACK_IMPORTED_MODULE_2__/* .logServerError */ .wh)(error, {
                service: 'unified-config',
                action: 'initialize'
            });
            // Continue with defaults only
            this.initialized = true;
        }
    }
    // ===== CORE CONFIGURATION METHODS =====
    /**
   * Get configuration value with intelligent fallback
   */ async get(key, defaultValue) {
        const startTime = Date.now();
        let success = true;
        await this.initialize();
        try {
            // Check cache first
            const cached = this.getCachedValue(key);
            if (cached) {
                _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackCacheHit(true, key);
                const latency = Date.now() - startTime;
                _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, true);
                return cached.value;
            }
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackCacheHit(false, key);
            // Try Azure App Configuration first
            const azureValue = await this.getFromAzure(key);
            if (azureValue !== null) {
                const latency = Date.now() - startTime;
                _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, true);
                return azureValue;
            }
            // Check if it's a client-only config that should come from Firebase
            const schema = CONFIG_SCHEMA[key];
            const defaultConfig = CONFIG_DEFAULTS[key];
            if (defaultConfig?.metadata?.clientOnly) {
                const firebaseValue = await this.getFromFirebase(key);
                if (firebaseValue !== null) {
                    const latency = Date.now() - startTime;
                    _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, true);
                    return firebaseValue;
                }
            }
            // Return default value or schema default
            const result = defaultValue !== undefined ? defaultValue : defaultConfig ? defaultConfig.value : undefined;
            const latency = Date.now() - startTime;
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, true);
            return result;
        } catch (error) {
            success = false;
            console.error(`Error getting config ${key}:`, error);
            const latency = Date.now() - startTime;
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'get', latency, false);
            return defaultValue;
        }
    }
    /**
   * Set configuration value with validation and audit
   */ async set(key, value, options) {
        const startTime = Date.now();
        let success = true;
        await this.initialize();
        const { environment = 'default', syncToFirebase = false, version = '1.0.0', changedBy = 'system' } = options || {};
        try {
            // Validate against schema
            this.validateConfigValue(key, value);
            // Get previous value for audit
            const previousValue = await this.get(key);
            // Create config value with metadata
            const configValue = {
                value,
                type: this.inferType(value),
                metadata: {
                    source: 'azure',
                    version,
                    lastModified: new Date(),
                    hash: this.calculateHash(value),
                    syncToFirebase
                }
            };
            // Store in Azure App Configuration
            if (this.azureClient) {
                await this.setInAzure(key, configValue, environment);
            }
            // Sync to Firebase if requested
            if (syncToFirebase) {
                await this.syncToFirebase(key, configValue);
            }
            // Clear cache
            this.cache.delete(key);
            // Record audit entry
            await this.recordAuditEntry({
                id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                key,
                oldValue: previousValue,
                newValue: value,
                version,
                source: 'unified',
                changedBy,
                timestamp: new Date(),
                rollbackable: true,
                metadata: {
                    environment,
                    syncToFirebase
                }
            });
            // Track configuration change
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigChange(key, previousValue, value, changedBy, environment);
            const latency = Date.now() - startTime;
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'set', latency, true);
            console.log(`✅ Config updated: ${key} = ${JSON.stringify(value)}`);
        } catch (error) {
            success = false;
            const latency = Date.now() - startTime;
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackConfigRequest(key, 'set', latency, false);
            console.error(`❌ Failed to set config ${key}:`, error);
            throw error;
        }
    }
    /**
   * Get all configuration values with optional prefix filter
   */ async getAll(prefix) {
        await this.initialize();
        const result = {};
        try {
            // Get from Azure App Configuration
            if (this.azureClient) {
                const settings = this.azureClient.listConfigurationSettings({
                    keyFilter: prefix ? `${prefix}*` : undefined
                });
                for await (const setting of settings){
                    if (setting.key && setting.value !== undefined) {
                        const parsedValue = this.parseConfigurationSetting(setting);
                        result[setting.key] = parsedValue.value;
                        // Cache the value
                        this.setCachedValue(setting.key, parsedValue, setting.etag);
                    }
                }
            }
            // Add defaults for missing keys
            Object.entries(CONFIG_DEFAULTS).forEach(([key, defaultConfig])=>{
                if (!prefix || key.startsWith(prefix)) {
                    if (result[key] === undefined) {
                        result[key] = defaultConfig.value;
                    }
                }
            });
            return result;
        } catch (error) {
            console.error('Error getting all configs:', error);
            // Return defaults only on error
            const defaults = {};
            Object.entries(CONFIG_DEFAULTS).forEach(([key, defaultConfig])=>{
                if (!prefix || key.startsWith(prefix)) {
                    defaults[key] = defaultConfig.value;
                }
            });
            return defaults;
        }
    }
    /**
   * Refresh cache and check for drift
   */ async refresh() {
        this.cache.clear();
        this.driftCache.clear();
        await this.checkForDrift();
    }
    /**
   * Subscribe to configuration changes (polling-based)
   */ subscribe(key, callback) {
        let lastValue = undefined;
        let isActive = true;
        const poll = async ()=>{
            if (!isActive) return;
            try {
                const currentValue = await this.get(key);
                if (JSON.stringify(currentValue) !== JSON.stringify(lastValue)) {
                    lastValue = currentValue;
                    callback(currentValue);
                }
            } catch (error) {
                console.error(`Config subscription error for ${key}:`, error);
            }
        };
        // Poll every 30 seconds
        const interval = setInterval(poll, 30000);
        // Initial call
        poll();
        return ()=>{
            isActive = false;
            clearInterval(interval);
        };
    }
    // ===== DRIFT DETECTION =====
    async checkForDrift() {
        const driftResults = [];
        try {
            // Get all configs that should sync to Firebase
            const allConfigs = await this.getAll();
            const syncableKeys = Object.keys(allConfigs).filter((key)=>{
                const defaultConfig = CONFIG_DEFAULTS[key];
                return defaultConfig?.metadata?.syncToFirebase;
            });
            for (const key of syncableKeys){
                const drift = await this.checkKeyForDrift(key);
                if (drift) {
                    driftResults.push(drift);
                    this.driftCache.set(key, drift);
                }
            }
            // Track drift detection metrics
            const driftedKeys = driftResults.filter((d)=>d.drifted).map((d)=>d.key);
            _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.trackDriftDetection(driftedKeys, syncableKeys.length);
            if (driftResults.length > 0) {
                console.warn(`⚠️ Configuration drift detected in ${driftResults.length} keys`);
                // Record drift event for monitoring
                await this.recordDriftEvent(driftResults);
            }
            return driftResults;
        } catch (error) {
            console.error('Error checking for drift:', error);
            return [];
        }
    }
    async checkKeyForDrift(key) {
        try {
            const [azureValue, firebaseValue] = await Promise.all([
                this.getFromAzure(key),
                this.getFromFirebase(key)
            ]);
            if (azureValue === null && firebaseValue === null) {
                return null; // Both missing, no drift
            }
            const azureHash = this.calculateHash(azureValue);
            const firebaseHash = this.calculateHash(firebaseValue);
            const drifted = azureHash !== firebaseHash;
            return {
                key,
                azureValue,
                firebaseValue,
                azureHash,
                firebaseHash,
                drifted,
                lastChecked: new Date()
            };
        } catch (error) {
            console.error(`Error checking drift for ${key}:`, error);
            return null;
        }
    }
    // ===== ROLLBACK FUNCTIONALITY =====
    async revert(versionId) {
        try {
            // Get audit entry
            const auditEntry = await this.getAuditEntry(versionId);
            if (!auditEntry || !auditEntry.rollbackable) {
                throw new Error(`Version ${versionId} not found or not rollbackable`);
            }
            // Restore previous value
            await this.set(auditEntry.key, auditEntry.oldValue, {
                version: `rollback_${versionId}`,
                changedBy: 'rollback-system',
                syncToFirebase: auditEntry.metadata?.syncToFirebase
            });
            console.log(`✅ Successfully reverted ${auditEntry.key} to version ${versionId}`);
        } catch (error) {
            console.error(`❌ Failed to revert to version ${versionId}:`, error);
            throw error;
        }
    }
    // ===== PRIVATE HELPER METHODS =====
    async getFromAzure(key) {
        if (!this.azureClient) return null;
        try {
            const setting = await this.azureClient.getConfigurationSetting({
                key
            });
            if (!setting || setting.value === undefined) {
                return null;
            }
            const parsedValue = this.parseConfigurationSetting(setting);
            this.setCachedValue(key, parsedValue, setting.etag);
            return parsedValue.value;
        } catch (error) {
            if (error.statusCode === 404) {
                return null;
            }
            throw error;
        }
    }
    async getFromFirebase(key) {
        try {
            // Import Firebase Remote Config dynamically
            const { getRemoteConfig, getValue } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 97747));
            const { app } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 65060));
            if (!app) {
                console.warn('Firebase app not available');
                return null;
            }
            const remoteConfig = getRemoteConfig(app);
            const value = getValue(remoteConfig, key);
            return value.asString();
        } catch (error) {
            console.warn(`Failed to get Firebase Remote Config for ${key}:`, error);
            return null;
        }
    }
    async setInAzure(key, configValue, environment) {
        if (!this.azureClient) return;
        const setting = {
            key: environment === 'default' ? key : `${key}__${environment}`,
            value: this.serializeValue(configValue.value),
            contentType: this.getContentType(configValue.value),
            isReadOnly: false,
            tags: {
                environment,
                version: configValue.metadata?.version || '1.0.0',
                source: 'unified-service',
                lastModified: new Date().toISOString(),
                hash: configValue.metadata?.hash || '',
                syncToFirebase: configValue.metadata?.syncToFirebase ? 'true' : 'false'
            }
        };
        await this.azureClient.setConfigurationSetting(setting);
    }
    async syncToFirebase(key, configValue) {
        // This will be implemented by the config-sync Azure Function
        // For now, we'll queue the sync request
        console.log(`🔄 Queuing Firebase sync for ${key}`);
    // Could implement immediate sync here if needed
    // For production, better to use the dedicated sync function
    }
    parseConfigurationSetting(setting) {
        const value = this.parseValue(setting.value || '', setting.contentType);
        return {
            value,
            type: this.inferType(value),
            metadata: {
                source: 'azure',
                version: setting.tags?.version || '1.0.0',
                lastModified: new Date(setting.tags?.lastModified || new Date()),
                hash: setting.tags?.hash || this.calculateHash(value),
                syncToFirebase: setting.tags?.syncToFirebase === 'true'
            }
        };
    }
    parseValue(value, contentType) {
        if (!contentType) {
            // Try to infer type
            if (value === 'true' || value === 'false') {
                return value === 'true';
            }
            const numberValue = Number(value);
            if (!isNaN(numberValue)) {
                return numberValue;
            }
            try {
                return JSON.parse(value);
            } catch  {
                return value;
            }
        }
        switch(contentType){
            case 'application/json':
                return JSON.parse(value);
            case 'text/plain':
            default:
                return value;
        }
    }
    serializeValue(value) {
        if (typeof value === 'string') {
            return value;
        }
        if (typeof value === 'number' || typeof value === 'boolean') {
            return value.toString();
        }
        return JSON.stringify(value);
    }
    getContentType(value) {
        if (typeof value === 'object') {
            return 'application/json';
        }
        return 'text/plain';
    }
    inferType(value) {
        if (Array.isArray(value)) return 'array';
        if (typeof value === 'object') return 'object';
        if (typeof value === 'boolean') return 'boolean';
        if (typeof value === 'number') return 'number';
        return 'string';
    }
    validateConfigValue(key, value) {
        const rule = CONFIG_SCHEMA[key];
        if (!rule) return; // No validation rule, allow any value
        // Type validation
        const actualType = this.inferType(value);
        if (rule.type !== actualType) {
            throw new Error(`Config ${key}: expected type ${rule.type}, got ${actualType}`);
        }
        // Enum validation
        if (rule.enum && !rule.enum.includes(value)) {
            throw new Error(`Config ${key}: value must be one of ${rule.enum.join(', ')}`);
        }
        // Range validation for numbers
        if (rule.type === 'number') {
            if (rule.min !== undefined && value < rule.min) {
                throw new Error(`Config ${key}: value ${value} is below minimum ${rule.min}`);
            }
            if (rule.max !== undefined && value > rule.max) {
                throw new Error(`Config ${key}: value ${value} is above maximum ${rule.max}`);
            }
        }
        // Pattern validation for strings
        if (rule.type === 'string' && rule.pattern && !rule.pattern.test(value)) {
            throw new Error(`Config ${key}: value does not match required pattern`);
        }
    }
    calculateHash(value) {
        const crypto = __webpack_require__(55511);
        const normalized = JSON.stringify(value, Object.keys(value || {}).sort());
        return crypto.createHash('sha256').update(normalized).digest('hex').substring(0, 16);
    }
    getCachedValue(key) {
        const cached = this.cache.get(key);
        if (!cached) return null;
        const isExpired = Date.now() - cached.timestamp > this.CACHE_TTL;
        if (isExpired) {
            this.cache.delete(key);
            return null;
        }
        return cached.value;
    }
    setCachedValue(key, value, etag) {
        this.cache.set(key, {
            value,
            timestamp: Date.now(),
            etag
        });
    }
    setupDriftDetection() {
        // Check for drift every 10 minutes
        setInterval(async ()=>{
            await this.checkForDrift();
        }, this.DRIFT_CHECK_INTERVAL);
    }
    async recordAuditEntry(entry) {
        try {
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.initialize();
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.createDocument('configAudit', {
                ...entry,
                _partitionKey: entry.key
            });
        } catch (error) {
            console.error('Failed to record config audit entry:', error);
        }
    }
    async getAuditEntry(versionId) {
        try {
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.initialize();
            const result = await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.queryDocuments('configAudit', 'SELECT * FROM c WHERE c.version = @versionId', [
                {
                    name: '@versionId',
                    value: versionId
                }
            ]);
            return result[0] || null;
        } catch (error) {
            console.error('Failed to get audit entry:', error);
            return null;
        }
    }
    async recordDriftEvent(driftResults) {
        try {
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.initialize();
            await _azure_cosmos_service__WEBPACK_IMPORTED_MODULE_3__/* .azureCosmosService */ .h.createDocument('configDrift', {
                id: `drift_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                timestamp: new Date(),
                driftCount: driftResults.length,
                keys: driftResults.map((d)=>d.key),
                details: driftResults,
                _partitionKey: 'drift-detection'
            });
        } catch (error) {
            console.error('Failed to record drift event:', error);
        }
    }
    // ===== HEALTH CHECK =====
    async healthCheck() {
        try {
            await this.initialize();
            if (!this.azureClient) {
                return {
                    healthy: false,
                    message: 'Azure App Configuration not available - using defaults only'
                };
            }
            // Test connectivity
            const testIterator = this.azureClient.listConfigurationSettings();
            await testIterator.next(); // Just test the connection
            const driftCount = Array.from(this.driftCache.values()).filter((d)=>d.drifted).length;
            // Get comprehensive health check from monitoring service
            const monitoringHealth = await _config_monitoring_service__WEBPACK_IMPORTED_MODULE_4__/* .configMonitoringService */ .G.healthCheck();
            return {
                healthy: monitoringHealth.status === 'healthy',
                message: monitoringHealth.status !== 'healthy' ? `Service status: ${monitoringHealth.status}` : undefined,
                details: {
                    cacheSize: this.cache.size,
                    driftDetected: driftCount,
                    lastRefresh: new Date(),
                    monitoring: monitoringHealth
                }
            };
        } catch (error) {
            return {
                healthy: false,
                message: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
}
// ===== SINGLETON INSTANCE =====
const unifiedConfigService = new UnifiedConfigService();
// ===== REACT HOOK =====
// Note: This hook should be used in client-side components only
// The actual implementation will be moved to a separate file to avoid
// bundling React in server-side code
function useUnifiedConfig(key, defaultValue) {
    // This is a placeholder implementation that will be overridden
    // in client-side usage. See /lib/hooks/useUnifiedConfig.ts
    console.warn('useUnifiedConfig called from server context. Use the client-side hook instead.');
    return {
        value: defaultValue,
        loading: false,
        error: null
    };
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (unifiedConfigService)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 75600:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.prod.js");

/***/ }),

/***/ 81031:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7028);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__]);
_lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/**
 * API endpoint for feature flags - provides client-safe access to feature flags
 * without bundling server-only modules for the client
 */ async function handler(req, res) {
    if (req.method !== 'GET') {
        return res.status(405).json({
            error: 'Method not allowed'
        });
    }
    try {
        // Optional: Verify authentication if needed
        // const authResult = await verifyAuthHeader(req.headers.authorization);
        // if (!authResult.success) {
        //   return res.status(401).json({ error: 'Unauthorized' });
        // }
        const refreshFlags = req.query.refresh === 'true';
        // Get feature flags from the service
        const flags = refreshFlags ? await _lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__/* .featureFlagsService */ .$.refreshFeatureFlags() : await _lib_services_feature_flags__WEBPACK_IMPORTED_MODULE_0__/* .featureFlagsService */ .$.getAllFeatureFlags();
        return res.status(200).json(flags);
    } catch (error) {
        console.error('Error fetching feature flags:', error);
        // Return default flags on error
        return res.status(200).json({
            autoApplyAzure: false,
            portalIntegration: false,
            voiceInterview: false,
            premiumFeatures: false,
            newUI: false,
            rolloutStatus: {
                autoApplyAzure: false,
                portalIntegration: false,
                voiceInterview: false,
                premiumFeatures: false,
                newUI: false
            }
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 82015:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 86958:
/***/ ((module) => {

module.exports = import("firebase/auth");;

/***/ }),

/***/ 97747:
/***/ ((module) => {

module.exports = import("firebase/remote-config");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7866], () => (__webpack_exec__(34000)));
module.exports = __webpack_exports__;

})();