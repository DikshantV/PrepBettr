# DevOps Team - Security Action Items
**PrepBettr Platform Infrastructure Security**  
**Azure Key Vault & Secrets Management**

---

## 🚨 IMMEDIATE ACTIONS (0-72 hours)

### Action #1: Emergency Key Rotation
**Priority:** P0 - Critical  
**Estimated Effort:** 4-6 hours  
**Owner:** DevOps Lead

**Keys to Rotate Immediately:**
```bash
# High-risk keys identified in audit
- AZURE_OPENAI_API_KEY (potentially exposed in docs)
- FIREBASE_ADMIN_PRIVATE_KEY (if compromised)
- DODO_PAYMENTS_API_KEY (for license validation)
- SPEECH_API_KEY (Azure Cognitive Services)
```

**Rotation Process:**

1. **Azure Key Vault Secret Rotation:**
```bash
# Create new versions of compromised secrets
az keyvault secret set --vault-name "prepbettr-prod-kv" \
  --name "azure-openai-api-key" \
  --value "$NEW_OPENAI_KEY" \
  --tags "rotated-date=$(date +%Y-%m-%d)" "rotation-reason=security-audit"

az keyvault secret set --vault-name "prepbettr-prod-kv" \
  --name "dodo-payments-api-key" \
  --value "$NEW_DODO_KEY" \
  --tags "rotated-date=$(date +%Y-%m-%d)" "rotation-reason=security-audit"
```

2. **Update Application References:**
```bash
# Update Azure Function App Settings
az functionapp config appsettings set \
  --name "prepbettr-functions" \
  --resource-group "prepbettr-prod-rg" \
  --settings "AZURE_OPENAI_API_KEY=@Microsoft.KeyVault(SecretUri=https://prepbettr-prod-kv.vault.azure.net/secrets/azure-openai-api-key/)"

# Update Next.js App Service
az webapp config appsettings set \
  --name "prepbettr-webapp" \
  --resource-group "prepbettr-prod-rg" \
  --settings "DODO_PAYMENTS_API_KEY=@Microsoft.KeyVault(SecretUri=https://prepbettr-prod-kv.vault.azure.net/secrets/dodo-payments-api-key/)"
```

3. **Verify Rotation Success:**
```bash
# Test applications with new keys
curl -H "Authorization: Bearer $NEW_OPENAI_KEY" \
  "https://your-azure-openai.openai.azure.com/openai/deployments/gpt-4/chat/completions" \
  -d '{"messages":[{"role":"user","content":"test"}],"max_tokens":1}'

# Monitor application logs for authentication errors
az monitor activity-log list --resource-group prepbettr-prod-rg --max-events 50
```

**Verification Checklist:**
- [ ] All services start successfully with new keys
- [ ] No authentication errors in application logs
- [ ] Old keys disabled/deleted from Key Vault
- [ ] Dependent services (OpenAI, Dodo Payments) confirmed working

---

### Action #2: Azure Key Vault Policy Hardening
**Priority:** P0 - Critical  
**Estimated Effort:** 2-3 hours  
**Owner:** Security Engineer + DevOps

**Current Issues Identified:**
- Overly permissive access policies
- Missing audit logging configuration
- No network restrictions
- Insufficient backup policies

**Implementation:**

1. **Review Current Access Policies:**
```bash
# Audit current policies
az keyvault show --name "prepbettr-prod-kv" --resource-group "prepbettr-prod-rg" --query "properties.accessPolicies"

# List all secret permissions
az keyvault secret list --vault-name "prepbettr-prod-kv" --query "[].{Name:name,Enabled:attributes.enabled}"
```

2. **Implement Least-Privilege Access:**
```bash
# Remove excessive permissions from existing policies
az keyvault delete-policy \
  --name "prepbettr-prod-kv" \
  --object-id "<user-or-service-principal-id>" \
  --resource-group "prepbettr-prod-rg"

# Add restricted policies for applications
az keyvault set-policy \
  --name "prepbettr-prod-kv" \
  --object-id "$(az webapp identity show --name prepbettr-webapp --resource-group prepbettr-prod-rg --query principalId -o tsv)" \
  --secret-permissions get list \
  --resource-group "prepbettr-prod-rg"

# Add restricted policies for Azure Functions
az keyvault set-policy \
  --name "prepbettr-prod-kv" \
  --object-id "$(az functionapp identity show --name prepbettr-functions --resource-group prepbettr-prod-rg --query principalId -o tsv)" \
  --secret-permissions get list \
  --resource-group "prepbettr-prod-rg"
```

3. **Enable Advanced Security Features:**
```bash
# Enable purge protection (prevents accidental deletion)
az keyvault update \
  --name "prepbettr-prod-kv" \
  --resource-group "prepbettr-prod-rg" \
  --enable-purge-protection true

# Enable soft delete (allows recovery of deleted secrets)
az keyvault update \
  --name "prepbettr-prod-kv" \
  --resource-group "prepbettr-prod-rg" \
  --enable-soft-delete true \
  --retention-days 90

# Enable audit logging
az monitor diagnostic-settings create \
  --resource "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/prepbettr-prod-rg/providers/Microsoft.KeyVault/vaults/prepbettr-prod-kv" \
  --name "KeyVaultAuditLogs" \
  --workspace "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/prepbettr-prod-rg/providers/Microsoft.OperationalInsights/workspaces/prepbettr-logs" \
  --logs '[{"category":"AuditEvent","enabled":true,"retentionPolicy":{"enabled":true,"days":365}}]'
```

4. **Implement Network Access Restrictions:**
```bash
# Configure firewall rules (adjust IPs for your infrastructure)
az keyvault network-rule add \
  --name "prepbettr-prod-kv" \
  --resource-group "prepbettr-prod-rg" \
  --ip-address "20.42.128.0/24"  # Azure App Service IPs

az keyvault network-rule add \
  --name "prepbettr-prod-kv" \
  --resource-group "prepbettr-prod-rg" \
  --subnet "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/prepbettr-prod-rg/providers/Microsoft.Network/virtualNetworks/prepbettr-vnet/subnets/app-subnet"

# Enable firewall
az keyvault update \
  --name "prepbettr-prod-kv" \
  --resource-group "prepbettr-prod-rg" \
  --default-action Deny
```

---

## 🔥 HIGH PRIORITY (1-7 days)

### Action #3: Automated Secrets Rotation
**Priority:** P1 - High  
**Estimated Effort:** 2-3 days  
**Owner:** DevOps Engineer

**Create Rotation Automation:**

1. **Azure Function for Automated Rotation:**
```typescript
// azure/secretRotationFunction/index.ts
import { AzureFunction, Context, Timer } from "@azure/functions";
import { SecretClient } from "@azure/keyvault-secrets";
import { DefaultAzureCredential } from "@azure/identity";

const timerTrigger: AzureFunction = async function (context: Context, myTimer: Timer): Promise<void> {
    const credential = new DefaultAzureCredential();
    const vaultUrl = "https://prepbettr-prod-kv.vault.azure.net/";
    const secretClient = new SecretClient(vaultUrl, credential);

    try {
        // Check secrets that need rotation (older than 90 days)
        const secretsToRotate = await getSecretsNeedingRotation(secretClient);
        
        for (const secretName of secretsToRotate) {
            await rotateSecret(secretClient, secretName);
            context.log(`Successfully rotated secret: ${secretName}`);
        }

        // Send notification if any secrets were rotated
        if (secretsToRotate.length > 0) {
            await sendRotationNotification(secretsToRotate);
        }

    } catch (error) {
        context.log.error(`Secret rotation failed: ${error.message}`);
        await sendFailureAlert(error.message);
        throw error;
    }
};

async function rotateSecret(client: SecretClient, secretName: string): Promise<void> {
    const currentSecret = await client.getSecret(secretName);
    let newSecretValue: string;

    switch (secretName) {
        case 'firebase-admin-private-key':
            newSecretValue = await rotateFirebaseKey();
            break;
        case 'encryption-key':
            newSecretValue = await generateNewEncryptionKey();
            break;
        case 'anonymization-key':
            newSecretValue = await generateNewAnonymizationKey();
            break;
        default:
            throw new Error(`No rotation logic for secret: ${secretName}`);
    }

    // Create new version of secret
    await client.setSecret(secretName, newSecretValue, {
        tags: {
            'rotated-date': new Date().toISOString(),
            'rotation-type': 'automated',
            'previous-version': currentSecret.properties.version || 'unknown'
        }
    });

    // Update applications with new secret (gradual rollout)
    await updateApplicationsWithNewSecret(secretName, newSecretValue);
}

export default timerTrigger;
```

2. **Create Rotation Policies:**
```json
{
  "rotation-policy": {
    "high-risk-secrets": {
      "rotation-interval": "30-days",
      "secrets": ["api-keys", "database-passwords", "encryption-keys"]
    },
    "medium-risk-secrets": {
      "rotation-interval": "90-days", 
      "secrets": ["service-tokens", "webhook-secrets"]
    },
    "low-risk-secrets": {
      "rotation-interval": "365-days",
      "secrets": ["configuration-secrets", "feature-flags"]
    }
  }
}
```

3. **Deploy Rotation Function:**
```bash
# Deploy secret rotation function
az functionapp deployment source config \
  --name "prepbettr-secret-rotation" \
  --resource-group "prepbettr-prod-rg" \
  --repo-url "https://github.com/your-org/prepbettr-secret-rotation" \
  --branch "main"

# Set up timer trigger (run weekly)
az functionapp function create \
  --name "prepbettr-secret-rotation" \
  --resource-group "prepbettr-prod-rg" \
  --function-name "RotateSecrets" \
  --trigger-type "TimerTrigger" \
  --schedule "0 0 2 * * 0"  # Every Sunday at 2 AM
```

---

### Action #4: Infrastructure Secrets Scanning
**Priority:** P1 - High  
**Estimated Effort:** 1-2 days  
**Owner:** Security Engineer

**Implement Continuous Scanning:**

1. **Azure DevOps Pipeline Integration:**
```yaml
# azure-pipelines-security.yml
trigger:
- main
- develop

stages:
- stage: SecurityScanning
  jobs:
  - job: SecretScanning
    pool:
      vmImage: 'ubuntu-latest'
    steps:
    - task: UsePythonVersion@0
      inputs:
        versionSpec: '3.9'
    
    - script: |
        pip install truffleHog detect-secrets gitpython
        # Run enhanced secret scanner
        python $(System.DefaultWorkingDirectory)/secret-scanner-enhanced.py
        
        # Check for new secrets
        if [ -f "hardcoded-secrets-enhanced.json" ]; then
          NEW_SECRETS=$(jq '.[] | select(.category == "PRODUCTION") | length' hardcoded-secrets-enhanced.json)
          if [ "$NEW_SECRETS" -gt 0 ]; then
            echo "##vso[task.logissue type=error]New production secrets detected!"
            exit 1
          fi
        fi
      displayName: 'Scan for hardcoded secrets'

    - script: |
        # Scan infrastructure as code
        docker run --rm -v $(pwd):/data bridgecrew/checkov -d /data --framework terraform azure_pipelines --output json --output-file-path /data/checkov-results.json
      displayName: 'Scan Infrastructure as Code'

    - task: PublishTestResults@2
      inputs:
        testResultsFiles: '**/checkov-results.json'
        testRunTitle: 'Security Scan Results'
```

2. **GitHub Actions Integration:**
```yaml
# .github/workflows/security-scan.yml
name: Security Scanning

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]
  schedule:
    - cron: '0 2 * * *'  # Daily at 2 AM

jobs:
  secret-scan:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
      with:
        fetch-depth: 0  # Need full history for secret scanning
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: 3.9

    - name: Install dependencies
      run: |
        pip install -r requirements-security.txt

    - name: Run Enhanced Secret Scanner
      run: |
        python secret-scanner-enhanced.py
        
        # Check results
        if [ -f "hardcoded-secrets-enhanced.json" ]; then
          CRITICAL_SECRETS=$(jq '[.[] | select(.category == "PRODUCTION")] | length' hardcoded-secrets-enhanced.json)
          echo "Critical secrets found: $CRITICAL_SECRETS"
          
          if [ "$CRITICAL_SECRETS" -gt 0 ]; then
            echo "❌ Critical secrets detected in code!"
            jq '.[] | select(.category == "PRODUCTION") | {file: .file, line: .line, pattern: .pattern}' hardcoded-secrets-enhanced.json
            exit 1
          else
            echo "✅ No critical secrets found"
          fi
        fi

    - name: Upload Scan Results
      uses: actions/upload-artifact@v3
      if: always()
      with:
        name: security-scan-results
        path: |
          hardcoded-secrets-enhanced.json
          hardcoded-secrets-enhanced.csv
```

---

### Action #5: Monitoring & Alerting Enhancement
**Priority:** P1 - High  
**Estimated Effort:** 1-2 days  
**Owner:** DevOps + Monitoring Engineer

**Implement Advanced Security Monitoring:**

1. **Azure Monitor Security Alerts:**
```json
{
  "securityAlerts": {
    "keyVaultAccess": {
      "query": "KeyVaultData | where OperationName contains 'SecretGet' | where ResultType != 'Success' | summarize count() by bin(TimeGenerated, 5m), CallerIPAddress | where count_ > 10",
      "threshold": 1,
      "action": "immediate-alert",
      "severity": "high"
    },
    "unusualKeyAccess": {
      "query": "KeyVaultData | where OperationName contains 'SecretGet' | where TimeGenerated > ago(1h) | summarize count() by CallerIPAddress | where count_ > 100",
      "threshold": 1,
      "action": "security-team-notification",
      "severity": "medium"
    },
    "suspiciousSecretAccess": {
      "query": "KeyVaultData | where TimeGenerated between (ago(5m) .. now()) | where OperationName == 'SecretGet' and ResultType == 'Success' | where CallerIPAddress !in ('52.168.112.0/24', '52.169.112.0/24')",
      "threshold": 1,
      "action": "immediate-investigation",
      "severity": "critical"
    }
  }
}
```

2. **Deploy Monitoring Rules:**
```bash
# Create alert rules for Key Vault access
az monitor metrics alert create \
  --name "key-vault-unauthorized-access" \
  --resource-group "prepbettr-prod-rg" \
  --scopes "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/prepbettr-prod-rg/providers/Microsoft.KeyVault/vaults/prepbettr-prod-kv" \
  --condition "count 'ServiceApiResult' Total > 5" \
  --window-size 5m \
  --evaluation-frequency 1m \
  --action-group "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/prepbettr-prod-rg/providers/microsoft.insights/actionGroups/security-alerts"

# Create Log Analytics workspace queries
az monitor log-analytics query \
  --workspace "prepbettr-logs" \
  --analytics-query "KeyVaultData | where OperationName contains 'SecretGet' | where TimeGenerated > ago(1h) | summarize count() by CallerIPAddress | order by count_ desc"
```

3. **Set Up Automated Response:**
```typescript
// azure/securityResponseFunction/index.ts
export default async function (context: Context, alertData: any): Promise<void> {
    const { alertType, severity, details } = alertData;
    
    switch (alertType) {
        case 'suspicious-key-vault-access':
            await handleSuspiciousKeyVaultAccess(details);
            break;
        case 'failed-authentication':
            await handleFailedAuthentication(details);
            break;
        case 'unusual-api-usage':
            await handleUnusualAPIUsage(details);
            break;
    }
};

async function handleSuspiciousKeyVaultAccess(details: any) {
    // Automatically disable suspicious service principal
    if (details.severity === 'critical') {
        await disableServicePrincipal(details.principalId);
        await notifySecurityTeam('Service principal disabled due to suspicious activity', details);
    }
    
    // Log the incident
    await logSecurityIncident({
        type: 'key-vault-access-violation',
        details,
        timestamp: new Date(),
        automated_response: 'principal-disabled'
    });
}
```

---

## 🔧 MEDIUM PRIORITY (1-4 weeks)

### Action #6: Backup & Disaster Recovery for Secrets
**Priority:** P2 - Medium  
**Estimated Effort:** 1-2 days

**Implement Secure Backup Strategy:**

1. **Cross-Region Key Vault Replication:**
```bash
# Create secondary Key Vault in different region
az keyvault create \
  --name "prepbettr-backup-kv" \
  --resource-group "prepbettr-dr-rg" \
  --location "East US" \
  --enabled-for-disk-encryption true \
  --enabled-for-deployment true \
  --enable-soft-delete true \
  --retention-days 90

# Set up replication script
#!/bin/bash
PRIMARY_KV="prepbettr-prod-kv"
BACKUP_KV="prepbettr-backup-kv"

# Get all secrets from primary vault
SECRETS=$(az keyvault secret list --vault-name $PRIMARY_KV --query "[].name" -o tsv)

for SECRET_NAME in $SECRETS; do
    echo "Backing up secret: $SECRET_NAME"
    
    # Get secret value
    SECRET_VALUE=$(az keyvault secret show --vault-name $PRIMARY_KV --name $SECRET_NAME --query "value" -o tsv)
    
    # Create backup in secondary vault
    az keyvault secret set \
        --vault-name $BACKUP_KV \
        --name $SECRET_NAME \
        --value "$SECRET_VALUE" \
        --tags "backup-date=$(date +%Y-%m-%d)" "source=primary-vault"
done
```

2. **Automated Backup Schedule:**
```yaml
# Azure DevOps pipeline for backup
schedules:
- cron: "0 6 * * 0"  # Weekly on Sunday at 6 AM
  displayName: Weekly Key Vault Backup
  branches:
    include:
    - main

stages:
- stage: BackupKeyVault
  jobs:
  - job: BackupSecrets
    steps:
    - task: AzureCLI@2
      inputs:
        azureSubscription: 'PrepBettr-Production'
        scriptType: 'bash'
        scriptPath: 'scripts/backup-keyvault.sh'
      displayName: 'Backup Key Vault Secrets'
```

### Action #7: Compliance & Audit Reporting
**Priority:** P2 - Medium  
**Estimated Effort:** 2-3 days

**Create Compliance Dashboard:**

1. **PowerBI Dashboard for Security Metrics:**
```json
{
  "securityDashboard": {
    "keyMetrics": {
      "secretsRotated": "last-30-days",
      "failedAccessAttempts": "real-time",
      "complianceScore": "calculated-daily"
    },
    "alertsSummary": {
      "critical": "count-by-week",
      "resolved": "resolution-time-avg"
    },
    "accessReports": {
      "byPrincipal": "usage-frequency",
      "bySecret": "access-patterns"
    }
  }
}
```

2. **Automated Compliance Reports:**
```bash
#!/bin/bash
# generate-compliance-report.sh

REPORT_DATE=$(date +%Y-%m-%d)
REPORT_FILE="security-compliance-report-$REPORT_DATE.json"

echo "Generating security compliance report for $REPORT_DATE..."

# Get Key Vault access logs
az monitor activity-log list \
  --resource-group "prepbettr-prod-rg" \
  --start-time "$(date -d '30 days ago' +%Y-%m-%dT%H:%M:%SZ)" \
  --end-time "$(date +%Y-%m-%dT%H:%M:%SZ)" \
  --caller "KeyVault" \
  > keyvault-access-logs.json

# Generate summary
jq '{
  reportDate: "'$REPORT_DATE'",
  summary: {
    totalKeyVaultAccesses: [.[] | select(.resourceType.value == "Microsoft.KeyVault/vaults")] | length,
    failedAccesses: [.[] | select(.resourceType.value == "Microsoft.KeyVault/vaults" and .status.value != "Success")] | length,
    uniqueCallers: [.[] | .caller] | unique | length
  },
  details: [.[] | {
    timestamp: .eventTimestamp,
    caller: .caller,
    operation: .operationName.value,
    status: .status.value,
    resourceId: .resourceId
  }]
}' keyvault-access-logs.json > "$REPORT_FILE"

echo "Report generated: $REPORT_FILE"
```

---

## 🛠️ LOWER PRIORITY (1-3 months)

### Action #8: Infrastructure as Code Security
**Priority:** P3 - Lower  
**Estimated Effort:** 3-5 days

**Secure Infrastructure Templates:**

1. **Azure Resource Manager (ARM) Template Security:**
```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "keyVaultName": {
      "type": "string",
      "metadata": {
        "description": "Name of the Key Vault"
      }
    }
  },
  "resources": [
    {
      "type": "Microsoft.KeyVault/vaults",
      "apiVersion": "2021-11-01-preview",
      "name": "[parameters('keyVaultName')]",
      "location": "[resourceGroup().location]",
      "properties": {
        "sku": {
          "family": "A",
          "name": "premium"
        },
        "tenantId": "[subscription().tenantId]",
        "enabledForDeployment": false,
        "enabledForDiskEncryption": true,
        "enabledForTemplateDeployment": false,
        "enableSoftDelete": true,
        "softDeleteRetentionInDays": 90,
        "enablePurgeProtection": true,
        "networkAcls": {
          "defaultAction": "Deny",
          "bypass": "AzureServices",
          "virtualNetworkRules": [],
          "ipRules": []
        },
        "accessPolicies": []
      }
    }
  ]
}
```

2. **Terraform Security Hardening:**
```hcl
# main.tf - Secure Key Vault configuration
resource "azurerm_key_vault" "main" {
  name                = var.key_vault_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tenant_id          = data.azurerm_client_config.current.tenant_id

  sku_name = "premium"

  # Security hardening
  enabled_for_disk_encryption     = true
  enabled_for_deployment          = false
  enabled_for_template_deployment = false
  purge_protection_enabled        = true
  soft_delete_retention_days      = 90

  # Network restrictions
  network_acls {
    default_action = "Deny"
    bypass         = "AzureServices"
    
    virtual_network_subnet_ids = [
      azurerm_subnet.app_subnet.id
    ]

    ip_rules = var.allowed_ip_ranges
  }

  # Logging
  tags = {
    Environment = var.environment
    CreatedBy   = "terraform"
    Purpose     = "secrets-management"
  }
}

# Diagnostic settings
resource "azurerm_monitor_diagnostic_setting" "keyvault" {
  name               = "keyvault-diagnostics"
  target_resource_id = azurerm_key_vault.main.id
  log_analytics_workspace_id = azurerm_log_analytics_workspace.main.id

  log {
    category = "AuditEvent"
    enabled  = true

    retention_policy {
      enabled = true
      days    = 365
    }
  }

  metric {
    category = "AllMetrics"
    enabled  = true

    retention_policy {
      enabled = true
      days    = 365
    }
  }
}
```

---

## Validation & Testing

### Security Testing Checklist:
- [ ] **Key Vault Access Testing**
  - Test access from authorized applications
  - Verify denial of unauthorized access
  - Validate network restrictions

- [ ] **Secret Rotation Testing**
  - Test automated rotation functionality
  - Verify applications handle key rotation gracefully
  - Test failure scenarios and rollback

- [ ] **Monitoring & Alerting Testing**
  - Trigger test alerts and verify notifications
  - Test automated response procedures
  - Validate log collection and retention

- [ ] **Backup & Recovery Testing**
  - Test secret backup procedures
  - Verify cross-region replication
  - Test disaster recovery scenarios

### Performance Testing:
- [ ] Key Vault response time under load
- [ ] Application startup time with Key Vault integration
- [ ] Secret retrieval performance with network restrictions

### Compliance Validation:
- [ ] SOC 2 Type II requirements mapping
- [ ] GDPR data protection validation
- [ ] Industry security standard compliance

---

## Success Metrics

| Metric | Current State | Target State | Timeline |
|--------|---------------|--------------|----------|
| Secret Rotation Frequency | Manual/Annual | Automated/90-day | 2 weeks |
| Key Vault Access Monitoring | Basic | Advanced + Alerting | 1 week |
| Failed Authentication Detection | None | Real-time | 3 days |
| Infrastructure Security Score | 65% | 90%+ | 6 weeks |
| Security Incident Response Time | 4+ hours | <30 minutes | 2 weeks |

---

## Emergency Contacts

- **DevOps On-Call:** +1-555-0123 (24/7)
- **Security Team:** security@prepbettr.com
- **Infrastructure Lead:** infra-lead@prepbettr.com
- **Incident Command:** incident@prepbettr.com

---

## Documentation Links

- **Azure Key Vault Best Practices:** `/docs/azure/key-vault-security.md`
- **Secret Rotation Procedures:** `/docs/security/secret-rotation.md`
- **Incident Response Playbook:** `/docs/incident-response/key-vault-compromise.md`
- **Monitoring & Alerting Setup:** `/docs/monitoring/security-alerts.md`

---

*This action plan should be reviewed and updated monthly to reflect the evolving security landscape and infrastructure changes.*
