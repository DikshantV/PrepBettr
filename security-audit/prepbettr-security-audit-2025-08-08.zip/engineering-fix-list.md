# Engineering Team - Security Remediation Fix List
**PrepBettr Platform Security Issues**  
**Priority-Ordered Action Items**

---

## 🚨 CRITICAL - Immediate Action Required (0-48 hours)

### Issue #1: Remove Hardcoded API Keys from Documentation
**Priority:** P0 - Critical  
**Estimated Effort:** 2-4 hours  
**Owner:** DevOps + Engineering Lead

**Files to Modify:**
```bash
- README.md (lines 135, 145)
- azure/deploy.sh (line 84)
- Any documentation with API key examples
```

**Actions Required:**
1. Replace all API key examples with placeholder text:
   ```bash
   # Before: AZURE_OPENAI_API_KEY=your_azure_openai_key
   # After: AZURE_OPENAI_API_KEY=<your-azure-openai-api-key>
   ```

2. Add security notice to README:
   ```markdown
   ## 🔐 Security Notice
   Never commit real API keys or secrets to version control.
   Use environment variables and Azure Key Vault for production.
   ```

3. Create `.env.example` file with safe placeholder values
4. Review all deployment scripts and remove hardcoded examples

**Verification:**
- [ ] Run enhanced secret scanner on updated files
- [ ] Verify no real API keys remain in documentation
- [ ] Confirm all examples use clear placeholder format

---

### Issue #2: Enhance Azure Function Authentication
**Priority:** P0 - Critical  
**Estimated Effort:** 1-2 days  
**Owner:** Backend Engineering Team

**Functions to Secure:**
```typescript
- azure/HttpTrigger1/index.ts
- azure/applicationWorker/index.ts
- azure/followUpWorker/index.ts
- azure/jobSearchWorker/index.ts
```

**Required Changes:**

1. **Add Authentication Middleware:**
```typescript
// Add to each function
import { validateFirebaseToken } from '../shared/auth-middleware';

export default async function (context: Context, req: HttpRequest) {
  try {
    // Validate authentication
    const user = await validateFirebaseToken(req.headers.authorization);
    if (!user) {
      context.res = {
        status: 401,
        body: { error: 'Unauthorized' }
      };
      return;
    }

    // Add rate limiting
    const rateLimitCheck = await checkRateLimit(user.uid, context.executionContext.functionName);
    if (!rateLimitCheck.allowed) {
      context.res = {
        status: 429,
        body: { error: 'Rate limit exceeded', retryAfter: rateLimitCheck.retryAfter }
      };
      return;
    }

    // Continue with function logic...
  } catch (error) {
    context.log.error('Authentication error:', error);
    context.res = {
      status: 500,
      body: { error: 'Internal server error' }
    };
  }
}
```

2. **Create Shared Authentication Middleware:**
```typescript
// azure/shared/auth-middleware.ts
import { admin } from 'firebase-admin';

export async function validateFirebaseToken(authHeader: string): Promise<any> {
  if (!authHeader?.startsWith('Bearer ')) {
    throw new Error('Invalid authorization header');
  }
  
  const token = authHeader.substring(7);
  try {
    const decodedToken = await admin.auth().verifyIdToken(token);
    return decodedToken;
  } catch (error) {
    throw new Error('Invalid token');
  }
}
```

3. **Implement Rate Limiting:**
```typescript
// azure/shared/rate-limiter.ts
export async function checkRateLimit(userId: string, functionName: string) {
  // Implement Redis or Azure Cache-based rate limiting
  const key = `rate_limit:${userId}:${functionName}`;
  const current = await redis.incr(key);
  
  if (current === 1) {
    await redis.expire(key, 3600); // 1 hour window
  }
  
  const limit = getRateLimitForFunction(functionName);
  return {
    allowed: current <= limit,
    retryAfter: current > limit ? 3600 : 0
  };
}
```

**Testing Requirements:**
- [ ] Unit tests for authentication middleware
- [ ] Integration tests with valid/invalid tokens
- [ ] Rate limiting tests
- [ ] Error handling tests

---

## 🔥 HIGH Priority (2-7 days)

### Issue #3: Implement Cryptographic Data Anonymization
**Priority:** P1 - High  
**Estimated Effort:** 3-5 days  
**Owner:** Backend Engineering Team

**File to Modify:**
```typescript
lib/services/gdpr-compliance-service.ts
```

**Current Issue:**
```typescript
// Current weak anonymization
private hashUserId(userId: string): string {
  return Buffer.from(userId).toString('base64').substring(0, 12);
}
```

**Required Solution:**
```typescript
import { createHmac, randomBytes } from 'crypto';

export class GDPRComplianceService {
  private readonly anonymizationKey: string;
  
  constructor() {
    // Use Azure Key Vault for anonymization key
    this.anonymizationKey = process.env.ANONYMIZATION_KEY || this.generateKey();
  }

  private generateKey(): string {
    return randomBytes(32).toString('hex');
  }

  // Proper cryptographic anonymization
  private hashUserId(userId: string): string {
    const hmac = createHmac('sha256', this.anonymizationKey);
    hmac.update(userId + 'user_id_salt');
    return hmac.digest('hex').substring(0, 12);
  }

  private hashSessionId(sessionId: string): string {
    const hmac = createHmac('sha256', this.anonymizationKey);
    hmac.update(sessionId + 'session_salt');
    return hmac.digest('hex').substring(0, 8);
  }

  // Add differential privacy for analytics
  anonymizeAnalyticsWithDP(data: any): AnonymizedAnalytics {
    return {
      ...this.anonymizeAnalyticsData(data),
      // Add differential privacy noise
      addedNoise: this.addDifferentialPrivacyNoise(data)
    };
  }

  private addDifferentialPrivacyNoise(data: any): number {
    // Implement Laplace mechanism for differential privacy
    const epsilon = 0.1; // Privacy parameter
    const sensitivity = 1; // Query sensitivity
    const scale = sensitivity / epsilon;
    
    // Generate Laplace noise
    const u = Math.random() - 0.5;
    return scale * Math.sign(u) * Math.log(1 - 2 * Math.abs(u));
  }
}
```

**Additional Requirements:**
1. Store anonymization key in Azure Key Vault
2. Implement key rotation mechanism
3. Add audit logging for anonymization operations
4. Update GDPR export to use proper anonymization

**Testing:**
- [ ] Verify anonymized data cannot be reverse-engineered
- [ ] Test differential privacy implementation
- [ ] Validate GDPR compliance with legal team

---

### Issue #4: Server-Side License Validation
**Priority:** P1 - High  
**Estimated Effort:** 2-3 days  
**Owner:** Full-Stack Engineering Team

**Current Vulnerability:**
License validation logic exposed in client-side code allows bypassing premium features.

**Solution Architecture:**

1. **Create License Validation Service:**
```typescript
// lib/services/license-validation-service.ts
export class LicenseValidationService {
  private readonly licenseSecret: string;
  
  constructor() {
    this.licenseSecret = process.env.DODO_PAYMENTS_LICENSE_SECRET;
  }

  async validateLicense(userId: string, licenseKey: string): Promise<LicenseValidationResult> {
    try {
      // Validate with Dodo Payments API
      const response = await this.validateWithDodoAPI(licenseKey);
      
      // Verify HMAC signature
      const expectedSignature = this.generateLicenseSignature(licenseKey, userId);
      if (response.signature !== expectedSignature) {
        return { valid: false, reason: 'Invalid signature' };
      }
      
      // Check expiration
      if (response.expiresAt < new Date()) {
        return { valid: false, reason: 'License expired' };
      }
      
      // Check usage limits
      const usageValid = await this.validateUsageLimits(userId, response.limits);
      if (!usageValid) {
        return { valid: false, reason: 'Usage limit exceeded' };
      }

      return {
        valid: true,
        tier: response.tier,
        features: response.features,
        expiresAt: response.expiresAt
      };
      
    } catch (error) {
      // Log error but don't expose details
      console.error('License validation error:', error);
      return { valid: false, reason: 'Validation failed' };
    }
  }

  private generateLicenseSignature(licenseKey: string, userId: string): string {
    const hmac = createHmac('sha256', this.licenseSecret);
    hmac.update(licenseKey + userId);
    return hmac.digest('hex');
  }

  private async validateWithDodoAPI(licenseKey: string): Promise<any> {
    // Implement Dodo Payments API validation
    const response = await fetch(`${process.env.DODO_PAYMENTS_API}/validate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.DODO_PAYMENTS_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ licenseKey })
    });

    if (!response.ok) {
      throw new Error('API validation failed');
    }

    return response.json();
  }
}
```

2. **Create License Middleware:**
```typescript
// middleware/license-middleware.ts
export function requireValidLicense(requiredTier: 'free' | 'premium' | 'enterprise') {
  return async (req: NextRequest) => {
    const userId = await getUserIdFromToken(req);
    const licenseService = new LicenseValidationService();
    
    const validation = await licenseService.validateLicense(userId, req.headers.get('x-license-key'));
    
    if (!validation.valid) {
      return new NextResponse(
        JSON.stringify({ error: 'Invalid license', reason: validation.reason }),
        { status: 403 }
      );
    }

    if (!hasRequiredTier(validation.tier, requiredTier)) {
      return new NextResponse(
        JSON.stringify({ error: 'Insufficient license tier' }),
        { status: 403 }
      );
    }

    // Add license info to request context
    req.license = validation;
    return null; // Continue to handler
  };
}
```

3. **Update API Routes:**
```typescript
// app/api/premium-feature/route.ts
import { requireValidLicense } from '@/middleware/license-middleware';

export async function POST(request: NextRequest) {
  // Validate license before processing
  const licenseCheck = await requireValidLicense('premium')(request);
  if (licenseCheck) return licenseCheck;

  // Continue with premium feature logic
  // ...
}
```

**Migration Steps:**
1. Deploy server-side validation service
2. Update all premium feature endpoints
3. Remove client-side validation logic
4. Test with various license scenarios

---

### Issue #5: Enhanced Input Validation Framework
**Priority:** P1 - High  
**Estimated Effort:** 3-4 days  
**Owner:** Full-Stack Engineering Team

**Create Validation Schema Library:**
```typescript
// lib/validation/schemas.ts
import { z } from 'zod';

export const UserProfileSchema = z.object({
  displayName: z.string()
    .min(1, 'Name required')
    .max(100, 'Name too long')
    .regex(/^[a-zA-Z\s\-'\.]+$/, 'Invalid characters'),
  
  email: z.string()
    .email('Invalid email format')
    .max(255, 'Email too long'),
  
  phone: z.string()
    .regex(/^\+?[\d\s\-\(\)]{10,20}$/, 'Invalid phone number')
    .optional(),
  
  bio: z.string()
    .max(1000, 'Bio too long')
    .optional()
});

export const ResumeUploadSchema = z.object({
  fileName: z.string()
    .min(1, 'Filename required')
    .max(255, 'Filename too long')
    .regex(/^[a-zA-Z0-9\s\-\_\.]+$/, 'Invalid filename characters'),
  
  fileSize: z.number()
    .min(1, 'File cannot be empty')
    .max(10 * 1024 * 1024, 'File too large (max 10MB)'),
  
  contentType: z.enum(['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'])
});

export const InterviewRequestSchema = z.object({
  jobTitle: z.string()
    .min(1, 'Job title required')
    .max(200, 'Job title too long'),
  
  company: z.string()
    .min(1, 'Company required')
    .max(200, 'Company name too long'),
  
  jobDescription: z.string()
    .min(10, 'Job description too short')
    .max(10000, 'Job description too long'),
  
  difficulty: z.enum(['entry', 'mid', 'senior', 'executive']),
  
  focusAreas: z.array(z.string()).max(10, 'Too many focus areas')
});
```

**Validation Middleware:**
```typescript
// middleware/validation-middleware.ts
export function validateRequest<T>(schema: z.ZodSchema<T>) {
  return async (req: NextRequest) => {
    try {
      const body = await req.json();
      const validated = schema.parse(body);
      
      // Add validated data to request
      (req as any).validatedData = validated;
      return null;
    } catch (error) {
      if (error instanceof z.ZodError) {
        return new NextResponse(
          JSON.stringify({
            error: 'Validation failed',
            details: error.errors.map(e => ({
              field: e.path.join('.'),
              message: e.message
            }))
          }),
          { status: 400 }
        );
      }
      
      return new NextResponse(
        JSON.stringify({ error: 'Invalid request format' }),
        { status: 400 }
      );
    }
  };
}
```

**Apply to All Routes:**
```typescript
// Example: app/api/profile/route.ts
export async function PUT(request: NextRequest) {
  const validationResult = await validateRequest(UserProfileSchema)(request);
  if (validationResult) return validationResult;

  const userData = (request as any).validatedData;
  // Continue with validated data...
}
```

---

## 🔧 MEDIUM Priority (1-2 weeks)

### Issue #6: Enhanced Error Handling and Security Logging
**Priority:** P2 - Medium  
**Estimated Effort:** 2-3 days

**Create Security Logger:**
```typescript
// lib/security/security-logger.ts
export class SecurityLogger {
  static async logSecurityEvent(event: SecurityEvent) {
    const logEntry = {
      timestamp: new Date().toISOString(),
      type: event.type,
      severity: event.severity,
      userId: event.userId,
      ipAddress: event.ipAddress,
      userAgent: event.userAgent,
      details: event.details,
      sessionId: event.sessionId
    };

    // Log to multiple destinations
    await Promise.all([
      this.logToFirestore(logEntry),
      this.logToAzureMonitor(logEntry),
      this.alertIfCritical(logEntry)
    ]);
  }

  static async logAuthenticationFailure(userId: string, reason: string, request: NextRequest) {
    await this.logSecurityEvent({
      type: 'authentication_failure',
      severity: 'warning',
      userId,
      ipAddress: this.getClientIP(request),
      userAgent: request.headers.get('user-agent'),
      details: { reason },
      sessionId: request.headers.get('x-session-id')
    });
  }

  static async logUnauthorizedAccess(userId: string, resource: string, request: NextRequest) {
    await this.logSecurityEvent({
      type: 'unauthorized_access',
      severity: 'high',
      userId,
      ipAddress: this.getClientIP(request),
      userAgent: request.headers.get('user-agent'),
      details: { resource, action: request.method },
      sessionId: request.headers.get('x-session-id')
    });
  }
}
```

### Issue #7: Implement Request Sanitization
**Priority:** P2 - Medium  
**Estimated Effort:** 1-2 days

```typescript
// lib/security/sanitization.ts
import DOMPurify from 'isomorphic-dompurify';

export class InputSanitizer {
  static sanitizeHTML(input: string): string {
    return DOMPurify.sanitize(input, {
      ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'p', 'br'],
      ALLOWED_ATTR: []
    });
  }

  static sanitizeFileName(fileName: string): string {
    return fileName
      .replace(/[^a-zA-Z0-9\s\-_\.]/g, '')
      .replace(/\s+/g, '_')
      .substring(0, 255);
  }

  static sanitizeSQL(input: string): string {
    return input.replace(/['"\\;]/g, '');
  }

  static removeScriptTags(input: string): string {
    return input.replace(/<script[^>]*>.*?<\/script>/gi, '');
  }
}
```

---

## 🛠️ LOWER Priority (2-4 weeks)

### Issue #8: Implement Content Security Policy
**Priority:** P3 - Lower  
**Estimated Effort:** 1 day

**Add CSP Headers:**
```typescript
// next.config.js
const securityHeaders = [
  {
    key: 'Content-Security-Policy',
    value: `
      default-src 'self';
      script-src 'self' 'unsafe-inline' 'unsafe-eval' https://apis.google.com https://www.gstatic.com;
      style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
      font-src 'self' https://fonts.gstatic.com;
      img-src 'self' data: https:;
      connect-src 'self' https://api.openai.com https://*.firebase.com https://*.azure.com;
      frame-src 'self' https://*.firebase.com;
    `.replace(/\s{2,}/g, ' ').trim()
  }
];
```

### Issue #9: Add Security Headers Middleware
**Priority:** P3 - Lower  
**Estimated Effort:** 0.5 days

```typescript
// middleware/security-headers.ts
export function addSecurityHeaders(response: NextResponse) {
  response.headers.set('X-Frame-Options', 'DENY');
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  response.headers.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  
  return response;
}
```

---

## Testing Requirements

### Unit Tests Required:
- [ ] Authentication middleware tests
- [ ] Input validation schema tests  
- [ ] License validation service tests
- [ ] GDPR anonymization tests
- [ ] Rate limiting tests

### Integration Tests Required:
- [ ] End-to-end authentication flows
- [ ] License validation workflows
- [ ] GDPR compliance workflows
- [ ] Security header validation

### Security Tests Required:
- [ ] Input fuzzing tests
- [ ] Authentication bypass attempts
- [ ] License validation bypass attempts
- [ ] XSS and injection attack tests

---

## Definition of Done

Each issue is considered complete when:
- [ ] Code implementation finished and reviewed
- [ ] Unit tests written and passing
- [ ] Integration tests written and passing
- [ ] Security tests validate fixes
- [ ] Documentation updated
- [ ] Deployed to staging environment
- [ ] Security team verification completed
- [ ] Production deployment approved

---

## Support Resources

- **Security Documentation:** `/docs/security/`
- **Testing Guidelines:** `/docs/testing/security-testing.md`
- **Emergency Contacts:** security-team@prepbettr.com
- **Incident Response:** `/docs/incident-response.md`

---

*This fix list should be reviewed weekly and updated based on progress and newly discovered issues.*
